package resources;

public class Batches {
	
	public static String MKBatch() {
		String MKBatch="Database.executeBatch(new BatchPostStudentClassAssignmentReRun(), 500);";
		return MKBatch;
	}

	public static String NeoFoCFUP1TaskBatch() {
        String NeoFoCFUP1TaskBatch="NeoFoCFUP1TaskBatch blcBatch = new NeoFoCFUP1TaskBatch();Database.executeBatch(blcBatch, 10);";
        return NeoFoCFUP1TaskBatch;
    }
	
	public static String PEtoMentor() {
        String PEtoMentor="Database.executeBatch(new AssignmentRuleForMentorBatch(), 10);";
        return PEtoMentor;
    }
	
   public static String GenerateBTCFeedbackCall() {
        String BTCFeedbackCall= "BLCFeedbackCallBatch blcBatch = new BLCFeedbackCallBatch();Database.executeBatch(blcBatch, 200);";
        return BTCFeedbackCall;
    }
}
