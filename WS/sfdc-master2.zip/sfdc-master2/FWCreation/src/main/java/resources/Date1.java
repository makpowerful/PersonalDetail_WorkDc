package resources;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Date1 {
	public static String currentDate() {
	
	  DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");  
	   LocalDateTime now = LocalDateTime.now();  
	   //System.out.println(dtf.format(now)); 
	   return dtf.format(now);
	   
}
	
	public static String tmrwDate() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MMM/dd/yyyy");        
        LocalDateTime tmrw=LocalDateTime.now().plusDays(1);//Add 1 to current date to get tomorrow's date
       
       System.out.println(dtf.format(tmrw));
       String[] arr=dtf.format(tmrw).split("/");  
       String date=arr[0].concat(" "+arr[1]+", " +arr[2]); //Change the date in the format like 'Nov 01, 2022' 
       return date;
       }
}