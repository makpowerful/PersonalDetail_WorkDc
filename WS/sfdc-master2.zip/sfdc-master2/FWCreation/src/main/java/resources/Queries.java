package resources;

import java.util.concurrent.ThreadLocalRandom;

public class Queries {
    
    
	public static String Chatcount(String val) {
		String Query="SELECT COUNT(Id)recordCount, OwnerId, Action_Type__c\r\n"
				+ "FROM Task\r\n"
				+ "WHERE Status = 'Open'\r\n"
				+ "AND Action_Type__c IN ('Student One-to-One', 'Parent One-to-One', 'Group Chat')\r\n"
				+ "AND OwnerId IN ('"+val+"')\r\n"
				+ "GROUP BY OwnerId, Action_Type__c\r\n"
				+ "ORDER BY COUNT(Id)";
		return Query;
	}
	
	//@Author : Bhavana
	// Query to Change status of audit case from not assigned to Rejected
	public static String StatusChange(String AuditcaseId,String colluserId)
	{
	  //Code to change the status of the audit case to rejected
        String statusChangeCode = "case c = new case();\n"
                + "c.id = '"+AuditcaseId+"';\n"
                + "c.ownerid = '"+colluserId+"';\n"
                + "c.Audit_Status__c = 'Rejected';\n"
                + "update c;";
	    return statusChangeCode;
	}
	
	//@Author : Bhavana
	// Query to Add pdId for the EMI case
	public static String AddpdId(String EMIcaseId,String PDID)
	{
	    String addpdId = "case c = new case();\n"
                + "c.id = '"+EMIcaseId+"';\n"
                + "c.PD_ID__c = '"+PDID+"';\n"
                + "update c;";
	    return addpdId;
	}

	//@Author : Bhavana
	//Query to get group Id  account Id
    public static String GetGrpId(String accId)
    {
        String grpId = "Select Owner_Group_Id__c,Name from account where id = '"+accId+"'";
        return grpId;
    }

    //@Author : Bhavana
    //Query to get assignment rule Id from group Id
    public static String GetAssgnIdProdTy(String prodType, String grpId, String progId,String rc,String name)
    {
        String asgnId = "Select id,(Select id, Assmt3_0_Field__c, Assmt3_0_Value__c, Assmt3_0_Operator__c"
                + " from Assignment_Rule_Entries__r WHERE Assmt3_0_Field__c = 'Product_Type__c' AND "
                + "Assmt3_0_Value__c='"+prodType+"'),Name,Rule_Category__c from Assignment_Rule__c where "
                        + "Group__c='"+grpId+"' and primary_program_Id__c = '"+progId+"' and "
                                + "Rule_Category__c='"+rc+"' and Name = '"+name+"'"; 
        return asgnId;
    }
    
   //@Author : Bhavana
    //Query to get assignment rule Id from group Id
    public static String GetAssgnIdTrpg(String trialProg, String grpId, String progId,String rc,String name)
    {
        String asgnId = "Select id,(Select id, Assmt3_0_Field__c, Assmt3_0_Value__c, Assmt3_0_Operator__c"
                + " from Assignment_Rule_Entries__r WHERE Assmt3_0_Field__c = 'Trial_Program__c' AND "
                + "Assmt3_0_Value__c='"+trialProg+"'),Name,Rule_Category__c from Assignment_Rule__c where"
                        + " Group__c='"+grpId+"' and primary_program_Id__c = '"+progId+"' and "
                                + "Rule_Category__c='"+rc+"'and Name = '"+name+"'";
                        
        return asgnId;
    }
    
    
    //@Author : Bhavana
    //Query to get group Id with trial program
    public static String getGrpIdTrPg(String trialProg,String name,String progId,String rc)
    {
        String asgnId = "select group__c,(SELECT id,Assmt3_0_Field__c,Assmt3_0_Value__c,Assmt3_0_Operator__c "
                + "from Assignment_Rule_Entries__r WHERE Assmt3_0_Field__c = 'Trial_Program__c' AND "
                + "Assmt3_0_Value__c='"+trialProg+"'),Rule_Category__c,id,Name,Student_Unit__c from Assignment_Rule__c where "
                + "Name = '"+name+"' and Primary_Program_Id__c = '"+progId+"' and Rule_Category__c='"+rc+"'";
        return asgnId;
    }

    //@Author : Bhavana
    //Query to get group Id with product type
    public static String getGrpIdProdTy(String prodType,String name,String progId,String rc)
    {
        String asgnId = "select group__c,(SELECT id,Assmt3_0_Field__c,Assmt3_0_Value__c,Assmt3_0_Operator__c"
                + " from Assignment_Rule_Entries__r WHERE Assmt3_0_Field__c = 'Product_Type__c' AND "
                + "Assmt3_0_Value__c='"+prodType+"'),Rule_Category__c,id,Name,Student_Unit__c from Assignment_Rule__c where "
                        + "Name = '"+name+"' and Primary_Program_Id__c = '"+progId+"' and Rule_Category__c='"+rc+"'";
        return asgnId;
    }
    
    //@Author : Bhavana
    //Query to get group Id with trial program
    public static String getGrpIdRegion(String name,String rc)
    {
        String asgnId = "select group__c,Rule_Category__c,id,Name,Student_Unit__c from Assignment_Rule__c where Name = '"+name+"'  and Rule_Category__c='"+rc+"'";
        return asgnId;
    }

   //@Author : Bhavana
    //Query to get group Id with trial program
    public static String getAssgnIdRegion(String grpId,String name,String rc)
    {
        String asgnId = "Select id,Name from Assignment_Rule__c where Group__c='"+grpId+"' and Name = '"+name+"' and Rule_Category__c = '"+rc+"' ";
        return asgnId;
    }
    
    //@Author : Manali
    //Query to get assignment rule Id only for K3
    public static String getGrpIdWOAsgnEntry(String name,String progId)
    {
        String asgnId = "select group__c,id,Name,Student_Unit__c from Assignment_Rule__c where "
                        + "Name = '"+name+"' and Primary_Program_Id__c = '"+progId+"'";
        return asgnId;
    }
    
    //@Author : Manali
    //Query to get assignment rule Id from group Id
    public static String getAssgnIdWOAsgnEntry(String grpId, String progId, String assgnName)
    {
        String asgnId = "Select id,Name from Assignment_Rule__c where Group__c='"+grpId+"'"
                + " and primary_program_Id__c = '"+progId+"' and Name='"+assgnName+"'";
        return asgnId;
    }
}
