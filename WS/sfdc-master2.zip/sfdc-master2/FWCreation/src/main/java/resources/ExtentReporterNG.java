package resources;

import java.util.Locale;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentReporterNG extends base{
	static ExtentReports extent;
	
	public static ExtentReports getReportObject()
	{
	    
	    String OSValue="";
        String OS = System.getProperty("os.name", "generic").toLowerCase(Locale.ENGLISH);
        if ((OS.indexOf("mac") >= 0) || (OS.indexOf("darwin") >= 0)) {
            OSValue = System.getProperty("user.dir")+"//reports//index.html";
        } else if (OS.indexOf("win") >= 0) {
            OSValue = System.getProperty("user.dir")+"\\reports\\index.html";
        }
        
	    //String Windows=System.getProperty("user.dir")+"\\reports\\index.html";
        //String MAC=System.getProperty("user.dir")+"//reports//index.html";
        
		String path = OSValue;
		ExtentSparkReporter reporter = new ExtentSparkReporter(path);
		reporter.config().setReportName("Web Automation Results");
		reporter.config().setDocumentTitle("Test Results");
		
		extent =new ExtentReports();
		extent.attachReporter(reporter);
		extent.setSystemInfo("Tester", "SF QA");
		return extent;
		
	}
}
