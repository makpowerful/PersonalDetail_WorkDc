package pageObjects;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import resources.ExcelData;
import resources.base;

public class loginPO extends base{
	WebDriver driver;

	private String txtUsernamexpath = "//input[@id='username']";
	private String txtPasswordxpath = "//input[@id='password']";
	private String btnLoginxpath = "//input[@type='submit']";
	private String btnNextxpath = "//button[text()='Next']";
	private String txtLoginReasonxpath = "//textarea";
	
	
	
	ExcelData excelData = new ExcelData();
	ArrayList<String> al = new ArrayList<String>();
	
	//Declaring Constructor
	public loginPO(WebDriver driver) {
		this.driver=driver;
	}
	
	//**************************************************Kalam Methods******************************************************
    
	//@Author : Kalam
	//Method to enter Username
	public void EnterUserName(String UN) throws InterruptedException {
		
		driver.findElement(By.xpath(txtUsernamexpath)).sendKeys(UN);
		Thread.sleep(1000);
	}
	
	//@Author : Kalam
	//Method to enter Password
	public void EnterPassword(String Pass) throws InterruptedException {
		
		driver.findElement(By.xpath(txtPasswordxpath)).sendKeys(Pass);
		Thread.sleep(1000);
	}
	
	//@Author : Kalam
	//Method to click on Login button
	public void ClickLoginbtn() throws InterruptedException {
		
		driver.findElement(By.xpath(btnLoginxpath)).click();
		Thread.sleep(1000);
	}
	
	//@Author : Kalam
	//Login as logic
	public void LoginUser(String val) throws InterruptedException, IOException {
		if(val.contains("PE")&&!val.contains("PE-FC")) {
			LoginAsPE_UAT();
		}
		else if(val.contains("Mentor")&&!val.contains("Mentor-FC")) {
			LoginAsMentor_UAT();
		}
		else if(val.contains("IRT")&&!val.contains("IRTO")) {
			LoginAsIRT_UAT();
		}
		else if(val.contains("BLC")) {
			LoginAsBLC_UAT();
		}
		else if(val.contains("IRTO")) {
			LoginAsIRTO_UAT();
		}
		else if(val.contains("Retention")&&!val.contains("ORetention")) {
			LoginAsRetention_UAT();
		}
		else if(val.contains("ORetention")) {
			LoginAsOutsourcedRetention_UAT();
		}
		else if(val.contains("PE-FC")) {
			LoginAsPE_UATFC();
		}
		else if(val.contains("Mentor-FC")) {
			LoginAsMentor_UATFC();
		}
		else if(val.contains("IRT-FC")) {
			LoginAsIRT_UATFC();
		}
		else if(val.contains("BLC-FC")) {
			LoginAsBLC_UATFC();
		}
        else if(val.contains("Retention-FC")&&!val.contains("ORetention-FC")) {
            LoginAsRetention_UATFC();
        }
        else if(val.contains("ORetention-FC")) {
            LoginAsOutsourcedRetention_UATFC();
        }
	}
	
	//@Author : Kalam
	public void LoginAsAdmin_UAT() throws InterruptedException, IOException {
		al = excelData.getData("Admin", "Login", "Type");
		EnterUserName(al.get(1));
		EnterPassword(al.get(2));
		ClickLoginbtn();
		//Thread.sleep(1000);
		//if(driver.findElement(By.xpath("//span[text()='This is Production Environment. ']")).isDisplayed()) {
		//driver.findElement(By.xpath(txtLoginReasonxpath)).sendKeys("Logging in for QA activities");
		//Thread.sleep(300);
		//driver.findElement(By.xpath(btnNextxpath)).click();
		//}
		Thread.sleep(5000);
	}
	
	//@Author : Kalam
	public void LoginAsAdmin_UAT1() throws InterruptedException, IOException {
	    Thread.sleep(5000);
		al = excelData.getData("AdminUAT", "Login", "Type");
		EnterUserName(al.get(1));
		EnterPassword(al.get(2));
		ClickLoginbtn();
		Thread.sleep(5000);
	}
	
	//@Author : Kalam
	public void LoginAsAdmin_UAT2() throws InterruptedException, IOException {
		al = excelData.getData("Admin2", "Login", "Type");
		EnterUserName(al.get(1));
		EnterPassword(al.get(2));
		ClickLoginbtn();
		Thread.sleep(5000);
	}
	
	//@Author : Kalam
	public void LoginAsPE_UAT() throws InterruptedException, IOException {
		al = excelData.getData("PE UAT", "Login", "Type");
		EnterUserName(al.get(1));
		EnterPassword(al.get(2));
		ClickLoginbtn();
		Thread.sleep(5000);
	}
	
	//@Author : Kalam
	public void LoginAsPE_UATFC() throws InterruptedException, IOException {
		al = excelData.getData("PE UATFC", "Login", "Type");
		EnterUserName(al.get(1));
		EnterPassword(al.get(2));
		ClickLoginbtn();
		Thread.sleep(5000);
	}
	
	//@Author : Kalam
	public void LoginAsMentor_UAT() throws InterruptedException, IOException {
		al = excelData.getData("Mentor UAT", "Login", "Type");
		EnterUserName(al.get(1));
		EnterPassword(al.get(2));
		ClickLoginbtn();
		Thread.sleep(5000);
	}
	
	//@Author : Kalam
	public void LoginAsMentor_UATFC() throws InterruptedException, IOException {
		al = excelData.getData("Mentor UATFC", "Login", "Type");
		EnterUserName(al.get(1));
		EnterPassword(al.get(2));
		ClickLoginbtn();
		Thread.sleep(5000);
	}
	
	//@Author : Kalam
	public void LoginAsIRT_UAT() throws InterruptedException, IOException {
		al = excelData.getData("IRT UAT", "Login", "Type");
		EnterUserName(al.get(1));
		EnterPassword(al.get(2));
		ClickLoginbtn();
		Thread.sleep(5000);
	}
	
	//@Author : Kalam
	public void LoginAsIRTO_UAT() throws InterruptedException, IOException {
		al = excelData.getData("IRTO UAT", "Login", "Type");
		EnterUserName(al.get(1));
		EnterPassword(al.get(2));
		ClickLoginbtn();
		Thread.sleep(5000);
	}
	
	//@Author : Kalam
	public void LoginAsIRT_UATFC() throws InterruptedException, IOException {
		al = excelData.getData("IRT UATFC", "Login", "Type");
		EnterUserName(al.get(1));
		EnterPassword(al.get(2));
		ClickLoginbtn();
		Thread.sleep(5000);
	}
	
	//@Author : Kalam
	public void LoginAsRetention_UAT() throws InterruptedException, IOException {
		al = excelData.getData("Retention UAT", "Login", "Type");
		EnterUserName(al.get(1));
		EnterPassword(al.get(2));
		ClickLoginbtn();
		Thread.sleep(5000);
	}
	
	//@Author : Kalam
    public void LoginAsRetention_UATFC() throws InterruptedException, IOException {
        al = excelData.getData("Retention UATFC", "Login", "Type");
        EnterUserName(al.get(1));
        EnterPassword(al.get(2));
        ClickLoginbtn();
        Thread.sleep(5000);
    }
	
  //@Author : Kalam
	public void LoginAsOutsourcedRetention_UAT() throws InterruptedException, IOException {
		al = excelData.getData("Outsourced Retention UAT", "Login", "Type");
		EnterUserName(al.get(1));
		EnterPassword(al.get(2));
		ClickLoginbtn();
		Thread.sleep(5000);
	}
	
	//@Author : Kalam
	public void LoginAsOutsourcedRetention_UATFC() throws InterruptedException, IOException {
        al = excelData.getData("Outsourced Retention UATFC", "Login", "Type");
        EnterUserName(al.get(1));
        EnterPassword(al.get(2));
        ClickLoginbtn();
        Thread.sleep(5000);
    }
	  
	//@Author : Kalam
	public void LoginAsBLC_UAT() throws InterruptedException, IOException {
		al = excelData.getData("BLC UAT", "Login", "Type");
		EnterUserName(al.get(1));
		EnterPassword(al.get(2));
		ClickLoginbtn();
		Thread.sleep(5000);
	}
	
	//@Author : Kalam
	public void LoginAsBLC_UATFC() throws InterruptedException, IOException {
		al = excelData.getData("BLC UAT", "Login", "Type");
		EnterUserName(al.get(1));
		EnterPassword(al.get(2));
		ClickLoginbtn();
		Thread.sleep(5000);
	}
	
	//@Author : Kalam
	public void LoginAsColltnAssociate_UAT() throws InterruptedException, IOException {
		al = excelData.getData("Collection Assistant UAT", "Login", "Type");
		EnterUserName(al.get(1));
		EnterPassword(al.get(2));
		ClickLoginbtn();
		Thread.sleep(15000);
	}
	
	//@Author : Kalam
	public void LoginAsColltnAssociate_UATFC() throws InterruptedException, IOException {
		al = excelData.getData("Collection Assistant UATFC", "Login", "Type");
		EnterUserName(al.get(1));
		EnterPassword(al.get(2));
		ClickLoginbtn();
		Thread.sleep(5000);
	}
	
	//@Author : Kalam
	public void LoginAsColltnAssociateManger_UAT() throws InterruptedException, IOException {
		al = excelData.getData("Collection Manager UAT", "Login", "Type");
		EnterUserName(al.get(1));
		EnterPassword(al.get(2));
		ClickLoginbtn();
		Thread.sleep(6500);
	}
	
	//@Author : Kalam
	public void LoginAsColltnAssociateManger_UATFC() throws InterruptedException, IOException {
		al = excelData.getData("Collection Manager UATFC", "Login", "Type");
		EnterUserName(al.get(1));
		EnterPassword(al.get(2));
		ClickLoginbtn();
		Thread.sleep(6500);
	}
	
	//@Author : Kalam
	public void LoginAsAdmin_QA() throws InterruptedException, IOException {
		al = excelData.getData("AdminQA", "Login", "Type");
		EnterUserName(al.get(1));
		EnterPassword(al.get(2));
		ClickLoginbtn();
		Thread.sleep(5000);
		
	}
	
	//@Author : Kalam
	public void LoginAsAdmin_Dev() throws InterruptedException, IOException {
		al = excelData.getData("AdminDev02", "Login", "Type");
		EnterUserName(al.get(1));
		EnterPassword(al.get(2));
		ClickLoginbtn();
		Thread.sleep(5000);
		
	}
	
	//@Author : Kalam
	public void LoginAsAdmin_QA2() throws InterruptedException, IOException {
		al = excelData.getData("AdminQA2", "Login", "Type");
		EnterUserName(al.get(1));
		EnterPassword(al.get(2));
		ClickLoginbtn();
		Thread.sleep(3000);
		driver.findElement(By.xpath(txtLoginReasonxpath)).sendKeys("Logging in for QA activities");
		Thread.sleep(300);
		driver.findElement(By.xpath(btnNextxpath)).click();
		Thread.sleep(5000);
		
	}
	
	//@Author : Kalam
	public void LoginAsAdmin_Prod() throws InterruptedException, IOException {
		al = excelData.getData("AdminProd", "Login", "Type");
		EnterUserName(al.get(1));
		EnterPassword(al.get(2));
		ClickLoginbtn();
		Thread.sleep(3000);
		//driver.findElement(By.xpath(txtLoginReasonxpath)).sendKeys("Logging in for QA activities");
		//Thread.sleep(800);
		//driver.findElement(By.xpath(btnNextxpath)).click();
		//Thread.sleep(25000);
		Thread.sleep(5000);
		//CookieSession();
		
	}
	
	//@Author : Kalam
	public void LoginAsAdmin_UATFC() throws InterruptedException, IOException {
		al = excelData.getData("Adminuatfc", "Login", "Type");
		EnterUserName(al.get(1));
		EnterPassword(al.get(2));
		ClickLoginbtn();
		Thread.sleep(5000);
	}
	
	//@Author : Kalam
	public void RefreshURL() throws InterruptedException {
		driver.get(driver.getCurrentUrl());
		Thread.sleep(2000);
	}
	
	//@Author : Kalam
	public void CookieSession() {
        // create file named Cookies to store Login Information		
        File file = new File("Cookies.data");							
        try		
        {	  
            // Delete old file if exists
			file.delete();		
            file.createNewFile();			
            FileWriter fileWrite = new FileWriter(file);							
            BufferedWriter Bwrite = new BufferedWriter(fileWrite);							
            // loop for getting the cookie information 		
            	
            // loop for getting the cookie information 		
            for(Cookie ck : driver.manage().getCookies())							
            {			
                Bwrite.write((ck.getName()+";"+ck.getValue()+";"+ck.getDomain()+";"+ck.getPath()+";"+ck.getExpiry()+";"+ck.isSecure()));																									
                Bwrite.newLine();             
            }			
            Bwrite.close();			
            fileWrite.close();	
            
        }
        catch(Exception ex)					
        {		
            ex.printStackTrace();			
        }		
    }

	//@Author : Kalam
	public void LoginAsColltnAssociate_QA() throws InterruptedException, IOException {
		// TODO Auto-generated method stub
		al = excelData.getData("Collection Assistant QA", "Login", "Type");
		EnterUserName(al.get(1));
		EnterPassword(al.get(2));
		ClickLoginbtn();
		Thread.sleep(5000);
	}

	//@Author : Kalam
	public void LoginAsColltnAssociate_Prod() {
		// TODO Auto-generated method stub
		
	}

	//@Author : Kalam
	public void LoginAsColltnAssociateManger_QA() throws InterruptedException, IOException {
		// TODO Auto-generated method stub
		al = excelData.getData("Collection Manager QA", "Login", "Type");
		EnterUserName(al.get(1));
		EnterPassword(al.get(2));
		ClickLoginbtn();
		Thread.sleep(5000);
	}

	//@Author : Kalam
	public void LoginAsColltnAssociateManger_Prod() {
		// TODO Auto-generated method stub
		
	}		
	
	//@Author : Kalam
	public void InternetConnectionIssue() {
		try {
			
			driver.findElement(By.xpath("//button[text()='Try Again']")).click();
			Thread.sleep(1000);
			
		}
		catch(Throwable t) {
			t.printStackTrace();
		}
	}
	
	//@Author : Kalam
	public void SessionLogin() {
		try {
			
			driver.findElement(By.xpath("//button[text()='Log In']")).click();
			driver.get(driver.getCurrentUrl());
			Thread.sleep(3000);
			
		}
		catch(Throwable t) {
			t.printStackTrace();
		}
	}
	
	//@Author : Kalam
	public void FromMiddleUAT(String val) throws InterruptedException, IOException {
		driver.get(val);
		al = excelData.getData("Admin", "Login", "Type");
		EnterUserName(al.get(1));
		EnterPassword(al.get(2));
		ClickLoginbtn();
		Thread.sleep(5000);
		
	}
	
	//@Author : Kalam
	public void FromMiddleUATFC(String val) throws InterruptedException, IOException {
		driver.get(val);
		al = excelData.getData("Adminuatfc", "Login", "Type");
		EnterUserName(al.get(1));
		EnterPassword(al.get(2));
		ClickLoginbtn();
		Thread.sleep(5000);
		
	}
	
	//@Author : Kalam
	public void FromMiddleprod(String val) throws InterruptedException, IOException {
        driver.get(val);
        al = excelData.getData("AdminProd", "Login", "Type");
        EnterUserName(al.get(1));
        EnterPassword(al.get(2));
        ClickLoginbtn();
        Thread.sleep(5000);
        
    }
	
	//@Author : Kalam
	public void switchWindow() throws InterruptedException{
		Set<String> winid = driver.getWindowHandles();
        Iterator<String> iter = winid.iterator();
        iter.next();
        String tab = iter.next();
        Thread.sleep(3000);
        driver.switchTo().window(tab);
	}
	
	//@Author : Kalam
	public void GetDevConsole(String val) throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("window.open()");
		switchWindow();
		if(val.equalsIgnoreCase("UAT")) {
			driver.get("https://byjusprod--byjusuat.my.salesforce.com/_ui/common/apex/debug/ApexCSIPage");
			Thread.sleep(3500);
		}
		else if (val.equalsIgnoreCase("QA")) {
			driver.get("https://byjusprod--byjusqa.my.salesforce.com/_ui/common/apex/debug/ApexCSIPage");
			Thread.sleep(3500);
		}
		else if(val.equalsIgnoreCase("UATFC")) {
			driver.get("https://byjusprod--byjusuatfc.my.salesforce.com/_ui/common/apex/debug/ApexCSIPage");
			Thread.sleep(3500);
		}
		else {
			driver.get("https://byjusprod.my.salesforce.com/_ui/common/apex/debug/ApexCSIPage");
			Thread.sleep(3500);
		}
	}
	
	//@Author : Kalam
	public void SwitchUser(String val) throws Exception {
		jsClick(driver.findElement(By.xpath("//a[contains(@class,'menuTriggerLink')]")));
		Thread.sleep(2000);
		//jsClick(driver.findElement(By.xpath("//ul[@class='scrollable']/li[1]")));
		visibleText(By.xpath("//ul[@class='scrollable']/li[@id='related_setup_app_home']"));
		Thread.sleep(300);
		Actions ac=new Actions(driver);
		ac.moveToElement(driver.findElement(By.xpath("//ul[@class='scrollable']/li[@id='related_setup_app_home']"))).build().perform();
		driver.findElement(By.xpath("//ul[@class='scrollable']/li[@id='related_setup_app_home']")).click();
		Thread.sleep(2000);
		switchWindow();
		driver.findElement(By.xpath("//input[@placeholder='Search Setup']")).sendKeys(val);
		//Thread.sleep(2000);
		visibleText(By.xpath("//span[@title='"+val+"']"));
		
		driver.findElement(By.xpath("//span[@title='"+val+"']")).click();
		Thread.sleep(2000);
		
		retryForDetachedFrame(driver, "//iframe", 0);
		WebElement frame=driver.findElement(By.xpath("//iframe"));
		Thread.sleep(800);
		driver.switchTo().frame(frame);
		Thread.sleep(800);
		driver.findElement(By.xpath("//input[@title='Login']")).click();
		Thread.sleep(8000);
		retryForDetachedFrame(driver, "//iframe", 0);
		driver.switchTo().defaultContent();
		Thread.sleep(2000);		
	}
	
	//@Author : Kalam
	public void LogbackwithUser(String val) throws Exception {
	    Thread.sleep(800);
		driver.findElement(By.xpath("//input[@placeholder='Search Setup']")).sendKeys(val);
		visibleText(By.xpath("//span[@title='"+val+"']"));
		try {
		clickButton(driver.findElement(By.xpath("//span[@title='"+val+"']")));
		}
		catch(Exception e) {
		    clickButton(driver.findElement(By.xpath("//span[@title='"+val+"']")));  
		    e.printStackTrace();
		}
		Thread.sleep(2000);
		
		retryForDetachedFrame(driver, "//iframe", 0);
		WebElement frame=driver.findElement(By.xpath("//iframe"));
		Thread.sleep(800);
		try {
		driver.switchTo().frame(frame);
		}
		catch(Exception e) {
		   e.printStackTrace();
		   driver.switchTo().frame(frame);
		}
		Thread.sleep(800);
		driver.findElement(By.xpath("//input[@title='Login']")).click();
		Thread.sleep(8000);
		retryForDetachedFrame(driver, "//iframe", 0);
		driver.switchTo().defaultContent();
		Thread.sleep(2000);		
	}
	
	//@Author : Kalam
	public void SwitchUsernProfile_Prod(String user,String profile) throws Exception {
		jsClick(driver.findElement(By.xpath("//a[contains(@class,'menuTriggerLink')]")));
		Thread.sleep(2000);
		driver.findElement(By.xpath("//ul[@class='scrollable']/li[1]")).click();
		Thread.sleep(2000);
		switchWindow();
		driver.findElement(By.xpath("//input[@placeholder='Search Setup']")).sendKeys(user);
		Thread.sleep(2000);
		jsClick(driver.findElement(By.xpath("//span[@title='"+user+"']")));
		Thread.sleep(2000);
		
		retryForDetachedFrame(driver, "//iframe", 0);
		WebElement frame=driver.findElement(By.xpath("//iframe"));
		Thread.sleep(800);
		driver.switchTo().frame(frame);
		Thread.sleep(800);
		driver.findElement(By.xpath("//input[@title='Edit']")).click();
		Thread.sleep(3000);
		retryForDetachedFrame(driver, "//iframe", 0);
		WebElement frame1=driver.findElement(By.xpath("//iframe"));
		Thread.sleep(800);
		driver.switchTo().frame(frame1);
		Thread.sleep(800);
		Select sel= new Select(driver.findElement(By.xpath("//select[@id='Profile']")));
		sel.selectByVisibleText(profile);
		driver.findElement(By.xpath("//input[@title='Save']")).click();
		Thread.sleep(3000);
		retryForDetachedFrame(driver, "//iframe[@force-alohapage_alohapage]", 0);
		WebElement frame2=driver.findElement(By.xpath("//iframe[@force-alohapage_alohapage]"));
		Thread.sleep(800);
		driver.switchTo().frame(frame2);
		Thread.sleep(800);
		driver.findElement(By.xpath("//input[@title='Login']")).click();
		Thread.sleep(8000);
		retryForDetachedFrame(driver, "//iframe", 0);
		driver.switchTo().defaultContent();
		Thread.sleep(2000);		
	}
	
	//@Author : Kalam
	//Logout and switch to home
	public void Logouthome() throws InterruptedException {
		try {
			driver.findElement(By.xpath("//a[contains(text(),'Log out')]")).click();
			Thread.sleep(3000);
			}
			catch(WebDriverException e){
				driver.navigate().refresh();
				Thread.sleep(2000);
				driver.findElement(By.xpath("//a[contains(text(),'Log out')]")).click();	
				Thread.sleep(3000);
			}
			 catch(Exception ee)
		    {
		        ee.printStackTrace();
		        throw ee;
		    }
		Thread.sleep(1000);
		ReturntoMain();
	}
	
	//@Author : Kalam
	//Only Logout
//<<<<<<< HEAD
			public void OnlyLogout1() throws InterruptedException {
				try {
					jsClick(driver.findElement(By.xpath("//a[contains(text(),'Log out')]")));
					Thread.sleep(3000);
					}
					catch(WebDriverException e){
						Thread.sleep(500);
						jsClick(driver.findElement(By.xpath("//a[contains(text(),'Log out')]")));
						Thread.sleep(3000);
					}
					 catch(Exception ee)
				    {
				        ee.printStackTrace();
				        throw ee;
				    }
				Thread.sleep(1000);
			}
	
//======
			//@Author : Kalam
		public void OnlyLogout() throws InterruptedException {
			try {
				jsClick(driver.findElement(By.xpath("//a[contains(text(),'Log out')]")));
				Thread.sleep(2000);
				}
				catch(WebDriverException e){
				    while(!isDisplayed(By.xpath("//a[contains(text(),'Log out')]"))) {
				        driver.get(driver.getCurrentUrl());
	                    Thread.sleep(500); 
				    }
					visibleText(By.xpath("//a[contains(text(),'Log out')]"));
					jsClick(driver.findElement(By.xpath("//a[contains(text(),'Log out')]")));
					Thread.sleep(2000);
				}
				 catch(Exception ee)
			    {
			        ee.printStackTrace();
			        throw ee;
			    }
			Thread.sleep(1000);
		}
		
		//Author : Kalam
		  public boolean isDisplayed(By element) {
		        List<WebElement> list = driver.findElements(element);
		        //System.out.println(list.toString());
		        boolean value = false;
		        if (!list.isEmpty()) {
		            if (list.get(0).isDisplayed()) {
		                value = true;
		                return value;
		            }
		        } else {

		            return value;
		        }
		        return value;
		    }
//>>>>>>> master2
	
		//@Author : Kalam
    public void ReturntoMain() throws InterruptedException {
    	Thread.sleep(1500);
    	visibleText(By.xpath("//div[@class='slds-icon-waffle']"));
		driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
		Thread.sleep(1000);
		visibleText(By.xpath("//input[@placeholder='Search apps and items...']"));
		driver.findElement(By.xpath("//input[@placeholder='Search apps and items...']")).sendKeys("Service Console_");
		Thread.sleep(1000);
		visibleText(By.xpath("//span/p/b[contains(text(),'Service Console_')]"));
		driver.findElement(By.xpath("//span/p/b[contains(text(),'Service Console_')]")).click();
		Thread.sleep(6000);
    }
    
  //@Author : Kalam
	   public void retryForDetachedFrame(final WebDriver driver, final String elementXpath, final int frameId) throws Exception {
	        int webDriverExceptionCounter = 0;
	        while (webDriverExceptionCounter < 5) {
	            try {
	                driver.findElement(By.xpath(elementXpath));
	                break;
	            } catch (final WebDriverException ex) {
	                webDriverExceptionCounter++;
	                if (webDriverExceptionCounter == 5) {
	                   // log.error("WebDriverException, not trying again: {}", webDriverExceptionCounter);
	                    throw ex;
	                } else {
	                   // log.info("WebDriverException, retrying: {}", webDriverExceptionCounter);
	                    Thread.sleep(500);
	                    final WebDriverWait wait = new WebDriverWait(driver, 15);
	                    wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameId));
	                }
	            } catch (final Exception e) {
	               // log.error("Exception: {}", e.getClass());
	                throw e;
	            }
	        }
	    }
	   
	 //@Author : Kalam
		public boolean visibleText(By element)
		{
			WebDriverWait wait= new WebDriverWait(driver, 50);
			
			wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));
			
			System.out.println("Element is visible");
			return false;
		}
	   
		//@Author : Kalam
	    public void jsClick(WebElement el) {
			try {
				JavascriptExecutor jse = (JavascriptExecutor)driver;
				jse.executeScript("arguments[0].click();", el);
				System.out.println("Element clicked");
			} catch (Exception e){
				System.out.println("=============================================================");
				System.out.println("Exception-jsClick(): "+e.getMessage());
				//takeScreenShot();
				e.printStackTrace();
				System.out.println("=============================================================");
			}
		}

	  //@Author : Kalam
	    public void clickButton(WebElement element)
	    {
	        WebDriverWait wait= new WebDriverWait(driver, 50);
	        
	        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));
	        
	        System.out.println("Element is clickable");
	        element.click();
	    }
	    
	  //@Author : Kalam
	    public void NavigatetoURL(String url)
	    {
	    	driver.get(url);
	    }
	    
	  //**************************************************Manish Methods*****************************************************    
	    
	    
	  //=================================================Author :: Manish Goyal=====================================
        //  This method only Logout and switch to user 'user1'
        //Author : Manish Goyal
        public void onlyLogoutAndSwitchToUser(WebDriver driver,String user) throws Exception
        {
            OnlyLogout();
            driver.findElement(By.xpath(CreatedCaseRecordPO.textfield_SearchField)).click();
            driver.findElement(By.xpath(CreatedCaseRecordPO.textfield_SearchField)).sendKeys(user);
            visibleText(By.xpath("//ul[@role='presentation']/li[2]/a/div[2]/span[@title='"+user+"']"));
            Thread.sleep(3000);
            driver.findElement(By.xpath("//ul[@role='presentation']/li[2]/a/div[2]/span[@title='"+user+"']")).click();      
            Thread.sleep(5000);     
                    
            retryForDetachedFrame(driver, "//iframe[@title='User: "+user+" ~ Salesforce - Enterprise Edition']", 0);
            WebElement frame=driver.findElement(By.xpath("//iframe[@title='User: "+user+" ~ Salesforce - Enterprise Edition']"));
            Thread.sleep(800);
            driver.switchTo().frame(frame);
            Thread.sleep(800);
            driver.findElement(By.xpath("//input[@title='Login']")).click();
            Thread.sleep(8000);
            //retryForDetachedFrame(driver, "//iframe[@title='User: "+user+" ~ Salesforce - Enterprise Edition']", 0);
            driver.switchTo().defaultContent();
            Thread.sleep(2000);     
        }
        
	    
	    //This method switches the user when two window tabs are already opened 
	    //Author : Manish Goyal
	    public void SwitchUserThreeTabs(String val) throws Exception {
			jsClick(driver.findElement(By.xpath("//a[contains(@class,'menuTriggerLink')]")));
			Thread.sleep(2000);
			//jsClick(driver.findElement(By.xpath("//ul[@class='scrollable']/li[1]")));
			driver.findElement(By.xpath("//ul[@class='scrollable']/li[@id='related_setup_app_home']")).click();
			Thread.sleep(2000);
			switchWindowThreeTabs();
			driver.findElement(By.xpath("//input[@placeholder='Search Setup']")).sendKeys(val);
			//Thread.sleep(2000);
			visibleText(By.xpath("//span[@title='"+val+"']"));
			driver.findElement(By.xpath("//span[@title='"+val+"']")).click();
			Thread.sleep(2000);
			
			retryForDetachedFrame(driver, "//iframe", 0);
			WebElement frame=driver.findElement(By.xpath("//iframe"));
			Thread.sleep(800);
			driver.switchTo().frame(frame);
			Thread.sleep(800);
			driver.findElement(By.xpath("//input[@title='Login']")).click();
			Thread.sleep(8000);
			retryForDetachedFrame(driver, "//iframe", 0);
			driver.switchTo().defaultContent();
			Thread.sleep(2000);		
		}
	    
	    //This method switches to third tab ( when three tabs are opened.
	    //Author : Manish Goyal
	    public void switchWindowThreeTabs() throws InterruptedException{
			Set<String> winid = driver.getWindowHandles();
	        Iterator<String> iter = winid.iterator();
	        iter.next();
	        iter.next();
	        String tab = iter.next();
	        Thread.sleep(3000);
	        driver.switchTo().window(tab);
		}
	    
	    //@Author :: Manish Goyal
	    public static void navigateToAssignmentRule(WebDriver driver) throws InterruptedException {
	        Thread.sleep(1500);
	        driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
	        Thread.sleep(1000);
	        driver.findElement(By.xpath("//input[@placeholder='Search apps and items...']")).sendKeys("Assignment Rules");
	        Thread.sleep(1000);
	        driver.findElement(By.xpath("//span/p/b[contains(text(),'Assignment Rules')]")).click();
	        Thread.sleep(2000);
	    }
	    
	  //@Author :: Manish Goyal
	    public void SwitchUsernProfile_Prod_threetabs(String val) throws Exception {
	        jsClick(driver.findElement(By.xpath("//a[contains(@class,'menuTriggerLink')]")));
	        Thread.sleep(2000);
	        driver.findElement(By.xpath("//ul[@class='scrollable']/li[1]")).click();
	        Thread.sleep(2000);
	        switchWindowThreeTabs();
	        driver.findElement(By.xpath("//input[@placeholder='Search Setup']")).sendKeys("Testing User");
	        Thread.sleep(2000);
	        driver.findElement(By.xpath("//span[@title='Testing User']")).click();
	        Thread.sleep(2000);
	        
	        retryForDetachedFrame(driver, "//iframe", 0);
	        WebElement frame=driver.findElement(By.xpath("//iframe"));
	        Thread.sleep(800);
	        driver.switchTo().frame(frame);
	        Thread.sleep(800);
	        driver.findElement(By.xpath("//input[@title='Edit']")).click();
	        Thread.sleep(3000);
	        retryForDetachedFrame(driver, "//iframe", 0);
	        WebElement frame1=driver.findElement(By.xpath("//iframe"));
	        Thread.sleep(800);
	        driver.switchTo().frame(frame1);
	        Thread.sleep(800);
	        Select sel= new Select(driver.findElement(By.xpath("//select[@id='Profile']")));
	        sel.selectByVisibleText(val);
	        driver.findElement(By.xpath("//input[@title='Save']")).click();
	        Thread.sleep(3000);
	        retryForDetachedFrame(driver, "//iframe[@force-alohapage_alohapage]", 0);
	        WebElement frame2=driver.findElement(By.xpath("//iframe[@force-alohapage_alohapage]"));
	        Thread.sleep(800);
	        driver.switchTo().frame(frame2);
	        Thread.sleep(800);
	        driver.findElement(By.xpath("//input[@title='Login']")).click();
	        Thread.sleep(8000);
	        retryForDetachedFrame(driver, "//iframe", 0);
	        driver.switchTo().defaultContent();
	        Thread.sleep(2000);     
	    }
	    
	    //**************************************************Manali Methods*****************************************************
	    //**************************************************Anil Methods*******************************************************
	    //**************************************************Amit Methods*******************************************************
	    //**************************************************Sumit Methods******************************************************
	    
	    public void logout() {
	        driver.findElement(By.xpath("//a[@class='action-link']")).click();
	    }
	    //**************************************************Bhavana Methods****************************************************
	    
	    //@Author :: Bhavana 
	    //Navitgate to group of specified assignment rule assignment rules
	    public void navToAssignmentruleGroup(String assRule) throws InterruptedException
	    {
	        jsClick(driver.findElement(By.xpath("//h1/span[text()='Assignment Rules']/following::button[@title='Select a List View']")));
	        Thread.sleep(1000);
	        jsClick(driver.findElement(By.xpath("//h1/span[text()='Assignment Rules']/following::ul/following::span[text()='All']")));
	        Thread.sleep(2000);
	        driver.findElement(By.xpath("//input[@name='Assignment_Rule__c-search-input']")).sendKeys(assRule);
	        driver.findElement(By.xpath("//input[@name='Assignment_Rule__c-search-input']")).sendKeys(Keys.ENTER);
	        Thread.sleep(2000);
	        
	        jsClick(driver.findElement(By.xpath("//tr/td[4]/span/a[contains(text(),'"+ assRule + "')]")));
	        Thread.sleep(1000);
	    }
	    
        
        public void navToAssignmentRules() throws InterruptedException {
            Thread.sleep(1500);
            visibleText(By.xpath("//div[@class='slds-icon-waffle']"));
            driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
            Thread.sleep(2000);
            visibleText(By.xpath("//input[@placeholder='Search apps and items...']"));
            driver.findElement(By.xpath("//input[@placeholder='Search apps and items...']")).sendKeys("Assignment Rules");
            Thread.sleep(2000);
            visibleText(By.xpath("//span/p/b[contains(text(),'Assignment Rules')]"));
            driver.findElement(By.xpath("//span/p/b[contains(text(),'Assignment Rules')]")).click();
            Thread.sleep(6000);
        }
        
        public void SwitchDefaultContent() throws Exception {
            retryForDetachedFrame(driver, "//iframe", 0);
            driver.switchTo().defaultContent();
            Thread.sleep(1500);
        }
        
        
        
	    //**************************************************Saurabh Methods****************************************************
	    
}
