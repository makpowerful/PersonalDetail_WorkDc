package pageObjects;



import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.ui.ExpectedConditions;

import org.openqa.selenium.support.ui.WebDriverWait;

import resources.base;

public class OpenActivitiesPO extends base {
	WebDriver driver;

	//private String btnNextxpath= "//button[text()='Next']";
	//private String lblAmtPaidbyCusxpath= "//label[text()='Amount Paid By Customer']/following::input";
	//private String btnListboxMovexpath = "//button[@title='Move selection to Selected']";
	//private String txtPayRefxpath = "//label[text()='Payment Reference']/following::input";
	//private String ddCollectionChnnelxpath = "//label[text()='Collection Channel']/following::button";
	//private String lblErrorMessxpath = "//div[@class='slds-text-color_error']";
	//private String ddNoEMICollxpath = "//select[@name='No_Of_EMI_Collected']";
	//private String ddTOCollAPxpath = "//select[@name='Type_Of_Collection_alreadyPaid']";
	//private String ddEligfrRefxpath = "//select[@name='Eligible_For_Refund']";


	// Declaring Constructor
	public OpenActivitiesPO(WebDriver driver) {
		this.driver = driver;
	}
	
	//**************************************************Kalam Methods******************************************************

	
	//@Author : Kalam
	//Click Capture call details
	public void ClickCaptureDetails() throws Exception {
    driver.findElement(By.xpath("//a[@title='Capture Call Details']")).click();
    Thread.sleep(3500);
	}
	
	//@Author : Kalam
	//Select Latest Open Activities Task
	public void LatestOpenActivity() throws InterruptedException {
		driver.findElement(By.xpath("//tr/th/span/a")).click();
		Thread.sleep(3000);
	}
 
	//@Author : Kalam
    //Capture Assigned To 
	public String CaptureAssignedTo() throws InterruptedException {
		String AssignedTo= driver.findElement(By.xpath("//span[text()='Task Information']/following::span[text()='Assigned To']/following::span//span")).getText();
		return AssignedTo;
	}
	
	//@Author : Kalam
	//Capture Action Type
	public String CaptureActionType() throws InterruptedException {
		String ActionType= driver.findElement(By.xpath("//div[text()='Task']/following::span[text()='Action Type']/following::span/span")).getText();
		return ActionType;
	}
	
	//@Author : Kalam
	//Delete Selected Task Open Activities
	public void DeleteSelectedTask_OpenActivities(String val) throws InterruptedException {
	    visibleText(By.xpath("//h1[text()='Open Activities']/following::*[text()='"+val+"']"));
	    jsClick(driver.findElement(By.xpath("//h1[text()='Open Activities']/following::*[text()='"+val+"']/following::a[contains(@class,'icon-x-small slds-button')]")));
	    Thread.sleep(800);
	    jsClick(driver.findElement(By.xpath("//a[@title='Delete']")));
        Thread.sleep(1200);
        driver.findElement(By.xpath("//button/span[text()='Delete']")).click();
        Thread.sleep(2000);
	    
	}
	
	//@Author : Kalam
    //Delete Selected Task Open Activities
    public void DeleteSelectedTask_ActivityHistory(String val) throws InterruptedException {
        visibleText(By.xpath("//h1[text()='Activity History']/following::*[text()='"+val+"']"));
        jsClick(driver.findElement(By.xpath("//h1[text()='Activity History']/following::*[text()='"+val+"']/following::a[contains(@class,'icon-x-small slds-button')]")));
        Thread.sleep(800);
        jsClick(driver.findElement(By.xpath("//a[@title='Delete']")));
        Thread.sleep(1200);
        driver.findElement(By.xpath("//button/span[text()='Delete']")).click();
        Thread.sleep(2000);
        
    }
	
	//@Author : Kalam
	//Click Specific Task Selection
	public void SelectTaskNumber(String val,int no) throws InterruptedException {
	    visibleText(By.xpath("//h1[text()='Open Activities']"));
	    try {
	    jsClick(driver.findElement(By.xpath("//h1[text()='Open Activities']/following::*[text()='"+val+"']["+no+"]")));
	    }
	    catch(Exception e) {
	        driver.get(driver.getCurrentUrl());
	        Thread.sleep(2000);
	        visibleText(By.xpath("//h1[text()='Open Activities']"));
	        jsClick(driver.findElement(By.xpath("//h1[text()='Open Activities']/following::*[text()='"+val+"']["+no+"]")));
	    }
	    Thread.sleep(2000);
	}
	
	//@Author : Kalam
    //Verify Task is present
    public boolean VerifyTaskpresent(String val) throws InterruptedException {
        visibleText(By.xpath("//h1[text()='Open Activities']/following::*[text()='"+val+"']"));
        WebElement ele = driver.findElement(By.xpath("//h1[text()='Open Activities']/following::*[text()='"+val+"']"));
        Thread.sleep(200);
        return ele.isDisplayed();
        
    }
    
    //@Author : Kalam
    //Capture Assgined user to Task 
    public String CaptureAssignedUsertoTask(String val) throws InterruptedException {
        visibleText(By.xpath("//h1[text()='Open Activities']/following::*[text()='"+val+"']"));
        return driver.findElement(By.xpath("//h1[text()='Open Activities']/following::*[text()='"+val+"']/following::td[2]")).getText();
    }
	
	//@Author : Kalam
	//To capture the Record Count in queue
    public String[] RecrdCnt() throws InterruptedException {
    Thread.sleep(1000); 
    String[] RecordCount=driver.findElement(By.xpath("//span[@class='countSortedByFilteredBy']")).getText().split(" item");
    System.out.println(RecordCount[0]);
    Thread.sleep(2000);
    return RecordCount;
    }
	
  //@Author : Kalam
	//Navigate back to Account screen
	public void NavBackAccount() throws InterruptedException {
		try {
		driver.findElement(By.xpath("//span[text()='Name']/following::a")).click();
		Thread.sleep(2500);
		}
		catch(WebDriverException e){
			driver.findElement(By.xpath("//span[text()='Name']/following::a")).click();	
			Thread.sleep(3000);
		}
		 catch(Exception ee)
	    {
	        ee.printStackTrace();
	        throw ee;
	    }
	}
	  
	//@Author : Kalam
    public void jsClick(WebElement el) {
		try {
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("arguments[0].click();", el);
			System.out.println("Element clicked");
		} catch (Exception e){
			System.out.println("=============================================================");
			System.out.println("Exception-jsClick(): "+e.getMessage());
			takeScreenShot();
			e.printStackTrace();
			System.out.println("=============================================================");
		}
	}
    
  //@Author : Kalam
    public boolean visibleText(By element)
    {
        WebDriverWait wait= new WebDriverWait(driver, 100);
        
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));
        
        System.out.println("Element is visible");
        return false;
    }
	  
    //**************************************************Manali Methods*****************************************************
    //@Author : Manali Shivareddy
    // To verify open task 
    public boolean textDisplayed(String val) {
        List<WebElement> l= driver.findElements(By.xpath("//h1[text()='Open Activities']/following::*[text()='"+val+"']"));
        boolean value = false;
        // verify list size
        if ( l.size() == 0){
           return value;
        } else {
           value=true;
           return value;
        }  
    }
    //**************************************************Manish Methods*****************************************************
    //**************************************************Anil Methods*******************************************************
    //**************************************************Amit Methods*******************************************************
    //**************************************************Sumit Methods******************************************************
    //**************************************************Bhavana Methods****************************************************
    //**************************************************Saurabh Methods****************************************************
}
