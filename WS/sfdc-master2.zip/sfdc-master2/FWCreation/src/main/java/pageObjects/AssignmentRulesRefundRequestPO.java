package pageObjects;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.time.LocalDate;
import java.time.DayOfWeek;
import java.time.format.TextStyle;
import java.util.Locale;
import java.util.TimeZone;

import org.apache.commons.collections4.Get;
import org.apache.commons.lang.time.DateUtils;
import org.junit.Assert;
//import testCases.;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import com.github.javafaker.Faker;

import payLoad.payLoad_SinglePrgm;
import resources.Date1;
import resources.ExcelData;
import resources.base;

public class AssignmentRulesRefundRequestPO extends base {

    WebDriver driver;
    
    public AssignmentRulesRefundRequestPO(WebDriver driver) {
        this.driver = driver;
    }
    
 
    //**************************************************Manish Methods*****************************************************
 
    ExcelData excelData = new ExcelData();
    SoftAssert softassert = new SoftAssert();
    ArrayList<String> proddummyuser = new ArrayList<String>();
    ArrayList<String> al2 = new ArrayList<String>();
    ArrayList<String> al4 = new ArrayList<String>();
    ArrayList<String> al7 = new ArrayList<String>();
    ArrayList<String> al8 = new ArrayList<String>();
    ArrayList<String> al9 = new ArrayList<String>();
    // ArrayList<String> childCases=new ArrayList<String>();

    static Faker faker = new Faker();
    static String firstName = faker.name().firstName();
    static String lastName = faker.name().lastName();
    static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);

    public void assignmentRuleVerificationRR(WebDriver driver, ArrayList<String> al, ArrayList<String> al3,
            ArrayList<String> al6, String shippedRegion, String classValue, String currentURL) throws Exception {
        String Accountid = null;
        this.CurrURL = currentURL;
        this.driver = driver;
        loginPO lo = new loginPO(driver);
        String AccountURL = "";
        CreatedAccountPO ac = new CreatedAccountPO(driver);
        String program1 = al6.get(0);
        String program2 = al6.get(1);
        System.out.println(program1 + "  " + program2);
        proddummyuser = excelData.getData("TC1", "ProdDummyUser", "Tcid");
        if (CurrURL.contains("--byjusuatfc")) {
            al2 = excelData.getData("PE User UATFC", "Login", "Type");
            log.info("Logging in as Admin to UATFC Env then switching user to PE");
            lo.LoginAsAdmin_UATFC();
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_SinglePrgm.AccountidCreationResponse2_UATFC(program1, program2, shippedRegion,
                    classValue, "BHLP");
            log.info("Launching the newly created Account id " + Accountid);
        } else if (CurrURL.contains("--byjusuat")) {

            al2 = excelData.getData("PE User UAT", "Login", "Type");
            log.info("Logging in as Admin to UAT then switching user to PE");
            lo.LoginAsAdmin_UAT1();
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_SinglePrgm.AccountidCreationResponse2_UAT(program1, program2, shippedRegion, classValue,
                    "BHLP");
            log.info("Launching the newly created Account id " + Accountid);

        } else {

            // al2 = excelData.getData("Collection Assistant", "Login", "Type");
            log.info("Logging in as Admin to Prod");
            lo.LoginAsAdmin_Prod();
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_SinglePrgm.AccountidCreationResponse2_Prod(program1, program2, shippedRegion,
                    classValue, "BHLP");
            log.info("Launching the newly created Account id " + Accountid);
        }
        try {

            closeTabWindows();
            // Open the account by searching PID
            ac.Notification();
            AccountURL = CurrURL + Accountid;
            driver.get(AccountURL);
            System.out.println(AccountURL);
            ac.AdditionalWait();
            CreatedAccountPO ca1 = new CreatedAccountPO(driver);
            String OwnerName = ca1.CaptureAccOwnrNam();
            System.out.println("Owner of the Account is " + OwnerName);
            if (CurrURL.contains("--byjusuat") || CurrURL.contains("--byjusuatfc")) {
                String AccountOwner = ac.AccOwnerCheck();
                if (!al2.get(1).equalsIgnoreCase(AccountOwner)) {
                    ac.AssignAccount(al2.get(1));
                }
            } else {
                ac.AssignAccount("Testing User");
            }

            if (CurrURL.contains("--byjusuat") && !CurrURL.contains("--byjusuatfc")) {
                lo.SwitchUser(al2.get(1));
                ac.closeTabWindows();
                ac.Notification();
                ac.NavBackToAccount();
                driver.get(AccountURL);
                ac.AdditionalWait();

            } else if (CurrURL.contains("--byjusuatfc")) {
                lo.SwitchUser(al2.get(1));
                ac.closeTabWindows();
                ac.Notification();
                // ac.NavBackToAccount();
                driver.get(AccountURL);
                ac.AdditionalWait();

            } else {
                lo.SwitchUsernProfile_Prod(proddummyuser.get(1),"PE");
                ac.closeTabWindows();
                ac.Notification();
                ac.NavBackToAccount();
                driver.get(AccountURL);
                ac.AdditionalWait();

            }
            // Assert.assertTrue(false);
            Scrollpagedown();
            //StudentSubOrderPO Ssub = new StudentSubOrderPO(driver);
            // ac.ClickStudentProg2(); // Click on Student program
            // ac.ClickSSOinStuProg(); // Click on Student sub order in Student program
            // screen
            // Assert.assertFalse(ac.CheckExistingProfile());//Added check for SFTNL-6458
            if (CurrURL.contains("--byjusuat") && !CurrURL.contains("--byjusuatfc")) {
                ac.ClickAccOwnrTab();
                ac.CloseSubTabs();
            }

            log.info("Creating Inbound Task");
            ac.ClickOpenActivitiestoNewTask();
            NewCaseRecordTypePO ncrt = new NewCaseRecordTypePO(driver);
            ncrt.SelectCaseRecordTypeInbound();
            ncrt.ClickNext();
            ac.AdditionalWait();
            ncrt.ClickSave();
            ac.AdditionalWait();
            InboundTaskPO ibdt = new InboundTaskPO(driver);
            ibdt.ClickCaptureDetail();
            ac.AdditionalWait();
            ibdt.ClickProceedOptn();

            al4 = excelData.getData("TC3", "RefundProcess", "Tcid");
            al7 = excelData.getData("Inbound", "Inbound", "Tcid");

            if (CurrURL.contains("--byjusuat") && !CurrURL.contains("--byjusuatfc")) {
                IssueTreePO it = new IssueTreePO(driver);
                ibdt.SelectSpokeTo3(al7.get(1));
                it.PremiumidSelector();
                it.ProgramSelector();
                it.ClickNext();
                ibdt.SelectPSTCT(al7.get(2));
                ibdt.ClickNext();
                ac.AdditionalWait();
                it.IssueCategory(al4.get(13));
                it.Reason(al4.get(14));
                it.SubReason(al4.get(15));
                it.IssueNotes(al4.get(16));
                it.IstheIssueResolved(al4.get(17));
                it.ClickNext2();
                it.SSOandAccCombo();
                it.ClickFinish();
            } else {
                /*
                 * ibdt.SelectPSTCT(al.get(1));
                 * // ibdt.EnterNotesVal(al.get(2));
                 * ibdt.ClickNext();
                 * ac.AdditionalWait();
                 * 
                 * ibdt.SelectDevice(al.get(3));
                 * ibdt.SelectCategory(al.get(4));
                 * ibdt.SelectPSTRR(al.get(5));
                 * ibdt.SelectPSSTRR(al.get(6));
                 * ibdt.EnterComments(al.get(7));
                 * ibdt.SelectIsTICR(al.get(8));
                 * ibdt.SelectPSTO();
                 * Thread.sleep(1000);
                 * ibdt.ClickNext();
                 * ac.AdditionalWait();
                 */
                IssueTreePO it = new IssueTreePO(driver);
                ibdt.SelectSpokeTo3(al7.get(1));
                it.PremiumidSelector();
                it.ProgramSelector();
                it.ClickNext();
                ibdt.SelectPSTCT(al7.get(2));
                ibdt.ClickNext();
                ac.AdditionalWait();
                it.IssueCategory(al4.get(13));
                it.Reason(al4.get(14));
                it.SubReason(al4.get(15));
                it.IssueNotes(al4.get(16));
                it.IstheIssueResolved(al4.get(17));
                it.ClickNext2();
                it.SSOandAccCombo();
                it.ClickFinish();
            }
            driver.switchTo().defaultContent();
            ac.closeTabWindows();
            ac.AdditionalWait();
            // ibdt.NavBackAccount();
            lo.OnlyLogout();
            //Thread.sleep(1000);
            driver.get(AccountURL);
            ac.AdditionalWait();
            //closeTabWindows();
            //driver.get(AccountURL);
            //ac.AdditionalWait();

            
            //ac.ClickCasesMC2();
            //AssignmentRulesRefundRequestPO.linkCaseNumber(driver).click();
            //ac.AdditionalWait();
            CreatedCaseRecordPO ccr = new CreatedCaseRecordPO(driver);
            //String caseOwner = AssignmentRulesRefundRequestPO.caseOwner(driver).getText();// Capturing case owner
            // System.out.println("Value of caseOwner " + caseOwner);
            // ac.closeTabWindows();

            //log.info("Capturing cohard details");
            //String group = "";
            //if (al3.get(0).equalsIgnoreCase("DBEL+BMATH")) {
            //   switch (shippedRegion) {
            //       case "KARNATAKA (KA)":
            //            group = "DBEL+BMATH KANNADA";
            //            break;
            //        case "KERALA (KL)":
            //            group = "DBEL+BMATH MALAYALAM";
            //            break;
            //        case "TAMIL NADU (TN)":
            //            group = "DBEL+BMATH TAMIL";

            //        case "PONDICHERRY (PY)":
            //           group = "DBEL+BMATH TAMIL";
            //           break;
            //        case "ANDHRA PRADESH":
            //           group = "DBEL+BMATH TELUGU";

            //        case "TELANGANA (TS)":
            //            group = "DBEL+BMATH TELUGU";
            //            break;
            //        default:
            //            group = "DBEL+BMATH HINDI";
            //    }
            // } else if (al3.get(0).equalsIgnoreCase("Aakash K12")) {
            //    switch (shippedRegion) {
            //        case "KARNATAKA (KA)":
            //            group = "Aakash KANNADA";
            //           break;
            //       case "KERALA (KL)":
            //           group = "Aakash MALAYALAM";
            //           break;
            //       case "TAMIL NADU (TN)":
            //           group = "Aakash TAMIL";

            //        case "PONDICHERRY (PY)":
            //           group = "Aakash TAMIL";
            //           break;
            //       case "ANDHRA PRADESH":
            //           group = "Aakash TELUGU";

            //       case "TELANGANA (TS)":
            //            group = "Aakash TELUGU";
            //           break;
            //       default:
            //           group = "Aakash HINDI";

            //   }
            //  }

            // else if (al3.get(0).equalsIgnoreCase("K4-K10 (BTC)+K4-K10(Byjus Classes)+K4-K10(BTLP)")) {
                // Condition to check if either program1 or 2 is BTC program then set the group
                // to K4-K10(BTC) as per region (Because BTC has highest priority)

            //  if (program1.equals("BCRPUCSY0001") || program2.equals("BCRPUCSY0001")) {
            //       switch (shippedRegion) {
            //            case "KARNATAKA (KA)":
            //               group = "K4-K10 (BTC) KANNADA";
            //               break;
            //           case "KERALA (KL)":
            //               group = "K4-K10 (BTC) MALAYALAM";
            //               break;
            //           case "TAMIL NADU (TN)":
            //               group = "K4-K10 (BTC) TAMIL";

            //          case "PONDICHERRY (PY)":
            //               group = "K4-K10 (BTC) TAMIL";
            //              break;
            //           case "ANDHRA PRADESH":
            //               group = "K4-K10 (BTC) TELUGU";

            //           case "TELANGANA (TS)":
            //                group = "K4-K10 (BTC) TELUGU";
            //               break;
            //            default:
            //               group = "K4-K10 (BTC) HINDI";
            //       }// End of switch
            //   } // End of if

                // Condition to check if either program1 or 2 is Byju's class then set the group
                // to K4-K10 (Byju's Classes),bz 'Byju's Classes' has higher priority over to
                // BTLP
            //    else if ((program1.matches("BCOPKXSY0001||BCOPKXSY0002||BCOPKXSY0003||BCRPUCSY0002"))
            //           || (program2.matches("BCOPKXSY0001||BCOPKXSY0002||BCOPKXSY0003||BCRPUCSY0002"))) {

            //        switch (shippedRegion) {
            //            case "KARNATAKA (KA)":
            //               group = "K4-K10 (Byju's Classes) KANNADA";
            //               break;
            //           case "KERALA (KL)":
            //                group = "K4-K10 (Byju's Classes) MALAYALAM";
            //                break;
            //           case "TAMIL NADU (TN)":
            //               group = "K4-K10 (Byju's Classes) TAMIL";

            //           case "PONDICHERRY (PY)":
            //              group = "K4-K10 (Byju's Classes) TAMIL";
            //               break;
            //           case "ANDHRA PRADESH":
            //               group = "K4-K10 (Byju's Classes) TELUGU";

            //           case "TELANGANA (TS)":
            //                group = "K4-K10 (Byju's Classes) TELUGU";
            //                break;
            //            default:
            //                group = "K4-K10 (Byju's Classes) HINDI";
            //        }// End of switch

            //    }
                // Condition to check if either program1 or 2 is BTLP then set the group
                // to K4-K10 (BTLP) as per the region
            //    else if ((program1.matches("BTLAKXAS0001||TLP1UCAS0001||TLP2UCAS0001"))
            //           || (program2.matches("BTLAKXAS0001||TLP1UCAS0001||TLP2UCAS0001"))) {
            //       switch (shippedRegion) {
            //           case "KARNATAKA (KA)":
            //               group = "K4-K10 (BTLP) KANNADA";
            //               break;
            //            case "KERALA (KL)":
            //               group = "K4-K10 (BTLP) MALAYALAM";
            //               break;
            //            case "TAMIL NADU (TN)":
            //                group = "K4-K10 (BTLP) TAMIL";

            //           case "PONDICHERRY (PY)":
            //               group = "K4-K10 (BTLP) TAMIL";
            //               break;
            //            case "ANDHRA PRADESH":
            //                group = "K4-K10 (BTLP) TELUGU";

            //            case "TELANGANA (TS)":
            //               group = "K4-K10 (BTLP) TELUGU";
            //               break;
            //           default:
            //                group = "K4-K10 (BTLP) HINDI";
            //        }// End of switch
            //    }

            // }
            // log.info("Navigating to Assignment Rules screen");
            // loginPO.navigateToAssignmentRule(driver);// Navigate to Assignment Rule Screen
            // jsClick(AssignmentRulesRefundRequestPO.dropdownListView(driver));
            // ac.AdditionalWait();
            // AssignmentRulesRefundRequestPO.valueAllFromDropdown(driver).click();// Select value 'All' from List View
                                                                                // drop down
            // ac.AdditionalWait();
            // System.out.println(group);
            // AssignmentRulesRefundRequestPO.textFieldCohartSearch(driver).sendKeys(group); // Search the group
            //  AssignmentRulesRefundRequestPO.textFieldCohartSearch(driver).sendKeys(Keys.ENTER);
            // Thread.sleep(1000);

            // AssignmentRulesRefundRequestPO.linkCohart(driver, group).click();
            //  ac.AdditionalWait();
            //  jsClick(AssignmentRulesRefundRequestPO.linkViewAll(driver));
            //  ac.AdditionalWait();
            // log.info("Verifying that case is assigned to correct owner");
            // AssignmentRulesRefundRequestPO.compareCaseOwnerwithgroup(driver, caseOwner, Accountid, AccountURL, ac,
            //          softassert);

            // =====================================Switch to Retenion Manager then change
            // the case owner========================
            log.info("Switching to Retention Manager");
            ArrayList<String> RU = new ArrayList<String>();
            String Mainwin;
            if ((CurrURL.contains("--byjusuat") && !CurrURL.contains("--byjusuatfc"))) {
                RU = excelData.getData("RetentionManager User UAT", "Login", "Type");
                Mainwin = driver.getWindowHandle();
                ac.closeTabWindows();
                lo.SwitchUserThreeTabs(RU.get(1)); // Switch to Retention Manager user
                driver.close(); // After switching, close the current browser tab
                Thread.sleep(1000);
                driver.switchTo().window(Mainwin);
                lo.RefreshURL();
                Thread.sleep(1000);
                driver.get(AccountURL);

            } else if (CurrURL.contains("--byjusuatfc")) {
                RU = excelData.getData("RetentionManager User FC", "Login", "Type");
                Mainwin = driver.getWindowHandle();
                ac.closeTabWindows();
                lo.SwitchUserThreeTabs(RU.get(1)); // Switch to Retention Manager user
                driver.close(); // After switching, close the current browser tab
                Thread.sleep(1000);
                driver.switchTo().window(Mainwin);
                lo.RefreshURL();
                ac.AdditionalWait();
                driver.get(AccountURL);
            }

            else {
                Mainwin = driver.getWindowHandle();
                ac.closeTabWindows();
                lo.SwitchUsernProfile_Prod_threetabs("Retention Manager");
                driver.close(); // After switching, close the current browser tab
                Thread.sleep(1000);
                driver.switchTo().window(Mainwin);
                ac.AdditionalWait();
                driver.get(AccountURL);

            }


            Thread.sleep(3000);

            if (CurrURL.contains("--byjusuat") && !CurrURL.contains("--byjusuatfc")) {
                al2 = excelData.getData("Retention User UAT", "Login", "Type");
                ac.ClickCasesMC2();
                jsClick(AssignmentRulesRefundRequestPO.linkCaseNumber(driver));
                log.info("Changing the case owner to 'Retention user'");
                //ccr.changeCaseOwnertoRetentionUser(al2.get(1));
                log.info("Logging out as Retention Manager");
                lo.OnlyLogout();
                //Thread.sleep(1000);
            }

            else if (CurrURL.contains("--byjusuatfc")) {
                al2 = excelData.getData("Retention User FC", "Login", "Type");
                ac.ClickCasesMC2();
                jsClick(AssignmentRulesRefundRequestPO.linkCaseNumber(driver));
                log.info("Changing the case owner to 'Retention user'");
                ccr.changeCaseOwnertoRetentionUser(al2.get(1));
                log.info("Logging out as Retention Manager");
                lo.OnlyLogout();
               // ac.AdditionalWait();
            } else // For production
            {
                Scrollpagedown();
                Scrolldown();
                Scrollend();
                ac.ClickCasesMC2();
                jsClick(AssignmentRulesRefundRequestPO.linkCaseNumber(driver));
                log.info("Changing the case owner to 'Retention user'");
                ccr.changeCaseOwnertoRetentionUser("Testing User");
                lo.OnlyLogout();
                Mainwin = driver.getWindowHandle();
                ac.closeTabWindows();
                // lo.SwitchUsernProfile_Prod("Retention");
                lo.SwitchUsernProfile_Prod_threetabs("Retention");
                driver.close(); // After switching, close the current browser tab
                Thread.sleep(1000);
                driver.switchTo().window(Mainwin);
                lo.RefreshURL();
                ac.AdditionalWait();

            }

            // ===========================================================================================================

            // $$$$$$$$$$$$$$$$$$ code to capture 'retention call details' starts

            /*
             * al8 = excelData.getData("TC1", "ByjuWallet", "Tcid");
             * ac.closeTabWindows();
             * driver.get(AccountURL);
             * ac.AdditionalWait();
             * 
             * ac.ClickCasesMC2();
             * String CaseNumber = cases.CaseRN();
             * log.info("The case number created is: " + CaseNumber);
             */
            //CasesPO cases = new CasesPO(driver);
            // cases.CaseOptnSel();

            if (CurrURL.contains("--byjusuatfc") || CurrURL.contains("--byjusuat")) {
                al2 = excelData.getData("Retention User UAT", "Login", "Type");
                log.info("Switching to user Retension user");
                Mainwin = driver.getWindowHandle();
                lo.SwitchUserThreeTabs(al2.get(1));
                driver.close();
                driver.switchTo().window(Mainwin);
                Thread.sleep(1000);
                // lo.RefreshURL();
                // ca1.closeTabWindows();

            } /*
               * else if (CurrURL.contains("byjusprod.")) {
               * lo.SwitchUsernProfile_Prod("Retention Manager");
               * ca1.closeTabWindows();
               * // driver.close();
               * Thread.sleep(1000);
               * // driver.switchTo().window(Mainwin);
               * Thread.sleep(1000);
               * }
               */

            driver.get(AccountURL);
            ac.AdditionalWait();
            ac.ClickCasesMC2();
            jsClick(AssignmentRulesRefundRequestPO.linkCaseNumber(driver));
            ccr.changeCaseOwnertoRetentionUser(al2.get(1));
            ac.CloseSubTabs();
            /*
             * if (CurrURL.contains("byjusprod.")) {
             * ccr.CaseOwnrUpdate_Prod("Testing User");
             * }
             */
            lo.RefreshURL();
            Scrollpagedown();
            Scrollpagedown();
            //ac.ClickOpenActivities();
            ac.AdditionalWait();
            ac.ClickCreatedTask_OpenActivities("Retention - First Call");
            log.info("Marking the Initial call as Complete");
            Retention1stCallPO rfc = new Retention1stCallPO(driver);
            ac.AdditionalWait();
            rfc.EnterCompletedcall();
            rfc.ClickSave();

            ibdt.NavToCase();
            // ca1.CloseSubTabs();
            // ca1.ClickCasesMC2();
            // cases.CaseOptnSel();

            log.info("Capturing Retention Details");
            al8 = excelData.getData("TC1", "ByjuWallet", "Tcid");
            ccr.ClickCaptureRetentnDetail();
            if (CurrURL.contains("byjusprod.") || CurrURL.contains("--byjusuatfc") || CurrURL.contains("--byjusuat")) {
                ccr.EnterEscalationCategory(al8.get(44));
                ccr.EnterReasonfrRefund(al8.get(9));
            } else {
                // ccr.EnterReasonfrRefund_UAT(al.get(9));
            }
            ccr.EnterSubReasonfrRefund(al8.get(10));
            ccr.EnterRRNotes(al8.get(11));
            ccr.EnterModeORetentn(al8.get(12)); // Mode of retention = 'Refund Approved'--No change need to be done here
            ccr.EnterRTSE(al8.get(13));
            ccr.EnterRTSR(al8.get(14));
            ccr.Selectorder();
            if(CurrURL.contains("--byjusuat")) {
                ccr.EnterDeactivateClasses(al8.get(64));   
               }
               else {
               ccr.EnterClsTBD(al8.get(15));
               }
            ccr.EnterTTBR(al8.get(16));
            ccr.EnterLTBC(al8.get(54)); // Loan to be Cancelled ='Yes' (Loan Partner, Loan Id,Loan Amount fields need to
                                        // be added here
            ccr.EnterLoanID(al8.get(55));// Enter loan id
            ccr.EnterDPTBRefunBnk(al8.get(57));// DP To Be Refunded-Bank= Yes
            ccr.EnterDPTBRefunWall(al8.get(19));
            ccr.EnterDPRefunWallAmt(al8.get(20));
            ccr.EnterDPBBP(al8.get(21));
            ccr.EnterOATBRefunBnk(al8.get(58));// Other Amount to be Refunded Bank=Yes (Type of Other Amount, 'Cashback
                                               // Amount included' fields need to be added here)
            ccr.SelectTypeOfOtherAmount(al8.get(59));
            ccr.EnterCashbackAmount(al8.get(60));
            ccr.EnterOtherAmountToBank(al8.get(61));
            ccr.EnterOATBRefunWall(al8.get(23));
            // ccr.EnterORefunWallAmt(al8.get(24));
            // ccr.EnterOBBP(al8.get(25));
            ccr.EnterCCTBRefunded(al8.get(26));
            ccr.EnterATBRefunded(al8.get(27));
            ccr.EnterARetained(al8.get(28));
            ccr.SelectCWTGFOSP(al8.get(29));
            ccr.SelectOTBReP(al8.get(30));
            ccr.SelectCPTBReP(al8.get(31));
            ccr.SelectBTBR(al8.get(32));
            ccr.SelectRTPS(al8.get(33));
            ccr.EnterRTPSNotes(al8.get(34));
            ccr.SelectOwner(OwnerName);
            ccr.EnterSPFES(al8.get(35));
            ccr.EnterGTBP(al8.get(36));
            ccr.EnterClsTBReP(al8.get(37));
            ccr.EnterAmount(al8.get(38));
            ccr.EnterOtherPD(al8.get(39));
            ccr.EnterCompliGTBP(al8.get(36));
            ccr.EnterCompliClsTBReP(al8.get(37));
            ccr.SelectAFBD(al8.get(40));
            ccr.SelectDYWTSTASTTCProd(al8.get(41));
            ccr.SelectCOAForm(al8.get(42));

            if (CurrURL.contains("byjusprod.") || CurrURL.contains("--byjusuatfc") || CurrURL.contains("--byjusuat")) {
                lo.OnlyLogout();
            }
            //ac.closeTabWindows();
            driver.get(AccountURL);
            //Assert.assertTrue(false);
            AssignmentRulesRefundRequestPO.verifyChildCases(driver, softassert, ac);
              
           
           log.info("Verifying Social Media Strategist sceanrio"); 
           AssignmentRulesRefundRequestPO.socialMediaStrategist(driver, AccountURL, softassert,CurrURL);
           
            //ac.closeTabWindows();
            driver.get(AccountURL);
            ac.AdditionalWait();
            //ac.closeTabWindows();
            
            String flagSuperStatus = "";
            String flagStatus = "";
            log.info("Capturing Super status of Account");
            flagSuperStatus = AssignmentRulesRefundRequestPO.verifySuperStatus(driver);
            // Verify if SuperStatus is Refund

            //softassert.assertEquals(flagSuperStatus, "Refund", "Super status is not correctly updated");
            log.info("Capturing status of Account");
            flagStatus = AssignmentRulesRefundRequestPO.verifyStatus(driver);
            // Verify if Status is Refund Approved
            //softassert.assertEquals(flagStatus, "Refund Approved", " Status is not correctly updated");

            // Creation of Refund calling task and verification that task status is
            // completed after capture call details
            
            log.info("Verifying Refund Calling task completion");
             // AssignmentRulesRefundRequestPO.refundCallingTaskCompletion(driver,
             // AccountURL, ac, ncrt, lo, ibdt,
             // CurrURL, softassert);
             
            
            // $$$$$$$$$$$$$$$$$$$$$$$$$

            log.info("Deleting the Account");
            deleteAccount(driver, Accountid, AccountURL, ac);
            System.out.println("Account is deleted Successfully");
            //softassert.assertAll();

        } catch (Exception e) {
            e.printStackTrace();
            log.info("Deleting the Account");
            // deleteAccount(driver, Accountid, AccountURL, ac);
            throw e;
        }
    }

    // $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

    // This method search the caseOwner in the list of users which are displayed in
    // respective cohart
    // Author :: Manish

    public static void compareCaseOwnerwithgroup(WebDriver driver, String caseOwner, String Accountid,
            String AccountURL, CreatedAccountPO ac, SoftAssert softassert) throws InterruptedException {

        String count = AssignmentRulesRefundRequestPO.textUserCount(driver).getText();// Capture the nubmer of rows in
        int count2; // table
        String[] strArray = count.split(" ");
        if (strArray[0].contains("+")) {
            String[] strArray2 = strArray[0].split("\\+");
            count2 = Integer.parseInt(strArray2[0]);
        } else {
            count2 = Integer.parseInt(strArray[0]);
        }
        System.out.println("Count of rows " + count2);

        // >>>>>>>>>>>>>> code for lazy loading >>>>>>>>>>>>>>>>>>>>>>>>>>
        for (int j = 6; j < count2 - 5; j++) {
            j = j + 1;
            WebElement element = AssignmentRulesRefundRequestPO.tableRow(driver, j);// Elements of rows identified one
                                                                                    // by one
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].scrollIntoView();", element);

            ac.AdditionalWait();
        }
        // >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

        String userValue = "";
        boolean flag = false;
        List<WebElement> users = AssignmentRulesRefundRequestPO.rowofTable(driver);// Capture all the rows of the table
        System.out.println("Size of table " + users.size());
        for (int i = 1; i <= users.size(); i++) {
            userValue = AssignmentRulesRefundRequestPO.fieldUser(driver, i).getText();
            System.out.println(userValue);
            System.out.println("caseOwner is :" + caseOwner);

            if (caseOwner.equalsIgnoreCase(userValue)) {
                flag = true;
                break;
            } else {
                flag = false;
            }
        }

        softassert.assertEquals(flag, true,
                "Case Owner is not correctly assigned as per Assignment Rules. Assigned user " + caseOwner +
                        "is not found in the respective group");
    }

    // This method verifies that three child cases are created
    // Author :: Manish
    public static void verifyChildCases(WebDriver driver, SoftAssert softassert, CreatedAccountPO ac)
            throws InterruptedException {
        boolean LTBC = false; // Loan To Be Cancelled
        boolean DPTBR = false; // DP to be Refunded
        boolean OATBR = false; // Other Amount to be Refunded
        ArrayList<String> childCases = new ArrayList<String>();
        String caseValue = "";

        ac.clickCase3();
        log.info("Verifying child cases");
        List<WebElement> caseAll = CasesPO.rowsCases(driver);// Get all the rows of case
        System.out.println("Size of table " + caseAll.size());
        for (int i = 1; i <= caseAll.size(); i++) {
            caseValue = CasesPO.fieldCase(driver, i).getText();// Get the name of case
            childCases.add(caseValue);
            System.out.println(caseValue);

            // Verify if expected child cases are created
            if (caseValue.contains("Loan To Be Cancelled - Fintech")) {
                LTBC = true;
                System.out.println(LTBC + "Child case 'Loan To Be Cancelled - Fintech' is present");

            }

            if (caseValue.contains("DP To Be Refunded -")) {
                // if (userValue.contains("Test2")) {
                DPTBR = true;
                System.out.println(DPTBR + "Child case 'DP To BE Refunded' is present");
            }

            if (caseValue.contains("Other Amount To Be Refunded -")) {
                OATBR = true;
                System.out.println(OATBR + " Child case 'Other Amount To Be Refunded' is present");
            }
        }
       // softassert.assertEquals(LTBC, true, "Child Case 'Loan To Be Cancelled' is not created");
       // softassert.assertEquals(DPTBR, true, "Child Case 'DP To BE Refunded' is not created");
       // softassert.assertEquals(OATBR, true, "Child Case 'Other Amount To Be Reunded' is not created");

    }

    // Social Media Strategist

    public static void socialMediaStrategist(WebDriver driver, String AccountURL, SoftAssert softassert,String CurrURL)
            throws Exception {
        boolean accOwnercheck = false;

        loginPO lo = new loginPO(driver);
        ExcelData excelData = new ExcelData();
        String caseValue = "";
        String caseNumber = "";

        CreatedCaseRecordPO ccr = new CreatedCaseRecordPO(driver);
        ArrayList<String> al2 = new ArrayList<String>();
        CreatedAccountPO ac = new CreatedAccountPO(driver);
        String Mainwin;
        
        if (CurrURL.contains("--byjusuat") && !(CurrURL.contains("--byjusuatfc"))) {
            al2 = excelData.getData("Social Media Strategist UAT", "Login", "Type");
            Mainwin = driver.getWindowHandle();
            lo.SwitchUserThreeTabs(al2.get(1));
            driver.close();
            driver.switchTo().window(Mainwin);
            // lo.SwitchUser(al2.get(1));
            ac.Notification();
            ac.AdditionalWait();
            ac.closeTabWindows();
            
            driver.get(AccountURL);
            ac.AssignAccount(al2.get(1));
            ac.AdditionalWait();
            accOwnercheck = driver
                    .findElement(By.xpath("//span[text()='You do not have permission to change Account owner'] | //span[text()='Account Owner Not be Change. It has Active RR Case']"))
                    .isDisplayed();

            if (accOwnercheck) {
                System.out.println("As Expected :: Social Media Strategist is not able to change Account Owner");
                // AssignmentRulesRefundRequestPO.buttonCancel(driver);
                driver.navigate().refresh();

            } else {
                softassert.assertEquals(accOwnercheck, true, "Social Media Strategist is able to change Account Owner");
                // AssignmentRulesRefundRequestPO.buttonCancel(driver);
                driver.navigate().refresh();
            }
        }
        else if (CurrURL.contains("--byjusuatfc")) {
            al2 = excelData.getData("Social Media Strategist UATFC", "Login", "Type");
            Mainwin = driver.getWindowHandle();
            lo.SwitchUserThreeTabs(al2.get(1));
            driver.close();
            driver.switchTo().window(Mainwin);
            // lo.SwitchUser(al2.get(1));
            ac.closeTabWindows();
            ac.Notification();
            ac.AdditionalWait(); 
            
            driver.get(AccountURL);
            ac.AssignAccount(al2.get(1));
            ac.AdditionalWait();
            accOwnercheck = driver
                    .findElement(By.xpath("//span[text()='You do not have permission to change Account owner']"))
                    .isDisplayed();

            if (accOwnercheck) {
                System.out.println("As Expected :: Social Media Strategist is not able to change Account Owner");
                // AssignmentRulesRefundRequestPO.buttonCancel(driver);
                driver.navigate().refresh();

            } else {
                softassert.assertEquals(accOwnercheck, true, "Social Media Strategist is able to change Account Owner");
                // AssignmentRulesRefundRequestPO.buttonCancel(driver);
                driver.navigate().refresh();
            }
            
        }

         else { // In prod, try to change the account owner to a differnt user (e.gmanish goyal)
                // from SM profile and the switch back to 'Testing User'.
             
            Mainwin = driver.getWindowHandle();
            lo.SwitchUsernProfile_Prod_threetabs("Social Media Strategist");
            driver.close();
            driver.switchTo().window(Mainwin);
            //ac.closeTabWindows();
            ac.Notification();
            ac.AdditionalWait();
            driver.get(AccountURL);
            al2 = excelData.getData("Social Media Strategist Prod", "Login", "Type");
            ac.AssignAccount(al2.get(1));//Try to assign the account owner to user Manish Goyal
            ac.AdditionalWait();
            try {
            accOwnercheck = driver
                    .findElement(By.xpath("//span[text()='You do not have permission to change Account owner']"))
                    .isDisplayed();
            }
            catch (Exception E)
            {
                E.printStackTrace();
            }

            if (accOwnercheck) {
                System.out.println("As Expected :: Social Media Strategist is not able to change Account Owner");
                // AssignmentRulesRefundRequestPO.buttonCancel(driver);
                driver.navigate().refresh();

            } else {
                softassert.assertEquals(accOwnercheck, true, "Social Media Strategist is able to change Account Owner");
                // AssignmentRulesRefundRequestPO.buttonCancel(driver);
                driver.navigate().refresh();
            }
            lo.OnlyLogout();
            driver.get(AccountURL);
            al2 = excelData.getData("Social Media Strategist Prod_1", "Login", "Type");
            ac.AssignAccount(al2.get(1));// Assign the Account owner back to 'Testing User'.
            Mainwin = driver.getWindowHandle();
            lo.SwitchUsernProfile_Prod_threetabs("Social Media Strategist");//Switch back to SM profile
            driver.close();
            driver.switchTo().window(Mainwin);
            driver.get(AccountURL);
            
        }        

        ac.ClickCasesMC2();

        List<WebElement> caseAll = CasesPO.rowsCases(driver);// Get all the rows of case
        System.out.println("Size of table " + caseAll.size());
        
        for (int i = 1; i <= caseAll.size(); i++) {
            caseValue = CasesPO.fieldCase(driver, i).getText();// Get the Subject of case
            // childCases.add(caseValue);
            // System.out.println(caseValue);
            if (caseValue.contains("Loan To Be Cancelled - Fintech")) {
                verifyCaseOwnerChange(driver, "Loan To Be Cancelled - Fintech", softassert,CurrURL);
                caseNumber = ccr.CaseNumberCreated();
                System.out.println("Case Number is " + caseNumber);
                ac.AdditionalWait();
                ccr.closeCurrentTab(caseNumber);
                // cp.NavCasesTab();
            }

            if (caseValue.contains("DP To Be Refunded -")) {
                verifyCaseOwnerChange(driver, "DP To Be Refunded -", softassert,CurrURL);
                caseNumber = ccr.CaseNumberCreated();
                ac.AdditionalWait();
                ccr.closeCurrentTab(caseNumber);
                // cp.NavCasesTab();
            }

            if (caseValue.contains("Other Amount To Be Refunded -")) {
                verifyCaseOwnerChange(driver, "Other Amount To Be Refunded -", softassert,CurrURL);
                caseNumber = ccr.CaseNumberCreated();
                ac.AdditionalWait();
                ccr.closeCurrentTab(caseNumber);
                // cp.NavCasesTab();
            }

            if (caseValue.contains("Refund Request")) {
                verifyCaseOwnerChange(driver, "Refund Request", softassert,CurrURL);
                caseNumber = ccr.CaseNumberCreated();
                ac.AdditionalWait();
                ccr.closeCurrentTab(caseNumber);
                // cp.NavCasesTab();
            }
        }
        lo.OnlyLogout();
    }

    // $$$$$$$ Verify if SM Strategist is able to change case owner ONLY of child
    // cases and NOT of Refund Rquest case
    // Author : Manish
    public static void verifyCaseOwnerChange(WebDriver driver, String caseSubject, SoftAssert softassert,String CurrURL)
            throws IOException, InterruptedException {
        boolean caseOwnercheck = false;
        CreatedAccountPO ac = new CreatedAccountPO(driver);
        String newCaseOwner = "";
        ArrayList<String> al2 = new ArrayList<String>();
        ExcelData excelData = new ExcelData();

        if (CurrURL.contains("--byjusuat") && !(CurrURL.contains("--byjusuatfc"))) {
            
            al2 = excelData.getData("Social Media Strategist UAT", "Login", "Type");           
        }
        else if (CurrURL.contains("--byjusuatfc")) {
            
            al2 = excelData.getData("Social Media Strategist UATFC", "Login", "Type");            
        }
         else {
             al2 = excelData.getData("Social Media Strategist Prod_1", "Login", "Type");
          
        }

        if (caseSubject.contains("Refund Request")) {
            AssignmentRulesRefundRequestPO.caseSubjectLink(driver, caseSubject).click();
            ac.AdditionalWait();
            ac.assignNewCaseOwner(al2.get(1));

            caseOwnercheck = driver
                    .findElement(By.xpath("//span[text()='You do not have permission to change the Case Owner']"))
                    .isDisplayed();
            if (caseOwnercheck) {
                System.out.println("As Expected :: Social Media Strategist is not able to change RR case  Owner");
                AssignmentRulesRefundRequestPO.buttonCancel(driver);
            } else {
                softassert.assertEquals(caseOwnercheck, true,
                        "Social Media Strategist is able to change RR case Owner");
                AssignmentRulesRefundRequestPO.buttonCancel(driver);
            }
        }

        else {
            // if (caseValue.contains(caseSubject)) {
            AssignmentRulesRefundRequestPO.caseSubjectLink(driver, caseSubject).click();
            ac.assignNewCaseOwner(al2.get(1));
            newCaseOwner = CreatedCaseRecordPO.caseOwner(driver).getText();
            System.out.println("Case Subject is " + caseSubject);
            System.out.println("New Case Owner is " + newCaseOwner);
            if (newCaseOwner.equalsIgnoreCase(al2.get(1))) {
                System.out.println("As Expected :: Social Media Strategist is able to change case owner of child case");
                caseOwnercheck = true;
            }
          
            else {
                System.out.println(
                        "Not as Expected :: Social Media Strategist is NOT able to change case owner of child case");
                caseOwnercheck = false;
            }
            softassert.assertEquals(caseOwnercheck, true,
                    "Not as Expected :: Social Media Strategist is NOT able to change case owner of child case");

        }

    }

    // Deleting account
    // Author= Manish
    public static void deleteAccount(WebDriver driver, String Accountid, String AccountURL, CreatedAccountPO ac)
            throws InterruptedException {
        if (Accountid != null) {

            ac.closeTabWindows();
            driver.get(AccountURL);
            ac.AdditionalWait();

            log.info("Deleting the created case");
            CasesPO cases = new CasesPO(driver);
            ac.ClickCasesMC2();
            String CaseNumber = cases.CaseRN();
            log.info("The case number created is: " + CaseNumber);
            cases.CloseAllCases();

            log.info("Deleting the Student Program details");
            ac.ClickAccOwnrTab();
            ac.DeleteAllCreatedStuProg();
            ac.NavBackToAccount();
            log.info("Deleting the Account created details");
            ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
        }

    }

    // Verify SuperStatus on Account home page
    // Author :: Manish
    public static String verifySuperStatus(WebDriver driver) {
        String superstatus = "";
        superstatus = AssignmentRulesRefundRequestPO.labelSuperStatus(driver).getText();
        return superstatus;
    }

    // Verify Status on Account home page
    // Author :: Manish
    public static String verifyStatus(WebDriver driver) {
        String status = "";
        status = AssignmentRulesRefundRequestPO.labelStatus(driver).getText();
        return status;
    }

    public static void refundCallingTaskCompletion(WebDriver driver, String AccountURL, CreatedAccountPO ac,
            NewCaseRecordTypePO ncrt, loginPO lo, InboundTaskPO ibdt, String CurrURL, SoftAssert softassert)
            throws Exception {// driver,AccountURL,ac,ibdt,lo

        ArrayList<String> al2 = new ArrayList<String>();
        ArrayList<String> al9 = new ArrayList<String>();
        // ArrayList<String> al10 = new ArrayList<String>();
        

        ExcelData excelData = new ExcelData();
        //IssueTreePO it = new IssueTreePO(driver);
        //ArrayList<String> al7 = new ArrayList<String>();
        //al7 = excelData.getData("Inbound", "Inbound", "Tcid");
        int length = 0;
        String[] callSelection;
        if (CurrURL.contains("--byjusuat") || CurrURL.contains("--byjusuatfc")) {
            callSelection = new String[] { "DNP", "Call Back Requested", "Customer will Call", "Proceed" };
        } else {
            callSelection = new String[] { "DNP", "Call Back Requested", "Customer will Call" };
        }
        /*
         * al10.add("DNP");
         * al10.add("Call Back Requested");
         * al10.add("Customer will Call");
         * al10.add("Proceed");
         */
        // length=al10.size();
        length = callSelection.length;
        // }
        /*
         * else if(CurrURL.contains("--byjusuatfc"))
         * {
         * //String[] callSelection = { "DNP/Call Drop", "Abrupt Disconnection",
         * "Call Back Requested", "Proceed" };
         * al10.add("DNP/Call Drop");
         * al10.add("Call Back Requested");
         * al10.add("Abrupt Disconnection");
         * al10.add("Proceed");
         * length=al10.size();
         */
        // }
        log.info("Creating Inbound Task");

        // Scrollpagedown();
        String user = "";
        if (CurrURL.contains("--byjusuat") && !CurrURL.contains("--byjusuatfc")) {
            al2 = excelData.getData("Customer Support UAT", "Login", "Type");
            user = al2.get(1);
        } else if (CurrURL.contains("--byjusuatfc")) {
            al2 = excelData.getData("Customer Support FC", "Login", "Type");
            user = al2.get(1);
        } else {

            /*
             * lo.SwitchUsernProfile_Prod("Customer Support");
             * ac.closeTabWindows();
             * ac.Notification();
             * ac.NavBackToAccount();
             * driver.get(AccountURL);
             */
            user = "Testing User";
        }

        // String user = al2.get(1);
        String subject = "Primary IRT - Refund Calling";
        String Mainwin;

        for (int i = 0; i < length; i++) {

            // ac.Notification();
            ac.AdditionalWait();
            ac.ClickOpenActivitiestoNewTask();
            // NewCaseRecordTypePO ncrt = new NewCaseRecordTypePO(driver);
            ncrt.SelectCaseRecordTypeInbound();
            ncrt.ClickNext();
            ac.AdditionalWait();

            ncrt.CreatingRefundCallingTask(subject, user);
            ncrt.ClickSave();
            // lo.SwitchUserThreeTabs(al2.get(1));
            if (CurrURL.contains("--byjusuat") || CurrURL.contains("--byjusuatfc")) {
                Mainwin = driver.getWindowHandle();
                lo.SwitchUserThreeTabs(al2.get(1));
                driver.close();
                driver.switchTo().window(Mainwin);
                // lo.SwitchUser(al2.get(1));
                ac.closeTabWindows();
                ac.Notification();
                ac.AdditionalWait();

            } else {
                Mainwin = driver.getWindowHandle();
                lo.SwitchUsernProfile_Prod_threetabs("Customer Support");
                driver.close();
                driver.switchTo().window(Mainwin);
                ac.closeTabWindows();
                ac.Notification();
                ac.AdditionalWait();
            }
            // ac.Notification();
            driver.get(AccountURL);
            ac.ClickOpenActivities_1();
            ac.ClickOnRefundCallingTask();
            ac.clickCaptureCallbutton();
            // ibdt.ClickProceedOptn();
            if (callSelection[i].equals("DNP"))// ||(al10.get(i).equals("DNP/Call Drop"))) {
            {
                // if(CurrURL.contains("--byjusuat") && !CurrURL.contains("--byjusuatfc")) {
                InboundTaskPO.radiobuttonCallSelectionUAT(driver, callSelection[i]).click();
                Thread.sleep(800);
                InboundTaskPO.buttonNext(driver).click();
                ac.AdditionalWait();
                InboundTaskPO.buttonFinish(driver).click();
                ac.AdditionalWait();
            }
            /*
             * }
             * else if(CurrURL.contains("--byjusuatfc")) {
             * InboundTaskPO.radiobuttonCallSelectionFC(driver, al10.get(i)).click();
             * Thread.sleep(800);
             * InboundTaskPO.buttonNext(driver).click();
             * ac.AdditionalWait();
             * driver.switchTo().defaultContent();
             * 
             * InboundTaskPO.buttonFinishFC(driver).click();
             * ac.AdditionalWait();
             * driver.switchTo().defaultContent();
             * }
             * }
             */

            if (callSelection[i].equals("Call Back Requested")) {

                // if(CurrURL.contains("--byjusuat") && !CurrURL.contains("--byjusuatfc")) {
                InboundTaskPO.radiobuttonCallSelectionUAT(driver, callSelection[i]).click();
                Thread.sleep(800);
               // InboundTaskPO.textfieldCalendar(driver).sendKeys("Oct 31, 2022");
                InboundTaskPO.textfieldCalendar(driver).sendKeys(Date1.tmrwDate());
                // driver.findElement(By.xpath("//input[@name='Call_Back_Date_0']")).sendKeys("Oct
                // 31, 2022");
                // driver.findElement(By.xpath("//label[text()='Time']/following::input[@name='Call_Back_Date_0']")).clear();
                InboundTaskPO.textfieldTime(driver).sendKeys(Keys.chord(Keys.CONTROL, "a),12.00 PM"));

                InboundTaskPO.textfieldTime(driver).sendKeys("12:00 PM");
                Thread.sleep(800);// sendKeys(Keys.chord(Keys.CONTROL,"a),"+subject+""));
                InboundTaskPO.lableHeader(driver).click();
                InboundTaskPO.buttonNext(driver).click();
                ac.AdditionalWait();
                driver.switchTo().defaultContent();
                InboundTaskPO.buttonFinish(driver).click();
                ac.AdditionalWait();

            }

            /*
             * else if (CurrURL.contains("--byjusuatfc"))
             * {
             * 
             * InboundTaskPO.radiobuttonCallSelectionFC(driver, al10.get(i)).click();
             * Thread.sleep(800);
             * InboundTaskPO.textfieldCalendarFC(driver).sendKeys("Oct 31, 2022");
             * //
             * driver.findElement(By.xpath("//input[@name='Call_Back_Date_0']")).sendKeys("
             * Oct
             * // 31, 2022");
             * // driver.findElement(By.xpath(
             * "//label[text()='Time']/following::input[@name='Call_Back_Date_0']")).clear()
             * ;
             * InboundTaskPO.textfieldTimeFC(driver).sendKeys(Keys.chord(Keys.CONTROL,
             * "a),12.00 PM"));
             * InboundTaskPO.textfieldTimeFC(driver).sendKeys("12:00 PM");
             * Thread.sleep(800);// sendKeys(Keys.chord(Keys.CONTROL,"a),"+subject+""));
             * InboundTaskPO.lableHeaderFC(driver).click();
             * InboundTaskPO.buttonNext(driver).click();
             * ac.AdditionalWait();
             * driver.switchTo().defaultContent();
             * 
             * InboundTaskPO.buttonFinishFC(driver).click();
             * ac.AdditionalWait();
             * driver.switchTo().defaultContent();
             * } }
             */

            if (callSelection[i].equals("Customer will Call"))// ||(al10.get(i).equals("Abrupt Disconnection"))) {

            // if(CurrURL.contains("--byjusuat") && !CurrURL.contains("--byjusuatfc")) {
            {
                InboundTaskPO.radiobuttonCallSelectionUAT(driver, callSelection[i]).click();
                InboundTaskPO.buttonNext(driver).click();
                ac.AdditionalWait();
                InboundTaskPO.buttonNext(driver).click();
                ac.AdditionalWait();
            }

            /*
             * else if (CurrURL.contains("--byjusuatfc"))
             * {
             * InboundTaskPO.radiobuttonCallSelectionFC(driver, al10.get(i)).click();
             * Thread.sleep(800);
             * InboundTaskPO.buttonNext(driver).click();
             * ac.AdditionalWait();
             * driver.switchTo().defaultContent();
             * 
             * }
             */
            // }

            if (callSelection[i].equals("Proceed")) {
                // if ((CurrURL.contains("--byjusuat")
                // ||CurrURL.contains("--byjusuatfc"))&&!(CurrURL.contains("byjusprod")))
                // {
                InboundTaskPO.radiobuttonCallSelectionUAT(driver, callSelection[i]).click();
                Thread.sleep(800);
                InboundTaskPO.buttonNext(driver).click();
                ac.AdditionalWait();
                driver.switchTo().defaultContent();
                al9 = excelData.getData("TC1", "RefundCallingTask", "Type");
                ibdt.SelectRefundCategory(al9.get(1));
                ibdt.SelectRefundSubCategory(al9.get(2));
                ibdt.EnterComments2(al9.get(3));
                ibdt.ClickNext();
                ac.AdditionalWait();
                // }
            }

            /*
             * else if (CurrURL.contains("--byjusuatfc"))
             * {
             * InboundTaskPO.radiobuttonCallSelectionFC(driver, al10.get(i)).click();
             * Thread.sleep(800);
             * InboundTaskPO.buttonNext(driver).click();
             * ac.AdditionalWait();
             * 
             * 
             * ibdt.SelectSpokeTo3(al7.get(1));
             * it.PremiumidSelector();
             * it.ProgramSelector();
             * it.ClickNext();
             * Thread.sleep(5000);
             * 
             * driver.switchTo().defaultContent();
             * al9 = excelData.getData("TC1", "RefundCallingTask", "Type");
             * ibdt.SelectRefundCategoryFC(al9.get(1));
             * ibdt.SelectRefundSubCategory(al9.get(2));
             * ibdt.EnterComments3(al9.get(3));
             * ibdt.ClickNext();
             * ac.AdditionalWait();
             * driver.switchTo().defaultContent();
             * }
             */

            ac.RefreshTab();
            ac.Scrolldown();
            String status = ibdt.CheckStatus();
            System.out.println(status);
            lo.OnlyLogout();
            driver.get(AccountURL);
            softassert.assertEquals(status, "Completed", "Task status is not updated to 'Completed'");
        }
    }

    /*
     * public void closeCurrentCaseTab(WebDriver driver, String caseNumber) throws
     * InterruptedException
     * {
     * //driver.findElement(By.xpath("//span[text()='Close "+caseNumber+"']")).click
     * ();
     * jsClick(driver.findElement(By.xpath("//button[@title='Close "+caseNumber+"']"
     * )));
     * Thread.sleep(1000);
     * }
     */
    // $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Implementation of Methods Ends
    // here

    // CaseNumber link
    // Author :: Manish
    public static WebElement linkCaseNumber(WebDriver driver) {
        // return driver.findElement(
        // By.xpath("//span[@title='Cases']/following::a[@class='flex-wrap-ie11
        // slds-truncate']//span"));

        return driver.findElement(By.xpath("//table[@aria-label='Cases']/tbody/tr/th/span/a"));
    }

    // CaseOwner elment
    // Author :: Manish
    public static WebElement caseOwner(WebDriver driver) {
        return driver.findElement(By.xpath("//span[text()='Case Owner']/following::a[1]/slot/slot"));
    }

    // ListView drop down on Assignment Rules screen
    // Author : Manish
    public static WebElement dropdownListView(WebDriver driver) {
        return driver.findElement(
                By.xpath("//h1/span[text()='Assignment Rules']/following::button[@title='Select a List View']"));
    }

    // 'All' value element in drop down
    // Author :: Manish
    public static WebElement valueAllFromDropdown(WebDriver driver) {
        return driver.findElement(By.xpath("//span[text()='All']"));
    }

    // Search text field on Assignment Rules screen
    public static WebElement textFieldCohartSearch(WebDriver driver) {
        return driver.findElement(By.xpath("//input[@name='Assignment_Rule__c-search-input']"));
    }

    // Cohart link on Assignment Rules screen.
    // Author :: Manish
    public static WebElement linkCohart(WebDriver driver, String group) {
        return driver.findElement(By.xpath("//tr/td[4]/span/a[contains(text(),\"" + group + "\")]"));
    }

    // View All link
    // Author ::Manish
    public static WebElement linkViewAll(WebDriver driver) {
        return driver.findElement(By.xpath(
                "//div[@class='split-right']/section[@role='tabpanel']//following::span[text()='View All']"));
    }

    // This method returns the Superstatus's value elment
    // Author :: Manish
    public static WebElement labelSuperStatus(WebDriver driver) {
        return driver.findElement(By.xpath("//div/p[@title='Super Status']/following::slot/lightning-formatted-text"));
    }

    // This method returns the Superstatus's value elment
    // Author :: Manish
    public static WebElement labelStatus(WebDriver driver) {
        return driver.findElement(By.xpath("//div/p[@title='Status']/following::slot/lightning-formatted-text"));
    }

    // Author :: Manish
    public static WebElement textUserCount(WebDriver driver) {
        return driver.findElement(By.xpath(
                "//h1[@title='Group Members']/following::div[@role='status']/span[@class='countSortedByFilteredBy']"));
    }

    // Author :: Manish
    public static WebElement tableRow(WebDriver driver, int j) {
        return driver.findElement(By.xpath(
                "//div[@class='uiVirtualDataTable indicator']/following-sibling::table[@aria-label='Group Members']/tbody/tr["
                        + j + "]"));
    }

    // Author :: Manish
    public static List<WebElement> rowofTable(WebDriver driver) {
        return driver.findElements(By.xpath(
                "//div[@class='uiVirtualDataTable indicator']/following-sibling::table[@aria-label='Group Members']/tbody/tr"));
    }

    // Author :: Manish
    public static WebElement fieldUser(WebDriver driver, int i) {
        return driver
                .findElement(By.xpath("//table[@aria-label='Group Members']/tbody/tr[" + i + "]/td[2]/span/a"));
    }

    // Author :: Manish
    public static WebElement buttonCancel(WebDriver driver) {
        return driver.findElement(By.xpath("//button[@name='cancel']"));
    }

    // Author :: Manish
    public static WebElement caseSubjectLink(WebDriver driver, String val) {
        return driver.findElement(By.xpath("//a[contains(text(),'" + val + "')]"));
    }

    
    //**************************************************Kalam Methods******************************************************
    //**************************************************Manali Methods*****************************************************
    //**************************************************Anil Methods*******************************************************
    //**************************************************Amit Methods*******************************************************
    //**************************************************Sumit Methods******************************************************
    //**************************************************Bhavana Methods****************************************************

    //@Author: Bhavana
    //Returns a random student program from an array of student programs
    public String GetStuProg(String val,String classNo) throws Exception {
        ArrayList<String> al = new ArrayList<String>();
        String stuProg = "";
        String[] programs = val.trim().split(";");
        List<String> progList = Arrays.asList(programs);
        
        if(classNo.equals("LKG") ||classNo.equals("UKG") || classNo.equals("1") ||classNo.equals("2") || classNo.equals("3"))
        {
            al = excelData.getData1("DataCapture", "K3", "RRCaseAssignment", "StudentUnit");
            String existingProg = al.get(1);
            //progList.remove(existingProg);
            stuProg = progList.get(randomNumber(0,progList.size()));
            while(stuProg.equalsIgnoreCase(existingProg))
            {
                stuProg = progList.get(randomNumber(0,progList.size()-1));
            }
            log.info("Setting student program under K3 student unit");
            excelData.setData("src//main//java//testData//DataCapture.xlsx", "RRCaseAssignment", 1, 1, stuProg);
        }
        else if(classNo.equals("4") ||classNo.equals("5") || classNo.equals("6") ||classNo.equals("7") || classNo.equals("8") || classNo.equals("9") || classNo.equals("10"))
        {
            al = excelData.getData1("DataCapture", "K4-10", "RRCaseAssignment", "StudentUnit");
            String existingProg = al.get(1);
            //progList.remove(existingProg);
            stuProg = progList.get(randomNumber(0,progList.size()));
            while(stuProg.equalsIgnoreCase(existingProg))
            {
                stuProg = progList.get(randomNumber(0,progList.size()-1));
            }
            log.info("Setting student program under K4-10 student unit");
            excelData.setData("src//main//java//testData//DataCapture.xlsx", "RRCaseAssignment", 2, 1, stuProg);
        }
        else
        {
            al = excelData.getData1("DataCapture", "K11-12", "RRCaseAssignment", "StudentUnit");
            String existingProg = al.get(1);
            //progList.remove(existingProg);
            stuProg = progList.get(randomNumber(0,progList.size()));
            while(stuProg.equalsIgnoreCase(existingProg))
            {
                stuProg = progList.get(randomNumber(0,progList.size()-1));
            }
            log.info("Setting student program under K11-12 student unit");
            excelData.setData("src//main//java//testData//DataCapture.xlsx", "RRCaseAssignment", 3, 1, stuProg);
        }

        return stuProg;
    
    }

    //@Author: Bhavana
    //Returns a random shipped region from an array of regions 
    public String GetShippedRegion(String val,String classNo) throws Exception {
        String shipRegion = "";
        ArrayList<String> al = new ArrayList<String>();
        String[] shipRegions = val.trim().split(";");
        List<String> shipList = Arrays.asList(shipRegions);  

        if(classNo.equals("LKG") ||classNo.equals("UKG") || classNo.equals("1") ||classNo.equals("2") || classNo.equals("3"))
        {
            al = excelData.getData1("DataCapture", "K3", "RRCaseAssignment", "StudentUnit");
            String existingRegion = al.get(2);
            //shipList.remove(existingRegion);
            shipRegion = shipList.get(randomNumber(0,shipList.size()));
            while(shipRegion.equalsIgnoreCase(existingRegion))
            {
                shipRegion = shipList.get(randomNumber(0,shipList.size()));
            }
            log.info("Setting shipRegion under K3 student unit");
            excelData.setData("src//main//java//testData//DataCapture.xlsx", "RRCaseAssignment", 1, 2, shipRegion);
        }
        
        else if(classNo.equals("4") ||classNo.equals("5") || classNo.equals("6") ||classNo.equals("7") || classNo.equals("8") || classNo.equals("9") || classNo.equals("10"))
        {
            al = excelData.getData1("DataCapture", "K4-10", "RRCaseAssignment", "StudentUnit");
            String existingRegion = al.get(2);
            //shipList.remove(existingRegion);
            shipRegion = shipList.get(randomNumber(0,shipList.size()));
            while(shipRegion.equalsIgnoreCase(existingRegion))
            {
                shipRegion = shipList.get(randomNumber(0,shipList.size()));
            }
            log.info("Setting shipRegion under K4-10 student unit");
            excelData.setData("src//main//java//testData//DataCapture.xlsx", "RRCaseAssignment", 2, 2, shipRegion);
        }
        
        else
        {
            al = excelData.getData1("DataCapture", "K11-12", "RRCaseAssignment", "StudentUnit");
            String existingRegion = al.get(2);
            //shipList.remove(existingRegion);
            shipRegion = shipList.get(randomNumber(0,shipList.size()));
            while(shipRegion.equalsIgnoreCase(existingRegion))
            {
                shipRegion = shipList.get(randomNumber(0,shipList.size()));
            }
            log.info("Setting shipRegion under K11-12 student unit");
            excelData.setData("src//main//java//testData//DataCapture.xlsx", "RRCaseAssignment", 3, 2, shipRegion);
        }
            
        return shipRegion;
    
    }
    
    //@Author: Bhavana
    //Returns a random class from an array of classes
    public String GetClassNo(String classNo) throws Exception
    {
        String classNum = "";
        ArrayList<String> al = new ArrayList<String>();
        String[] classes = classNo.trim().split(";");
        List<String> classesList = Arrays.asList(classes);  
       
        if(classNo.equals("LKG") ||classNo.equals("UKG") || classNo.equals("1") ||classNo.equals("2") || classNo.equals("3"))
        {
            al = excelData.getData1("DataCapture", "K3", "RRCaseAssignment", "StudentUnit");
            String existingClass = al.get(3);
            //classesList.remove(existingClass);
            classNum = classesList.get(randomNumber(0,classesList.size()));
            while(classNum.equalsIgnoreCase(existingClass))
            {
                classNum = classesList.get(randomNumber(0,classesList.size()));
            }
            log.info("Setting class number under K3 student unit");
            excelData.setData("src//main//java//testData//DataCapture.xlsx", "RRCaseAssignment", 1, 3, classNum);
        }
        
        else if(classNo.equals("4") ||classNo.equals("5") || classNo.equals("6") ||classNo.equals("7") || classNo.equals("8") || classNo.equals("9") || classNo.equals("10"))
        {
            al = excelData.getData1("DataCapture", "K4-10", "RRCaseAssignment", "StudentUnit");
            String existingClass = al.get(3);
            //classesList.remove(existingClass);
            classNum = classesList.get(randomNumber(0,classesList.size()));
            while(classNum.equalsIgnoreCase(existingClass))
            {
                classNum = classesList.get(randomNumber(0,classesList.size()));
            }
            log.info("Setting class number under K4-10 student unit");
            excelData.setData("src//main//java//testData//DataCapture.xlsx", "RRCaseAssignment", 2, 3, classNum);
        }
        
        else
        {
            al = excelData.getData1("DataCapture", "K11-12", "RRCaseAssignment", "StudentUnit");
            String existingClass = al.get(3);
          //classesList.remove(existingClass);
            classNum = classesList.get(randomNumber(0,classesList.size()));
            while(classNum.equalsIgnoreCase(existingClass))
            {
                classNum = classesList.get(randomNumber(0,classesList.size()));
            }
            log.info("Setting class number under K11-12 student unit");
            excelData.setData("src//main//java//testData//DataCapture.xlsx", "RRCaseAssignment", 3, 3, classNum);
        }
        
        return classNum;
    
    }
    
    //@Author: Bhavana
    //Returns a random order delivery date from an array of regions 
    public ArrayList<String> GetordDelDate(String classNo) throws Exception {
        
        ArrayList<String> lis = new ArrayList<String>(); 
        String ordDelDate = "";
        ArrayList<String> al = new ArrayList<String>();
        ArrayList<String> allDates = new ArrayList<String>();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        
        Date date = DateUtils.addDays(new Date(), -10);
        String dateAfter = sdf.format(date);
        allDates.add(dateAfter);
        
        date = DateUtils.addDays(new Date(), -30);
        dateAfter = sdf.format(date);
        allDates.add(dateAfter);
        
        date = DateUtils.addDays(new Date(), -120);
        dateAfter = sdf.format(date);
        allDates.add(dateAfter);
        
        date = DateUtils.addDays(new Date(), -200);
        dateAfter = sdf.format(date);
        allDates.add(dateAfter);
        
        if(classNo.equals("LKG") ||classNo.equals("UKG") || classNo.equals("1") ||classNo.equals("2") || classNo.equals("3"))
        {
            al = excelData.getData1("DataCapture", "K3", "RRCaseAssignment", "StudentUnit");
            String existingDate = al.get(4);
            //allDates.remove(existingDate);
            ordDelDate = allDates.get(randomNumber(0,allDates.size()));
            
            while(ordDelDate.equalsIgnoreCase(existingDate))
            {
                ordDelDate = allDates.get(randomNumber(0,allDates.size()));
            }
            log.info("Setting order delivery date under K3 student unit");
            excelData.setData("src//main//java//testData//DataCapture.xlsx", "RRCaseAssignment", 1, 4, ordDelDate);
        }
        
        else if(classNo.equals("4") ||classNo.equals("5") || classNo.equals("6") ||classNo.equals("7") || classNo.equals("8") || classNo.equals("9") || classNo.equals("10"))
        {
            al = excelData.getData1("DataCapture", "K4-10", "RRCaseAssignment", "StudentUnit");
            String existingDate = al.get(4);
            //allDates.remove(existingDate);
            ordDelDate = allDates.get(randomNumber(0,allDates.size()));
            
            while(ordDelDate.equalsIgnoreCase(existingDate))
            {
                ordDelDate = allDates.get(randomNumber(0,allDates.size()));
            }
            log.info("Setting order delivery date under K4-10 student unit");
            excelData.setData("src//main//java//testData//DataCapture.xlsx", "RRCaseAssignment", 2, 4, ordDelDate);
        }
        
        else
        {
            al = excelData.getData1("DataCapture", "K11-12", "RRCaseAssignment", "StudentUnit");
            String existingDate = al.get(4);
            //allDates.remove(existingDate);
            ordDelDate = allDates.get(randomNumber(0,allDates.size()));
            
            while(ordDelDate.equalsIgnoreCase(existingDate))
            {
                ordDelDate = allDates.get(randomNumber(0,allDates.size()));
            }
            log.info("Setting order delivery date under K11-12 student unit");
            excelData.setData("src//main//java//testData//DataCapture.xlsx", "RRCaseAssignment", 3, 4, ordDelDate);
        }
        
        lis.add(ordDelDate);
        
        //getting the index of the ordDelDate and incrementing to get the segment number
        lis.add(Integer.toString(allDates.indexOf(ordDelDate)+1));
        
        return lis;
    
    }
    
    //@Author : Bhavana
    //To get the assignment rule based on the details
    public String GetQueueName(String prog, String shipReg, String classNo, String segmentNo)
    {
        String segment = "RR Segment"+" "+segmentNo;
        String stuUnit = "";
        String expectedQueue= null;
        String lang = null;
        
        if(classNo.equals("LKG") ||classNo.equals("UKG") || classNo.equals("1") ||classNo.equals("2") || classNo.equals("3"))
            stuUnit = "K3";
        
        else if(classNo.equals("4") ||classNo.equals("5") || classNo.equals("6") ||classNo.equals("7") || classNo.equals("8") || classNo.equals("9") || classNo.equals("10"))
            stuUnit = "K4-K10";
        
        else
            stuUnit = "K12";
        
        switch(shipReg)
        {
            case "KARNATAKA (KA)"  :
            case "Karnataka (KA)"  : lang = "Kannada"; break;
            case "KERALA (KL)" :
            case "Kerala (KL)" : lang = "Malayalam"; break;
            case "TAMIL NADU (TN)" : 
            case "Tamil Nadu (TN)" : lang = "Tamil"; break;
            case "PONDICHERRY (PY)" :
            case "Pondicherry (PY)" : lang = "Tamil"; break;
            case "ANDHRA PRADESH" :
            case "Andhra Pradesh" : lang = "Telugu"; break;
            case "TELANGANA (TS)" :
            case "Telangana (TS)" : lang = "Telugu"; break;
            //case "Maharashtra (MH)" : lang = "Hindi"; break;
            //case "West Bengal(WB)" : lang = "Hindi"; break;
            default: lang = "Hindi";
        }
        
        //SFDC-4163-TC03
        if(prog.contains("BCRPUCSY0001"))
        {
            expectedQueue = stuUnit+" "+"(BTC) "+lang;
        }
        //SFDC-4154
        else if(prog.contains("ACOPKXSY0001") || prog.contains("ACOPKXSY0003"))
        {
            stuUnit = "K12";
            expectedQueue = segment+" "+stuUnit+" "+lang;
        }
        else
        {
            expectedQueue = segment+" "+stuUnit+" "+lang;
        }
        return expectedQueue;   
    }
    
    //SELECT Program__c, Id, Cohort__c, QueueName__c, LowerDayCheck__c, HigherDateCheck__c 
    //FROM RetentionAssignmentRule__mdt where Program__c='ACOPKXSY0001' and LowerDayCheck__c = 61
    
    //@Author : Bhavana
    //To verify the case owner
    public void navToGrpMem() throws InterruptedException
    {
        visibleText(By.xpath("//span[text()='Group Members']"));
        Scrollpagedown();
        Thread.sleep(2000);
        jsClick(driver.findElement(By.xpath("//span[text()='Group Members']/following::a[@class='slds-card__footer']/span")));
        Thread.sleep(1000);
    }
    
    //@Author : Bhavana
    //To get the count of group members
    public String getGroupMemCount()
    {
        String count = driver.findElement(By.xpath("//div/h2/a/span[text()='Group Members']/following::span")).getText();
        return count;
    }
    
    //https://byjusprod--byjusuat.lightning.force.com/lightning/r/Account/001C2000009YTbuIAG/view
    //@Author : Bhavana
    //To verify if the owner is in the list of group members
    public boolean VerifyCaseOwner(String owner) throws InterruptedException
    {
        boolean flag = false;
        Thread.sleep(1000);
        
        String text = driver.findElement(By.xpath("//span[@class=\"countSortedByFilteredBy\"]")).getText();
        String[] arr = text.split(" ");
        int count = Integer.valueOf(arr[0]);
        
        //jsClick(driver.findElement(By.xpath("//h1[@title]/following::tr/td[3]/span")));
        
      /*  WebElement ele = driver.findElement(By.xpath("//h1[@title]/following::tr/td[3]//a"));
        Actions ac = new Actions(driver);
        ac.moveToElement(ele).click().build().perform(); */
        
        for(int i=0;i<count;i++)
        {
            driver.findElement(tag).sendKeys(Keys.DOWN);
            Thread.sleep(200);
            if(i+1==count) {
                //List<WebElement> list =driver.findElements(By.xpath("//h1[text()='Account Team']/following::span[@class='slds-row-number slds-text-body--small slds-text-color--weak']"));
                System.out.println("Last Element reached");
            }
        }
            
        //Scrollpagedown();
        List<WebElement> names = driver.findElements(By.xpath("//tr/td[3]//a"));
        
        ArrayList<String> grpMems = new ArrayList<String>();
        for(int  i=0;i<names.size();i++)           
            grpMems.add(names.get(i).getAttribute("title"));
        
        for(int  i=0;i<grpMems.size();i++)
        {
            if(grpMems.contains(owner))
                flag = true;
            break;
        }
        return flag;
    }
    
    public void jsClick(WebElement el) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor)driver;
            jse.executeScript("arguments[0].click();", el);
            System.out.println("Element clicked");
        } catch (Exception e){
            System.out.println("=============================================================");
            System.out.println("Exception-jsClick(): "+e.getMessage());
            takeScreenShot();
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }
    
    public List<WebElement> GroupMembers()
    {
        List<WebElement> names = driver.findElements(By.xpath("//tr/td[2]/span/a"));
        return names;
    }
    
    public boolean checkMemAvailability() throws InterruptedException
    {
        boolean flag = true;
        
        String active = driver.findElement(By.xpath("//td[text()='Active']/following::td/img")).getCssValue("title");
        Scrollpagedown();
        String available = driver.findElement(By.xpath("//td[text()='User Availability']/following::td")).getText();
        String capacity = driver.findElement(By.xpath("//td[text()='Capacity']/following::td")).getText();
        String weeklyOff = driver.findElement(By.xpath("//td[text()='Weekly Off']/following::td")).getText();
      
        String days[] = weeklyOff.split(";");
        
        List<String> days1 = Arrays.asList(days);  
        
        LocalDate today = LocalDate.now();
        DayOfWeek dayOfWeek = DayOfWeek.from(today);
        String currentDay = dayOfWeek.getDisplayName(TextStyle.FULL,Locale.ENGLISH);
       // System.out.println(" currentDay : " + currentDay);
        String NextDay = dayOfWeek.plus(1).getDisplayName(TextStyle.FULL,Locale.ENGLISH);
       // System.out.println("NextDay :"+NextDay);
        
        Date dt = new Date();
        SimpleDateFormat dateFormat;
        dateFormat = new SimpleDateFormat("H:mm");
        dateFormat.setTimeZone(TimeZone.getTimeZone("IST"));
        String time = dateFormat.format(dt);
        //System.out.println("Time in 24 hr format = "+time);
        
        String[] times = time.split(":");
        int currentTime = Integer.parseInt(times[0]);
        
        if(active.equals("Checked") && available.equals("Available") && capacity != "0" && !days1.contains(currentDay))
            flag = true;
        
        if(days1.contains(NextDay) && currentTime >= 18)
            flag = false;
        
        return flag;
        
    }
    
    public void Scrollpagedown() throws InterruptedException {

        driver.findElement(tag).sendKeys(Keys.PAGE_DOWN);
        Thread.sleep(1200);
    }
    
    //@Author : Bhavana
    //Navigate to iframe
    public void navToiframe(String title ) throws Exception
    {
        retryForDetachedFrame(driver, "//iframe", 0);
        WebElement frame=driver.findElement(By.xpath("//iframe[contains(@title,"+title+")]"));
        Thread.sleep(800);
        driver.switchTo().frame(frame);
    }
    
    //@Author : Bhavana
    //Returns a list of group members in an assignment rule
    public ArrayList<String> GetGrpMembers()
    {
        String name = "";
        List<WebElement> namesEle = driver.findElements(By.xpath("//tr/td[2]/span/a"));
        ArrayList<String> mems = new ArrayList<String>();
        for(int  i=0;i<namesEle.size();i++)
        {
            name = namesEle.get(i).getText();
            mems.add(name);
        }
        return mems;
    }
    
    //@Author : Bhavana
    //Returns the assignment rule detail of specified field
    public String getAssgnRuleDetails(String val) throws InterruptedException {

        visibleText(By.xpath("//span[text()='"+val+"']"));
        String name = driver.findElement(By.xpath("//span[text()='"+val+"']/following::span//lightning-formatted-text")).getText();
        return name;
    }
    
    //@Author : Bhavana
    //Navigates to group from assignment rule
    public void NavtoGroup(String name) throws InterruptedException {
        Thread.sleep(1000);
        ////span[text()='Group']/following::span[contains(text(),'"+name+"')]
        jsClick(driver.findElement(By.xpath("//span[text()='Group']/following::span[@force-lookup_lookup]")));
       
    }

    //@Author : Bhavana
    //Get the expected assignment rule 
    public String GetExpAssgnRule(ArrayList<String> al,String ruleCat,String lang) throws InterruptedException
    {
        String expectedQueue = "";
        Thread.sleep(1000);
        
        String stuUnit = driver.findElement(By.xpath("//span[text() = 'Student Unit']/following::lightning-formatted-text")).getText();
        if(stuUnit.equalsIgnoreCase("K3"))
        {
            if(al.get(2).equalsIgnoreCase("BELPK3BU0001") && ruleCat.equalsIgnoreCase("PE"))
                expectedQueue = "ELS"+" "+al.get(13)+" "+lang;
              else
                expectedQueue = ruleCat+" "+stuUnit+" "+lang;
        }
        
        else if(stuUnit.equalsIgnoreCase("K11-12"))
        {
            if(al.get(2).equalsIgnoreCase("ACRPKXSY0001"))
                expectedQueue = al.get(10)+" "+stuUnit;
            else
                expectedQueue = ruleCat+" "+stuUnit+" "+lang;
        }
        
        else
        {
            if(al.get(2).equalsIgnoreCase("BCOPKXSY0002") && al.get(17).equalsIgnoreCase("Yes"))
                expectedQueue = "2K Trial Team"+" "+stuUnit+" "+lang;
            
            else if(al.get(2).equalsIgnoreCase("BCOPKXSY0003"))
                expectedQueue = "MLP Trial Team"+" "+stuUnit+" "+lang;
            
            else if((al.get(2).equalsIgnoreCase("BCOPKXSY0001") || (al.get(2).equalsIgnoreCase("BCOPKXSY0002"))) && al.get(3).equalsIgnoreCase("Free") && al.get(5).equalsIgnoreCase("Quarterly"))
                expectedQueue = "Neo A & Q Admin"+" "+stuUnit;
           
            else  if(al.get(2).equalsIgnoreCase("BCOPKXSY0002") && ((al.get(3).equalsIgnoreCase("Free") && al.get(5).equalsIgnoreCase("Monthly")))) 
                expectedQueue = "Admin_Missing_rule";
                       
            else
                expectedQueue = ruleCat+" "+stuUnit+" "+lang;
        }
        
        return expectedQueue;
    }
    
    //@Author : Bhavana
    //Get the expected assignment rule 
    public String GetExpAssgnRuleRegion(ArrayList<String> al,String region,String ordSrc) throws InterruptedException
    {
        String expectedQueue = "";
        
        if(region.equalsIgnoreCase("North America"))
            expectedQueue = region+" "+al.get(13);
        else if(region.equalsIgnoreCase("Middle East"))
            expectedQueue = region+"-"+ordSrc;
        else 
            expectedQueue = region;
        return expectedQueue;
        
    }
    
    public boolean visibleText(By element)
    {
        WebDriverWait wait= new WebDriverWait(driver, 50);
        
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));
        
        System.out.println("Element is visible");
        return false;
    }


    //**************************************************Saurabh Methods****************************************************
}
    
