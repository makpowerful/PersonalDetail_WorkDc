package pageObjects;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.time.DateUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import resources.base;

public class PEOnBoardingTaskPO extends base {
	WebDriver driver;

	//private String btnNextxpath= "//button[text()='Next']";
	//private String lblAmtPaidbyCusxpath= "//label[text()='Amount Paid By Customer']/following::input";
	//private String btnListboxMovexpath = "//button[@title='Move selection to Selected']";
	//private String txtPayRefxpath = "//label[text()='Payment Reference']/following::input";
	//private String ddCollectionChnnelxpath = "//label[text()='Collection Channel']/following::button";
	//private String lblErrorMessxpath = "//div[@class='slds-text-color_error']";
	//private String ddNoEMICollxpath = "//select[@name='No_Of_EMI_Collected']";
	//private String ddTOCollAPxpath = "//select[@name='Type_Of_Collection_alreadyPaid']";
	//private String ddEligfrRefxpath = "//select[@name='Eligible_For_Refund']";
	//private String TaskCaptureiFrame="//iframe[@title='accessibility title']";

	// Declaring Constructor
	public PEOnBoardingTaskPO(WebDriver driver) {
		this.driver = driver;
	}
	
    //**************************************************Kalam Methods******************************************************

	//Author : Kalam
	//Click on Capture detail button
	public void ClickCaptureDetail() throws InterruptedException {
  jsClick(driver.findElement(By.xpath("//div[text()='Capture Call Details']")));
  Thread.sleep(3000);
	}
	
	//Author : Kalam
	//Select DNP as option
	public void SelectDNP() throws InterruptedException {
  driver.findElement(By.xpath("//lightning-formatted-rich-text/span[text()='DNP']")).click();
  Thread.sleep(1200);
  driver.findElement(By.xpath("//button[text()='Next']")).click();
  Thread.sleep(2000);
	}
	
	//Author : Kalam
	//Select Proceed as option
	public void SelectProceed() throws InterruptedException {
  driver.findElement(By.xpath("//lightning-formatted-rich-text/span[text()='Proceed']")).click();
  Thread.sleep(1000);
  driver.findElement(By.xpath("//button[text()='Next']")).click();
  Thread.sleep(1000);
	}
	
	//Author : Kalam
	//Select Proceed as option
	public void SelectProceed_iframe() throws Exception {
		retryForDetachedFrame(driver, "//iframe", 0);
		WebElement frame1=driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
		Thread.sleep(800);
		driver.switchTo().frame(frame1);
		visibleText(By.xpath("//lightning-formatted-rich-text/span[text()='Proceed']"));
		driver.findElement(By.xpath("//lightning-formatted-rich-text/span[text()='Proceed']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//button[text()='Next']")).click();
		Thread.sleep(3000);
	}
	
	//Author : Kalam
	//Select value for Proceed - Spoke To
	public void SelectProceedST(String val) throws InterruptedException {
		Select sel = new Select(driver.findElement(By.xpath("//span[contains(text(),'Spoke To')]/following::select[@required]")));
		sel.selectByVisibleText(val);
		Thread.sleep(800);
	}
	
	//Author : Kalam
	//Select value for Proceed - Spoke_To
	public void SelectProceedS_T(String val) throws InterruptedException {
		Select sel = new Select(driver.findElement(By.xpath("//span[contains(text(),'Spoke_To')]/following::select[@required] | //span[contains(text(),'Spoke To')]/following::select[@required]")));
		sel.selectByVisibleText(val);
		Thread.sleep(200);
	}
	
	//Author : Kalam
	//Select value for Proceed - Have they pitched the Mentor Connect App
	public void SelectProceedHTPTMCA(String val) throws InterruptedException {
		Select sel = new Select(driver.findElement(By.xpath("//span[contains(text(),'Have they pitched the Mentor Connect App')]/following::select[@required]")));
		sel.selectByVisibleText(val);
		Thread.sleep(200);
	}
	
	//Author : Kalam
	//Select value for Proceed - Student's App Usage
	public void SelectProceedSAU(String val) throws InterruptedException {
		Select sel = new Select(driver.findElement(By.xpath("//select[@name='Student_s_App_Usage']")));
		sel.selectByVisibleText(val);
		Thread.sleep(200);
	}
	
	//Author : Kalam
	//Select value for Proceed - Student's App Usage 
	public void SelectProceedSAU_iframe(String val) throws InterruptedException {
		Select sel = new Select(driver.findElement(By.xpath("//span[contains(text(),'App Usage')]/following::select")));
		sel.selectByVisibleText(val);
		Thread.sleep(200);
	}
	
	//Author : Kalam
	//Select value for Proceed - Issue Resolved?
	public void SelectProceedIR(String val) throws InterruptedException {
		Select sel = new Select(driver.findElement(By.xpath("//select[@name='IsTheIssueResolved']")));
		sel.selectByVisibleText(val);
		Thread.sleep(800);
	}
	
	//Author : Kalam
	//Capture the Assigned To of PE Onboarding Call
    public String CapturePEOnboardingAssigned() {
        visibleText(By.xpath("//div[text()='Task']/following::span[text()='Assigned To']"));
        String PEShippedOwner= driver.findElement(By.xpath("//div[text()='Task']/following::span[text()='Assigned To']/following::a")).getText();
        return PEShippedOwner;
    }

  //Author : Kalam
	//Select value for Proceed - Notes
	public void SelectProceedNotes(String val) throws InterruptedException {
		driver.findElement(By.xpath("//lightning-formatted-rich-text/span[text()='Notes']/following::textarea")).sendKeys(val);
		Thread.sleep(800);
		 driver.findElement(By.xpath("//button[text()='Next']")).click();
		  Thread.sleep(2200);
	}
	
	//Author : Kalam
	//Select value for Neo Classes feedback screen - Notes
	public void EnterNotes(String val) throws InterruptedException {
		driver.findElement(By.xpath("//lightning-formatted-rich-text/span[text()='Notes']/following::textarea")).sendKeys(val);
		Thread.sleep(800);
	}
	
	//Author : Kalam
	//Select Student has attended any class since last outbound call?
	public void SelectProceedSHAAC(String val) throws InterruptedException {
		Select sel = new Select(driver.findElement(By.xpath("//select[@required]")));
		sel.selectByVisibleText(val);
		Thread.sleep(800);
		 driver.findElement(By.xpath("//button[text()='Next']")).click();
		  Thread.sleep(2000);
		
	}
	
	//Author : Kalam
	   //Click Next
    public void ClickNext() throws InterruptedException {
         driver.findElement(By.xpath("//button[text()='Next']")).click();
          Thread.sleep(2000);
    }
	
  //Author : Kalam
	//Select value for Proceed - Is There Any Issue?
	public void SelectProceedIsThereIssue(String val) throws Exception {
		
		//visibleText(By.xpath("//select[@name='Is_There_Any_Issue_Picklist']"));
	
		//Select sel = new Select(driver.findElement(By.xpath("//select[@required]"))); 
		Thread.sleep(5000);
		Select sel = new Select(driver.findElement(By.xpath("//select[@name='Is_There_Any_Issue_Picklist']"))); 
		sel.selectByVisibleText(val);
		Thread.sleep(800);
		 driver.findElement(By.xpath("//button[text()='Next']")).click();
		  Thread.sleep(4000);
		  driver.switchTo().defaultContent();
		
	}
	
	//Author : Kalam
	//Select value for Proceed - Is There Any Issue?
	public void SelectProceedIsThereIssue2(String val) throws InterruptedException {
		visibleText(By.xpath("//span[text()='Is There Any Issue?']"));
		Select sel = new Select(driver.findElement(By.xpath("//select")));
		sel.selectByVisibleText(val);
		Thread.sleep(800);
		 driver.findElement(By.xpath("//button[text()='Next']")).click();
		  Thread.sleep(4000);
		
	}
	
	//Author : Kalam
	//Change the Due date
	public void ChangeDueDate() throws InterruptedException {
		driver.findElement(By.xpath("//span[text()='PE - Onboarding Call']/following::span[text()='Due Date']/following::button")).click();
		Thread.sleep(1500);
		driver.findElement(By.xpath("//span[text()='PE - Onboarding Call']/following::label[text()='Due Date']/following::input")).clear();
		Thread.sleep(500);
		 Date date = DateUtils.addDays(new Date(), -5);
		 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		 driver.findElement(By.xpath("//span[text()='PE - Onboarding Call']/following::label[text()='Due Date']/following::input")).sendKeys(sdf.format(date));
		 Thread.sleep(500);
		 driver.findElement(By.xpath("//span[text()='PE - Onboarding Call']/following::span[text()='Save']")).click();
		 Thread.sleep(3000);
	}
	
	//Author : Kalam
	//Student has attended any class since last outbound call?
	public void SelectSHAACLOC(String val) throws InterruptedException {
		Select sel = new Select(driver.findElement(By.xpath("//span[text()='Student has attended any class since last outbound call?']/following::select[@required]")));
		sel.selectByVisibleText(val);
		Thread.sleep(200);
	}
	
	//Author : Kalam
	//1. Product
	public void SelectProductRating(String val) throws InterruptedException {
		Select sel = new Select(driver.findElement(By.xpath("//span[text()='1. Product']/following::select[@required]")));
		sel.selectByVisibleText(val);
		Thread.sleep(200);
	}
	
	//Author : Kalam
	//What all did you not like about the product
	public void SelectNotLikeProduct(String val) throws InterruptedException {
		jsClick(driver.findElement(By.xpath("//span[text()='What all did you not like about the product']/following::span[text()='"+val+"']")));
		Thread.sleep(200);
	}
	
	//Author : Kalam
	//2. Teacher
	public void SelectTeacherRating(String val) throws InterruptedException {
		Select sel = new Select(driver.findElement(By.xpath("//span[text()='2. Teacher']/following::select[@required]")));
		sel.selectByVisibleText(val);
		Thread.sleep(200);
	}
	
	//Author : Kalam
	//What all did you not like about the teacher
	public void SelectNotLikeTeacher(String val) throws InterruptedException {
		jsClick(driver.findElement(By.xpath("//span[text()='What all did you not like about the teacher']/following::span[text()='"+val+"']")));
		Thread.sleep(200);
	}
	
	//Author : Kalam
	//3. Content (Coverage, sync with school, relevance, quiz/polls)
	public void SelectContentRating(String val) throws InterruptedException {
		Select sel = new Select(driver.findElement(By.xpath("//span[text()='3. Content (Coverage, sync with school, relevance, quiz/polls)']/following::select[@required]")));
		sel.selectByVisibleText(val);
		Thread.sleep(200);
	}
	
	//Author : Kalam
	//What all did you not like about the content
	public void SelectNotLikeContent(String val) throws InterruptedException {
		jsClick(driver.findElement(By.xpath("//span[text()='What all did you not like about the product']/following::span[text()='"+val+"']")));
		Thread.sleep(200);
	}
	
	//Author : Kalam
	//Student's App Usage
	public void SelectStudentAppUsage(String val) throws InterruptedException {
		Select sel = new Select(driver.findElement(By.xpath("//span[contains(text(),'App Usage')]/following::select[@required]")));
		sel.selectByVisibleText(val);
		Thread.sleep(200);
	}
	
	//Author : Kalam
	//Is the TLP product Onboarding done?
	public void SelectTLPOnboardngDone(String val) throws InterruptedException {
		Select sel = new Select(driver.findElement(By.xpath("//span[contains(text(),'Is the TLP product Onboarding done?')]/following::select[@required]")));
		sel.selectByVisibleText(val);
		Thread.sleep(200);
		  driver.findElement(By.xpath("//button[text()='Next']")).click();
		  Thread.sleep(3000);
	}
	
	//Author : Kalam
	//Capture the Assigned To of PE Onboarding Call
	public String CapturePEOnBoardingAssigned() {
		String PEOnBoardingOwner= driver.findElement(By.xpath("//span[text()='Assigned To']/following::a")).getText();
		return PEOnBoardingOwner;
	}
	
	//Author : Kalam
	//Click Next button
	public void ClickOnboardingScreenNext() throws InterruptedException {
		  visibleText(By.xpath("//header[contains(text(),'Onboarding Call')]"));
		  clickButton(driver.findElement(By.xpath("//header[contains(text(),'Onboarding Call')]/following::button[text()='Next']")));
		  jsClick(driver.findElement(By.xpath("//header[contains(text(),'Onboarding Call')]/following::button[text()='Next']")));
		  Thread.sleep(2500);
	}
	

	//Author : Kalam
  //Navigate back to Account screen
	public void NavBackAccount() throws InterruptedException {
		try
	    {
			  jsClick(driver.findElement(By.xpath("//span[text()='Name']/following::a")));
			  Thread.sleep(2500);
	    }
	    catch(WebDriverException e)
	    {
	    	  jsClick(driver.findElement(By.xpath("//span[text()='Name']/following::a")));
	    	  Thread.sleep(2500);
	    }
	    catch(Exception ee)
	    {
	        ee.printStackTrace();
	        throw ee;
	    }
	}
	
	//Author : Kalam
	   //Capture Due Date
    public String CaptureDueDate() {
        String DueDate = driver.findElement(By.xpath("//div[text()='Task']/following::span[text()='Due Date']//following::span[2]")).getText();
        return DueDate;
        
    }
    
  //Author : Kalam
    //Date compare
    public String DateCompare(int val) {
        Date date = DateUtils.addDays(new Date(), val);
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy"); 
        return sdf.format(date);
    }
	  
  //Author : Kalam
	   public void jsClick(WebElement el) {
			try {
				JavascriptExecutor jse = (JavascriptExecutor)driver;
				jse.executeScript("arguments[0].click();", el);
				System.out.println("Element clicked");
			} catch (Exception e){
				System.out.println("=============================================================");
				System.out.println("Exception-jsClick(): "+e.getMessage());
				//takeScreenShot();
				e.printStackTrace();
				System.out.println("=============================================================");
			}
		}
	 //Author : Kalam
		public void clickButton(WebElement element)
		{
			WebDriverWait wait= new WebDriverWait(driver, 10000);
			
			wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));
			
			System.out.println("Element is clickable");
			element.click();
		}
	  
		//Author : Kalam
		public boolean visibleText(By element)
		{
			WebDriverWait wait= new WebDriverWait(driver, 10000);
			
			wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));
			
			System.out.println("Element is visible");
			return false;
		}
		
		//**************************************************Manish Methods*****************************************************
		
		//==============================Author :: Manish Goyal
		
		public void SelectProceedIsThereIssueFC(String val) throws Exception {
			
			//visibleText(By.xpath("//select[@name='Is_There_Any_Issue_Picklist']"));
		
			//Select sel = new Select(driver.findElement(By.xpath("//select[@required]"))); 
			Thread.sleep(5000);
			Select sel = new Select(driver.findElement(By.xpath("//select[@class='slds-select pickVal']"))); 
			sel.selectByVisibleText(val);
			Thread.sleep(800);
			 driver.findElement(By.xpath("//button[text()='Next']")).click();
			  Thread.sleep(4000);
			  driver.switchTo().defaultContent();
			
		}
		
		
	    //**************************************************Manali Methods*****************************************************
	    //**************************************************Anil Methods*******************************************************
	    //**************************************************Amit Methods*******************************************************
	    //**************************************************Sumit Methods******************************************************
	    //**************************************************Bhavana Methods****************************************************
		//**************************************************Saurabh Methods****************************************************
}
