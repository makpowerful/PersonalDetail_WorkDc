package pageObjects;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.commons.lang.time.DateUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import resources.ExcelData;
import resources.base;

public class StudentProgPO extends base {
    WebDriver driver;

    
    private String lnkSSOxpath= "//span[text()='Student Sales Order']/following::span[@force-lookup_lookup]";
    static int randomNum = ThreadLocalRandom.current().nextInt(10000, 100000 + 1);
    static int randomNum1 = ThreadLocalRandom.current().nextInt(1, 100 + 1);
    


    // Declaring Constructor
    public StudentProgPO(WebDriver driver) {
        this.driver = driver;
    }
    
    //**************************************************Kalam Methods******************************************************

    
    //Author : Kalam
    //Click on Student Sales Order
    public void ClickSSO() throws InterruptedException {
     driver.findElement(By.xpath(lnkSSOxpath)).click();
      Thread.sleep(3000);
    }
    
    //Author : Kalam
    //View and Edit Class/Program Type
    public void EditClass_ProgramType() throws InterruptedException {
        visibleText(By.xpath("//span[text()='Class/Program Type']"));
        jsClick(driver.findElement(By.xpath("//span[text()='Class/Program Type']/following::button")));
        Thread.sleep(500);
    }
    
    //Author : Kalam
    //Select Class/Program Type
    public void SelectClass_ProgramType(String val) throws InterruptedException {
        visibleText(By.xpath("//label[text()='Class/Program Type']"));
        jsClick(driver.findElement(By.xpath("//label[text()='Class/Program Type']/following::button")));
        Thread.sleep(300);
        jsClick(driver.findElement(By.xpath("//label[text()='Class/Program Type']/following::span[text()='"+val+"']")));
        Thread.sleep(300);
    }
    
    //Author : Kalam
   //Select Product Type
    public void SelectProductType(String val) throws InterruptedException {
        visibleText(By.xpath("//div[text()='Student Program']/following::span[text()='Product Type']"));
        jsClick(driver.findElement(By.xpath("//div[text()='Student Program']/following::span[text()='Product Type']/following::button")));
        Thread.sleep(500);
        jsClick(driver.findElement(By.xpath("//label[text()='Product Type']/following::button")));
        Thread.sleep(200);
        jsClick(driver.findElement(By.xpath("//label[text()='Product Type']/following::button/following::span[text()='"+val+"']")));
        Thread.sleep(200);
    }

    //Author : Kalam
    //Select Product Type
    public void SelectProductType2(String val) throws InterruptedException {
     visibleText(By.xpath("//label[text()='Product Type']"));
     jsClick(driver.findElement(By.xpath("//label[text()='Product Type']/following::button")));
     Thread.sleep(200);
     jsClick(driver.findElement(By.xpath("//label[text()='Product Type']/following::button/following::span[text()='"+val+"']")));
     Thread.sleep(200);
 }
    //Author : Kalam
    //Verify the Class/Program Type picklist
    public void VerifyPL_Class_ProgramType(String val) throws InterruptedException {
        
        scrollIntoView(driver.findElement(By.xpath("//label[text()='Class/Program Type']")));
        jsClick(driver.findElement(By.xpath("//label[text()='Class/Program Type']/following::button")));
        //System.out.println(driver.findElement(By.xpath("//label[text()='BYJU’s Classes type']/following::button/following::div[contains(@class,'vertical')]/lightning-base-combobox-item/span/span")));
        List<WebElement> list = driver.findElements(By.xpath("//label[text()='Class/Program Type']/following::button/following::div[contains(@class,'vertical')]/lightning-base-combobox-item/span/span"));
        for(int i=0;i<list.size();i++) {
            String value = list.get(i).getText();
            
                if(value.equalsIgnoreCase(val)) {
                    Assert.assertTrue(true);
                    System.out.println("Current value "+value+" is equal to "+val+"");
                    break;
                }   
                else {
                    System.out.println("Current value "+value+" is not equal to "+val+"");
                    if((i+1==list.size())) {
                        System.out.println("All "+list.size()+" values were not matching the picklist value "+val+"");
                        Assert.assertTrue(false);
                    }
                }
            } 
        jsClick(driver.findElement(By.xpath("//label[text()='Class/Program Type']/following::button")));
     }

    //Author : Kalam
    //Click Cancel button
    public void ClickCancel() throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//button[text()='Cancel']")));
        Thread.sleep(1000); 
     }
    
    //Author : Kalam
    //Click New Button 
    public void ClickNewbutton() throws InterruptedException {
    driver.findElement(By.xpath("//div[text()='New']")).click();
    Thread.sleep(2000);
    }
    
    //Author : Kalam
    //Enter Student Program Name
    public void EnterStudentProgramName(String val) throws InterruptedException {
    driver.findElement(By.xpath("//h2[text()='New Student Program']/following::label[text()='Student Program Name']/following::input")).sendKeys(val);
    Thread.sleep(200);
    }
    
   //Author : Kalam
   //Enter Start Date
    public void EnterStartDate() throws InterruptedException {
    Date date = DateUtils.addDays(new Date(), -5);
    SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
    driver.findElement(By.xpath("//h2[text()='New Student Program']/following::label[text()='Start Date']/following::input")).sendKeys(sdf.format(date));
    Thread.sleep(500);
    }

    //Author : Kalam
    //Enter Start Date
    public void EnterStartDate_dmy() throws InterruptedException {
    Date date = DateUtils.addDays(new Date(), -5);
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    driver.findElement(By.xpath("//h2[text()='New Student Program']/following::label[text()='Start Date']/following::input")).sendKeys(sdf.format(date));
    Thread.sleep(500);
    }
    
    //Author : Kalam
    //Enter Status
    public void EnterStatus(String val) throws InterruptedException {
    jsClick(driver.findElement(By.xpath("//h2[text()='New Student Program']/following::label[text()='Status']/following::button")));
    Thread.sleep(200);
    jsClick(driver.findElement(By.xpath("//h2[text()='New Student Program']/following::label[text()='Status']/following::lightning-base-combobox-item[@data-value='"+val+"']")));
    Thread.sleep(200);
    }
    
    //Author : Kalam
    //Enter Student Enrolment ID
    public void EnterStudentEnrolmentID(String val) throws InterruptedException {
    
    driver.findElement(By.xpath("//h2[text()='New Student Program']/following::label[text()='Student Enrolment ID']/following::input")).sendKeys(val+randomNum+randomNum1);
    System.out.println("Student Enrolment ID is: "+val+randomNum+randomNum1);
    Thread.sleep(200);
    }
    
    //Author : Kalam
    //Enter Program
    public void EnterProgram(String val) throws InterruptedException {
    driver.findElement(By.xpath("//h2[text()='New Student Program']/following::label[text()='Program']/following::input")).sendKeys(val);
    visibleText(By.xpath("//*[contains(text(),'Show All Results for')]"));
    jsClick(driver.findElement(By.xpath("//*[contains(text(),'Show All Results for')]")));
    }
    
    //Author : Kalam
    //Click Program
    public void ClickProgramName() throws InterruptedException {
    visibleText(By.xpath("//h2[text()='Program']"));
    jsClick(driver.findElement(By.xpath("//h2[text()='Program']/following::a[@data-navigable]")));
    }
    
    //Author : Kalam
    //Click Save
    public void ClickSave() throws InterruptedException {
        driver.findElement(By.xpath("//button[text()='Save']")).click();
        Thread.sleep(2000);
    }
    
    //Author : Kalam
    public void clickButton(WebElement element)
    {
        WebDriverWait wait= new WebDriverWait(driver, 100);
        
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));
        
        System.out.println("Element is clickable");
        element.click();
    }
    
    //Author : Kalam
    public boolean visibleText(By element)
    {
        WebDriverWait wait= new WebDriverWait(driver, 100);
        
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));
        
        System.out.println("Element is visible");
        return false;
    }
    
    //Author : Kalam
    public void jsClick(WebElement el) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor)driver;
            jse.executeScript("arguments[0].click();", el);
            System.out.println("Element clicked");
        } catch (Exception e){
            System.out.println("=============================================================");
            System.out.println("Exception-jsClick(): "+e.getMessage());
            takeScreenShot();
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }
    
  //Author : Kalam
    public void Scrollpagedown() throws InterruptedException {

        driver.findElement(tag).sendKeys(Keys.PAGE_DOWN);
        Thread.sleep(1200);
    }

    //Author : Kalam
    // Scroll element to view
    public void scrollIntoView(WebElement element) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor)driver;
            jse.executeScript("arguments[0].scrollIntoView(true);", element);
            System.out.println("Page scrolled down");
        } catch (Exception e){
            System.out.println("=============================================================");
            System.out.println("Exception-scrollIntoView(): "+e.getMessage());
            takeScreenShot();
            e.printStackTrace();
            System.out.println("=============================================================");
        }    
    }
    
    //Click on Branch Account
    public void ClickBranchAccount() throws InterruptedException {
        visibleText(By.xpath("//div[text()='Student Program']/following::span[text()='Branch Account']"));
        jsClick(driver.findElement(By.xpath("//div[text()='Student Program']/following::span[text()='Branch Account']/following::a")));
        Thread.sleep(1000);
    }
    
    
    
    
    //**************************************************Manali Methods*****************************************************
    
    // To get the primary prog id, prodType, trialPgm
    public String[] verifyIsPrimarychecked() throws InterruptedException {
        Thread.sleep(1000);
        goToprimaryProg();
        Thread.sleep(2000);
        // to get the product type of primary prog
        visibleText(By.xpath("//div[text()='Student Program']/following::span[text()='Product Type']"));
        String prodType = driver
            .findElement(By.xpath("//div[text()='Student Program']/following::span[text()='Product Type']/following::lightning-formatted-text")).getText();
        Thread.sleep(2000);
        // to get the trial pgm
        String trialPgm = driver
            .findElement(By.xpath("//span[text()='Trial Program']/following::lightning-formatted-text"))
            .getText();
        driver.findElement(By.xpath("//span[text()='Program']/following::span//a//span")).click();
        Thread.sleep(12000);
        Thread.sleep(12000);
        String progId = driver.findElement(By.xpath("//span[text()='Program ID']/following::lightning-formatted-text"))
            .getText();
        return new String[] { progId,prodType, trialPgm};
      }
    
    // To click on Asgmt CDC Executors
    public void ClickAsgmtCDCExecutors() throws InterruptedException {
        //visibleText(By.xpath("//h2//span[@title='AsgmtCDCExecutors']"));       
        jsClick(driver.findElement(By.xpath("//h2//span[@title='AsgmtCDCExecutors']")));
        Thread.sleep(1000);
    }
    
    // To get the 'Completed' status count, Parameter numb= no. of tasks in the excel
    public int statusCompletedCount(int numb, String status) throws InterruptedException {
        List<WebElement> list;
        if (status.equalsIgnoreCase("Open") || status.equalsIgnoreCase("Cancelled") ) {
           list = driver.findElements(By.xpath("//span[text()='"+status+"']")); 
        }else {
       list = driver.findElements(By.xpath("//lightning-primitive-custom-cell/lst-formatted-text[text()='"+status+"']"));
        }
       int count=list.size();
       int i = 1;
       
       while(i<=7) 
       {
           if(count == numb)
               break;
           else
           {
               Thread.sleep(2000);
               //driver.navigate().refresh();
               jsClick(driver.findElement(By.xpath("//button[contains(@title,'Actions for')]")));
               Thread.sleep(900);
               jsClick(driver.findElement(By.xpath("//li[@title='Refresh Tab']/a")));
               Thread.sleep(200);
               if (status.equalsIgnoreCase("Open") || status.equalsIgnoreCase("Cancelled") ) {
                   list = driver.findElements(By.xpath("//span[text()='"+status+"']")); 
               }else {
                   list = driver.findElements(By.xpath("//lightning-primitive-custom-cell/lst-formatted-text[text()='"+status+"']"));
               }
               count=list.size();
           }
           i++;
           
       }
       
       return count;
    } 
    
    // To get the task due date, Parameter numb= task subject
    public String getTaskDueDate(String taskName,String dateTime) throws InterruptedException {
       //visibleText(By.xpath("//span[text()='"+taskName+"']/preceding::th[1]//a")); 
       driver.findElement(By.xpath("//lst-formatted-text[text()='"+taskName+"']/following::span//lst-formatted-text[text()='"+dateTime+"']/preceding::th[1]")).click();
       Scrollpagedown();
       String taskDueDate=driver.findElement(By.xpath("//span[text()='Task Due Date']/following::lightning-formatted-number")).getText();
       return taskDueDate;
    }
    
    //**************************************************Manish Methods*****************************************************
    //**************************************************Anil Methods*******************************************************
    //**************************************************Amit Methods*******************************************************
    //**************************************************Sumit Methods******************************************************
    //**************************************************Bhavana Methods****************************************************
    
    //Author : Bhavana
    //Select Duration
    public void SelectDuration(String val) throws InterruptedException {
        Scrollpagedown();
        //visibleText(By.xpath("//label[text()='Duration']"));
        jsClick(driver.findElement(By.xpath("//label[text()='Duration']/following::button")));
        Thread.sleep(300);
        jsClick(driver.findElement(By.xpath("//label[text()='Duration']/following::span[text()='"+val+"']")));
        Thread.sleep(300);
    }
    
    //@Author : Bhavana
    //Select trial program
    public void SelectTrialProg(String val) throws InterruptedException {
        Scrollpagedown();
        Thread.sleep(1000);
        //visibleText(By.xpath("//span[text()='Trial Program'] | //label[text()='Trial Program']"));
        jsClick(driver.findElement(By.xpath("//span[text()='Trial Program']/following::button")));
        Thread.sleep(1000);
        jsClick(driver.findElement(By.xpath("//label[text()='Trial Program']/following::button")));
        Thread.sleep(1000);
        jsClick(driver.findElement(By.xpath("//label[text()='Trial Program']/following::button/following::span[text()='"+val+"']")));
        Thread.sleep(1000);
     }
    
    //@Author : Bhavana
    // To get the primary prog id, prodType, trialPgm
    public void goToprimaryProg() throws InterruptedException {
      List<WebElement> ele = driver.findElements(By.xpath("//h1[@title='Student Programs']/following::input[@name='IsPrimaryProgram__c']"));
      for(int i=0; i<ele.size();i++) {
         // boolean value=driver.findElement(By.xpath("//h1[@title='Student Programs']/following::input[@name='IsPrimaryProgram__c']")).isSelected();
          boolean value = ele.get(i).isSelected();
          int j = i+1;
          if(value == true) {
              jsClick(driver.findElement(By.xpath("//h1[@title='Student Programs']/following::span[@class='slds-checkbox_faux'][@part][1]/preceding::td[5]/following::th["+j+"]//a")));
              Thread.sleep(1000);
              break;
          }
       }
    }
    //@Author : Bhavana
    //Navigates to program which is not primary
    public void goToNonprimaryProg() throws InterruptedException {
      Thread.sleep(1000);
      List<WebElement> ele = driver.findElements(By.xpath("//h1[@title='Student Programs']/following::input[@name='IsPrimaryProgram__c']"));
      for(int i=0; i<ele.size();i++) {
        //boolean value=driver.findElement(By.xpath("//h1[@title='Student Programs']/following::input[@name='IsPrimaryProgram__c']")).isSelected();
          boolean value = ele.get(i).isSelected();
          int j = i+1;
          if(value == false) {
              jsClick(driver.findElement(By.xpath("//h1[@title='Student Programs']/following::span[@class='slds-checkbox_faux'][@part][1]/preceding::td[5]/following::th["+j+"]//a")));
              Thread.sleep(1000);
              break;
          }
       }
    }
    
    public void Scrollpageup() throws InterruptedException {

        driver.findElement(tag).sendKeys(Keys.PAGE_UP);
        Thread.sleep(1200);
    }
    
    //@Author : Bhavana
    //click on pencil icon on a student program
    public void clickEditBtn() throws InterruptedException {
        Thread.sleep(1000);
        jsClick(driver.findElement(By.xpath("//div[text()='Student Program']/following::span[text()='Product Type']/following::button")));
        Thread.sleep(500);
    } 
    
    //@Author : Bhavana
    // To get progId-prodType-progType-Duration-TrialProg // 11-12 //K3 //BTLA
    public String getCombination(String stuUnit,String newstuUnit,ArrayList<String> al) throws InterruptedException {
        
        String prodType;
        String progType;
        String duration;
        String trialPgm;
        String usageMode="";
        
        //To get the product type
        if(!al.get(18).equalsIgnoreCase("NA"))
            prodType = driver.findElement(By.xpath("//div[text()='Student Program']/following::span[text()='Product Type']/following::lightning-formatted-text")).getText();
        else
            prodType = al.get(18);
        
        Thread.sleep(500);
        
        //To get program type
        if(!al.get(19).equalsIgnoreCase("NA"))
            progType = driver.findElement(By.xpath("//div[text()='Student Program']/following::span[text()='Class/Program Type']/following::lightning-formatted-text")).getText();
        else
            progType = al.get(19);
        Thread.sleep(500);
        
        Scrollpagedown();
        
        //To get duration
        if(!al.get(20).equalsIgnoreCase("NA"))
            duration = driver.findElement(By.xpath("//span[text()='Duration']/following::lightning-formatted-text")).getText();
        else
            duration = al.get(20);
        Thread.sleep(500);
        
        //To get the trial prgm
        trialPgm = driver.findElement(By.xpath("//span[text()='Trial Program']/following::lightning-formatted-text")).getText();
        Thread.sleep(500);
        
        if(stuUnit.equalsIgnoreCase("K3"))
        {
          //To get the usage mode
            if(!al.get(21).equalsIgnoreCase("NA"))
                usageMode = driver.findElement(By.xpath("//span[text()='Usage Mode']/following::lightning-formatted-text")).getText();
            else
                usageMode = al.get(21);
        }
        
        Thread.sleep(500);
        Scrollpageup();
        //To get the program Id
        Thread.sleep(2000);
        driver.findElement(By.xpath("//span[text()='Program']/following::span//a//span")).click();
        Thread.sleep(12000);
        String progId = driver.findElement(By.xpath("//span[text()='Program ID']/following::lightning-formatted-text")).getText();
        Thread.sleep(500);
        
        String comb = "";
        
        if(stuUnit.equalsIgnoreCase("K3"))
            comb = progId+"-"+prodType+"-"+progType+"-"+duration+"-"+trialPgm+"-"+usageMode+"-"+newstuUnit;
        else
            comb = progId+"-"+prodType+"-"+progType+"-"+duration+"-"+trialPgm+"-"+newstuUnit;
        
        return comb;

    } 
    
    //@Author : Bhavana
    //Returns new program from randomly selected student unit
    public ArrayList<String> getNewProg(String currstuUnit,String classNo) throws IOException
    {
        ExcelData excelData = new ExcelData();
        ArrayList<String> al =new  ArrayList<String>();
        String stuUnit = "";
        int noofRows1;
        String Tcid;

        //getting random student unit
        int c = randomNumber( 1,12);
        
        while(c<Integer.valueOf(classNo) && !currstuUnit.equalsIgnoreCase("K11-12"))
        {
            c = randomNumber( 1,12);
        }
        
        if(c>=1 && c<=3)
            stuUnit = "K3";
        
        else if(c>=4 && c<=6)
            stuUnit = "K4-6";
        
        else if(c>=7 && c<=9)
            stuUnit = "K7-9";
        
        else if(c==10)
            stuUnit = "K10";
        
        else
            stuUnit = "K11-12";
        
        while(currstuUnit.equalsIgnoreCase(stuUnit))//c == Integer.valueOf(classNo) ||
        {
            c = randomNumber(1,12);
            
            if(c>=1 && c<=3)
                stuUnit = "K3";
            
            else if(c>=4 && c<=6)
                stuUnit = "K4-6";
            
            else if(c>=7 && c<=9)
                stuUnit = "K7-9";
            
            else if(c==10)
                stuUnit = "K10";
            
            else
                stuUnit = "K11-12";
        }
        
        //getting a random row from above student unit
        if(stuUnit.equalsIgnoreCase("K3"))
        {
            noofRows1 = getRowCount("src//main//java//testData//TestData.xlsx", "Revamp_K3");
            //getting a random row number 
            Tcid = String.valueOf(randomNumber(1,noofRows1-1));
            al = excelData.getData(Tcid, "Revamp_K3", "Tcid");
            
        }
        
        else if(stuUnit.equalsIgnoreCase("K4-6"))
        {
            noofRows1 = getRowCount("src//main//java//testData//TestData.xlsx", "Revamp_K4-6");
            //getting a random row number 
            Tcid = String.valueOf(randomNumber(1,noofRows1-1));
            al = excelData.getData(Tcid, "Revamp_K4-6", "Tcid");
        }
        
        else if(stuUnit.equalsIgnoreCase("K7-9"))
        {
            noofRows1 = getRowCount("src//main//java//testData//TestData.xlsx", "Revamp_K8-9");
            //getting a random row number 
            Tcid = String.valueOf(randomNumber(1,noofRows1-1));
            al = excelData.getData(Tcid, "Revamp_K8-9", "Tcid");
            
            if(c==7)
            {
                while(al.get(2).equalsIgnoreCase("AFNCKXSY0001") || al.get(2).equalsIgnoreCase("BAFLKXAS0001"))
                {
                    noofRows1 = getRowCount("src//main//java//testData//TestData.xlsx", "Revamp_K8-9");
                    //getting a random row number 
                    Tcid = String.valueOf(randomNumber(1,noofRows1-1));
                    al = excelData.getData(Tcid, "Revamp_K8-9", "Tcid");
                }
            }
            
        }
        else if(stuUnit.equalsIgnoreCase("K10"))
        {
            noofRows1 = getRowCount("src//main//java//testData//TestData.xlsx", "Revamp_K10");
            //getting a random row number 
            Tcid = String.valueOf(randomNumber(1,noofRows1-1));
            al = excelData.getData(Tcid, "Revamp_K10", "Tcid");
        }
        else if(stuUnit.equalsIgnoreCase("K11-12"))
        {
            noofRows1 = getRowCount("src//main//java//testData//TestData.xlsx", "Revamp_K11-12");
            //getting a random row number 
            Tcid = String.valueOf(randomNumber(1,noofRows1-1));
            al = excelData.getData(Tcid, "Revamp_K11-12", "Tcid");
        }
        al = excelData.getData("13", "Revamp_K10", "Tcid");
        System.out.println(al);
        return al;
    }
    
    //@Author : Bhavana
    //Select status
    public void SelectStatus(String val) throws InterruptedException {
        
        visibleText(By.xpath("//div[text()='Student Program']/following::span[text()='Status']"));
        jsClick(driver.findElement(By.xpath("//div[text()='Student Program']/following::span[text()='Status']/following::button")));
        Thread.sleep(1000);
        jsClick(driver.findElement(By.xpath("//label[text()='Status']/following::button")));
        Thread.sleep(200);
        jsClick(driver.findElement(By.xpath("//label[text()='Status']/following::button/following::span[text()='"+val+"']")));
        Thread.sleep(200);
     }
    
    //@Author : Bhavana
    //Get all the student programs on account
    public List<String> getProgNames()
    {
      //span[text()='Student Program Name']/following::tr/th/span/a
        List<String> progNames = new ArrayList<String>();
        List<WebElement> ele = driver.findElements(By.xpath("//span[text()='Student Program Name']/following::tr/th//slot/span"));
        for(int i = 0;i<ele.size();i++)
        {
            progNames.add(ele.get(i).getText());
        }
        return progNames;
    }
    
    //@Author : Bhavana
    //Click on given student program
    public void clickStuProgName(String val) throws InterruptedException
    {
        Thread.sleep(1000);
        jsClick(driver.findElement(By.xpath("//span[text()='Student Program Name']/following::span[text()=\""+val+"\"]")));
        Thread.sleep(1000);
    }
    
    //@Author : Bhavana
    //get the primary program
    public String getPrimaryProgTcid(String prog1,String prog2,String prog3, String classNo) throws IOException
    {
        ExcelData excelData = new ExcelData();
        String primaryProgId = "";
        
        boolean p1,p2,p3;
        ArrayList<String> al1 = new ArrayList<String>();
        ArrayList<String> al2 = new ArrayList<String>();
        ArrayList<String> al3 = new ArrayList<String>();
        
        
        if(classNo.equalsIgnoreCase("7")){
             p1 = excelData.searchColData("TestData", "Revamp_Combinations_K7", "Id", prog1);
             p2 = excelData.searchColData("TestData", "Revamp_Combinations_K7", "Id", prog2);
             p3 = excelData.searchColData("TestData", "Revamp_Combinations_K7", "Id", prog3);
            
             al1 = excelData.getData(prog1, "Revamp_Combinations_K7", "Id");
             al2 = excelData.getData(prog2, "Revamp_Combinations_K7", "Id");
             al3 = excelData.getData(prog3, "Revamp_Combinations_K7", "Id");
        } 
        else {
             p1 = excelData.searchColData("TestData", "Revamp_Combinations", "Id", prog1);
             p2 = excelData.searchColData("TestData", "Revamp_Combinations", "Id", prog2);
             p3 = excelData.searchColData("TestData", "Revamp_Combinations", "Id", prog3);
            
             al1 = excelData.getData(prog1, "Revamp_Combinations", "Id");
             al2 = excelData.getData(prog2, "Revamp_Combinations", "Id");
             al3 = excelData.getData(prog3, "Revamp_Combinations", "Id");
        }
      
        //verify if the combinations are in excel
        if(p1 && p2 && p3)
        {
            if(Integer.valueOf(al1.get(1)) < Integer.valueOf(al2.get(1)) && Integer.valueOf(al1.get(1)) < Integer.valueOf(al3.get(3)))
            {
                primaryProgId = al1.get(3);
            }
            else if(Integer.valueOf(al2.get(1)) < Integer.valueOf(al3.get(1)) && Integer.valueOf(al2.get(1)) < Integer.valueOf(al1.get(1)))
            {
                primaryProgId = al2.get(3);
            }
            else 
            {
                primaryProgId = al3.get(3);
            }
        }
        else if(p1 && p2)
        {
            if(Integer.valueOf(al1.get(1)) < Integer.valueOf(al2.get(1)))
                primaryProgId = al1.get(3);
            else
                primaryProgId = al2.get(3);
        }
        else if(p2 && p3)
        {
            if(Integer.valueOf(al2.get(1)) < Integer.valueOf(al3.get(1)))
                primaryProgId = al2.get(3);
            else 
                primaryProgId = al3.get(3);
        }
        else if(p1 && p3)
        {
            if(Integer.valueOf(al1.get(1)) < Integer.valueOf(al3.get(1)))
                primaryProgId = al1.get(3);
            else 
                primaryProgId = al3.get(3);
        }
        else if(p1)
        {
            primaryProgId = al1.get(3);
        }
        else if(p2)
        {
            primaryProgId = al2.get(3);
        }
        else if(p3)
        {
            primaryProgId = al3.get(3);
        }
        
        return primaryProgId;
    }
    
    //@Author : Bhavana
    //To clone the student program
    public void selectClone() throws InterruptedException
    {
        Thread.sleep(2000);
        jsClick(driver.findElement(By.xpath("//div[text()='Student Program']/following::lightning-button-menu/button/lightning-primitive-icon")));
        Thread.sleep(500);
        jsClick(driver.findElement(By.xpath("//div[text()='Student Program']/following::a/span[text()='Clone']")));
        Thread.sleep(200);
    }
    
    //@Author : Bhavana
    //To clear the data when creating the student program
    //Student Program Name , Start Date , Student Enrolment ID
    public void clearData(String val) throws InterruptedException 
    {
        driver.findElement(By.xpath("//h2[text()='New Student Program']/following::label[text()='"+val+"']/following::input")).clear();
        Thread.sleep(200);
    }
    
    //@Author : Bhavana
    //To clear the program selection
    public void clearProgramSel() throws InterruptedException
    {
        jsClick(driver.findElement(By.xpath("//h2[text()='New Student Program']/following::label[text()='Program']/following::div/button")));
        Thread.sleep(200);
    }

    //@Author : Bhavana
    //To uncheck the primary program
    public void clearPrimaryProg() throws InterruptedException
    {
        jsClick(driver.findElement(By.xpath(" //h2[text()='New Student Program']/following::label/span[text()='Is Primary Program']/following::div/span/input")));
        Thread.sleep(200);
    }
    
    //@Author : Bhavana
    //To select a program on program selection
    public void SelectProgSel() throws InterruptedException
    {
        jsClick(driver.findElement(By.xpath("//a[text()='Program Name']/following::a")));
        Thread.sleep(200);
    }
  
    //Author : Bhavana
    //Select product type,Class/Program Type,Usage Mode
    public void SelectDropdownValues(String par,String val) throws InterruptedException 
    {
        visibleText(By.xpath("//label[text()='"+par+"']"));
        jsClick(driver.findElement(By.xpath("//label[text()='"+par+"']/following::button")));
        Thread.sleep(200);
        jsClick(driver.findElement(By.xpath("//label[text()='"+par+"']/following::button/following::span[text()='"+val+"']")));
        Thread.sleep(1000);
    }
    
    //@Author : Bhavana
    //Returns all the tcids with same prog Id
    public ArrayList<String> getTcids(String sheetName, String progId) throws IOException
    {
        ExcelData excelData = new ExcelData();
        ArrayList<String> tcids = new ArrayList<String>();
        ArrayList<String> al = new ArrayList<String>();
        
         //getting count of rows
        int noofRows = getRowCount("src//main//java//testData//TestData.xlsx", sheetName);
        for(int i=1;i<noofRows;i++)
        {
            al = excelData.getData(String.valueOf(i), sheetName, "Tcid");
            if(al.get(2).equalsIgnoreCase(progId))
                tcids.add(al.get(0));
            
        }
        
        return tcids;
    }
    
    //@Author : Bhavana
    // Returns the program combination if t is matching with the sheet
    public String getProgComb(ArrayList<String> tcids,String sheetName,String progId) throws IOException, InterruptedException
    {
        ExcelData excelData = new ExcelData();
        ArrayList<String> al = new ArrayList<String>();
        
        String prodType;
        String progType;
        String duration;
        String trialPgm;
        String usageMode="";
        String tcid = "";
        String comb = "";
        int i=0;
        
        while(i<tcids.size())
        {
            al = excelData.getData(tcids.get(i), sheetName, "Tcid");
            
            //To get the product type
            if(!al.get(18).equalsIgnoreCase("NA"))
                prodType = driver
                        .findElement(By.xpath("//div[text()='Student Program']/following::span[text()='Product Type']/following::span//lightning-formatted-text")).getText();
            else
                prodType = al.get(18);
            
            Thread.sleep(500);
            
            //To get program type
            if(!al.get(19).equalsIgnoreCase("NA"))
                progType = driver
                        .findElement(By.xpath("//div[text()='Student Program']/following::span[text()='Class/Program Type']/following::span//lightning-formatted-text")).getText();
            else
                progType = al.get(19);
            Thread.sleep(500);
            
            Scrollpagedown();
            
            //To get duration
            if(!al.get(20).equalsIgnoreCase("NA"))
                duration = driver
                        .findElement(By.xpath("//div[text()='Student Program']/following::span[text()='Duration']/following::span//lightning-formatted-text")).getText();
            else
                duration = al.get(20);
            Thread.sleep(500);
            
            //To get the trial prgm
            trialPgm = driver
                    .findElement(By.xpath("//div[text()='Student Program']/following::span[text()='Trial Program']/following::span//lightning-formatted-text")).getText();
            Thread.sleep(500);
            
            if(al.get(13).equalsIgnoreCase("K3"))
            {
              //To get the usage mode
                if(!al.get(21).equalsIgnoreCase("NA"))
                    usageMode = driver
                            .findElement(By.xpath("//div[text()='Student Program']/following::span[text()='Usage Mode']/following::span//lightning-formatted-text")).getText();
                else
                    usageMode = al.get(21);
            }
            
            if(al.get(13).equalsIgnoreCase("K3"))
            {
                if(al.get(18).equalsIgnoreCase(prodType) && al.get(19).equalsIgnoreCase(progType) && al.get(20).equalsIgnoreCase(duration) && trialPgm.equalsIgnoreCase(al.get(7)) && usageMode.equalsIgnoreCase(al.get(21)))
                {
                    tcid = al.get(0);
                    comb = progId+"-"+prodType+"-"+progType+"-"+duration+"-"+trialPgm+"-"+usageMode+"-"+al.get(13);
                    break;
                }
            }
            else
                if(al.get(18).equalsIgnoreCase(prodType) && al.get(19).equalsIgnoreCase(progType) && al.get(20).equalsIgnoreCase(duration) && trialPgm.equalsIgnoreCase(al.get(7)))
                {
                    tcid = al.get(0);
                    comb = progId+"-"+prodType+"-"+progType+"-"+duration+"-"+trialPgm+"-"+al.get(13);
                    break;
                }
            
            i++;
        }
        return comb;
    }
    
    //@Author : Bhavana
    //Return tcid for Task_Journey
    public String getTcid_TaskJour(ArrayList<String> tcids,ArrayList<String> al2) throws IOException, InterruptedException
    {
        ExcelData excelData = new ExcelData();
        ArrayList<String> al = new ArrayList<String>();
        
        String prodType;
        String progType;
        String duration;
        String trialPgm;
        String usageMode="";
        String tcid = "";
        int i=0;
        
        while(i<tcids.size())
        {
            al = excelData.getData(tcids.get(i), "Task_Journey", "Tcid");
            
            if(al.get(3).contains(al2.get(13)))
            {
              //To get program type
                if(!al.get(4).equalsIgnoreCase("NA"))
                    progType = driver
                            .findElement(By.xpath("//div[text()='Student Program']/following::span[text()='Class/Program Type']/following::lightning-formatted-text")).getText();
                else
                    progType = al.get(4);
                Thread.sleep(500);
                
                //To get the product type
                if(!al.get(6).equalsIgnoreCase("NA"))
                    prodType = driver
                            .findElement(By.xpath("//div[text()='Student Program']/following::span[text()='Product Type']/following::lightning-formatted-text")).getText();
                else
                    prodType = al.get(6);
                
                Thread.sleep(500);
                
                Scrollpagedown();
                
                //To get duration
                if(!al.get(5).equalsIgnoreCase("NA"))
                    duration = driver
                            .findElement(By.xpath("//span[text()='Duration']/following::div/span//lightning-formatted-text")).getText();
                else
                    duration = al.get(5);
                Thread.sleep(500);
                
               //To get the trial prgm
                trialPgm = driver
                        .findElement(By.xpath("//span[text()='Trial Program']/following::div/span//lightning-formatted-text")).getText();
                Thread.sleep(500);
                
                if(al2.get(13).equalsIgnoreCase("K3"))
                {
                  //To get the usage mode
                    if(!al.get(7).equalsIgnoreCase("NA"))
                        usageMode = driver
                                .findElement(By.xpath("//span[text()='Usage Mode']/following::div/span//lightning-formatted-text")).getText();
                    else
                        usageMode = al.get(7);
                }
                
                //compare and return tcid
                if(al2.get(13).equalsIgnoreCase("K3"))
                {
                    if(al.get(6).contains(prodType) && al.get(4).equalsIgnoreCase(progType) && al.get(5).contains(duration) && al.get(10).equalsIgnoreCase(trialPgm) && al.get(7).equalsIgnoreCase(usageMode))
                    {
                        tcid = al.get(0);
                        break;
                    }
                }
                else
                    if(al.get(6).contains(prodType) && al.get(4).equalsIgnoreCase(progType) && al.get(5).contains(duration) && al.get(10).equalsIgnoreCase(trialPgm))
                    {
                        tcid = al.get(0);
                        break;
                    }
            }
            
            i++;
        }
        return tcid;
    }
    
    //@Author : Bhavana
    // To get the created date in CDC Executor
    public String getCreatedDate(String sub)
    {
        //String createdDate = "5/25/2023, 6:31 PM";//driver.findElement(By.xpath("//span[text()='"+sub+"']/following::td[5]/span/span")).getText();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("h:mm a");
        List<WebElement> tasks = driver.findElements(By.xpath("//span[text()='"+sub+"']/following::td[5]/span/span"));
        ArrayList<String> DateTimes = new ArrayList<String>();
        int j=0;
        while(j<tasks.size())
        {
            DateTimes.add(tasks.get(j).getText());
            j++;
        }
        
        String dateTime1 = DateTimes.get(0);
        String[] check1 = dateTime1.split(",");
        String time1String = check1[1].trim();
        
        LocalTime time1 = LocalTime.parse(time1String, formatter); 
        String createdDate = tasks.get(0).getText();
        int i = 1;
        
        while(i < tasks.size())
        {
            String dateTime = DateTimes.get(i);
            String[] check = dateTime.split(",");
            String time2String = check[1].trim();
            LocalTime time2 = LocalTime.parse(time2String, formatter);
            
            if (time2.isAfter(time1)) {
              time1 = time2;
              createdDate = DateTimes.get(i);
          } 
            
            i++;
        }
       
        return createdDate;
    }
    
    //@Author : Bhavana
    //Get the order source
    public String getRandOrdSrc()
    {
        String[] list= {"Byjus India", "More Ideas"};
        String ordsrc = list[randomNumber(0,list.length)];
        
        return ordsrc;
    }
    
    public void enterOrdSrc(String name) throws InterruptedException
    {
        Thread.sleep(500);
        jsClick(driver.findElement(By.xpath("//div[text()='Student Sales Order']/following::span[text()='Order Source']/following::button")));
        Thread.sleep(500);
        jsClick(driver.findElement(By.xpath("//div[text()='Student Sales Order']/following::label[text()='Order Source']/following::button")));
        Thread.sleep(300);
        jsClick(driver.findElement(By.xpath("//div[text()='Student Sales Order']/following::label[text()='Order Source']/following::div/lightning-base-combobox-item/span/span[text()='"+name+"']")));
        ClickSave();
    }
    
    //@Author : Bhavana
    //Returns all the tcids with same prog Id
    public String getTcidRegion(String sheetName, String reg) throws IOException
    {
        ExcelData excelData = new ExcelData();
        String tcid = "";
        ArrayList<String> al = new ArrayList<String>();
        
         //getting count of rows
        int noofRows = getRowCount("src//main//java//testData//TestData.xlsx", sheetName);
        for(int i=1;i<noofRows;i++)
        {
            al = excelData.getData(String.valueOf(i), sheetName, "Tcid");
            if(al.get(8).equalsIgnoreCase(reg))
                tcid = al.get(0);
            
        }
        
        return tcid;
    }
    
    //**************************************************Saurabh Methods****************************************************
}
