package pageObjects;



import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.ui.ExpectedConditions;

import org.openqa.selenium.support.ui.WebDriverWait;


import resources.base;

public class Retention1stCallPO extends base {
	WebDriver driver;

	private String btnSavexpath = "//div/span[text()='Retention - First Call']/following::span[text()='Save']";
	
	// Declaring Constructor
	public Retention1stCallPO(WebDriver driver) {
		this.driver = driver;
	}
	
    //**************************************************Kalam Methods******************************************************

	
	//Author : Kalam
	//Select the First call status as Call Completed 
	public void EnterCompletedcall() throws InterruptedException {
		jsClick(driver.findElement(By.xpath("//div/span[text()='Retention - First Call']/following::span[text()='Call Status']/following::button")));
		Thread.sleep(800);
		driver.findElement(By.xpath("//div/span[text()='Retention - First Call']/following::span[text()='Call Status']/following::a[@class='select']")).click();
		Thread.sleep(800);
		driver.findElement(By.xpath("//div/span[text()='Retention - First Call']/following::span[text()='Call Status']/following::a[text()='Call Completed']")).click();
		Thread.sleep(800);
		
	}
    	
	//Author : Kalam
    public void jsClick(WebElement el) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor)driver;
            jse.executeScript("arguments[0].click();", el);
            System.out.println("Element clicked");
        } catch (Exception e){
            System.out.println("=============================================================");
            System.out.println("Exception-jsClick(): "+e.getMessage());
            takeScreenShot();
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }
	
	//Author : Kalam
    //Click Save button
	public void ClickSave() throws InterruptedException {
		driver.findElement(By.xpath(btnSavexpath)).click();
		Thread.sleep(4000);
	}
		
	//Author : Kalam
    public void clickButton(WebElement element)
    {
        WebDriverWait wait= new WebDriverWait(driver, 1000);
        
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));
        
        System.out.println("Element is clickable");
        element.click();
    }
    
    //**************************************************Manali Methods*****************************************************
    //**************************************************Manish Methods*****************************************************
    //**************************************************Anil Methods*******************************************************
    //**************************************************Amit Methods*******************************************************
    //**************************************************Sumit Methods******************************************************
    //**************************************************Bhavana Methods****************************************************
    //**************************************************Saurabh Methods****************************************************
}
