package pageObjects;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import resources.base;

public class FirstConnectPO extends base {
	WebDriver driver;

	private String lblFirstConnectCasexpath = "//div[text()='Related To']/following-sibling::div/span";
	private String btnCapturePxpath = "//div[text()='Capture Payment']";
	private String btnNoCallConnectxpath = "//div[text()='No Call Connect']";
	private String btnCompleteFCxpath = "//div[text()='Complete FC']";

	private String lblStatusxpath = "//div[text()='Status']/following-sibling::div/span";
	private String lblCallStatusxpath = "//div[text()='Call Status']/following-sibling::div/span";
	private String btnDropDownTabxpath = "//button[@title='Actions for First Connect']";
	private String lnkRefreshxpath = "//li[@title='Refresh Tab']/a";
	private String btnNoPaymntxpath = "//div[text()='No Payment']";
	private String btnNoPaymntLnkxpath = "//a[@title='No Payment']";
	private String lnkSystemInformation = "//h3[@class='slds-accordion__summary-heading']//span[@title='System Information']";
	private String txtLastModified = "//label[text()='Last Modified By']/following::div/span";
	private String txtPhone = "//input[@placeholder='Please enter only 10 digits']";
	private String btnNext = "//button[text()='Next']";
	private String txtComments = "//input[@class='slds-input'][@name='Comments']";
	private String callBackDatexpath = "//span[text()='Call Back Date']/following::input";
	private String txtReasonForDenial = "//div[text()='Reason For Denial']/following-sibling::div/span";
	private String drpdwnCxIssue = "//select[@class='slds-select']";
	private String editSupCallStatus = "//button[@type='button'][@title='Edit Status']";
	private String supStatus = "//span[@data-aura-class='uiPicklistLabel']/span[text()='Status']/following::div[@class='uiMenu']";
	private String supCallStatus = "//span[@data-aura-class='uiPicklistLabel']/span[text()='Call Status']/following::div[@class='uiMenu']";
	private String supStatusCompleted = "//span[@data-aura-class='uiPicklistLabel']/span[text()='Status']/following::a[text()='Completed']";
	private String supCalStatusIssueRsolevd = "//span[@data-aura-class='uiPicklistLabel']/span[text()='Call Status']/following::a[text()='Issue Resolved']";
	private String supComments = "//textarea[@role='textbox']";
	private String saveSupDetails = "//div[@class='button-container-inner slds-float_none']//span[@dir='ltr'][text()='Save']";
	private String txtSupStatusCompleted = "//div[@class='slds-form-element__control slds-grid itemBody']//span[text()='Completed']";
	private String txtCallStatusIssueResolved = "//div[@class='slds-form-element__control slds-grid itemBody']//span[text()='Issue Resolved']";

	// Declaring Constructor
	public FirstConnectPO(WebDriver driver) {
		this.driver = driver;
	}
	
	//**************************************************Kalam Methods******************************************************
 
	//@Author : Kalam
	// Capture the First connect Case id
	public String CaptureFCcaseid() throws InterruptedException {
		String Firstconnect_caseid = driver.findElement(By.xpath(lblFirstConnectCasexpath)).getText();
		Thread.sleep(2200);
		return Firstconnect_caseid;
	}

	//@Author : Kalam
	// Click on Capture Payment button
	public void ClickCapturePayment() throws InterruptedException {
		driver.findElement(By.xpath(btnCapturePxpath)).click();
		Thread.sleep(8000);
	}
	
	//@Author : Kalam
    // Click on No Payment button
    public void ClickNoPayment() throws InterruptedException {
        driver.findElement(By.xpath("//div[text()='No Payment']")).click();
        Thread.sleep(2000);
    }
    
 
    //@Author : Kalam
    // Select Call Status
    public void ClickCallStatus(String val) throws Exception {
        retryForDetachedFrame(driver, "//iframe[@title='accessibility title']", 0);
        WebElement frame = driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
        Thread.sleep(800);
        driver.switchTo().frame(frame);
        Thread.sleep(800);
        visibleText(By.xpath("//span[text()='Call Status']"));
        driver.findElement(By.xpath("//span[text()='Call Status']/following::span[text()='"+val+"']")).click();
        Thread.sleep(800);
    }
    
    //@Author : Kalam
    // Select Reason For Denial
    public void ClickReasonForDenial(String val) throws InterruptedException {
        visibleText(By.xpath("//span[text()='Reason For Denial']"));
        driver.findElement(By.xpath("//span[text()='Reason For Denial']/following::span[contains(text(),'"+val+"')]")).click();
        Thread.sleep(800);
        
    }
    
    //@Author : Kalam
    // Select Cx Issue
    public void SelectCXIssue(String val) throws InterruptedException {
       Select se = new Select(driver.findElement(By.xpath("//span[text()='Cx Issue']/following::select[@required]")));
       se.selectByVisibleText(val);
       Thread.sleep(200);
    }
    
    //@Author : Kalam
    // Enter Comments
    public void EnterComments(String val) throws InterruptedException {
       driver.findElement(By.xpath("//span[text()='Comments']/following::input[1]")).sendKeys(val);
       Thread.sleep(200);
    }
    
	//@Author : Kalam
	// Checking the status of First Connect
	public String CheckFCStatus() throws Exception {
		// retryForDetachedFrame(driver,"//iframe" , 0);
		// driver.switchTo().defaultContent();
		Thread.sleep(2000);
		try {
			Thread.sleep(1000);
			driver.get(driver.getCurrentUrl());
			Thread.sleep(2000);
			driver.findElement(By.xpath(lblStatusxpath)).click();

		} catch (WebDriverException e) {
		    driver.get(driver.getCurrentUrl());
			visibleText(By.xpath("//div[text()='Status']"));
			Thread.sleep(2000);
			clickButton(driver.findElement(By.xpath(lblStatusxpath)));
			// driver.get(driver.getCurrentUrl());
			// Thread.sleep(3000);
		} catch (Exception ee) {
			ee.printStackTrace();
			throw ee;
		}
		String Firstconnect_status = driver.findElement(By.xpath(lblStatusxpath)).getText();
		Thread.sleep(800);
		return Firstconnect_status;
	}

	//@Author : Kalam
	// Logout code
	public void Logout() throws InterruptedException {

		driver.findElement(By.xpath("//span[@class='uiImage']")).click();
		Thread.sleep(1200);
		driver.findElement(By.xpath("//a[text()='Log Out']")).click();
		Thread.sleep(1500);

	}

	//@Author : Kalam
	// Checking the status of Call Status
	public String CheckFCCallStatus() throws InterruptedException {
		String Firstconnect_callstatus = driver.findElement(By.xpath(lblCallStatusxpath)).getText();
		Thread.sleep(800);
		return Firstconnect_callstatus;
	}

	//@Author : Kalam
	// Checking if able to Complete FC with out Collection Manager approval
	public void ClickCompleteFC() throws InterruptedException {
		driver.findElement(By.xpath(btnCompleteFCxpath)).click();
		Thread.sleep(5000);
	}

	//@Author : Kalam
	// Refresh First Connect Screen
	public void RefreshFCScreen() throws Exception {
		int webDriverExceptionCounter = 0;
		while (webDriverExceptionCounter < 5) {
			try {
				driver.get(driver.getCurrentUrl());
				Thread.sleep(3000);
				driver.findElement(By.xpath(btnCompleteFCxpath)).click();
				break;
			} catch (final WebDriverException ex) {
				webDriverExceptionCounter++;
				if (webDriverExceptionCounter == 5) {
					log.error("WebDriverException, not trying again: {}", webDriverExceptionCounter);
					throw ex;
				} else {
					log.info("WebDriverException, retrying: {}", webDriverExceptionCounter);
					driver.get(driver.getCurrentUrl());
					Thread.sleep(3000);
					driver.findElement(By.xpath(btnCompleteFCxpath)).click();
				}
			} catch (final Exception e) {
				log.error("Exception: {}", e.getClass());
				throw e;
			}
		}
	}

	//@Author : Kalam
	// To refresh the FC tab for updated values
	public void RefreshTab() throws InterruptedException {
		try {
			Thread.sleep(1000);
			driver.findElement(By.xpath(btnDropDownTabxpath)).click();
			Thread.sleep(1000);
		} catch (WebDriverException e) {
			driver.findElement(By.xpath(btnDropDownTabxpath)).click();
			Thread.sleep(1000);
		} catch (Exception ee) {
			ee.printStackTrace();
			throw ee;
		}
		driver.findElement(By.xpath(lnkRefreshxpath)).click();
		Thread.sleep(1500);
	}

	//@Author : Kalam
	// To refresh the FC tab for updated values
	public void RefreshPage() throws InterruptedException {
		try {
			// Thread.sleep(1000);
			driver.get(driver.getCurrentUrl());
		} catch (WebDriverException e) {
			driver.get(driver.getCurrentUrl());
		} catch (Exception ee) {
			ee.printStackTrace();
			throw ee;
		}

		Thread.sleep(2500);
	}




	//@Author : Kalam
    public void jsClick(WebElement el) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor)driver;
            jse.executeScript("arguments[0].click();", el);
            System.out.println("Element clicked");
        } catch (Exception e){
            System.out.println("=============================================================");
            System.out.println("Exception-jsClick(): "+e.getMessage());
            takeScreenShot();
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }
    
	//@Author : Kalam
	// Verify No Call Connect Statuses @ manali shivareddy
	public String verifyCallStatuses(String val) throws Exception {
		retryForDetachedFrame(driver, "//iframe[@title='accessibility title']", 0);
		WebElement frame = driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
		Thread.sleep(800);
		driver.switchTo().frame(frame);
		Thread.sleep(800);
		String val1 = driver.findElement(By.xpath("//span[text()='" + val + "']")).getText();
		driver.switchTo().defaultContent();
		Thread.sleep(2000);
		return val1;
		
	}
	
	//@Author : Kalam
	public boolean visibleText(By element)
	{
		WebDriverWait wait= new WebDriverWait(driver, 20);
		
		wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));
		
		System.out.println("Element is visible");
		return false;
	}
	
	//@Author : Kalam
	public void clickButton(WebElement element)
	{
		WebDriverWait wait= new WebDriverWait(driver, 20);
		
		wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));
		
		System.out.println("Element is clickable");
		element.click();
	}
	
	//@Author : Kalam
	public void retryForDetachedFrame(final WebDriver driver, final String elementXpath, final int frameId) throws Exception {
        int webDriverExceptionCounter = 0;
        while (webDriverExceptionCounter < 5) {
            try {
                driver.findElement(By.xpath(elementXpath));
                break;
            } catch (final WebDriverException ex) {
                webDriverExceptionCounter++;
                if (webDriverExceptionCounter == 5) {
                   // log.error("WebDriverException, not trying again: {}", webDriverExceptionCounter);
                    throw ex;
                } else {
                   // log.info("WebDriverException, retrying: {}", webDriverExceptionCounter);
                    Thread.sleep(500);
                    final WebDriverWait wait = new WebDriverWait(driver, 15);
                    wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameId));
                }
            } catch (final Exception e) {
               // log.error("Exception: {}", e.getClass());
                throw e;
            }
        }
    }

	//@Author : Kalam
    // Enter call back date for ATCB
    public void enterCallBackDate() throws InterruptedException {
        DateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy");
        Date date = new Date();
        String date1 = dateFormat.format(date);
        
        driver.findElement(By.xpath(callBackDatexpath)).clear();
        Thread.sleep(800);
        driver.findElement(By.xpath(callBackDatexpath)).sendKeys(date1);
        Thread.sleep(1000);
        WebElement ele = driver.findElement(By.xpath("//input[@name='Call_Back_Date'][@role='combobox']"));
        ele.click();
        String[] Time = driver.findElement(By.xpath("//input[@name='Call_Back_Date'][@role='combobox']"))
                .getAttribute("value").split(":");
        int i = Integer.parseInt(Time[0]) + 1;
        String Atime = i + ":" + Time[1].replaceAll("AM", "PM");

        Actions action = new Actions(driver);
        /*
         * WebElement ele = driver.findElement(By.xpath(
         * "//input[@name='Call_Back_Date'][@role='combobox']")); ele.click();
         */
        ele.clear();

        action.keyDown(Keys.CONTROL).sendKeys("A").keyUp(Keys.CONTROL).sendKeys(Atime).build().perform();
        Thread.sleep(800);

        Thread.sleep(500);
    }

    //@Author : Kalam
    // Enter call back date for No Payment - Intent to Pay
    public void enterCallBackDateNoPayment() throws InterruptedException {
        DateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy");
        Date date = new Date();
        String date1 = dateFormat.format(date);

        driver.findElement(By.xpath(callBackDatexpath)).clear();
        Thread.sleep(800);
        driver.findElement(By.xpath(callBackDatexpath)).sendKeys(date1);
        Thread.sleep(1000);
        WebElement ele = driver.findElement(By.xpath("//input[@name='Call_Back_Date_New'][@role='combobox']"));
        ele.click();
        String[] Time = driver.findElement(By.xpath("//input[@name='Call_Back_Date_New'][@role='combobox']"))
                .getAttribute("value").split(":");
        int i = Integer.parseInt(Time[0]) + 1;
        String Atime = i + ":" + Time[1].replaceAll("AM", "PM");

        Actions action = new Actions(driver);
        /*
         * WebElement ele = driver.findElement(By.xpath(
         * "//input[@name='Call_Back_Date'][@role='combobox']")); ele.click();
         */
        ele.clear();

        action.keyDown(Keys.CONTROL).sendKeys("A").keyUp(Keys.CONTROL).sendKeys(Atime).build().perform();
        Thread.sleep(800);

        Thread.sleep(500);
    }

    //@Author : Kalam
    // Providing Rating to the user for ATCB flow
    public void EnterRating() throws Exception {

        /*
         * retryForDetachedFrame(driver,
         * "//div[@class='oneAlohaPage']//iframe[@title='accessibility title']", 0);
         * WebElement frame = driver .findElement(By.
         * xpath("//div[@class='oneAlohaPage']//iframe[@title='accessibility title']"));
         * Thread.sleep(800); driver.switchTo().frame(frame);
         */

        visibleText(By.xpath("//span[text()='Customer Rating Service']"));
        driver.findElement(By.xpath("//label[@title='4']")).click();
        Thread.sleep(1000);
    }

    //@Author : Kalam
    // Switch to the frame
    public void switchToTheFrame() throws Exception {
        retryForDetachedFrame(driver, "//iframe[@title='accessibility title']", 0);
        WebElement frame = driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
        Thread.sleep(800);
        driver.switchTo().frame(frame);
        Thread.sleep(800);
    }
	//**************************************************Manali Methods*****************************************************


	
	// Radio button check @ manali shivareddy
	public Boolean verifyRadioBtn(String val) throws Exception {
		retryForDetachedFrame(driver, "//iframe[@title='accessibility title']", 0);
		WebElement frame = driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
		Thread.sleep(800);
		driver.switchTo().frame(frame);
		Thread.sleep(800);
		Boolean value = driver.findElement(By.xpath("//span[text()='" + val + "']")).isDisplayed();
		driver.findElement(By.xpath("//span[text()='" + val + "']")).click();
		if (val == "No Payment") {
			Assert.assertTrue(driver.findElement(By.xpath("//span[text()='Facing Issues-BYJUS']")).isEnabled(),
					"Facing Issues-BYJUS radio button is not selected");
		}
		driver.switchTo().defaultContent();
		Thread.sleep(2000);
		return value;
	}

	// Verify No Payment button @ manali shivareddy
	public String verifyNoPaymntBtn() throws InterruptedException {
		String val = driver.findElement(By.xpath(btnNoPaymntxpath)).getText();
		return val;
	}

	// Click on No Payment button @ manali shivareddy
	public void clickNoPaymntBtn() throws InterruptedException {
		jsClick(driver.findElement(By.xpath(btnNoPaymntLnkxpath)));
		Thread.sleep(2000);
	}

	// Click on System Information button @ manali shivareddy
	public void clickSysInfoBtn() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,650);");
		driver.findElement(By.xpath(lnkSystemInformation)).click();
	}

	// to get Last Modified PtpDateTime @ manali shivareddy
	public String getLastModifiedPtpDateTime(String CurrURL) throws InterruptedException {
		String date2 = null;
		String part4;
		String val = driver.findElement(By.xpath(txtLastModified)).getText();// ameena banu 9/30/2022, 10:58 AM
		String[] parts = val.split("[, ]+");
		if(CurrURL.contains("--byjusuat")) {
		    part4 = parts[3];// 10:58 10/3/2022
		}else {
		    part4 = parts[2];
		}
		
		String[] date = part4.split("/");
		String date1 = date[1];
		String month = date[0];
		String year = date[2];
		if (Integer.parseInt(date1) <= 9) {
			date2 = "0" + date1;

		} else {
			date2 = date1;
		}
		if (Integer.parseInt(month) <= 9) {
		    month = "0" + month;
        } 
		String result = year + "-" + month + "-" + date2;

		return result;
	}

	// Click on 'No Call Connect' options @ manali shivareddy
	public void clickNoCallConnect(String val) throws Exception {
		retryForDetachedFrame(driver, "//iframe[@title='accessibility title']", 0);
		WebElement frame = driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
		Thread.sleep(800);
		driver.switchTo().frame(frame);
		Thread.sleep(800);
		driver.findElement(By.xpath("//span[text()='" + val + "']")).click();
		// driver.switchTo().defaultContent();
		Thread.sleep(2000);
	}

	// Enter phone number @ manali shivareddy
	public void enterPhone() throws InterruptedException {
		driver.findElement(By.xpath(txtPhone)).sendKeys("1234567890");
		Thread.sleep(1000);
	}

	// Enter Comments @ manali shivareddy
	public void enterComments() throws InterruptedException {
		driver.findElement(By.xpath(txtComments)).sendKeys("Entering Test Comments");
		Thread.sleep(1000);
	}

	// Click next @ manali shivareddy
	public void clickNext() throws InterruptedException {
		driver.findElement(By.xpath(btnNext)).click();
		Thread.sleep(1000);
	}

	// Click next and go to default frame @ manali shivareddy
	public void clickNextSwitchDefault() throws InterruptedException {
		driver.findElement(By.xpath(btnNext)).click();
		Thread.sleep(1000);
		driver.switchTo().defaultContent();
		Thread.sleep(3000);
	}

	
	

	// Radio button check @ manali shivareddy
	public void clickNoPayment(String val) throws Exception {
		driver.findElement(By.xpath("//span[text()='" + val + "']")).click();
		Thread.sleep(800);
	}

	// Checking 'Reason For Denial' @ manali shivareddy
	public String CheckReasonForDenial() throws InterruptedException {
		String ReasonForDenial = driver.findElement(By.xpath(txtReasonForDenial)).getText();
		Thread.sleep(800);
		return ReasonForDenial;
	}

	// Select Cx issue @ manali shivareddy
	public void SelectCxIssue(String val) throws InterruptedException {
		Select se = new Select(driver.findElement(By.xpath(drpdwnCxIssue)));
		se.selectByVisibleText(val);
		Thread.sleep(800);
	}

	// Complete Sup Call task @ manali shivareddy
	public void saveSupCallDue() throws InterruptedException {
		driver.findElement(By.xpath(editSupCallStatus)).click();
		// Select the status value
		driver.findElement(By.xpath(supStatus)).click();
		Thread.sleep(800);
		WebElement status = driver.findElement(By.xpath(supStatusCompleted));
		status.click();
		// select call status
		driver.findElement(By.xpath(supCallStatus)).click();
		WebElement issueResolved = driver.findElement(By.xpath(supCalStatusIssueRsolevd));
		issueResolved.click();
		driver.findElement(By.xpath(supComments)).sendKeys("Entering Comments");
		driver.findElement(By.xpath(saveSupDetails)).click();
		Thread.sleep(5000);
	}

	// Verify Sup Call status @ manali shivareddy
	public String[] getSupTaskStatus() {
		String status = driver.findElement(By.xpath(txtSupStatusCompleted)).getText();
		String callStatus = driver.findElement(By.xpath(txtCallStatusIssueResolved)).getText();
		return new String[] { status, callStatus };
	}

	   // Verify No Call Connect button @ manali shivareddy
    public String verifyNoCallConnectBtn() throws InterruptedException {
        String val = driver.findElement(By.xpath(btnNoCallConnectxpath)).getText();
        return val;
    }


    // Click on No Call Connect button @ manali shivareddy
    public void clickNoCallConnectBtn() throws InterruptedException {
        Thread.sleep(1000);
        driver.get(driver.getCurrentUrl());
        Thread.sleep(2000);
        jsClick(driver.findElement(By.xpath(btnNoCallConnectxpath)));
        Thread.sleep(2500);
    }
    
  //@Author : Manali Shivareddy
    // Enter call back date for ATCB , only on prod
    public void enterCallBackDateProd() throws InterruptedException {
        DateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy");
        Date date = new Date();
        String date1 = dateFormat.format(date);

        String[] newDate = date1.split("[\\s,]+");
        String newdate1 = newDate[1] + "-" + newDate[0] + "-" + newDate[2];
        
        driver.findElement(By.xpath(callBackDatexpath)).clear();
        Thread.sleep(800);
        driver.findElement(By.xpath(callBackDatexpath)).sendKeys(newdate1);
        Thread.sleep(1000);
        WebElement ele = driver.findElement(By.xpath("//input[@name='Call_Back_Date'][@role='combobox']"));
        ele.click();
        String[] Time = driver.findElement(By.xpath("//input[@name='Call_Back_Date'][@role='combobox']"))
                .getAttribute("value").split(":");
        int i = Integer.parseInt(Time[0]) + 1;
        String Atime = i + ":" + Time[1].replaceAll("AM", "PM");

        Actions action = new Actions(driver);
        /*
         * WebElement ele = driver.findElement(By.xpath(
         * "//input[@name='Call_Back_Date'][@role='combobox']")); ele.click();
         */
        ele.clear();

        action.keyDown(Keys.CONTROL).sendKeys("A").keyUp(Keys.CONTROL).sendKeys(Atime).build().perform();
        Thread.sleep(800);

        Thread.sleep(500);
    }

    //@Author : Manali Shivareddy
    // Enter call back date for No Payment - Intent to Pay only on prod
    public void enterCallBackDateNoPaymentProd() throws InterruptedException {
        DateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy");
        Date date = new Date();
        String date1 = dateFormat.format(date);
        
        String[] newDate = date1.split("[\\s,]+");
        String newdate1 = newDate[1] + "-" + newDate[0] + "-" + newDate[2];

        driver.findElement(By.xpath(callBackDatexpath)).clear();
        Thread.sleep(800);
        driver.findElement(By.xpath(callBackDatexpath)).sendKeys(newdate1);
        Thread.sleep(1000);
        WebElement ele = driver.findElement(By.xpath("//input[@name='Call_Back_Date_New'][@role='combobox']"));
        ele.click();
        String[] Time = driver.findElement(By.xpath("//input[@name='Call_Back_Date_New'][@role='combobox']"))
                .getAttribute("value").split(":");
        int i = Integer.parseInt(Time[0]) + 1;
        String Atime = i + ":" + Time[1].replaceAll("AM", "PM");

        Actions action = new Actions(driver);
        ele.clear();

        action.keyDown(Keys.CONTROL).sendKeys("A").keyUp(Keys.CONTROL).sendKeys(Atime).build().perform();
        Thread.sleep(800);

        Thread.sleep(500);
    }
	
    //**************************************************Manish Methods*****************************************************
    //**************************************************Anil Methods*******************************************************
    //**************************************************Amit Methods*******************************************************
    //**************************************************Sumit Methods******************************************************
    //**************************************************Bhavana Methods****************************************************
	
	//@Author : Bhavana
	//To refresh the page to get complete FC button
	public void ClickCompleteFC_Refresh() throws InterruptedException {
	    while(!isDisplayed(By.xpath(btnCompleteFCxpath)))
	    {
	        driver.get(driver.getCurrentUrl());
	        Thread.sleep(2000);
	    }
	    ClickCompleteFC();
	}
	
	//@Author : Bhavana
	//To check if element is displayed (From base)
	public boolean isDisplayed(By element) {
        List<WebElement> list = driver.findElements(element);
        //System.out.println(list.toString());
        boolean value = false;
        if (!list.isEmpty()) {
            if (list.get(0).isDisplayed()) {
                value = true;
                return value;
            }
        } else {

            return value;
        }
        return value;
    }
    
	//**************************************************Saurabh Methods****************************************************
}
