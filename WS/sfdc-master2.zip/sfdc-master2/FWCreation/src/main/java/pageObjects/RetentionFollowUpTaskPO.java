package pageObjects;



import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


import resources.base;

public class RetentionFollowUpTaskPO extends base {
	WebDriver driver;

	private String btnSavexpath = "//div/span[text()='Retention - First Call']/following::span[text()='Save']";
	
	// Declaring Constructor
	public RetentionFollowUpTaskPO(WebDriver driver) {
		this.driver = driver;
	}
	
	//**************************************************Kalam Methods******************************************************

	
	
	//Author : Kalam
	//Click on Capture detail button
	public void ClickCaptureDetail() throws InterruptedException {
  jsClick(driver.findElement(By.xpath("//div[text()='Capture Call Details']")));
  Thread.sleep(3000);
	}
	
	//Author : Kalam
	//Select Proceed as option
	public void SelectProceed() throws InterruptedException {
		visibleText(By.xpath("//lightning-formatted-rich-text/span[text()='Proceed']"));
        driver.findElement(By.xpath("//lightning-formatted-rich-text/span[text()='Proceed']")).click();
        Thread.sleep(200);
        driver.findElement(By.xpath("//button[text()='Next']")).click();
        Thread.sleep(2000);
	}
	
	//Author : Kalam
	//Select Proceed as option
	public void SelectProceed_iframe() throws Exception {
		retryForDetachedFrame(driver, "//iframe", 0);
		WebElement frame1=driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
		Thread.sleep(800);
		driver.switchTo().frame(frame1);
		visibleText(By.xpath("//lightning-formatted-rich-text/span[text()='Proceed']"));
		driver.findElement(By.xpath("//lightning-formatted-rich-text/span[text()='Proceed']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//button[text()='Next']")).click();
		Thread.sleep(1000);
	}
	
	//Author : Kalam
	//Select value for Proceed - Spoke To
	//public void SelectProceedST(String val) throws InterruptedException {
		//visibleText(By.xpath("//article/following::lightning-formatted-rich-text/span[text()='Spoke To']"));
		//Thread.sleep(200);
		//Select sel = new Select(driver.findElement(By.xpath("//article/following::lightning-formatted-rich-text/span[text()='Spoke To']/following::select[@required]")));
		//sel.selectByVisibleText(val);
		//Thread.sleep(200);
	//}
	
	//Author : Kalam
	//Select value for Proceed - Spoke To
	public void SelectProceedST(String val) throws InterruptedException {
		Select sel = new Select(driver.findElement(By.xpath("//flowruntime-picklist-input-lwc/div/div/lightning-formatted-rich-text/span[text()='Spoke To']/following::select")));
		sel.selectByVisibleText(val);
		Thread.sleep(300);
	}
	
	//Author : Kalam
	//Select value for Proceed - Discussed Dashboard
	public void SelectDiscussedDashboard(String val) throws InterruptedException {
		Select sel = new Select(driver.findElement(By.xpath("//flowruntime-picklist-input-lwc/div/div/lightning-formatted-rich-text/span[text()='Discussed Dashboard']/following::select[@required]")));
		sel.selectByVisibleText(val);
		Thread.sleep(200);
	}
    
	//Author : Kalam
	//Select value for Proceed - Is There Any Issue?
	public void SelectProceedIsThereIssue(String val) throws InterruptedException {
		visibleText(By.xpath("//span[text()='Is There Any Issue?']"));
		Select sel = new Select(driver.findElement(By.xpath("//span[text()='Is There Any Issue?']/following::select")));
		sel.selectByVisibleText(val);
		Thread.sleep(300);		
	}
	
	//Author : Kalam
	//Click Next
	public void ClickNext() throws InterruptedException {
		 driver.findElement(By.xpath("//button[text()='Next']")).click();
		  Thread.sleep(2000);
	}
	
	//Author : Kalam
    //Click Save button
	public void ClickSave() throws InterruptedException {
		driver.findElement(By.xpath(btnSavexpath)).click();
		Thread.sleep(4000);
	}
	
	//Author : Kalam
	public boolean visibleText(By element)
	{
		WebDriverWait wait= new WebDriverWait(driver, 10000);
		
		wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));
		
		System.out.println("Element is visible");
		return false;
	}
	
	//Author : Kalam
    public void jsClick(WebElement el) {
		try {
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("arguments[0].click();", el);
			System.out.println("Element clicked");
		} catch (Exception e){
			System.out.println("=============================================================");
			System.out.println("Exception-jsClick(): "+e.getMessage());
			takeScreenShot();
			e.printStackTrace();
			System.out.println("=============================================================");
		}
	}
    
    //**************************************************Manali Methods*****************************************************
    //**************************************************Manish Methods*****************************************************
    //**************************************************Anil Methods*******************************************************
    //**************************************************Amit Methods*******************************************************
    //**************************************************Sumit Methods******************************************************
    //**************************************************Bhavana Methods****************************************************
    //**************************************************Saurabh Methods****************************************************
}
