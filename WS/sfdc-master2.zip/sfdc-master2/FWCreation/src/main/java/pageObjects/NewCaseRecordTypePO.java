package pageObjects;



import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import resources.base;

public class NewCaseRecordTypePO extends base {
	WebDriver driver;

	
	private String btnNextxpath = "//span[text()='Next']";
	//private String btnSavexpath = "//span[text()='Save']";
	

	// Declaring Constructor
	public NewCaseRecordTypePO(WebDriver driver) {
		this.driver = driver;
	}
	
	//**************************************************Kalam Methods******************************************************


	//@Author : Kalam
	//Click on New Case Button
	public void SelectCaseRecordType(String val) throws InterruptedException {
	Thread.sleep(1000);
	WebElement ele = driver.findElement(By.xpath("//span[text()='"+val+"']")); 
	scrollIntoView(ele);
	ele.click();
	Thread.sleep(800);
	}
	
	//@Author : Kalam
	//Click Next button
	public void ClickNext() throws InterruptedException {
	driver.findElement(By.xpath(btnNextxpath)).click();
	Thread.sleep(2000);
	
	}
	
	//@Author : Kalam
	//Click Save button
	public void ClickRetentionSave() throws InterruptedException {
	driver.findElement(By.xpath("//h2[text()='New Task: Retention Initial Call']/following::span[text()='Save']")).click();
	Thread.sleep(2000);
	
	}

	//@Author : Kalam
	//Click Save button
	public void ClickSave() throws InterruptedException {
	visibleText(By.xpath("//h2[contains(text(),'New Task:')]/following::span[text()='Save']"));
	jsClick(driver.findElement(By.xpath("//h2[contains(text(),'New Task:')]/following::span[text()='Save']")));
	Thread.sleep(2000);
	}
	
	//@Author : Kalam
	//Click Save button
	public void EnterSubject(String val) throws InterruptedException {
	visibleText(By.xpath("//h2[contains(text(),'New Task:')]/following::*[text()='Subject']"));
	driver.findElement(By.xpath("//h2[contains(text(),'New Task:')]/following::*[text()='Subject']/following::input")).sendKeys(val);
	Thread.sleep(200);
	}
	
	//@Author : Kalam
	//Select Action Type
	public void SelectActionType(String val) throws InterruptedException {
	    driver.findElement(By.xpath("//h2[contains(text(),'New Task:')]/following::*[text()='Action Type']/following::a")).click();
	    Thread.sleep(200);
	    driver.findElement(By.xpath("//h2[contains(text(),'New Task:')]/following::*[text()='Action Type']/following::a[@title='"+val+"']")).click();
	    Thread.sleep(200);
	}
	
	//@Author : Kalam
	//Click Save button
	public void EnterCallBackNumber() throws InterruptedException {
		visibleText(By.xpath("//span[text()='Call Back Number']"));
		driver.findElement(By.xpath("//span[text()='Call Back Number']/following::button")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[text()='Task']/following::label/span[text()='Call Back Number']/following::input")).sendKeys("1122334455");
		driver.findElement(By.xpath("//div[text()='Task']/following::span[text()='Save']")).click();
		Thread.sleep(1000);
	
	}
	
	//@Author : Kalam
	//Click on New Case Button and select Inbound option
	public void SelectCaseRecordTypeInbound() throws InterruptedException {	
	WebElement ele = driver.findElement(By.xpath("//span[text()='Inbound']")); 
	scrollIntoView(ele);
	ele.click();
	Thread.sleep(500);
	}

	//@Author : Kalam
	//Click on New Case Button and select Inbound option
	public void SelectTaskRecordType(String val) throws InterruptedException {	
	WebElement ele = driver.findElement(By.xpath("//h2[text()='New Task']/following::span[text()='"+val+"']")); 
	scrollIntoView(ele);
	ele.click();
	Thread.sleep(500);
	}
	
	//@Author : Kalam
	//Click on New Case Button and select Retention Initial Call option
	public void SelectCaseRecdTypeRetenInitialCall() throws InterruptedException {	
	WebElement ele = driver.findElement(By.xpath("//span[text()='Retention Initial Call']")); 
	scrollIntoView(ele);
	ele.click();
	Thread.sleep(800);
	}
	
	//@Author : Kalam
	//Click on New Case Button and select SDC option
	public void SelectCaseRecordTypeSDC() throws InterruptedException {	
	WebElement ele = driver.findElement(By.xpath("//span[text()='SDC Task']")); 
	scrollIntoView(ele);
	ele.click();
	Thread.sleep(800);
	}
	
	//@Author : Kalam
	//Click on New Case Button and select Retention Refund Request option
	public void SelectCaseRecordTypeRRR() throws InterruptedException {	
	WebElement ele = driver.findElement(By.xpath("//span[text()='Retention Refund Request']")); 
	scrollIntoView(ele);
	ele.click();
	Thread.sleep(800);
	}
	
	//@Author : Kalam
	//Select Case status as Closed
	public void SelectCaseStatusClosed() throws InterruptedException {
		driver.findElement(By.xpath("//span/span[text()='Status']/following::a | //label[text()='Status']/following::button[1]")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath("//span/span[text()='Status']/following::a[text()='Closed'] | //label[text()='Status']/following::span[text()='Closed']")).click();
		Thread.sleep(800);
	}
	
	//Enter Subject details
	//public void EnterSubject(String val) throws InterruptedException {
	//	driver.findElement(By.xpath("//span[text()='Subject']/following::input")).sendKeys(val);
	//	Thread.sleep(800);
	
	//}

	//@Author : Kalam
	//Enter Subject details for SDC
	public void EnterSubject_SDC(String val) throws InterruptedException {
	    visibleText(By.xpath("//label[text()='Subject']"));
		driver.findElement(By.xpath("//label[text()='Subject']/following::input")).sendKeys(val);
		Thread.sleep(800);
		driver.findElement(By.xpath("//h2[text()='New Task: SDC Task']/following::span[text()='Save']")).click();
		Thread.sleep(2000);
	
	}
	
	//@Author : Kalam
	//Enter Order details
	public void EnterOrder(String val) throws InterruptedException {
		driver.findElement(By.xpath("//span[text()='Orders']/following::input")).sendKeys(val);
		Thread.sleep(800);
	
	}
	
	//@Author : Kalam
	//Enter Value for Reason For Refund
	public void EnterResnFrRefnd(String val) throws InterruptedException {
		WebElement ele = driver.findElement(By.xpath("//div[text()='Reason For Refund']/following::span[text()='"+val+"']"));
		scrollIntoView(ele);
		ele.click();
		Thread.sleep(800);
		driver.findElement(By.xpath("//div[text()='Reason For Refund']/following::lightning-primitive-icon")).click();
		Thread.sleep(800);
	
	}	
	
	//@Author : Kalam
	// Scroll element to view
	public void scrollIntoView(WebElement element) {
		try {
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("arguments[0].scrollIntoView(true);", element);
			System.out.println("Page scrolled down");
		} catch (Exception e){
			System.out.println("=============================================================");
			System.out.println("Exception-scrollIntoView(): "+e.getMessage());
			takeScreenShot();
			e.printStackTrace();
			System.out.println("=============================================================");
		}    
	}
	
	//@Author : Kalam
	public boolean visibleText(By element)
	{
		WebDriverWait wait= new WebDriverWait(driver, 100);
		
		wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));
		
		System.out.println("Element is visible");
		return false;
	}
	
  //@Author : Kalam
  //Click Next button
    public void ClickNextButton() throws InterruptedException {
    driver.findElement(By.xpath("//button[text()='Next']")).click();
    Thread.sleep(2000);
    
    }
    
    //**************************************************Manish Methods*****************************************************
	
	// This method enters the Subject for inboud task
	//Author :: Manish
	public void CreatingRefundCallingTask(String subject,String user) throws InterruptedException
	{
	    //WebElement e=driver.findElement(By.xpath("//label[contains(text(),'Subject')]/following::input"));
        /*
         * e.sendKeys(Keys.CONTROL+"a");
         * e.sendKeys(Keys.DELETE);
         */
	    //this.driver=driver;
	    Thread.sleep(4000);
	    driver.findElement(By.xpath("//label[contains(text(),'Subject')]/following::input")).sendKeys(Keys.chord(Keys.CONTROL,"a),"+subject+""));
	    //driver.findElement(By.xpath("//label[contains(text(),'Subject')]/following::input")).sendKeys(Keys.chord(Keys.CONTROL,"a"));
	    //driver.findElement(By.xpath("//label[contains(text(),'Subject')]/following::input")).sendKeys(Keys.ENTER);
	    driver.findElement(By.xpath("//label[contains(text(),'Subject')]/following::input")).sendKeys(subject);
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//label/span[text()='Assigned To']/following::a/span[@class='pillIcon']/following::a/span[@class='deleteIcon']")).click();
	    driver.findElement(By.xpath("//label/span[text()='Assigned To']/following::input[@placeholder]")).sendKeys(user);
	    Thread.sleep(3000);
	    driver.findElement(By.xpath("//div[@title='"+user+"']")).click();
	    Thread.sleep(4500);
	    driver.findElement(tag).sendKeys(Keys.PAGE_DOWN);
        Thread.sleep(1200);
	    //Scrollpagedown();
	   // Scrollpagedown();
	    driver.findElement(By.xpath("//span[text()='Call Back Number']/following::input")).sendKeys("1234567890");
	}
	
	//Click on New Case Button and select Unregisted customer option
	//Author ::Manish
    public void UCDetailsCapture() throws InterruptedException { 
    WebElement ele = driver.findElement(By.xpath("//span[text()='Unregistered Customers Detail Capture']")); 
    scrollIntoView(ele);
    ele.click();
    Thread.sleep(500);
}
    

    
    //**************************************************Manali Methods*****************************************************
    //**************************************************Anil Methods*******************************************************
    //**************************************************Amit Methods*******************************************************
    //**************************************************Sumit Methods******************************************************
    //**************************************************Bhavana Methods****************************************************
    
    //@Author : Bhavana
    //Click Save button
    public void ClickSavenNew() throws InterruptedException {
    driver.findElement(By.xpath("//h2[contains(text(),'New Task:')]/following::span[text()='Save & New']")).click();
    Thread.sleep(2000);
    }
    
    public void jsClick(WebElement el) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor)driver;
            jse.executeScript("arguments[0].click();", el);
            System.out.println("Element clicked");
        } catch (Exception e){
            System.out.println("=============================================================");
            System.out.println("Exception-jsClick(): "+e.getMessage());
            takeScreenShot();
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }
  
    //@Author :: Bhavana
    // Navigate to Open Activity History section and click on the mentioned open task
    public void ClickCreatedTaskActivityHistory(String val) throws InterruptedException {
        
        Scrollpagedown();
        Scrollpagedown();
        Thread.sleep(3000);
        Scrollpagedown();
        Scrollend();
        WebElement ele1 =  driver.findElement(By.xpath("//div[text()= 'Case']/following::span[text()= 'Activity History']/following::article//a[@data-refid][text()='"+val+"']"));
       // scrollIntoView(ele1);
        //Thread.sleep(800);
        Actions ac= new Actions(driver);
        ac.moveToElement(ele1).build().perform();
        Thread.sleep(2000);
        jsClick(ele1);
        Thread.sleep(800);
    }

    //@Author : Bhavana
    //To get the status of Information Task
    public String CaptureStatusofIT() throws InterruptedException {
        
        String status = driver.findElement(By.xpath("//div/span[text()='Information Task']/following::span[text()= 'Status']/following::span/span")).getText();
        return status;
        
    }
    
    public void Scrollpagedown() throws InterruptedException {

        driver.findElement(tag).sendKeys(Keys.PAGE_DOWN);
        Thread.sleep(1200);
    }
    
    public void Scrollend() throws InterruptedException {

        driver.findElement(tag).sendKeys(Keys.END);
        Thread.sleep(1200);
    }
    
    
    //@Author : Bhavana
    //Click Save button
    public void ClickSave1() throws InterruptedException {
    visibleText(By.xpath("//h2[contains(text(),'New Task:')]/following::span[text()='Save']"));
    driver.findElement(By.xpath("//h2[contains(text(),'New Task:')]/following::span[text()='Save']")).click();
    Thread.sleep(2000);
    }
    //**************************************************Saurabh Methods****************************************************
}
