package pageObjects;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


import resources.ExcelData;
import resources.base;

public class NewPaymentPO extends base {
	WebDriver driver;
	ExcelData excelData = new ExcelData();
	ArrayList<String> al = new ArrayList<String>();
	
	private String btnNextxpath = "//span[text()='Next']";
	

	// Declaring Constructor
	public NewPaymentPO(WebDriver driver) {
		this.driver = driver;
	}

	//**************************************************Kalam Methods******************************************************
	
	//@Author : Kalam
	//Selecting Payment option for New payment
	public void SelectPaymentOptn(String Paymenttype) throws InterruptedException {
		jsClick(driver.findElement(By.xpath("//span[text()='"+Paymenttype+"']")));
		Thread.sleep(500);
	}
	
	//@Author : Kalam
	//Next button click
	public void ClickNext() throws InterruptedException {
		jsClick(driver.findElement(By.xpath(btnNextxpath)));
		Thread.sleep(2000);
	}

	//@Author : Kalam
	 public void jsClick(WebElement el) {
			try {
				JavascriptExecutor jse = (JavascriptExecutor)driver;
				jse.executeScript("arguments[0].click();", el);
				System.out.println("Element clicked");
			} catch (Exception e){
				System.out.println("=============================================================");
				System.out.println("Exception-jsClick(): "+e.getMessage());
				takeScreenShot();
				e.printStackTrace();
				System.out.println("=============================================================");
			}
		}
	 
	    //**************************************************Manali Methods*****************************************************
	    //**************************************************Manish Methods*****************************************************
	    //**************************************************Anil Methods*******************************************************
	    //**************************************************Amit Methods*******************************************************
	    //**************************************************Sumit Methods******************************************************
	    //**************************************************Bhavana Methods****************************************************
	    //**************************************************Saurabh Methods****************************************************
}
