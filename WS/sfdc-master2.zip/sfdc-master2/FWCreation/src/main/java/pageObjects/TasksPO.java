package pageObjects;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.Calendar;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import resources.base;


public class TasksPO extends base {
	WebDriver driver;

	// private String btnNavMenuxpath =

	// Declaring Constructor
	public TasksPO(WebDriver driver) {
		this.driver = driver;
	}

	//**************************************************Kalam Methods******************************************************

	
	//Author : Kalam
	// Navigate to main Task Screen
	public void TaskScreen() throws InterruptedException {
		// driver.findElement(By.xpath("//span[@class='slds-truncate'][text()='Tasks']")).click();
		// Thread.sleep(2000);
		WebElement ele = driver.findElement(By.xpath(
				"//lightning-icon[@class='slds-icon-utility-down slds-button__icon slds-icon_container forceIcon']"));
		jsClick(ele);
		Thread.sleep(1000);
	}

	//Author : Kalam
	// Navback to Task screen
	public void NavBackToTask() throws InterruptedException {
		WebElement ele5 = driver.findElement(By.xpath("//button[@title='Show Navigation Menu']"));
		jsClick(ele5);
		Thread.sleep(1000);

		driver.findElement(By.xpath(
				"//span[text()='Tasks'][@class='menuLabel slds-listbox__option-text slds-listbox__option-text_entity']"))
				.click();
		Thread.sleep(2000);
	}
	
	//Author : Kalam
	//Click on New Task Button
	public void ClickNewTask() throws InterruptedException {
		WebElement ele5 = driver.findElement(By.xpath("//div[text()='New Task']"));
		jsClick(ele5);
		
	}
	
	//Author : Kalam
	//Click on Select the Task type
	public void NewTaskType(String val) throws InterruptedException {
		visibleText(By.xpath("//h2[text()='New Task']"));
		scrollIntoView(driver.findElement(By.xpath("//h2[text()='New Task']/following::span[text()='"+val+"']")));
		jsClick(driver.findElement(By.xpath("//h2[text()='New Task']/following::span[text()='"+val+"']")));
		driver.findElement(By.xpath("//h2[text()='New Task']/following::span[text()='Next']")).click();
		Thread.sleep(2000);
		
		
	}
	
	
	//Author : Kalam
	//Click Save
	public void NewTaskClickSave() throws InterruptedException {
		driver.findElement(By.xpath("//h2[contains(text(),'New Task')]/following::span[text()='Save']")).click();
	}
	
	//Enter Call Back number
	//Author : Kalam
	public void EnterCallBackNumber(String val) throws InterruptedException {
	    Thread.sleep(1000);
		driver.findElement(By.xpath("//h2[contains(text(),'New Task')]/following::span[text()='Call Back Number']/following::input")).sendKeys(val);
	}
	
	//Author : Kalam
	//Open the My Assigned Task Screen
	public void MyAssignedSelctn() throws InterruptedException {
		WebElement ele = driver.findElement(By.xpath("//input[@role='combobox']"));
		jsClick(ele);
		Thread.sleep(800);
		driver.findElement(By.xpath("//input[@role='combobox']")).sendKeys("My Assigned Task");
		Thread.sleep(1200);
		driver.findElement(By.xpath("//mark[text()='My Assigned Task']")).click();
		Thread.sleep(2500);
	}

	//Author : Kalam
	// Select the Case Record
	public void SelectCR(String val) throws InterruptedException {
		driver.navigate().refresh();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//td/following::a[text()='" + val + "']")).click();
		Thread.sleep(4000);
	}

	//Author : Kalam
	// Capture Task Type
	public String TaskType() {
		String TaskType = driver.findElement(By.xpath("//div[text()='Task']/following::span[@class='uiOutputText']"))
				.getText();
		return TaskType;
	}
	
	//Author : Kalam
	// Scroll element to view
	public void scrollIntoView(WebElement element) {
		try {
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("arguments[0].scrollIntoView(true);", element);
			System.out.println("Page scrolled down");
		} catch (Exception e){
			System.out.println("=============================================================");
			System.out.println("Exception-scrollIntoView(): "+e.getMessage());
			takeScreenShot();
			e.printStackTrace();
			System.out.println("=============================================================");
		}    
	}
	
	//Author : Kalam
    public void jsClick(WebElement el) {
		try {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("arguments[0].click();", el);
			System.out.println("Element clicked");
		} catch (Exception e) {
			System.out.println("=============================================================");
			System.out.println("Exception-jsClick(): " + e.getMessage());
			takeScreenShot();
			e.printStackTrace();
			System.out.println("=============================================================");
		}
	}

  //Author : Kalam
	// Take screenshot of page and save in screenshots folder
	public void takeScreenShot() {
		Date date = new Date();
		String screenshotFile = date.toString().replace(":", "_").replace(" ", "_") + ".png";
		String filePath = System.getProperty("user.dir") + "screenshots\\" + screenshotFile;

		try {
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File(filePath));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	//Author : Kalam
	public void clickButton(WebElement element)
	{
		WebDriverWait wait= new WebDriverWait(driver, 100);
		
		wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));
		
		System.out.println("Element is clickable");
		element.click();
	}
	
	//Author : Kalam
	public boolean visibleText(By element)
	{
		WebDriverWait wait= new WebDriverWait(driver, 100);
		
		wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));
		
		System.out.println("Element is visible");
		return false;
	}
	
    //**************************************************Manali Methods*****************************************************

	// Navback to case screen @ manali shivareddy
	public void NavBackToCase() throws InterruptedException {
		WebElement ele5 = driver.findElement(By.xpath("//button[@title='Show Navigation Menu']"));
		jsClick(ele5);
		Thread.sleep(1000);

		driver.findElement(By.xpath(
				"//span[text()='Cases'][@class='menuLabel slds-listbox__option-text slds-listbox__option-text_entity']"))
				.click();
		Thread.sleep(2000);
	}

	// close tab @ manali shivareddy
	public void closeTab() throws InterruptedException {
		driver.findElement(By.xpath(
				"//div[@class='close slds-col--bump-left slds-p-left--none slds-context-bar__icon-action ']//button[@type='button']"))
				.click();
		Thread.sleep(4000);
	}
	

    //**************************************************Manish Methods*****************************************************
    //**************************************************Anil Methods*******************************************************
	
	public void verifylabels() {
	    
	    String fieldname=driver.findElement(By.xpath("//label[text()='Reason for not attending class']")).getText();
	    String errormessage= driver.findElement(By.xpath("//span[text()='A value is required.']")).getText();
	    System.out.println(fieldname + " : " +errormessage );
	    
        
    }
    //**************************************************Amit Methods*******************************************************
    //**************************************************Sumit Methods******************************************************
    //**************************************************Bhavana Methods****************************************************
	
	//@Author : Bhavana
	//To get subject of the task
	public String CaptureSubject() throws InterruptedException
	{
	    Thread.sleep(800);
	    String sub = driver.findElement(By.xpath("//div[text()='Task']/following::span[text()='Subject']/following::span")).getText();
	    return sub;
	}
	
	//@Author : Bhavana
    //To get action type of the task
    public String CaptureActiontype() throws InterruptedException
    {
        Thread.sleep(800);
        String sub = driver.findElement(By.xpath("//div[text()='Task']/following::span[text()='Action Type']/following::span")).getText();
        return sub;
    }
    
  //@Author : Bhavana
    //To get Created By of the task
    public String CaptureCreatedBy() throws InterruptedException
    {
        Thread.sleep(800);
        String sub = driver.findElement(By.xpath("//div[text()='Task']/following::span[text()='Created By']/following::span")).getText();
        return sub;
    }

    
    //@Author : Bhavana
    //To get Expected Close Date-Time of the RCA Analysis task
    public String CaptureExpectedDnT() throws InterruptedException
    {
        Thread.sleep(800);
        String dnt = driver.findElement(By.xpath("//div[text()='Task']/following::span[text()='Expected Close Date-Time']/following::span")).getText();
        return dnt;
    }
    
    //@Author : Bhavana
    //Calculate the expected date and time from RCA Analysis
    
    public String CalDueDate(String created)
    {
        
      //String created = "Vedansh Shukla, 1/28/2023, 6:26 PM";
        String splitted[] = created.split(",");
        String time = splitted[2].trim();
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("h:mm aa");
        Calendar cal = Calendar.getInstance();

        try{  
           cal.setTime(dateFormat.parse(time));  
        }catch(ParseException e){  
            e.printStackTrace();  
         }  
        cal.add(Calendar.MINUTE, 15);
        String newTime = dateFormat.format(cal.getTime());
        String date1 = splitted[1].trim();
        String dateTime =  date1+","+" "+newTime;
        //System.out.println("dateTime : "+dateTime);
        
        return dateTime;
    }
    
    //@Author : Bhavana
    //Navigate to iframe
    public void navToiframe(String title ) throws Exception
    {
        retryForDetachedFrame(driver, "//iframe", 0);
        WebElement frame1=driver.findElement(By.xpath("//iframe[@title = '"+title+"']"));
        Thread.sleep(800);
        driver.switchTo().frame(frame1);
    }
    
    //@Author : Bhavana 
    //Issue Category in  RCA Analysis task 
    public void IssueCategoryRCA(String val) throws InterruptedException {
        visibleText(By.xpath("//label[text()='Issue Category']"));
//        clickButton(driver.findElement(By.xpath("//label[text()='Issue Category']/following::button")));
//        Thread.sleep(300);
        jsClick(driver.findElement(By.xpath("//label[text()='Issue Category']/following::button")));
        Thread.sleep(1000);
        //visibleText(By.xpath("//label[text()='Issue Category']/following::span[text()='"+val+"']"));
        jsClick(driver.findElement(By.xpath("//label[text()='Issue Category']/following::lightning-base-combobox-item/span/following::span[text()='"+val+"']")));
        
    }
    
    //@Author : Bhavana 
    //Issue Type in  RCA Analysis task 
    public void IssueTypeRCA(String val) throws InterruptedException {
        //visibleText(By.xpath("//label[text()='Issue Type']"));
//        Thread.sleep(300);
        //clickButton(driver.findElement(By.xpath("//label[text()='Issue Type']/following::button")));
        //jsClick(driver.findElement(By.xpath("//label[text()='Issue Type']/following::button")));
     
        jsClick(driver.findElement(By.xpath(" //lightning-combobox[contains(@class,'has-error')][1]//button")));
        Thread.sleep(1000);
        //visibleText(By.xpath("//label[text()='Issue Category']/following::span[text()='"+val+"']"));
        jsClick(driver.findElement(By.xpath("//label[text()='Issue Type']/following::lightning-base-combobox-item/span/following::span[text()='"+val+"']")));
        
    }
    
    //@Author : Bhavana 
    //Issue Type in  RCA Analysis task 
    public void IssueSubTypeRCA(String val) throws InterruptedException {
        //visibleText(By.xpath("//label[text()='Issue Sub-Type']"));
//        clickButton(driver.findElement(By.xpath("//label[text()='Issue Sub-Type']/following::button")));
//        Thread.sleep(300);
        //jsClick(driver.findElement(By.xpath("//label[text()='Issue Sub-Type']/following::button[2]")));
      
        jsClick(driver.findElement(By.xpath("//lightning-combobox[contains(@class,'has-error')][1]//button")));
        Thread.sleep(1000);
        //visibleText(By.xpath("//label[text()='Issue Category']/following::span[text()='"+val+"']"));
        jsClick(driver.findElement(By.xpath("//label[text()='Issue Sub-Type']/following::lightning-base-combobox-item/span/following::span[text()='"+val+"']")));
        
    }
    
  //@Author : Bhavana 
    //click next in  RCA Analysis task 
    public void ClickNext() throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//button[text()='Next']")));
        Thread.sleep(1000);
    }
    
	//**************************************************Saurabh Methods****************************************************

}
