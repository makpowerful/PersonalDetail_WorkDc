package pageObjects;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import resources.ExcelData;
import resources.base;

public class NewPaymentRecordPO extends base{
	WebDriver driver;
	ExcelData excelData = new ExcelData();
	ArrayList<String> al = new ArrayList<String>();

	private String lblPayRecdxpath = "//lightning-formatted-text[contains(text(),'Payment-')]";
	private String lnkCasesxpath = "//div[text()='Payment']/following::span[@title='Cases']";
	private String lnkStudentPayments = "//span[@lst-listviewmanagerheader_listviewmanagerheader][@title='Student Payments']";
	private String txtAccountName = "//div[text()='Student Payment']/following::span[text()='Student']/following::a/slot/slot/span";
	private String txtAccountStatus = "//dt[normalize-space() = 'Account Status:']/following::span";
	private String txtAccountSuprStatus = "//dt[normalize-space()='Account Super Status:']/following::span";
	private String lnkNotificationsxpath = "//span[@lst-listviewmanagerheader_listviewmanagerheader][@title='Notifications']";

	// Declaring Constructor
	public NewPaymentRecordPO(WebDriver driver) {
		this.driver = driver;
	}

	//**************************************************Kalam Methods******************************************************

	
	//@Author : Kalam
	// Selecting Capture newly created Payment record ID
	public String CapturePaymentRcdID() throws InterruptedException {
	    visibleText(By.xpath("//div[text()='Payment']"));
	    Scrollpagedown();
	    Scrollpagedown();
		String PaymentRecord = driver.findElement(By.xpath(lblPayRecdxpath)).getText();
		Thread.sleep(300);
		return PaymentRecord;
	}

	//@Author : Kalam
	// Selecting Capture newly created Payment record ID
    public void ClickCasesQA() throws InterruptedException {
        Scrollpagedown();
        Scrollend();
        Thread.sleep(1000);
        WebElement Cases = driver.findElement(By.xpath(lnkCasesxpath));
        jsClick(Cases);
        Thread.sleep(1500);
    }

		
		//@Author : Kalam
		public void Scrollpagedown() throws InterruptedException {

			driver.findElement(tag).sendKeys(Keys.PAGE_DOWN);
			Thread.sleep(1200);
		}	
		
		//@Author : Kalam
	    public void jsClick(WebElement el) {
	        try {
	            JavascriptExecutor jse = (JavascriptExecutor)driver;
	            jse.executeScript("arguments[0].click();", el);
	            System.out.println("Element clicked");
	        } catch (Exception e){
	            System.out.println("=============================================================");
	            System.out.println("Exception-jsClick(): "+e.getMessage());
	            takeScreenShot();
	            e.printStackTrace();
	            System.out.println("=============================================================");
	        }
	    }
	    
	  //@Author : Kalam
	    public void Scrollend() throws InterruptedException {

	        driver.findElement(tag).sendKeys(Keys.END);
	        Thread.sleep(1200);
	    }
	    
        // @Author : Kalam
        public boolean visibleText(By element) {
            WebDriverWait wait = new WebDriverWait(driver, 50);

            wait.ignoring(StaleElementReferenceException.class)
                    .until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));

            System.out.println("Element is visible");
            return false;
        }
	    //**************************************************Manali Methods*****************************************************
	    
	    // Selecting studentPayment @manali shivareddy
	    public void ClickStudentPayments() throws InterruptedException {
	        Scrollpagedown();
	        Scrollpagedown();
	        WebElement studentPayment = driver.findElement(By.xpath(lnkStudentPayments));
	        jsClick(studentPayment);
	        Thread.sleep(3000);
	    }

	    // Enter Account name @manali shivareddy
	    public String getStudentAcctName() throws InterruptedException {
	        
	        String input = driver.findElement(By.xpath(txtAccountName)).getText();
	        return input;
	    }

	    // Enter Account name @manali shivareddy
	    public void getStudntAcctName() throws InterruptedException {
	        jsClick(driver.findElement(By.xpath("//div[text()='Student Payment']/following::span[text()='Student']/following::a")));

	    }

	    // Enter Account name @manali shivareddy
	    public String getAcctStatus() throws InterruptedException {
	        String input = driver.findElement(By.xpath(txtAccountStatus)).getText();
	        return input;
	    }

	    // Enter Account name @manali shivareddy
	    public String getAcctSuprStatus() throws InterruptedException {
	        String input = driver.findElement(By.xpath(txtAccountSuprStatus)).getText();
	        return input;
	    }
	    
	    // Selection Notificatons @manali shivareddy
	        public void ClickNotificationsQA() throws InterruptedException {
	            JavascriptExecutor js = (JavascriptExecutor) driver;
	            js.executeScript("scroll(0,650);");
	            Thread.sleep(3000);
	            WebElement Cases = driver.findElement(By.xpath(lnkNotificationsxpath));
	            Cases.click();
	            Thread.sleep(3000);
	        }
	        
	        
	    //**************************************************Manish Methods*****************************************************
	    //**************************************************Anil Methods*******************************************************
	    //**************************************************Amit Methods*******************************************************
	    //**************************************************Sumit Methods******************************************************
	    //**************************************************Bhavana Methods****************************************************
	        
	    //@Author : Bhavana
	    //click cases button on the payment page 
	    public void ClickCasesbtn() throws InterruptedException {
	        Scrollpageup();
	        Scrollpageup();
	        Thread.sleep(1000);
    
	        WebElement Cases = driver.findElement(By.xpath("//div[text()='Payment']/following::span[@title='Cases']"));
			jsClick(Cases);
	        Thread.sleep(1500);
	    }
	        
	    public void Scrollpageup() throws InterruptedException {

	        driver.findElement(tag).sendKeys(Keys.PAGE_UP);
	        Thread.sleep(1200);
	    }
	        
	    //@Author : Bhavana
		//Clicking button  
	    public void clickButton(WebElement element)
	    {
	        WebDriverWait wait= new WebDriverWait(driver, 50);
	            
	        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));
	            
	        System.out.println("Element is clickable");
	        element.click();
	    }
	    //**************************************************Saurabh Methods****************************************************
}
