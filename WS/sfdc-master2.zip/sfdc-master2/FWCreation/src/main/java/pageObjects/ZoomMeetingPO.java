package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ZoomMeetingPO {
	
	WebElement element;
	
	public static String calendarNextbtun="//button[@class='fc-next-button fc-button fc-state-default fc-corner-right']";
	public static String calendarAllDaySec="//*[@id=\"calendar-25\"]/div[2]//following::tr/td[2]";
	

    //**************************************************Manish Methods*****************************************************

	
	//Author : Manish
	//Arrowed next button in Calendar section which takes to next month
	public static WebElement calendarNextButton(WebDriver driver)
	{	
	return driver.findElement(By.xpath(ZoomMeetingPO.calendarNextbtun));
	
	}
	
	//Author : Manish
	//Any date section in calendar based on 'date' and 'day' parameters
	public static WebElement calendateDate(WebDriver driver, String date, String day)
	{
		return driver.findElement(By.xpath("//td[@data-date='"+date+"']/a[text()='"+day+"']"));
	}
	
	//Author : Manish
	//All Day section in Calendar
	public static WebElement calendarAllDaySection(WebDriver driver)
	{
		return driver.findElement(By.xpath(ZoomMeetingPO.calendarAllDaySec));
	}
	
	//Author : Manish
	//Meeting start time text field
	public static WebElement meetingStartTime(WebDriver driver)
	{
		return driver.findElement(By.xpath("//div/input[@class='slds-combobox__input slds-input']"));
	}
	//Author : Manish
	public static WebElement meetingDuration(WebDriver driver)
	{
		return driver.findElement(By.xpath("//label[text()='Duration']//following::div/input[@class='slds-input']"));
	}
	
	//**************************************************Kalam Methods******************************************************
    //**************************************************Manali Methods*****************************************************
    //**************************************************Anil Methods*******************************************************
    //**************************************************Amit Methods*******************************************************
    //**************************************************Sumit Methods******************************************************
    //**************************************************Bhavana Methods****************************************************
	//**************************************************Saurabh Methods****************************************************
}
