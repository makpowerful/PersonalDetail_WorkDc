package pageObjects;



import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import resources.base;


public class PaymentCaseQAPO extends base{
	WebDriver driver;

	
	//private String btnNextxpath = "//span[text()='Next']";
	

	// Declaring Constructor
	public PaymentCaseQAPO(WebDriver driver) {
		this.driver = driver;
	}

    //**************************************************Kalam Methods******************************************************

	
	//@Author : Kalam
	//Click on New Case Button
	public void ClickCaseNewButton(String PaymentRecord) throws InterruptedException {
		
	jsClick(driver.findElement(By.xpath("//a[text()='"+PaymentRecord+"']/following::div[@title='New']")));
	Thread.sleep(2000);
	}
	
	//@Author : Kalam
    public void jsClick(WebElement el) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor)driver;
            jse.executeScript("arguments[0].click();", el);
            System.out.println("Element clicked");
        } catch (Exception e){
            System.out.println("=============================================================");
            System.out.println("Exception-jsClick(): "+e.getMessage());
            takeScreenShot();
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }
    //**************************************************Manali Methods*****************************************************
    //**************************************************Manish Methods*****************************************************
    //**************************************************Anil Methods*******************************************************
    //**************************************************Amit Methods*******************************************************
    //**************************************************Sumit Methods******************************************************
    //**************************************************Bhavana Methods****************************************************
	//**************************************************Saurabh Methods****************************************************
}
