package pageObjects;


import java.util.concurrent.ThreadLocalRandom;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.ui.ExpectedConditions;

import org.openqa.selenium.support.ui.WebDriverWait;


import resources.base;

public class BranchAccountPO extends base {
    WebDriver driver;

    //private String lnkSSOxpath = "//span[text()='Student Sales Order']/following::span[@force-lookup_lookup]";
    static int randomNum = ThreadLocalRandom.current().nextInt(10000, 100000 + 1);
    static int randomNum1 = ThreadLocalRandom.current().nextInt(1, 100 + 1);

    // Declaring Constructor
    public BranchAccountPO(WebDriver driver) {
        this.driver = driver;
    }
	
	//**************************************************Kalam Methods******************************************************
    //Author : Kalam
    // Click on Account Team view card
    public void ClickAccountTeamCard() throws InterruptedException {
        visibleText(By.xpath("//div[text()='Account']/following::span[text()='Account Team'][@title]"));
        driver.findElement(
                By.xpath("//div[text()='Account']/following::span[text()='Account Team'][@title]"))
                .click();
        Thread.sleep(1000);
    }

    // Author : Kalam
    // Click Save
    public void ClickSave() throws InterruptedException {
        driver.findElement(By.xpath("//button[text()='Save']")).click();
        Thread.sleep(2000);
    }

    // Author : Kalam
    public void clickButton(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, 100);

        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));

        System.out.println("Element is clickable");
        element.click();
    }

    // Author : Kalam
    public boolean visibleText(By element) {
        WebDriverWait wait = new WebDriverWait(driver, 100);

        wait.ignoring(StaleElementReferenceException.class)
                .until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));

        System.out.println("Element is visible");
        return false;
    }

    // Author : Kalam
    public void jsClick(WebElement el) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].click();", el);
            System.out.println("Element clicked");
        } catch (Exception e) {
            System.out.println("=============================================================");
            System.out.println("Exception-jsClick(): " + e.getMessage());
            takeScreenShot();
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }

    // Author : Kalam
    public void Scrollpagedown() throws InterruptedException {

        driver.findElement(tag).sendKeys(Keys.PAGE_DOWN);
        Thread.sleep(1200);
    }

    // Author : Kalam
    // Scroll element to view
    public void scrollIntoView(WebElement element) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].scrollIntoView(true);", element);
            System.out.println("Page scrolled down");
        } catch (Exception e) {
            System.out.println("=============================================================");
            System.out.println("Exception-scrollIntoView(): " + e.getMessage());
            takeScreenShot();
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }
	
    //**************************************************Manali Methods*****************************************************
    //**************************************************Manish Methods*****************************************************
    //**************************************************Anil Methods*******************************************************
    //**************************************************Amit Methods*******************************************************
    //**************************************************Sumit Methods******************************************************
    //**************************************************Bhavana Methods****************************************************
	//**************************************************Saurabh Methods****************************************************
}
