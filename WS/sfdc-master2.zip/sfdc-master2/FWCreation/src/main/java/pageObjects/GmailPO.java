package pageObjects;

import java.awt.AWTException;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.apache.commons.lang.time.DateUtils;
import org.junit.Assert;
import org.openqa.selenium.By;

import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import resources.ExcelData;
import resources.base;

public class GmailPO extends base{
	WebDriver driver;

    /*
     * private String txtUsernamexpath = "//input[@id='username']";
     * private String txtPasswordxpath = "//input[@id='password']";
     * private String btnLoginxpath = "//input[@type='submit']";
     * private String btnNextxpath = "//button[text()='Next']";
     * private String txtLoginReasonxpath = "//textarea";
     */
	
	
	
	ExcelData excelData = new ExcelData();
	ArrayList<String> al = new ArrayList<String>();
	
	//Declaring Constructor
	public GmailPO(WebDriver driver) {
		this.driver=driver;
	}
	
	//**************************************************Kalam Methods******************************************************
  
	//@Author : Kalam
	public void switchWindow() throws InterruptedException{
		Set<String> winid = driver.getWindowHandles();
        Iterator<String> iter = winid.iterator();
        iter.next();
        String tab = iter.next();
        Thread.sleep(3000);
        driver.switchTo().window(tab);
	}
	
	//@Author : Kalam
	   public void switchWindowTwo() throws InterruptedException{
	        Set<String> winid = driver.getWindowHandles();
	        Iterator<String> iter = winid.iterator();
	        iter.next();
	        iter.next();
	        String tab = iter.next();
	        Thread.sleep(3000);
	        driver.switchTo().window(tab);
	    }
	   
	 //@Author : Kalam
	public void switchWindowArrayLast() throws InterruptedException{
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
	    int i=tabs2.size()-1;
		driver.switchTo().window(tabs2.get(i));
	}
	
	//@Author : Kalam
	public void LoginGmail(String username, String password) throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("window.open()");
		switchWindowArrayLast();
		driver.get("https://www.gmail.com/");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@type='email']")).sendKeys(username);
		driver.findElement(By.xpath("//span[text()='Next']")).click();
		visibleText(By.xpath("//div[text()='Show password']"));
		jsClick(driver.findElement(By.xpath("//input[@type='password']")));
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@type='password']")).sendKeys(password);
		driver.findElement(By.xpath("//span[text()='Next']")).click();
		//List<WebElement> list= driver.findElements(By.xpath("//a[@class='x-tab-close-btn']"));
		//for(int i=0;i<list.size();i++) {
		//	list.get(i).click();
		//	Thread.sleep(300);
		//}
	}
	
	//@Author : Kalam
	//Send mail to byjus mailbox
	public void SendMail(String emailid,String Subject,String MessBody) throws InterruptedException {
		visibleText(By.xpath("//div[text()='Compose']"));
		driver.findElement(By.xpath("//div[text()='Compose']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@peoplekit-id]")).sendKeys(emailid);
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='subjectbox']")).sendKeys(Subject);
		Thread.sleep(500);
		driver.findElement(By.xpath("//div[@aria-label='Message Body']")).sendKeys(MessBody);
		Thread.sleep(500);
		driver.findElement(By.xpath("//div[text()='Send']")).click();
	}
	
	//@Author : Kalam
	//Click Inbox
	public void ClickInboxnRefresh() throws InterruptedException {
		clickButton(driver.findElement(By.xpath("//a[text()='Inbox']")));
		driver.navigate().refresh();
		Thread.sleep(3000);
	}
	
	//@Author : Kalam
	//Checking the mail recieved from Byjus
	public void VerifyNoMailfromByjus(String mailid) throws Exception {
	visibleText(By.xpath("//div[text()='Compose']"));
	//List<WebElement> list = driver.findElements(By.xpath("//table[@role='grid']//td[4]//span[@email='"+mailid+"']/following::span[contains(text(),'Dear')]"));
    	Actions ac = new Actions(driver);
    	//int j=1;
			while(isDisplayed(By.xpath("//table[@role='grid']//td[4]//span[@email='"+mailid+"']/following::span[contains(text(),'Dear')]"))) {
				WebElement list2 = driver.findElement(By.xpath("//table[@role='grid']//td[4]//span[@email='"+mailid+"']/following::span[contains(text(),'Dear')]"));
				visibleText(By.xpath("//div[text()='Compose']"));
				clickButton(list2);
				Thread.sleep(1000);
		    	clickButton(driver.findElement(By.xpath("//div[@data-tooltip='More']")));
		    	Thread.sleep(1000);
		    	visibleText(By.xpath("//div[text()='Delete this message']"));
		    	Thread.sleep(1000);
		    	ac.moveToElement(driver.findElement(By.xpath("//div[text()='Delete this message']")));
		    	clickButton(driver.findElement(By.xpath("//div[text()='Delete this message']")));
		    	Thread.sleep(1000);
		    	driver.findElement(By.xpath("//a[text()='Inbox']")).click();
		    	Thread.sleep(1000);

			}
	
	}
	
	//@Author : Kalam
	   //Delete the Test User email
    public void DeleteTestUserMail() throws Exception {
    visibleText(By.xpath("//div[text()='Compose']"));
    Actions ac = new Actions(driver);
    WebElement list2 = driver.findElement(By.xpath("//table[@role='grid']//td[4]//following::span[text()='Testing User'][2]"));
    visibleText(By.xpath("//div[text()='Compose']"));
    clickButton(list2);
    Thread.sleep(1000);
    driver.findElement(By.xpath("//div[@data-tooltip='More']")).click();
    Thread.sleep(1000);
    visibleText(By.xpath("//div[text()='Delete this message']"));
    Thread.sleep(1000);
    ac.moveToElement(driver.findElement(By.xpath("//div[text()='Delete this message']")));
    clickButton(driver.findElement(By.xpath("//div[text()='Delete this message']")));
    Thread.sleep(1000);
    driver.findElement(By.xpath("//a[text()='Inbox']")).click();
    Thread.sleep(1000);
    
    }
	
  //@Author : Kalam
	   //Checking the mail recieved from Byjus
    public void VerifyNoMailfromByjus_Prod(String mailid) throws Exception {
    visibleText(By.xpath("//div[text()='Compose']"));
   // List<WebElement> list = driver.findElements(By.xpath("//table[@role='grid']//td[4]//span[@email='"+mailid+"']/following::span[contains(text(),'Dear Parent, As')]"));
        Actions ac = new Actions(driver);
        //int j=1;
            while(isDisplayed(By.xpath("//table[@role='grid']//td[4]//span[@email='"+mailid+"']/following::span[contains(text(),'Dear Parent, As')]"))) {
                WebElement list2 = driver.findElement(By.xpath("//table[@role='grid']//td[4]//span[@email='"+mailid+"']/following::span[contains(text(),'Dear Parent, As')]"));
                visibleText(By.xpath("//div[text()='Compose']"));
                clickButton(list2);
                Thread.sleep(1000);
                driver.findElement(By.xpath("//div[@data-tooltip='More']")).click();
                Thread.sleep(1000);
                visibleText(By.xpath("//div[text()='Delete this message']"));
                Thread.sleep(1000);
                ac.moveToElement(driver.findElement(By.xpath("//div[text()='Delete this message']")));
                clickButton(driver.findElement(By.xpath("//div[text()='Delete this message']")));
                Thread.sleep(1000);
                driver.findElement(By.xpath("//a[text()='Inbox']")).click();
                Thread.sleep(1000);

            }
    
    }
    
  //@Author : Kalam
    //Handle Alert if visible
    public void HandleAlert() {
        try {
            driver.switchTo().alert().dismiss();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
    
  //@Author : Kalam
	 //Checking the mail recieved from Byjus
    public void DeleteMailfromByjus(String mailid) throws Exception {
        try {
            visibleText(By.xpath("//div[text()='Compose']"));
        }
        catch(Exception e) {
            HandleAlert();
            driver.get(driver.getCurrentUrl());
            Thread.sleep(2000);
            HandleAlert();
            visibleText(By.xpath("//div[text()='Compose']"));
        }
            while(isDisplayed(By.xpath("//table[@role='grid']//td[4]//span[@email='"+mailid+"']/following::span[contains(text(),'Dear')]"))) {
                WebElement list2 = driver.findElement(By.xpath("//table[@role='grid']//td[4]//span[@email='"+mailid+"']/following::span[contains(text(),'Dear')]"));
                visibleText(By.xpath("//div[text()='Compose']"));
                clickButton(list2);
                Thread.sleep(1000);
            }
    
    }
	
  //@Author : Kalam
	//Nav to the Bank Form
	public void NavtoBankForm(String mailid) throws InterruptedException {
	    try {
	    jsClick(driver.findElement(By.xpath("//table[@role='grid']//td[4]//div/following::span[@email='"+mailid+"']")));
	    }
	    catch(Exception e){
	        driver.navigate().refresh();
	        Thread.sleep(1000);
	        visibleText(By.xpath("//div[text()='Compose']"));
	        jsClick(driver.findElement(By.xpath("//table[@role='grid']//td[4]//div/following::span[@email='"+mailid+"']")));  
	    }
        Thread.sleep(2000);
        try {
        clickButton(driver.findElement(By.xpath("//a[contains(@href,'byju')]")));
        }
        catch(Exception e){
            driver.navigate().refresh();
            Thread.sleep(2000);
            clickButton(driver.findElement(By.xpath("//a[contains(@href,'byju')]")));  
        }
        switchWindowArrayLast();
	}
	
	//@Author : Kalam
	//Click Shippment detail link 
	   public void Clickshipmentdetailslink() throws InterruptedException {
	       Thread.sleep(2000);
	       try {
	        visibleText(By.xpath("//a[contains(@href,'byju')]"));
	        clickButton(driver.findElement(By.xpath("//a[contains(@href,'byju')]")));
	       }
	       catch(Exception e) {
	           clickButton(driver.findElement(By.xpath("//a[contains(@href,'byju')]")));  
	       }
	        switchWindowArrayLast();
	    }

	   
	 //@Author : Kalam
	   //Nav to the Bank Form
    public void NavtoBankForm_Prod(String mailid) throws InterruptedException {
        try {
        jsClick(driver.findElement(By.xpath("//table[@role='grid']//td[4]//div/following::span[@email='"+mailid+"']")));
        //visibleText(By.xpath("//div[text()='Compose']"));
        Thread.sleep(1000);
        jsClick(driver.findElement(By.xpath("//a[contains(@href,'byju')]")));
        switchWindowArrayLast();
        }
        catch(Exception e) {
            driver.navigate().refresh();
            Thread.sleep(2000);
            try {
                jsClick(driver.findElement(By.xpath("//table[@role='grid']//td[4]//div/following::span[@email='"+mailid+"'][2]")));
            }
            catch(Exception e1) {
                jsClick(driver.findElement(By.xpath("//table[@role='grid']//td[4]//div/following::span[@email='"+mailid+"'][2]"))); 
            }
            //visibleText(By.xpath("//div[text()='Compose']"));
            Thread.sleep(1000);
            jsClick(driver.findElement(By.xpath("//a[contains(@href,'byju')]")));
            switchWindowArrayLast();  
        }
    }
	
  //@Author : Kalam
	//Enter Account Holders Name
	public void EnterAccountHoldersName(String val) throws InterruptedException {
	    visibleText(By.xpath("//label[text()='Account Holders Name']"));
	    driver.findElement(By.xpath("//label[text()='Account Holders Name']/following::input")).sendKeys(val);
	    Thread.sleep(200);
	}
	
	//@Author : Kalam
	//Enter Account Number
    public void EnterAccountNumber(String val) throws InterruptedException {
        driver.findElement(By.xpath("//label[text()='Account Number']/following::input")).sendKeys(val);
        Thread.sleep(200);
    }
    
  //@Author : Kalam
    //Enter Confirm Account Number
    public void EnterConfirmAccountNumber(String val) throws InterruptedException {
        driver.findElement(By.xpath("//label[text()='Confirm Account Number']/following::input")).sendKeys(val);
        Thread.sleep(200);
    }
    
  //@Author : Kalam
    //Enter Bank Name
    public void EnterBankName(String val) throws InterruptedException {
        driver.findElement(By.xpath("//label[text()='Bank Name']/following::input")).sendKeys(val);
        Thread.sleep(200);
    }
    
  //@Author : Kalam
    //Enter IFSC Code
    public void EnterIFSCCode(String val) throws InterruptedException {
        driver.findElement(By.xpath("//label[text()='IFSC Code']/following::input")).sendKeys(val);
        Thread.sleep(200);
    }
    
  //@Author : Kalam
    //Enter Remarks
    public void EnterRemarks(String val) throws InterruptedException {
        driver.findElement(By.xpath("//label[text()='Remarks']/following::input")).sendKeys(val);
        Thread.sleep(200);
    }
    
  //@Author : Kalam
    //Enter Shipment Partner
    public void EnterShipmentID(String val) throws InterruptedException {
        driver.findElement(By.xpath("//label[text()='Shipment ID/Tracking No / AWB No']/following::input")).sendKeys(val);
        Thread.sleep(200);
    }
    
  //@Author : Kalam
  //Enter Shipment Partner
    public void EnterShipmentPartner(String val) throws InterruptedException {
        driver.findElement(By.xpath("//label[text()='Shipment Partner']/following::input")).sendKeys(val);
        Thread.sleep(200);
    }
    
  //@Author : Kalam
    //Date of Shipment
    public void EnterDateofShipment() throws InterruptedException{
        Date date = DateUtils.addDays(new Date(), 0);
        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
        driver.findElement(By.xpath("//label[text()='Date of Shipment']/following::input")).sendKeys(sdf.format(date));
        Thread.sleep(200);
    }
    
  //@Author : Kalam
    //Upload Files
    public void UploadFiles() throws InterruptedException, IOException, AWTException {
        //driver.findElement(By.xpath("//*[text()='Upload Files']")).click();
        //Thread.sleep(2000);
       // WebElement ele1 = driver.findElement(By.xpath("//*[text()='Upload Files']"));
        //Runtime.getRuntime().exec("C:\\Users\\Tnluser\\Documents\\sfdc-1\\FWCreation\\src\\main\\java\\resources\\UploadFile.exe");
       // ((JavascriptExecutor) driver).executeScript("window.open()");
      //  switchWindowArrayLast();
      //  driver.get("https://www.google.com/");
       // Thread.sleep(2000);
     //   driver.findElement(By.xpath("//input[@type='text']")).sendKeys("Bank Cheque for Testing",Keys.ENTER);
      //  visibleText(By.xpath("//a[text()='Images']"));
     //   driver.findElement(By.xpath("//a[text()='Images']")).click();
        
      //  Actions ac= new Actions(driver);
      //  WebElement ele= driver.findElement(By.xpath("//img[@src][@jsname]"));
        //ac.moveToElement(ele).contextClick().build().perform();
        //Robot robot = new Robot();
        //robot.keyPress(KeyEvent.VK_CONTROL);
        //robot.keyPress(KeyEvent.VK_T);
        //robot.keyRelease(KeyEvent.VK_CONTROL);
        //robot.keyRelease(KeyEvent.VK_T);
        //Thread.sleep(1200);
        //ac.clickAndHold(ele).build().perform();
       // driver.switchTo().window(Window);
     //   ac.moveToElement(ele1).release().build().perform();
       // ac.dragAndDrop(ele, help(Window)).build().perform();
       // visibleText("");
       // Thread.sleep(10000);
        WebElement addFile = driver.findElement(By.xpath(".//input[@type='file']"));
        addFile.sendKeys(System.getProperty("user.dir")+"\\src\\main\\java\\resources\\BankCheck.png");
        
    }
    
  //@Author : Kalam
    public WebElement help(String Window) throws InterruptedException {
        driver.switchTo().window(Window);
        driver.navigate().refresh();
        Thread.sleep(2000);
        WebElement ele1 = driver.findElement(By.xpath("//*[text()='Upload Files']"));
        return ele1;
    }
    
  //@Author : Kalam
    //Click Submit
    public void ClickSubmit() throws InterruptedException {
        driver.findElement(By.xpath("//button[text()='Submit']")).click();
        Thread.sleep(200);
        visibleText(By.xpath("//*[text()='Thanks, Your Request has been submitted']"));
    }
	
  //@Author : Kalam
	//Checking the mail recieved from Byjus
		public void DeletingAllByjusMail(String mailid) throws Exception {
		
		clickButton(driver.findElement(By.xpath("//a[text()='Inbox']")));
		driver.navigate().refresh();
		Thread.sleep(2000);
		visibleText(By.xpath("//div[text()='Compose']"));
		 	Actions ac = new Actions(driver);
				while(isDisplayed(By.xpath("//table[@role='grid']//td[4]//span[@email='"+mailid+"']/following::span[contains(text(),'Dear')]"))) {
					WebElement list2 = driver.findElement(By.xpath("//table[@role='grid']//td[4]//span[@email='"+mailid+"']/following::span[contains(text(),'Dear')]"));
					visibleText(By.xpath("//div[text()='Compose']"));
					clickButton(list2);
					Thread.sleep(1000);
			    	driver.findElement(By.xpath("//div[@data-tooltip='More']")).click();
			    	Thread.sleep(1000);
			    	visibleText(By.xpath("//div[text()='Delete this message']"));
			    	Thread.sleep(1000);
			    	ac.moveToElement(driver.findElement(By.xpath("//div[text()='Delete this message']")));
			    	clickButton(driver.findElement(By.xpath("//div[text()='Delete this message']")));
			    	Thread.sleep(1000);
			    	driver.findElement(By.xpath("//a[text()='Inbox']")).click();
			    	Thread.sleep(1000);
			    	driver.navigate().refresh();
			    	Thread.sleep(2000);
				}	
		}
	
		//@Author : Kalam
	//Checking the mail recieved from Byjus
	public void ReplytoByjusMail(String mailid, String ownermailid) throws Exception {
	//visibleText(By.xpath("//div[text()='Compose']"));
	//Thread.sleep(1000);
	List<WebElement> list = driver.findElements(By.xpath("//table[@role='grid']//td[4]//span[@email='"+mailid+"']/following::span[contains(text(),'Dear')]"));
	//List<WebElement> list1 = driver.findElements(By.xpath("//table[@role='grid']//td[2]"));
	for(int i=0;i<list.size();i++){
    	//list1.get(i).click();
		jsClick(list.get(i));
    	//Thread.sleep(1000);
    	//driver.findElement(By.xpath("//div[text()='Get started with Gmail']")).click();
    	//Thread.sleep(500);
		try {
    	driver.findElement(By.xpath("//div[@data-tooltip='More']")).click();
		}
		catch(Exception e) {
		    e.printStackTrace();
		    driver.findElement(By.xpath("//div[@data-tooltip='More']")).click();
		}
    	Thread.sleep(1000);
    	visibleText(By.xpath("//div[text()='Reply']"));
    	driver.findElement(By.xpath("//div[text()='Reply']")).click();
    	Thread.sleep(1000);
    	driver.findElement(By.xpath("//div[@aria-label='Message Body']")).sendKeys(ownermailid);
		Thread.sleep(500);
		driver.findElement(By.xpath("//div[text()='Send']")).click();
    }
	
	}
	
	//@Author : Kalam
	//Checking the mail recieved from Byjus
	public void CheckMailRecieved(String mailid) throws Exception {
	Thread.sleep(5000);
    int i = 1;
	while(i<=7) {
		driver.navigate().refresh();
		List<WebElement> list = driver.findElements(By.xpath("//table[@role='grid']//td[4]//span[@email='"+mailid+"']/following::span[contains(text(),'Dear')]"));
		//List<WebElement> list = driver.findElements(By.xpath("//table[@role='grid']//following::span[contains(text(),'Dear')]"));
	    //Alert simpleAlert = driver.switchTo().alert();
	    //simpleAlert.accept();
		 if(list.size()>=1) {
			 
			 System.out.println("Got mail from support team " +mailid);
			 break; 
		    	
		 }
		 else {
			 Thread.sleep(5000);
			 if(i==7) {
				 System.out.println("Did not get mail from support team " +mailid);
				
			 }
		 }
		 i++;
	}
	}
	
	   //@Author : Kalam
    //Checking the mail recieved from Byjus
    public String CheckMailRecievedwithMailcount(String mailid) throws Exception {
    Thread.sleep(5000);
    int i = 1;
    while(i<=7) {
        driver.navigate().refresh();
        List<WebElement> list = driver.findElements(By.xpath("//table[@role='grid']//td[4]//span[@email='"+mailid+"']"));
         if(list.size()>=1) {
             
             System.out.println("Got mail from support team " +mailid);
             break; 
                
         }
         else {
             Thread.sleep(5000);
             if(i==7) {
                 System.out.println("Did not get mail from support team " +mailid);
                
             }
         }
         i++;
    }
    return driver.findElement(By.xpath("//table[@role='grid']//td[4]//span[@email='"+mailid+"'][1]/following::*[contains(text(),'Sandbox')][2]/preceding::span[1]")).getText();
    }
	
	//@Author : Kalam
	   //Checking the mail recieved from Byjus
    public void CheckMailRecieved_Prod(String mailid) throws Exception {
    Thread.sleep(5000);
    int i = 1;
    while(i<=7) {
        driver.navigate().refresh();
        List<WebElement> list = driver.findElements(By.xpath("//table[@role='grid']//td[4]//span[@email='"+mailid+"']/following::span[contains(text(),'Dear Parent, As')]"));
        //List<WebElement> list = driver.findElements(By.xpath("//table[@role='grid']//following::span[contains(text(),'Dear')]"));
        //Alert simpleAlert = driver.switchTo().alert();
        //simpleAlert.accept();
         if(list.size()>=1) {
             
             System.out.println("Got mail from support team "+mailid);
             break; 
                
         }
         else {
             Thread.sleep(5000);
             if(i==7) {
                 System.out.println("Did not get mail from support team "+mailid);
                
             }
         }
         i++;
    }
    }
    
  //@Author : Kalam
    //Select Shipment details mail
    public void SelectShippmentDetailsmail() {
        jsClick(driver.findElement(By.xpath("//table[@role='grid']//td[4]//following::span[contains(text(),'shipment details')]")));
    }

  //@Author : Kalam
    //Select Acknowledgement Receipt mail
    public void DeleteAcknowledgementReceiptShippmentDetailsmail() throws InterruptedException {
    jsClick(driver.findElement(By.xpath("//table[@role='grid']//td[4]//following::span[contains(text(),'Acknowledgement Receipt')]")));
    Thread.sleep(1500);
    Actions ac = new Actions(driver);
    try {
    clickButton(driver.findElement(By.xpath("//div[@data-tooltip='More']")));
    }
    catch(Exception e) {
        e.printStackTrace();
        ac.moveToElement(driver.findElement(By.xpath("//div[@data-tooltip='More']"))).click().build().perform();
    }
    Thread.sleep(1000);
    visibleText(By.xpath("//div[text()='Delete this message']"));
    Thread.sleep(1000);
    ac.moveToElement(driver.findElement(By.xpath("//div[text()='Delete this message']")));
    clickButton(driver.findElement(By.xpath("//div[text()='Delete this message']")));
    Thread.sleep(1000);
    }
    
    //@Author : Kalam
    //Verify Email case is present and delete
    public void VerifyEmailnCase(String mailid,String caseno, String TAT,String content) throws InterruptedException {
    visibleText(By.xpath("//a[text()='Inbox']"));
    clickButton(driver.findElement(By.xpath("//table[@role='grid']//td[4]//span[@email='"+mailid+"']/following::*[contains(text(),'Sandbox')][2] | //table[@role='grid']//td[4]//span[@email='"+mailid+"']/following::*[contains(text(),'Service')][2]")));
    Thread.sleep(1000);

    Thread.sleep(500);
    if(driver.findElement(By.xpath("//*[text()=\""+content+"\"]")).isDisplayed()){
        System.out.println(caseno+" with TAT "+TAT+" is present.");
        Assert.assertTrue(true);
    }
    else {
        System.out.println(caseno+" with TAT "+TAT+" is NOT present.");
        Assert.assertTrue(false);
    }
    Actions ac = new Actions(driver);
    try {
    clickButton(driver.findElement(By.xpath("//div[@data-tooltip='More'][@role]/img")));
    }
    catch(Exception e) {
        e.printStackTrace();
        ac.moveToElement(driver.findElement(By.xpath("//div[@data-tooltip='More'][@role]/img"))).click().build().perform();
    }
    
    visibleText(By.xpath("//div[text()='Delete this message']"));
    Thread.sleep(1000);
    ac.moveToElement(driver.findElement(By.xpath("//div[text()='Delete this message']")));
    clickButton(driver.findElement(By.xpath("//div[text()='Delete this message']")));
    Thread.sleep(1000);
    driver.findElement(By.xpath("//a[text()='Inbox']")).click();
    Thread.sleep(1000);
    }
    
    //@Author : Kalam
    //Verify Email case is present and delete
    public void VerifyEmailnCase2(String mailid,String caseno, String TAT, String content) throws InterruptedException {
    visibleText(By.xpath("//a[text()='Inbox']"));
    try {
    jsClick(driver.findElement(By.xpath("//table[@role='grid']//td[4]//span[@email='"+mailid+"']/following::*[contains(text(),'Sandbox')][2] | //table[@role='grid']//td[4]//span[@email='"+mailid+"']/following::*[contains(text(),'Service')][2]")));
    }
    catch(Exception e) {
        e.printStackTrace();
        driver.get(driver.getCurrentUrl());
        Thread.sleep(2000);
        jsClick(driver.findElement(By.xpath("//table[@role='grid']//td[4]//span[@email='"+mailid+"']/following::*[contains(text(),'Sandbox')][2] | //table[@role='grid']//td[4]//span[@email='"+mailid+"']/following::*[contains(text(),'Service')][2]")));   
    }
    Thread.sleep(1000);
    try {
    jsClick(driver.findElement(By.xpath("//span[@email='"+mailid+"'][@role] | //span[@email='btcsupport@byjus.com']/span")));
    }
    catch(Exception e) {
        e.printStackTrace();
        jsClick(driver.findElement(By.xpath("//span[@email='"+mailid+"'][@role] | //span[@email='btcsupport@byjus.com']/span"))); 
    }
    Thread.sleep(500);
    if(driver.findElement(By.xpath("//*[text()=\""+content+"\"]")).isDisplayed()){
        System.out.println(caseno+" with TAT "+TAT+" is present.");
        Assert.assertTrue(true);
    }
    else {
        System.out.println(caseno+" with TAT "+TAT+" is NOT present.");
        Assert.assertTrue(false);
    }
    Actions ac = new Actions(driver);
    try {
    clickButton(driver.findElement(By.xpath("//div[@data-tooltip='More'][@role]/img")));
    }
    catch(Exception e) {
        e.printStackTrace();
        ac.moveToElement(driver.findElement(By.xpath("//div[@data-tooltip='More'][@role]/img"))).click().build().perform();
    }
    
    visibleText(By.xpath("//div[text()='Delete this message']"));
    Thread.sleep(1000);
    ac.moveToElement(driver.findElement(By.xpath("//div[text()='Delete this message']")));
    clickButton(driver.findElement(By.xpath("//div[text()='Delete this message']")));
    Thread.sleep(1000);
    driver.findElement(By.xpath("//a[text()='Inbox']")).click();
    Thread.sleep(1000);
    }
    
    
    
    //@Author : Kalam
    //Email content
    public String EmailContent(String caseno, String TAT) throws InterruptedException {
        String byju= "BYJU’S";
        String content="Thank you for contacting "+byju+" Tuition Centre. Your Service Request number is "+caseno+". We have forwarded your request to our concerned team for the resolution and we shall get back to you in "+TAT+" Hrs with further update on the same.";
        return content;
    }
    
    //@Author : Kalam
    //Email content
    public String ResolvedEmailContent(String caseno) throws InterruptedException {
        String content="Thank you for contacting BYJU’S Tuition Centre. We have resolved your Service Request no. "+caseno+". Please connect with us at ";
        return content;
    }
    
  //@Author : Kalam
	//Return value for email subject
	public String EmailSubject() throws IOException {
		al = excelData.getData("UAT", "Email", "Tcid");
		String[] Val = al.get(2).trim().split(";");
		Random generator = new Random();
		int randomIndex = generator.nextInt(Val.length);
		System.out.println(Val[randomIndex]);
		return Val[randomIndex];
	}
	
    public void jsClick(WebElement el) {
		try {
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("arguments[0].click();", el);
			System.out.println("Element clicked");
		} catch (Exception e){
			System.out.println("=============================================================");
			System.out.println("Exception-jsClick(): "+e.getMessage());
			//takeScreenShot();
			e.printStackTrace();
			System.out.println("=============================================================");
		}
	}
	
  //@Author : Kalam
	public boolean visibleText(By element)
	{
		WebDriverWait wait= new WebDriverWait(driver, 100);
		
		wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));
		
		System.out.println("Element is visible");
		return false;
	}
	
	//@Author : Kalam
	public void clickButton(WebElement element)
	{
		WebDriverWait wait= new WebDriverWait(driver, 50);
		
		wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));
		
		System.out.println("Element is clickable");
		element.click();
	}
	
	//@Author : Kalam
	public boolean isDisplayed(By element) {
		List<WebElement> list = driver.findElements(element);
		//System.out.println(list.toString());
		boolean value = false;
		if (!list.isEmpty()) {
			if (list.get(0).isDisplayed()) {
				value = true;
				return value;
			}
		} else {

			return value;
		}
		return value;
	}
	
	//Author : Kalam
	public void DeleteAllMails() throws InterruptedException {
	    clickButton(driver.findElement(By.xpath("//a[text()='Inbox']")));
	    visibleText(By.xpath("//div[text()='Compose']"));
	    Thread.sleep(200);
	    jsClick(driver.findElement(By.xpath("//span[@role='checkbox']")));
	    Thread.sleep(2000);
	    WebElement ele = driver.findElement(By.xpath("//span[@role='checkbox']/following::div[@data-tooltip='Delete']"));
	    Actions ac = new Actions(driver);
	    ac.moveToElement(ele).click().build().perform();
	    //clickButton(driver.findElement(By.xpath("//span[@role='checkbox']/following::div[@data-tooltip='Delete']/div/div")));
	    Thread.sleep(200);
	}
	
	//**************************************************Manali Methods*****************************************************
	
	//Return value for email @manali shivareddy

	  public String EasyPayMailBodyContent() throws IOException, InterruptedException {
	      try {
	    String text = driver.findElement(By.xpath("//div[@class='a3s aiL ']")).getText();
	    System.out.println(text);
	    driver.navigate().back();
        return text;
	      }
	      catch(Exception e) {
	          driver.get(driver.getCurrentUrl());
	          Thread.sleep(200);
	          String text = driver.findElement(By.xpath("//div[@class='a3s aiL ']")).getText();
	          System.out.println(text);  
	          driver.navigate().back();
	          return text;
	      }
	    
	 /*   visibleText(By.xpath("//a[text()='Inbox']"));
	    clickButton(driver.findElement(By.xpath("//a[text()='Inbox']")));*/
	    
	  }
	  
	  // to verify the mail body @#manali shivareddy
	  public String expectedText(String easyPayCaseId) {
	    String expected = "Dear  Vedansh Shukla\n"
	        + "\n"
	        + "Greetings from the CGR team!\n"
	        + "Your \"Query\" is resolved.\n"
	        + "For more details please check your ticket status – https://byjusprod--byjusuat.my.salesforce.com/"+easyPayCaseId+"\n"
	        + "\n"
	        + "If your issue is still not resolved, kindly raise a new ticket.\n"
	        + "For any further queries & escalations reach out to:\n"
	        + "Rajanikanta.nayak@byjus.com\n"
	        + "Aayush.parasrampuria@byjus.com\n"
	        + "\n"
	        + "\n"
	        + "Regards:\n"
	        + "Customer Grievance Redressal – Digital Finance";
	    System.out.println(expected);
	    return expected;
	  }
	 // to get the case id from the url @manali shivareddy

	  public String getCaseId(String url) {
	    String[] parts = url.split("[/ ]+");
	    String p= parts[5];
	    String caseId=p.substring(0, p.length() - 3);
	    System.out.println("The case id is: "+caseId);
	    return caseId;
	  }
	
	// To Check the mail recieved  @manali shivareddy

	    public void CheckMailRecievedIrrelevantToCGR() throws Exception {
	    Thread.sleep(5000);
	    int i = 1;
	    while(i<=7) {
	      List<WebElement> list = driver.findElements(By.xpath("//table[@role='grid']//td[4]//span/following::span[contains(text(),'Dear')]"));
	       if(list.size()>=1) {
	         System.out.println("Got mail from support team");
	         break;
	       }
	       else {
	         Thread.sleep(10000);
	         if(i==7) {
	           System.out.println("Did not get mail from support team");
	         }
	       }
	       i++;
	    }
	    }
	    //To open the mail recieved @manali shivareddy

	    public void openMail() throws Exception {
	    visibleText(By.xpath("//div[text()='Compose']"));
	        while(isDisplayed(By.xpath("//table[@role='grid']//td[4]//span/following::span[contains(text(),'Dear')]"))) {
	          WebElement list2 = driver.findElement(By.xpath("//table[@role='grid']//td[4]//span/following::span[contains(text(),'Dear')]"));
	          visibleText(By.xpath("//div[text()='Compose']"));
	          try {
	          clickButton(list2);
	          }
	          catch(Exception e) {
	              jsClick(list2);
	          }
	          Thread.sleep(1000);
	        }
	    }
	    
	 // To pass the irrilevant text @#manali shivareddy
	    public String expectedTextIrrelevantToCGR() {
	      String expected = "Dear Vedansh Shukla ,\n"
	          + "\n"
	          + "This issue/query cannot be catered by the Easy-pay team. Please reach out below teams for certain unrelated CGR issue-\n"
	          + "\n"
	          + "1.) For Tenurity extension reach out to cancellations@byjus.com\n"
	          + "\n"
	          + "2.) For Non-EMI’s cases reach out to payuqueries@byjus.com\n"
	          + "\n"
	          + "3.) For EMI due date change reach out to cancellations@byjus.com\n"
	          + "\n"
	          + "\n"
	          + "Thanks & Regards";
	      System.out.println(expected);
	      return expected;
	    }
    //**************************************************Manish Methods*****************************************************
    //**************************************************Anil Methods*******************************************************
    //**************************************************Amit Methods*******************************************************
    //**************************************************Sumit Methods******************************************************
    //**************************************************Bhavana Methods****************************************************
	//**************************************************Saurabh Methods****************************************************
}
