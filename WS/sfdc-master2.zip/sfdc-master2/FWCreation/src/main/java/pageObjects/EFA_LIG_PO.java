package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import resources.base;

public class EFA_LIG_PO extends base {
    WebDriver driver;

    // Declaring Constructor
    public EFA_LIG_PO(WebDriver driver) {
        this.driver = driver;
    }

    // @Author : Manali Shivareddy
    // Select on EFA-LIG radio button
    public void SelectCaseRecordType(String val) throws InterruptedException {
        Thread.sleep(1000);
        WebElement ele = driver.findElement(By.xpath("//span[text()='" + val + "']"));
        scrollIntoView(ele);
        ele.click();
        Thread.sleep(200);
    }

    // @Author : Manali Shivareddy
    // Select options such as 'DP to be Refunded' : Yes or No
    public void SelectDropdownOption(String val, String val1) throws InterruptedException {

        jsClick(driver.findElement(By.xpath("//span[text()='" + val + "']/following::a | //label[text()='" + val + "']/following::button[1]"))); // DP to be Refunded?
        Thread.sleep(200);
        /*
         * ele.sendKeys(Keys.ARROW_DOWN);
         * ele.sendKeys(Keys.ARROW_DOWN);
         * ele.sendKeys(Keys.RETURN);
         */
        WebElement a6 = driver
                .findElement(By.xpath("//span[text()='" + val + "']/following::a[text()='" + val1 + "'] | //label[text()='" + val + "']/following::span[text()='" + val1 + "']"));
        jsClick(a6);
    }

    // @Author : Manali Shivareddy
    // Click save
    public void clickSave() throws InterruptedException {
        driver.findElement(By.xpath("//button[text()='Save']")).click();
        Thread.sleep(2000);
    }

    //
    public String parentCaseNumb() throws InterruptedException {
        String parentCase = driver
                .findElement(By.xpath("//div/p[text()='Case Number']/following::lightning-formatted-text")).getText();
        Thread.sleep(200);
        return parentCase;

    }

    // @Author : Manali Shivareddy
// to get the Case Owner text
    public String getEfaLigCaseOwnerDetailsSection() throws InterruptedException {

        String Owner = driver
                .findElement(By.xpath("//span[text()='Case Owner']/following::span[@class='displayLabel']/slot"))
                .getText();
        Thread.sleep(200);
        return Owner;
    }

    // @Author : Manali Shivareddy
    // to get the contact name text
    public String getEfaLigContactName() throws InterruptedException {
        String contactName = driver.findElement(By.xpath("//span[text()='Contact Name']/following::slot/span"))
                .getText();
        Thread.sleep(200);
        return contactName;
    }

    // @Author : Manali Shivareddy
    public String getParentOrder() throws InterruptedException {
        String order = driver.findElement(By.xpath("//span[text()='Order']/following::slot/span")).getText();
        Thread.sleep(200);
        return order;
    }

    // @Author : Manali Shivareddy
    // to get the case origin text
    public String getEfaLigCaseOrigin() throws InterruptedException {
        String caseOrigin = driver
                .findElement(By.xpath("//span[text()='Case Origin']/following::lightning-formatted-text"))
                .getText();
        Thread.sleep(200);
        return caseOrigin;
    }

    // @Author : Manali Shivareddy
    // to get the Subject text
    public String getEfaLigSub() throws InterruptedException {
        String sub = driver.findElement(By.xpath("//span[text()='Subject']/following::lightning-formatted-text"))
                .getText();
        Thread.sleep(200);
        return sub;
    }

    // @Author : Manali Shivareddy
    // to get the Status text
    public String getEfaLigStatus() throws InterruptedException {
        String status = driver.findElement(By.xpath(
                "//lightning-formatted-text[starts-with(text(),'EFA-LIG')]/following::span[text()='Status']/following::lightning-formatted-text"))
                .getText();
        Thread.sleep(200);
        return status;
    }

    // @Author : Manali Shivareddy
    // to get the EP Partner text
    public String getEfaLigEPpartner() throws InterruptedException {

        String epPartner = driver.findElement(By.xpath(
                "//lightning-formatted-text[starts-with(text(),'EFA-LIG')]/following::span[text()='EP Partner']/following::lightning-formatted-text"))
                .getText();
        Thread.sleep(200);
        return epPartner;
    }

    // @Author : Manali Shivareddy
    // to get the text of Details section feilds
    public String getEfaLigDetailsFields(String val) throws InterruptedException {
        String text = driver
                .findElement(
                        By.xpath("//lightning-formatted-text[starts-with(text(),'EFA-LIG')]/following::span[text()='"
                                + val + "']/following::lightning-formatted-text"))
                .getText();
        Thread.sleep(200);
        return text;
    }

    // @Author : Manali Shivareddy
    // Click Next button
    public void ClickNext() throws InterruptedException {
        driver.findElement(By.xpath("//span[text()='Next']")).click();
        Thread.sleep(2000);
    }

    // @Author : Manali Shivareddy
    // Click EFA LIG Take Action button
    public void clickEfaLigBtn() throws InterruptedException {
        driver.findElement(By.xpath("//button[text()='EFA LIG Action']")).click();
        Thread.sleep(2000);
    }

    // @Author : Manali Shivareddy
    // to enter the text in EFA LIG Take Action section feilds
    public void enterEfaLigActionFields(String val) throws InterruptedException {
        WebElement ele = driver
                .findElement(By.xpath("//body[@class='slds-scope']//span[text()='" + val + "']/following::input"));
        ele.click();
        ele.clear();
        if (val == "Classes to be Deactivated" || val == "Courier Charges to be Refunded") {
            ele.sendKeys("No");
        } else {
            ele.sendKeys("100");
        }
        Thread.sleep(200);
    }

    // @Author : Manali Shivareddy
    // Select Value for 'Retention Team Product Status' & 'Retention Team Mode of
    // Retention'
    public void selectRetentionTeamProductStatus(String val) throws InterruptedException {
        Select sel = new Select(driver.findElement(By.xpath("//select[@name='Retention_Team_Product_Status']")));
        sel.selectByVisibleText(val);
        Thread.sleep(200);
    }

    // @Author : Manali Shivareddy
    // Select Value for 'Retention Team Product Status' & 'Retention Team Mode of
    // Retention'
    public void selectRetentionTeamModeofRetention(String val) throws InterruptedException {
        Select sel = new Select(driver.findElement(By.xpath("//select[@name='Retention_Team_Mode_of_Retention']")));
        sel.selectByVisibleText(val);
        Thread.sleep(200);
    }

    // @Author : Manali Shivareddy
    // Click save
    public void clickEfaLigSave() throws InterruptedException {
        driver.findElement(By.xpath("//button[@class='slds-button slds-button_brand flow-button__NEXT']")).click();
        Thread.sleep(2000);
    }

    // @Author : Manali Shivareddy
    // Clicking on Related Cases link
    public void clickRelatedCases() throws InterruptedException {
        Thread.sleep(1000);
        WebElement relatedCases = driver.findElement(
                By.xpath("//span[@lst-listviewmanagerheader_listviewmanagerheader][@title='Related Cases']"));
        jsClick(relatedCases);
        Thread.sleep(1500);
    }

    // @Author : Manali Shivareddy
    // Click on New Case Button
    public void ClickCaseNewButton() throws InterruptedException {
        driver.findElement(By.xpath("//h1[text()='Related Cases']/following::div[@title='New']")).click();
        Thread.sleep(2000);
    }

    // @Author : Manali Shivareddy
    // get child case subject
    public String getChildcaseSubject(String val) throws InterruptedException {
        String sub = driver.findElement(By.xpath("//lightning-formatted-text[@title='EFA-LIG " + val + "']")).getText();
        Thread.sleep(200);
        return sub;
    }

    // @Author : Manali Shivareddy to get the details of links
    public String getChildCaseLinkDetails(String val1, String val2) throws InterruptedException {
        String linkText = driver.findElement(
                By.xpath("//lightning-formatted-text[@title='EFA-LIG " + val1 + "']/following::span[text()='" + val2
                        + "']/following::slot/span"))
                .getText();
        Thread.sleep(200);
        return linkText;
    }

    // @Author : Manali Shivareddy to click the links
    public void clickChildCaseLinkDetails(String val) throws InterruptedException {
        driver.findElement(
                By.xpath("//lightning-formatted-text[@title='EFA-LIG DP To be Refunded']/following::span[text()='" + val
                        + "']/following::slot/span"))
                .click();
        Thread.sleep(200);
    }

    // @Author : Manali Shivareddy to get the details on page
    public String getChildCaseDeatils(String val) throws InterruptedException {
        String text = driver.findElement(
                By.xpath("//lightning-formatted-text[@title='EFA-LIG DP To be Refunded']/following::span[text()='" + val
                        + "']/following::lightning-formatted-text"))
                .getText();
        Thread.sleep(200);
        return text;
    }

    // To get the case owner of the child case
    public String getCaseOwner(String val) throws InterruptedException {
        String owner = driver.findElement(By.xpath(
                "//lightning-formatted-text[@title='EFA-LIG " + val
                        + "']/following::span[text()='Case Owner']/following::span[@class='displayLabel']/slot"))
                .getText();
        Thread.sleep(200);
        return owner;
    }

    // Switch only to the frame @manali shivareddy
    public void switchToTheFrame() throws Exception {
        Thread.sleep(1000);
        retryForDetachedFrame(driver, "//iframe[@title='accessibility title']", 0);
        WebElement frame = driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
        Thread.sleep(1000);
        driver.switchTo().frame(frame);
        Thread.sleep(200);
    }

    // @Author : Manali Shivareddy
    // Scroll element to view
    public void scrollIntoView(WebElement element) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].scrollIntoView(true);", element);
            System.out.println("Page scrolled down");
        } catch (Exception e) {
            System.out.println("=============================================================");
            System.out.println("Exception-scrollIntoView(): " + e.getMessage());
            takeScreenShot();
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }

    // @Author : Manali Shivareddy
    public void jsClick(WebElement el) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].click();", el);
            System.out.println("Element clicked");
        } catch (Exception e) {
            System.out.println("=============================================================");
            System.out.println("Exception-jsClick(): " + e.getMessage());
            takeScreenShot();
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }
    
    //**************************************************Kalam Methods*****************************************************
    //**************************************************Manish Methods*****************************************************
    //**************************************************Anil Methods*******************************************************
    //**************************************************Amit Methods*******************************************************
    //**************************************************Sumit Methods******************************************************
    //**************************************************Bhavana Methods****************************************************
    //**************************************************Saurabh Methods****************************************************

}
