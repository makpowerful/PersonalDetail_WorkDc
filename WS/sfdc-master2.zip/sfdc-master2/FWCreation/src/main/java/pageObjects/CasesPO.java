package pageObjects;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.time.DateUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import resources.base;

public class CasesPO extends base {
	WebDriver driver;

	private String btnNavMenuxpath = "//button[@title='Show Navigation Menu']";
	private String btnPaymntOptnxpath = "//span[text()='Cases'][@class='menuLabel slds-listbox__option-text slds-listbox__option-text_entity']";
	private String btnNewPaymntxpath="//div[text()='New']";
	//private String lnkRecentViewxpath= "//ul/following::span[text()='Recently Viewed']";
	private String lnkDeletexpath = "//a[@title='Delete']";
	private String btnDeletexpath = "//button/span[text()='Delete']";
	private String btnDrpdwnxpath = "//div[@role='tablist']//a[@title='Cases'][contains(@class,'tabHeader')]/following::button[contains(@title,'Actions for')]";
	private String btnRefreshxpath = "//li[@title='Refresh Tab']/a";
	//private String dropdwnCase = "//a[@class='rowActionsPlaceHolder slds-button slds-button--icon-x-small slds-button--icon-border-filled keyboardMode--trigger']";

	
	// Declaring Constructor
	public CasesPO(WebDriver driver) {
		this.driver = driver;
	}
	
    //**************************************************Kalam Methods******************************************************
  
	//@Author : Kalam
	//Open LSPD CSO URL
	public void OpenURL(String MailName, String CaseNumber, String Pid) throws InterruptedException {
		  String LSPDURL="https://dev.byjusorders.com/cso/create-request?emailId%3D"+MailName+"%40byjus.com%26source%3Dsalesforce%26studentId%3D"+Pid+"%26caseId%3D"+CaseNumber+"%26issueType%3DSD%20card%20Issues%26issueSubType%3DSD%20Card(FOC%2FLocked)";
		  System.out.println(LSPDURL);
		  driver.get(LSPDURL);
		  Thread.sleep(2500);
	}
	
	//@Author : Kalam
	//Page Launch text
	public String PageLaunch() throws Exception {
	    retryForDetachedFrame(driver, "//iframe[contains(@src,'dev.')]", 0);
        WebElement frame = driver.findElement(By.xpath("//iframe[contains(@src,'dev.')]"));
        Thread.sleep(1000);
        driver.switchTo().frame(frame);
        Thread.sleep(800);
        visibleText(By.xpath("//h5[text()='Create Customer Service Request']"));
		 String PageLaunch=driver.findElement(By.xpath("//h5")).getText();
		 driver.switchTo().defaultContent();
		 return PageLaunch;
	}
	
	//@Author : Kalam
	//Capture Case Number
	public String CaptureCaseNo() {
		String ele=driver.findElement(By.xpath("//p[text()='Case Number']/following::lightning-formatted-text")).getText();
		return ele;
	}
	
	//@Author : Kalam
	//Selecting Nav Menu
	public void NavMenuClick() throws InterruptedException {
	jsClick(driver.findElement(By.xpath(btnNavMenuxpath)));
	Thread.sleep(1000);
	}

	//@Author : Kalam
	//Selecting Payment option from Nav Menu
	public void CaseNavMenuClick() throws InterruptedException {
	    try {
	driver.findElement(By.xpath(btnPaymntOptnxpath)).click();
	    }
	    catch(Exception e) {
	        driver.get(driver.getCurrentUrl());
	        Thread.sleep(2000);
	        NavMenuClick();
	        driver.findElement(By.xpath(btnPaymntOptnxpath)).click();  
	    }
	Thread.sleep(1500);
	}
	
	//@Author : Kalam
	//Creating New Payment
	public void NewCaseClick() throws InterruptedException {
	driver.findElement(By.xpath(btnNewPaymntxpath)).click();
	Thread.sleep(3000);
	}
	
	//@Author : Kalam
	//Creating New Case with in Account
	public void NewCaseInAccountClick() throws InterruptedException {
	driver.findElement(By.xpath("//h1[text()='Cases']/following::div[text()='New']")).click();
	Thread.sleep(3000);
	}
	
	//@Author : Kalam
	//Navigate to Case tab
	public void NavCaseTab(String val) throws InterruptedException {
	driver.findElement(By.xpath("//ul[@class='tabBarItems slds-tabs--default__nav']//span[@class='title slds-truncate'][text()='"+val+"']")).click();
	Thread.sleep(1000);
	}
	
	//@Author : Kalam
	//Navigate to Cases tab
	public void NavCasesTab() throws InterruptedException {
		try
	    {
	    Thread.sleep(1000);
			driver.findElement(By.xpath("//ul[@class='tabBarItems slds-tabs--default__nav']//span[@class='title slds-truncate'][text()='Cases']")).click();
			Thread.sleep(1000);
	    }
	    catch(WebDriverException e)
	    {
	    	driver.findElement(By.xpath("//ul[@class='tabBarItems slds-tabs--default__nav']//span[@class='title slds-truncate'][text()='Cases']")).click();
	    	Thread.sleep(1000);
	    }
	    catch(Exception ee)
	    {
	        ee.printStackTrace();
	        throw ee;
	    }

	}
	
	//@Author : Kalam
	//Refresh tab
	public void RefreshTab() throws InterruptedException {
	driver.get(driver.getCurrentUrl());
	Thread.sleep(3000);
	}
	
	//@Author : Kalam
	//Delete the Case record created
	public void DeleteCCaseRecord(String val) throws InterruptedException {
		jsClick(driver.findElement(By.xpath("//a[@title='Cases'][contains(@class,'tabHeader')]")));
		Thread.sleep(1000);
		driver.findElement(By.xpath("//a[text()='"+val+"']/following::span[@class='slds-icon_container slds-icon-utility-down']")).click();
		Thread.sleep(800);
		WebElement ele = driver.findElement(By.xpath("//a[text()='"+val+"']/following::a[@role='button']/following::div[text()='Delete']"));
		jsClick(ele);
		Thread.sleep(800);
		driver.findElement(By.xpath("//span[text()='Delete']")).click();
		Thread.sleep(2000);
	}

	//@Author : Kalam
	//Delete the created Case record
	public void DeleteCaseRecord(String val) throws InterruptedException {
		driver.findElement(By.xpath("//a[text()='"+val+"']/following::span[@class='slds-icon_container slds-icon-utility-down']")).click();
		Thread.sleep(1500);
		driver.findElement(By.xpath(lnkDeletexpath)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(btnDeletexpath)).click();
		Thread.sleep(1500);
	}
	
	//@Author : Kalam
	//Delete all the created My Case record
	public void DeleteAllMyCaseRecord() throws InterruptedException {
		driver.findElement(By.xpath("//lightning-icon[contains(@class,'close')]")).click();
		Thread.sleep(1000);
		driver.get(driver.getCurrentUrl());
		Thread.sleep(3500);
		List<WebElement> list=driver.findElements(By.xpath("//tr/td[10]"));
		for(int i=0;i<list.size();i++) {
			//try {
		//jsClick(list.get(i));
		//	}
		//	catch(org.openqa.selenium.StaleElementReferenceException ex) {
			//	ex.printStackTrace();
				//driver.findElement(By.xpath("//button[@name]/lightning-primitive-icon")).click();
			//	Thread.sleep(1000);
			//	list.get(i).click();
			//}//
		WebElement ele = driver.findElement(By.xpath("//span[@class='slds-icon_container slds-icon-utility-down']"));
		jsClick(ele);
		Thread.sleep(1500);
		driver.findElement(By.xpath(lnkDeletexpath)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(btnDeletexpath)).click();
		Thread.sleep(3500);
		}
		driver.findElement(By.xpath("//button[@title='Show filters']")).click();
		Thread.sleep(1000);
	}
	
	//@Author : Kalam
	//Remove all the filters added
	public void RemveFlterAdded() throws InterruptedException {
	List<WebElement> list =driver.findElements(By.xpath("//a[@class='closeX']"));
	for(int i=0;i<list.size();i++) {
	    try {
		list.get(i).click();
	    }
	    catch(Exception e) {
	        e.printStackTrace();
	        list.get(i).click();  
	    }
		Thread.sleep(500);
	}
	
	driver.findElement(By.xpath("//button[text()='Save']")).click();
	Thread.sleep(2000);
	}
	
	//@Author : Kalam
	//Remove all the filters added after refresh
	public void RemveFlterAdded_Refresh() throws InterruptedException {
	visibleText(By.xpath("//span[text()='Updated a few seconds ago']"));
	driver.findElement(By.xpath("//button[@title='Show filters']")).click();
	Thread.sleep(1000);
	List<WebElement> list =driver.findElements(By.xpath("//a[@class='closeX']"));
	for(int i=0;i<list.size();i++) {
		list.get(i).click();
		Thread.sleep(500);
	}
	
	driver.findElement(By.xpath("//button[text()='Save']")).click();
	Thread.sleep(2000);
	}
	
	//@Author : Kalam
	//Adding filter for Status
	public void NavNEOL2Queue() throws InterruptedException {
	WebElement IcnDownxpath = driver.findElement(By.xpath("//lightning-icon[@class='slds-icon-utility-down slds-button__icon slds-icon_container forceIcon']"));
    jsClick(IcnDownxpath);
	Thread.sleep(1000);
	driver.findElement(By.xpath("//input[@role='combobox'][@aria-owns]")).click();
	Thread.sleep(800);
	driver.findElement(By.xpath("//input[@role='combobox'][@aria-owns]")).sendKeys("Neo L2 Queue");
	Thread.sleep(1200);
	driver.findElement(By.xpath("//mark[text()='Neo L2 Queue']")).click();
	Thread.sleep(2500);
	}
	
	//@Author : Kalam
	//Adding filter for Status
	public void NavNEOL2QueueProd() throws InterruptedException {
	WebElement IcnDownxpath = driver.findElement(By.xpath("//lightning-icon[@class='slds-icon-utility-down slds-button__icon slds-icon_container forceIcon']"));
    jsClick(IcnDownxpath);
	Thread.sleep(1000);
	driver.findElement(By.xpath("//input[@role='combobox'][@aria-owns]")).click();
	Thread.sleep(800);
	driver.findElement(By.xpath("//input[@role='combobox'][@aria-owns]")).sendKeys("Automation Test Queue");
	Thread.sleep(1200);
	driver.findElement(By.xpath("//mark[text()='Automation Test Queue']")).click();
	Thread.sleep(2500);
	}
	
	//@Author : Kalam
	public void FilterbyMyCases() throws InterruptedException {
		visibleText(By.xpath("//span[text()='Updated a few seconds ago']"));
		driver.findElement(By.xpath("//button[@title='Show filters']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//div[text()='Filter by Owner']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//span[text()='My cases']")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath("//span[text()='Done']")).click();
		Thread.sleep(800);
		driver.findElement(By.xpath("//button[text()='Save']")).click();
		Thread.sleep(3500);
	}
	
	//@Author : Kalam
	//Capture the Filter text
	public String CaptureFilterText() {
		String FilterText=driver.findElement(By.xpath("//span[@role='status']")).getText();
		return FilterText;
	}
	
	//@Author : Kalam
	public void SetBackDefault() throws InterruptedException {
		driver.findElement(By.xpath("//div[text()='Filter by Owner']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//span[text()='All cases']")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath("//span[text()='Done']")).click();
		Thread.sleep(800);
		driver.findElement(By.xpath("//button[text()='Save']")).click();
		Thread.sleep(3000);
	}
	
	//@Author : Kalam
	public void AddFilterStatus() throws InterruptedException {
		visibleText(By.xpath("//span[text()='Updated a few seconds ago']"));
	driver.findElement(By.xpath("//button[@title='Show filters']")).click();
	Thread.sleep(1000);
	
	visibleText(By.xpath("//a[text()='Add Filter']"));
	driver.findElement(By.xpath("//a[text()='Add Filter']")).click();
	Thread.sleep(1000);
	
	driver.findElement(By.xpath("//label[text()='Field']/following::button")).click();
	Thread.sleep(800);
	WebElement ele = driver.findElement(By.xpath("//label[text()='Field']/following::span[text()='Status']"));
	scrollIntoView(ele);
	ele.click();
	
	driver.findElement(By.xpath("//div[text()='Value']/following::a")).click();
	Thread.sleep(800);
	WebElement ele1 = driver.findElement(By.xpath("//div[text()='Value']/following::a[text()='Open']"));
	ele1.click();
	WebElement ele2 = driver.findElement(By.xpath("//div[text()='Value']/following::a[text()='Closed']"));
	scrollIntoView(ele2);
	ele2.click();
	driver.findElement(By.xpath("//span[text()='Done']")).click();
	Thread.sleep(1000);
	}
	
	//@Author : Kalam
	public void AddFilterWebEmail(String val) throws InterruptedException {
	visibleText(By.xpath("//span[text()='Updated a few seconds ago']"));
	jsClick(driver.findElement(By.xpath("//button[@title='Show filters']")));
	Thread.sleep(1000);
	
	driver.findElement(By.xpath("//a[text()='Add Filter']")).click();
	Thread.sleep(1000);
	
	driver.findElement(By.xpath("//label[text()='Field']/following::button")).click();
	Thread.sleep(800);
	WebElement ele = driver.findElement(By.xpath("//label[text()='Field']/following::span[text()='Web Email']"));
	scrollIntoView(ele);
	ele.click();
	
	driver.findElement(By.xpath("//span[text()='Value']/following::input")).sendKeys(val);
	Thread.sleep(200);
	driver.findElement(By.xpath("//span[text()='Done']")).click();
	Thread.sleep(1000);
	}
	
	//@Author : Kalam
	//Refresh tab
	public void RefreshCurrentTab() throws InterruptedException {
	driver.findElement(By.xpath(btnDrpdwnxpath)).click();
	Thread.sleep(900);
	
	jsClick(driver.findElement(By.xpath(btnRefreshxpath)));
	Thread.sleep(1500);
	}
	
	//@Author : Kalam
	//Adding filter for Last Modified Date
	public void AddFilterDateTimeOpen() throws InterruptedException {
	driver.findElement(By.xpath("//a[text()='Add Filter']")).click();
	Thread.sleep(1000);
	
	driver.findElement(By.xpath("//label[text()='Field']/following::button")).click();
	Thread.sleep(800);
	WebElement ele3 = driver.findElement(By.xpath("//label[text()='Field']/following::span[text()='Date/Time Opened']"));
	scrollIntoView(ele3);
	ele3.click();
	
	driver.findElement(By.xpath("//label[text()='Operator']/following::button")).click();
	Thread.sleep(800);
	WebElement ele = driver.findElement(By.xpath("//label[text()='Operator']/following::span[text()='greater or equal']"));
	scrollIntoView(ele);
	ele.click();
	
	//DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
	// Date date = new Date();
	 //String date1= dateFormat.format(date);
	 //System.out.println(date1);
	
	 Date date = DateUtils.addDays(new Date(), -1);
	 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	// SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
	// if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
		 driver.findElement(By.xpath("//span[text()='Value']/following::input")).sendKeys(sdf.format(date)); 
	 //}
	//driver.findElement(By.xpath("//span[text()='Value']/following::input")).sendKeys(sdf.format(date));
	Thread.sleep(800);
	
	driver.findElement(By.xpath("//span[text()='Done']")).click();
	Thread.sleep(1000);
	}
	
	//@Author : Kalam
	//Adding filter for Last Modified Date
	public void AddFilterDateTimeOpen_UAT() throws InterruptedException {
	driver.findElement(By.xpath("//a[text()='Add Filter']")).click();
	Thread.sleep(1000);
	
	driver.findElement(By.xpath("//label[text()='Field']/following::button")).click();
	Thread.sleep(800);
	WebElement ele3 = driver.findElement(By.xpath("//label[text()='Field']/following::span[text()='Date/Time Opened']"));
	scrollIntoView(ele3);
	ele3.click();
	
	driver.findElement(By.xpath("//label[text()='Operator']/following::button")).click();
	Thread.sleep(800);
	WebElement ele = driver.findElement(By.xpath("//label[text()='Operator']/following::span[text()='greater or equal']"));
	scrollIntoView(ele);
	ele.click();
	
	//DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
	// Date date = new Date();
	 //String date1= dateFormat.format(date);
	 //System.out.println(date1);
	
	 Date date = DateUtils.addDays(new Date(), -1);
	 SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
	 driver.findElement(By.xpath("//span[text()='Value']/following::input")).sendKeys(sdf1.format(date)); 
	 Thread.sleep(800);
	
	driver.findElement(By.xpath("//span[text()='Done']")).click();
	Thread.sleep(1000);
	}
	
	//@Author : Kalam
	//Adding filter for all owners
		public void AddFilterOwnerName(String Env) throws InterruptedException {
		driver.findElement(By.xpath("//a[text()='Add Filter']")).click();
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//label[text()='Field']/following::button")).click();
		Thread.sleep(800);
		WebElement ele3 = driver.findElement(By.xpath("//label[text()='Field']/following::span[text()='Owner Name']"));
		scrollIntoView(ele3);
		ele3.click();
		
		if(Env.equalsIgnoreCase("UAT")) {
		    driver.findElement(By.xpath("//span[text()='Value']/following::input")).sendKeys("Rakesh Kr Soni, Shashi Kant, Ajit Singh, Jai Saheb, Karthik Kumbar, Neo L2 Queue, Roopa Ashok");
	        Thread.sleep(800); 
		}
		else {
		driver.findElement(By.xpath("//span[text()='Value']/following::input")).sendKeys("Neo L2 Queue, Roopa Ashok, Nandan Kumar, Anoop Kurian Mathew, Priya G S, Sheela Gangadhar, Mohammed sheriff, Renitta Jaison, Arnab Mondal, Rakesh Kr Soni, Ajit Singh, Anushka Priya, Jai Saheb");
		Thread.sleep(800);
		}
		
		driver.findElement(By.xpath("//span[text()='Done']")).click();
		Thread.sleep(1000);
		}
		
		//@Author : Kalam
		//Adding filter for Parent Case Number
		public void AddFilterParentCaseNo() throws InterruptedException {
		driver.findElement(By.xpath("//a[text()='Add Filter']")).click();
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//label[text()='Field']/following::button")).click();
		Thread.sleep(800);
		WebElement ele3 = driver.findElement(By.xpath("//label[text()='Field']/following::span[text()='Parent Case Number']"));
		scrollIntoView(ele3);
		ele3.click();
		
		driver.findElement(By.xpath("//label[text()='Operator']/following::button")).click();
		Thread.sleep(800);
		WebElement ele = driver.findElement(By.xpath("//label[text()='Operator']/following::span[text()='less or equal']"));
		scrollIntoView(ele);
		ele.click();
		
		driver.findElement(By.xpath("//span[text()='Value']/following::input")).sendKeys("0");
		Thread.sleep(800);
		
		driver.findElement(By.xpath("//span[text()='Done']")).click();
		Thread.sleep(1000);
		}	
		
		//@Author : Kalam
		//Click Rentention first call for Rentention user
		public void ClickRetentionFirstCall() throws InterruptedException {
			//WebElement ele = driver.findElement(By.xpath("//span[text()='Open Activities']"));
			//Actions ac=new Actions(driver);
			//ac.moveToElement(ele).build().perform();
			//jsClick(ele);
			Scrollpagedown();
			jsClick(driver.findElement(By.xpath("//div[text()='Case']/following::span[text()='Open Activities']/following::a[text()='Retention - First Call']")));
			Thread.sleep(2000);
		}
	
		//@Author : Kalam
	//To click on Save Button
	public void ClickSave() throws InterruptedException {
	driver.findElement(By.xpath("//button[text()='Save']")).click();
	Thread.sleep(2000);
	}
	
	//@Author : Kalam
	//Click created case from Unregistered Email
	public void ClickUnregisEmailCase(String val) throws InterruptedException {
		jsClick(driver.findElement(By.xpath("//span[text()='Cases']/following::span[text()='Subject']/following::a[text()='"+val+"']")));
		Thread.sleep(1000);
	}
	
	//@Author : Kalam
	//Capture Account Name
	public String CaptureAccountName() throws InterruptedException {
		//visibleText(By.xpath("//div[text()='Case']/following::span[text()='Account Name']"));
		String AccountName =driver.findElement(By.xpath("//div[text()='Case']/following::span[text()='Account Name']/following::slot[@force-lookup_lookup]")).getText();
		return AccountName;
	}
	//div[text()='Case']/following::span[text()='Payment']/following::span[@id]
	
	//@Author : Kalam
    //Capture Payment number
    public String CapturePaymentNumer() throws InterruptedException {
        visibleText(By.xpath("//div[text()='Case']/following::span[text()='Payment']"));
        return driver.findElement(By.xpath("//div[text()='Case']/following::span[text()='Payment']/following::a/slot/slot/span")).getText();
         
    }
    
    //@Author : Kalam
    //Capture EMI Amount
    public String CaptureEMIAmount() throws InterruptedException {
        
        return driver.findElement(By.xpath("//div[text()='Case']/following::span[text()='EMI Amount']/following::lightning-formatted-number[1]")).getText();
         
    }
    
    //@Author : Kalam
    //Capture Loan Amount
    public String CaptureLoanAmount() throws InterruptedException {
        
        return driver.findElement(By.xpath("//div[text()='Case']/following::span[text()='Loan Amount']/following::lightning-formatted-text[1]")).getText().replaceAll("₹","");
         
    }
    
    //@Author : Kalam
    //Capture PremiumId 
    public String CapturePremiumid() throws InterruptedException {
        Scrollpagedown();
        return driver.findElement(By.xpath("//div[text()='Case']/following::span[text()='PremiumId']/following::lightning-formatted-text[1]")).getText();
         
    }
    
    //@Author : Kalam
    //Capture Account Owner 
    public String CaptureAccountOwner() throws InterruptedException {
        
        return driver.findElement(By.xpath("//div[text()='Case']/following::span[text()='Account Owner']/following::lightning-formatted-text[1]")).getText();
         
    }
    
    //@Author : Kalam
    //Capture Account Name 
    public String CaptureCaseAccountName() throws InterruptedException {
        
        return driver.findElement(By.xpath("//div[text()='Case']/following::span[text()='Account Name']/following::a/slot/slot/span")).getText();
         
    }
    
    //@Author : Kalam
    //Capture Program Name 
    public String CaptureProgramName() throws InterruptedException {
        
        return driver.findElement(By.xpath("//div[text()='Case']/following::span[text()='Program Name']/following::lightning-formatted-text[1]")).getText();
         
    }
    
	//@Author : Kalam
	//To capture the Record Count in queue
	public String[] RecrdCnt() throws InterruptedException {
	Thread.sleep(1000);	
	String[] RecordCount=driver.findElement(By.xpath("//span[@class='countSortedByFilteredBy']")).getText().split(" item");
	System.out.println(RecordCount[0]);
	Thread.sleep(2000);
	return RecordCount;
	}
	
	//@Author : Kalam
	//Capture the Case Record number
	public String CaseRN() {
	String CaseNumber= driver.findElement(By.xpath("//span/a[@data-refid]")).getText();
	return CaseNumber;
	}
	
	//@Author : Kalam
	//Click On Case option
	public void CaseOptnSel() throws InterruptedException {
	driver.findElement(By.xpath("//span/a[@data-refid]")).click();
	Thread.sleep(3000);
	}
	
	//@Author : Kalam
    //Click On Case option
    public void SelectCaseBySubject(String IssueType,String IssueSubtype) throws InterruptedException {
    driver.findElement(By.xpath("//span[text()='Cases']/following::th[@title='Subject']/following::td/span/a[text()='"+IssueType+"_"+IssueSubtype+"']")).click();
    Thread.sleep(2000);
    }
	
	//@Author : Kalam
	//Check for DP to be Refunded to Wallet
    public void CheckInwardTeamUpdate() {
        List<WebElement> list=driver.findElements(By.xpath("//tr/following::td[5]/span/a"));
        for(int i=0;i<list.size();i++) {
            if(list.get(i).getText().equalsIgnoreCase("Inward Team Update")) {
                list.get(i).click();
            }
        }
    }
	
  //@Author : Kalam
	//Check for DP to be Refunded to Wallet
	public void CheckDPRefdWall() {
		List<WebElement> list=driver.findElements(By.xpath("//tr/following::td[5]/span/a"));
		for(int i=0;i<list.size();i++) {
			if(list.get(i).getText().equalsIgnoreCase("DP to be Refunded to Wallet")) {
				list.get(i).click();
			}
		}
	}
	
	//@Author : Kalam
	//Check for DP to be Refunded to Wallet
	public void CheckOARefdWall() {
		List<WebElement> list1=driver.findElements(By.xpath("//tr/following::td[5]/span/a"));
		for(int m=0;m<list1.size();m++) {
			if(list1.get(m).getText().equalsIgnoreCase("Other Amount To Be Refunded To Wallet")) {
				list1.get(m).click();
			}
		}
	}
	
	//@Author : Kalam
	//Check for Other Amount to be Refunded
    public void CheckOARefBank() {
        List<WebElement> list1=driver.findElements(By.xpath("//tr/following::td[5]/span/a"));
        for(int m=0;m<list1.size();m++) {
            if(list1.get(m).getText().contains("Other Amount To Be Refunded")) {
                list1.get(m).click();
            }
        }
    }
	
  //@Author : Kalam
	//Check for case subject
	public void CheckCaseSubject(String val) {
		List<WebElement> list=driver.findElements(By.xpath("//tr/following::td[5]/span/a[text()='"+val+"']"));
		for(int i=0;i<list.size();i++) {
				list.get(i).click();
			}
		}
	
	//@Author : Kalam
	//Check for case subject with refresh
			public void CheckCaseSubject_refresh(String val) throws Exception {
			Thread.sleep(5000);
		    int i = 1;
			while(i<=5) {
				driver.navigate().refresh();
				Thread.sleep(3000);
				List<WebElement> Statuses = driver.findElements(By.xpath("//tr/following::td[5]/span/a[text()='"+val+"']"));
				if(Statuses.size()==1) {
					Statuses.get(0).click();
					 System.out.println("Case found with status as "+val+"");
					 break; 
				    	
				 }
				 else {
					 Thread.sleep(5000);
					 if(i==5) {
						 System.out.println("Case not found with status as "+val+"");
						
					 }
				 }
				 i++;
			}
			}
	
	
	//@Author : Kalam
	//Capture Case for DP
	public String CaptureCaseNoDP() throws InterruptedException {
		String CaseNumberfrDP= driver.findElement(By.xpath("//lightning-formatted-text[contains(text(),'DP to be')]/following::p[text()='Case Number']/following::lightning-formatted-text")).getText();
		Thread.sleep(700);
		return CaseNumberfrDP;

	}
	
	//@Author : Kalam
	//Capture Case for DP
    public String CaptureCaseNoInwardTeamUpdate() throws InterruptedException {
        String CaseNumberfrDP= driver.findElement(By.xpath("//lightning-formatted-text[contains(text(),'Inward Team Update')]/following::p[text()='Case Number']/following::lightning-formatted-text")).getText();
        Thread.sleep(700);
        return CaseNumberfrDP;

    }
	
    //@Author : Kalam
	//Capture Case owner detail
	public String CaptureCaseOwnerDP() throws InterruptedException {
		String Owner=driver.findElement(By.xpath("//lightning-formatted-text[contains(text(),'DP to be')]/following::span[text()='Case Owner']/following::slot[@force-lookup_lookup]")).getText();
		Thread.sleep(700);
		return Owner;

	}
	
	//@Author : Kalam
	//Capture Parent Case detail
	public String CaptureParentCaseOwnerDP() throws InterruptedException {
		String ParentCase=driver.findElement(By.xpath("//lightning-formatted-text[contains(text(),'DP To Be')]/following::span[text()='Parent Case']/following::slot[@force-lookup_lookup]/span | //lightning-formatted-text[contains(text(),'DP to be')]/following::span[text()='Parent Case']/following::slot[@force-lookup_lookup]/span")).getText();
		//Thread.sleep(700);
		return ParentCase;

	}
	
	//@Author : Kalam
	//Capture Case for Other Amount
	public String CaptureCaseNoOA() throws InterruptedException {
		String CaseNumberfrOA= driver.findElement(By.xpath("//lightning-formatted-text[contains(text(),'Other Amount To Be')]/following::p[text()='Case Number']/following::lightning-formatted-text")).getText();
		Thread.sleep(700);
		return CaseNumberfrOA;
		
	}
	
	//@Author : Kalam
	//Capture Case owner detail OA
	public String CaptureCaseOwnerOA() throws InterruptedException {
		String Owner1=driver.findElement(By.xpath("//lightning-formatted-text[contains(text(),'Other Amount To Be')]/following::span[text()='Case Owner']/following::slot[@force-lookup_lookup]")).getText();
		Thread.sleep(700);
		return Owner1;

	}
	
	//@Author : Kalam
	//Capture Case owner
	public String CaptureCaseOwner() throws InterruptedException {
	    visibleText(By.xpath("//div[text()='Case']"));
		String Owner1=driver.findElement(By.xpath("//div[text()='Case']/following::span[text()='Case Owner']/following::a//span")).getText();
		Thread.sleep(700);
		return Owner1;

	}
	
    // @Author : Kalam
    // Change or set the Assigned To
    public void ChangeAssignedTo(String val) throws InterruptedException {
        scrollIntoView(driver.findElement(By.xpath("//span[text()='Assigned To']")));
        jsClick(driver.findElement(By.xpath("//span[text()='Assigned To']/following::button[1]")));
        Thread.sleep(1000);
        visibleText(By.xpath("//div[text()='Case']/following::label[text()='Assigned To']"));
        driver.findElement(By.xpath("//div[text()='Case']/following::label[text()='Assigned To']/following::input[1]")).sendKeys(val);
        Thread.sleep(2000);
        
        driver.findElement(By.xpath("//label[text()='Assigned To']/following::span[@class='slds-media__body']/span/lightning-base-combobox-formatted-text[@title='"+val+"']")).click();
        Thread.sleep(1000);

    }
	
	//@Author : Kalam
	//Capture Task owner
	public void ClickTaskOwner() throws InterruptedException {
	    try {
		jsClick(driver.findElement(By.xpath("//div[text()='Case']/following::span[text()='Activity History']/following::div[text()='Assigned To:']/following::a")));
	    }
	    catch(Exception e) {
	        Scrollpagedown();
	        Scrollpagedown();
	        jsClick(driver.findElement(By.xpath("//div[text()='Case']/following::span[text()='Activity History']/following::div[text()='Assigned To:']/following::a")));
	    }
	}
	
	//@Author : Kalam
    //Capture Status value
    public String CaptureSuperStatus() throws InterruptedException {
        String Status=driver.findElement(By.xpath("//div[text()='Case']/following::p[text()='Super Status']/following::lightning-formatted-text")).getText();
        return Status;

    }
	
	//@Author : Kalam
	//Capture Status value
	public String CaptureStatus() throws InterruptedException {
		String Status=driver.findElement(By.xpath("//div[text()='Case']/following::p[text()='Status']/following::lightning-formatted-text")).getText();
		return Status;

	}
	
	//@Author : Kalam
    //Capture Assigned To value
    public String CaptureAssignedTo() throws InterruptedException {
        return driver.findElement(By.xpath("//div[text()='Case']/following::p[text()='Assigned To']/following::a/slot/slot/span")).getText();
        
    }
    
    //@Author : Kalam
    //Capture Assigned To value
    public String CapturePendingOn() throws InterruptedException {
        return driver.findElement(By.xpath("//div[text()='Case']/following::p[text()='Pending On(User)']/following::a/slot/slot/span")).getText();
        
    }
    
    //@Author : Kalam
    //Capture Assigned To value
    public void SelectTaskOpenActivities(String val) throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//div[text()='Case']/following::span[text()='Open Activities'][1]/following::a[text()='"+val+"']")));
        

    }
	
	//@Author : Kalam
	//Change Status value
	public void ChangeStatusValue(String val) throws InterruptedException {
	    Thread.sleep(500);
	    jsClick(driver.findElement(By.xpath("//div[text()='Case']/following::span[text()='Status']/following::button")));
	    Thread.sleep(1000);
	    visibleText(By.xpath("//div[text()='Case']/following::label[text()='Status']"));
	    Thread.sleep(500);
	    jsClick(driver.findElement(By.xpath("//div[text()='Case']/following::label[text()='Status']/following::button")));
	    Thread.sleep(500);
	    jsClick(driver.findElement(By.xpath("//div[text()='Case']/following::label[text()='Status']/following::span[text()='"+val+"']")));
	}
	
	//@Author : Kalam
    //Change Case Origin value
    public void ChangeCaseOrigin(String val) throws InterruptedException {
        visibleText(By.xpath("//div[text()='Case']/following::label[text()='Case Origin']"));
        Thread.sleep(500);
        jsClick(driver.findElement(By.xpath("//div[text()='Case']/following::label[text()='Case Origin']/following::button")));
        Thread.sleep(500);
        jsClick(driver.findElement(By.xpath("//div[text()='Case']/following::label[text()='Case Origin']/following::span[text()='"+val+"']")));
    }
    
    //@Author : Kalam
    //Change Action Taken By
    public void ChangeActionTakenBy(String val) throws InterruptedException {
        visibleText(By.xpath("//div[text()='Case']/following::label[text()='Action Taken By']"));
        Thread.sleep(500);
        jsClick(driver.findElement(By.xpath("//div[text()='Case']/following::label[text()='Action Taken By']/following::button")));
        Thread.sleep(500);
        jsClick(driver.findElement(By.xpath("//div[text()='Case']/following::label[text()='Action Taken By']/following::span[text()='"+val+"']")));
    }
    
    //@Author : Kalam
    //Enter Resolution Responsibility
    public void EnterResolutionResponsibility(String val) throws InterruptedException {
        visibleText(By.xpath("//div[text()='Case']/following::label[text()='Resolution Responsibility']"));
        Thread.sleep(500);
        jsClick(driver.findElement(By.xpath("//div[text()='Case']/following::label[text()='Resolution Responsibility']/following::input")));
        Thread.sleep(500);
        driver.findElement(By.xpath("//div[text()='Case']/following::label[text()='Resolution Responsibility']/following::input")).sendKeys(val);
        Thread.sleep(500);
    }
    
    //@Author : Kalam
    //Enter Reason for Closing
    public void EnterReasonforClosing(String val) throws InterruptedException {
        visibleText(By.xpath("//div[text()='Case']/following::label[text()='Reason For Closing']"));
        Thread.sleep(500);
        jsClick(driver.findElement(By.xpath("//div[text()='Case']/following::label[text()='Reason For Closing']/following::input")));
        Thread.sleep(500);
        driver.findElement(By.xpath("//div[text()='Case']/following::label[text()='Reason For Closing']/following::input")).sendKeys(val);
        Thread.sleep(500);
    }
	
	//@Author : Kalam
	//Capture Status value
	public String CaptureReopenCount() throws InterruptedException {
	    Thread.sleep(800);
		String Status=driver.findElement(By.xpath("//span[text()='Reopen Count']/following::lightning-formatted-number")).getText();
		return Status;

	}
	
	
	//@Author : Kalam
	//Verify Status changed from Closed to Open
		public void StatusChangeCheck() throws Exception {
		Thread.sleep(5000);
	    int i = 1;
		while(i<=9) {
			driver.navigate().refresh();
			Thread.sleep(5000);
			String Status = driver.findElement(By.xpath("//div[text()='Case']/following::p[text()='Status']/following::lightning-formatted-text")).getText();
			 if(Status.contains("Open")) {
				 
				 System.out.println("Status change was successfull");
				 break; 
			    	
			 }
			 else {
				 Thread.sleep(5000);
				 if(i==9) {
					 System.out.println("Status change failed");
					
				 }
			 }
			 i++;
		}
		}
	
	//@Author : Kalam
	//Verify Email Request_Cancellation Request_Auto task is created 
	public boolean VerifyEmailReqCancelTask() throws InterruptedException {
		List<WebElement> list=driver.findElements(By.xpath("//div[text()='Case']/following::span[text()='Open Activities']/following::article//a[text()='Email Request_Cancellation Request_Auto'] | //div[text()='Case']/following::span[text()='Open Activities']/following::article//a[text()='Email_Request_Refund Request Update_Auto']"));
		if(list.size()==1) {
			return true;
		}
		else {
			return false;
		}

	}
	
	//@Author : Kalam
	//Close all cases open
	public void CloseAllCases() throws InterruptedException {
		visibleText(By.xpath("//h1[text()='Cases']"));
		List<WebElement> Closebutton=driver.findElements(By.xpath("//tr/td[6]"));
		for(int n=0;n<Closebutton.size();n++) {
			WebElement ele= driver.findElement(By.xpath("//h1[text()='Cases']/following::span[@class='slds-icon_container slds-icon-utility-down']"));
			Thread.sleep(200);
			try {
			clickButton(ele);
			Thread.sleep(500);
			}
			catch(Exception e) {
			    e.printStackTrace();
			    jsClick(ele);
			    Thread.sleep(500);
			}
			Thread.sleep(1000);
			jsClick(driver.findElement(By.xpath("//a[@title='Delete']")));
			Thread.sleep(1000);
			driver.findElement(By.xpath("//button/span[text()='Delete']")).click();
			Thread.sleep(2000);
		}
	}
	
	//@Author : Kalam
	//Recently viewed
	public void RecentlyViewedlist() throws InterruptedException {

		WebElement IcnDownxpath = driver.findElement(By.xpath("//lightning-icon[@class='slds-icon-utility-down slds-button__icon slds-icon_container forceIcon']"));
	    jsClick(IcnDownxpath);
		Thread.sleep(1000);
		driver.findElement(By.xpath("//ul/following::span[text()='Recently Viewed']")).click();
		Thread.sleep(2000);
	}
	
	//@Author : Kalam
	//Click Related Tab on cases

	public void ClickRelatedTab() throws InterruptedException {

		jsClick(driver.findElement(By.xpath("//a[@data-label='Related']")));
		Thread.sleep(1000);
	}
	
	//@Author : Kalam
    //Navigate to Open CSO:Order

    public void NavigateCSOOrder() throws InterruptedException {

        jsClick(driver.findElement(By.xpath("//div[text()='Case']/following::button[contains(@class,'icon-border-filled')]")));
        Thread.sleep(1000);
        jsClick(driver.findElement(By.xpath("//div[text()='Case']/following::span[contains(text(),'Open CSO: Order')]")));
        Thread.sleep(1000);
    }
    
    // @Author : Kalam
    // Changing the Owner
    public void ChangeCaseOwner(String val) throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//span[text()='Case Owner']/following::button[@title='Change Owner']")));
        Thread.sleep(3000);

        driver.findElement(By.xpath("//h2[text()='Change Case Owner']/following::input[@role='combobox']")).sendKeys(val);
        Thread.sleep(2000);

        jsClick(driver.findElement(By.xpath("//div[@title='"+val+"']")));
        Thread.sleep(800);

        
        driver.findElement(By.xpath("//button[text()='Change Owner']")).click();
        Thread.sleep(3000);

    }
    
    // @Author : Kalam
    // Changing the Owner
    public void RemovePendingOnUser() throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//div[text()='Case']/following::span[text()='Pending On(User)']/following::button[contains(@title,'Edit Pending')]")));
        Thread.sleep(1000);
        visibleText(By.xpath("//div[text()='Case']/following::label[text()='Pending On(User)']"));
        Thread.sleep(500);
        jsClick(driver.findElement(By.xpath("//div[text()='Case']/following::label[text()='Pending On(User)']/following::lightning-primitive-icon[@lightning-basecombobox_basecombobox]")));
        Thread.sleep(500);
    }
    
    // @Author : Kalam
    // Changing the Owner
    public void ChangePendingOnUser(String val) throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//div[text()='Case']/following::span[text()='Pending On(User)']/following::button[1]")));
        Thread.sleep(1000);
        visibleText(By.xpath("//div[text()='Case']/following::label[text()='Pending On(User)']"));
        driver.findElement(By.xpath("//div[text()='Case']/following::label[text()='Pending On(User)']/following::input[1]")).sendKeys(val);
        Thread.sleep(2000);
        
        driver.findElement(By.xpath("//label[text()='Pending On(User)']/following::span[@class='slds-media__body']/span/lightning-base-combobox-formatted-text[@title='"+val+"']")).click();
        Thread.sleep(1000);

    }
    
    // @Author : Kalam
    // Changing the Owner
    public void ClickCaseOwner() throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//div[text()='Case']/following::span[text()='Case Owner']/following::a")));
        Thread.sleep(1000);

    }
    
    // @Author : Kalam
    // Click Case Number
    public void ClickCaseNo(String val) throws InterruptedException {
        visibleText(By.xpath("//th[1]/span[1]/a[@title='"+val+"']"));
        jsClick(driver.findElement(By.xpath("//th[1]/span[1]/a[@title='"+val+"']")));
        Thread.sleep(1000);

    }
	
    // @Author : Kalam
    // Click BTC Milestone
    public void ClickBTCMilestone() throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//div[text()='Case']/following::span[text()='Milestones']/following::a[@title='BTC Milestone'][last()]")));
        Thread.sleep(1000);

    }
    
    // @Author : Kalam
    // Capture Target Response Time
    public String CaptureTargetResponseTime() throws InterruptedException {
        visibleText(By.xpath("//div[text()='Case Milestone']/following::span[text()='Target Response (Mins)']"));
        Thread.sleep(500);
        return driver.findElement(By.xpath("//div[text()='Case Milestone']/following::span[text()='Target Response (Mins)']/following::span[1]/span")).getText().replaceAll(",", "");
        
    }
    
	//@Author : Kalam
	// Scroll element to view
	public void scrollIntoView(WebElement element) {
		try {
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("arguments[0].scrollIntoView(true);", element);
			System.out.println("Page scrolled down");
		} catch (Exception e){
			System.out.println("=============================================================");
			System.out.println("Exception-scrollIntoView(): "+e.getMessage());
			takeScreenShot();
			e.printStackTrace();
			System.out.println("=============================================================");
		}    
	}
	
	
	//@Author : Kalam
    public void closeTabWindows() throws InterruptedException {
		List<WebElement> list= driver.findElements(By.xpath("//ul[@class='tabBarItems slds-grid']//div[@class='close slds-col--bump-left slds-p-left--none slds-context-bar__icon-action ']"));
		if (list.size() == 0) {
			System.out.println("There are no open tabs");
		} else {
			for (int i = 0; i < list.size(); i++) {
				try {
				list.get(i).click();
				Thread.sleep(500);
				}
				catch(Throwable t) {
					System.out.println("More tabs on page loaded later");
					t.printStackTrace();
				}
			}
		}
    }

        //@Author : Kalam
	    public void jsClick(WebElement el) {
			try {
				JavascriptExecutor jse = (JavascriptExecutor)driver;
				jse.executeScript("arguments[0].click();", el);
				System.out.println("Element clicked");
			} catch (Exception e){
				System.out.println("=============================================================");
				System.out.println("Exception-jsClick(): "+e.getMessage());
				//takeScreenShot();
				e.printStackTrace();
				System.out.println("=============================================================");
			}
		}
	    
	  //@Author : Kalam
	    public void clickButton(WebElement element)
		{
			WebDriverWait wait= new WebDriverWait(driver, 100);
			
			wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));
			
			System.out.println("Element is clickable");
			element.click();
		}
	    
	  //@Author : Kalam
		public boolean visibleText(By element)
		{
			WebDriverWait wait= new WebDriverWait(driver, 100);
			
			wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));
			
			System.out.println("Element is visible");
			return false;
		}
		
        // @Author : Kalam
        public void Scrollpagedown() throws InterruptedException {

            driver.findElement(tag).sendKeys(Keys.PAGE_DOWN);
            Thread.sleep(1200);
        }
        
        // @Author : Kalam
        public void Scrollhome() throws InterruptedException {

            driver.findElement(tag).sendKeys(Keys.HOME);
            Thread.sleep(1200);
        }
		
		//**************************************************Manish Methods*****************************************************
		
		//Author :: Manish
		public static List<WebElement> rowsCases(WebDriver driver)
		{
		return driver.findElements(By.xpath("//table[@aria-label='Cases']/tbody/tr"));
		}
		
		//Author :: Manish
		public static WebElement fieldCase(WebDriver driver,int i)
		{
		    return driver
                    .findElement(By.xpath("//table[@aria-label='Cases']/tbody/tr[" + i + "]/td[5]/span/a"));
		}
		
		//**************************************************Manali Methods*****************************************************

        private String btnTakeAction = "//button[text()='Take Action']";
        private String txtSubject = "//span[text()='Task Information']/following::span[text()='Subject']/following::span/span";
        private String txtType = "//span[text()='Task Information']/following::span[text()='Type']/following::span/span";
        private String lnkRelatedTo = "//span[text()='Task Information']/following::span[text()='Related To']/following::a";
        private String txtAssignedTo = "//span[text()='Task Information']/following::span[text()='Assigned To']/following::a";
        private String txtStatus = "//span[text()='Task Information']/following::span[text()='Status']/following::span/span";
        private String btnEdit = "//a[@title='Edit']";
        private String txtNoAccess = "//p[@class='detail']/span";
        private String btnClose = "//button[@title='Close this window']";
        private String editStatus = "//span[text()='Task Information']/following::span[text()='Status']/following::span/span/following::button[@title='Edit Status']";
        private String drpdwnStatusEdit = "//span[text()='Status']/following::a[text()='Open']";
        private String closeSubTab = "//div[@class='close slds-col--bump-left slds-p-left--none slds-p-right--none ']";
        private String smsTaskName = "//a[text()='SMS Sent - MessageForCaseBeingClosed']";
        private String txtSmsSent = "//span[text()='Task Record Type']/following::span//span";
        private String comments = "//span[text()='Task Information']/following::span[text()='Comments']/following::span/span";

        // easy pay collection Case owner @manali shivareddy

        public String easyPayCaseOwner() throws InterruptedException {
            try {
            String Owner = driver.findElement(By.xpath("//slot[text()='CGR-Digital Finance']")).getText();
            Thread.sleep(700);
            return Owner;
            }
            catch(Exception e) {
                
               driver.get(driver.getCurrentUrl());
               Thread.sleep(2000);
               Scrollhome();
               Thread.sleep(1000);
               String Owner = driver.findElement(By.xpath("//slot[text()='CGR-Digital Finance']")).getText();
                Thread.sleep(700);
                return Owner;
            }

        }

        // easy pay collection Case owner under @manali shivareddy

        public String getEasyPayCaseOwnerDetailsSection() throws InterruptedException {
            visibleText(By.xpath("//span[text()='Case Owner']/following::slot/span"));
            String Owner = driver.findElement(By.xpath("//span[text()='Case Owner']/following::slot/span")).getText();
            Thread.sleep(700);
            return Owner;
        }

        // to get case age @manali shivareddy

        public String getCaseAge() throws InterruptedException {
            String caseAge = driver
                    .findElement(By.xpath("//span[text()='Case Age']/following::slot/lightning-formatted-number"))
                    .getText();
            Thread.sleep(700);
            return caseAge;
        }

        // Icon to change the easy Pay Case Owner
        public void easyPayCaseOwnerChangeIcon() throws InterruptedException {
            jsClick(driver
                    .findElement(By.xpath("//slot[text()='CGR-Digital Finance']/following::lightning-button-icon")));
            Thread.sleep(1000);
        }

        // easy pay collection 'Created By' @manali shivareddy

        public String createdBy() throws InterruptedException {
            visibleText(
                    By.xpath("//div[text()='Case']/following::span[text()='Created By']/following::a/slot/slot/span"));
            String Owner = driver
                    .findElement(By.xpath(
                            "//div[text()='Case']/following::span[text()='Created By']/following::a/slot/slot/span"))
                    .getText();
            Thread.sleep(700);
            return Owner;
        }
        // Change Case Owner ,search users field @manali shivareddy

        public void easyPaySearchUsersField(String val) throws InterruptedException {
            visibleText(By.xpath("//input[@role='combobox']"));
            WebElement input = driver.findElement(By.xpath("//input[@role='combobox']"));
            jsClick(input);
            Thread.sleep(1000);
            input.sendKeys(val);
            Thread.sleep(4000);
            input.sendKeys(Keys.ARROW_DOWN);
            input.sendKeys(Keys.RETURN);
        }
        // Change Owner button @manali shivareddy

        public void easyPayChangeOwnerbtn() throws InterruptedException {
            jsClick(driver.findElement(By.xpath("//button[@name='change owner']")));
            Thread.sleep(1000);
        }
        // Click on Take Action button @manali shivareddy

        public void easyPayTakeActionbtn() throws InterruptedException {
            jsClick(driver.findElement(By.xpath(btnTakeAction)));
            Thread.sleep(1000);
        }
        // Select 'Resolved' radio button @manali shivareddy

        public void radiobtnResolved(String val) throws InterruptedException {
            jsClick(driver
                    .findElement(By.xpath("//span[@class='slds-radio_faux']/following::span[text()='" + val + "']")));
            Thread.sleep(1000);
        }

        // Enter Resolution Comments @manali shivareddy

        public void EnterResolutionComments(String val) throws InterruptedException {
            driver.findElement(By.xpath("//input[@name='Resolution_Comments']")).sendKeys(val);
            Thread.sleep(1000);
        }
        // Enter Resolution Comments @manali shivareddy

        public void EnterClarificationReq(String val) throws InterruptedException {
            driver.findElement(By.xpath("//input[@name='Clarification_Required_On']")).sendKeys(val);
            Thread.sleep(1000);
        }
        // To get open activity task name @manali shivareddy

        public String easyPayOpenActivityTask() throws InterruptedException {
            Thread.sleep(700);
            String task = driver.findElement(By.xpath("//a[@data-refid='recordId'][contains(text(),'Your')]"))
                    .getText();
            Thread.sleep(700);
            return task;
        }
        // To get open activity task name @manali shivareddy

        public void ClickEasyPayOpenActivityTask() throws InterruptedException {
            jsClick(driver.findElement(By.xpath("//a[@data-refid='recordId'][contains(text(),'Your')]")));
            Thread.sleep(700);
        }
        // To get subject of easy pay open activity task @manali shivareddy

        public String easyPayTaskSubj() throws InterruptedException {
            String easyPayTaskSubjct = driver.findElement(By.xpath(txtSubject)).getText();
            Thread.sleep(700);
            return easyPayTaskSubjct;
        }
        // To get 'Type' of easy pay open activity task @manali shivareddy

        public String easyPayTaskType() throws InterruptedException {
            String easyPayTaskType = driver.findElement(By.xpath(txtType)).getText();
            Thread.sleep(700);
            return easyPayTaskType;
        }
        // To get 'Related To' of easy pay open activity task @manali shivareddy

        public String easyPayTaskRelatedToTxt() throws InterruptedException {
            String easyPayTaskRelatedToTxt = driver.findElement(By.xpath(lnkRelatedTo)).getText();
            Thread.sleep(700);
            return easyPayTaskRelatedToTxt;
        }
        // To get 'Related To' of easy pay open activity task @manali shivareddy

        public String easyPayTaskAssignedTo() throws InterruptedException {
            String easyPayTaskAssignedTo = driver.findElement(By.xpath(txtAssignedTo)).getText();
            Thread.sleep(700);
            return easyPayTaskAssignedTo;
        }
        // To get 'Status' of easy pay open activity task @manali shivareddy

        public String easyPayTaskStatus() throws InterruptedException {
            Thread.sleep(700);
            String easyPayTaskStatus = driver.findElement(By.xpath(txtStatus)).getText();
            Thread.sleep(700);
            return easyPayTaskStatus;
        }

        // To click 'Edit' of easy pay open activity task @manali shivareddy

        public void easyPayTaskEdit() throws InterruptedException {
            driver.findElement(By.xpath(btnEdit)).click();
            Thread.sleep(700);
        }
        // To get 'Status' of easy pay open activity task @manali shivareddy

        public String easyPayTaskNoAccess() throws InterruptedException {
            String easyPayTaskNoAccess = driver.findElement(By.xpath(txtNoAccess)).getText();
            Thread.sleep(700);
            return easyPayTaskNoAccess;
        }
        // To close the alert message @manali shivareddy

        public void easyPayMsgClose() throws InterruptedException {
            driver.findElement(By.xpath(btnClose)).click();
            Thread.sleep(700);
        }
        // To edit status @manali shivareddy

        public void easyPayEditStatus() throws InterruptedException {
            driver.findElement(By.xpath(editStatus)).click();
            Thread.sleep(700);
        }
        // To select 'Completed' status from dropdown @manali shivareddy

        public void easyPaySelectStatus(String val) throws InterruptedException {
            jsClick(driver.findElement(By.xpath(drpdwnStatusEdit)));
            Thread.sleep(2000);
            WebElement a6 = driver.findElement(By.xpath("//span[text()='Status']/following::a[text()='" + val + "']"));
            scrollIntoView(a6);
            a6.click();
            Thread.sleep(700);
        }
        // To click on save @manali shivareddy

        public void btnSaveEasyPay() throws InterruptedException {
            driver.findElement(By.xpath("//button/span[text()='Save']")).click();
            Thread.sleep(4000);
        }
        // Switch to the frame @manali shivareddy

        public void switchToTheFrame() throws Exception {
            Thread.sleep(1000);
            retryForDetachedFrame(driver, "//iframe[@title='accessibility title']", 0);
            WebElement frame = driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
            Thread.sleep(1000);
            driver.switchTo().frame(frame);
            Thread.sleep(800);
        }
        // close sub tab @manali shivareddy

        public void clickCloseSubTab() throws InterruptedException {
            driver.findElement(By.xpath(closeSubTab)).click();
            Thread.sleep(4000);
        }
        // to get case owner @manali shivareddy

        public String getCaseOwnerEasypay() throws InterruptedException {
            String caseOwner;
            try {
                caseOwner= driver.findElement(By.xpath("//span[text()='Case Owner']/following::slot/span"))
                    .getText();
            }
            catch(Exception e) {
                Scrollhome();
                caseOwner= driver.findElement(By.xpath("//span[text()='Case Owner']/following::slot/span"))
                .getText();
            }
             
            Thread.sleep(1500);
            return caseOwner;
        }
        // verify SMS closed task @manali shivareddy

        public String verifySmsClosedTask() throws InterruptedException {
            String task = driver.findElement(By.xpath(smsTaskName)).getText();
            Thread.sleep(2000);
            return task;
        }
        // Open SMS closed task @manali shivareddy

        public void clickSmsClosedTask() throws InterruptedException {
            jsClick(driver.findElement(By.xpath(smsTaskName)));
            Thread.sleep(4000);
        }
        // To get easy pay 'task record type' @manali shivareddy

        public String verifyTaskRecordType() throws InterruptedException {
            String task = driver.findElement(By.xpath(txtSmsSent)).getText();
            Thread.sleep(2000);
            return task;
        }
        // To get easy pay 'comments' @manali shivareddy

        public String verifySmsComments() throws InterruptedException {
            String task = driver.findElement(By.xpath(comments)).getText();
            Thread.sleep(2000);
            return task;
        }
        // To get easy pay 'details status' @manali shivareddy

        public String getDetailsStatus() throws InterruptedException {
            String detailsStatus = driver.findElement(By.xpath(
                    "//div[text()='Case']/following::div/span[text()='Status']/following::lightning-formatted-text"))
                    .getText();
            Thread.sleep(2000);
            return detailsStatus;
        }
        // click staus dropdown @manali shivareddy

        public void clickDetailsStatusEdit() throws InterruptedException {
            jsClick(driver.findElement(By.xpath(
                    "//div[text()='Case']/following::div/span[text()='Status']/following::lightning-formatted-text/following::button")));
            Thread.sleep(1000);
        }
        // select status from the dropdown @manali shivareddy

        public void enterStatusDetailsEasyPay(String val) throws InterruptedException {
            jsClick(driver.findElement(By.xpath("//label[text()='Status']/following::button[@role='combobox']")));
            Thread.sleep(800);
            WebElement a6 = driver
                    .findElement(By.xpath("//label[text()='Status']/following::span[text()='" + val + "']"));
            a6.click();
            if (val == "New") {
                Thread.sleep(800);
                jsClick(driver.findElement(By.xpath("//label[text()='Case Origin']/following::button[@role='combobox']"))
                        );
                driver.findElement(By.xpath("//label[text()='Case Origin']/following::span[text()='Web']")).click();
                Thread.sleep(800);
            }
            driver.findElement(By.xpath("//button[text()='Save']")).click();
            Thread.sleep(1000);
        }
        // Icon to change the easy Pay Case Owner when it is already filled @manali
        // shivareddy

        public void changeEasyPayCaseOwnerChangeIcon() throws InterruptedException {
            jsClick(driver.findElement(
                    By.xpath("//span[text()='Case Owner']/following::slot/span/following::lightning-button-icon[2]")));
            Thread.sleep(1000);
        }
        // To get open activity task name @manali shivareddy

        public String easyPayOpenActivityTaskClarificationRequired() throws InterruptedException {
            String task = driver
                    .findElement(By.xpath("//a[@data-refid='recordId'][contains(text(),'Clarification Required')]"))
                    .getText();
            Thread.sleep(700);
            return task;
        }

        // To get open activity task name @manali shivareddy

        public void ClickEasyPayOpenActivityTaskClarificationRequired() throws InterruptedException {
            jsClick(driver.findElement(By.xpath("//a[@data-refid='recordId'][contains(text(),'Clarification Required')]")));
            Thread.sleep(700);
        }
        // To get 'No access message' for an easy pay open activity task @manali
        // shivareddy

        public String easyPayTaskInsufficientAccess() throws InterruptedException {
            String easyPayTaskNoAccess = driver.findElement(By.xpath("//li[contains(text(),'insufficient access')]"))
                    .getText();
            Thread.sleep(700);
            return easyPayTaskNoAccess;
        }
        // To click on Cancel @manali shivareddy

        public void btnCancelEasyPay() throws InterruptedException {
            driver.findElement(By.xpath("//button/span[text()='Cancel']")).click();
            Thread.sleep(2000);
        }
        // Enter Clarification Comments @manali shivareddy

        public void EnterClarificationComments(String val) throws InterruptedException {
            driver.findElement(By.xpath("//span[text()='Clarification']/following::textarea[2]")).sendKeys(val);
            Thread.sleep(1000);
        }
        // Get text @manali shivareddy

        public String getNoAccessMsg() throws InterruptedException {
            String text = "You do not have the level of access necessary to perform the operation you requested. Please contact the owner of the record or your administrator if access is necessary.";
            Thread.sleep(700);
            return text;
        }
        // Get SMS text @manali shivareddy

        public String getSmsComments(String CaseNumber) throws InterruptedException {
            String text = "Hi , \n"
                    + "Your service request with reference ID SR - " + CaseNumber
                    + " has been resolved successfully. For any other issues feel free to contact us at 080 4550 6831 or Mailed us at easypaycollections@byjus.com.\n"
                    + "Regards,\n"
                    + "Team BYJU'S";
            Thread.sleep(700);
            return text;
        }
        
        // Get Case owner under @manali shivareddy
        public String getCaseOwnerDetailsSection() throws InterruptedException {
           // visibleText(By.xpath("//span[text()='Case Owner']/following::div//div/span/slot"));
            String Owner = driver.findElement(By.xpath("//span[text()='Case Owner']/following::div//div/span/slot")).getText();
            Thread.sleep(700);
            return Owner;
        }
        
      //@Author : @manali shivareddy
        //Click On Case option
        public void SelectCaseByExtraSubject(String IssueType,String IssueSubtype, String text) throws InterruptedException {
        driver.findElement(By.xpath("//span[text()='Cases']/following::th[@title='Subject']/following::td/span/a[text()='"+IssueType+"_"+IssueSubtype+"("+text+")']")).click();
        Thread.sleep(2000);
        }
	    //**************************************************Anil Methods*******************************************************
	    //**************************************************Amit Methods*******************************************************
	    //**************************************************Sumit Methods******************************************************
        
      //@Author : Sumit
      
        //Delete the Case record created
        public void DeleteCaseRecord() throws InterruptedException {
            //driver.findElement(By.xpath("//a[@title='Cases'][contains(@class,'tabHeader')]")).click();
           // Thread.sleep(1000);
            driver.findElement(By.xpath("//span[text()='Cases']/following::button[@class='slds-button slds-button_icon-border slds-button_icon-x-small']")).click();
            Thread.sleep(800);
            WebElement ele = driver.findElement(By.xpath("//a[text()='Cases']/following::a[@role='button']/following::div[text()='Delete']"));
            jsClick(ele);
            Thread.sleep(800);
            driver.findElement(By.xpath("//span[text()='Delete']")).click();
            Thread.sleep(2000);
        }
	    //**************************************************Bhavana Methods****************************************************
        
        //@Author : Kalam
        //Click on New Case Button
        public void ClickRelatedCaseNewBtn(String CaseRecord) throws InterruptedException {
            
        jsClick(driver.findElement(By.xpath("//a[text()='"+CaseRecord+"']/following::div[@title='New']")));
        Thread.sleep(2000);
        }
        
       //@Author : Bhavana
        //Check for DP to be Refunded to Wallet
        public void ClickChildCase(String val) {
            List<WebElement> list=driver.findElements(By.xpath("//tr/following::td[5]/span/a"));
            for(int i=0;i<list.size();i++) {
                if(list.get(i).getText().contains(val)) {
                    list.get(i).click();
                }
            }
        }
        
        //@Author : Bhavana
        //Get case owner by passing child case name
        public String CaptureCaseOwnerCC(String val) throws InterruptedException {
            
            String owner = driver.findElement(By.xpath("//lightning-formatted-text[contains(text(),'"+val+"')]/following::span[text()='Case Owner']/following::slot[@force-lookup_lookup]")).getText();
            Thread.sleep(700);
            return owner; 
        }
        
       //@Author : Bhavana
        // To get the Case Owner Profile
        public String CaptureCaseOwnerProfile() throws InterruptedException {
            Thread.sleep(1000);
            String profile = driver.findElement(By.xpath("//span[text()='Profile']/following::a")).getText();
            return profile;
        }
        
        //@Author : Bhavana
        //Capture Parent Case detail
        public String CaptureParentCaseNoCC(String val) throws InterruptedException {
            String ParentCase=driver.findElement(By.xpath("//lightning-formatted-text[contains(text(),'"+val+"')]/following::span[text()='Parent Case']/following::slot[@force-lookup_lookup]/span")).getText();
            //Thread.sleep(700);
            return ParentCase;

        }
        
        //@Author : Bhavana
        //Get case number by passing child case name
        public String CaptureCaseNoCC(String val) throws InterruptedException {
            String CaseNumberfrCC= driver.findElement(By.xpath("//lightning-formatted-text[contains(text(),'"+val+"')]/following::p[text()='Case Number']/following::lightning-formatted-text")).getText();
            Thread.sleep(700);
            return CaseNumberfrCC;
            
        }
        
      //@Author : Bhavana
        //Get case owner by passing child case name
        public String CaptureCaseStatusCC(String val) throws InterruptedException {
            
            String status = driver.findElement(By.xpath("//lightning-formatted-text[contains(text(),'"+val+"')]/following::span[text()='Status']/following::span")).getText();
            Thread.sleep(700);
            return status; 
        }
        
        
        
		//**************************************************Saurabh Methods****************************************************
}
