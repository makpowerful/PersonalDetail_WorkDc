package pageObjects;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


import resources.base;

public class CreatedCaseRecordPO extends base {
	WebDriver driver;

	private String lblCaseRecordNumxpath = "//div[text()='Case']/following::lightning-formatted-text";
	private String txtAssignedToxpath = "//label[text()='Assigned To']/following::input";

	private String btnSavexpath = "//button[text()='Save']";
	private String txtAssignedToSupCall = "//span[@title='Open Activities']/following::a[@data-refid][contains(text(),'Sup Call')]/following::a[@data-refid='recordId']";

	// Declaring Constructor
	public CreatedCaseRecordPO(WebDriver driver) {
		this.driver = driver;
	}

	//**************************************************Kalam Methods******************************************************
 
	//@Author : Kalam
	// Capture the New Case Record Created
	public String CaptureNewCaseRecord() throws InterruptedException {
		String CaseRecord = driver.findElement(By.xpath(lblCaseRecordNumxpath)).getText();
		Thread.sleep(300);
		return CaseRecord;
	}

	//@Author : Kalam
	// Click on Assigned To option to assign the case
	public void ClickAssingedTo() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,600);");
		Thread.sleep(2000);
		jsClick(driver.findElement(By.xpath("//lightning-formatted-text[text()='" + CaptureNewCaseRecord()
				+ "']/following::span[text()='Assigned To']/following::button/span")));
		Thread.sleep(2000);
	}

	//@Author : Kalam
	// Enter name details for collection assistant
	public void EnterAssingedTo(String val) throws InterruptedException {
		driver.findElement(By.xpath(txtAssignedToxpath)).sendKeys(val);
		Thread.sleep(2500);
		driver.findElement(By.xpath(
				"//label[text()='Assigned To']/following::span[@class='slds-media__body']/span/lightning-base-combobox-formatted-text[contains(translate(@title, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'"
						+ val + "')]"))
				.click();
		// driver.findElement(By.xpath("//label[text()='Assigned
		// To']/following::span[@class='slds-media__body']/span/lightning-base-combobox-formatted-text/Strong[contains(translate(text(),
		// 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'"+val+"')]"));
		// jsClick(ele);
		Thread.sleep(800);
	}

	//@Author : Kalam
	// Enter name details for collection assistant
	public void EnterAssingedTo2(String val) throws InterruptedException {
		driver.findElement(By.xpath(txtAssignedToxpath)).sendKeys(val);
		Thread.sleep(2500);
		driver.findElement(By.xpath(
				"//label[text()='Assigned To']/following::span[@class='slds-media__body']/span/lightning-base-combobox-formatted-text[@title='"
						+ val + "']"))
				.click();
		// driver.findElement(By.xpath("//label[text()='Assigned
		// To']/following::span[@class='slds-media__body']/span/lightning-base-combobox-formatted-text/Strong[contains(translate(text(),
		// 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'"+val+"')]"));
		// jsClick(ele);
		Thread.sleep(800);
	}

	//@Author : Kalam
	// Click on Save button
	public void ClickSave() throws InterruptedException {
		driver.findElement(By.xpath(btnSavexpath)).click();
		Thread.sleep(5000);
	}

	//@Author : Kalam
	// Click on Assigned user
	public void ClickAssignedUser(String val) throws InterruptedException {
		// JavascriptExecutor js = (JavascriptExecutor) driver;
		// js.executeScript("scroll(0,600);");
		Thread.sleep(1000);
		jsClick(driver.findElement(By.xpath(
				"//label[text()='Assigned To']/following::span[contains(translate(@title, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'"
						+ val + "')]")));
		Thread.sleep(3000);
	}

	//@Author : Kalam
	// Click on Assigned user
	public void ClickAssignedUser2(String val) throws InterruptedException {
		// JavascriptExecutor js = (JavascriptExecutor) driver;
		// js.executeScript("scroll(0,600);");
		Thread.sleep(1000);
		jsClick(driver.findElement(By.xpath("//span[text()='Assigned To']/following::span[text()=\"" + val + "\"]")));
		Thread.sleep(3000);
	}

	//@Author : Kalam
	// Capture the Case Status val
	public String CaseStatusval() throws InterruptedException {
		String CaseStatus = driver.findElement(By.xpath(
				"//div[@records-highlightsdetailsitem_highlightsdetailsitem]/p[@title='Status']/following::lightning-formatted-text"))
				.getText();
		Thread.sleep(200);
		return CaseStatus;
	}

	//@Author : Kalam
	// Capture the Case Owner val
	public String CaseOwnerval() throws InterruptedException {
		String CaseOwner = driver.findElement(By.xpath(
				"//div[@records-highlightsdetailsitem_highlightsdetailsitem]/p[@title='Owner Name']/following::lightning-formatted-text"))
				.getText();
		Thread.sleep(200);
		return CaseOwner;
	}

	//@Author : Kalam
	// Capture the val of New case record created
	public String NewCaseCreated() throws InterruptedException {
		String CaseCreated = driver.findElement(By.xpath("//span[@title='Related Cases']/following::a[@data-refid]"))
				.getText();
		Thread.sleep(200);
		return CaseCreated;
	}

	//@Author : Kalam
	// Select the ForeClosure Approval Record
	public void ClickFCApprovalRcd(String val) throws InterruptedException {
	    Scrollpagedown();
	  //  Scrollend();
		driver.findElement(By.xpath("//a[@title='" + val + "']")).click();
		Thread.sleep(1000);
		jsClick(driver.findElement(By.xpath("//span[@title='Open Activities']/following::a[@data-refid][text()='Foreclosure Approval']")));
		Thread.sleep(2000);
	}

	//@Author : Kalam
	// Select the First Connect Approval Record
	public void ClickFCRcd(String val) throws InterruptedException {
		driver.findElement(By.xpath("//a[@title='" + val + "']")).click();
		Thread.sleep(1000);
		driver.findElement(
				By.xpath("//span[@title='Open Activities']/following::a[@data-refid][text()='First Connect']")).click();
		Thread.sleep(2000);
	}

	//@Author : Kalam
	// Select the ForeClosure Approval Record
	public void ClickFollowPTPRcd(String val) throws InterruptedException {
		driver.findElement(By.xpath("//a[@title='" + val + "']")).click();
		Thread.sleep(1000);
		// driver.findElement(By.xpath("//span[@title='Open
		// Activities']/following::a[@data-refid][contains(text(),'Follow Up
		// Call')]")).click();
		try {
		visibleText(By.xpath(
				"//span[@title='Open Activities']/following::a[@data-refid][translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'='Follow Up')]"));
		driver.findElement(By.xpath(
				"//span[@title='Open Activities']/following::a[@data-refid][translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'='Follow Up')]"))
				.click();
		Thread.sleep(2000);
		}
		catch(Exception e){
		    driver.navigate().refresh();
		    Thread.sleep(2500);
		      visibleText(By.xpath(
		                "//span[@title='Open Activities']/following::a[@data-refid][translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'='Follow Up')]"));
		        driver.findElement(By.xpath(
		                "//span[@title='Open Activities']/following::a[@data-refid][translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'='Follow Up')]"))
		                .click();
		        Thread.sleep(2000);
		}
	}

	//@Author : Kalam
	// Capture the Created Case number
	public String CaseNumberCreated() {
		visibleText(By.xpath("//p[@title='Case Number']/following-sibling::p"));
		String CaseNumber = driver.findElement(By.xpath("//p[@title='Case Number']/following-sibling::p")).getText();
		return CaseNumber;

	}

	//@Author : Kalam
	// Logout code
	public void Logout() throws InterruptedException {

		driver.findElement(By.xpath("//span[@class='uiImage']")).click();
		Thread.sleep(1500);
		driver.findElement(By.xpath("//a[text()='Log Out']")).click();
		Thread.sleep(1500);

	}

	//@Author : Kalam
	// Changing the Owner from user to queue
	public void CaseOwnrUpdate() throws InterruptedException {
		driver.findElement(By.xpath("//span[text()='Case Owner']/following::button[@title='Change Owner']")).click();
		Thread.sleep(3000);

		driver.findElement(By.xpath("//img[@title='Users']")).click();
		Thread.sleep(1000);

		driver.findElement(By.xpath("//a[@title='Queues']")).click();
		Thread.sleep(2000);

		driver.findElement(By.xpath("//h2[text()='Change Case Owner']/following::input[@role='combobox']"))
				.sendKeys("NEO L2 Queue");
		Thread.sleep(2000);

		driver.findElement(By.xpath("//div[@title='Neo L2 Queue']")).click();
		Thread.sleep(800);

		driver.findElement(By.xpath("//button[text()='Change Owner']")).click();
		Thread.sleep(3000);

	}

	//@Author : Kalam
	// Changing the Owner from user to queue
	public void CaseOwnrUpdate_Prod(String val) throws InterruptedException {
		driver.findElement(By.xpath("//span[text()='Case Owner']/following::button[@title='Change Owner']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//h2[text()='Change Case Owner']/following::input[@role='combobox']"))
				.sendKeys(val);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@title='" + val + "']")).click();
		Thread.sleep(800);
		driver.findElement(By.xpath("//button[text()='Change Owner']")).click();
		Thread.sleep(5000);
		}
	
        // @Author : Kalam
        // Changing the Owner
        public void ChangeCaseOwner(String val) throws InterruptedException {
            driver.findElement(By.xpath("//span[text()='Case Owner']/following::button[@title='Change Owner']")).click();
            Thread.sleep(3000);

            driver.findElement(By.xpath("//h2[text()='Change Case Owner']/following::input[@role='combobox']")).sendKeys(val);
            Thread.sleep(2000);

            driver.findElement(By.xpath("//div[@title='"+val+"']")).click();
            Thread.sleep(800);

            driver.findElement(By.xpath("//button[text()='Change Owner']")).click();
            Thread.sleep(1000);

        }
	
	//@Author : Kalam
	// Update the Status of case to Open
	public void UpdateStatsOpen() throws InterruptedException {
		Thread.sleep(1000);
		driver.findElement(By.xpath("//span[text()='Status'][@class='test-id__field-label']/following::button"))
				.click();
		Thread.sleep(1000);

		driver.findElement(By.xpath("//label[text()='Status']/following::button")).click();
		Thread.sleep(800);

		driver.findElement(By.xpath("//label[text()='Status']/following::span[text()='Open']")).click();
		Thread.sleep(800);

		driver.findElement(By.xpath("//button[text()='Save']")).click();
		Thread.sleep(3000);
	}

	//@Author : Kalam
	// Update the Status of case to Open
	public void UpdateStatsClosed() throws InterruptedException {
		Thread.sleep(1000);
		driver.findElement(By.xpath("//span[text()='Status'][@class='test-id__field-label']/following::button"))
				.click();
		Thread.sleep(1000);

		driver.findElement(By.xpath("//label[text()='Status']/following::button")).click();
		Thread.sleep(800);

		driver.findElement(By.xpath("//label[text()='Status']/following::span[text()='Closed']")).click();
		Thread.sleep(800);

		driver.findElement(By.xpath("//button[text()='Save']")).click();
		Thread.sleep(3000);
	}

	//@Author : Kalam
	// Capture Related Case Record
	public String CaptureRelatedCase() {
		String RelatedCaseRecord = driver
				.findElement(
						By.xpath("//span[text()='Related Cases']/following::a[@records-hoverablelink_hoverablelink]"))
				.getText();
		return RelatedCaseRecord;
	}

	//@Author : Kalam
	// Delete the Related Case record
	public void DeleteRelatedCaseRecord(String val) throws InterruptedException {
		Actions ac = new Actions(driver);
		ac.moveToElement(driver.findElement(
				By.xpath("//span[text()='Related Cases']/following::a[@records-hoverablelink_hoverablelink]"))).build()
				.perform();
		Thread.sleep(1500);

		// jsClick(driver.findElement(By.xpath("//span[text()='Related
		// Cases']/following::span[text()='"+val+"']/following::button[@aria-haspopup]/lightning-primitive-icon")));

		// Thread.sleep(1000);
		jsClick(driver.findElement(By.xpath("//div[text()='Delete']")));
		Thread.sleep(1000);
		jsClick(driver.findElement(By.xpath("//span[text()='Delete']")));
		Thread.sleep(1500);
		// jsClick(driver.findElement(By.xpath("//span[text()='Close'][@class='assistiveText']")));
		// Thread.sleep(1000);
	}

	//@Author : Kalam
	// Click on Capture Retention Details
	public void ClickCaptureRetentnDetail() throws InterruptedException {
		jsClick(driver.findElement(By.xpath("//button[text()='Capture Retention Details']")));
		
	}

	//@Author : Kalam
	// Enter Please select Escalation Category
	public void EnterEscalationCategory(String val) throws Exception {
		retryForDetachedFrame(driver, "//iframe", 0);
		WebElement frame1 = driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
		Thread.sleep(800);
		driver.switchTo().frame(frame1);
		Thread.sleep(1200);
		visibleText(By.xpath("//span[text()='Please select Escalation Category']"));
		Select sel = new Select(driver.findElement(
				By.xpath("//span[text()='Please select Escalation Category']/following::select[@required]")));
		sel.selectByVisibleText(val);
		Thread.sleep(500);
	}

	//@Author : Kalam
	// Enter Reason For Refund
	public void EnterReasonfrRefund(String val) throws Exception {

		driver.findElement(By.xpath("//div[text()='Reason For Refund']/following::span[text()='" + val + "']")).click();
		Thread.sleep(800);
		driver.findElement(By.xpath("//div[text()='Reason For Refund']/following::lightning-primitive-icon")).click();
		Thread.sleep(800);
	}

	//@Author : Kalam
	// Enter Reason For Refund
	public void EnterReasonfrRefund_UAT(String val) throws Exception {
		retryForDetachedFrame(driver, "//iframe", 0);
		WebElement frame1 = driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
		Thread.sleep(800);
		driver.switchTo().frame(frame1);
		Thread.sleep(1200);
		driver.findElement(By.xpath("//div[text()='Reason For Refund']/following::span[text()='" + val + "']")).click();
		Thread.sleep(800);
		driver.findElement(By.xpath("//div[text()='Reason For Refund']/following::lightning-primitive-icon")).click();
		Thread.sleep(800);
	}

	//@Author : Kalam
	// Enter Sub Reason For Refund
	public void EnterSubReasonfrRefund(String val) throws Exception {
		driver.findElement(By.xpath("//div[text()='Sub Reason For Refund']/following::span[text()='" + val + "']"))
				.click();
		Thread.sleep(200);
		driver.findElement(By.xpath("//div[text()='Sub Reason For Refund']/following::lightning-primitive-icon"))
				.click();
		Thread.sleep(200);
	}

	//@Author : Kalam
	// Enter Retention Reason Notes
	public void EnterRRNotes(String val) throws InterruptedException {
		driver.findElement(By.xpath("//label[text()='Retention Reason Notes']/following::textarea")).sendKeys(val);
		Thread.sleep(200);
	}

	//@Author : Kalam
	// Enter Mode Of Retention
	public void EnterModeORetentn(String val) throws InterruptedException {
		driver.findElement(By.xpath("//label[text()='Mode Of Retention']/following::button")).click();
		Thread.sleep(200);
		driver.findElement(By.xpath("//label[text()='Mode Of Retention']/following::span[text()='" + val + "']"))
				.click();
		Thread.sleep(200);

	}

	//@Author : Kalam
	// Enter Retention Team Sales Escalation?
	public void EnterRTSE(String val) throws InterruptedException {
		driver.findElement(By.xpath("//label[text()='Retention Team Sales Escalation?']/following::button")).click();
		Thread.sleep(200);
		driver.findElement(
				By.xpath("//label[text()='Retention Team Sales Escalation?']/following::span[text()='" + val + "']"))
				.click();
		Thread.sleep(200);
	}

	//@Author : Kalam
	// Enter Retention Team Sales Referral?
	public void EnterRTSR(String val) throws InterruptedException {
		driver.findElement(By.xpath("//label[text()='Retention Team Sales Referral?']/following::button")).click();
		Thread.sleep(200);
		driver.findElement(
				By.xpath("//label[text()='Retention Team Sales Referral?']/following::span[text()='" + val + "']"))
				.click();
		Thread.sleep(200);
		driver.findElement(By.xpath("//button[text()='Next']")).click();
		Thread.sleep(3500);
	}

	//@Author : Kalam
	// Make Order Selection
	public void Selectorder() throws InterruptedException {
		jsClick(driver.findElement(By
				.xpath("//span[text()='Please Select The Order']/following::span[contains(@class,'checkbox')]/input")));
		Thread.sleep(200);
		Scrollend();
		driver.findElement(By.xpath("//span[text()='Please Select The Order']/following::button[text()='Next']"))
				.click();
		Thread.sleep(2000);
	}

	//@Author : Kalam
	// Enter Classes To Be Deactivated
	public void EnterClsTBD(String val) throws InterruptedException {
		driver.findElement(By.xpath("//div[text()='Classes To Be Deactivated']/following::span[text()='" + val + "']"))
				.click();
		Thread.sleep(200);
		driver.findElement(By.xpath("//div[text()='Classes To Be Deactivated']/following::lightning-primitive-icon"))
				.click();
		Thread.sleep(200);

	}
	
	//@Author : Kalam
    // Enter Deactivate Classes
    public void EnterDeactivateClasses(String val) throws InterruptedException {
        driver.findElement(By.xpath("//label[text()='Deactivate Classes']/following::button")).click();
        Thread.sleep(200);
        driver.findElement(By.xpath("//label[text()='Deactivate Classes']/following::span[text()='" + val + "']"))
                .click();
        Thread.sleep(200);

    }

	//@Author : Kalam
	// Enter Tablet To Be Returned
	public void EnterTTBR(String val) throws InterruptedException {
		driver.findElement(By.xpath("//label[text()='Tablet To Be Returned']/following::button")).click();
		Thread.sleep(200);
		driver.findElement(By.xpath("//label[text()='Tablet To Be Returned']/following::span[text()='" + val + "']"))
				.click();
		Thread.sleep(200);
	}

	//@Author : Kalam
	// Enter Loan To Be Cancelled
	public void EnterLTBC(String val) throws InterruptedException {
		driver.findElement(By.xpath("//label[text()='Loan To Be Cancelled']/following::button")).click();
		Thread.sleep(200);
		driver.findElement(By.xpath("//label[text()='Loan To Be Cancelled']/following::span[text()='" + val + "']"))
				.click();
		Thread.sleep(200);
	}

	//@Author : Kalam
	// Enter DP To Be Refunded-Bank
	public void EnterDPTBRefunBnk(String val) throws InterruptedException {
		driver.findElement(By.xpath("//label[text()='DP To Be Refunded-Bank']/following::button")).click();
		Thread.sleep(200);
		driver.findElement(By.xpath("//label[text()='DP To Be Refunded-Bank']/following::span[text()='" + val + "']"))
				.click();
		Thread.sleep(200);
	}

	//@Author : Kalam
	// Enter DP To Be Refunded -Wallet
	public void EnterDPTBRefunWall(String val) throws InterruptedException {
		driver.findElement(By.xpath("//label[text()='DP To Be Refunded -Wallet']/following::button")).click();
		Thread.sleep(200);
		driver.findElement(
				By.xpath("//label[text()='DP To Be Refunded -Wallet']/following::span[text()='" + val + "']")).click();
		Thread.sleep(200);
	}

	//@Author : Kalam
	// Enter DP - Refund to wallet Amount
	public void EnterDPRefunWallAmt(String val) throws InterruptedException {
		driver.findElement(By.xpath("//label[text()='DP - Refund to wallet Amount']/following::input")).sendKeys(val);
		Thread.sleep(200);
	}

	//@Author : Kalam
	// Enter DP - Byjus Bonus Point
	public void EnterDPBBP(String val) throws InterruptedException {
		driver.findElement(By.xpath("//label[text()='DP - Byjus Bonus Point']/following::input")).sendKeys(val);
		Thread.sleep(200);
	}

	//@Author : Kalam
	// Enter Other Amount To Be Refunded Bank
	public void EnterOATBRefunBnk(String val) throws InterruptedException {
		driver.findElement(By.xpath("//label[text()='Other Amount To Be Refunded Bank']/following::button")).click();
		Thread.sleep(200);
		driver.findElement(
				By.xpath("//label[text()='Other Amount To Be Refunded Bank']/following::span[text()='" + val + "']"))
				.click();
		Thread.sleep(200);
	}

	//@Author : Kalam
	// Enter Other Amount To Be Refunded-Wallet
	public void EnterOATBRefunWall(String val) throws InterruptedException {
		driver.findElement(By.xpath("//label[text()='Other Amount To Be Refunded-Wallet']/following::button")).click();
		Thread.sleep(200);
		driver.findElement(
				By.xpath("//label[text()='Other Amount To Be Refunded-Wallet']/following::span[text()='" + val + "']"))
				.click();
		Thread.sleep(200);
	}

	//@Author : Kalam
	//Enter Other Amount To Be Refunded-Wallet
    public void EnterCashbackAmountIncluded(String val) throws InterruptedException {
        driver.findElement(By.xpath("//label[text()='Cashback Amount Included?']/following::button")).click();
        Thread.sleep(200);
        driver.findElement(By.xpath("//label[text()='Cashback Amount Included?']/following::span[text()='"+val+"']")).click();
        Thread.sleep(200);  
    }

    //@Author : Kalam
	//Enter Other Refund to wallet Amount
	public void EnterORefunWallAmt(String val) throws InterruptedException {
		driver.findElement(By.xpath("//label[text()='Other Refund to wallet Amount']/following::input")).sendKeys(val);
		Thread.sleep(200);
	}

	//@Author : Kalam
	//Enter Other Amount - Bank
    public void EnterOtherAmountBank(String val) throws InterruptedException {
        driver.findElement(By.xpath("//label[text()='Other Amount - Bank']/following::input")).sendKeys(val);
        Thread.sleep(200);  
        driver.findElement(By.xpath("//label[text()='Courier Charges To Be Refunded?']/following::button[text()='Next']")).click();
        Thread.sleep(2000); 
    }

  //@Author : Kalam
	//Enter Other Byjus Bonus Point
	public void EnterOBBP(String val) throws InterruptedException {
		driver.findElement(By.xpath("//label[text()='Other Byjus Bonus Point']/following::input")).sendKeys(val);
		Thread.sleep(200);
	}
	


	//@Author : Kalam
	//Enter Courier Charges To Be Refunded?
	public void EnterCCTBRefunded(String val) throws InterruptedException {
		driver.findElement(By.xpath("//label[text()='Courier Charges To Be Refunded?']/following::button")).click();
		Thread.sleep(200);
		driver.findElement(
				By.xpath("//label[text()='Courier Charges To Be Refunded?']/following::span[text()='" + val + "']"))
				.click();
		Thread.sleep(200);
		driver.findElement(
				By.xpath("//label[text()='Courier Charges To Be Refunded?']/following::button[text()='Next']")).click();
		Thread.sleep(2000);
	}

	//@Author : Kalam
	// Enter Amount to be refunded
	public void EnterATBRefunded(String val) throws InterruptedException {
		driver.findElement(By.xpath("//span[text()='Amount to be refunded']/following::input")).sendKeys(val);
		Thread.sleep(200);
	}

	//@Author : Kalam
	// Enter Amount retained
	public void EnterARetained(String val) throws InterruptedException {
		driver.findElement(By.xpath("//span[text()='Amount retained']/following::input")).sendKeys(val);
		Thread.sleep(200);
		driver.findElement(By.xpath("//span[text()='Amount retained']/following::button[text()='Next']")).click();
		Thread.sleep(2000);
	}

	//@Author : Kalam
	// Select Customer Wants To Go For One Shot Payment?
	public void SelectCWTGFOSP(String val) throws InterruptedException {
		Select sel = new Select(driver.findElement(
				By.xpath("//span[text()='Customer Wants To Go For One Shot Payment?']/following::select[@required]")));
		sel.selectByVisibleText(val);
		Thread.sleep(200);
	}

	//@Author : Kalam
	// Select Order To Be Re-Punched
	public void SelectOTBReP(String val) throws InterruptedException {
		Select sel = new Select(
				driver.findElement(By.xpath("//span[text()='Order To Be Re-Punched']/following::select[@required]")));
		sel.selectByVisibleText(val);
		Thread.sleep(200);
	}

	//@Author : Kalam
	// Select Complementary Products To Be Repunched
	public void SelectCPTBReP(String val) throws InterruptedException {
		Select sel = new Select(driver.findElement(
				By.xpath("//span[text()='Complementary Products To Be Repunched']/following::select[@required]")));
		sel.selectByVisibleText(val);
		Thread.sleep(200);
	}

	//@Author : Kalam
	// Select Books To Be Returned?
	public void SelectBTBR(String val) throws InterruptedException {
		Select sel = new Select(
				driver.findElement(By.xpath("//span[text()='Books To Be Returned?']/following::select[@required]")));
		sel.selectByVisibleText(val);
		Thread.sleep(200);
	}

	//@Author : Kalam
	// Select Retention Team Product Status
	public void SelectRTPS(String val) throws InterruptedException {
		Select sel = new Select(driver
				.findElement(By.xpath("//span[text()='Retention Team Product Status']/following::select[@required]")));
		sel.selectByVisibleText(val);
		Thread.sleep(200);
	}

	//@Author : Kalam
	// Enter Retention Team Product Status Notes
	public void EnterRTPSNotes(String val) throws InterruptedException {
		driver.findElement(By.xpath("//span[text()='Retention Team Product Status Notes']/following::textarea"))
				.sendKeys(val);
		Thread.sleep(200);
		driver.findElement(
				By.xpath("//span[text()='Retention Team Product Status Notes']/following::button[text()='Next']"))
				.click();
		Thread.sleep(2000);
	}

	//@Author : Kalam
	// Select the owner
	public void SelectOwner(String val) throws InterruptedException {
		WebElement ele = driver.findElement(
				By.xpath("//span[text()='Select The Student Required For Order Repunch']/following::span[text()='" + val
						+ "']"));
		scrollIntoView(ele);
		jsClick(ele);
		Thread.sleep(1000);
		driver.findElement(By.xpath(
				"//span[text()='Select The Student Required For Order Repunch']/following::button[text()='Next']"))
				.click();
		Thread.sleep(2000);
	}

	//@Author : Kalam
	// Enter Specify Products For Each Siblings
	public void EnterSPFES(String val) throws InterruptedException {
		driver.findElement(By.xpath("//label[text()='Specify Products For Each Siblings']/following::textarea"))
				.sendKeys(val);
		Thread.sleep(200);
	}

	//@Author : Kalam
	// Enter Grades To Be Re Punched
	public void EnterGTBP(String val) throws InterruptedException {
		driver.findElement(By.xpath("//div[text()='Grades To Be Re Punched']/following::span[text()='" + val + "']"))
				.click();
		Thread.sleep(200);
		driver.findElement(By.xpath("//div[text()='Grades To Be Re Punched']/following::lightning-primitive-icon"))
				.click();
		Thread.sleep(200);

	}

	//@Author : Kalam
	// Enter Classes To Be Re - Punched
	public void EnterClsTBReP(String val) throws InterruptedException {
		driver.findElement(By.xpath("//div[text()='Classes To Be Re - Punched']/following::span[text()='" + val + "']"))
				.click();
		Thread.sleep(200);
		driver.findElement(By.xpath("//div[text()='Classes To Be Re - Punched']/following::lightning-primitive-icon"))
				.click();
		Thread.sleep(200);

	}

	//@Author : Kalam
	// Enter Amount
	public void EnterAmount(String val) throws InterruptedException {
		driver.findElement(By.xpath("//label[text()='Amount']/following::input")).sendKeys(val);
		Thread.sleep(200);
	}

	//@Author : Kalam
	// Enter Other Payment Details
	public void EnterOtherPD(String val) throws InterruptedException {
		driver.findElement(By.xpath("//label[text()='Other Payment Details']/following::textarea")).sendKeys(val);
		Thread.sleep(200);
	}

	//@Author : Kalam
	// Enter Grades To Be Re Punched
	public void EnterCompliGTBP(String val) throws InterruptedException {
		driver.findElement(By.xpath(
				"//span[contains(text(),'Complimentary')]/following::div[text()='Grades To Be Re Punched']/following::span[text()='"
						+ val + "']"))
				.click();
		Thread.sleep(200);
		driver.findElement(By.xpath(
				"//span[contains(text(),'Complimentary')]/following::div[text()='Grades To Be Re Punched']/following::lightning-primitive-icon"))
				.click();
		Thread.sleep(200);

	}

	//@Author : Kalam
	// Enter Classes To Be Re - Punched
	public void EnterCompliClsTBReP(String val) throws InterruptedException {
		driver.findElement(By.xpath(
				"//span[contains(text(),'Complimentary')]/following::div[text()='Classes To Be Re - Punched']/following::span[text()='"
						+ val + "']"))
				.click();
		Thread.sleep(200);
		driver.findElement(By.xpath(
				"//span[contains(text(),'Complimentary')]/following::div[text()='Classes To Be Re - Punched']/following::lightning-primitive-icon"))
				.click();
		Thread.sleep(200);
		driver.findElement(By.xpath("//span[contains(text(),'Complimentary')]/following::button[text()='Next']"))
				.click();
		Thread.sleep(2000);
	}

	//@Author : Kalam
	// Select Ask For Bank Details
	public void SelectAFBD(String val) throws InterruptedException {
		Select sel = new Select(
				driver.findElement(By.xpath("//span[text()='Ask For Bank Details']/following::select[@required]")));
		sel.selectByVisibleText(val);
		Thread.sleep(200);
	}

	//@Author : Kalam
	// Select Do You Want To Send The Address So That The Customer Can Send Product
	public void SelectDYWTSTASTTCProd(String val) throws InterruptedException {
		Select sel = new Select(driver.findElement(By.xpath(
				"//span[text()='Do You Want To Send The Address So That The Customer Can Send Product']/following::select[@required]")));
		sel.selectByVisibleText(val);
		Thread.sleep(200);
	}

	//@Author : Kalam
	// Select Do You Want To Ask The Customer To Share The Copy Of Application Form?
	public void SelectCOAForm(String val) throws InterruptedException {
		Select sel = new Select(driver.findElement(By.xpath(
				"//span[text()='Do You Want To Ask The Customer To Share The Copy Of Application Form?']/following::select[@required]")));
		sel.selectByVisibleText(val);
		Thread.sleep(200);
		driver.findElement(By.xpath(
				"//span[contains(text(),'Do You Want To Ask The Customer To Share The Copy Of Application Form?')]/following::button[text()='Next']"))
				.click();
		Thread.sleep(2000);
	}

	//@Author : Kalam
	// Check for Created Case Buttons
	public void CheckCreatedCaseButtonsQAandSM(String Env, String SheetName) throws Exception {
		List<WebElement> List = driver
				.findElements(By.xpath("//div[text()='Case']/following::ul/li[@class='visible']//button"));
		System.out.println(List.size());
		for (int i = 0; i < List.size(); i++) {
		    
			String OnPagebuttons = driver
	                .findElements(By.xpath("//div[text()='Case']/following::ul/li[@class='visible']//button")).get(i).getText();
			System.out.println(OnPagebuttons);
			setData(Env, SheetName, i + 1, 5, OnPagebuttons);
			if (i == List.size() - 1) {
				setData2(Env, SheetName, i + 2, 5, List.size());
				try {
					if (driver.findElement(By.xpath(
							"//div[text()='Case']/following::button[@class='slds-button slds-button_icon-border-filled']/span[text()='Show more actions']"))
							.isDisplayed()) {
						jsClick(driver.findElement(By.xpath(
								"//div[text()='Case']/following::button[@class='slds-button slds-button_icon-border-filled']/span[text()='Show more actions']")));
						Thread.sleep(1500);

						List<WebElement> Showmore = driver.findElements(By.xpath(
								"//div[text()='Case']/following::span[@runtime_platform_actions-ribbonmenuitem_ribbonmenuitem]"));
						System.out.println(Showmore.size());

						for (int j = 0; j < Showmore.size(); j++) {

							String ShowMorebuttons = Showmore.get(j).getText();
							System.out.println(ShowMorebuttons);
							setData(Env, SheetName, j + 1, 7, ShowMorebuttons);
							if (j == Showmore.size() - 1) {
								setData2(Env, SheetName, j + 2, 7, Showmore.size());
							}
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println("No corner button present");
				}
			}
		}
	}

	//@Author : Kalam
	public void Scrollend() throws InterruptedException {

		driver.findElement(tag).sendKeys(Keys.END);
		Thread.sleep(1200);
	}

	//@Author : Kalam
	public void jsClick(WebElement el) {
		try {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("arguments[0].click();", el);
			System.out.println("Element clicked");
		} catch (Exception e) {
			System.out.println("=============================================================");
			System.out.println("Exception-jsClick(): " + e.getMessage());
			takeScreenShot();
			e.printStackTrace();
			System.out.println("=============================================================");
		}
	}

	//@Author : Kalam
	// Scroll element to view
	public void scrollIntoView(WebElement element) {
		try {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("arguments[0].scrollIntoView(true);", element);
			System.out.println("Page scrolled down");
		} catch (Exception e) {
			System.out.println("=============================================================");
			System.out.println("Exception-scrollIntoView(): " + e.getMessage());
			takeScreenShot();
			e.printStackTrace();
			System.out.println("=============================================================");
		}
	}

	//@Author : Kalam
	public boolean visibleText(By element) {
		WebDriverWait wait = new WebDriverWait(driver, 50);

		wait.ignoring(StaleElementReferenceException.class)
				.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));

		System.out.println("Element is visible");
		return false;
	}
	
	//@Author : Kalam
    public void Scrollpagedown() throws InterruptedException {

        driver.findElement(tag).sendKeys(Keys.PAGE_DOWN);
        Thread.sleep(1200);
    }


	//**************************************************Manish Methods*****************************************************
	
   //========================Author :: Manish Goyal=====================================
    
    //public static String button_EditAssignedTo= "";
    public static String button_SaveEdit="//button[@name='SaveEdit']";
    public static String iframe_NoCallConnect="//iframe[@title='accessibility title']";
    public static String textfield_SearchField="//input[@placeholder='Search Setup']";
    //public static String textfield_SearchAsButton="";
    //public static String textfiedl_SearchAsInput="";
    //public static String link_FirstConnect="//a[text()='First Connect']";
    //public static String button_NoCallConnect="//div[text()='No Call Connect']";  
    //public static String rbutton_LanguageBarrier="//span[text()='Language Barrier']";
    //public static String dropdown_PreferredLanguage="//select[@name='Preferred_Language']";
    //public static String textfield_PhoneNumber="//input[@id='input-12']";
    //public static String textfield_Comment="//input[@id='input-15']";
    //public static String button_Next="//button[@class='slds-button slds-button_brand flow-button__NEXT']";    
    //public static String static_text="//p[text()='Owner Name']/following::slot/records-formula-output";
    //public static String link_FollowUP="//a[text()='Follow Up - Language Barrier']";
    //public static String button_AssignCase="//div[@title='Assign Case']";
    //public static String button_ClearSelection="//div[@class='slds-input__icon-group slds-input__icon-group_right']/button";
    //public static String button_AssignNext="//button[@class='slds-button slds-button_brand flow-button__NEXT']";
    

	
	//This method changes the caseOwner
    //Author :: Manish
    public void changeCaseOwnertoRetentionUser(String val) throws Exception
    {
        
        jsClick(driver.findElement(By.xpath("//div/span[text()='Case Owner']/following::span[text()='Change Owner']")));
        Thread.sleep(3000);
        //driver.findElement(By.xpath("//h2[text()='Change Account Owner']/following::input[@placeholder]")).sendKeys(val);
      
        driver.findElement(By.xpath("//input[@title='Search Users']")).sendKeys(val);
        Thread.sleep(1500);
        jsClick(driver.findElement(By.xpath("//div[@title='"+val+"']")));
        Thread.sleep(1000);
        driver.findElement(By.xpath("//button[@name='change owner']")).click();
        Thread.sleep(2500);     
    }
    
    //This method enters Loan ID while capturing Retential call details
    //Author :: Manish
    
    public void EnterLoanID(String val) throws InterruptedException {
        driver.findElement(By.xpath("//label[text()='Loan ID']/following::input")).sendKeys(val);
        Thread.sleep(200);  
    }
    
    //This method selects type of other amount while capturing Retention call details
    //Author :: Manish
    
 
    public void SelectTypeOfOtherAmount(String val) throws InterruptedException {
        driver.findElement(By.xpath("//div[text()='Type Of Other Amount']/following::span[text()='"+val+"']")).click();
        Thread.sleep(200);
        driver.findElement(By.xpath("//div[text()='Type Of Other Amount']/following::lightning-primitive-icon")).click();
        Thread.sleep(200);
        
    }  
	
	//Enter Other Amount To Be Refunded Bank
    //Author :: Manish
    public void EnterCashbackAmount(String val) throws InterruptedException {
        driver.findElement(By.xpath("//label[text()='Cashback Amount Included?']/following::button")).click();
        Thread.sleep(200);
        driver.findElement(By.xpath("//label[text()='Cashback Amount Included?']/following::span[text()='"+val+"']")).click();
        Thread.sleep(200);  
    }
    
  //Enter Other Amount To Be Refunded Bank
    //Author :: Manish
    public void EnterOtherAmountToBank(String val) throws InterruptedException {
        driver.findElement(By.xpath("//label[text()='Other Amount - Bank']/following::input")).sendKeys(val);
        Thread.sleep(200);    
    }
    
    
	
		//---Author :: Manish
	public static WebElement button_AssignNext(WebDriver driver)
	{
		return driver.findElement(By.xpath("//button[@class='slds-button slds-button_brand flow-button__NEXT']"));
	}
	
	//---Author :: Manish
	public static WebElement button_ClearSelection(WebDriver driver)
	{
		return driver.findElement(By.xpath("//div[@class='slds-input__icon-group slds-input__icon-group_right']/button"));
	}
	
	//---Author :: Manish
	public static WebElement button_AssignCase(WebDriver driver)
	{
		return driver.findElement(By.xpath("//div[@title='Assign Case']"));
	}
	
	//---Author :: Manish
	public static WebElement link_FollowUP(WebDriver driver)
	{
		return driver.findElement(By.xpath("//a[text()='Follow Up - Language Barrier']"));
	}
	//---Author :: Manish
	public static WebElement static_text(WebDriver driver)
	{
		return driver.findElement(By.xpath("//p[text()='Owner Name']/following::slot/records-formula-output"));
	}
	//---Author :: Manish
	public static WebElement static_text2(WebDriver driver)
	{
		return driver.findElement(By.xpath("//p[text()='Owner Name']/following::slot/lightning-formatted-text"));
	}
	
	//---Author :: Manish
	public static WebElement button_Next(WebDriver driver)
	{
		return driver.findElement(By.xpath("//button[@class='slds-button slds-button_brand flow-button__NEXT']"));
	}
	
	//---Author :: Manish
	public static WebElement textfield_Comment(WebDriver driver)
	{
		return driver.findElement(By.xpath("//input[@id='input-15']"));
	}
	
	//---Author :: Manish
	public static WebElement textfield_PhoneNumber(WebDriver driver)
	{
		return driver.findElement(By.xpath("//input[@id='input-12']"));
	}
	
	//---Author :: Manish
	public static WebElement dropdown_PreferredLanguage(WebDriver driver)
	{
		return driver.findElement(By.xpath("//select[@name='Preferred_Language']"));
	}
	
	//This method returns the 'Language Barrier' radio button webelement //---Author :: Manish
	public static WebElement rbutton_LanguageBarrier(WebDriver driver)
	{
		return driver.findElement(By.xpath("//span[text()='Language Barrier']"));
	}
	
	//---Author :: Manish
	public static WebElement iframe_NoCallConnect(WebDriver driver)
	{
		return driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
	}
	
	//---Author :: Manish
	public static WebElement button_NoCallConnect(WebDriver driver)
	{
		return driver.findElement(By.xpath("//div[text()='No Call Connect']"));
	}
	
	//---Author :: Manish
	public static WebElement link_FirstConnect(WebDriver driver)
	{
		return driver.findElement(By.xpath("//a[text()='First Connect']"));
	}
	
	// This method searches the case by case number and click on the case number link in result//Author :: Manish Goyal
	public void searchCaseAndClick(String caseNumber)
	{
		CreatedCaseRecordPO.textfield_SearchAsButton(driver).click();
		CreatedCaseRecordPO.textfiedl_SearchAsInput(driver).sendKeys(caseNumber); //Enter the case number captured in search field
		CreatedCaseRecordPO.textfiedl_SearchAsInput(driver).sendKeys(Keys.RETURN);// Press the Enter key on the same search field
		CreatedCaseRecordPO.link_CaseNumberInSearchResult(driver,caseNumber).click();//Click on the case number which is displayed.
	}
	
	
	//Author :: Manish Goyal
	public static WebElement button_EditAssignedTo(WebDriver driver)
	{
		return driver.findElement(By.xpath("//button[@title='Edit Assigned To']"));
	}
	
	//This method returns Search field webelment (as a button) //Author :: Manish Goyal
	public static WebElement textfield_SearchAsButton(WebDriver driver)
	{
		return driver.findElement(By.xpath("//button[@class='slds-button slds-button_neutral search-button slds-truncate']"));
	}
	
	//This method returns Search field webelment (as a input field) //Author :: Manish Goyal
	public static WebElement textfiedl_SearchAsInput(WebDriver driver)
	{
		return driver.findElement(By.xpath("//lightning-input[@class='saInput slds-grow slds-form-element']/div/input[@class='slds-input']"));
	}
	
	//This methods returns link of case number which is displayed in search result //Author :: Manish Goyal
	public static WebElement link_CaseNumberInSearchResult(WebDriver driver,String caseNumber)
	{
		return driver.findElement(By.xpath("//a[@title='"+caseNumber+"']"));
	}
	
	//This method returns the webelement related to Case Owner's value
    public static WebElement caseOwner(WebDriver driver) {
        //return driver.findElement(By.xpath("//span[@data-aura-class='forceSocialPhoto_v2 forceOutputLookup']/following-sibling::a[starts-with(@class,'outputLookup')]"));
        return driver.findElement(By.xpath("//span[text()='Case Owner']/following::force-owner-lookup//a/slot/slot/span"));
    }
	
	
	//----------------------------------Methods------------------------------
	//This method clicks on Edit Assigned button //Author :: Manish Goyal
	public static void clickEditAssignedButton(WebDriver driver)
	{
		CreatedCaseRecordPO.button_EditAssignedTo(driver).click();
	}
	
	//This method closes the current case tab 
	public  void closeCurrentTab(String val) throws InterruptedException
	    {
	        //driver.findElement(By.xpath("//span[text()='Close "+caseNumber+"']")).click();
	        jsClick(driver.findElement(By.xpath("//button[@title='Close "+val+"']")));	      
	        Thread.sleep(1000);
	    }

	
	//This method enters the phone number into Phone field
	//Author ::Manish
	public static void enterPhoneNumber(WebDriver driver,String phoneNumber)
	{
		CreatedCaseRecordPO.textfield_PhoneNumber(driver).sendKeys(phoneNumber);
	}
	
	//----This method enters the comments into the comment field
	//Author ::Manish
		
	public static void enterComment(WebDriver driver, String comment)
	{
		CreatedCaseRecordPO.textfield_Comment(driver).sendKeys(comment);
	}
	//This method clicks on the 'Next' button
	//Author ::Manish
	public static void clickNextbutton(WebDriver driver)
	{
		CreatedCaseRecordPO.button_Next(driver).click();
	}
	
	////Author ::Manish
	public static void clickFirstConnectlink(WebDriver driver)
	{
		CreatedCaseRecordPO.link_FirstConnect(driver).click();
	}
	
	public static void clickNoCallConnectbutton(WebDriver driver)
	{
		CreatedCaseRecordPO.button_NoCallConnect(driver).click();
	}
	
	//**************************************************Manali Methods*****************************************************
    // Click Sup call Due @Manali Shivareddy
    public void clickSupCallDue() throws InterruptedException {
        Thread.sleep(100);
        WebElement ele=driver.findElement(
                By.xpath("//span[@title='Open Activities']/following::a[@data-refid][text()='Sup Call Due']"));
        scrollIntoView(ele);
        jsClick(ele);
        Thread.sleep(2000);
    }

    // txtAssignedToSupCall
    public String getSupCallDueAssignee() throws InterruptedException {
        String assignedTo = driver.findElement(By.xpath(txtAssignedToSupCall)).getAttribute("title");
        Thread.sleep(2000);
        return assignedTo;
    }
    
    //@Author : Manali Shivareddy , Click on Audit case
    public void clickAuditRelatedCase() throws InterruptedException {
        WebElement ele=driver
                .findElement(
                        By.xpath("//span[text()='Related Cases']/following::a[@records-hoverablelink_hoverablelink]"));
        jsClick(ele);    
        Thread.sleep(2000);
    }
    
    //@Author : Manali Shivareddy , to get 'Payment Methods' text
    public String getPaymentMethod() throws InterruptedException {
        String text=driver
                .findElement(
                        By.xpath("//div/span[text()='Payment Methods']/following::lightning-formatted-text"))
                .getText();
        Thread.sleep(2000);
        return text;
    }
	
    // Capture Related Case Record - to get the Audit case number @Author : Manali Shivareddy. Same as CaptureRelatedCase() with diff xpath
    public String getAuditCaseCaptureRelatedCase() throws InterruptedException {
        String RelatedCaseRecord = driver
                .findElement(
                        By.xpath("//span[text()='Related Cases']/following::slot//span"))
                .getText();
        Thread.sleep(2000);
        return RelatedCaseRecord;
    }
	
    //**************************************************Anil Methods*******************************************************
    //**************************************************Amit Methods*******************************************************
    //**************************************************Sumit Methods******************************************************
    //**************************************************Bhavana Methods****************************************************
    
    //@Author : Bhavana 
    //To get 'Payment Methods' text
    public String getEPPartner() throws InterruptedException {
        String text=driver
                .findElement(
                        By.xpath("//div/span[text()='EP Partner']/following::lightning-formatted-text"))
                .getText();
        Thread.sleep(2000);
        return text;
    }
   
    //@Author : Bhavana
    // Capture Related Case Record - to get the Audit case number
    public String CaptureRelatedCaseno() {
        String RelatedCaseRecord = driver
                .findElement(
                        By.xpath("//span[text()='Related Cases']/following::a[@records-hoverablelink_hoverablelink]/slot/slot/span"))
                .getText();
        return RelatedCaseRecord;
    }
    
    //@Author : Bhavana
    // Capture Related Case Record - to get the Audit case number
    public String getPayRef() throws InterruptedException
    {
        String payref = driver
                .findElement(
                        By.xpath("//span[text() = 'Payment Reference']/following::lightning-formatted-text"))
                .getText();
        Thread.sleep(200);
        return payref;
    }
    
    //@Author : Bhavana
    //To get audit case status
    public String getAuditStatus() throws InterruptedException
    {
        Thread.sleep(2000);
        String AuditStatus = driver.
                findElement(
                        By.xpath("//p[@title = 'Audit Status']/following::lightning-formatted-text"))
                .getText();
        return AuditStatus;
    }
    
    //@Author : Bhavana
    // Select the Follow Up Approval Record
    public void ClickFCRcdFollowUp(String val) throws InterruptedException {
        driver.findElement(By.xpath("//a[@title='" + val + "']")).click();
        Thread.sleep(1000);
        driver.findElement(
                By.xpath("//span[@title='Open Activities']/following::a[@data-refid][text()='Follow Up Call-DNP']")).click();
        Thread.sleep(2000);
    }
    
  //@Author : Bhavana
    // Capture the Case status
    public String CaptureCaseStatus() {
        jsClick(driver.findElement(By.xpath("//p[@title='Priority']/following::p[@title='Status']/following-sibling::p")));
        String CaseStatus = driver.findElement(By.xpath("//p[@title='Priority']/following::p[@title='Status']/following-sibling::p")).getText();
        return CaseStatus;
    }
    
    //@Author : Bhavana
    // Click on Case owner
    public void ClickCaseOwner(String val) throws InterruptedException {
        Thread.sleep(1000);
        jsClick(driver.findElement(By.xpath("//span[text()='Case Owner']/following::span[text()='" + val + "']")));
        Thread.sleep(3000);
    }
    
    //@Author : Bhavana
    // Click on Case owner
    public void ClickCaseOwner1(String val) throws InterruptedException {
        Thread.sleep(1000);
        jsClick(driver.findElement(By.xpath("//lightning-formatted-text[contains(text(),'"+val+"')]/following::span[text()='Case Owner']/following::records-hoverable-link")));
        Thread.sleep(3000);
    }
    
    //@Author : Bhavana
    // Click on Case owner-Gives user 
    public String CaptureCaseOwner() throws InterruptedException {
        Thread.sleep(1000);
        String owner = driver.findElement(By.xpath("//span[text()='Case Owner']/following::span/following::a/slot/slot/span")).getText();
        Thread.sleep(3000);
        return owner;
    }
    
  //span[text()='Case Owner']/following::span[@class='displayLabel']/slot
  //span[text()='Case Owner']/following::div/span/force-lookup/div/span/slot
    
    //@Author : Bhavana
    // Click on Case owner-Gives Queue name
    public String CaptureCaseOwner1() throws InterruptedException {
        Thread.sleep(1000);
        String owner = driver.findElement(By.xpath(" //span[text()='Case Owner']/following::span[@class='displayLabel']/slot")).getText();
        Thread.sleep(3000);
        return owner;
    }
    
   //@Author : Bhavana
    //click cases button on the payment page 
    public void ClickRelatedCasesbtn() throws InterruptedException {
        Thread.sleep(1000);
        jsClick(driver.findElement(By.xpath("//div[text()='Case']/following::span[@title='Related Cases']")));
        Thread.sleep(1500);
    }
    
    
    //@Author : Bhavana
    //Navigate to Open Activity on case
    public void ClickOpenActivities() throws InterruptedException {
        Scrollpagedown();
        Scrollpagedown();
        Thread.sleep(3000);
        Scrollpagedown();
        WebElement ele1 =  driver.findElement(By.xpath("//div[text()='Case']/following::span[contains(text(),'Open Activities')]"));
        jsClick(ele1);
        Thread.sleep(800);
    }
    
    //@Author : Bhavana
    //Get subject on Open activity 
    public boolean CheckOpenActivities(String val) {
        boolean flag=false;
        List<WebElement> list=driver.findElements(By.xpath("//tr/following::td[5]/span/a"));
        for(int i=0;i<list.size();i++) {
            if(list.get(i).getText().contains(val)) {
                flag = true;
            }
        }
        return flag;
    }
  
    //@Author : Bhavana
    //Capture Reason For Refund
    public String CaptureReasonForRefund() throws InterruptedException {
        Thread.sleep(1000);
        String Reason = driver.findElement(By.xpath("//span[text()='Reason For Refund']/following::span/slot/lightning-formatted-text")).getText();
        Thread.sleep(3000);
        return Reason;
    }
    
    //@Author : Bhavana
    //Capture Sub Reason For Refund
    public String CaptureSubReasonRefund() throws InterruptedException {
        Thread.sleep(1000);
        String SubReason = driver.findElement(By.xpath("//span[text()='Sub Reason Refund']/following::span/slot/lightning-formatted-text")).getText();
        Thread.sleep(3000);
        return SubReason;
    }
    
    //@Author : Bhavana
    //Capture siblings name
    public String captureSiblingName() throws InterruptedException
    {
        Scrollpagedown();
        Scrollpagedown();
        String name  = driver.findElement(By.xpath("//span[text()='Sibling 1']/following::span /slot/force-lookup/div/records-hoverable-link/div/a/slot/slot/span")).getText();
        return name;
    }
    
  //@Author : Bhavana
    //Nav to case tab from account
    public void NavToCaseTab(String val)
    {
        jsClick(driver.findElement(By.xpath("//span[text()='"+val+"']")));
    }
    
    //**************************************************Saurabh Methods****************************************************
	

}


