package pageObjects;



import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.time.DateUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import resources.base;

public class NewCaseDetailsPO extends base {
	WebDriver driver;

	private String btnSavexpath = "//button[text()='Save']";
	private String btnStudentPaymentSavexpath = "//button[text()='Save']";
	private String closeSubTab = "//div[@class='close slds-col--bump-left slds-p-left--none slds-p-right--none ']";
	private String inputEMIamount="//label[text()='EMI Amount']/following::input[1]";

	// Declaring Constructor
	public NewCaseDetailsPO(WebDriver driver) {
		this.driver = driver;
	}
	
	//**************************************************Kalam Methods******************************************************
    
	//@Author : Kalam
	// Click Save button
	public void ClickSave() throws InterruptedException {
		driver.findElement(By.xpath(btnSavexpath)).click();
		Thread.sleep(4000);

	}

	//@Author : Kalam
	// Capture the Issue Category
	public String CaptureIssueCategory() {
		String IssueCategory = driver
				.findElement(By.xpath("//span[text()='Category']/following::lightning-formatted-text")).getText();
		return IssueCategory;
	}

	//@Author : Kalam
	// Capture the Device
	public String CaptureDevice() {
		String Device = driver.findElement(By.xpath("//span[text()='Device']/following::lightning-formatted-text"))
				.getText();
		return Device;
	}

	//@Author : Kalam
	// Capture the Issue Sub Type
	public String CaptureIssueSubType() {
		String IssueSubType = driver
				.findElement(By.xpath("//span[text()='Issue Sub Type']/following::lightning-formatted-text")).getText();
		return IssueSubType;
	}
	

	//@Author : Kalam
	// Click Delete button
	public void ClickDeleteonCase() throws InterruptedException {
		driver.findElement(By.xpath("//button[text()='Delete']")).click();
		Thread.sleep(1000);
	}

	//@Author : Kalam
	// Click Delete button
	public void ClickDeleteToComplete() throws InterruptedException {
		driver.findElement(By.xpath("//span[text()='Delete']")).click();
		Thread.sleep(2000);
	}

	//@Author : Kalam
	// Click on Open Activities drop down
	public void ClickOpenActiDD() {
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("scroll(0,750);");
			Thread.sleep(2000);
			WebElement ele1 = driver.findElement(By
					.xpath("//div[text()='Case']/following::span[text()='Open Activities']/following::lightning-icon"));
			Thread.sleep(1000);
			Actions ac = new Actions(driver);
			ac.moveToElement(ele1).click().build().perform();
			Thread.sleep(800);
			// ele1.click();
			ClickNewTask();
		} catch (Throwable t) {
			t.printStackTrace();
		}
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("scroll(0,850);");
			Thread.sleep(2000);
			// Scrollpagedown();
			Thread.sleep(2000);
			WebElement ele1 = driver
					.findElement(By.xpath("//span[text()='Open Activities']/following::lightning-icon"));
			Actions ac = new Actions(driver);
			ac.moveToElement(ele1).click().build().perform();
			Thread.sleep(800);
			ClickNewTask();
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

	//@Author : Kalam
	// Click on Open Activities drop down
	public void ClickOpenActiDD_Prod() {
		try {
			WebElement ele1 = driver.findElement(By
					.xpath("//div[text()='Case']/following::span[text()='Open Activities']/following::lightning-icon"));
			Thread.sleep(1000);
			Actions ac = new Actions(driver);
			ac.moveToElement(ele1).click().build().perform();
			Thread.sleep(800);
			// ele1.click();
			ClickNewTask();
		} catch (Throwable t) {
			t.printStackTrace();
		}
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("scroll(0,550);");
			Thread.sleep(2000);
			// Scrollpagedown();
			WebElement ele1 = driver
					.findElement(By.xpath("//span[text()='Open Activities']/following::lightning-icon"));
			Actions ac = new Actions(driver);
			ac.moveToElement(ele1).click().build().perform();
			Thread.sleep(800);
			ClickNewTask();
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

	//@Author : Kalam
	// Click on Open Activities New Task Option
	public void ClickNewTask() throws InterruptedException {
		Thread.sleep(1000);
		WebElement ele = driver.findElement(
				By.xpath("//span[text()='Open Activities']/following::lightning-icon/following::a[@title='New Task']"));
		Actions ac = new Actions(driver);
		ac.moveToElement(ele).build().perform();
		jsClick(ele);
		Thread.sleep(2000);
	}

	//@Author : Kalam
	// Click on Capture Retention Details
	public void ClickCaptureRetentnDetail() throws InterruptedException {
		driver.findElement(By.xpath("//button[text()='Capture Retention Details']")).click();
		Thread.sleep(3000);
	}

	//@Author : Kalam
	// Enter value for Subject
	public void EnterSubject(String val) throws InterruptedException {
	    visibleText(By.xpath("//span[text()='Subject'] | //label[text()='Subject']"));
		jsClick(driver.findElement(By.xpath("//span[text()='Subject']/following::input | //label[text()='Subject']/following::input")));
		driver.findElement(By.xpath("//span[text()='Subject']/following::input | //label[text()='Subject']/following::input")).sendKeys(val);
		Thread.sleep(1000);
	}

	//@Author : Kalam
	// Enter value for Subject
	public void EnterSubject2(String val) throws InterruptedException {
		jsClick(driver.findElement(
				By.xpath("//h2[contains(text(),'New Case')]/following::span[text()='Subject']/following::input | //h2[contains(text(),'New Case')]/following::label[text()='Subject']/following::input")));
		Thread.sleep(300);
		driver.findElement(
				By.xpath("//h2[contains(text(),'New Case')]/following::span[text()='Subject']/following::input | //h2[contains(text(),'New Case')]/following::label[text()='Subject']/following::input"))
				.sendKeys(val);
		Thread.sleep(300);
	}

	//@Author : Kalam
	// Enter value for Orders
	public void EnterOrders(String val) throws InterruptedException {
		jsClick(driver.findElement(
				By.xpath("//h2[contains(text(),'New Case')]/following::span[text()='Orders']/following::input | //h2[contains(text(),'New Case')]/following::label[text()='Orders']/following::input")));
		Thread.sleep(300);
		driver.findElement(
				By.xpath("//h2[contains(text(),'New Case')]/following::span[text()='Orders']/following::input | //h2[contains(text(),'New Case')]/following::label[text()='Orders']/following::input"))
				.sendKeys(val);
		Thread.sleep(300);
	}
	
	//@Author : Kalam
    // Enter value for Orders
    public void EnterStudentSalesOrder() throws InterruptedException {
        jsClick(driver.findElement(
                By.xpath("//h2[contains(text(),'New Case')]/following::span[text()='Student Sales Order']/following::input | //h2[contains(text(),'New Case')]/following::label[text()='Student Sales Order']/following::input")));
        Thread.sleep(1000);
        driver.findElement(By.xpath("//h2[contains(text(),'New Case')]/following::span[text()='Student Sales Order']/following::input | //h2[contains(text(),'New Case')]/following::label[text()='Student Sales Order']/following::input")).sendKeys("Order");
        Thread.sleep(1500);
       clickButton(driver.findElement(
                By.xpath("//h2[contains(text(),'New Case')]/following::span[text()='Student Sales Order']/following::input/following::li/a | //h2[contains(text(),'New Case')]/following::label[text()='Student Sales Order']/following::input/following::li//lightning-base-combobox-formatted-text")));
        Thread.sleep(300);
    }
  //@Author : Kalam
	// Enter value for Status
	public void EnterStatus(String val) throws InterruptedException {
		jsClick(driver.findElement(
				By.xpath("//h2[contains(text(),'New Case')]/following::span[text()='Status']/following::a | //h2[contains(text(),'New Case')]/following::label[text()='Status']/following::button[1]")));
		Thread.sleep(300);
		jsClick(driver.findElement(
				By.xpath("//h2[contains(text(),'New Case')]/following::span[text()='Status']/following::a[text()='"
						+ val + "'] | //h2[contains(text(),'New Case')]/following::label[text()='Status']/following::span[text()='"
		                        + val + "']")));
		Thread.sleep(300);
	}

	//@Author : Kalam
	// Enter value for Case Origin
	public void EnterCaseOrigin(String val) throws InterruptedException {
		jsClick(driver.findElement(
				By.xpath("//h2[contains(text(),'New Case')]/following::span[text()='Case Origin']/following::a | //h2[contains(text(),'New Case')]/following::label[text()='Case Origin']/following::span")));
		Thread.sleep(300);
		jsClick(driver.findElement(
				By.xpath("//h2[contains(text(),'New Case')]/following::span[text()='Case Origin']/following::a[text()='"
						+ val + "'] | //h2[contains(text(),'New Case')]/following::label[text()='Case Origin']/following::span[text()='"
		                        + val + "']")));
		Thread.sleep(300);
	}

	//@Author : Kalam
	// Enter value for Type Of Order Punched
	public void EnterTypeOfOrderPunched(String val) throws InterruptedException {
		jsClick(driver.findElement(By.xpath(
				"//h2[contains(text(),'New Case')]/following::span[text()='Type Of Order Punched']/following::a | //h2[contains(text(),'New Case')]/following::label[text()='Type Of Order Punched']/following::span")));
		Thread.sleep(300);
		jsClick(driver.findElement(By.xpath(
				"//h2[contains(text(),'New Case')]/following::span[text()='Type Of Order Punched']/following::a[text()='"
						+ val + "'] | //h2[contains(text(),'New Case')]/following::label[text()='Type Of Order Punched']/following::span[text()='"
		                        + val + "']")));
		Thread.sleep(300);
	}

	//@Author : Kalam
	// Enter value for Type of Order
	public void EnterTypeOfOrder(String val) throws InterruptedException {
		jsClick(driver.findElement(
				By.xpath("//h2[contains(text(),'New Case')]/following::span[text()='Type of Order']/following::a | //h2[contains(text(),'New Case')]/following::label[text()='Type of Order']/following::span")));
		Thread.sleep(300);
		jsClick(driver.findElement(By
				.xpath("//h2[contains(text(),'New Case')]/following::span[text()='Type of Order']/following::a[text()='"
						+ val + "'] | //h2[contains(text(),'New Case')]/following::label[text()='Type of Order']/following::span[text()='"
		                        + val + "']")));
		Thread.sleep(300);
	}

	//@Author : Kalam
	// Enter value for Case Category
	public void EnterCaseCategory(String val) throws InterruptedException {
		jsClick(driver.findElement(
				By.xpath("//h2[contains(text(),'New Case')]/following::span[text()='Case Category']/following::a | //h2[contains(text(),'New Case')]/following::label[text()='Case Category']/following::span")));
		Thread.sleep(300);
		jsClick(driver.findElement(By
				.xpath("//h2[contains(text(),'New Case')]/following::span[text()='Case Category']/following::a[text()='"
						+ val + "'] | //h2[contains(text(),'New Case')]/following::label[text()='Case Category']/following::span[text()='"
		                        + val + "']")));
		Thread.sleep(300);
	}

	//@Author : Kalam
	// Enter value for Order Landing Selected
	public void EnterOrderLandingSelected(String val) throws InterruptedException {
		jsClick(driver.findElement(By.xpath(
				"//h2[contains(text(),'New Case')]/following::span[text()='Order Landing Selected']/following::a | //h2[contains(text(),'New Case')]/following::label[text()='Order Landing Selected']/following::span")));
		Thread.sleep(300);
		jsClick(driver.findElement(By.xpath(
				"//h2[contains(text(),'New Case')]/following::span[text()='Order Landing Selected']/following::a[text()='"
						+ val + "'] | //h2[contains(text(),'New Case')]/following::label[text()='Order Landing Selected']/following::span[text()='"
		                        + val + "']")));
		Thread.sleep(300);
		jsClick(driver.findElement(
				By.xpath("//h2[contains(text(),'New Case')]/following::span[text()='Resolution Responsibility'] | //h2[contains(text(),'New Case')]/following::label[text()='Resolution Responsibility']")));
	}

	//@Author : Kalam
	// Enter value for Product Category
	public void EnterProductCategory(String val) throws InterruptedException {
		jsClick(driver.findElement(By.xpath(
				"//h2[contains(text(),'New Case')]/following::span[text()='Product Category']/following::input | //h2[contains(text(),'New Case')]/following::label[text()='Product Category']/following::input")));
		Thread.sleep(300);
		driver.findElement(By
				.xpath("//h2[contains(text(),'New Case')]/following::span[text()='Product Category']/following::input | //h2[contains(text(),'New Case')]/following::label[text()='Product Category']/following::input"))
				.sendKeys(val);
		Thread.sleep(300);
	}

	//@Author : Kalam
	// Enter value for Reason for dispatch
	public void EnterReasonForDispatch(String val) throws InterruptedException {
		jsClick(driver.findElement(By.xpath(
				"//h2[contains(text(),'New Case')]/following::span[text()='Reason for dispatch']/following::input | //h2[contains(text(),'New Case')]/following::label[text()='Reason for dispatch']/following::input")));
		Thread.sleep(300);
		driver.findElement(By.xpath(
				"//h2[contains(text(),'New Case')]/following::span[text()='Reason for dispatch']/following::input | //h2[contains(text(),'New Case')]/following::label[text()='Reason for dispatch']/following::input"))
				.sendKeys(val);
		Thread.sleep(300);
	}

	//@Author : Kalam
	// Enter value for Validity as per OH/OMS
	public void EnterValidityOHorOMS(String val) throws InterruptedException {
		jsClick(driver.findElement(By.xpath(
				"//h2[contains(text(),'New Case')]/following::span[text()='Validity as per OH/OMS']/following::input | //h2[contains(text(),'New Case')]/following::label[text()='Validity as per OH/OMS']/following::input")));
		Thread.sleep(300);
		driver.findElement(By.xpath(
				"//h2[contains(text(),'New Case')]/following::span[text()='Validity as per OH/OMS']/following::input | //h2[contains(text(),'New Case')]/following::label[text()='Validity as per OH/OMS']/following::input"))
				.sendKeys(val);
		Thread.sleep(300);
	}

	//@Author : Kalam
	// Enter value for Pincode is serviceable for exchange
	public void EnterPincodeServicable(String val) throws InterruptedException {
		jsClick(driver.findElement(By.xpath(
				"//h2[contains(text(),'New Case')]/following::span[text()='Pincode is serviceable for exchange']/following::input | //h2[contains(text(),'New Case')]/following::label[text()='Pincode is serviceable for exchange']/following::input")));
		Thread.sleep(300);
		driver.findElement(By.xpath(
				"//h2[contains(text(),'New Case')]/following::span[text()='Pincode is serviceable for exchange']/following::input | //h2[contains(text(),'New Case')]/following::label[text()='Pincode is serviceable for exchange']/following::input"))
				.sendKeys(val);
		Thread.sleep(300);
	}

	//@Author : Kalam
	// Enter value for Orders
	public void EnterOrders(int randomNum) throws InterruptedException {
		jsClick(driver.findElement(By.xpath("//span[text()='Orders']/following::input")));
		driver.findElement(By.xpath("//span[text()='Orders']/following::input")).sendKeys("ORD" + randomNum);
		Thread.sleep(800);
	}

	//@Author : Kalam
	// Select the value for Reason For Refund
	public void SelectReasonForRefund(String val) throws InterruptedException {
		scrollIntoView(driver.findElement(By.xpath("//div[text()='Reason For Refund']")));
		jsClick(driver.findElement(By.xpath("//li[@class='slds-listbox__item']/div[@data-value='" + val + "']")));
		jsClick(driver.findElement(By
				.xpath("//lightning-button-icon/button[@title='Move selection to Chosen']/lightning-primitive-icon")));
		Thread.sleep(800);
	}

	//@Author : Kalam
	public void jsClick(WebElement el) {
		try {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("arguments[0].click();", el);
			System.out.println("Element clicked");
		} catch (Exception e) {
			System.out.println("=============================================================");
			System.out.println("Exception-jsClick(): " + e.getMessage());
			takeScreenShot();
			e.printStackTrace();
			System.out.println("=============================================================");
		}
	}

	//@Author : Kalam
	public void Scrollpagedown() throws InterruptedException {

		driver.findElement(tag).sendKeys(Keys.PAGE_DOWN);
		Thread.sleep(1500);
	}

	//@Author : Kalam
	// Scroll element to view
	public void scrollIntoView(WebElement element) {
		try {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("arguments[0].scrollIntoView(true);", element);
			System.out.println("Page scrolled down");
		} catch (Exception e) {
			System.out.println("=============================================================");
			System.out.println("Exception-scrollIntoView(): " + e.getMessage());
			takeScreenShot();
			e.printStackTrace();
			System.out.println("=============================================================");
		}
	}

	   //@Author : Kalam
    public void clickButton(WebElement element)
     {
         WebDriverWait wait= new WebDriverWait(driver, 100);
         
         wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));
         
         System.out.println("Element is clickable");
         element.click();
     }
    
  //**************************************************Manali Methods*****************************************************
    
  // Enter Account name @manali shivareddy
  public void EnterStudentAcctName(String val) throws InterruptedException {
      jsClick(driver.findElement(By.xpath("//label[text()='Student']/following::input[1]")));
      WebElement input = driver.findElement(By.xpath("//label[text()='Student']/following::input[1]"));
      input.sendKeys(val);
      Thread.sleep(4000);
      input.sendKeys(Keys.ARROW_DOWN);
      input.sendKeys(Keys.ARROW_DOWN);
      input.sendKeys(Keys.ARROW_DOWN, Keys.RETURN);
  }

  // Click Student PaymentSavexpath button @manali shivareddy
  public void clickStudentPaymentSave() throws InterruptedException {
      driver.findElement(By.xpath(btnStudentPaymentSavexpath)).click();
      Thread.sleep(4000);

  }

  // Click Student PaymentSavexpath button @manali shivareddy
  public void clickCloseSubTab() throws InterruptedException {
      driver.findElement(By.xpath(closeSubTab)).click();
      Thread.sleep(4000);

  }

  // Enter EMI amount @ manali shivareddy
  public void enterEMIamount(String val) {
      driver.findElement(By.xpath(inputEMIamount)).sendKeys(val);

  }

  // @ manali shivareddy
  public boolean visibleText(By element) {
      WebDriverWait wait = new WebDriverWait(driver, 50);

      wait.ignoring(StaleElementReferenceException.class)
              .until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));

      System.out.println("Element is visible");
      return false;
  }
		
//**************************************************Manish Methods*****************************************************
//**************************************************Anil Methods*******************************************************
//**************************************************Amit Methods*******************************************************
//**************************************************Sumit Methods******************************************************
//**************************************************Bhavana Methods****************************************************
  

  //@Author : Bhavana
  //To link student account in RR Child Case
  public void EnterContactName(String name) throws InterruptedException
  {
      driver.findElement(By.xpath(
                      "//h2[contains(text(), 'New Case')]/following::label[text()='Contact Name']/following::input"))
      .sendKeys(name);
      Thread.sleep(2500);
      jsClick(driver.findElement(By.xpath(
                      "//label[text()='Contact Name']/following::lightning-base-combobox-formatted-text[@title='"+name+"']")));
      Thread.sleep(800);
     // driver.findElement(By.xpath( "//h2[contains(text(), 'New Case')]/following::span[text()='Contact Name']")).click();
  }
  
  //@Author : Bhavana
  //To enter Amount in RR Child Case creation
  public void EnterAmount(String val) throws InterruptedException
  {
      Thread.sleep(2500);
      driver.findElement(By.xpath("//label[text() = 'Amount']/following::input")).sendKeys(val);
      driver.findElement(By.xpath("//label[text() = 'Amount']")).click();
      Thread.sleep(800);
  }
  
  //@Author : Bhavana
  //To enter retention approved date in RR Child Case creation
  public void EnterRetApprDate() throws InterruptedException
  {
      Thread.sleep(2500);
      jsClick(driver.findElement(By.xpath("//label[text()='Retention Approved Date']/following::input")));
      
      //2/20/2023
      //2/21/2023
      
      SimpleDateFormat sdf = new SimpleDateFormat("M/dd/yyyy");
      Date date = DateUtils.addDays(new Date(), 0);
      String dateAfter = sdf.format(date);
      
      driver.findElement(By.xpath("//label[text()='Retention Approved Date']/following::input")).sendKeys(dateAfter);
     // jsClick(driver.findElement(By.xpath("//span[contains(@class,'todayDate')]")));
      Thread.sleep(800);
  }
  

  //@Author : Bhavana
  //To enter yes or no in RR Child Case creation
  public void SelectDropdownOptionCC(String val, String opt) throws InterruptedException {
      
      WebElement a5=driver.findElement(By.xpath("//label[contains(text(),'"+val+"')]"));
      ////label[contains(text(),'DP to be Refunded?')]
      scrollIntoView(a5);
      jsClick(a5);
      
    //label[contains(text(),'DP to be Refunded?')]/following::button
      jsClick(driver.findElement(By.xpath("//label[contains(text(),'"+val+"')]/following::button"))); // DP to be Refunded?
      Thread.sleep(200);

      WebElement a6 = driver
          .findElement(By.xpath("//label[contains(text(),'"+val+"')]/following::span[text()='" + opt + "']"));
      jsClick(a6);
    }
  
  //@Author : Bhavana
  //To enter subject in RR Child Case creation
  public void EnterSubject1(String val)
  {
      WebElement a5=driver.findElement(By.xpath("//h2[contains(text(), 'New Case')]/following::label[text() = 'Subject']"));
      scrollIntoView(a5);
      a5.click();
      driver.findElement(By.xpath("//h2[contains(text(), 'New Case')]/following::label[text() = 'Subject']/following::input")).sendKeys(val);
  }
  
  
  //@Author : Bhavana
  // Enter Grades To Be Re - Punched
  public void EnterGTBP1(String val) throws InterruptedException {
      
      WebElement a5=driver.findElement(By.xpath("//div[text()='Grades To Be Re - Punched']"));
      scrollIntoView(a5);
      
      driver.findElement(By.xpath("//div[text()='Grades To Be Re - Punched']/following::span[text()='" + val + "']"))
              .click();
      Thread.sleep(200);
      driver.findElement(By.xpath("//div[text()='Grades To Be Re - Punched']/following::lightning-primitive-icon"))
              .click();
      Thread.sleep(200);

  }
  
  //@Author : Bhavana
  // Enter Grades To Be Re - Punched
  public void EnterGTBP2(String val) throws InterruptedException {
      
      WebElement a5=driver.findElement(By.xpath("//div[text()='Grades To Be Re - Punched']/following::span[text()='"+val+"'][2]"));
      scrollIntoView(a5);
      
      driver.findElement(By.xpath("//div[text()='Grades To Be Re - Punched']/following::span[text()='"+val+"'][2]"))
              .click();
      Thread.sleep(200);
      driver.findElement(By.xpath("//div[text()='Grades To Be Re - Punched']//following::span[text()='"+val+"'][2]/following::lightning-primitive-icon"))
              .click();
      Thread.sleep(200);

  }
  
  //@Author : Bhavana
  // Enter Classes To Be Re - Punched
  public void EnterClsTBReP2(String val) throws InterruptedException {
      driver.findElement(By.xpath("//div[text()='Classes To Be Re - Punched']/following::span[text()='"+val+"'][last()]"))
              .click();
      Thread.sleep(200);
      driver.findElement(By.xpath(
              "//div[text()='Classes To Be Re - Punched']/following::span[text()='"+val+"'][last()]/following::lightning-primitive-icon"))
              .click();
      Thread.sleep(200);

  }
  
  //@Author : Bhavana
  // Enter value for Orders
  public void EnterStudentSalesOrder_Prod() throws InterruptedException {
      jsClick(driver.findElement(
              By.xpath("//h2[contains(text(),'New Case')]/following::label[text()='Student Sales Order']/following::input")));
      Thread.sleep(1000);
      driver.findElement(By.xpath("//h2[contains(text(),'New Case')]/following::label[text()='Student Sales Order']/following::input")).sendKeys("Order");
      Thread.sleep(1500);
     clickButton(driver.findElement(
              By.xpath("//h2[contains(text(), \"New Case\")]/following::label[text()='Student Sales Order']/following::input/following::ul/li[not(contains(@class,'invisible'))]")));
      Thread.sleep(300);
  }
  //**************************************************Saurabh Methods****************************************************
}
