package pageObjects;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


import resources.base;

public class CapturePaymtDetailsPTPPO extends base {
	WebDriver driver;
	

	private String btnNextxpath = "//button[text()='Next']";
	private String SelNoofMnthxpath = "//select[@name='No_of_Months']";
	private String txtPhnNoxpath = "//span[text()='Phone No']/following::input";
	private String DateCapptpxpath = "//span[text()='Capture Date/Time for PTP']/following::input";
	private String txtCommxpath = "//span[text()='Comments']/following::input";
	private String SelPTPGivnbyxpath = "//select[@name='PTP_Given_By']";
	private String lblErrorMessxpath = "//span[contains(text(),'within today only.')]";

	// Declaring Constructor
	public CapturePaymtDetailsPTPPO(WebDriver driver) {
		this.driver = driver;
	}

	//**************************************************Kalam Methods******************************************************
 
	// public WebElement PRerror1=
	// driver.findElement(By.xpath("//div[@class='slds-text-color_error']"));

	//@Author : Kalam
	// Providing Rating to the user
	public void EnterRating(String val) throws Exception {
	retryForDetachedFrame(driver, "//iframe", 0);
	WebElement frame1=driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
	Thread.sleep(800);
	driver.switchTo().frame(frame1);
	visibleText(By.xpath("//label[text()='"+val+"']"));
	driver.findElement(By.xpath("//label[text()='"+val+"']")).click();
	Thread.sleep(1000);
	}
	
	//@Author : Kalam
	//Click next to submit customer rating
	public void ClickNext() throws InterruptedException {
	driver.findElement(By.xpath(btnNextxpath)).click();
	Thread.sleep(1500);
	}
	
	//@Author : Kalam
	//Select Payment Option
		public void SelectPaymntOptn(String val) throws InterruptedException {
		driver.findElement(By.xpath("//span[text()='"+val+"']")).click();
		Thread.sleep(1000);
	}

		//@Author : Kalam
	// Select the No Of EMI Collected
	public void SelectNoofEMI(String val) throws InterruptedException {
		Select sel = new Select(driver.findElement(By.xpath(SelNoofMnthxpath)));
		sel.selectByVisibleText(val);
		Thread.sleep(200);
	}

	//@Author : Kalam
	// Enter the value for Phone number
	public void EnterPhoneNo(String val) throws InterruptedException {
		driver.findElement(By.xpath(txtPhnNoxpath)).sendKeys(val);
		Thread.sleep(200);
	}

	//@Author : Kalam
	// Enter Capture Date/Time for PTP value for error
	public void EnterDateerrormess() throws InterruptedException {
		driver.findElement(By.xpath(DateCapptpxpath)).clear();
		Thread.sleep(100);
		driver.findElement(By.xpath(DateCapptpxpath)).sendKeys("Apr 11, 2022");
		Thread.sleep(800);
	}

	//@Author : Kalam
	// Enter Comments
	public void EnterComments(String val) throws InterruptedException {
		driver.findElement(By.xpath(txtCommxpath)).sendKeys(val);
		Thread.sleep(200);
	}

	//@Author : Kalam
	// Select the value for PTP Given By
	public void SelectPTPGivenBy(String val) throws InterruptedException {
		Select sel1 = new Select(driver.findElement(By.xpath(SelPTPGivnbyxpath)));
		sel1.selectByVisibleText(val);
		Thread.sleep(200);
	}

	//@Author : Kalam
	// Capture Error message for date before today
	public String CapturDateError() throws InterruptedException {
		String DateErrorMess = driver.findElement(By.xpath(lblErrorMessxpath)).getText();
		Thread.sleep(200);
		return DateErrorMess;
	}

	//@Author : Kalam
	// ReEnter correct date for Date/Time for PTP value
	public void EnterDateTimePTP() throws InterruptedException {
		DateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		driver.findElement(By.xpath(DateCapptpxpath)).clear();
		Thread.sleep(800);
		driver.findElement(By.xpath(DateCapptpxpath)).sendKeys(date1);
		Thread.sleep(1000);
		String[] Time = driver.findElement(By.xpath("//input[@name='PTPDateTime'][contains(@data-value,':')]"))
				.getAttribute("value").split(":");
		int i = Integer.parseInt(Time[0]) + 1;
		String Atime = i + ":" + Time[1].replaceAll("AM", "PM");

		Actions action = new Actions(driver);
		WebElement ele = driver.findElement(By.xpath("//input[@name='PTPDateTime'][contains(@data-value,':')]"));
		ele.click();
		ele.clear();

		action.keyDown(Keys.CONTROL).sendKeys("A").keyUp(Keys.CONTROL).sendKeys(Atime).build().perform();
		Thread.sleep(800);

		Thread.sleep(500);
	}

	//@Author : Kalam
	// Click finish to submit FC details
	public void ClickNextSwitchDefault() throws Exception {
		driver.findElement(By.xpath(btnNextxpath)).click();
		Thread.sleep(4000);
		// retryForDetachedFrame(driver, "//iframe", 0);
		driver.switchTo().defaultContent();
		 Thread.sleep(3000);
	}


	
	//@Author : Kalam
	public boolean visibleText(By element)
	{
		WebDriverWait wait= new WebDriverWait(driver, 100);
		
		wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));
		
		System.out.println("Element is visible");
		return false;
	}
	
	//**************************************************Manali Methods*****************************************************
	 // Verify PTP default values @ manali shivareddy
    public String[] getDefaultDateTimePTP(String currentURL ) throws InterruptedException {
       // String currentURL="prod";
        this.CurrURL = currentURL;
        String day2 = null;
        DateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy");
        Date date = new Date();
        String date1 = dateFormat.format(date);
        String[] month=date1.split(" ");
        String[] day=date1.replaceAll(",", "").split(" ");
        if(!CurrURL.contains("--byjusuat")) {
         date1 = day[1] + "-" + day[0] + "-" + day[2];
        }else {
        String[] year=date1.split(" ");
        if(Integer.parseInt(day[1])<=9){
             day2=day[1].replaceAll("0", "");
            
        }else {
            day2=day[1];
        }
        date1=month[0]+" "+day2+","+" "+year[2];
        System.out.println(date1);
        }

        String ptpDate = driver.findElement(By.xpath(DateCapptpxpath)).getAttribute("value");
        Thread.sleep(800);
        String Time = driver.findElement(By.xpath("//input[@name='PTPDateTime'][contains(@data-value,':')]"))
                .getAttribute("value");
        if(!CurrURL.contains("--byjusuat")) {
            Time=Time.toUpperCase();
        }
        return new String[] { date1, ptpDate, Time };

    }
    
  //@Author : manali shivareddy
    // Enter Capture Date/Time for PTP value for error
    public void EnterDateerrormessProd() throws InterruptedException {
        driver.findElement(By.xpath(DateCapptpxpath)).clear();
        Thread.sleep(100);
        driver.findElement(By.xpath(DateCapptpxpath)).sendKeys("11-Apr-2022");
        Thread.sleep(800);
    }
    
  //@Author : manali shivareddy
    // ReEnter correct date for Date/Time for PTP value
    public void EnterDateTimePTPProd() throws InterruptedException {
        DateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy");
        Date date = new Date();
        String date1 = dateFormat.format(date);
        String[] day=date1.replaceAll(",", "").split(" ");
         date1 = day[1] + "-" + day[0] + "-" + day[2];       
        driver.findElement(By.xpath(DateCapptpxpath)).clear();
        Thread.sleep(800);
        driver.findElement(By.xpath(DateCapptpxpath)).sendKeys(date1);
        Thread.sleep(1000);
        String[] Time = driver.findElement(By.xpath("//input[@name='PTPDateTime'][contains(@data-value,':')]"))
                .getAttribute("value").split(":");
        int i = Integer.parseInt(Time[0]) + 1;
        String Atime = i + ":" + Time[1].replaceAll("am", "pm");
System.out.println(Atime);
        Actions action = new Actions(driver);
        WebElement ele = driver.findElement(By.xpath("//input[@name='PTPDateTime'][contains(@data-value,':')]"));
        ele.click();
        ele.clear();

        action.keyDown(Keys.CONTROL).sendKeys("A").keyUp(Keys.CONTROL).sendKeys(Atime).build().perform();
        Thread.sleep(800);

        Thread.sleep(500);
    }
	
	//**************************************************Manish Methods*****************************************************
    //**************************************************Anil Methods*******************************************************
    //**************************************************Amit Methods*******************************************************
    //**************************************************Sumit Methods******************************************************
    //**************************************************Bhavana Methods****************************************************
	//**************************************************Saurabh Methods****************************************************
}
