package pageObjects;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.time.DateUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import resources.ExcelData;
import resources.base;


public class CreatedAccountPO extends base{
	WebDriver driver;
	public static Logger log = LogManager.getLogger(CreatedAccountPO.class.getName());
	ExcelData excelData = new ExcelData();
	private String lnk_Sorder_xpath = "//span[text()='Student Orders']/following::span[contains(text(),'Student Order :')][@force-lookup_lookup]";
	private String lnk_StunSSorder_xpath = "//span[text()='Student Sales Orders']/following::span[@force-lookup_lookup][contains(text(),'SSO')]";
	private String btnDrpdwnxpath = "//button[contains(@title,'Actions for')]";
	private String btnRefreshxpath = "//li[@title='Refresh Tab']/a";
	
	String[] Studentorder1val = null;
	String[] Studentorder2val = null;
	int counter=1;
	
	// Declaring Constructor
	public CreatedAccountPO(WebDriver driver) {
		this.driver = driver;
	}
	
	//**************************************************Kalam Methods******************************************************
	
	//@Author : Kalam
    //Navigate to URL
        public void goTo(String val) {
            driver.get(val);
        }
	
    //@Author : Kalam
    //Capture URL
        public String CaptureURL() {
            return driver.getCurrentUrl();
        }
	
	//@Author : Kalam
	//Check Visibility Student Order id 
		public boolean CheckVisStudentOrderid() {
			WebElement Studentpayments=driver.findElement(By.xpath(lnk_Sorder_xpath));
			return Studentpayments.isDisplayed();
		}
	
	//@Author : Kalam
	//Check Visibility Student and Student Sales Orders
	public boolean CheckVisSalesStudentOrderid() {
		WebElement Studentpayments=driver.findElement(By.xpath(lnk_StunSSorder_xpath));
		return Studentpayments.isDisplayed();
	}
	
	//@Author : Kalam
	//Capture the Student and Student Sales Orders created
		public void CaptureStudentSalesOrder() throws InterruptedException {
		List<WebElement> Studentorder=driver.findElements(By.xpath(lnk_StunSSorder_xpath));
		for(int i=0;i<Studentorder.size();i++) {
			
			System.out.println("The Student order created is "+i+ " " +Studentorder.get(i).getText());
			log.info("The Student order created is "+i+ " " +Studentorder.get(i).getText());
			//Studentorder1val = Studentorder.get(0).getText().trim().split(": ");
			//Studentorder2val = Studentorder.get(1).getText().trim().split(": ");
			Thread.sleep(500);
		}
		//System.out.println(Studentorder1val[1]);
		//System.out.println(Studentorder2val[1]);
		}
		
		//@Author : Kalam
		//Capture the Student and Student Sales Orders created
				public void CaptureStudentAppInfo() throws InterruptedException {
				List<WebElement> StudentAppInfo=driver.findElements(By.xpath("//span[text()='Student App Informations']/following::span[contains(text(),'SAI-')][@force-lookup_lookup]"));
				for(int i=0;i<StudentAppInfo.size();i++) {
					
					System.out.println("The Student order created is "+i+ " " +StudentAppInfo.get(i).getText());
					log.info("The Student order created is "+i+ " " +StudentAppInfo.get(i).getText());
					//Studentorder1val = Studentorder.get(0).getText().trim().split(": ");
					//Studentorder2val = Studentorder.get(1).getText().trim().split(": ");
					Thread.sleep(500);
				}
				//System.out.println(Studentorder1val[1]);
				//System.out.println(Studentorder2val[1]);
				}
	//@Author : Kalam
	//Capture the Student Order id's created
	public void CaptureStudentOrder() throws InterruptedException {
	List<WebElement> Studentorder=driver.findElements(By.xpath(lnk_Sorder_xpath));
	for(int i=0;i<Studentorder.size();i++) {
		
		System.out.println("The Student order created is "+i+ " " +Studentorder.get(i).getText());
		log.info("The Student order created is "+i+ " " +Studentorder.get(i).getText());
		Studentorder1val = Studentorder.get(0).getText().trim().split(": ");
		Studentorder2val = Studentorder.get(1).getText().trim().split(": ");
		Thread.sleep(500);
	}
	System.out.println(Studentorder1val[1]);
	System.out.println(Studentorder2val[1]);
	}
	

	//@Author : Kalam
	public void CaptureStudentOrderIndvid() {
	String OrderNo1 = driver.findElement(By.xpath("//span[text()='Student Orders']/following::span[contains(text(),'"+Studentorder1val[1]+"')][@force-lookup_lookup]/following::dt[text()='Order No:']/following-sibling::dd/lst-template-list-field/lst-formatted-text")).getText();
	String OrderNo2 = driver.findElement(By.xpath("//span[text()='Student Orders']/following::span[contains(text(),'"+Studentorder2val[1]+"')][@force-lookup_lookup]/following::dt[text()='Order No:']/following-sibling::dd/lst-template-list-field/lst-formatted-text")).getText();
	System.out.println(OrderNo1);
	System.out.println(OrderNo2);
	}
	
	//@Author : Kalam
	//Click Student Order
	public void ClickStudentOrder() throws InterruptedException {
	WebElement ele = driver.findElement(By.xpath(lnk_Sorder_xpath));
	Actions ac=new Actions(driver);
	ac.moveToElement(ele).build().perform();
	jsClick(ele);
	Thread.sleep(3000);
	//driver.findElement(By.xpath("//tr[1]/th/span/a")).click();
	//Thread.sleep(2000);
	driver.findElement(By.xpath("//span[text()='Order']/following::a")).click();
	Thread.sleep(2000);
	}
	
	//@Author : Kalam
	//Click Student Order
	public void ClickStudentSalesOrder() throws InterruptedException {
	WebElement ele = driver.findElement(By.xpath("//span[text()='Student Sales Orders']"));
	Actions ac=new Actions(driver);
	Scrollpageup();
	ac.moveToElement(ele).build().perform();
	jsClick(ele);
	Thread.sleep(3000);
	driver.findElement(By.xpath("//td[2]/span/a")).click();
	Thread.sleep(2000);
	}
	
	//@Author : Kalam
	//Check Existing Profile field is present
	public boolean CheckExistingProfile() {
		/*
		 * boolean a; try { if(driver.findElement(By.
		 * xpath("//span[text()='Existing Profile']/following::button[contains(@title,'Edit')]"
		 * )).isDisplayed()) { a=true; return a; } } catch(Throwable t) {
		 * t.printStackTrace(); a=false; return a; }
		 */
		return isDisplayed(By.xpath("//span[text()='Existing Profile']/following::button[contains(@title,'Edit')]"));
	}
	
	//@Author : Kalam
	//Check Visibility Student Payment id
	public boolean CheckVisStudentPayid() throws InterruptedException {
		Scrollpagedown();
		WebElement Studentpayments=driver.findElement(By.xpath("//span[text()='Student Payments']/following::span[contains(text(),'SP-')][@force-lookup_lookup]"));
		return Studentpayments.isDisplayed();
	}
	
	//@Author : Kalam
	//Capture the Student Payment id's
	public void CaptureAllStudentPayid() throws InterruptedException {
	List<WebElement> Studentpayments=driver.findElements(By.xpath("//span[text()='Student Payments']/following::span[contains(text(),'SP-')][@force-lookup_lookup]"));
	for(int j=0;j<Studentpayments.size();j++) {
		
		System.out.println("The Student payment created are "+j+ " " +Studentpayments.get(j).getText());		
		Thread.sleep(500);
		
	}
	
	}
	
	//@Author : Kalam
	//Capture the Premium ID
	public String CapturePremiumID() {
	WebElement ele2=driver.findElement(By.xpath("//span[text()='Premium ID']/following::lightning-formatted-text"));		
	String PremiumID = ele2.getText();
	System.out.println("The Premium ID is: "+PremiumID);
	return PremiumID;
	}

	//@Author : Kalam
	//Check Visibility Student Program id
	public boolean CheckVisStudentPrgid() {
		WebElement StudentProgramCreated=driver.findElement(By.xpath("//span[text()='Student Programs']/following::article[1]//span[@force-lookup_lookup]"));
		return StudentProgramCreated.isDisplayed();
	}
	
	//@Author : Kalam
	//Capture Student Program details	
	public void CaptureAllStudentProgDetails() throws InterruptedException {
	List<WebElement> StudentProgramCreated=driver.findElements(By.xpath("//span[text()='Student Programs']/following::article[1]//span[@force-lookup_lookup]"));
	
	for(int k=0;k<StudentProgramCreated.size();k++) {
		
		System.out.println("The Student payment created are "+k+ " " +StudentProgramCreated.get(k).getText());
		log.info("The Student payment created are "+k+ " " +StudentProgramCreated.get(k).getText());
		Thread.sleep(500);
	}
	}
	
	//@Author : Kalam
	//Check created Program
	public String CapturePrgCreated() throws InterruptedException {
	Scrollpagedown();
	String Progval = driver.findElement(By.xpath("//span[text()='Student Programs']/following::article[1]//span[@force-lookup_lookup]")).getText();
	return Progval;
	}
	
	//@Author : Kalam
	//Check the Super status
	public String CaptureSuperStatus() {
	String SuperStatus = driver.findElement(By.xpath("//div[@records-highlightsdetailsitem_highlightsdetailsitem]/p[@title='Super Status']/following::lightning-formatted-text")).getText();
	return SuperStatus;
	}
	
	//@Author : Kalam
	//Check Status
	public String CaptureStatus() {
	String Status = driver.findElement(By.xpath("//div[@records-highlightsdetailsitem_highlightsdetailsitem]/p[@title='Status']/following::lightning-formatted-text")).getText();
	return Status;
	}
	
	//@Author : Kalam
	//Verify the PE shipped call is present
	
	public boolean CheckVisPEShippedCall() throws InterruptedException {
		 Scrollpagedown();
		  
		  WebElement ele = driver.findElement(By.xpath("//span[text()='Open Activities']//following::a[text()='PE - Shipped Call']"));
		 return ele.isDisplayed();
	}
	
	//@Author : Kalam
	//Verify the Workshop - Welcome Call is present
	
	public boolean CheckVisWSWelcomeCall() throws InterruptedException {
		 Scrollpagedown();
		 Scrollpagedown();
		  WebElement ele = driver.findElement(By.xpath("//span[text()='Open Activities']//following::a[text()='Workshop - Welcome Call']"));
		 return ele.isDisplayed();
	}

	//@Author : Kalam
	//Verify the PE shipped call is present
	
	public boolean CheckVisProdPEShippedCall() throws InterruptedException {
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		  js.executeScript("scroll(0,400);");
		  Thread.sleep(2000);
		  
		  WebElement ele = driver.findElement(By.xpath("//span[text()='Open Activities']//following::a[text()='PE - Shipped Call']"));
		 return ele.isDisplayed();
	}
	
	//@Author : Kalam
	public boolean CheckVisProdPEShippedCall_UAT() throws InterruptedException {
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		  js.executeScript("scroll(0,650);");
		  Thread.sleep(2000);
		  
		  WebElement ele = driver.findElement(By.xpath("//span[text()='Open Activities']//following::a[text()='PE - Shipped Call']"));
		 return ele.isDisplayed();
	}
	
	//@Author : Kalam
	//Check BTC Welcome Call
	public boolean CheckVisBTCWelcomeCall_UAT() throws InterruptedException {
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		  js.executeScript("scroll(0,650);");
		  Thread.sleep(2000);
		  
		  WebElement ele = driver.findElement(By.xpath("//span[text()='Open Activities']//following::a[text()='BTC Welcome Call']"));
		 return ele.isDisplayed();
	}
  
	//@Author : Kalam
	 //Click on PE shipped task
	public void ClickPEShipped() throws InterruptedException {
		WebElement ele = driver.findElement(By.xpath("//span[text()='Open Activities']//following::a[text()='PE - Shipped Call']"));
		Actions ac= new Actions(driver);
		//waitForElementToVisible(ele);
		ac.moveToElement(ele).build().perform();
		jsClick(ele);
		Thread.sleep(1000);
		//ele.click();
	}
	
	//@Author : Kalam
	 //Click on BTC Welcome Call
	public void ClickBTCWelcomeCall() throws InterruptedException {
		WebElement ele = driver.findElement(By.xpath("//span[text()='Open Activities']//following::a[text()='BTC Welcome Call']"));
		Actions ac= new Actions(driver);
		//waitForElementToVisible(ele);
		ac.moveToElement(ele).build().perform();
		jsClick(ele);
		Thread.sleep(1000);
		//ele.click();
	}
	
	
	//@Author : Kalam
	 //Click on Workshop - Welcome Call task
	public void ClickWSWelcomeCall() throws InterruptedException {
		WebElement ele = driver.findElement(By.xpath("//span[text()='Open Activities']//following::a[text()='Workshop - Welcome Call']"));
		Actions ac= new Actions(driver);
		//waitForElementToVisible(ele);
		ac.moveToElement(ele).build().perform();
		jsClick(ele);
		Thread.sleep(3000);
		//ele.click();
	}
	
	//@Author : Kalam
	//Click on Student Prog
	public void ClickStudentProg() throws InterruptedException {
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
	  js.executeScript("scroll(0,200);");
	  Thread.sleep(2000);
	  
	  driver.findElement(By.xpath("//span[text()='Student Programs']/following::span[@force-lookup_lookup]")).click();
	  Thread.sleep(3000);
	}
	
	//@Author : Kalam
	//Click on Student Prog
	public void ClickStudentProg2() throws InterruptedException {
		WebElement ele1 = driver.findElement(By.xpath("//span[text()='Student Programs']/following::span[@force-lookup_lookup]"));
		Actions ac= new Actions(driver);
		ac.moveToElement(ele1).build().perform();
		Thread.sleep(2000);
		jsClick(ele1);
		Thread.sleep(3000);
	}
	
	//@Author : Kalam
	//Click Student sales order in Student Program
	public void ClickSSOinStuProg() throws InterruptedException {
	  driver.findElement(By.xpath("//span[text()='Student Sales Order']/following::span[@force-lookup_lookup]")).click();
	  Thread.sleep(2000);
	}
	//span[text()='Phone']/following::a
	
	//@Author : Kalam
	//Capture Phone
	public String CapturePhoneNo() {
	return driver.findElement(By.xpath("//span[text()='Phone']/following::a")).getText();
	}
	
	//@Author : Kalam	
	//Capture Account Name
	public String CaptureAccOwnrNam() {
	return driver.findElement(By.xpath("//span[text()='Account Name']/following::lightning-formatted-name")).getText();
	}
	
	//@Author : Kalam
	//Capture Account Owner Name
	public String CaptureAccOwnerNam() throws InterruptedException {
	Scrollhome();
	return driver.findElement(By.xpath("//span[text()='Account Owner']/following::a/following::span")).getText().replaceAll("Open ", "").replaceAll(" Preview", "");
	}

	//@Author : Kalam
	//Capture 15 digit id from user
	public String Capture15digitid() {
		String[] id= driver.findElement(By.xpath("//span[text()='Account Name']/following::a")).getAttribute("href").split("/");
		System.out.println(id[5]);
		return id[5];
	}
	
	//@Author : Kalam
	//Capture Account Owner Name
	public void ClickAccOwnerNam() throws InterruptedException {
	//Actions ac = new Actions(driver);
	//ac.moveToElement(driver.findElement(By.xpath("//span[text()='Account Owner']/following::a"))).build().perform();
	//Thread.sleep(500);
	jsClick(driver.findElement(By.xpath("//span[text()='Account Owner']/following::a")));
	Thread.sleep(3000);
	}
	
	//@Author : Kalam
	//Navigate to Account Owner Tab
	public void ClickAccOwnrTab() throws InterruptedException {
		jsClick(driver.findElement(By.xpath("//a[@title='"+CaptureAccOwnrNam()+"'][@class='tabHeader slds-tabs--default__link slds-p-right--small slds-grow ']")));
		Thread.sleep(2000);
	}
	
	//@Author : Kalam
	//Navigate to Account Owner Tab
	public void ClickAccOwnrTab2(String val) throws InterruptedException {
		jsClick(driver.findElement(By.xpath("//a[@title='"+val+"'][@class='tabHeader slds-tabs--default__link slds-p-right--small slds-grow ']")));
		Thread.sleep(2000);
	}
	
	//@Author : Kalam
	//Open Activities count 
	public String OpenActivitiesCount() throws InterruptedException {
		Scrollpagedown();
		return driver.findElement(By.xpath("//span[text()='Open Activities']/following::span[@title]")).getAttribute("title");
	}

	//@Author : Kalam
	//Verify the PE OnBoarding call is present
	
	public boolean CheckVisPEOnboardingCall() throws InterruptedException {

		// JavascriptExecutor js = (JavascriptExecutor) driver;
		//  js.executeScript("scroll(0,900);");//previous value 750
		 // Thread.sleep(2000);
		  Scrollpagedown();
          /*
           * WebElement ele = driver.findElement(By.
           * xpath("//span[text()='Open Activities']//following::a[text()='PE - Onboarding Call']"
           * ));
           * return ele.isDisplayed();
           */

		Scrollpagedown();
		Scrollpagedown();
		WebElement ele = driver.findElement(By.xpath("//span[text()='Open Activities']//following::a[text()='PE - Onboarding Call']"));
		return ele.isDisplayed();
	}
	
	//@Author : Kalam
	//Verify the Mentor OnBoarding call is present
	
	public boolean CheckVisMentorOnboardingCall() throws InterruptedException {
		Scrollpagedown();
		Scrollpagedown();
		WebElement ele = driver.findElement(By.xpath("//span[text()='Open Activities']//following::a[text()='Mentor - Onboarding Call']"));
		return ele.isDisplayed();
//>>>>>>> master2
	}
	
	//@Author : Kalam
	//Verify the Workshop - Onboarding Call is present
	
	public boolean CheckVisWSOnboardingCall() throws InterruptedException {
	    Scrollpagedown();
        Scrollpagedown();
		  
		  WebElement ele = driver.findElement(By.xpath("//span[text()='Open Activities']//following::a[text()='Workshop - Onboarding Call']"));
		 return ele.isDisplayed();
	}
  
	//@Author : Kalam
	 //Click on Workshop - Onboarding Call task
	public void ClickWSOnboardngCall() throws InterruptedException {
		WebElement ele = driver.findElement(By.xpath("//span[text()='Open Activities']//following::a[text()='Workshop - Onboarding Call']"));
		jsClick(ele);
		Thread.sleep(2200);
	}
	
	//@Author : Kalam
	 //Click on PE OnBoarding task
	public void ClickPEOnboardngCall() throws InterruptedException {
		WebElement ele = driver.findElement(By.xpath("//span[text()='Open Activities']//following::a[text()='PE - Onboarding Call']"));
		jsClick(ele);
		Thread.sleep(2200);
	}
	
	//@Author : Kalam
	 //Click on Mentor OnBoarding task
	public void ClickMentorOnboardngCall() throws InterruptedException {
		WebElement ele = driver.findElement(By.xpath("//span[text()='Open Activities']//following::a[text()='Mentor - Onboarding Call']"));
		jsClick(ele);
		Thread.sleep(2200);
	}
	
	//@Author : Kalam
	//Verify the PE OnBoarding call is present
	
	public boolean CheckVisPEFollowUpCall() throws InterruptedException {
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		  js.executeScript("scroll(0,500);");
		  Thread.sleep(2000);
		  
		  WebElement ele = driver.findElement(By.xpath("//span[text()='Open Activities']//following::a[contains(text(),'PE - Follow Up')]"));
		 return ele.isDisplayed();
	}
	
	//@Author : Kalam
	//Verify the PE OnBoarding call is present
	
	public boolean CheckVisFollowUpTutorandMentorCall() throws InterruptedException {
		 Scrollpagedown();
		 Scrollpagedown();
		  Thread.sleep(500);
		  
		  //WebElement ele = driver.findElement(By.xpath("//span[text()='Open Activities']//following::a[text()='Followup "+counter+"/Tutor & Mentor Feedback']"));
		  WebElement ele = driver.findElement(By.xpath("//span[text()='Open Activities']//following::a[contains(text(),'Follow')]"));
		 return ele.isDisplayed();
	}
	
	//@Author : Kalam
	//Verify the Mentor follow up is present
	
	public boolean CheckVisMentorFollowUpCall() throws InterruptedException {
		 Scrollpagedown();
		 Scrollpagedown();
		  Thread.sleep(2000);
		  WebElement ele = driver.findElement(By.xpath("//span[text()='Open Activities']//following::a[contains(text(),'Mentor - Follow Up Call')]"));
		 return ele.isDisplayed();
	}
	
	//@Author : Kalam
	 //Click on PE OnBoarding task
	public void ClickPEFollowUpCall() throws InterruptedException {
		WebElement ele = driver.findElement(By.xpath("//span[text()='Open Activities']//following::a[contains(text(),'PE - Follow Up')]"));
		jsClick(ele);
		Thread.sleep(3500);
	}
	
	//@Author : Kalam
	 //Click on Followup 1/Tutor & Mentor Feedback
	public void ClickFollowUpTutorandMentorCall() throws InterruptedException {
		//WebElement ele = driver.findElement(By.xpath("//span[text()='Open Activities']//following::a[text()='Followup "+counter+"/Tutor & Mentor Feedback']"));
		WebElement ele = driver.findElement(By.xpath("//span[text()='Open Activities']//following::a[contains(text(),'Follow')]"));
		jsClick(ele);
		Thread.sleep(3500);
		counter++;
	}
	
	//@Author : Kalam
	 //Click on Mentor follow up call
	public void ClickMentorFollowUpCall() throws InterruptedException {
		WebElement ele = driver.findElement(By.xpath("//span[text()='Open Activities']//following::a[contains(text(),'Mentor - Follow Up Call')]"));
		jsClick(ele);
		Thread.sleep(3500);
		counter++;
	}
  
	//@Author : Kalam
	//Click Open Activities -> New Task
	public void ClickOpenActivitiestoNewTask() throws InterruptedException {

	    Scrollpagedown();
		Scrollpagedown();
		Scrollend();
		WebElement ele1 =  driver.findElement(By.xpath("//span[text()='Open Activities']"));
      	//Thread.sleep(800);
		Actions ac= new Actions(driver);
		ac.moveToElement(ele1).build().perform();
		//Thread.sleep(2000);
		jsClick(ele1);
		//Thread.sleep(800);
		jsClick(driver.findElement(By.xpath("//h1[text()='Open Activities']/following::div[text()='New Task']")));
		Thread.sleep(1500);
	}
	
	//@Author : Kalam
	//Click on Open Activities drop down
	public void ClickOpenActiDD() {
	  try {
		  WebElement ele1 =  driver.findElement(By.xpath("//span[text()='Open Activities']/following::lightning-icon"));
      	//Thread.sleep(800);
		Actions ac= new Actions(driver);
		ac.moveToElement(ele1).build().perform();
		Thread.sleep(1200);
		jsClick(ele1);
      	//ele1.click();
	  }
		catch(Throwable t){
			t.printStackTrace();
		}
	  try {
		  JavascriptExecutor js = (JavascriptExecutor) driver;
		  	js.executeScript("scroll(0,750);");
		  	Thread.sleep(2000);
          WebElement ele1 =  driver.findElement(By.xpath("//span[text()='Open Activities']/following::lightning-icon"));
			Actions ac= new Actions(driver);
			ac.moveToElement(ele1).click().build().perform();
			Thread.sleep(1200);
	  }
	  catch(Throwable t) {
		  t.printStackTrace();
	  }
	}
	
	//@Author : Kalam
	//Click on Open Activities drop down
		public void ClickOpenActiDD2() throws InterruptedException {
			  JavascriptExecutor js = (JavascriptExecutor) driver;
			  	js.executeScript("scroll(0,775);");
			  	Thread.sleep(2000);
			  WebElement ele1 =  driver.findElement(By.xpath("//span[text()='Open Activities']/following::lightning-icon"));
	      	//Thread.sleep(800);
			Actions ac= new Actions(driver);
			ac.moveToElement(ele1).build().perform();
			Thread.sleep(1200);
			jsClick(ele1);
	      	//ele1.click();
		 
		}
	
	//@Author : Kalam
	//Click on Open Activities drop down
	public void ClickOpenActiDD_Prod() {
	  try {
		  WebElement ele1 =  driver.findElement(By.xpath("//span[text()='Open Activities']/following::lightning-icon"));
      	//Thread.sleep(800);
		Actions ac= new Actions(driver);
		ac.moveToElement(ele1).click().build().perform();
		Thread.sleep(1200);
      	//ele1.click();
	  }
		catch(Throwable t){
			t.printStackTrace();
		}
	  try {
		  JavascriptExecutor js = (JavascriptExecutor) driver;
		  	js.executeScript("scroll(0,525);");
		  	Thread.sleep(2000);
          WebElement ele1 =  driver.findElement(By.xpath("//span[text()='Open Activities']/following::lightning-icon"));
			Actions ac= new Actions(driver);
			ac.moveToElement(ele1).click().build().perform();
			Thread.sleep(1200);
	  }
	  catch(Throwable t) {
		  t.printStackTrace();
	  }
	}
	
	//@Author : Kalam
	//Click on Open Activities drop down
    public void ClickNearestStudentCenters() throws InterruptedException {
        Scrollpagedown();
        Scrollpagedown();
        Scrollend();
        visibleText(By.xpath("//span[text()='Nearest Student Centers']"));
        jsClick(driver.findElement(By.xpath("//span[text()='Nearest Student Centers']")));
        Thread.sleep(2000); 
    }
	
  //@Author : Kalam
    //Click Student Programs
    public void ClickStudentPrograms() throws InterruptedException {
        Scrollpagedown();
        try {
            Scrollpagedown();
            visibleText(By.xpath("//span[text()='Student Programs']"));
            jsClick(driver.findElement(By.xpath("//span[text()='Student Programs']")));
        }
        catch(Throwable t)
        {
            Scrollpagedown();
            Thread.sleep(1000);
            jsClick(driver.findElement(By.xpath("//span[text()='Student Programs']")));
        }
        
        Thread.sleep(2000); 
    }
    
  //@Author : Kalam
	//Click on Cases drop down
	public void ClickCasesiDD() {
	  try {
		  WebElement ele1 =  driver.findElement(By.xpath("//span[text()='Cases']/following::lightning-icon"));
      	//Thread.sleep(800);
		Actions ac= new Actions(driver);
		ac.moveToElement(ele1).click().build().perform();
		Thread.sleep(800);
      	//ele1.click();
	  }
		catch(Throwable t){
			t.printStackTrace();
		}
	  try {
		  JavascriptExecutor js = (JavascriptExecutor) driver;
		  	js.executeScript("scroll(0,600);");
		  	Thread.sleep(2000);
          WebElement ele1 =  driver.findElement(By.xpath("//span[text()='Cases']/following::lightning-icon"));
			Actions ac= new Actions(driver);
			ac.moveToElement(ele1).click().build().perform();
			Thread.sleep(800);
	  }
	  catch(Throwable t) {
		  t.printStackTrace();
	  }
	}
	
	//@Author : Kalam
	//Click on Cases New Task Option
	public void ClickNew() throws InterruptedException {
	driver.findElement(By.xpath("//span[text()='Cases']/following::lightning-icon/following::a[@title='New']")).click();
	Thread.sleep(2000);
	}
	
	//@Author : Kalam
	//Click on Open Activities New Task Option
	public void ClickNewTask() throws InterruptedException {
	WebElement ele = driver.findElement(By.xpath("//span[text()='Open Activities']/following::lightning-icon/following::a[@title='New Task']"));
	Actions ac= new Actions(driver);
	ac.moveToElement(ele).build().perform();
	jsClick(ele);
	Thread.sleep(2000);
	}
	
	//@Author : Kalam
	//Click on Cases Mobile card
	public void ClickCasesMC() throws InterruptedException {
	Thread.sleep(800);
	Actions ac = new Actions(driver);
	ac.moveToElement(driver.findElement(By.xpath("//span[text()='Cases']")));
	jsClick(driver.findElement(By.xpath("//span[text()='Cases']")));
	Thread.sleep(2000);
	}
	
	//@Author : Kalam
	//Click on Cases Mobile card
	public void ClickCasesMC2() throws InterruptedException {
	Scrollpagedown();
	Scrollpagedown();
	Scrollpagedown();
	
	Actions ac = new Actions(driver);
	ac.moveToElement(driver.findElement(By.xpath("//span[text()='Cases'][@title]")));
	jsClick(driver.findElement(By.xpath("//span[text()='Cases'][@title]")));
	Thread.sleep(2000);
	}
	
	//@Author : Kalam
	//Delete the created Student Prog
	public void DeleteCreatedStuProg() throws InterruptedException {
		Scrollpagedown();
		WebElement ele4= driver.findElement(By.xpath("//span[text()='Student Programs']/following::span[@force-lookup_lookup]/following::lightning-button-menu"));
		Actions ac=new Actions(driver);
		ac.moveToElement(ele4).build().perform();
		jsClick(ele4);
		Thread.sleep(1000);
		
		jsClick(driver.findElement(By.xpath("//span[text()='Student Programs']/following::span[@force-lookup_lookup]/following::lightning-button-menu/following::a[@title='Delete']")));
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//span[text()='Delete']")).click();
		Thread.sleep(3000);
	}
	
	//@Author : Kalam
	//Delete the created Student Prog
	public void DeleteAllCreatedStuProg() throws InterruptedException {
		//WebElement ele4= driver.findElement(By.xpath("//span[text()='Student Programs']/following::span[@force-lookup_lookup]/following::lightning-button-menu"));
		//Actions ac=new Actions(driver);
		//ac.moveToElement(ele4).build().perform();
		//jsClick(ele4);
		//Thread.sleep(1000);
		Scrollpagedown();
		List<WebElement> list = driver.findElements(By.xpath("//span[text()='Student Programs']/following::span[@force-lookup_lookup]/following::button[@class='slds-button slds-button_icon-border slds-button_icon-x-small']"));
		//List<WebElement> list2= driver.findElements(By.xpath("//span[text()='Student Programs']/following::span[@force-lookup_lookup]/following::lightning-button-menu/following::a[@title='Delete']"));
		for(int i=0;i<list.size();i++) {
			jsClick(list.get(i));
			Thread.sleep(1000);
			jsClick(driver.findElement(By.xpath("//span[text()='Student Programs']/following::span[@force-lookup_lookup]/following::lightning-button-menu/following::a[@title='Delete']")));
			Thread.sleep(1000);
			visibleText(By.xpath("//h2[text()='Delete Student Program']"));
			jsClick(driver.findElement(By.xpath("//span[text()='Delete']")));
			Thread.sleep(3000);
		}
	}
	
	//@Author : Kalam
	//Delete the created Student payment
	public void DeleteAllCreatedStuPayment() throws InterruptedException {
		List<WebElement> list = driver.findElements(By.xpath("//span[text()='Student Payments']/following::span[@force-lookup_lookup]/following::button[@class='slds-button slds-button_icon-border slds-button_icon-x-small']"));
		//List<WebElement> list2= driver.findElements(By.xpath("//span[text()='Student Programs']/following::span[@force-lookup_lookup]/following::lightning-button-menu/following::a[@title='Delete']"));
		for(int i=0;i<list.size();i++) {
			jsClick(list.get(i));
			Thread.sleep(1000);
			jsClick(driver.findElement(By.xpath("//span[text()='Student Payments']/following::span[@force-lookup_lookup]/following::lightning-button-menu/following::a[@title='Delete']")));
			Thread.sleep(1000);
			//visibleText(By.xpath("//h2[contains(text(),'Student')] | //h2[contains(text(),'Delete')]"));
			visibleText(By.xpath("//h2[contains(text(),'Delete')]"));
			jsClick(driver.findElement(By.xpath("//span[text()='Delete']")));
			Thread.sleep(3000);
		}
	}
	
	//@Author : Kalam
	//Navback to Account screen
	public void NavBackToAccount() throws InterruptedException {
		WebElement ele5 = driver.findElement(By.xpath("//button[@title='Show Navigation Menu']"));
		jsClick(ele5);
		//ele5.click();
		Thread.sleep(1000);
		
		jsClick(driver.findElement(By.xpath("//span[text()='Accounts'][@class='menuLabel slds-listbox__option-text slds-listbox__option-text_entity']")));
		Thread.sleep(2000);
	}
	  
	
	//@Author : Kalam
	//Delete the Created Account
	public void DeleteAccountCreated(String val) throws InterruptedException {

		WebElement IcnDownxpath = driver.findElement(By.xpath("//lightning-icon[@class='slds-icon-utility-down slds-button__icon slds-icon_container forceIcon']"));
	    jsClick(IcnDownxpath);
		Thread.sleep(1000);
		jsClick(driver.findElement(By.xpath("//ul/following::span[text()='Recently Viewed']")));
		Thread.sleep(2000);
		jsClick(driver.findElement(By.xpath("//a[text()='"+val+"']/following::span[@class='slds-icon_container slds-icon-utility-down']")));
		Thread.sleep(1000);
		jsClick(driver.findElement(By.xpath("//a[@title='Delete']")));
		Thread.sleep(1000);
		jsClick(driver.findElement(By.xpath("//button/span[text()='Delete']")));
		Thread.sleep(1500);
	}
	
	//@Author : Kalam
    //Run Manual Assignment the Created Account
    public void RunManualAssignment(String val) throws InterruptedException {

        WebElement IcnDownxpath = driver.findElement(By.xpath("//lightning-icon[@class='slds-icon-utility-down slds-button__icon slds-icon_container forceIcon']"));
        jsClick(IcnDownxpath);
        Thread.sleep(1000);
        driver.findElement(By.xpath("//ul/following::span[text()='Recently Viewed']")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//a[text()='"+val+"']/preceding::span[@class='slds-checkbox--faux'][1]")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//*[text()='Run Manual Assignment']")).click();
        Thread.sleep(1000);
        
    }
	
	//@Author : Kalam
	//Refresh tab
	public void RefreshTab() throws InterruptedException {
	jsClick(driver.findElement(By.xpath(btnDrpdwnxpath)));
	Thread.sleep(900);
	
	jsClick(driver.findElement(By.xpath(btnRefreshxpath)));

	Thread.sleep(1500);
	}
	
	//@Author : Kalam
	//Refresh tab
	public void RefreshTab_Targetframe() throws InterruptedException {
		Thread.sleep(1000);
		try {
			driver.findElement(By.xpath(btnDrpdwnxpath)).click();
			Thread.sleep(900);
			
			driver.findElement(By.xpath(btnRefreshxpath)).click();
			Thread.sleep(1500);
			}
			catch(WebDriverException e){
				jsClick(driver.findElement(By.xpath(btnDrpdwnxpath)));
				Thread.sleep(900);
				
				jsClick(driver.findElement(By.xpath(btnRefreshxpath)));
				Thread.sleep(1500);
			}
			 catch(Exception ee)
		    {
		        ee.printStackTrace();
		        throw ee;
		    }

	}
	
	//@Author : Kalam
	   //Refresh tab
    public void RefreshTab_Targetframe_IT() throws InterruptedException {

        
        try {
            visibleText(By.xpath("//div[text()='Task']/following::span[text()='Related To']"));
            driver.findElement(By.xpath(btnDrpdwnxpath)).click();
            Thread.sleep(900);
            
            driver.findElement(By.xpath(btnRefreshxpath)).click();
            Thread.sleep(1500);
            }
            catch(WebDriverException e){
                visibleText(By.xpath("//div[text()='Task']/following::span[text()='Related To']"));
                jsClick(driver.findElement(By.xpath(btnDrpdwnxpath)));
                Thread.sleep(900);
                
                jsClick(driver.findElement(By.xpath(btnRefreshxpath)));
                Thread.sleep(1500);
            }
             catch(Exception ee)
            {
                ee.printStackTrace();
                throw ee;
            }

    }
	
  //@Author : Kalam
	//Navigate to Session
	public void ClickSessionInformation() {
		 try {
			  WebElement ele1 =  driver.findElement(By.xpath("//span[text()='Sessions_Information']"));
	      	//Thread.sleep(800);
			Actions ac= new Actions(driver);
			ac.moveToElement(ele1).build().perform();
			jsClick(ele1);
			Thread.sleep(800);
	      	//ele1.click();
		  }
			catch(Throwable t){
				t.printStackTrace();
			}
		  try {
			  JavascriptExecutor js = (JavascriptExecutor) driver;
			  	js.executeScript("scroll(0,600);");
			  	Thread.sleep(2000);
	          WebElement ele1 =  driver.findElement(By.xpath("//span[text()='Sessions_Information']"));
				Actions ac= new Actions(driver);
				ac.moveToElement(ele1).click().build().perform();
				Thread.sleep(800);
		  }
		  catch(Throwable t) {
			  t.printStackTrace();
		  }
	}
	
	//@Author : Kalam
	//Navigate to Session
		public void ClickSessionInformation_UAT() {
			 try {
				  WebElement ele1 =  driver.findElement(By.xpath("//span[text()='Sessions Information']"));
		      	//Thread.sleep(800);
				Actions ac= new Actions(driver);
				ac.moveToElement(ele1).build().perform();
				//jsClick(ele1);
				Thread.sleep(800);
		      	ele1.click();
			  }
				catch(Throwable t){
					t.printStackTrace();
				}
			  try {
				  JavascriptExecutor js = (JavascriptExecutor) driver;
				  	js.executeScript("scroll(0,600);");
				  	Thread.sleep(2000);
		          WebElement ele1 =  driver.findElement(By.xpath("//span[text()='Sessions Information']"));
					Actions ac= new Actions(driver);
					ac.moveToElement(ele1).click().build().perform();
					Thread.sleep(800);
			  }
			  catch(Throwable t) {
				  t.printStackTrace();
			  }
		}
	
	//@Author : Kalam
	public void ClickOn(By by) throws InterruptedException {

		WebElement element = driver.findElement(by);
		new WebDriverWait(driver, 100).until(ExpectedConditions.elementToBeClickable(element));
		element.click(); // Expected condition for the element to be clickable
		Thread.sleep(3000);
	}
	
	//@Author : Kalam
	//Navigate to Exam Details
	public void ClickExamDetails() {
		 try {
			  Scrollpagedown();
			  Scrollpagedown();
			  WebElement ele1 =  driver.findElement(By.xpath("//span[text()='Exam Details']"));
	      	//Thread.sleep(800);
			Actions ac= new Actions(driver);
			ac.moveToElement(ele1).click().build().perform();
			Thread.sleep(800);
	      	//ele1.click();
		  }
			catch(Throwable t){
				t.printStackTrace();
			}
		  try {
			  Scrollpagedown();
	          WebElement ele1 =  driver.findElement(By.xpath("//span[text()='Exam Details']"));
				jsClick(ele1);
				Thread.sleep(800);
		  }
		  catch(Throwable t) {
			  t.printStackTrace();
		  }
	}
	
	//@Author : Kalam
	//Navigate to Student Classroom Associations
	public void ClickStudentClassroomAssociations() {
		 try {
			  Scrollpagedown();
			  //Scrollpagedown();
			  WebElement ele1 =  driver.findElement(By.xpath("//span[text()='Student Classroom Associations']"));
	      	//Thread.sleep(800);
			Actions ac= new Actions(driver);
			ac.moveToElement(ele1).click().build().perform();
			Thread.sleep(800);
	      	//ele1.click();
		  }
			catch(Throwable t){
				t.printStackTrace();
			}
		  try {
			  Scrollpagedown();
	          WebElement ele1 =  driver.findElement(By.xpath("//span[text()='Student Classroom Associations']"));
				jsClick(ele1);
				Thread.sleep(800);
		  }
		  catch(Throwable t) {
			  t.printStackTrace();
		  }
	}
	
	//@Author : Kalam
	//Navigate to Student App Informations
		public void ClickStudentAppInfo() throws InterruptedException {
		    Scrollpagedown();
		    Scrollpagedown();
		    Scrollend();
			WebElement ele1 =  driver.findElement(By.xpath("//span[text()='Student App Informations']"));
            jsClick(ele1);
		}
		
		//@Author : Kalam
		//Close the History tab
		public void ClickMinimizeHistory() throws InterruptedException {
			driver.findElement(By.xpath("//h2[@title='History']/following::button[@title='Minimize']")).click();
			Thread.sleep(1000);
		}
		
	//@Author : Kalam
	//Navigate to Open Activities
	public void ClickOpenActivities() throws InterruptedException {
		 Scrollpagedown();
	     Scrollpagedown();
	     WebElement ele1 =  driver.findElement(By.xpath("//span[text()='Open Activities']"));
	     jsClick(ele1);
	     Thread.sleep(800);
	}
	
	//@Author : Kalam
    //Navigate to Open Activities
    public void ClickActivityHistory_Scroll() throws InterruptedException {
         Scrollpagedown();
         Scrollpagedown();
         try {
         WebElement ele1 =  driver.findElement(By.xpath("//span[text()='Activity History']"));
         jsClick(ele1);
         }
         catch(Exception e) {
             driver.get(driver.getCurrentUrl());
             Thread.sleep(2000);
             WebElement ele1 =  driver.findElement(By.xpath("//span[text()='Activity History']"));
             jsClick(ele1);  
         }
         Thread.sleep(800);
    }
    
    //@Author : Kalam
    //Navigate to Open Activities
    public void ClickActivityHistory() throws InterruptedException {
         WebElement ele1 =  driver.findElement(By.xpath("//span[text()='Activity History']"));
         jsClick(ele1);
         Thread.sleep(800);
    }
	
	//@Author : Kalam
    //Navigate to Student Payments
    public void ClickStudentPayments() throws InterruptedException {
         
         Scrollpagedown();
         WebElement ele1 =  driver.findElement(By.xpath("//span[text()='Student Payments']"));
         jsClick(ele1);
         Thread.sleep(800);
    }
		
	//@Author : Kalam			
	//Scroll down
	public void Scrolldown() throws InterruptedException {

		driver.findElement(tag).sendKeys(Keys.DOWN);
		Thread.sleep(700);
	}
	
	//@Author : Kalam
	//Close all sub tabs opened
	public void CloseSubTabs() throws InterruptedException {
	    try {
	    visibleText((By.xpath("//ul[@class='tabBarItems slds-tabs--default__nav']//div[contains(@class,'close')]/button/lightning-primitive-icon[@data-aura-rendered-by]")));
	    }
	    catch(Exception e) {
	        e.printStackTrace();
	    }
	    List<WebElement> ele=driver.findElements(By.xpath("//ul[@class='tabBarItems slds-tabs--default__nav']//div[contains(@class,'close')]/button/lightning-primitive-icon[@data-aura-rendered-by]"));
		for(int i=0;i<ele.size();i++) {
			jsClick(ele.get(i));
			Thread.sleep(300);
		}
	}
	
	//@Author : Kalam
	//Verify CSO: page is loaded
	public void VerifyCSOPageLoad() throws InterruptedException {
	    try {
	    driver.switchTo().defaultContent();
	    visibleText(By.xpath("//ul[@class='tabBarItems slds-tabs--default__nav']//*[contains(text(),'CSO:')]"));
	    Thread.sleep(500);
	    }
	    catch(Throwable t) {
	        driver.switchTo().defaultContent();
	        visibleText(By.xpath("//ul[@class='tabBarItems slds-tabs--default__nav']//*[contains(text(),'CSO:')]"));
	        Thread.sleep(500); 
	    }
	}
	
	//@Author : Kalam
	//Close current sub tab open
	public void CloseCurrentSubTab() throws InterruptedException {
		//RefreshTab();
		driver.switchTo().defaultContent();
		Thread.sleep(800);
		List<WebElement> ele=driver.findElements(By.xpath("//ul[@class='tabBarItems slds-tabs--default__nav']//div[contains(@class,'close')]/button/lightning-primitive-icon[@data-aura-rendered-by]"));
		int m = ele.size()-1;
		try {
		clickButton(ele.get(m));
		}
		catch(Exception e) {
		    e.printStackTrace();
		    jsClick(ele.get(m));
		}
		Thread.sleep(1000);		
	}
	
	//@Author : Kalam
	//Close current sub tab open
	public void CloseCurrentSubTab_Prod() throws InterruptedException {
		//RefreshTab();
		try {
		driver.switchTo().defaultContent();
		List<WebElement> ele=driver.findElements(By.xpath("//ul[@class='tabBarItems slds-tabs--default__nav']//div[contains(@class,'close')]/button/lightning-primitive-icon[@data-aura-rendered-by]"));
		int m = ele.size()-1;
		jsClick(ele.get(m));
		Thread.sleep(300);		
		}
		catch(Throwable t) {
			driver.switchTo().defaultContent();
			List<WebElement> ele=driver.findElements(By.xpath("//ul[@class='tabBarItems slds-tabs--default__nav']//div[contains(@class,'close')]/button/lightning-primitive-icon[@data-aura-rendered-by]"));
			int m = ele.size()-1;
			jsClick(ele.get(m));
			Thread.sleep(300);	
		}
	}
	
	//@Author : Kalam
	//Mark all notifications as Read
    public void AllNotificationRead() throws InterruptedException {
    	Thread.sleep(1000);
    	driver.findElement(By.xpath("//lightning-icon[@class='slds-icon-utility-notification slds-button__icon slds-global-header__icon slds-icon_container forceIcon']")).click();
    	Thread.sleep(2000); 	
    	driver.findElement(By.xpath("//a[text()='Mark all as read']")).click();
    	Thread.sleep(5000);
    	}
    
  //@Author : Kalam
    //If No notification
    public void Notification() throws InterruptedException {
    	Thread.sleep(1500);
    	driver.findElement(By.xpath("//lightning-icon[@class='slds-icon-utility-notification slds-button__icon slds-global-header__icon slds-icon_container forceIcon']")).click();
    	Thread.sleep(2000);
    	String Text=driver.findElement(By.xpath("//div[@class='titleContainer']/following::span")).getText();
    	if(Text.equalsIgnoreCase("You don't have any notifications right now.")) {
    		driver.findElement(By.xpath("//button[@title='Close Notifications']")).click();
    		Thread.sleep(1000);
    	}
    	else {
    		if(isDisplayed((By.xpath("//a[text()='Mark all as read']")))) {
    			driver.findElement(By.xpath("//a[text()='Mark all as read']")).click();
            	Thread.sleep(1000);	
    		}
    		else {
    			driver.navigate().refresh();
    			Thread.sleep(5000);
    			try {
    			driver.findElement(By.xpath("//a[text()='Mark all as read']")).click();
    			}
    			catch (Exception e) {
    			    e.printStackTrace();
    			//  jsClick(driver.findElement(By.xpath("//a[text()='Mark all as read']")));  
    			}
            	Thread.sleep(1000);	
    		}
        	
    	}
    	}
    
  //@Author : Kalam
    //Check for Quick Access Buttons and show more buttons
    public void CheckButtonsQAandSM(String Env,String SheetName) throws Exception {
    	List<WebElement> List= driver.findElements(By.xpath("//ul/li[@class='visible']//button"));
		System.out.println(List.size());
		for(int i=0;i<List.size();i++) {
			
			String OnPagebuttons=List.get(i).getText();
			System.out.println(OnPagebuttons);
			setData(Env, SheetName, i + 1, 1, OnPagebuttons);
			if(i==List.size()-1) {
				setData2(Env, SheetName, i + 2, 1, List.size());
				jsClick(driver.findElement(By.xpath("//span[text()='Show more actions']")));
				Thread.sleep(1500);
				List<WebElement> Showmore= driver.findElements(By.xpath("//span[@runtime_platform_actions-ribbonmenuitem_ribbonmenuitem]"));
				System.out.println(Showmore.size());
				
				for(int j=0;j<Showmore.size();j++) {
					
					String ShowMorebuttons=Showmore.get(j).getText();
					System.out.println(ShowMorebuttons);
					setData(Env, SheetName, j + 1, 3, ShowMorebuttons);
					if(j==Showmore.size()-1) {
					setData2(Env, SheetName, j + 2, 3, Showmore.size());
				}

					//Actions ac= new Actions(driver);
					//ac.sendKeys(Keys.ESCAPE);
			}
				jsClick(driver.findElement(By.xpath("//span[text()='Show more actions']")));
		}
		}
    }
    
  //@Author : Kalam
    //Check for Related List
    public void CheckRelatedList(String Env,String SheetName) throws Exception {
		Scrollpagedown();
		Thread.sleep(2500);
		
		Scrollpagedown();
		Thread.sleep(2500);
		
		Scrollend();
		Thread.sleep(2500);
		
		List<WebElement> List1= driver.findElements(By.xpath("//span[@lst-listviewmanagerheader_listviewmanagerheader][@class='slds-truncate slds-m-right--xx-small']"));
		System.out.println(List1.size());
		for(int k=0;k<List1.size();k++) {
			String MobileCards=List1.get(k).getText();
			System.out.println(MobileCards);
			setData(Env, SheetName, k + 1, 5, MobileCards);
			if(k==List1.size()-1) {
				setData2(Env, SheetName, k + 2, 5, List1.size());
			}
			
			
		}
		
		
    }
    
  //@Author : Kalam
    //Check for Case List view Buttons
    public void CheckCaseListViewButtons(String Env,String SheetName) throws Exception {		
    	List<WebElement> List= driver.findElements(By.xpath("//ul/li[@class='slds-button slds-button--neutral']//div"));
		System.out.println(List.size());
		for(int i=0;i<List.size();i++) {
			
			String OnPagebuttons=List.get(i).getText();
			System.out.println(OnPagebuttons);
			setData(Env, SheetName, i + 1, 1, OnPagebuttons);
			if(i==List.size()-1) {
				setData2(Env, SheetName, i + 2, 1, List.size());
				if(isDisplayed((By.xpath("//span[text()='Show more actions']")))) {
				jsClick(driver.findElement(By.xpath("//span[text()='Show more actions']")));
				Thread.sleep(1500);
				}
				List<WebElement> Showmore= driver.findElements(By.xpath("//a/div[@class='forceActionLink']"));
				System.out.println(Showmore.size());
				
				for(int j=0;j<Showmore.size();j++) {
					
					String ShowMorebuttons=Showmore.get(j).getText();
					System.out.println(ShowMorebuttons);
					setData(Env, SheetName, j + 1, 3, ShowMorebuttons);
					if(j==Showmore.size()-1) {
					setData2(Env, SheetName, j + 2, 3, Showmore.size());
				}

					//Actions ac= new Actions(driver);
					//ac.sendKeys(Keys.ESCAPE);
			}//driver.findElement(By.xpath("//span[text()='Show more actions']")).isDisplayed()
				if(isDisplayed((By.xpath("//span[text()='Show more actions']")))) {
				jsClick(driver.findElement(By.xpath("//span[text()='Show more actions']")));
				}	
		}
		}
    }
    
  //@Author : Kalam
    //Enable all the buttons
    public void EnableButtons() throws InterruptedException { 
    	Scrollhome();
    	Thread.sleep(3000);
    	List<WebElement> List= driver.findElements(By.xpath("//*[local-name()='svg'][@class='slds-icon slds-icon-text-default slds-icon_xx-small']"));
    	for(int i=0;i<List.size();i++) {
    		jsClick(List.get(i));
    		Thread.sleep(500);
    	}
    }
    
  //@Author : Kalam
    //Naivagte to URL
    public void NavigateTo(String val) throws InterruptedException {
        driver.navigate().to(val);
        Thread.sleep(2000);
    }
    
  //@Author : Kalam
    //Check created Task
    public boolean CheckCreatedTask(String val) throws InterruptedException {
        Scrollpagedown();
    	if(driver.findElement(By.xpath("//span[text()='Open Activities']/following::article//a[@data-refid][text()=\""+val+"\"]")).isDisplayed()) {
    		return true;
    	}
    	else {//\""+val+"\"
    		return false;
    	}
    }
    
  //@Author : Kalam
    //Click created Task
    public void ClickCreatedTask_OpenActivities(String val) throws InterruptedException {
        
        Scrollpagedown();
        Scrollpagedown();
        Scrollend();
        
        jsClick(driver.findElement(By.xpath("//span[text()='Open Activities']/following::article//a[@data-refid][text()=\""+val+"\"]")));
        Thread.sleep(200);
    }
    
  //@Author : Kalam
    //Delete created Task
    public void DeleteCreatedTask_OpenActivities(String val) throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//span[text()='Open Activities']/following::article//a[@data-refid][text()=\""+val+"\"]/following::a")));
        Thread.sleep(1000);
        
        jsClick(driver.findElement(By.xpath("//a[@title='Delete']")));
        Thread.sleep(1000);
        
        driver.findElement(By.xpath("//span[text()='Delete']")).click();
        Thread.sleep(2000);
    }
    
  //@Author : Kalam
    //Check for Related List buttons values
    public void CheckRelatedListButtonVals(String Env,String SheetName) throws Exception {
		//Scrollpagedown();
		//Thread.sleep(4000);
		
		//Scrollend();
		//Thread.sleep(4000);
		
    	Scrollhome();
    	Thread.sleep(3000);
    	//span[@lst-listviewmanagerheader_listviewmanagerheader][@class='slds-truncate slds-m-right--xx-small']/following::div[@class='uiMenu']
    	//span[@lst-listviewmanagerheader_listviewmanagerheader][@class='slds-truncate slds-m-right--xx-small']/following::ul[@data-aura-class]/li//a/following::div[@role='button']
    	List<WebElement> List= driver.findElements(By.xpath("//span[@lst-listviewmanagerheader_listviewmanagerheader][@class='slds-truncate slds-m-right--xx-small']/following::ul[@data-aura-class]/li"));
		List<WebElement> List1= driver.findElements(By.xpath("//span[@lst-listviewmanagerheader_listviewmanagerheader][@class='slds-truncate slds-m-right--xx-small']/following::ul[@data-aura-class]/li//a"));
		List<WebElement> List2= driver.findElements(By.xpath("//span[@lst-listviewmanagerheader_listviewmanagerheader][@class='slds-truncate slds-m-right--xx-small']/following::ul[@class='slds-button-group-list']/li/lightning-button-menu/following::runtime_platform_actions-ribbon-menu-item/a/span"));
		//System.out.println(List1.size());
		for(int k=0;k<List.size();k++) {
			String MobileCards=List.get(k).getAttribute("data-target-reveals").replaceAll("sfdc:StandardButton.", "").replaceAll("__c.New", "").replaceAll("_", " ");
			System.out.println(MobileCards);
			setData(Env, SheetName, k + 1, 7, MobileCards);
			jsClick(List1.get(k));
			Thread.sleep(800);
			String ButtonVal=List2.get(k).getText();
			setData(Env, SheetName, k + 2, 7, ButtonVal);
			System.out.println(ButtonVal);
			if(k==List.size()-1) {
				setData2(Env, SheetName, k + 2, 7, List1.size());
			}
			
			
		}
    }
    
  //@Author : Kalam
    //Current owner check
    public String AccOwnerCheck() {
    	jsClick(driver.findElement(By.xpath("//span[text()='Account Owner']")));
    	System.out.println("Account Owner id: "+driver.findElement(By.xpath("//span[text()='Account Owner']/following::a")).getAttribute("href"));
    	String AccountOwner= driver.findElement(By.xpath("//span[text()='Account Owner']/following::a[1]//span[1]")).getText();
    	return AccountOwner;
    }
    
  //@Author : Kalam
    //Assign Account to logged in profile user
    public void AssignAccount(String val) throws InterruptedException {
    	jsClick(driver.findElement(By.xpath("//span[text()='Change Owner']")));
    	Thread.sleep(1500);
    	visibleText(By.xpath("//h2[text()='Change Account Owner']"));
    	driver.findElement(By.xpath("//h2[text()='Change Account Owner']/following::input[@placeholder]")).sendKeys(val);
    	Thread.sleep(1500);
    	jsClick(driver.findElement(By.xpath("//div[@title='"+val+"']")));
    	Thread.sleep(1000);
    	driver.findElement(By.xpath("//button[@name='change owner']")).click();
    	Thread.sleep(2500);    
    }
    
  //@Author : Kalam
    //Assign Account to logged in profile user
    public void AssignAccount2() throws InterruptedException {
		jsClick(driver.findElement(By.xpath("//span[@class='uiImage']/img[@title='User']")));
		Thread.sleep(2000);
		String val= driver.findElement(By.xpath("//a[@class='profile-link-label']")).getText();
		Thread.sleep(1000);
    	jsClick(driver.findElement(By.xpath("//span[text()='Change Owner']")));
    	Thread.sleep(1500);
    	driver.findElement(By.xpath("//h2[text()='Change Account Owner']/following::input[@placeholder]")).sendKeys(val);
    	Thread.sleep(1500);
    	jsClick(driver.findElement(By.xpath("//div[@title='"+val+"']")));
    	Thread.sleep(1000);
    	driver.findElement(By.xpath("//button[@name='change owner']")).click();
    	Thread.sleep(2500);    
    }
    
  //@Author : Kalam
    //Go to logged in user
    public void GotoLoggedInUser() throws InterruptedException {
 		jsClick(driver.findElement(By.xpath("//span[@class='uiImage']/img[@title='User']")));
 		Thread.sleep(2000);
 		jsClick(driver.findElement(By.xpath("//a[@class='profile-link-label']")));
 		Thread.sleep(2500); 
     }
    
  //@Author : Kalam
    //Edit the account page
    public void EditAccount() throws InterruptedException {
    	jsClick(driver.findElement(By.xpath("//button[@title='Edit Account Name']")));
		Thread.sleep(1000); 
     }
     
  //@Author : Kalam
    //Verify picklist for BYJU’s Classes type
    public void VerifyPL_ByjusClassestype(String val) throws InterruptedException {
    	scrollIntoView(driver.findElement(By.xpath("//label[text()='BYJU’s Classes type']")));
		jsClick(driver.findElement(By.xpath("//label[text()='BYJU’s Classes type']/following::button")));
		//System.out.println(driver.findElement(By.xpath("//label[text()='BYJU’s Classes type']/following::button/following::div[contains(@class,'vertical')]/lightning-base-combobox-item/span/span")));
		List<WebElement> list = driver.findElements(By.xpath("//label[text()='BYJU’s Classes type']/following::button/following::div[contains(@class,'vertical')]/lightning-base-combobox-item/span/span"));
		for(int i=0;i<list.size();i++) {
			String value = list.get(i).getText();
			
				if(value.equalsIgnoreCase(val)) {
					Assert.assertTrue(true);
					System.out.println("Current value "+value+" is equal to "+val+"");
					break;
				}	
				else {
					System.out.println("Current value "+value+" is not equal to "+val+"");
					if((i+1==list.size())) {
						System.out.println("All "+list.size()+" values were not matching the picklist value "+val+"");
						Assert.assertTrue(false);
					}
				}
			} 
		jsClick(driver.findElement(By.xpath("//label[text()='BYJU’s Classes type']/following::button")));
     }
    
  //@Author : Kalam
    //Update Student Email ID
    public void UpdateStudentEmailid(String val) throws InterruptedException {
    	scrollIntoView(driver.findElement(By.xpath("//label[text()='Student Email ID']")));
		jsClick(driver.findElement(By.xpath("//label[text()='Student Email ID']/following::input")));
		driver.findElement(By.xpath("//label[text()='Student Email ID']/following::input")).clear();
		driver.findElement(By.xpath("//label[text()='Student Email ID']/following::input")).sendKeys(val);
		
    }
    
  //@Author : Kalam
    //Update Student Email ID
    public void UpdateEmail(String val) throws InterruptedException {
    	//scrollIntoView(driver.findElement(By.xpath("//label[text()='Email']")));
		jsClick(driver.findElement(By.xpath("//label[text()='Email']/following::input")));
		driver.findElement(By.xpath("//label[text()='Email']/following::input")).clear();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//label[text()='Email']/following::input")).sendKeys(val);
		Thread.sleep(1000);
		jsClick(driver.findElement(By.xpath("//label[text()='WhatsApp Number'] | //span[contains(text(),'Whatsapp')]")));
    }
    
  //@Author : Kalam
    //Click Cancel button
    public void ClickCancel() throws InterruptedException {
    	jsClick(driver.findElement(By.xpath("//button[text()='Cancel']")));
		Thread.sleep(1000); 
     }
    
  //@Author : Kalam
    //Click Save button
    public void ClickSave() throws InterruptedException {
    	jsClick(driver.findElement(By.xpath("//button[text()='Save']")));
		Thread.sleep(1000); 
     }
    
    //Select Student Program \""+val+"\"
  //span[text()='Student Programs']/following::article//a//span[text()="Aakash BYJU'S Test Series"]
    public void SelectStudentProg(String val) throws InterruptedException {
        Scrollpagedown();
    	jsClick(driver.findElement(By.xpath("//span[text()='Student Programs']/following::article//a//span[text()=\""+val+"\"]")));
		Thread.sleep(1000); 
     }
    
  //@Author : Kalam
    //Account load wait
	public void AccountLoadwait() throws InterruptedException {

		Thread.sleep(5000);
	}
	
	//@Author : Kalam
    //Additional wait
	public void AdditionalWait() throws InterruptedException {

		Thread.sleep(2000);
	}
	
	//@Author : Kalam
	//Click Account Owner
	public void ClickAccountOwner() {
	    jsClick(driver.findElement(By.xpath("//div[text()='Person Account']/following::span[text()='Account Owner']/following::a")));
	}
	
	//@Author : Kalam
	//Dummy account for all orgs
   public void GetDummyAccount(String val) throws InterruptedException {
    if(val.equalsIgnoreCase("UAT")&&!val.equalsIgnoreCase("UATFC")) {
        driver.get("https://byjusprod--byjusuat.lightning.force.com/lightning/r/Account/001C2000003kSMBIA2/view");
        Thread.sleep(3500);
    }
    else if (val.equalsIgnoreCase("UATFC")) {
        driver.get("https://byjusprod--byjusuatfc.lightning.force.com/lightning/r/Account/001HF000001MoYfYAK/view");
        Thread.sleep(3500);
    }
    else {
        driver.get("https://byjusprod.lightning.force.com/lightning/r/Account/0019G000003RbAgQAK/view");
        Thread.sleep(3500);
    }
    }
	
 //@Author : Kalam
	public void ClickPersonAccount() throws InterruptedException {

		jsClick(driver.findElement(By.xpath("//div[text()='Person Account']")));
		
	}
    
	//@Author : Kalam
	public void Scrollpagedown() throws InterruptedException {

		driver.findElement(tag).sendKeys(Keys.PAGE_DOWN);
		Thread.sleep(1500);
	}
	
	//@Author : Kalam
	public void Scrollpageup() throws InterruptedException {

		driver.findElement(tag).sendKeys(Keys.PAGE_UP);
		Thread.sleep(1500);
	}
	
	//@Author : Kalam
	public void Scrollhome() throws InterruptedException {

		driver.findElement(tag).sendKeys(Keys.HOME);
		Thread.sleep(1200);
	}
	
	//@Author : Kalam
	public void Scrollend() throws InterruptedException {

		driver.findElement(tag).sendKeys(Keys.END);
		Thread.sleep(1200);
	}
	
	//@Author : Kalam
    public void CloseWindowArrayLast() throws InterruptedException{
        ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
        int i=tabs2.size()-1;
        driver.switchTo().window(tabs2.get(i));
        driver.close();
    }
	
  //@Author : Kalam
    public void jsClick(WebElement el) {
		try {
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("arguments[0].click();", el);
			System.out.println("Element clicked");
		} catch (Exception e){
			System.out.println("=============================================================");
			System.out.println("Exception-jsClick(): "+e.getMessage());
			takeScreenShot();
			e.printStackTrace();
			System.out.println("=============================================================");
		}
	}
    
  //@Author : Kalam
	// Scroll element to view
	public void scrollIntoView(WebElement element) {
		try {
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("arguments[0].scrollIntoView(true);", element);
			System.out.println("Page scrolled down");
		} catch (Exception e){
			System.out.println("=============================================================");
			System.out.println("Exception-scrollIntoView(): "+e.getMessage());
			takeScreenShot();
			e.printStackTrace();
			System.out.println("=============================================================");
		}    
	}
	
	//@Author : Kalam
	public boolean visibleText(By element)
	{
		WebDriverWait wait= new WebDriverWait(driver, 70);
		
		wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));
		
		System.out.println("Element is visible");
		return false;
	}
	
	//@Author : Kalam
    public void AccountOwnerTabClick(String val) throws InterruptedException {
        driver.findElement(By.xpath("//ul[@class='tabBarItems slds-grid']//span[text()='"+val+"']")).click();
        Thread.sleep(1000);
    }
	
    //@Author : Kalam
    public void Closebuttonpopup() {
        try {
            jsClick(driver.findElement(By.xpath("//button[@title='Close this window']")));
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
    
	//@Author : Kalam
    public void closeTabWindows() throws InterruptedException {
        Closebuttonpopup();
		List<WebElement> list= driver.findElements(By.xpath("//ul[@class='tabBarItems slds-grid']//div[@class='close slds-col--bump-left slds-p-left--none slds-context-bar__icon-action ']"));
		if (list.size() == 0) {
			System.out.println("There are no open tabs");
		} else {
			for (int i = 0; i < list.size(); i++) {
				try {
				list.get(i).click();
				Thread.sleep(200);
				}
				catch(Throwable t) {
					System.out.println("More tabs on page loaded later");
					driver.navigate().refresh();
					Thread.sleep(2000);
					List<WebElement> list1= driver.findElements(By.xpath("//ul[@class='tabBarItems slds-grid']//div[@class='close slds-col--bump-left slds-p-left--none slds-context-bar__icon-action ']"));
					for (int j = 0; j < list1.size(); j++) {
					    list1.get(j).click();
		                Thread.sleep(200);
					}
				}
			}
		}
    }
    
  //@Author : Kalam
    public void closeTabWindows(int a) throws InterruptedException {
        //Closebuttonpopup();
        List<WebElement> list= driver.findElements(By.xpath("//ul[@class='tabBarItems slds-grid']//div[@class='close slds-col--bump-left slds-p-left--none slds-context-bar__icon-action ']"));
        if (list.size() == 0) {
            System.out.println("There are no open tabs");
        } else {
            for (int i = 0; i < list.size(); i++) {
                try {
                list.get(i).click();
                Thread.sleep(200);
                }
                catch(Throwable t) {
                    System.out.println("More tabs on page loaded later");
                    driver.navigate().refresh();
                    Thread.sleep(2000);
                    List<WebElement> list1= driver.findElements(By.xpath("//ul[@class='tabBarItems slds-grid']//div[@class='close slds-col--bump-left slds-p-left--none slds-context-bar__icon-action ']"));
                    for (int j = 0; j < list1.size(); j++) {
                        try {
                            list1.get(j).click();
                        }
                        catch(Throwable t1)
                        {
                            list1.get(j).click();
                            Thread.sleep(200);
                        }
                    }
                }
            }
        }
    }
    
    //@Author : Kalam
    public void closeCurrentTabWindow() throws InterruptedException {
		List<WebElement> ele=driver.findElements(By.xpath("//div[contains(@class,'__icon-action')]/button[@class='slds-button slds-button_icon slds-button_icon-x-small slds-button_icon-container']"));
		int m = ele.size()-1;
		jsClick(ele.get(m));
		Thread.sleep(300);	
    }
   

    
    //@Author : Kalam
    public void setData(String fileName, String sheetName, int rowIndex, int cellIndex, String data) throws Exception {
        File location = new File(fileName);
        FileInputStream fis = new FileInputStream(location);
        XSSFWorkbook wb = new XSSFWorkbook(fis);
        XSSFSheet sheet1 = wb.getSheet(sheetName);
        if (sheet1.getRow(rowIndex) == null) {
        sheet1.createRow(rowIndex).createCell(cellIndex).setCellValue(data);
        } else {
        sheet1.getRow(rowIndex).createCell(cellIndex).setCellValue(data);
        }
        FileOutputStream fos = new FileOutputStream(location);
        wb.write(fos);
        wb.close();
    }
    
    /*
     * //@Author : Kalam
     * public void setData2(String fileName, String sheetName, int rowIndex, int
     * cellIndex, int data) throws Exception {
     * File location = new File(fileName);
     * FileInputStream fis = new FileInputStream(location);
     * XSSFWorkbook wb = new XSSFWorkbook(fis);
     * XSSFSheet sheet1 = wb.getSheet(sheetName);
     * if (sheet1.getRow(rowIndex) == null) {
     * sheet1.createRow(rowIndex).createCell(cellIndex).setCellValue(data);
     * } else {
     * sheet1.getRow(rowIndex).createCell(cellIndex).setCellValue(data);
     * }
     * FileOutputStream fos = new FileOutputStream(location);
     * wb.write(fos);
     * wb.close();
     * }
     */
    
    //@Author : Kalam
	public boolean isDisplayed(By element) {
		List<WebElement> list = driver.findElements(element);
		//System.out.println(list.toString());
		boolean value = false;
		if (!list.isEmpty()) {
			if (list.get(0).isDisplayed()) {
				value = true;
				return value;
			}
		} else {

			return value;
		}
		return value;
	}
	
	//@Author : Kalam
	public void clickButton(WebElement element)
	{
		WebDriverWait wait= new WebDriverWait(driver, 100);
		
		wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));
		
		System.out.println("Element is clickable");
		element.click();
	}
	 //**************************************************Manish Methods*****************************************************
	//Click on Refund Calling task
	//Author :: Manish
	
    public void ClickOnRefundCallingTask() throws InterruptedException {
        WebElement ele = driver.findElement(By.xpath("//span[text()='Open Activities']//following::span/a[text()='Primary IRT - Refund Calling']"));
        jsClick(ele);
        Thread.sleep(2200);
    }
    
    //Click on Capture Call Details button
    //Author :: Manish
    public void clickCaptureCallbutton()
    {
        driver.findElement(By.xpath("//div[@title='Capture Call Details']")).click();
    }
    
    // Navigate to Open Activities section and click on 'Open Activities'
    //Author :: Manish
    public void ClickOpenActivities_1() throws InterruptedException {
        
        Scrollpagedown();
        Scrollpagedown();
        Thread.sleep(3000);
        Scrollpagedown();
        Scrollend();
        WebElement ele1 =  driver.findElement(By.xpath("//span[text()='Open Activities']"));
       // scrollIntoView(ele1);
        //Thread.sleep(800);
        Actions ac= new Actions(driver);
        ac.moveToElement(ele1).build().perform();
        Thread.sleep(2000);
        jsClick(ele1);
        Thread.sleep(800);
    }
    
    //Author :: Manish
    public void clickCase3() throws InterruptedException
    {
        
          Scrollpagedown();
          Thread.sleep(1000);
          Scrollpagedown();
          Thread.sleep(1000);
          Scrollpagedown();
          Scrollend();
         
        WebElement ele=driver.findElement(By.xpath("//span[text()='Cases'][@title]"));
        scrollIntoView(ele);
        Actions ac = new Actions(driver);
        ac.moveToElement(driver.findElement(By.xpath("//span[text()='Cases'][@title]")));
        jsClick(driver.findElement(By.xpath("//span[text()='Cases'][@title]")));
        Thread.sleep(3000);
        
    }
    
    //This function assigns the Case owner as per the value passed
    //Author :: Manish
    public void assignNewCaseOwner(String val) throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//span[text()='Case Owner']/following::span[text()='Change Owner']")));
        Thread.sleep(1500);
        driver.findElement(By.xpath("//h2[text()='Change Case Owner']/following::input[@placeholder]")).sendKeys(val);
        Thread.sleep(1500);
        jsClick(driver.findElement(By.xpath("//div[@title='"+val+"']")));
        Thread.sleep(1000);
        driver.findElement(By.xpath("//button[@name='change owner']")).click();
        Thread.sleep(2500);    
    }

   
    
    //**************************************************Manali Methods*****************************************************
  
    //@Author : Manali
    // To get account team member
    public boolean verifyAccTeamMem(String val) throws InterruptedException {
      Scrollpagedown();
      jsClick(driver.findElement(By.xpath("//span[text()='Account Team']")));
      
      boolean flag = driver.findElement(By.xpath("//h1[text()='Account Team']/following::tr/following::div/a[text()='"+val+"']")).isDisplayed();
      return flag;
    }    
    
    
    //**************************************************Anil Methods*******************************************************
    //**************************************************Amit Methods*******************************************************
    //**************************************************Sumit Methods******************************************************
    
    //@Author: Sumit
    public void NavBackIntegrationLoginScreen() throws InterruptedException {
        WebElement ele5 = driver.findElement(By.xpath("//button[@title='Show Navigation Menu']"));
        Thread.sleep(1000);
        Actions ac = new Actions(driver);
        ac.moveToElement(ele5).build().perform();
        jsClick(ele5);
        Thread.sleep(1000);
        
        jsClick(driver.findElement(By.xpath("//span[text()='Integration Logging'][@class='menuLabel slds-listbox__option-text slds-listbox__option-text_entity']")));
        Thread.sleep(2000);
        
        driver.findElement(By.xpath("//span[@class='triggerLinkText selectedListView slds-page-header__title slds-truncate slds-p-right--xx-small uiOutputText']")).click();
        driver.findElement(By.xpath("//div[@class='uiInput uiAutocomplete uiInput--default uiInput--picklist']/input")).sendKeys("All");
        jsClick(driver.findElement(By.xpath("//ul/following::mark[text()='All']")));
        
    }
    
    //@Author: Sumit
    public void NavBackIntegrationLoginScreen1() throws InterruptedException {
        /*WebElement ele5 = driver.findElement(By.xpath("//button[@title='Show Navigation Menu']"));
        jsClick(ele5);
        Thread.sleep(1000);
        
        jsClick(driver.findElement(By.xpath("//span[text()='Integration Logging'][@class='menuLabel slds-listbox__option-text slds-listbox__option-text_entity']")));
        Thread.sleep(2000);*/
        driver.findElement(By.xpath("//button[@title='Show filters']")).click();
        Thread.sleep(2000);
        Actions ac = new Actions(driver);
        WebElement ele = driver.findElement(By.xpath("//a[@class='removeAll']"));
        ac.moveToElement(ele).build().perform();
        Thread.sleep(1000);
        jsClick(ele);
        Thread.sleep(1000);
        try {
        driver.findElement(By.xpath("//button[text()='Save']")).click();
        }
        catch(Exception e) {
            driver.findElement(By.xpath("//lightning-icon[contains(@class,'slds-icon-utility-close slds-icon_container')]")).click();
            Thread.sleep(1000);
        }
        
        }
    //@Author: Sumit
    public void DeleteCreatedStuCase() throws InterruptedException {
        //WebElement ele4= driver.findElement(By.xpath("//span[text()='Student Programs']/following::span[@force-lookup_lookup]/following::lightning-button-menu"));
        //Actions ac=new Actions(driver);
        //ac.moveToElement(ele4).build().perform();
        //jsClick(ele4);
        //Thread.sleep(1000);
        Scrollpagedown();
        List<WebElement> list = driver.findElements(By.xpath("//span[text()='Cases']/following::span[@force-lookup_lookup]/following::button[@class='slds-button slds-button_icon-border slds-button_icon-x-small']"));
        //List<WebElement> list2= driver.findElements(By.xpath("//span[text()='Student Programs']/following::span[@force-lookup_lookup]/following::lightning-button-menu/following::a[@title='Delete']"));
        for(int i=0;i<list.size();i++) {
            jsClick(list.get(i));
            Thread.sleep(1000);
            jsClick(driver.findElement(By.xpath("//span[text()='Cases']/following::span[@force-lookup_lookup]/following::lightning-button-menu/following::a[@title='Delete']")));
            Thread.sleep(1000);
         //   visibleText(By.xpath("//h2[text()='Delete Student Program']"));
            jsClick(driver.findElement(By.xpath("//span[text()='Delete']")));
            Thread.sleep(3000);
        }
    }
    //**************************************************Bhavana Methods****************************************************
    
    //@Author :: Bhavana
    // Navigate to Open Activities section and click on the mentioned open task
    public void ClickCreatedTaskOpenActivities_1(String val) throws InterruptedException {
        
        Scrollpagedown();
        Scrollpagedown();
        Thread.sleep(3000);
        Scrollpagedown();
        Scrollend();
        WebElement ele1 =  driver.findElement(By.xpath("//span[text()='Open Activities']/following::article//a[@data-refid][text()='"+val+"']"));
       // scrollIntoView(ele1);
        //Thread.sleep(800);
        Actions ac= new Actions(driver);
        ac.moveToElement(ele1).build().perform();
        Thread.sleep(2000);
        jsClick(ele1);
        Thread.sleep(800);
    }
  
    //@Author :: Bhavana
    // Get all the task names and check if it has only retention tasks
    public int checkOpenActivitiesRet()
    {
        List<WebElement> taskSubjects = driver.findElements(By.xpath("//tr/th/span/a"));
        int count = 0;
        for(int i=0;i<taskSubjects.size();i++)
        {
            if(!taskSubjects.get(i).getText().contains("Retention"))
                count++;
        }
        return count;
    }
    
    //@Author : Bhavana
    //Open Activities count //span[text()='Activity History']/following::span[@title]
    public String ActivityHistoryCount() throws InterruptedException {
        Scrollpagedown();
        Scrollpagedown();        
        return driver.findElement(By.xpath("//span[text()='Activity History']/following::span")).getText();
    }
    
    //@Author : Bhavana
    //Cases count 
    public String CasesCount() throws InterruptedException {
        Scrollpagedown();
        Scrollpagedown();        
        return driver.findElement(By.xpath("//span[text()='Cases']/following::span")).getText();
    }
    
    //@Author : Bhavana
    //Click on related contacts
    public void ClickRelatedCtctstoAddRS() throws InterruptedException {
        
        Actions ac = new Actions(driver);
        ac.moveToElement(driver.findElement(By.xpath("//span[text()='Related Contacts']")));
        jsClick(driver.findElement(By.xpath("//span[text()='Related Contacts']")));
        Thread.sleep(2000);
        jsClick(driver.findElement(By.xpath("//div[text()='Add Relationship']")));
        
    }
  
    //@Author : Bhavana
    //Click on related contacts
    public void SelectRole() throws InterruptedException {
       
        jsClick(driver.findElement(By.xpath("//div[text()='Roles']/following::span[text()='Siblings']")));
        Thread.sleep(2000);
        jsClick(driver.findElement(By.xpath("//div/lightning-button-icon/button[@title='Move selection to Chosen']")));
        
    }
    
    //@Author : Bhavana
    //Enter Contact Name in contact relationships
    public void EnterContactName(String name) throws InterruptedException {
       
        Scrollend();
        driver.findElement(By.xpath("//span[text()='Contact']/following::input")).sendKeys(name);
        Thread.sleep(5000);
        try
        {
            jsClick(driver.findElement(By.xpath("//h2[text()='New Account Contact Relationship']/following::span[text()='Contact']/following::input/following::li/a")));
            Thread.sleep(300);
        }
        catch(Throwable t)
        {
            Scrollpagedown();
            visibleText(By.xpath("//h2[text()='New Account Contact Relationship']/following::span[text()='Contact']/following::input/following::li/a/div/following::div[@title='Dummy Arla Lemke2']"));
            driver.findElement(By.xpath("//span[text()='Contact']/following::input")).clear();
            Thread.sleep(300);
            driver.findElement(By.xpath("//span[text()='Contact']/following::input")).sendKeys(name);
            Thread.sleep(5000);
            jsClick(driver.findElement(By.xpath("//h2[text()='New Account Contact Relationship']/following::span[text()='Contact']/following::input/following::li/a")));
            Thread.sleep(300);
        }
        jsClick(driver.findElement(By.xpath("//h2[text()='New Account Contact Relationship']/following::button/span[text()='Save']")));
        Thread.sleep(2000);
    }
    
    //@Author : Bhavana
    //Open a specific user in set up 
    public void openUserinSetup(String val) throws InterruptedException
    {
        jsClick(driver.findElement(By.xpath("//a[contains(@class,'menuTriggerLink')]")));
        Thread.sleep(2000);
        //jsClick(driver.findElement(By.xpath("//ul[@class='scrollable']/li[1]")));
        visibleText(By.xpath("//ul[@class='scrollable']/li[@id='related_setup_app_home']"));
        Thread.sleep(300);
        Actions ac=new Actions(driver);
        ac.moveToElement(driver.findElement(By.xpath("//ul[@class='scrollable']/li[@id='related_setup_app_home']"))).build().perform();
        driver.findElement(By.xpath("//ul[@class='scrollable']/li[@id='related_setup_app_home']")).click();
        Thread.sleep(2000);
        switchWindow();
        driver.findElement(By.xpath("//input[@placeholder='Search Setup']")).sendKeys(val);
        //Thread.sleep(2000);
        visibleText(By.xpath("//span[@title='"+val+"']"));
        
        jsClick(driver.findElement(By.xpath("//span[@title='"+val+"']")));
        Thread.sleep(2000);
    }
    
    //@Author : Bhavana
    //Change subject of SSO
    public void AddSubjectSSO(String sub) throws InterruptedException
    {
        driver.findElement(By.xpath("//span[contains(text(),'Student Sales Orders')]/following::dd/lst-template-list-field/force-lookup")).click();
        Thread.sleep(300);
        driver.findElement(By.xpath("//span[text()='Student Sales Order Name']/following::button")).click();
        Thread.sleep(300);
        driver.findElement(By.xpath("//label[text()='Student Sales Order Name']/following::input")).clear();
        Thread.sleep(300);
        driver.findElement(By.xpath("//label[text()='Student Sales Order Name']/following::input")).sendKeys(sub);
        Thread.sleep(300);
        driver.findElement(By.xpath("//label[text()='Student Sales Order Name']"));
        Thread.sleep(300);
     
        driver.findElement(By.xpath("//button[text()='Save']")).click();
        Thread.sleep(300);
    }
      
    //@Author : Bhavana
    //Add SSO with specified subject(name)
    public void AddSSOinSibling(String sub) throws InterruptedException
    {
        Scrollpagedown();
        Scrollpagedown();
        jsClick(driver.findElement(By.xpath("//span[text()='Student Programs']")));
        Thread.sleep(2000);
        jsClick(driver.findElement(By.xpath("//h1[text()='Student Programs']/following::tr[2]/th/span/a")));
        Thread.sleep(2000);
        jsClick(driver.findElement(By.xpath("//span[text()='Student Sales Order']/following::button[2]")));
        Thread.sleep(800);
        jsClick(driver.findElement(By.xpath("//label[text()='Student Sales Order']/following::input/following::lightning-primitive-icon")));
        Thread.sleep(800);
        driver.findElement(By.xpath("//label[text()='Student Sales Order']/following::input")).sendKeys(sub);
        Thread.sleep(800);
        try {
            
            jsClick(driver.findElement(
                    By.xpath("//label[text()='Student Sales Order']/following::input/following::li/lightning-base-combobox-item")));
        }
        catch(Throwable e)
        {
            clickButton(driver.findElement(
                    By.xpath("//label[text()='Student Sales Order']/following::input/following::li/lightning-base-combobox-item")));
        }
        
        Thread.sleep(800);
        jsClick(driver.findElement(By.xpath(" //button[text()='Save']")));
        Thread.sleep(2000);
    }
    
    //@Author : Bhavana
    //append last name of the account with given value
    public void appendLastName(String val)
    {
        driver.findElement(By.xpath("//span[text()='Account Name']/following::button/span")).click();
        driver.findElement(By.xpath("//label[text()='Last Name']/following::input")).sendKeys(val);
    }
    
    //@Author : Bhavana
    //Click Save button
    public void ClickSaveName() throws InterruptedException {
        driver.findElement(By.xpath("//button[text()='Save']")).click();
        Thread.sleep(1000); 
     }
    
    
    //@Author : Bhavana
    //Click Open Activities -> New Task
    public void ClickOpenActivitiestoNewTask1() throws InterruptedException {

        Scrollpagedown();
        Scrollpagedown();
        WebElement ele1 =  driver.findElement(By.xpath("//span[text()='Open Activities']"));
        //Thread.sleep(800);
        Actions ac= new Actions(driver);
        ac.moveToElement(ele1).build().perform();
        //Thread.sleep(2000);
        jsClick(ele1);
        //Thread.sleep(800);
        jsClick(driver.findElement(By.xpath("//h1[text()='Open Activities']/following::div[text()='New Task']")));
        Thread.sleep(1500);
    }
    
    //@Author : Bhavana
    //Click Open Activities
    public void ClickOpenActivities1() throws InterruptedException {

        Scrollpagedown();
        Scrollpagedown();
        WebElement ele1 =  driver.findElement(By.xpath("//span[text()='Open Activities']"));
        Thread.sleep(800);
        Actions ac= new Actions(driver);
        ac.moveToElement(ele1).build().perform();
        Thread.sleep(2000);
        jsClick(ele1);
        Thread.sleep(800);
    }
    
    //To switch the top most window
    public void switchWindow() throws InterruptedException{
        Set<String> winid = driver.getWindowHandles();
        Iterator<String> iter = winid.iterator();
        iter.next();
        String tab = iter.next();
        Thread.sleep(3000);
        driver.switchTo().window(tab);
    }
    
    //@Author : Bhavana
    //Change class on the account
    public void ChangeClass(String classNo) throws InterruptedException{
        Thread.sleep(1000);
        visibleText(By.xpath("//span[text()='Current Class']"));
        jsClick(driver.findElement(By.xpath("//span[text()='Current Class']/following::button")));
        Thread.sleep(1000);
        jsClick(driver.findElement(By.xpath("//label[text()='Current Class']/following::button")));
        Thread.sleep(1000);
        jsClick(driver.findElement(By.xpath("//label[text()='Current Class']/following::div/lightning-base-combobox-item/span/span[text()='"+classNo+"']")));
        ClickSaveName();
    }
    
     //@Author : Bhavana
     //To get the due date of given task
     public String GetDueDate(String sub,String date) throws InterruptedException
     {
         String min1 = getMinutes(date,1);
         String min2 = getMinutes(date,2);
         Thread.sleep(200);
         String dueDate = driver.findElement(
                 By.xpath("//a[text()='"+sub+"']/following::td[7]/span/span[text()='"+date+"']/preceding::td[6]/span/span | "
                        + "//a[text()='"+sub+"']/following::td[7]/span/span[contains(text(),'"+min1+"')]/preceding::td[6]/span/span | "
                        + "//a[text()='"+sub+"']/following::td[7]/span/span[contains(text(),'"+min2+"')]/preceding::td[6]/span/span")).getText();
         
         return dueDate;
     }
     //@Author : Bhavana
     //To get the assigned to of given task
     public String GetAssignedTo(String sub,String date) throws InterruptedException
     {
         String min1 = getMinutes(date,1);
         String min2 = getMinutes(date,2);
         Thread.sleep(200);
         String dueDate = driver.findElement(
                 By.xpath("//a[text()='"+sub+"']/following::td[7]/span/span[text()='"+date+"']/preceding::td[5]/span/a | "
                        + "//a[text()='"+sub+"']/following::td[7]/span/span[contains(text(),'"+min1+"')]/preceding::td[5]/span/a | "
                        + "//a[text()='"+sub+"']/following::td[7]/span/span[contains(text(),'"+min2+"')]/preceding::td[5]/span/a ")).getText();
         
         return dueDate;
     }
    
     //@Author : Bhavana
     //To get the status
     public String GetStatus(String sub,String date) throws InterruptedException
     {
         String min1 = getMinutes(date,1);
         String min2 = getMinutes(date,2);
         Thread.sleep(200);
         String dueDate = driver.findElement(
                 By.xpath("//a[text()='"+sub+"']/following::td[7]/span/span[text()='"+date+"']/preceding::td[3]/span/span | "
                        + "//a[text()='"+sub+"']/following::td[7]/span/span[contains(text(),'"+min1+"')]/preceding::td[3]/span/span | "
                        + "//a[text()='"+sub+"']/following::td[7]/span/span[contains(text(),'"+min2+"')]/preceding::td[3]/span/span")).getText();
         
         return dueDate;
     }
     
     //@Author : Bhavana
     // To calculate and return the due date based on the given value
     public String getExpDueDate(String val)
     {
         String exp_date = "";
         SimpleDateFormat sdf = new SimpleDateFormat("M/d/yyyy");
         Date date = DateUtils.addDays(new Date(), Integer.valueOf(val));
         exp_date = sdf.format(date);        
         return exp_date;
     }
    
     //@Author : Bhavana
     // To get the Random SO selection
     public String getSOSelection(String classNo) throws Exception 
     {
         String sel = "";
         ArrayList<String> al = new ArrayList<String>();
         String existingSel = "";
         
         if(classNo.equals("LKG") ||classNo.equals("UKG") || classNo.equals("1") ||classNo.equals("2") || classNo.equals("3"))
         {
             al = excelData.getData1("DataCapture", "K3", "Revamp_SOselection", "Class");
             existingSel = al.get(1);
             
             if(existingSel.equalsIgnoreCase("1"))
             {
                 sel = "2";
             }
             else
                 sel = "1";
             excelData.setData("src//main//java//testData//DataCapture.xlsx", "Revamp_SOselection", 1, 1, sel);
             
         }
         else if(classNo.equals("4") ||classNo.equals("5") || classNo.equals("6"))
         {
             al = excelData.getData1("DataCapture", "K4-6", "Revamp_SOselection", "Class");
             existingSel = al.get(1);
             if(existingSel.equalsIgnoreCase("1"))
             {
                 sel = "2";
             }
             else
                 sel = "1";
             
             excelData.setData("src//main//java//testData//DataCapture.xlsx", "Revamp_SOselection", 2, 1, sel);
         }
         else if(classNo.equals("7"))
         {
             al = excelData.getData1("DataCapture", "K7", "Revamp_SOselection", "Class");
             existingSel = al.get(1);
             if(existingSel.equalsIgnoreCase("1"))
             {
                 sel = "2";
             }
             else
                 sel = "1";
             
             excelData.setData("src//main//java//testData//DataCapture.xlsx", "Revamp_SOselection", 3, 1, sel);
         }
         else if(classNo.equals("8") || classNo.equals("9"))
         {
             al = excelData.getData1("DataCapture", "K8-9", "Revamp_SOselection", "Class");
             existingSel = al.get(1);
             if(existingSel.equalsIgnoreCase("1"))
             {
                 sel = "2";
             }
             else
                 sel = "1";
             excelData.setData("src//main//java//testData//DataCapture.xlsx", "Revamp_SOselection", 4, 1, sel);
         }
         else if(classNo.equals("10"))
         {
             al = excelData.getData1("DataCapture", "K10", "Revamp_SOselection", "Class");
             existingSel = al.get(1);
             if(existingSel.equalsIgnoreCase("1"))
             {
                 sel = "2";
             }
             else
                 sel = "1";
             excelData.setData("src//main//java//testData//DataCapture.xlsx", "Revamp_SOselection", 5, 1, sel);
         }
         else if(classNo.equals("11") || classNo.equals("12"))
         {
             al = excelData.getData1("DataCapture", "K11-12", "Revamp_SOselection", "Class");
             existingSel = al.get(1);
             if(existingSel.equalsIgnoreCase("1"))
             {
                 sel = "2";
             }
             else
                 sel = "1";
             excelData.setData("src//main//java//testData//DataCapture.xlsx", "Revamp_SOselection", 6, 1, sel);
         }
         
         return sel;
     }
     
     //@Author : Bhavana
     // To add the minutes to given date 
     public String getMinutes(String date,int val)
     {
         //String act_date = "4/14/2023, 4:55 PM";
         String[] spl = date.split(":");
         String[] space = spl[1].split(" ");
         String act_time = space[0];//"55"; 
         
         int min = Integer.valueOf(act_time);
         String ans = "";
         if(min<9)
         {
             ans = ":0"+String.valueOf(min+val);
         }
         else if(min>=9 && min <59)
         {
             ans = ":"+String.valueOf(min+val);
             if(ans.equalsIgnoreCase(":60")) {
                 ans = ":00";
             }
         }
         else
         {
             ans = ":00";
         }
         return ans;
     }
     
     //@Author : Bhavana
     // To get random mentoring language
     public String getMentLang(String mentLang) throws Exception
     {
         String sel = "";
         ArrayList<String> al = new ArrayList<String>();
         String existingSel = "";
         
         String[] lang = {"Bengali","Hindi","Kannada","Malayalam","Tamil","Telugu","Malayalam","Marathi"};
         
         al = excelData.getData1("DataCapture", "Mentlang", "Revamp_SOselection", "Class");
         existingSel = al.get(1);
         
         sel = lang[randomNumber(0,lang.length)];
         while(sel.equalsIgnoreCase(existingSel) || sel.equalsIgnoreCase(mentLang))
         {
             sel = lang[randomNumber(0,lang.length)];
         }
         
         excelData.setData("src//main//java//testData//DataCapture.xlsx", "Revamp_SOselection", 7, 1, sel);
         return sel;
     }
     
     //@Author : Bhavana
     //To update the mentoring language 
     public void changeMentLang(String mentLang) throws InterruptedException
     {
         Scrollpagedown();
         Thread.sleep(1000);
         jsClick(driver.findElement(By.xpath("//span[text()='Parent Language Preference']/following::button")));
         Thread.sleep(1000);
         jsClick(driver.findElement(By.xpath("//label[text()='Parent Language Preference']/following::button")));
         Thread.sleep(1000);
         jsClick(driver.findElement(By.xpath("//label[text()='Parent Language Preference']/following::div/lightning-base-combobox-item/span/span[text()='"+mentLang+"']")));
         ClickSaveName();
     }
     
     //, "Middle East"
     //@Author : Bhavana
     //To get random region
     public String getRandRegion()
     {
         String[] list= {"International - others", "North America", "Middle East"};
         String region = list[randomNumber(0,list.length)];
         
         return region;
     }
     
   //@Author : Bhavana
     //To update the region 
     public void changeRegion(String region) throws InterruptedException
     {
         Scrollpagedown();
         Scrollend();
         Thread.sleep(1000);
         jsClick(driver.findElement(By.xpath("//span[text()='Region']/following::button")));
         Thread.sleep(200);
         visibleText(By.xpath("//label[text()='Region']"));
         jsClick(driver.findElement(By.xpath("//label[text()='Region']")));
         Thread.sleep(200);
         jsClick(driver.findElement(By.xpath("//label[text()='Region']/following::div/lightning-base-combobox-item/span/span[text()='"+region+"']")));
         ClickSaveName();
     }
     
   //@Author : Bhavana
     //To click on first program on the account
     public void clickProgName() throws InterruptedException
     {
         Thread.sleep(200);
         Scrollpagedown();
         jsClick(driver.findElement(By.xpath("//span[text()='Student Programs']/following::slot/span")));
         Thread.sleep(200);
     }
    //****************************************Saurabh Methods****************************************************


     
}