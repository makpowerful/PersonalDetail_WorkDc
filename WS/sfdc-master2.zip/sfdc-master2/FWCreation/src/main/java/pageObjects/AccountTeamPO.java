package pageObjects;

import java.awt.AWTException;

import java.io.IOException;

import java.util.ArrayList;

import java.util.concurrent.ThreadLocalRandom;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import org.openqa.selenium.support.ui.ExpectedConditions;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import resources.ExcelData;
import resources.base;

public class AccountTeamPO extends base {
    WebDriver driver;

    //private String lnkSSOxpath = "//span[text()='Student Sales Order']/following::span[@force-lookup_lookup]";
    static int randomNum = ThreadLocalRandom.current().nextInt(10000, 100000 + 1);
    static int randomNum1 = ThreadLocalRandom.current().nextInt(1, 100 + 1);
    ExcelData excelData = new ExcelData();
    ArrayList<String> al = new ArrayList<String>();
    
    // Declaring Constructor
    public AccountTeamPO(WebDriver driver) {
        this.driver = driver;
    }
	
	//**************************************************Kalam Methods******************************************************

    //Author : Kalam
    // Verify the Account Owner is BLC Counsellor or BLC Area Business Head
    public void VerifyAccOwnerBLCRole(String val,String URL) throws InterruptedException, AWTException, IOException {
        visibleText(By.xpath("//h1[text()='Account Team']"));
        if(!val.contains("poms api")) {
            Scrolltilllast();
        String TeamRole= driver.findElement(
                By.xpath("//h1[text()='Account Team']/following::tbody//th//a[text()='"+val+"']/following::td/span/span")).getText();
        if(TeamRole.contains("BLC Area Business Head") || TeamRole.contains("BLC Counsellor") ) {
            System.out.println("The allocated Team role to Account owner is: "+TeamRole);
        }
        else {
            System.out.println("The allocated Team role to Account owner is: "+TeamRole+" which is not correct"); 
            Assert.assertTrue(false);
        }
        }
        else {
            if(URL.contains("--byjusuat")) {
            
            al = excelData.getData("BLC User UAT", "Login", "Type");
            System.out.println("Account team does not have BLC counsellor or ABH, Hence adding member as BLC counsellor");
            driver.findElement(By.xpath("//h1[text()='Account Team']/following::*[text()='Add Team Members']")).click();
            Thread.sleep(1000);
            visibleText(By.xpath("//h2[text()='Add account team members']"));
            driver.findElement(By.xpath("//h2[text()='Add account team members']/following::*[text()='User']/following::button")).click();
            Thread.sleep(200);
            driver.findElement(By.xpath("//h2[text()='Add account team members']/following::*[text()='User']/following::input[@title]")).sendKeys(al.get(1));
            Thread.sleep(1000);
            String[] Fname= al.get(1).split(" ");
            jsClick(driver.findElement(By.xpath("//h2[text()='Add account team members']/following::*[text()='User']/following::input[@title]/following::*[text()='"+Fname[0]+"']")));
            Thread.sleep(300);
            jsClick(driver.findElement(By.xpath("//h2[text()='Add account team members']/following::*[text()='Team Role']/following::span[contains(text(),'Edit Team Role')]")));
            Thread.sleep(200);
            jsClick(driver.findElement(By.xpath("//h2[text()='Add account team members']/following::*[text()='Team Role']/following::a")));
            Thread.sleep(300);
            jsClick(driver.findElement(By.xpath("//h2[text()='Add account team members']/following::*[text()='Team Role']/following::a[text()='BLC Counsellor']")));
            Thread.sleep(200);
            jsClick(driver.findElement(By.xpath("//h2[text()='Add account team members']/following::*[text()='Account Access']/following::span[contains(text(),'Edit Account Access')]")));
            Thread.sleep(200);
            jsClick(driver.findElement(By.xpath("//h2[text()='Add account team members']/following::*[text()='Account Access']/following::a")));
            Thread.sleep(300);
            jsClick(driver.findElement(By.xpath("//h2[text()='Add account team members']/following::*[text()='Account Access']/following::a[text()='Read/Write']")));
            Thread.sleep(200);
            jsClick(driver.findElement(By.xpath("//h2[text()='Add account team members']/following::*[text()='Case Access']/following::span[contains(text(),'Edit Case Access')]")));
            Thread.sleep(200);
            jsClick(driver.findElement(By.xpath("//h2[text()='Add account team members']/following::*[text()='Case Access']/following::a")));
            Thread.sleep(300);
            jsClick(driver.findElement(By.xpath("//h2[text()='Add account team members']/following::*[text()='Case Access']/following::a[text()='Read/Write']")));
            Thread.sleep(200);
            jsClick(driver.findElement(By.xpath("//h2[text()='Add account team members']/following::*[text()='Opportunity Access']/following::span[contains(text(),'Edit Opportunity Access')]")));
            Thread.sleep(200);
            jsClick(driver.findElement(By.xpath("//h2[text()='Add account team members']/following::*[text()='Opportunity Access']/following::a")));
            Thread.sleep(300);
            jsClick(driver.findElement(By.xpath("//h2[text()='Add account team members']/following::*[text()='Opportunity Access']/following::a[text()='Read/Write']")));
            Thread.sleep(200);
            jsClick(driver.findElement(By.xpath("//h2[text()='Add account team members']/following::span[text()='Save']")));
            Thread.sleep(2000);
            CreatedAccountPO ac=new CreatedAccountPO(driver);
            ac.CloseSubTabs();
            String AccountAssignedOwner = ac.CaptureAccOwnrNam();
            ac.NavBackToAccount();
            ac.RunManualAssignment(AccountAssignedOwner);
            ac.AccountOwnerTabClick(AccountAssignedOwner);
            ac.RefreshTab();
            Assert.assertEquals(al.get(1), ac.CaptureAccOwnerNam());
            
            }
            else {
                System.out.println("Account team does not have BLC counsellor or ABH on Production");
            }
        }
    }
    
    
    //Author : Kalam
    //Run Manual Assignment
    public void RunManualAssignment(String AccountAssignedOwner) throws InterruptedException {
        
        
    }
    
    //Author : Kalam
    //Main user count
    public int MainUsercount() {
        String[] count = driver.findElement(By.xpath("//h1[text()='Account Team']/following::span[@class='countSortedByFilteredBy']")).getText().split(" items");
        int countval= Integer.parseInt(count[0]);
        return countval;
    }
    
    //Author : Kalam
    //Scroll down till last elemet
    public void Scrolltilllast() throws InterruptedException {
       // try {
       //jsClick(driver.findElement(By.xpath("//div[@data-aura-class='uiScroller']")));
       // }
       // catch(Exception e) {
       //     e.printStackTrace();
       // }
        WebElement ele = driver.findElement(By.xpath("//div[@data-aura-class='forceChatterEntityPhoto']"));
        Actions ac = new Actions(driver);
        ac.moveToElement(ele).click().build().perform();
        //driver.findElement(By.xpath("//div[@data-aura-class='forceChatterEntityPhoto']")).click();
       for(int i=0;i<MainUsercount();i++) {
           driver.findElement(tag).sendKeys(Keys.DOWN);
           Thread.sleep(200);
           if(i+1==MainUsercount()) {
               //List<WebElement> list =driver.findElements(By.xpath("//h1[text()='Account Team']/following::span[@class='slds-row-number slds-text-body--small slds-text-color--weak']"));
               System.out.println("Last Element reached");
           }
       }
        
        
    }

    // Author : Kalam
    // Click Save
    public void ClickSave() throws InterruptedException {
        driver.findElement(By.xpath("//button[text()='Save']")).click();
        Thread.sleep(2000);
    }

    // Author : Kalam
    public void clickButton(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, 100);

        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));

        System.out.println("Element is clickable");
        element.click();
    }

    // Author : Kalam
    public boolean visibleText(By element) {
        WebDriverWait wait = new WebDriverWait(driver, 100);

        wait.ignoring(StaleElementReferenceException.class)
                .until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));

        System.out.println("Element is visible");
        return false;
    }

    // Author : Kalam
    public void jsClick(WebElement el) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].click();", el);
            System.out.println("Element clicked");
        } catch (Exception e) {
            System.out.println("=============================================================");
            System.out.println("Exception-jsClick(): " + e.getMessage());
            takeScreenShot();
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }

    // Author : Kalam
    public void Scrollpagedown() throws InterruptedException {

        driver.findElement(tag).sendKeys(Keys.PAGE_DOWN);
        Thread.sleep(1200);
    }

    // Author : Kalam
    // Scroll element to view
    public void scrollIntoView(WebElement element) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].scrollIntoView(true);", element);
            System.out.println("Page scrolled down");
        } catch (Exception e) {
            System.out.println("=============================================================");
            System.out.println("Exception-scrollIntoView(): " + e.getMessage());
            takeScreenShot();
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }
    
    // Author : Kalam
    public void Scrollend() throws InterruptedException {

        driver.findElement(tag).sendKeys(Keys.END);
        Thread.sleep(1200);
    }
	
    //**************************************************Manali Methods*****************************************************
    //**************************************************Manish Methods*****************************************************
    //**************************************************Anil Methods*******************************************************
    //**************************************************Amit Methods*******************************************************
    //**************************************************Sumit Methods******************************************************
    //**************************************************Bhavana Methods****************************************************
	//**************************************************Saurabh Methods****************************************************
}
