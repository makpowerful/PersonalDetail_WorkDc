package pageObjects;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.time.DateUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import resources.base;

public class CSInboundPO extends base {
    public WebDriver driver;

    public CSInboundPO(WebDriver driver) {
        this.driver = driver;
    }

    // Author : Manish
    public void textFieldCallBackNumber(String phoneNumber) throws InterruptedException {
        driver.findElement(By.xpath("//span[text()='Call Back Number']/following::input[1]")).sendKeys(phoneNumber);
        Thread.sleep(200);
        driver.findElement(By.xpath("//span[text()='Call Back Number']")).click();
    }

    // Author : Manish
    public WebElement textFieldSearchStudent() {
        return driver.findElement(
                By.xpath("//label[text()='Search registered student by Phone or Email']/following::div/input"));
    }

    // Author : Manish
    public void ClicktextFieldSearchStudentResult(String val) throws InterruptedException {
        Thread.sleep(1000);
        driver.findElement(By
                .xpath("//div[@c-customlwclookup_customlwclookup]//span[contains(@class,'option-text_entity')][text()='"
                        + val + "']"))
                .click();
    }

    // Author :: Manish
    public void EnterCallType(String val) throws Exception {

        retryForDetachedFrame(driver, "//iframe", 0);
        WebElement frame1 = driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
        Thread.sleep(800);
        driver.switchTo().frame(frame1);

        Thread.sleep(2000);
        Select sel = new Select(
                driver.findElement(By.xpath("//span[text()='Call Type']/following::select[@required][1]")));

        sel.selectByVisibleText(val);
        Thread.sleep(500);
    }

    // Author :: Manish
    public void EnterCallStatus(String val) throws Exception {

        Select sel = new Select(driver.findElement(
                By.xpath("//span[text()='Call Status']/following::select[@required]")));
        sel.selectByVisibleText(val);
        Thread.sleep(500);
    }

    // Author :: Manish
    public void EnterCustomerType(String val) throws Exception {

        Select sel = new Select(driver.findElement(
                By.xpath("//span[text()='Customer Type']/following::select[@required]")));
        sel.selectByVisibleText(val);
        Thread.sleep(500);
    }

    // Author :: Manish
    public String studentName() throws Exception {
        retryForDetachedFrame(driver, "//iframe", 0);
        WebElement frame1 = driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
        Thread.sleep(800);
        driver.switchTo().frame(frame1);
        Thread.sleep(1200);
        return driver.findElement(By.xpath("//p/strong/em[text()='Student Name']/following::span")).getText();
    }

    // Author :: Manish
    public String parentName() throws Exception {

        return driver.findElement(By.xpath("//p/strong/em[text()='Parent Name']/following::span")).getText();
    }

//Author :: Manish
    public String email() throws Exception {

        return driver.findElement(By.xpath("//p/strong/em[text()='Email']/following::span")).getText();
    }

//Author :: Manish
    public String phone() throws Exception {

        return driver.findElement(By.xpath("//p/strong/em[text()='Phone']/following::span[2]")).getText();
    }

//Author :: Manish
    public String status() throws Exception {

        return driver.findElement(By.xpath("//p/strong/em[text()='Status:']/following::span[1]")).getText();
    }

    // Author :: Manish
    public String superStatus() throws Exception {
        return driver.findElement(By.xpath("//p/strong/em[text()='Super Status']/following::span[1]")).getText();
    }

    // Author :: Manish
    // This method returns 10 digit random number for phone
    public String tenDigitNumber() {
        long number = (long) Math.floor(Math.random() * 9_000_000_000L) + 1_000_000_000L;
         System.out.println("Phone number is:"+number);
        String str = Long.toString(number);
        return str;
    }

    // Author : Manish
    public void switchToFrame() throws Exception {
        retryForDetachedFrame(driver, "//iframe", 0);
        WebElement frame1 = driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
        Thread.sleep(800);
        driver.switchTo().frame(frame1);
        Thread.sleep(1200);
    }

    // Author : Manish
    // Do you want to raise a task to the Central Retention Team ?
    public void SelectTasktoCentralRetentionTeam_2(String val) throws Exception {
        retryForDetachedFrame(driver, "//iframe", 0);
        WebElement frame1 = driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
        Thread.sleep(800);
        driver.switchTo().frame(frame1);
        Thread.sleep(1200);
        Select sel3 = new Select(driver.findElement(By.xpath(
                "//span[text()='Do you want to raise a task to the Central Retention Team ?']/following::select[@required]")));
        sel3.selectByVisibleText(val);
        Thread.sleep(200);
    }

    // **************************************************Kalam
    // Methods******************************************************
    // **************************************************Manali
    // Methods*****************************************************
    // **************************************************Manish
    // Methods*****************************************************
    // **************************************************Anil
    // Methods*******************************************************
    // **************************************************Amit
    // Methods*******************************************************
    // **************************************************Sumit
    // Methods******************************************************

    // @Author= Sumit
    public void InbusinessHours() {

        // WebElement chkboxElement=driver.findElement(By.xpath("//h2[contains
        // (text(),'New Task:')]//following::span[text()='In Business
        // Hours']//following::input"));
        WebElement chkboxElement = driver.findElement(
                By.xpath("//span[text()='In Business Hours']//following::span[@class='uiImage uiOutputCheckbox']"));
        String javascript = "arguments[0]. click()";
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        jsExecutor.executeScript(javascript, chkboxElement);
    }

    // @Author= Sumit
    public void textFieldSearchStudentCS(String accuntname) {
        driver.findElement(
                By.xpath("//label[text()='Search registered student by Phone or Email']/following::div/input"))
                .sendKeys(accuntname);

    }

    // @Author= Sumit
    public void csstudentnameverify() {

        String studentnamefield = driver.findElement(By.xpath("//p/strong/em[text()='Student Name']")).getText();
        String studentnamevalue = driver
                .findElement(By.xpath("//p/strong/em[text()='Student Name']/following::span[1]")).getText();
        System.out.println(studentnamefield + ":" + studentnamevalue);
    }

    // @Author= Sumit
    public void csParentNameverify() {
        String ParentNamefield = driver.findElement(By.xpath("//p/strong/em[text()='Parent Name']")).getText();
        String ParentNamevalue = driver.findElement(By.xpath("//p/strong/em[text()='Parent Name']/following::span[1]"))
                .getText();
        System.out.println(ParentNamefield + ":" + ParentNamevalue);
    }

    // @Author= Sumit
    public void csEmailverify() {

        String Emailfield = driver.findElement(By.xpath("//p/strong/em[text()='Email']")).getText();
        String Emailvalue = driver.findElement(By.xpath("//p/strong/em[text()='Email']/following::span[1]")).getText();
        System.out.println(Emailfield + ":" + Emailvalue);
    }

    // @Author= Sumit
    public void csPhoneverify() {
        String Phonefield = driver.findElement(By.xpath("//p/strong/em[text()='Phone']")).getText();
        //String Phonevalue = driver.findElement(By.xpath("//p/strong/em[text()='Phone']/following::span[1]")).getText();
        System.out.println(Phonefield + ":" + Phonefield);
    }

    // @Author= Sumit
    public void csStatusverify() {
        String Statusfield = driver.findElement(By.xpath("//p/strong/em[text()='Status:']")).getText();
        String Statusvalue = driver.findElement(By.xpath("//p/strong/em[text()='Status:']/following::span[1]"))
                .getText();
        System.out.println(Statusfield + Statusvalue);
    }

    // @Author= Sumit
    public void csSuperStatusverify() {
        String SuperStatusfield = driver.findElement(By.xpath("//p/strong/em[text()='Super Status']")).getText();
        String SuperStatusvalue = driver
                .findElement(By.xpath("//p/strong/em[text()='Super Status']/following::span[1]")).getText();
        System.out.println(SuperStatusfield + ":" + SuperStatusvalue);

    }
    // @Author= Sumit
    public void CSFilterSelection(String loginuser, String lastname) throws InterruptedException {

        driver.findElement(By.xpath("//button[@title='Show filters']")).click();

        driver.findElement(By.xpath("//a[@class=' addFilter']")).click();
        Thread.sleep(1000);

        driver.findElement(By.xpath("//label[text()='Field']/following::button")).click();
        Thread.sleep(800);
        WebElement ele = driver.findElement(By.xpath("//label[text()='Field']/following::span[text()='Created Date']"));

        ele.click();

        Date date = DateUtils.addDays(new Date(), 0);
        SimpleDateFormat sdf1 = new SimpleDateFormat("MM/dd/yyyy");
        driver.findElement(By.xpath("//span[text()='Value']/following::input")).sendKeys(sdf1.format(date));
        Thread.sleep(1000);
        driver.findElement(By.xpath("//span[text()='Done']")).click();
        Thread.sleep(1000);
        
        driver.findElement(By.xpath("//a[@class=' addFilter']")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//label[text()='Field']/following::button")).click();
        Thread.sleep(800);
        WebElement ele1 = driver.findElement(By.xpath("//label[text()='Field']/following::span[text()='Owner First Name']"));
        ele1.click();
        driver.findElement(By.xpath("//span[text()='Value']/following::input")).sendKeys(loginuser);
        Thread.sleep(1000);
        driver.findElement(By.xpath("//span[text()='Done']")).click();
        Thread.sleep(1000);
    //here    
        driver.findElement(By.xpath("//a[@class=' addFilter']")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//label[text()='Field']/following::button")).click();
        Thread.sleep(800);
        WebElement ele2 = driver.findElement(By.xpath("//label[text()='Field']/following::span[text()='Owner Last Name']"));
        ele2.click();
        driver.findElement(By.xpath("//span[text()='Value']/following::input")).sendKeys(lastname);
        Thread.sleep(1000);
        driver.findElement(By.xpath("//span[text()='Done']")).click();
        Thread.sleep(1000);
        
        driver.findElement(By.xpath("//button[text()='Save']")).click();
        Thread.sleep(1000);

    }
    
 // @Author= Sumit
    public void CSFilterSelection_ddmmyyyy() throws InterruptedException {

        driver.findElement(By.xpath("//button[@title='Show filters']")).click();

        driver.findElement(By.xpath("//a[@class=' addFilter']")).click();
        Thread.sleep(1000);

        driver.findElement(By.xpath("//label[text()='Field']/following::button")).click();
        Thread.sleep(800);
        WebElement ele = driver.findElement(By.xpath("//label[text()='Field']/following::span[text()='Created Date']"));

        ele.click();

        Date date = DateUtils.addDays(new Date(), 0);
        SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
        driver.findElement(By.xpath("//span[text()='Value']/following::input")).sendKeys(sdf1.format(date));
        Thread.sleep(1000);
      
        
        driver.findElement(By.xpath("//span[text()='Done']")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//button[text()='Save']")).click();
        Thread.sleep(1000);

    }
    
    // @Author= Sumit
    public void IntegrationLoggingName(String accountname) {

        driver.findElement(By.xpath("//*[contains(text(),'" + accountname + "')]/preceding::a[2]")).click();
        String successmessage = driver.findElement(By.xpath("//lightning-formatted-text[contains(text(),'Success')]")).getText();
               
        System.out.println(successmessage);

    }

    // **************************************************Bhavana
    // Methods****************************************************
    // **************************************************Saurabh
    // Methods****************************************************

}
