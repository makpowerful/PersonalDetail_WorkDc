package pageObjects;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.time.DateUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import resources.ExcelData;
import resources.base;

public class GeneralTaskPO extends base {
	WebDriver driver;

    /*
     * private String btnNextxpath= "//button[text()='Next']";
     * private String lblAmtPaidbyCusxpath=
     * "//label[text()='Amount Paid By Customer']/following::input";
     * private String btnListboxMovexpath =
     * "//button[@title='Move selection to Selected']";
     * private String txtPayRefxpath =
     * "//label[text()='Payment Reference']/following::input";
     * private String ddCollectionChnnelxpath =
     * "//label[text()='Collection Channel']/following::button";
     * private String lblErrorMessxpath = "//div[@class='slds-text-color_error']";
     * private String ddNoEMICollxpath = "//select[@name='No_Of_EMI_Collected']";
     * private String ddTOCollAPxpath =
     * "//select[@name='Type_Of_Collection_alreadyPaid']";
     * private String ddEligfrRefxpath = "//select[@name='Eligible_For_Refund']";
     */
	ExcelData excelData = new ExcelData();
	ArrayList<String> al3 = new ArrayList<String>();
	
	// Declaring Constructor
	public GeneralTaskPO(WebDriver driver) {
		this.driver = driver;
	}
	
	//**************************************************Kalam Methods******************************************************
    
	//@Author : Kalam
	//Click on Capture detail button
	public void ClickCaptureDetail() throws InterruptedException {
		visibleText(By.xpath("//div[text()='Capture Call Details'] | //div[text()='Capture Call Detail']"));
		jsClick(driver.findElement(By.xpath("//div[text()='Capture Call Details'] | //div[text()='Capture Call Detail']")));
		Thread.sleep(3000);
	}

	//@Author : Kalam
	 //Capture Status
    public String CaptureStatus() throws InterruptedException {
        visibleText(By.xpath("//div[text()='Capture Call Details'] | //div[text()='Capture Call Detail']"));
        String Status = driver.findElement(By.xpath("//div[text()='Task']/following::span[text()='Status']/following::span/span")).getText();
        return Status;
    }

  //@Author : Kalam
	//Select on Spoke To
	public void SelectSpokeTo(String val) throws InterruptedException {
		Select sel = new Select(driver.findElement(By.xpath("//span[text()='Spoke To']/following::select")));
		sel.selectByVisibleText(val);
		Thread.sleep(400);
	    driver.findElement(By.xpath("//button[text()='Next']")).click();
	    Thread.sleep(2000);
	}

	//@Author : Kalam
	//Select on Spoke To
	public void SelectSpokeTo2(String val) throws InterruptedException {
		Select sel = new Select(driver.findElement(By.xpath("//span[text()='Spoke To']/following::select")));
		sel.selectByVisibleText(val);
		Thread.sleep(400);
	}

	//@Author : Kalam
	//Select on Spoke To
	public void SelectSpokeTo3(String val) throws InterruptedException {
		visibleText(By.xpath("//label[text()='Spoke To']"));
		clickButton(driver.findElement(By.xpath("//label[text()='Spoke To']/following::button[@name]")));
		Thread.sleep(300);
		jsClick(driver.findElement(By.xpath("//label[text()='Spoke To']/following::button[@name]")));
		Thread.sleep(200);
		jsClick(driver.findElement(By.xpath("//label[text()='Spoke To']/following::span[text()=\""+val+"\"]")));
	}

	//@Author : Kalam
	//Click Proceed option to move forward
	public void ClickProceedOptn() throws Exception {
	retryForDetachedFrame(driver, "//iframe", 0);
	WebElement frame1=driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
	Thread.sleep(400);
	driver.switchTo().frame(frame1);
	Thread.sleep(400);
    driver.findElement(By.xpath("//span[text()='Proceed']")).click();
    Thread.sleep(800);
    driver.findElement(By.xpath("//button[text()='Next']")).click();
    Thread.sleep(3000);
	}

	//@Author : Kalam
	//Click Proceed option to move forward
	public void ClickProceedOptn2() throws Exception {
	retryForDetachedFrame(driver, "//iframe", 0);
	WebElement frame1=driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
	Thread.sleep(400);
	driver.switchTo().frame(frame1);
	visibleText(By.xpath("//span[text()='Proceed']"));
    driver.findElement(By.xpath("//span[text()='Proceed']")).click();
    Thread.sleep(200);
    driver.findElement(By.xpath("//button[text()='Next']")).click();
    //Thread.sleep(3000);
	}

	//@Author : Kalam
	//Click DNP to move forward
	public void ClickDNP() throws Exception {
	retryForDetachedFrame(driver, "//iframe", 0);
	WebElement frame1=driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
	Thread.sleep(400);
	driver.switchTo().frame(frame1);
	visibleText(By.xpath("//span[text()='DNP']"));
    driver.findElement(By.xpath("//span[text()='DNP']")).click();
    Thread.sleep(200);
    driver.findElement(By.xpath("//button[text()='Next']")).click();
    //Thread.sleep(3000);
	}

	//@Author : Kalam
	//Click DNP/Call Drop to move forward
	public void ClickDNP_CallDrop() throws Exception {
	retryForDetachedFrame(driver, "//iframe", 0);
	WebElement frame1=driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
	Thread.sleep(400);
	driver.switchTo().frame(frame1);
	visibleText(By.xpath("//span[text()='DNP/Call Drop']"));
    driver.findElement(By.xpath("//span[text()='DNP/Call Drop']")).click();
    Thread.sleep(200);
    driver.findElement(By.xpath("//button[text()='Next']")).click();
    //Thread.sleep(3000);
	}

	//@Author : Kalam
	//Click Abrupt Disconnection option to move forward
	public void ClickAbruptDisconnection() throws Exception {
	retryForDetachedFrame(driver, "//iframe", 0);
	WebElement frame1=driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
	Thread.sleep(400);
	driver.switchTo().frame(frame1);
	visibleText(By.xpath("//span[text()='Abrupt Disconnection']"));
    driver.findElement(By.xpath("//span[text()='Abrupt Disconnection']")).click();
    Thread.sleep(200);
    driver.findElement(By.xpath("//button[text()='Next']")).click();
    //Thread.sleep(3000);
	}

	//@Author : Kalam
	//Click Customer will Call option to move forward
	public void ClickCustomerwillCall() throws Exception {
	retryForDetachedFrame(driver, "//iframe", 0);
	WebElement frame1=driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
	Thread.sleep(400);
	driver.switchTo().frame(frame1);
	visibleText(By.xpath("//span[text()='Customer will Call']"));
    driver.findElement(By.xpath("//span[text()='Customer will Call']")).click();
    Thread.sleep(200);
    driver.findElement(By.xpath("//button[text()='Next']")).click();
    //Thread.sleep(3000);
	}

	//@Author : Kalam
	//Click Call Back Requested option to move forward
	public void ClickCallBackRequested() throws Exception {
	retryForDetachedFrame(driver, "//iframe", 0);
	WebElement frame1=driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
	Thread.sleep(400);
	driver.switchTo().frame(frame1);
	visibleText(By.xpath("//span[text()='Call Back Requested']"));
    driver.findElement(By.xpath("//span[text()='Call Back Requested']")).click();
    Thread.sleep(200);
    Date date = DateUtils.addDays(new Date(), +1);
	 SimpleDateFormat sdf = new SimpleDateFormat("MM dd, yyyy");
    driver.findElement(By.xpath("//span[text()='Call Back Date']/following::input")).sendKeys(sdf.format(date));
    driver.findElement(By.xpath("//button[text()='Next']")).click();
    //Thread.sleep(3000);
	}

	//@Author : Kalam
    //Select the value for Please Select The Call Type
	public void SelectPSTCT(String val) throws InterruptedException {
	visibleText(By.xpath("//label[text()='Please Select The Call Type']"));
	Select sel = new Select(driver.findElement(By.xpath("//label[text()='Please Select The Call Type']/following::select[@required]")));
	sel.selectByVisibleText(val);
	Thread.sleep(200);
	}

	//@Author : Kalam
    //Select the value for Please Select the Existing Open Case
	public void SelectPSTEOC() throws InterruptedException {
	visibleText(By.xpath("//label[text()='Please Select the Existing Open Case']"));
	Thread.sleep(200);
	Select sel = new Select(driver.findElement(By.xpath("//label[text()='Please Select the Existing Open Case']/following::select[@required]")));
	sel.selectByIndex(1);
	Thread.sleep(200);
	}

	//@Author : Kalam
	//Enter the value for Notes
	public void EnterNotesVal(String val) throws InterruptedException {
	driver.findElement(By.xpath("//label[text()='Notes']/following::textarea")).sendKeys(val);
	Thread.sleep(200);
	}

	//@Author : Kalam
	//Click Next button
	public void ClickNext() throws InterruptedException {
	jsClick(driver.findElement(By.xpath("//button[text()='Next']")));
	Thread.sleep(2000);
	}

	//@Author : Kalam
	//Click Finish button
	public void ClickFinish() throws InterruptedException {
	jsClick(driver.findElement(By.xpath("//button[text()='Finish']")));
	Thread.sleep(2000);
	}

	//@Author : Kalam
	//Select the device
	public void SelectDevice(String val) throws InterruptedException {
	driver.findElement(By.xpath("//label[text()='Device']/following::span[@lightning-basecombobox_basecombobox]")).click();
	Thread.sleep(400);
	driver.findElement(By.xpath("//label[text()='Device']/following::span[text()='"+val+"']")).click();
	Thread.sleep(1000);
	}

	//@Author : Kalam
	//Select the Please Select Your Issue Category
	public void SelectIssueCategory(String val) throws InterruptedException {
	driver.findElement(By.xpath("//label[text()='Please Select Your Issue Category']/following::span[@lightning-basecombobox_basecombobox]")).click();
	Thread.sleep(400);
	driver.findElement(By.xpath("//label[text()='Please Select Your Issue Category']/following::span[text()='"+val+"']")).click();
	Thread.sleep(400);
	}

	//@Author : Kalam
    //Select the value for Please Specify Your Issue
	public void SelectPSYI(String val) throws InterruptedException {
	Select sel = new Select(driver.findElement(By.xpath("//label[text()='Please Specify Your Issue']/following::select[@required]")));
	sel.selectByVisibleText(val);
	Thread.sleep(400);
	}

	//@Author : Kalam
    //Select the value for Please Specify Your Issue Sub Type
	public void SelectPSYIST(String val) throws InterruptedException {
	Select sel = new Select(driver.findElement(By.xpath("//label[text()='Please Specify Your Issue Sub Type']/following::select[@required]")));
	sel.selectByVisibleText(val);
	Thread.sleep(400);
	}

	//@Author : Kalam
    //Select the value for Is The Issue Resolved Currently?
	public void SelectIsTICR(String val) throws InterruptedException {
	Select sel = new Select(driver.findElement(By.xpath("//label[text()='Is The Issue Resolved Currently?']/following::select[@required]")));
	sel.selectByVisibleText(val);
	Thread.sleep(400);
	}

	//@Author : Kalam
	//Select the Please Select Your Issue Category
	public void SelectPSYICategory(String val) throws InterruptedException {
	driver.findElement(By.xpath("//label[text()='Please Select Your Issue Category']/following::span[@lightning-basecombobox_basecombobox]")).click();
	Thread.sleep(400);
	driver.findElement(By.xpath("//label[text()='Please Select Your Issue Category']/following::span[text()='"+val+"']")).click();
	Thread.sleep(400);
	}

	//@Author : Kalam
	//Select the Category
	public void SelectCategory(String val) throws InterruptedException {
	driver.findElement(By.xpath("//label[text()='Category']/following::span[@lightning-basecombobox_basecombobox]")).click();
	Thread.sleep(400);
	driver.findElement(By.xpath("//label[text()='Category']/following::span[text()='"+val+"']")).click();
	Thread.sleep(400);
	}

	//@Author : Kalam
	//Select the Sub Category
	public void SelectSubCategory(String val) throws InterruptedException {
	Select sel1 = new Select(driver.findElement(By.xpath("//label[text()='Sub Category']/following::select[@required]")));
	sel1.selectByVisibleText(val);
	Thread.sleep(400);
	}

	//@Author : Kalam
	//Select the Please Specify Your Issue Sub Type
	public void SelectIssueSubType(String val) throws InterruptedException {
	Select sel2 = new Select(driver.findElement(By.xpath("//label[text()='Please Specify Your Issue Sub Type']/following::select[@required]")));
	sel2.selectByVisibleText(val);
	Thread.sleep(400);
	}

	//@Author : Kalam
	//Select Is The Issue Resolved Currently?
	public void SelectIssueResolved(String val) throws InterruptedException {
	Select sel3 = new Select(driver.findElement(By.xpath("//label[text()='Is The Issue Resolved Currently?']/following::select[@required]")));
	sel3.selectByVisibleText(val);
	Thread.sleep(400);
	}

	//@Author : Kalam
	//Select Please Specify Your Logistics Issue
	public void SelectSYLI(String val) throws InterruptedException {
	Select sel3 = new Select(driver.findElement(By.xpath("//label[text()='Please Specify Your Logistics Issue']/following::select[@required]")));
	sel3.selectByVisibleText(val);
	Thread.sleep(400);
	}

	//@Author : Kalam
	//Select the Is there is any change in grade, course, or validity
	public void SelectITGCorV(String val) throws InterruptedException {
	driver.findElement(By.xpath("//label[text()='Is there is any change in grade, course, or validity']/following::span[@lightning-basecombobox_basecombobox]")).click();
	Thread.sleep(400);
	driver.findElement(By.xpath("//label[text()='Is there is any change in grade, course, or validity']/following::span[text()='"+val+"']")).click();
	Thread.sleep(400);
	}

	//@Author : Kalam
	//Select Is there is any change in registered no: or shipping address
	public void SelectIRNorSA(String val) throws InterruptedException {
	driver.findElement(By.xpath("//label[text()='Is there is any change in registered no: or shipping address']/following::span[@lightning-basecombobox_basecombobox]")).click();
	Thread.sleep(400);
	driver.findElement(By.xpath("//label[text()='Is there is any change in registered no: or shipping address']/following::span[text()='"+val+"']")).click();
	Thread.sleep(400);
	}

	//@Author : Kalam
	//Select Is The Issue Resolved Currently?
	public void SelectITIRC(String val) throws InterruptedException {
	Select sel3 = new Select(driver.findElement(By.xpath("//label[text()='Is The Issue Resolved Currently?']/following::select[@required]")));
	sel3.selectByVisibleText(val);
	Thread.sleep(400);
	}	

	//@Author : Kalam
	//Select Please Select The Catagory Of Your Refund
	public void SelectPSCOYR(String val) throws InterruptedException {
	Select sel3 = new Select(driver.findElement(By.xpath("//label[text()='Please Select The Catagory Of Your Refund']/following::select[@required]")));
	sel3.selectByVisibleText(val);
	Thread.sleep(400);
	}

	//@Author : Kalam
	//Select Please Select Reason for Refund
	public void SelectPSTRR(String val) throws InterruptedException {
	Select sel3 = new Select(driver.findElement(By.xpath("//label[text()='Please Select Reason for Refund']/following::select[@required]")));
	sel3.selectByVisibleText(val);
	Thread.sleep(400);
	}

	//@Author : Kalam
	//Select Please Select Reason for Refund
	public void SelectPSTRR2(String val) throws InterruptedException {
	Select sel3 = new Select(driver.findElement(By.xpath("//label[text()='Please Select The Refund Reason']/following::select[@required]")));
	sel3.selectByVisibleText(val);
	Thread.sleep(400);
	}

	//@Author : Kalam
	//Pull values for Product
	public void PullProductVal() throws InterruptedException, IOException {

		
		
	}

	//@Author : Kalam
	//Select all values present in Please Select Sub Reason for Refund - Product
	public void VerifyAllValinPSSTRR(int m) throws InterruptedException, IOException {
		al3 = excelData.getData("TC2", "RefundProcess", "Tcid");
		String[] Val = al3.get(m).trim().split(";");
		List<WebElement> List = driver.findElements(By.xpath("//label[text()='Please Select Sub Reason for Refund']/following-sibling::select/option"));
		for(int i=0;i<List.size();i++) {
			String Val2=List.get(i).getText();
			Thread.sleep(300);
			System.out.println(Val[i]+" | "+Val2);
			Assert.assertTrue(Val[i].equalsIgnoreCase(Val2));
		}
		
		}

	//@Author : Kalam
	//Select Please Select Sub Reason for Refund
	public void SelectPSSTRR(String val) throws InterruptedException {
	Select sel3 = new Select(driver.findElement(By.xpath("//label[text()='Please Select Sub Reason for Refund']/following::select[@required]")));
	sel3.selectByVisibleText(val);
	Thread.sleep(400);
	}

	//@Author : Kalam
	//Enter Comments
	public void EnterComments(String val) throws InterruptedException {
	driver.findElement(By.xpath("//label[text()='Comments']/following::textarea")).sendKeys(val);
	Thread.sleep(400);
	}

	//@Author : Kalam
	//Please Select The Order
	public void SelectPSTO() throws InterruptedException {
	driver.findElement(By.xpath("//label[text()='Please Select The Order']/following::span[@lightning-basecombobox_basecombobox]")).click();
	Thread.sleep(400);
	driver.findElement(By.xpath("//label[text()='Please Select The Order']/following::span[contains(text(),'ORD')]")).click();
	Thread.sleep(1200);
	}

	//@Author : Kalam
	//Please Select The Issue responsibility
	public void SelectPSTIR(String val) throws InterruptedException {
	Select sel3 = new Select(driver.findElement(By.xpath("//label[text()='Please Select The Issue responsibility']/following::select[@required]")));
	sel3.selectByVisibleText(val);
	Thread.sleep(400);
	}

	//@Author : Kalam
	//Verify Error message
	public boolean CheckErrorMess() {
		if(driver.findElement(By.xpath("//p[contains(text(),'Existing RR case')]")).isDisplayed()) {
			return true;
		}
		else {
		return false;
		}
	}

	//@Author : Kalam
  //Navigate back to Account screen
	public void NavBackAccount() throws InterruptedException {
		try {
		jsClick(driver.findElement(By.xpath("//span[text()='Name']/following::a")));
		Thread.sleep(3000);
		}
		catch(WebDriverException e){
			Thread.sleep(500);
			jsClick(driver.findElement(By.xpath("//span[text()='Name']/following::a")));	
			Thread.sleep(3000);
		}
		 catch(Exception ee)
	    {
	        ee.printStackTrace();
	        throw ee;
	    }
	}

	//@Author : Kalam
	//Navigate back to Account screen
		public void NavToCase() throws InterruptedException {
			try {
			driver.findElement(By.xpath("//span[text()='Related To']/following::a")).click();
			Thread.sleep(3000);
			}
			catch(WebDriverException e){
				Thread.sleep(500);
				driver.findElement(By.xpath("//span[text()='Related To']/following::a")).click();	
				Thread.sleep(3000);
			}
			 catch(Exception ee)
		    {
		        ee.printStackTrace();
		        throw ee;
		    }
		}
	
		//@Author : Kalam
		//Get the Case created value under Related To
		public String CaptureRelatedTo() throws InterruptedException {
			String RelatedTo=driver.findElement(By.xpath("//div[text()='Task']/following::span[text()='Related To']/following::a[@data-refid]")).getText();
			Thread.sleep(300);
			return RelatedTo;
		}
	
		//@Author : Kalam
		//Verify Status
		public String CheckStatus() throws InterruptedException {
		String val = driver.findElement(By.xpath("//div[text()='Task']/following::span[text()='Status']/following::span/span")).getText();
		return val;
		}
	
		//@Author : Kalam
		//Is Neo FOC pitched to Cx?
		public void SelectIsNeoFOCpitchedtoCx(String val) throws InterruptedException {
		    visibleText(By.xpath("//label[text()='Is Neo FOC pitched to Cx?']"));
		    jsClick(driver.findElement(By.xpath("//label[text()='Is Neo FOC pitched to Cx?']/following::button")));
		    Thread.sleep(200);
		    jsClick(driver.findElement(By.xpath("//label[text()='Is Neo FOC pitched to Cx?']/following::button/following::span[text()=\""+val+"\"]")));
		    Thread.sleep(200);
		}

		//@Author : Kalam
	    //Did customer agree for upgrade ?
        public void SelectDidcustomeragreeforupgrade(String val) throws InterruptedException {
            visibleText(By.xpath("//label[text()='Did customer agree for upgrade ?'] | //label[text()='Did customer agree for upgrade?']"));
            jsClick(driver.findElement(By.xpath("//label[text()='Did customer agree for upgrade ?']/following::button | //label[text()='Did customer agree for upgrade?']/following::button")));
            Thread.sleep(200);
            jsClick(driver.findElement(By.xpath("//label[text()='Did customer agree for upgrade ?']/following::button/following::span[text()=\""+val+"\"] | //label[text()='Did customer agree for upgrade?']/following::button/following::span[text()=\""+val+"\"]")));
            Thread.sleep(200);
        }
  
      //@Author : Kalam
        //Is the order punching complete?
        public void SelectIstheorderpunchingcomplete(String val) throws InterruptedException {
            
            jsClick(driver.findElement(By.xpath("//label[text()='Is the order punching complete?']/following::button")));
            Thread.sleep(200);
            jsClick(driver.findElement(By.xpath("//label[text()='Is the order punching complete?']/following::button/following::span[text()=\""+val+"\"]")));
            Thread.sleep(200);
        }
  
      //@Author : Kalam
        //Are the Add ons provided (e.g. Doubt resolutions, SST classes)?
        public void SelectAretheAddonsprovided(String val) throws InterruptedException {
            
            jsClick(driver.findElement(By.xpath("//label[text()='Are the Add ons provided (e.g. Doubt resolutions, SST classes)?']/following::button")));
            Thread.sleep(200);
            jsClick(driver.findElement(By.xpath("//label[text()='Are the Add ons provided (e.g. Doubt resolutions, SST classes)?']/following::button/following::span[text()=\""+val+"\"]")));
            Thread.sleep(200);
        }
	
      //@Author : Kalam
        //Did you explain the customer about the usage?
        public void SelectExplainCustomerAboutUsage(String val) throws InterruptedException {
            
            jsClick(driver.findElement(By.xpath("//label[text()='Did you explain the customer about the usage?']/following::button")));
            Thread.sleep(200);
            jsClick(driver.findElement(By.xpath("//label[text()='Did you explain the customer about the usage?']/following::button/following::span[text()=\""+val+"\"]")));
            Thread.sleep(200);
        }
    
      //@Author : Kalam
        //How interested is customer?
        public void SelectHowInterestedIsCustomer(String val) throws InterruptedException {
            
            jsClick(driver.findElement(By.xpath("//label[text()='How interested is customer?']/following::button[2]")));
            Thread.sleep(200);
            clickButton(driver.findElement(By.xpath("//label[text()='How interested is customer?']/following::button/following::span[text()=\""+val+"\"]")));
            Thread.sleep(200);
        }
        
        //@Author : Kalam
        //How interested is customer?
        public void SelectHowInterestedIsCustomer2(String val) throws InterruptedException {
            
            jsClick(driver.findElement(By.xpath("//label[text()='How interested is customer?']/following::button")));
            Thread.sleep(200);
            clickButton(driver.findElement(By.xpath("//label[text()='How interested is customer?']/following::button/following::span[text()=\""+val+"\"]")));
            Thread.sleep(200);
        }
    
      //@Author : Kalam
        //Click Task Detail
        public void ClickTaskDetail() throws InterruptedException {
            jsClick(driver.findElement(By.xpath("//div[text()='Task']/following::span[text()='Task Detail']/following::a")));
            Thread.sleep(200);
        }
        
      //@Author : Kalam
        //Click Question Answers view all button
        public void ClickQuestionAnwer_ViewAll() throws InterruptedException {
            visibleText(By.xpath("//div[text()='Task Detail']"));
            Scrollpagedown();
            jsClick(driver.findElement(By.xpath("//div[text()='Task Detail']/following::*[text()='Question Answers']/following::span[text()='View All']")));
            Thread.sleep(200);
        }
       
      //@Author : Kalam
        //Verify Task detail values
        public String VerifyTaskDetailvalue(String val) throws InterruptedException {
            visibleText(By.xpath("//h1[text()='Question Answers']"));
            String value = driver.findElement(By.xpath("//h1[text()='Question Answers']/following::*[text()=\""+val+"\"]/following::span/span")).getText();
            Thread.sleep(100);
            return value;
        }
  
      //@Author : Kalam
        //Has the student attended any class?
        public void SelectHasStudentAttendedClass(String val) throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//label[text()='Has the student attended any class?']/following::button")));
        Thread.sleep(200);
        jsClick(driver.findElement(By.xpath("//label[text()='Has the student attended any class?']/following::button/following::span[text()=\""+val+"\"]")));
        Thread.sleep(200);
        }
 
      //@Author : Kalam
        //If the customer is facing any issue?
        public void SelectCustometFacingIssue(String val) throws InterruptedException {
        visibleText(By.xpath("//label[text()='If the customer is facing any issue?']"));
        jsClick(driver.findElement(By.xpath("//label[text()='If the customer is facing any issue?']/following::button")));
        Thread.sleep(200);
        jsClick(driver.findElement(By.xpath("//label[text()='If the customer is facing any issue?']/following::button/following::span[text()=\""+val+"\"]")));
        Thread.sleep(200);
        }

      //@Author : Kalam
        //Are the punched classes reflected on the portal?
        public void SelectArePunchedClassesReflected(String val) throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//label[text()='Are the punched classes reflected on the portal?']/following::button")));
        Thread.sleep(200);
        jsClick(driver.findElement(By.xpath("//label[text()='Are the punched classes reflected on the portal?']/following::button/following::span[text()=\""+val+"\"]")));
        Thread.sleep(200);
        }
        
      //@Author : Kalam
        //Is the Batch/Grade/Board accurate as per the previous selection?
        public void SelectBatchGradeBoard(String val) throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//label[text()='Is the Batch/Grade/Board accurate as per the previous selection?']/following::button")));
        Thread.sleep(200);
        jsClick(driver.findElement(By.xpath("//label[text()='Is the Batch/Grade/Board accurate as per the previous selection?']/following::button/following::span[text()=\""+val+"\"]")));
        Thread.sleep(200);
        }
     
      //@Author : Kalam
        //Did you guide cx the process to login into the portal?
        public void SelectGuidecxProcess(String val) throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//label[text()='Did you guide cx the process to login into the portal?']/following::button")));
        Thread.sleep(200);
        jsClick(driver.findElement(By.xpath("//label[text()='Did you guide cx the process to login into the portal?']/following::button/following::span[text()=\""+val+"\"]")));
        Thread.sleep(200);
        }
     
      //@Author : Kalam
        //How likely is the customer to attend classes?
        public void SelectHowLikelyCustomerClasses(String val) throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//label[text()='How likely is the customer to attend classes?']/following::button")));
        Thread.sleep(200);
        jsClick(driver.findElement(By.xpath("//label[text()='How likely is the customer to attend classes?']/following::button/following::span[text()=\""+val+"\"]")));
        Thread.sleep(200);
        }
     
      //@Author : Kalam
        //Did you solve the customer issue?
        public void SelectDidSolveCustomerIssue(String val) throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//label[text()='Did you solve the customer issue?']/following::button")));
        Thread.sleep(200);
        jsClick(driver.findElement(By.xpath("//label[text()='Did you solve the customer issue?']/following::button/following::span[text()=\""+val+"\"]")));
        Thread.sleep(200);
        }
    
      //@Author : Kalam
        //Did you solve the customer issue?
        public void SelectReasonsForNotSolving(String val) throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//label[text()='Reasons for not solving']/following::button")));
        Thread.sleep(200);
        jsClick(driver.findElement(By.xpath("//label[text()='Reasons for not solving']/following::button/following::span[text()=\""+val+"\"]")));
        Thread.sleep(200);
        }
    
      //@Author : Kalam
        //What was previous exam for which the student had appeared ?
        public void SelectPreviousExamStudent(String val) throws InterruptedException {
        visibleText(By.xpath("//label[text()='What was previous exam for which the student had appeared ?']"));
        jsClick(driver.findElement(By.xpath("//label[text()='What was previous exam for which the student had appeared ?']/following::button")));
        Thread.sleep(200);
        jsClick(driver.findElement(By.xpath("//label[text()='What was previous exam for which the student had appeared ?']/following::button/following::span[text()=\""+val+"\"]")));
        Thread.sleep(200);
        }
     
      //@Author : Kalam
        //Capture Marks
        public void SelectCaptureMarks(String val) throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//label[text()='Capture Marks']/following::button")));
        Thread.sleep(200);
        jsClick(driver.findElement(By.xpath("//label[text()='Capture Marks']/following::button/following::span[text()=\""+val+"\"]")));
        Thread.sleep(200);
        }
        
        
      //@Author : Kalam
        //Maths Marks scored in previous exam in % (0-100)
        public void EnterMathsMarksPreviousExam(String val) throws InterruptedException {
        driver.findElement(By.xpath("//label[text()='Maths Marks scored in previous exam in % (0-100)']/following::input")).sendKeys(val);
        Thread.sleep(200);
        }
       
      //@Author : Kalam
        //Science Marks scored in previous exam in % (0-100)
        public void EnterScienceMarksPreviousExam(String val) throws InterruptedException {
        driver.findElement(By.xpath("//label[text()='Science Marks scored in previous exam in % (0-100)']/following::input")).sendKeys(val);
        Thread.sleep(200);
        }
        
      //@Author : Kalam
        //Enter Mid Term Exam Date (If customer is not aware of the exact exam date, please get the tentative date)
        public void EnterMidTermExamDate() throws InterruptedException {
        Date date = DateUtils.addDays(new Date(), 0);
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
        driver.findElement(By.xpath("//label[text()='Enter Mid Term Exam Date (If customer is not aware of the exact exam date, please get the tentative date)']/following::input")).sendKeys(sdf.format(date));
        Thread.sleep(200);
        }
        
      //@Author : Kalam
        //Enter Mid Term Exam Date (If customer is not aware of the exact exam date, please get the tentative date)
        public void EnterMidTermExamDate_Prod() throws InterruptedException {
        Date date = DateUtils.addDays(new Date(), 0);
        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
        driver.findElement(By.xpath("//label[text()='Enter Mid Term Exam Date (If customer is not aware of the exact exam date, please get the tentative date)']/following::input")).sendKeys(sdf.format(date));
        Thread.sleep(200);
        }
        
      //@Author : Kalam
        //Today Date
        public String TodayDate() throws InterruptedException {
        Date date = DateUtils.addDays(new Date(), 0);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(date);
        }
        
      //@Author : Kalam
        //Enter Midterm target marks for Maths in % (0-100)
        public void EnterMidTermMarksMaths(String val) throws InterruptedException {
        driver.findElement(By.xpath("//label[text()='Enter Midterm target marks for Maths in % (0-100)']/following::input")).sendKeys(val);
        Thread.sleep(200);
        }
        
      //@Author : Kalam
        //Enter Midterm target marks for Science in % (0-100)
        public void EnterMidTermMarksScience(String val) throws InterruptedException {
        driver.findElement(By.xpath("//label[text()='Enter Midterm target marks for Science in % (0-100)']/following::input")).sendKeys(val);
        Thread.sleep(200);
        }
        
      //@Author : Kalam
		//Check for Created Case Buttons
	    public void CheckTaskButtonsQAandSM(String Env,String SheetName) throws Exception {
	    	List<WebElement> List= driver.findElements(By.xpath("//div[text()='Task']/following::ul[contains(@class,'branding-actions')]/li/a/div"));
			System.out.println(List.size());
			for(int i=0;i<List.size();i++) {
				
				String OnPagebuttons=List.get(i).getText();
				System.out.println(OnPagebuttons);
				setData(Env, SheetName, i + 1, 1, OnPagebuttons);
				if(i==List.size()-1) {
					setData2(Env, SheetName, i + 2, 1, List.size());
					try {
						if(driver.findElement(By.xpath("//div[text()='Task']/following::a[@title='Show one more action']")).isDisplayed()) {
					Thread.sleep(1000);
					WebElement ele= driver.findElement(By.xpath("//div[text()='Task']/following::a[@title='Show one more action']"));
					Actions ac=new Actions(driver);
					ac.moveToElement(ele);
					jsClick(ele);
					Thread.sleep(1200);

					List<WebElement> Showmore= driver.findElements(By.xpath("//div[text()='Task']/following::div[contains(@class,'uiPopupTarget')]/div/ul/li/a/div"));
					System.out.println(Showmore.size());
					
					for(int j=0;j<Showmore.size();j++) {
						
						String ShowMorebuttons=Showmore.get(j).getText();
						System.out.println(ShowMorebuttons);
						setData(Env, SheetName, j + 1, 3, ShowMorebuttons);
						if(j==Showmore.size()-1) {
						setData2(Env, SheetName, j + 2, 3, Showmore.size());
					}
				}
						}
					}
					catch(Exception e) {
						e.printStackTrace();
						System.out.println("No corner button present");
					}
			}
			}
	    }
		
		
	  //@Author : Kalam
    public void jsClick(WebElement el) {
		try {
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("arguments[0].click();", el);
			System.out.println("Element clicked");
		} catch (Exception e){
			System.out.println("=============================================================");
			System.out.println("Exception-jsClick(): "+e.getMessage());
			//takeScreenShot();
			e.printStackTrace();
			System.out.println("=============================================================");
		}
	}
    
  //@Author : Kalam
	public boolean visibleText(By element)
	{
		WebDriverWait wait= new WebDriverWait(driver, 100);
		
		wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));
		
		System.out.println("Element is visible");
		return false;
	}
	
	//@Author : Kalam
	public void clickButton(WebElement element)
	{
		WebDriverWait wait= new WebDriverWait(driver, 100);
		
		wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));
		
		System.out.println("Element is clickable");
		element.click();
	}
	    
	//@Author : Kalam
	   public void Scrollpagedown() throws InterruptedException {

	        driver.findElement(tag).sendKeys(Keys.PAGE_DOWN);
	        Thread.sleep(1200);
	    }
	   
	   
	 //**************************************************Manali Methods*****************************************************
	    //**************************************************Manish Methods*****************************************************
	    //**************************************************Anil Methods*******************************************************
	    //**************************************************Amit Methods*******************************************************
	    //**************************************************Sumit Methods******************************************************
	    //**************************************************Bhavana Methods****************************************************
	 //**************************************************Saurabh Methods****************************************************
}
