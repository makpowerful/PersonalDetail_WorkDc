package pageObjects;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import resources.base;

public class PaymentsPO extends base {
	WebDriver driver;

	private String btnNavMenuxpath = "//button[@title='Show Navigation Menu']";
	private String btnPaymntOptnxpath = "//span[text()='Payments'][@class='menuLabel slds-listbox__option-text slds-listbox__option-text_entity']";
	private String btnNewPaymntxpath = "//div[text()='New']";
	private String lnkRecentViewxpath = "//ul/following::span[text()='Recently Viewed']";
	private String lnkDeletexpath = "//a[@title='Delete']";
	private String btnDeletexpath = "//button/span[text()='Delete']";
	private String btnCreateCase = "//button[@name='Payment__c.Create_Case']";
	private String btnSave = "//button[@class='slds-button slds-button_brand cuf-publisherShareButton undefined uiButton']/span[text()='Save']";
	private String txtPriorityDate = "//div/p[text()='Priority Date/Time']";
	private String txtPriorityTime = "//div/p[text()='Priority Date/Time']/following::p/slot/lightning-formatted-text";
	private String txtCaseNumber = "//td//a[@data-refid='recordId']";
	private String txtAppId = "//div[@class='uiInput uiInputText uiInput--default uiInput--input']/input";
	private String datePicker = "//a[@class='datePicker-openIcon display']";
	private String dateToday = "//button[@class='today slds-button slds-align_absolute-center slds-text-link']";
	private String txtWarning = "//div[@role='alertdialog']//div/span[text()='You can send only one message per day per payment']";
	private String lnkContact1 = "//button[@title='Edit Contact No 1']";
	private String txtContact1 = "//input[@name='Contact_No_1__c']";
	private String btnContactSave = "//button[@name='SaveEdit']";
	private String iconMessage = "//lightning-icon[@class='message-icon slds-icon-utility-anywhere-chat slds-icon_container'][@c-additionalcontacts_additionalcontacts]";
	private String dropdownSmsTemplate = "//button[@aria-haspopup='listbox']";
	private String btnSend = "//button[@title='Primary action']";
	private String msgSubject = "//a[@title='FINBJC SMS Sent - 8105710715'] | //a[@title='FINBJC SMS Sent - ******715'] | //a[@title='FINBJC SMS Sent - ******0715']";
	private String closeNotificationTab = "//button[@title='Close Notifications']";
	//private String closeSubTab = "//div[@class='close slds-col--bump-left slds-p-left--none slds-p-right--none ']";
	private String lnkCasesxpath = "//span[@lst-listviewmanagerheader_listviewmanagerheader][@title='Cases']";

	// Declaring Constructor
	public PaymentsPO(WebDriver driver) {
		this.driver = driver;
	}

	//**************************************************Kalam Methods******************************************************

	
	//@Author : Kalam
	// Selecting Nav Menu
	public void NavMenuClick() throws InterruptedException {
		Thread.sleep(3000);
		jsClick(driver.findElement(By.xpath(btnNavMenuxpath)));
		Thread.sleep(3000);
	}

	//@Author : Kalam
	// Selecting Payment option from Nav Menu
	public void PaymntNavMenuClick() throws InterruptedException {
		jsClick(driver.findElement(By.xpath(btnPaymntOptnxpath)));
		Thread.sleep(3000);
	}

	//@Author : Kalam
	// Creating New Payment
	public void NewPaymentClick() throws InterruptedException {
		jsClick(driver.findElement(By.xpath(btnNewPaymntxpath)));
		Thread.sleep(3000);
	}

	//@Author : Kalam
	// Navigate to Case tab
	public void NavCaseTab(String val) throws InterruptedException {
		Scrollpagedown();
		Scrollend();
		WebElement Cases = driver.findElement(By.xpath(lnkCasesxpath));
		jsClick(Cases);
		Thread.sleep(2000);
		WebElement ele = driver.findElement(By.xpath("//span/a[@title='" + val + "']"));
		jsClick(ele);

		// jsClick(driver.findElement(By.xpath("//dt[text()='Case
		// Number:']/following::a[@title]")));

		/*
		 * jsClick(driver.findElement(By
		 * .xpath("//ul[@class='tabBarItems slds-tabs--default__nav']//span[@class='title slds-truncate'][text()='"
		 * + val + "']")));
		 */
		Thread.sleep(1000);
	}

	//@Author : Kalam
	// Navigate to Cases tab
	public void NavCasesTab() throws InterruptedException {
		Thread.sleep(1000);
		  jsClick(driver.findElement(By.xpath(
		  "//ul[@class='tabBarItems slds-tabs--default__nav']//span[@class='title slds-truncate'][text()='Cases']")));		
		Thread.sleep(3000);
	}
	
    // @Author : Kalam
    // Navigate to Cases tab
    public void ClickCasesTab() throws InterruptedException {
        Scrollpagedown();
        Scrollend();
        jsClick(driver.findElement(By.xpath(
                "//div[text()='Payment']/following::span[text()='Cases'][1]")));
        Thread.sleep(1500);
    }
    
    // @Author : Kalam
    // Navigate to Cases tab
    public String CaptureCaseCount() throws InterruptedException {
        try {
        Scrollpagedown();
        Scrollpagedown();
        Thread.sleep(2000);
        return driver.findElement(By.xpath(
                "//div[text()='Payment']/following::span[text()='Cases'][1]/following::span[1]")).getText();
        }
        catch(Exception e) {
            driver.get(driver.getCurrentUrl());
            Thread.sleep(3000);
            Scrollpagedown();
            Scrollpagedown();
            Thread.sleep(2000);
            return driver.findElement(By.xpath(
                    "//div[text()='Payment']/following::span[text()='Cases'][1]/following::span[1]")).getText();
        }
        
    }
    
    // @Author : Kalam
    // Navigate to Cases tab
    public void SelectSMECase(String val) throws InterruptedException {
        WebElement ele = driver.findElement(By.xpath("//h1[text()='Cases']/following::a[@title][@data-recordid][not(contains(@title,'"+val+"'))]"));
        jsClick(ele);
        Thread.sleep(500);
    }

	//@Author : Kalam
	// Delete the created Payment record
	public void DeletePayRecord(String val) throws InterruptedException {
		// closeTabWindows();
		Thread.sleep(1000);
		WebElement IcnDownxpath = driver.findElement(By.xpath(
				"//lightning-icon[@class='slds-icon-utility-down slds-button__icon slds-icon_container forceIcon']"));
		jsClick(IcnDownxpath);
		Thread.sleep(1000);
		driver.findElement(By.xpath(lnkRecentViewxpath)).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(
				"//a[text()='" + val + "']/following::span[@class='slds-icon_container slds-icon-utility-down']"))
				.click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(lnkDeletexpath)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(btnDeletexpath)).click();
		Thread.sleep(1500);
	}

	//@Author : Kalam
	public void closeTabWindows() throws InterruptedException {
		List<WebElement> list = driver.findElements(By.xpath(
				"//ul[@class='tabBarItems slds-grid']//div[@class='close slds-col--bump-left slds-p-left--none slds-context-bar__icon-action ']"));
		if (list.size() == 0) {
			System.out.println("There are no open tabs");
		} else {
			for (int i = 0; i < list.size(); i++) {
				try {
					list.get(i).click();
					Thread.sleep(500);
				} catch (Throwable t) {
					System.out.println("More tabs on page loaded later");
					t.printStackTrace();
				}
			}
		}
	}


	//@Author : Kalam
	public void clickButton(WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, 50);

		wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));

		System.out.println("Element is clickable");
		element.click();
	}
	
	//@Author : Kalam
	    public void jsClick(WebElement el) {
			try {
				JavascriptExecutor jse = (JavascriptExecutor)driver;
				jse.executeScript("arguments[0].click();", el);
				System.out.println("Element clicked");
			} catch (Exception e){
				System.out.println("=============================================================");
				System.out.println("Exception-jsClick(): "+e.getMessage());
				//takeScreenShot();
				e.printStackTrace();
				System.out.println("=============================================================");
			}
	    }

	  //@Author : Kalam
	    //Click on Student Payment record
	    public void ClickStudentPaymentRecord() throws InterruptedException {
	        Scrollpagedown();
	        Scrollpagedown();
	        Actions ac = new Actions(driver);
	        ac.moveToElement(driver.findElement(By.xpath("//span[text()='Student Payments']/following::a/following::span[contains(text(),'SP-')]"))).build().perform();
	        Thread.sleep(500);
	        jsClick(driver.findElement(By.xpath("//span[text()='Student Payments']/following::a")));
	        Thread.sleep(1000);
	    }
	    
     //@Author : Kalam
    public void ClickLoanPaymentRecord() throws InterruptedException {

        jsClick(driver.findElement(By.xpath("//*[text()='Loan']/preceding::a[contains(text(),'Payment-')][1]")));
        Thread.sleep(1500);
    }
    
    //@Author : Kalam
    //Capture Loan Amount
    public String CaptureLoanAmount() throws InterruptedException {
        //Scrollpagedown();
        return driver.findElement(By.xpath("//div[text()='Payment']/following::span[text()='Loan Amount']/following::lightning-formatted-number")).getText();
    }
    
    //@Author : Kalam
    //Capture Loan EMI Amount
    public String CaptureEMIAmount() throws InterruptedException {
        return driver.findElement(By.xpath("//div[text()='Payment']/following::span[text()='Amount']/following::lightning-formatted-number")).getText();
    }
	  //@Author : Kalam
	    public void Scrollpagedown() throws InterruptedException {

	        driver.findElement(tag).sendKeys(Keys.PAGE_DOWN);
	        Thread.sleep(1200);
	    }
	    
	  //@Author : Kalam
	    public void Scrollend() throws InterruptedException {

	        driver.findElement(tag).sendKeys(Keys.END);
	        Thread.sleep(1200);
	    }
	    
	       //**************************************************Manish Methods*****************************************************
	       //==============================Author :: Manish Goyal==============================
	      //span[text()='Student Payments']/following::article/div/div[2]//a/slot[1]
	        //public static String link_paymentId="//span[text()='Student Payments']/following::article/div/div[2]//a/slot[1]";
	        //public static String button_CreateCase="//div[text()='Payment']/following::button[text()='Create Case']";
	       // public static String textfield_LoanAmount="//h2[text()='Create Case']/following::input[@class='input uiInputSmartNumber']";
	        //public static String button_Savebutton="//span[text()='Save']";
	        //public static String label_CaseNumber="//span[text()='Cases']/following::article//dt[text()='Case Number:']/following::a/slot[1]";
	        //public static String link_CaseNumber="//span[text()='Cases']/following::article//dt[text()='Case Number:']/following::a";
	        
	        //Author :: Manish Goyal
	        public static WebElement textfield_LoanAmount(WebDriver driver)
	        {
	            return driver.findElement(By.xpath("//h2[text()='Create Case']/following::input[@class='input uiInputSmartNumber']"));
	        }

	      //Author :: Manish Goyal
	        public static WebElement link_paymentId(WebDriver driver)
	        {
	            return driver.findElement(By.xpath("//span[text()='Student Payments']/following::article/div/div[2]//a/slot[1]"));
	        }
	        
	      //Author :: Manish Goyal
	        public static WebElement button_CreateCase(WebDriver driver)
	        {
	            return driver.findElement(By.xpath("//div[text()='Payment']/following::button[text()='Create Case']"));
	        }
	        
	      //Author :: Manish Goyal
	        public static WebElement button_Savebutton(WebDriver driver)
	        {
	            return driver.findElement(By.xpath("//span[text()='Save']"));
	        }
	        
	      //Author :: Manish Goyal
	        public static WebElement label_CaseNumber(WebDriver driver)
	        {
	            return driver.findElement(By.xpath("//span[text()='Cases']/following::article//dt[text()='Case Number:']/following::a/slot[1]"));
	        }
	        
	      //Author :: Manish Goyal
	        //Returns Case Number link webelement
	        public static WebElement link_CaseNumber(WebDriver driver)
	        {
	            return driver.findElement(By.xpath("//span[text()='Cases']/following::article//dt[text()='Case Number:']/following::a"));
	        }
	    
	    
	  //Author :: Manish Goyal
	    public static void clickCreateCase(WebDriver driver)
	    {
	    	PaymentsPO.button_CreateCase(driver).click();
	    }
	    
	  //Author :: Manish Goyal
	    public static void enterLoanAmount(WebDriver driver,String loanamount)
	    {
	    	PaymentsPO.textfield_LoanAmount(driver).sendKeys(loanamount);
	    }
	    
	  //Author :: Manish Goyal
	    public static String returnCaseNumber(WebDriver driver)
	    
	    {
	    	return PaymentsPO.link_CaseNumber(driver).getAttribute("title");
	    }
	    
	  //Author :: Manish Goyal
	    public static void clickCaseNumber(WebDriver driver)
	    
	    {
	    	 PaymentsPO.link_CaseNumber(driver).click();
	    }
	    
	    //**************************************************Manali Methods*****************************************************

	    // Navigate to Payment tab @ manali shivareddy
	    public void NavPaymentTab(String val) throws InterruptedException {
	        jsClick(driver.findElement(By
	                .xpath("//ul[@class='tabBarItems slds-tabs--default__nav']//span[@class='title slds-truncate'][text()='"
	                        + val + "']")));
	        Thread.sleep(2000);
	    }

	    // Create an EMI case @ manali shivareddy
	    public void clickCreateCase(String val) throws InterruptedException {
	        Thread.sleep(2000);
	        jsClick(driver.findElement(By.xpath(btnCreateCase)));
	        Thread.sleep(2000);
	        driver.findElement(By.xpath(txtAppId)).sendKeys(val);
	        driver.findElement(By.xpath(datePicker)).click();
	        driver.findElement(By.xpath(dateToday)).click();
	        jsClick(driver.findElement(By.xpath(btnSave)));
	        Thread.sleep(2000);
	    }

	    // Get PriorityDate @ manali shivareddy
	    public String[] getPriorityDateTime() throws InterruptedException {
	        DateFormat dateFormat = new SimpleDateFormat("dd-M-yyyy");
	        Date date = new Date();
	        String date1 = dateFormat.format(date);

	        String txtPriorityDateTime = driver.findElement(By.xpath(txtPriorityDate)).getAttribute("title");
	        Thread.sleep(800);
	        String priorityDate = driver.findElement(By.xpath(txtPriorityTime)).getAttribute("value");
	        return new String[] { txtPriorityDateTime, priorityDate, date1 };

	    }

	    // Get Case Number @ manali shivareddy
	    public String getCaseNumber() throws InterruptedException {
	        String txtPriorityDateTime = driver.findElement(By.xpath(txtCaseNumber)).getAttribute("title");
	        Thread.sleep(800);
	        return txtPriorityDateTime;

	    }

	    // Click on the newly created EMI case @ manali shivareddy
	    public void clickCaseNumber() throws InterruptedException {
	        driver.findElement(By.xpath(txtCaseNumber)).click();
	        Thread.sleep(800);

	    }

	    // Create an EMI case with no app id @ manali shivareddy
	    public void clickCreateCase() throws InterruptedException {
	        Thread.sleep(2000);
	        jsClick(driver.findElement(By.xpath(btnCreateCase)));
	        Thread.sleep(2000);
	        driver.findElement(By.xpath(datePicker)).click();
	        driver.findElement(By.xpath(dateToday)).click();
	        jsClick(driver.findElement(By.xpath(btnSave)));
	        Thread.sleep(2000);
	    }

	    // to create a message notification @ manali shivareddy
	    public String createMessageNotification() throws InterruptedException {
	        Scrollend();
	        jsClick(driver.findElement(By.xpath(lnkContact1)));
	        Thread.sleep(300);
	        driver.findElement(By.xpath(txtContact1)).clear();
	        Thread.sleep(300);
	        driver.findElement(By.xpath(txtContact1)).sendKeys("8105710715");
	        Thread.sleep(300);
	        driver.findElement(By.xpath(btnContactSave)).click();
	        Thread.sleep(300);
	        jsClick(driver.findElement(By.xpath(iconMessage)));
	        Thread.sleep(300);
	        WebElement ele = driver.findElement(By.xpath(dropdownSmsTemplate));
	        ele.click();
	        ele.sendKeys(Keys.DOWN);
	        ele.sendKeys(Keys.ENTER);
	        driver.findElement(By.xpath(btnSend)).click();
	        Thread.sleep(2000);
	        driver.navigate().refresh();
	        Thread.sleep(2000);
	        Scrollpagedown();
	        jsClick(driver.findElement(By.xpath(iconMessage)));
	        WebDriverWait wait = new WebDriverWait(driver, 1000);
	        wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(txtWarning))));
	        String warning = driver.findElement(By.xpath(txtWarning)).getText();
	        return warning;
	    }

	    // to get notification msg @ manali shivareddy
	    public String getMessageNotificationSub() throws InterruptedException {
	        Thread.sleep(2000);
	        String msgText = driver.findElement(By.xpath(msgSubject)).getAttribute("title");
	        return msgText;
	    }

	    // to close notification tab @ manali shivareddy
	    public void closeNotification() throws InterruptedException {
	        driver.findElement(By.xpath(closeNotificationTab)).click();
	        Thread.sleep(800);

	    }
	    
	    
	    //**************************************************Anil Methods*******************************************************
	    //**************************************************Amit Methods*******************************************************
	    //**************************************************Sumit Methods******************************************************
	    //**************************************************Bhavana Methods****************************************************
	    
	    //@Author : Bhavana
	    // To open payment record
        public void openPaymentRecord(String val) throws InterruptedException 
        {
            jsClick(driver.findElement(By.xpath("//a[@title='"+val+"']")));
            Thread.sleep(1000);
        }

	  //**************************************************Saurabh Methods****************************************************
	    
	   

}
