package pageObjects;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.time.DateUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import resources.ExcelData;
import resources.base;

public class UnregisteredCustomersDetailCaptureTaskPO extends base {
    WebDriver driver;

    //private String btnNextxpath = "//button[text()='Next']";
    //private String lblAmtPaidbyCusxpath = "//label[text()='Amount Paid By Customer']/following::input";
    //private String btnListboxMovexpath = "//button[@title='Move selection to Selected']";
    //private String txtPayRefxpath = "//label[text()='Payment Reference']/following::input";
    //private String ddCollectionChnnelxpath = "//label[text()='Collection Channel']/following::button";
    //private String lblErrorMessxpath = "//div[@class='slds-text-color_error']";
    //private String ddNoEMICollxpath = "//select[@name='No_Of_EMI_Collected']";
    //private String ddTOCollAPxpath = "//select[@name='Type_Of_Collection_alreadyPaid']";
    //private String ddEligfrRefxpath = "//select[@name='Eligible_For_Refund']";
    ExcelData excelData = new ExcelData();
    ArrayList<String> al3 = new ArrayList<String>();

    // Declaring Constructor
    public UnregisteredCustomersDetailCaptureTaskPO(WebDriver driver) {
        this.driver = driver;
    }
    
    //**************************************************Kalam Methods******************************************************


  //Author : Kalam
    // Click on Capture detail button
    public void ClickCaptureDetail() throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//div[text()='Capture Call Details']")));
        Thread.sleep(3000);
    }

  //Author : Kalam
    // Select on Spoke To
    public void SelectSpokeTo(String val) throws InterruptedException {
        Select sel = new Select(driver.findElement(By.xpath("//span[text()='Spoke To']/following::select")));
        sel.selectByVisibleText(val);
        Thread.sleep(400);
        driver.findElement(By.xpath("//button[text()='Next']")).click();
        Thread.sleep(2000);
    }

  //Author : Kalam
    // Select on Spoke To
    public void SelectSpokeTo2(String val) throws InterruptedException {
        Select sel = new Select(driver.findElement(By.xpath("//span[text()='Spoke To']/following::select")));
        sel.selectByVisibleText(val);
        Thread.sleep(400);
    }

  //Author : Kalam
    // Select on Spoke To
    public void SelectSpokeTo3(String val) throws InterruptedException {
        visibleText(By.xpath("//label[text()='Spoke To']"));
        clickButton(driver.findElement(By.xpath("//label[text()='Spoke To']/following::button[@name]")));
        Thread.sleep(300);
        jsClick(driver.findElement(By.xpath("//label[text()='Spoke To']/following::button[@name]")));
        Thread.sleep(200);
        jsClick(driver.findElement(By.xpath("//label[text()='Spoke To']/following::span[text()=\"" + val + "\"]")));
    }

  //Author : Kalam
    // Click Proceed option to move forward
    public void ClickProceedOptn() throws Exception {
        retryForDetachedFrame(driver, "//iframe", 0);
        WebElement frame1 = driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
        Thread.sleep(400);
        driver.switchTo().frame(frame1);
        Thread.sleep(400);
        driver.findElement(By.xpath("//span[text()='Proceed']")).click();
        Thread.sleep(800);
        driver.findElement(By.xpath("//button[text()='Next']")).click();
        Thread.sleep(3000);
    }

  //Author : Kalam
    // Click Proceed option to move forward
    public void ClickProceedOptn2() throws Exception {
        retryForDetachedFrame(driver, "//iframe", 0);
        WebElement frame1 = driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
        Thread.sleep(400);
        driver.switchTo().frame(frame1);
        visibleText(By.xpath("//span[text()='Proceed']"));
        driver.findElement(By.xpath("//span[text()='Proceed']")).click();
        Thread.sleep(200);
        driver.findElement(By.xpath("//button[text()='Next']")).click();
        // Thread.sleep(3000);
    }

  //Author : Kalam
    // Click DNP to move forward
    public void ClickDNP() throws Exception {
        retryForDetachedFrame(driver, "//iframe", 0);
        WebElement frame1 = driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
        Thread.sleep(400);
        driver.switchTo().frame(frame1);
        visibleText(By.xpath("//span[text()='DNP']"));
        driver.findElement(By.xpath("//span[text()='DNP']")).click();
        Thread.sleep(200);
        driver.findElement(By.xpath("//button[text()='Next']")).click();
        // Thread.sleep(3000);
    }

  //Author : Kalam
    // Click DNP/Call Drop to move forward
    public void ClickDNP_CallDrop() throws Exception {
        retryForDetachedFrame(driver, "//iframe", 0);
        WebElement frame1 = driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
        Thread.sleep(400);
        driver.switchTo().frame(frame1);
        visibleText(By.xpath("//span[text()='DNP/Call Drop']"));
        driver.findElement(By.xpath("//span[text()='DNP/Call Drop']")).click();
        Thread.sleep(200);
        driver.findElement(By.xpath("//button[text()='Next']")).click();
        // Thread.sleep(3000);
    }

  //Author : Kalam
    // Click Abrupt Disconnection option to move forward
    public void ClickAbruptDisconnection() throws Exception {
        retryForDetachedFrame(driver, "//iframe", 0);
        WebElement frame1 = driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
        Thread.sleep(400);
        driver.switchTo().frame(frame1);
        visibleText(By.xpath("//span[text()='Abrupt Disconnection']"));
        driver.findElement(By.xpath("//span[text()='Abrupt Disconnection']")).click();
        Thread.sleep(200);
        driver.findElement(By.xpath("//button[text()='Next']")).click();
        // Thread.sleep(3000);
    }

  //Author : Kalam
    // Click Customer will Call option to move forward
    public void ClickCustomerwillCall() throws Exception {
        retryForDetachedFrame(driver, "//iframe", 0);
        WebElement frame1 = driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
        Thread.sleep(400);
        driver.switchTo().frame(frame1);
        visibleText(By.xpath("//span[text()='Customer will Call']"));
        driver.findElement(By.xpath("//span[text()='Customer will Call']")).click();
        Thread.sleep(200);
        driver.findElement(By.xpath("//button[text()='Next']")).click();
        // Thread.sleep(3000);
    }

  //Author : Kalam
    // Click Call Back Requested option to move forward
    public void ClickCallBackRequested() throws Exception {
        retryForDetachedFrame(driver, "//iframe", 0);
        WebElement frame1 = driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
        Thread.sleep(400);
        driver.switchTo().frame(frame1);
        visibleText(By.xpath("//span[text()='Call Back Requested']"));
        driver.findElement(By.xpath("//span[text()='Call Back Requested']")).click();
        Thread.sleep(200);
        Date date = DateUtils.addDays(new Date(), +1);
        SimpleDateFormat sdf = new SimpleDateFormat("MM dd, yyyy");
        driver.findElement(By.xpath("//span[text()='Call Back Date']/following::input")).sendKeys(sdf.format(date));
        driver.findElement(By.xpath("//button[text()='Next']")).click();
        // Thread.sleep(3000);
    }

  //Author : Kalam
    // Select the value for Please Select The Call Type
    public void SelectPSTCT(String val) throws InterruptedException {
        visibleText(By.xpath("//label[text()='Please Select The Call Type']"));
        Select sel = new Select(driver
                .findElement(By.xpath("//label[text()='Please Select The Call Type']/following::select[@required]")));
        sel.selectByVisibleText(val);
        Thread.sleep(200);
    }

  //Author : Kalam
    // Select the value for Please Select the Existing Open Case
    public void SelectPSTEOC() throws InterruptedException {
        visibleText(By.xpath("//label[text()='Please Select the Existing Open Case']"));
        Thread.sleep(200);
        Select sel = new Select(driver.findElement(
                By.xpath("//label[text()='Please Select the Existing Open Case']/following::select[@required]")));
        sel.selectByIndex(1);
        Thread.sleep(200);
    }

    // Enter the value for Notes
    // public void EnterNotesVal(String val) throws InterruptedException {
    // driver.findElement(By.xpath("//label[text()='Notes']/following::textarea")).sendKeys(val);
    // Thread.sleep(200);
    // }

  //Author : Kalam
    // Click Next button
    public void ClickNext() throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//button[text()='Next']")));
        Thread.sleep(2000);
    }

  //Author : Kalam
    // Click Finish button
    public void ClickFinish() throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//button[text()='Finish']")));
        Thread.sleep(2000);
    }

  //Author : Kalam
    // Select the device
    public void SelectDevice(String val) throws InterruptedException {
        driver.findElement(By.xpath("//label[text()='Device']/following::span[@lightning-basecombobox_basecombobox]"))
                .click();
        Thread.sleep(400);
        driver.findElement(By.xpath("//label[text()='Device']/following::span[text()='" + val + "']")).click();
        Thread.sleep(1000);
    }

  //Author : Kalam
    // Select the Please Select Your Issue Category
    public void SelectIssueCategory(String val) throws InterruptedException {
        driver.findElement(By.xpath(
                "//label[text()='Please Select Your Issue Category']/following::span[@lightning-basecombobox_basecombobox]"))
                .click();
        Thread.sleep(400);
        driver.findElement(
                By.xpath("//label[text()='Please Select Your Issue Category']/following::span[text()='" + val + "']"))
                .click();
        Thread.sleep(400);
    }

  //Author : Kalam
    // Select the value for Please Specify Your Issue
    public void SelectPSYI(String val) throws InterruptedException {
        Select sel = new Select(driver
                .findElement(By.xpath("//label[text()='Please Specify Your Issue']/following::select[@required]")));
        sel.selectByVisibleText(val);
        Thread.sleep(400);
    }

  //Author : Kalam
    // Select the value for Please Specify Your Issue Sub Type
    public void SelectPSYIST(String val) throws InterruptedException {
        Select sel = new Select(driver.findElement(
                By.xpath("//label[text()='Please Specify Your Issue Sub Type']/following::select[@required]")));
        sel.selectByVisibleText(val);
        Thread.sleep(400);
    }

  //Author : Kalam
    // Select the value for Is The Issue Resolved Currently?
    public void SelectIsTICR(String val) throws InterruptedException {
        Select sel = new Select(driver.findElement(
                By.xpath("//label[text()='Is The Issue Resolved Currently?']/following::select[@required]")));
        sel.selectByVisibleText(val);
        Thread.sleep(400);
    }

  //Author : Kalam
    // Select the Please Select Your Issue Category
    public void SelectPSYICategory(String val) throws InterruptedException {
        driver.findElement(By.xpath(
                "//label[text()='Please Select Your Issue Category']/following::span[@lightning-basecombobox_basecombobox]"))
                .click();
        Thread.sleep(400);
        driver.findElement(
                By.xpath("//label[text()='Please Select Your Issue Category']/following::span[text()='" + val + "']"))
                .click();
        Thread.sleep(400);
    }

  //Author : Kalam
    // Select the Category
    public void SelectCategory(String val) throws InterruptedException {
        driver.findElement(By.xpath("//label[text()='Category']/following::span[@lightning-basecombobox_basecombobox]"))
                .click();
        Thread.sleep(400);
        driver.findElement(By.xpath("//label[text()='Category']/following::span[text()='" + val + "']")).click();
        Thread.sleep(400);
    }

  //Author : Kalam
    // Select the Sub Category
    public void SelectSubCategory(String val) throws InterruptedException {
        Select sel1 = new Select(
                driver.findElement(By.xpath("//label[text()='Sub Category']/following::select[@required]")));
        sel1.selectByVisibleText(val);
        Thread.sleep(400);
    }

  //Author : Kalam
    // Select the Please Specify Your Issue Sub Type
    public void SelectIssueSubType(String val) throws InterruptedException {
        Select sel2 = new Select(driver.findElement(
                By.xpath("//label[text()='Please Specify Your Issue Sub Type']/following::select[@required]")));
        sel2.selectByVisibleText(val);
        Thread.sleep(400);
    }

  //Author : Kalam
    // Select Is The Issue Resolved Currently?
    public void SelectIssueResolved(String val) throws InterruptedException {
        Select sel3 = new Select(driver.findElement(
                By.xpath("//label[text()='Is The Issue Resolved Currently?']/following::select[@required]")));
        sel3.selectByVisibleText(val);
        Thread.sleep(400);
    }

  //Author : Kalam
    // Select Please Specify Your Logistics Issue
    public void SelectSYLI(String val) throws InterruptedException {
        Select sel3 = new Select(driver.findElement(
                By.xpath("//label[text()='Please Specify Your Logistics Issue']/following::select[@required]")));
        sel3.selectByVisibleText(val);
        Thread.sleep(400);
    }

  //Author : Kalam
    // Select the Is there is any change in grade, course, or validity
    public void SelectITGCorV(String val) throws InterruptedException {
        driver.findElement(By.xpath(
                "//label[text()='Is there is any change in grade, course, or validity']/following::span[@lightning-basecombobox_basecombobox]"))
                .click();
        Thread.sleep(400);
        driver.findElement(By
                .xpath("//label[text()='Is there is any change in grade, course, or validity']/following::span[text()='"
                        + val + "']"))
                .click();
        Thread.sleep(400);
    }

  //Author : Kalam
    // Select Is there is any change in registered no: or shipping address
    public void SelectIRNorSA(String val) throws InterruptedException {
        driver.findElement(By.xpath(
                "//label[text()='Is there is any change in registered no: or shipping address']/following::span[@lightning-basecombobox_basecombobox]"))
                .click();
        Thread.sleep(400);
        driver.findElement(By.xpath(
                "//label[text()='Is there is any change in registered no: or shipping address']/following::span[text()='"
                        + val + "']"))
                .click();
        Thread.sleep(400);
    }

  //Author : Kalam
    // Select Is The Issue Resolved Currently?
    public void SelectITIRC(String val) throws InterruptedException {
        Select sel3 = new Select(driver.findElement(
                By.xpath("//label[text()='Is The Issue Resolved Currently?']/following::select[@required]")));
        sel3.selectByVisibleText(val);
        Thread.sleep(400);
    }

  //Author : Kalam
    // Select Please Select The Catagory Of Your Refund
    public void SelectPSCOYR(String val) throws InterruptedException {
        Select sel3 = new Select(driver.findElement(
                By.xpath("//label[text()='Please Select The Catagory Of Your Refund']/following::select[@required]")));
        sel3.selectByVisibleText(val);
        Thread.sleep(400);
    }

  //Author : Kalam
    // Select Please Select Reason for Refund
    public void SelectPSTRR(String val) throws InterruptedException {
        Select sel3 = new Select(driver.findElement(
                By.xpath("//label[text()='Please Select Reason for Refund']/following::select[@required]")));
        sel3.selectByVisibleText(val);
        Thread.sleep(400);
    }

  //Author : Kalam
    // Select Please Select Reason for Refund
    public void SelectPSTRR2(String val) throws InterruptedException {
        Select sel3 = new Select(driver.findElement(
                By.xpath("//label[text()='Please Select The Refund Reason']/following::select[@required]")));
        sel3.selectByVisibleText(val);
        Thread.sleep(400);
    }

  //Author : Kalam
    // Pull values for Product
    public void PullProductVal() throws InterruptedException, IOException {

    }

  //Author : Kalam
    // Select all values present in Please Select Sub Reason for Refund - Product
    public void VerifyAllValinPSSTRR(int m) throws InterruptedException, IOException {
        al3 = excelData.getData("TC2", "RefundProcess", "Tcid");
        String[] Val = al3.get(m).trim().split(";");
        List<WebElement> List = driver.findElements(
                By.xpath("//label[text()='Please Select Sub Reason for Refund']/following-sibling::select/option"));
        for (int i = 0; i < List.size(); i++) {
            String Val2 = List.get(i).getText();
            Thread.sleep(300);
            System.out.println(Val[i] + " | " + Val2);
            Assert.assertTrue(Val[i].equalsIgnoreCase(Val2));
        }

    }

  //Author : Kalam
    // Select Please Select Sub Reason for Refund
    public void SelectPSSTRR(String val) throws InterruptedException {
        Select sel3 = new Select(driver.findElement(
                By.xpath("//label[text()='Please Select Sub Reason for Refund']/following::select[@required]")));
        sel3.selectByVisibleText(val);
        Thread.sleep(400);
    }

  //Author : Kalam
    // Enter Comments
    public void EnterComments(String val) throws InterruptedException {
        driver.findElement(By.xpath("//label[text()='Comments']/following::textarea")).sendKeys(val);
        Thread.sleep(400);
    }

  //Author : Kalam
    // Please Select The Order
    public void SelectPSTO() throws InterruptedException {
        driver.findElement(By.xpath(
                "//label[text()='Please Select The Order']/following::span[@lightning-basecombobox_basecombobox]"))
                .click();
        Thread.sleep(400);
        driver.findElement(
                By.xpath("//label[text()='Please Select The Order']/following::span[contains(text(),'ORD')]")).click();
        Thread.sleep(1200);
    }

  //Author : Kalam
    // Please Select The Issue responsibility
    public void SelectPSTIR(String val) throws InterruptedException {
        Select sel3 = new Select(driver.findElement(
                By.xpath("//label[text()='Please Select The Issue responsibility']/following::select[@required]")));
        sel3.selectByVisibleText(val);
        Thread.sleep(400);
    }

  //Author : Kalam
    // Verify Error message
    public boolean CheckErrorMess() {
        if (driver.findElement(By.xpath("//p[contains(text(),'Existing RR case')]")).isDisplayed()) {
            return true;
        } else {
            return false;
        }
    }

  //Author : Kalam
    // Navigate back to Account screen
    public void NavBackAccount() throws InterruptedException {
        try {
            jsClick(driver.findElement(By.xpath("//span[text()='Name']/following::a")));
            Thread.sleep(3000);
        } catch (WebDriverException e) {
            Thread.sleep(500);
            jsClick(driver.findElement(By.xpath("//span[text()='Name']/following::a")));
            Thread.sleep(3000);
        } catch (Exception ee) {
            ee.printStackTrace();
            throw ee;
        }
    }

  //Author : Kalam
    // Navigate back to Account screen
    public void NavToCase() throws InterruptedException {
        try {
            driver.findElement(By.xpath("//span[text()='Related To']/following::a")).click();
            Thread.sleep(3000);
        } catch (WebDriverException e) {
            Thread.sleep(500);
            driver.findElement(By.xpath("//span[text()='Related To']/following::a")).click();
            Thread.sleep(3000);
        } catch (Exception ee) {
            ee.printStackTrace();
            throw ee;
        }
    }

  //Author : Kalam
    // Get the Case created value under Related To
    public String CaptureRelatedTo() throws InterruptedException {
        String RelatedTo = driver
                .findElement(
                        By.xpath("//div[text()='Task']/following::span[text()='Related To']/following::a[@data-refid]"))
                .getText();
        Thread.sleep(300);
        return RelatedTo;
    }

  //Author : Kalam
    // Verify Status
    public String CheckStatus() throws InterruptedException {
        String val = driver
                .findElement(By.xpath("//div[text()='Task']/following::span[text()='Status']/following::span/span"))
                .getText();
        return val;
    }
    // *****************************************************************************************************************************//

  //Author : Kalam
    // Click Save button
    public void EnterCallBackNumber(String val) throws InterruptedException {
        visibleText(By.xpath("//span[text()='Call Back Number']"));
        clickButton(driver
                .findElement(By.xpath("//span[text()='Call Back Number']/following::button/lightning-primitive-icon")));
        Thread.sleep(2000);
        driver.findElement(
                By.xpath("//div[text()='Task']/following::label/span[text()='Call Back Number']/following::input"))
                .sendKeys(val);
        driver.findElement(By.xpath("//div[text()='Task']/following::span[text()='Save']")).click();
        Thread.sleep(3000);

    }

  //Author : Kalam
    // Call Type
    public void SelectCallType(String val) throws Exception {
        retryForDetachedFrame(driver, "//iframe", 0);
        WebElement frame1 = driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
        Thread.sleep(400);
        driver.switchTo().frame(frame1);
        visibleText(By.xpath("//h2/span[text()='Capture Call Log - Class Issues']"));
        Select sel3 = new Select(
                driver.findElement(By.xpath("//span[text()='Call Type']/following::select[@required]")));
        sel3.selectByVisibleText(val);
        Thread.sleep(200);
    }

  //Author : Kalam
    // Call Status
    public void SelectCallStatus(String val) throws InterruptedException {
        Select sel3 = new Select(
                driver.findElement(By.xpath("//span[text()='Call Status']/following::select[@required]")));
        sel3.selectByVisibleText(val);
        Thread.sleep(200);
    }

  //Author : Kalam
    // Customer Type
    public void SelectCustomerType(String val) throws InterruptedException {
        Select sel3 = new Select(
                driver.findElement(By.xpath("//span[text()='Customer Type']/following::select[@required]")));
        sel3.selectByVisibleText(val);
        Thread.sleep(200);
    }

  //Author : Kalam
    // Search registered student by Phone or Email
    public void SelectInsertNumber(String val) throws InterruptedException {
        driver.findElement(
                By.xpath("//h2/span[text()='Capture Call Log - Class Issues']/following::input[@type='search']"))
                .sendKeys(val);
        Thread.sleep(2000);
        driver.findElement(
                By.xpath("//h2/span[text()='Capture Call Log - Class Issues']/following::input[@type='search']"))
                .sendKeys(" ");
        Thread.sleep(200);
        Thread.sleep(1200);

    }

  //Author : Kalam
    // Search registered student by Phone or Email
    public void SelectPersonAccount(String val) throws InterruptedException {
        driver.findElement(By.xpath(
                "//span[@class='slds-listbox__option-text slds-listbox__option-text_entity'][text()='" + val + "']"))
                .click();
        Thread.sleep(200);
    }

  //Author : Kalam
    // Enquiry Type
    public void SelectEnquiryType(String val) throws InterruptedException {
        Select sel3 = new Select(
                driver.findElement(By.xpath("//label[text()='Enquiry Type']/following::select[@required] | //span[text()='Enquiry Type']/following::select[@required]")));
        sel3.selectByVisibleText(val);
        Thread.sleep(200);
    }

  //Author : Kalam
    // Reason For Call
    public void SelectReasonForCall(String val) throws InterruptedException {
        Select sel3 = new Select(
                driver.findElement(By.xpath("//label[text()='Reason For Call']/following::select[@required] | //span[text()='Reason For Call']/following::select[@required] | //span[text()='Reason for Call']/following::select[@required] ")));
        sel3.selectByVisibleText(val);
        Thread.sleep(200);
    }

  //Author : Kalam
    // Course
    public void SelectCourse(String val) throws InterruptedException {
        Select sel3 = new Select(driver.findElement(By.xpath("//span[text()='Course']/following::select[@required]")));
        sel3.selectByVisibleText(val);
        Thread.sleep(200);
    }

  //Author : Kalam
    // Country
    public void SelectCountry(String val) throws InterruptedException {
        Select sel3 = new Select(driver.findElement(By.xpath("//span[text()='Country']/following::select[@required]")));
        sel3.selectByVisibleText(val);
        Thread.sleep(200);
    }

  //Author : Kalam
    // Name
    public void EnterName(String val) throws InterruptedException {
        visibleText(By.xpath("//span[text()='Inbound Enquiry on CST']"));
        driver.findElement(By.xpath("//label[text()='Name']/following::input")).sendKeys(val);
        Thread.sleep(200);
    }
    
    //Author : Kalam
    // Name
    public void EnterPhoneNumber(String val) throws InterruptedException {
        driver.findElement(By.xpath("//label[text()='Phone Number']/following::input[1]")).sendKeys("1234567890");
        Thread.sleep(200);
    }
    
  //Author : Kalam
    // Email
    public void EnterEmail(String val) throws InterruptedException {
        driver.findElement(By.xpath("//label[text()='Email']/following::input")).sendKeys(val);
        Thread.sleep(200);
    }

  //Author : Kalam
    // City
    public void EnterCity(String val) throws InterruptedException {
        driver.findElement(By.xpath("//label[text()='City']/following::input")).sendKeys(val);
        Thread.sleep(200);
    }

  //Author : Kalam
    // Language
    public void EnterLanguage(String val) throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//label[text()='Language']/following::button")));
        Thread.sleep(200);
        jsClick(driver.findElement(By.xpath(
                "//label[text()='Language']/following::button/following::lightning-base-combobox-item[@data-value='"
                        + val + "']")));
        Thread.sleep(200);
    }

  //Author : Kalam
    // Reason For Call
    public void EnterReasonForCall(String val) throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//label[text()='Reason For Call']/following::button")));
        Thread.sleep(200);
        jsClick(driver.findElement(By.xpath(
                "//label[text()='Reason For Call']/following::button/following::lightning-base-combobox-item[@data-value=\""
                        + val + "\"]")));
        Thread.sleep(200);
    }

  //Author : Kalam
    // Grade
    public void EnterGrade(String val) throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//label[text()='Grade']/following::button")));
        Thread.sleep(200);
        jsClick(driver.findElement(By.xpath(
                "//label[text()='Grade']/following::button/following::lightning-base-combobox-item[@data-value=\"" + val+ "\"] | //span[text()='Grade']/following::button/following::lightning-base-combobox-item[@data-value=\"" + val+ "\"]")));
        Thread.sleep(200);
    }

  //Author : Kalam
    // Course
    public void EnterCourse(String val) throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//label[text()='Course']/following::button")));
        Thread.sleep(200);
        jsClick(driver.findElement(By.xpath(
                "//label[text()='Course']/following::button/following::lightning-base-combobox-item[@data-value=\""
                        + val + "\"]")));
        Thread.sleep(200);
    }

  //Author : Kalam
    // Enquiry By
    public void EnterEnquiryBy(String val) throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//label[text()='Enquiry By']/following::button")));
        Thread.sleep(200);// label[text()='Enquiry
                          // By']/following::button/following::lightning-base-combobox-item[@data-value='Parent']
        // jsClick(driver.findElement(By.xpath("//label[text()='Enquiry
        // By']/following::button/span[text()=\""+val+"\"]")));
        jsClick(driver.findElement(By.xpath(
                "//label[text()='Enquiry By']/following::button/following::lightning-base-combobox-item[@data-value=\""
                        + val + "\"]")));
        Thread.sleep(200);
    }

  //Author : Kalam
    // Purchased BYJU'S Course before?
    public void EnterPurchasedCourseBefore(String val) throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//label[text()=\"Purchased BYJU'S Course before?\"]/following::button")));
        Thread.sleep(200);
        jsClick(driver.findElement(By.xpath(
                "//label[text()=\"Purchased BYJU'S Course before?\"]/following::button/following::lightning-base-combobox-item[@data-value=\""
                        + val + "\"]")));
        Thread.sleep(200);
    }

  //Author : Kalam
    // Is this a repeat call?
    public void EnterIsthisrepeatcall(String val) throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//label[text()='Is this a repeat call?']/following::button")));
        Thread.sleep(200);
        jsClick(driver.findElement(By.xpath(
                "//label[text()='Is this a repeat call?']/following::button/following::lightning-base-combobox-item[@data-value=\""
                        + val + "\"]")));
        Thread.sleep(200);
    }

  //Author : Kalam
    // Brief Comment (Purpose of call)
    public void EnterBriefComment(String val) throws InterruptedException {
        driver.findElement(By.xpath("//label[text()='Brief Comment (Purpose of call)']/following::textarea"))
                .sendKeys(val);
        Thread.sleep(200);
    }

  //Author : Kalam
    // How did you know about Byjus?
    public void EnterHDYKAByjus(String val) throws InterruptedException {
        jsClick(driver.findElement(By.xpath("//label[text()='How did you know about Byjus?']/following::button")));
        Thread.sleep(200);
        jsClick(driver.findElement(By.xpath(
                "//label[text()='How did you know about Byjus?']/following::button/following::lightning-base-combobox-item[@data-value=\""
                        + val + "\"]")));
        Thread.sleep(200);
    }

  //Author : Kalam
    // Do you want to transfer the call?
    public void Selecttransfercall(String val) throws InterruptedException {
        Select sel3 = new Select(driver.findElement(
                By.xpath("//span[text()='Do you want to transfer the call?']/following::select[@required]")));
        sel3.selectByVisibleText(val);
        Thread.sleep(200);
    }

  //Author : Kalam
    // Do you want to raise a task to the Central Retention Team ?
    public void SelectTasktoCentralRetentionTeam(String val) throws InterruptedException {
        Thread.sleep(1000);
        visibleText(By.xpath("//span[text()='Do you want to raise a task to the Central Retention Team ?']"));
        Select sel3 = new Select(driver.findElement(By.xpath(
                "//span[text()='Do you want to raise a task to the Central Retention Team ?']/following::select[@required]")));
        sel3.selectByVisibleText(val);
        Thread.sleep(200);
    }

  //Author : Kalam
    // Task Name assigned to
    public String CaptureTaskNameAssignedAccount() throws InterruptedException {
        visibleText(By.xpath("//span[text()='Task Information']"));
        return driver.findElement(By.xpath("//div[text()='Task']/following::span[text()='Name']/following::a"))
                .getText();
    }

  //Author : Kalam
    // Task Detail creation
    public String CaptureTaskDetailCreation() throws InterruptedException {
        return driver.findElement(By.xpath("//div[text()='Task']/following::span[text()='Task Detail']/following::a"))
                .getText();
    }	

  //Author : Kalam
    public void jsClick(WebElement el) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].click();", el);
            System.out.println("Element clicked");
        } catch (Exception e) {
            System.out.println("=============================================================");
            System.out.println("Exception-jsClick(): " + e.getMessage());
            // takeScreenShot();
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }

  //Author : Kalam
    public boolean visibleText(By element) {
        WebDriverWait wait = new WebDriverWait(driver, 10000);

        wait.ignoring(StaleElementReferenceException.class)
                .until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));

        System.out.println("Element is visible");
        return false;
    }

  //Author : Kalam
    public void clickButton(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, 10000);

        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));

        System.out.println("Element is clickable");
        element.click();
    }

  //Author : Kalam
    public void retryForDetachedFrame(final WebDriver driver, final String elementXpath, final int frameId)
            throws Exception {
        int webDriverExceptionCounter = 0;
        while (webDriverExceptionCounter < 5) {
            try {
                driver.findElement(By.xpath(elementXpath));
                break;
            } catch (final WebDriverException ex) {
                webDriverExceptionCounter++;
                if (webDriverExceptionCounter == 5) {
                    // log.error("WebDriverException, not trying again: {}",
                    // webDriverExceptionCounter);
                    throw ex;
                } else {
                    // log.info("WebDriverException, retrying: {}", webDriverExceptionCounter);
                    Thread.sleep(500);
                    final WebDriverWait wait = new WebDriverWait(driver, 15);
                    wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameId));
                }
            } catch (final Exception e) {
                // log.error("Exception: {}", e.getClass());
                throw e;
            }
        }
    }
    //**************************************************Manish Methods*****************************************************
    
 // Author : Manish
    public void switchToFrame() throws Exception {
        retryForDetachedFrame(driver, "//iframe", 0);
        WebElement frame1 = driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
        Thread.sleep(800);
        driver.switchTo().frame(frame1);
        Thread.sleep(1200);
    }
    
    
    // Name
    // Author ::Manish
    public void EnterName2(String val) throws Exception {
        retryForDetachedFrame(driver, "//iframe", 0);
        WebElement frame1 = driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
        Thread.sleep(800);
        driver.switchTo().frame(frame1);
        Thread.sleep(1200);
       // visibleText(By.xpath("//span[text()='Inbound Enquiry on CST']"));
        driver.findElement(By.xpath("//label[text()='Name']/following::input")).sendKeys(val);
        Thread.sleep(200);
    }
    
  //Author : Manish
    //This method returns success message 
     public String getMessage() {
         String msg = "";

         try {

             msg = driver
                     .findElement(By.xpath(
                             "//span[text()='Task has been completed successfully. Click Next to close the window.']"))
                     .getText();
         } catch (Exception E) {
             E.getStackTrace();
         }
         return msg;
     }
     
  // Author : Manish
     public String getName() throws InterruptedException {
         Thread.sleep(1000);
         return driver.findElement(By.xpath("//label[text()='Name']/following::input")).getAttribute("value");

     }

     // Author : Manish
     public String getCity() {
         return driver.findElement(By.xpath("//label[text()='City']/following::input")).getAttribute("value");

     }

     // Author : Manish
     public String getLanguage() {
         return driver.findElement(By.xpath("//label[text()='Language']/following::button/span")).getText();

     }

     // Author : Manish
     public String reasonForCall() {
         return driver.findElement(By.xpath("//label[text()='Reason For Call']/following::button/span")).getText();
     }

     // Author : Manish
     public String getGrade() {
         return driver.findElement(By.xpath("//label[text()='Grade']/following::button/span")).getText();
     }

     // Author : Manish
     public String getCourse() {
         return driver.findElement(By.xpath("//label[text()='Course']/following::button/span")).getText();
     }
     
   //Author : Manish
     public WebElement textFieldMobileNumber()
     {
         return  driver.findElement(By.xpath("//input[@placeholder='Enter mobile number']"));
     }


  // Author : Manish
  //Switch to OXMS frame   
     public void switchToOXMSFrame() throws Exception {
         retryForDetachedFrame(driver, "//iframe", 0);
         WebElement frame1 = driver.findElement(By.xpath("//iframe[@src='https://dev.byjusorders.com/customers/leads']"));
         Thread.sleep(800);
         driver.switchTo().frame(frame1);
         Thread.sleep(1200);
     }
     
     //**************************************************Manali Methods*****************************************************
     //**************************************************Anil Methods*******************************************************
     //**************************************************Amit Methods*******************************************************
     //**************************************************Sumit Methods******************************************************
     
     public void LSName() {
         
         String Name= driver.findElement(By.xpath("//label[text()='Enquiry Type']")).getText();
         System.out.println(Name);
        
       
     }
     //**************************************************Bhavana Methods****************************************************
   //**************************************************Saurabh Methods****************************************************
}
