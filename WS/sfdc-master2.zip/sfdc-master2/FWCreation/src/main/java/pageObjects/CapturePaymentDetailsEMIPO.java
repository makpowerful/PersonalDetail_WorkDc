package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


import resources.base;

public class CapturePaymentDetailsEMIPO extends base {
	WebDriver driver;
	int counter=0;
	private String btnNextxpath= "//button[text()='Next']";
	private String lblAmtPaidbyCusxpath= "//label[text()='Amount Paid By Customer']/following::input";
	private String btnListboxMovexpath = "//button[@title='Move selection to Selected']";
	private String txtPayRefxpath = "//label[text()='Payment Reference']/following::input";
	private String ddCollectionChnnelxpath = "//label[text()='Collection Channel']/following::button";
	private String lblErrorMessxpath = "//div[@class='slds-text-color_error']";
	private String ddNoEMICollxpath = "//select[@name='No_Of_EMI_Collected']";
	private String ddTOCollAPxpath = "//select[@name='Type_Of_Collection_alreadyPaid']";
	private String ddEligfrRefxpath = "//select[@name='Eligible_For_Refund']";


	// Declaring Constructor
	public CapturePaymentDetailsEMIPO(WebDriver driver) {
		this.driver = driver;
	}
	
	//**************************************************Kalam Methods******************************************************
  
	//public WebElement PRerror1= driver.findElement(By.xpath("//div[@class='slds-text-color_error']"));
	
	//@Author : Kalam
	//Providing Rating to the user
	public void EnterRating(String val) throws Exception {
	retryForDetachedFrame(driver, "//iframe", 0);
	WebElement frame1=driver.findElement(By.xpath("//iframe[@title='accessibility title']"));
	Thread.sleep(800);
	driver.switchTo().frame(frame1);
	
	visibleText(By.xpath("//span[text()='Customer Rating Service']"));
	driver.findElement(By.xpath("//label[text()='"+val+"']")).click();
	Thread.sleep(1000);
	}
	
	//@Author : Kalam
	//Click next to submit customer rating
	public void ClickNext() throws InterruptedException {
	driver.findElement(By.xpath(btnNextxpath)).click();
	Thread.sleep(1500);
	}
	
	//@Author : Kalam
	//Select Payment Option
	public void SelectPaymntOptn(String val) throws InterruptedException {
	driver.findElement(By.xpath("//span[text()='"+val+"']")).click();
	Thread.sleep(1000);
	}
	
	//@Author : Kalam
	//Enter Amount Paid By Customer
	public void EnterAmtpaid(String val) throws InterruptedException {
		driver.findElement(By.xpath(lblAmtPaidbyCusxpath)).clear();
	driver.findElement(By.xpath(lblAmtPaidbyCusxpath)).sendKeys(val);
	Thread.sleep(800);
	}
	
	//@Author : Kalam
	//Enter Payment method
	public void SelectPaymentMethod(String val) throws InterruptedException {
	driver.findElement(By.xpath("//ul[@role='listbox']/li/div[@data-value='"+val+"']")).click();
	Thread.sleep(1000);
	driver.findElement(By.xpath(btnListboxMovexpath)).click();
	Thread.sleep(800);
	}
	

	//@Author : Kalam
	//Repeated Payment reference for validation UAT
	public void EnterDupPaymentRef() throws InterruptedException {
	driver.findElement(By.xpath(txtPayRefxpath)).sendKeys("BTR7910");
	Thread.sleep(800);
	}
	
	//@Author : Kalam
	//Select the Collection Channel value
	public void SelectCollectionchannel(String val) throws InterruptedException {
	driver.findElement(By.xpath(ddCollectionChnnelxpath)).click();
	Thread.sleep(800);
	WebElement a6=driver.findElement(By.xpath("//label[text()='Collection Channel']/following::span[text()='"+val+"']"));
	scrollIntoView(a6);
	jsClick(a6);
	}
	
	//@Author : Kalam
	//Cepture the Error message
	public String CaptureErrorMess() throws InterruptedException {
	String PRerror= driver.findElement(By.xpath(lblErrorMessxpath)).getText();
	Thread.sleep(300);
	return PRerror;
	}
	
	
	//@Author : Kalam
	//Enter Payment Reference value
	public void EnterPaymntRefVal(int randomNum) throws InterruptedException {
	driver.findElement(By.xpath(txtPayRefxpath)).clear();
	Thread.sleep(200);
	driver.findElement(By.xpath(txtPayRefxpath)).sendKeys("BTR1"+randomNum+counter);
	Thread.sleep(800);
	counter++;
	}
	
	//@Author : Kalam
	//Select Value for No of EMI collected
	public void SelectEMIcoll(String val) throws InterruptedException {
	Select sel = new Select(driver.findElement(By.xpath(ddNoEMICollxpath)));
	sel.selectByVisibleText(val);
	Thread.sleep(800);
	}
	
	//@Author : Kalam
	//Select Value for Type of collection already paid
	public void SelectTypofCollPaid(String val) {
	Select sel1 = new Select(driver.findElement(By.xpath(ddTOCollAPxpath)));
	sel1.selectByVisibleText(val);
	}
	
	
	//@Author : Kalam
	//Select value for Eligible for refund
	public void SelectElgfrRef(String val) {
	Select sel2 = new Select(driver.findElement(By.xpath(ddEligfrRefxpath)));
	sel2.selectByVisibleText(val);
	}
	
	
	//@Author : Kalam
	// Scroll element to view
	public void scrollIntoView(WebElement element) {
		try {
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("arguments[0].scrollIntoView(true);", element);
			System.out.println("Page scrolled down");
		} catch (Exception e){
			System.out.println("=============================================================");
			System.out.println("Exception-scrollIntoView(): "+e.getMessage());
			takeScreenShot();
			e.printStackTrace();
			System.out.println("=============================================================");
		}    
	}
	

	//@Author : Kalam
	public boolean visibleText(By element)
	{
		WebDriverWait wait= new WebDriverWait(driver, 100);
		
		wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));
		
		System.out.println("Element is visible");
		return false;
	}

	 //**************************************************Manali Methods*****************************************************
	//Select Payment Option @manali shivareddy
		public String verifyPaymntOptn(String val1) throws InterruptedException {
		String paymentOption=driver.findElement(By.xpath("//span[text()='"+val1+"']")).getText();
		return paymentOption;		
		}
		
		//Get 'Amount Paid By Customer' default value @manali shivareddy
		public String getAmtpaid() throws InterruptedException {
		Thread.sleep(2000);
		String val=driver.findElement(By.xpath(lblAmtPaidbyCusxpath)).getAttribute("value");
		Thread.sleep(800);
		return val;
		}
		
		// Pass the text @manali shivareddy
		public String errorMsg() {
		    String error="Audit Cases are found with the same Payment Reference.Kindly provide the different Payment Reference Id";
		    return error;
		}
		 
	    //**************************************************Manish Methods*****************************************************
	    //**************************************************Anil Methods*******************************************************
	    //**************************************************Amit Methods*******************************************************
	    //**************************************************Sumit Methods******************************************************
	    //**************************************************Bhavana Methods****************************************************
		
		//@Author : Bhavana
		//Navigate to iframe
		public void navToiframe(String title ) throws Exception
		{
		    retryForDetachedFrame(driver, "//iframe", 0);
		    WebElement frame1=driver.findElement(By.xpath("//iframe[@title='"+title+"']"));
		    Thread.sleep(800);
		    driver.switchTo().frame(frame1);
		}
	
		//@Author : Bhavana
        //To get the collection channel
		public String getCollchannel(String val) throws InterruptedException
		{
		    Thread.sleep(1000);
		    jsClick(driver.findElement(By.xpath("//div/button[@name='Collection_Channel']")));
	        String channel = driver.findElement(By.xpath("//lightning-base-combobox-item/span/span[@title = '"+val+"']")).getText();
	        Thread.sleep(800);
	        return channel;
		}
		
		//@Author : Bhavana
	    //Clicking an element
	    public void jsClick(WebElement el) {
	        try {
	            JavascriptExecutor jse = (JavascriptExecutor)driver;
	            jse.executeScript("arguments[0].click();", el);
	            System.out.println("Element clicked");
	        } catch (Exception e){
	            System.out.println("=============================================================");
	            System.out.println("Exception-jsClick(): "+e.getMessage());
	            takeScreenShot();
	            e.printStackTrace();
	            System.out.println("=============================================================");
	        }
	    }
		
	    
	  //@Author : Bhavana
	    //Enter given Payment Reference value
	    public void EntergivenPayRef(String val) throws InterruptedException {
	    driver.findElement(By.xpath(txtPayRefxpath)).clear();
	    Thread.sleep(200);
	    driver.findElement(By.xpath(txtPayRefxpath)).sendKeys(val);
	    Thread.sleep(800);
	    counter++;
	    }
	    
		//**************************************************Saurabh Methods****************************************************
}
