package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import resources.base;

public class UserDetailPO extends base{
	WebDriver driver;

	private String btnUserDetailxpath = "//div[text()='User Detail']";
	
	// Declaring Constructor
	public UserDetailPO(WebDriver driver) {
		this.driver = driver;
	}

	//**************************************************Kalam Methods******************************************************

	
	//Author : Kalam
	//Clicking on User Detail Button
	public void ClickUserDetailbutton() throws InterruptedException {
		//visibleText(By.xpath("//div[text()='User Detail']"));
	    try {
	        jsClick(driver.findElement(By.xpath(btnUserDetailxpath)));
	    }
	    catch(Exception e) {
	        clickButton(driver.findElement(By.xpath(btnUserDetailxpath)));
	    }
		jsClick(driver.findElement(By.xpath(btnUserDetailxpath)));
		Thread.sleep(5000);
	}

	//Author : Kalam
	//Clicking on User Detail Button
	public void ClickUserDetailbtn(String val) throws InterruptedException {
		//visibleText(By.xpath("//div[text()='User Detail']"));
		clickButton(driver.findElement(By.xpath("//span[text()='"+val+"']/following::div[text()='User Detail'][2]")));
		jsClick(driver.findElement(By.xpath("//span[text()='"+val+"']/following::div[text()='User Detail'][2]")));
		Thread.sleep(5000);
	}
	
	//Author : Kalam
	//Logout code
	public void Logout() throws InterruptedException {
		
		driver.findElement(By.xpath("//span[@class='uiImage']")).click();
		Thread.sleep(1200);
		driver.findElement(By.xpath("//a[text()='Log Out']")).click();
		Thread.sleep(1500);
		
	}
	
	//Author : Kalam
	//Capture Profile
	public String CaptureProfile() throws InterruptedException {
	String Profile= driver.findElement(By.xpath("//span[text()='Details']/following::span[text()='Profile']/following::a")).getText();
	        return Profile;
	}
	
	//Author : Kalam
	//Capture the Manager value
	public String CaptureManager() throws InterruptedException {
		String Manager= driver.findElement(By.xpath("//span[text()='Manager']/following::a")).getText();
		return Manager;
	}
	
	//Author : Kalam
	public void clickButton(WebElement element)
	{
		WebDriverWait wait= new WebDriverWait(driver, 10000);
		
		wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));
		
		System.out.println("Element is clickable");
		element.click();
	}
	
	//Author : Kalam
	public boolean visibleText(By element)
	{
		WebDriverWait wait= new WebDriverWait(driver, 10000);
		
		wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));
		
		System.out.println("Element is visible");
		return false;
	}
	
	//Author : Kalam
    public void jsClick(WebElement el) {
		try {
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("arguments[0].click();", el);
			System.out.println("Element clicked");
		} catch (Exception e){
			System.out.println("=============================================================");
			System.out.println("Exception-jsClick(): "+e.getMessage());
			takeScreenShot();
			e.printStackTrace();
			System.out.println("=============================================================");
		}
	}
    
    //**************************************************Manali Methods*****************************************************
    //**************************************************Manish Methods*****************************************************
    //**************************************************Anil Methods*******************************************************
    //**************************************************Amit Methods*******************************************************
    //**************************************************Sumit Methods******************************************************
    //**************************************************Bhavana Methods****************************************************
    //**************************************************Saurabh Methods****************************************************
}
