package payLoad;
import static io.restassured.RestAssured.given;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.commons.lang.time.DateUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.github.javafaker.Faker;

import io.restassured.path.json.JsonPath;
import resources.Utils;


public class payLoad_SinglePrgm_Revamp_K4_10{
	
	public static Logger log = LogManager.getLogger(payLoad_SinglePrgm_Revamp_K4_10.class.getName());
	static Faker faker = new Faker();
	static int randomNum = ThreadLocalRandom.current().nextInt(1000, 10000 + 1);
	static String firstName = faker.name().firstName().replaceAll("'","");
	static String lastName = faker.name().lastName().replaceAll("'","");
	static String parentName = faker.name().fullName().replaceAll("'","");
	static String Auto="Dummy ";
	static long Premiumid= 58514495345L+randomNum;
	static int counter=1;
	
	public static String bodycontent_K4_10(String classNo,String Mentlang,String ProgId,String Duration, String ProdType,String TrialProg,String ProgType) {
        //Add "+Premiumid+""+counter+" to Premium Id and "+randomNum+" to Student Enrollment Id
        //Add "+Auto+ ""+firstName+" to FirstName
        //Add "+lastName+" to LastName
        //Add "+parentName+" to ParentName
        
        Date date = DateUtils.addDays(new Date(), -7);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        //driver.findElement(By.xpath("//label[text()='Due Date']/following::input")).sendKeys(sdf.format(date));
        
        String bodycontent = "{\n"
                + "  \"allOrNone\": true,\n"
                + "  \"compositeRequest\": [\n"
                + "    {\n"
                + "      \"method\": \"PATCH\",\n"
                + "      \"url\": \"/services/data/v53.0/sobjects/Account/Premium_ID__c/"+Premiumid+""+counter+"\",\n"
                + "      \"referenceId\": \"RefStudent"+Premiumid+""+counter+"\",\n"
                + "      \"body\": {\n"
                + "        \"FirstName\": \""+Auto+""+firstName+"\",\n"
                + "        \"LastName\": \""+lastName+"\",\n"
                + "        \"Sub_Status__c\": \"\",\n"
                + "        \"Current_Class__c\": \""+classNo+"\",\n"
                + "        \"BillingState\": \"Telangana (TS)\",\n"
                + "        \"Expiry_date__c\": \"2027-08-09\",\n"
                + "        \"Manager__c\": \"\",\n"
                + "        \"Lead_Category__c\": \"Non-EMI\",\n"
                + "        \"Type_Of_Student__c\": \"\",\n"
                + "        \"Student_Type__c\": \"\",\n"
                + "        \"Parent_Name__c\": \""+parentName+"\",\n"
                + "        \"PersonEmail\": \"automation"+Premiumid+""+counter+"@user.com\",\n"
                + "        \"Phone\": \"9876543210\",\n"
                + "        \"Student_Email_ID__c\": \"automation"+Premiumid+""+counter+"@user.com\",\n"
                + "        \"Created_On__c\": \"2020-07-03\",\n"
                + "        \"BillingStreet\": \"133\",\n"
                + "        \"BillingCountry\": \"India\",\n"
                + "        \"BillingCity\": \"Bengaluru\",\n"
                + "        \"BillingPostalCode\": \"\",\n"
                + "        \"ShippingStreet\": \"2212 18th main road\",\n"
                + "        \"ShippingState\": \"Karnataka (KA)\",\n"
                + "        \"ShippingCountry\": \"India\",\n"
                + "        \"ShippingCity\": \"Bengaluru\",\n"
                + "        \"ShippingPostalCode\": \"560008\",\n"
                + "        \"Parent_App_Code__c\": \"BS-1234\",\n"
                + "        \"Session_1_Date__c\": \"2020-06-21\",\n"
                + "        \"Shipped_Activity_Date__c\": \"2020-05-21\",\n"
                + "        \"Order_Punched_By__c\": \"Byju Admin\",\n"
                + "        \"E_Score__c\": \"\",\n"
                + "        \"Version__c\": \"V1.2.1\",\n"
                + "        \"High_Priority_PE_Date__c\": \"2020-05-14\",\n"
                + "        \"Date_of_Birth__c\": \"1995-09-07\",\n"
                + "        \"Last_online_time__c\": \"12:20 am\",\n"
                + "        \"Back_End_Dashboard__c\": \"https://www.byju.com/resources/dashboard-examples\",\n"
                + "        \"WhatsApp_OPTOUT__c\": true,\n"
                + "        \"Creation_Agent__c\": \"Test Agent 11\",\n"
                + "        \"Transfer_type__c\": \"\",\n"
                + "        \"Notes__c\": \"24 test note\",\n"
                + "        \"Region__c\" : \"India\",\n"
                + "        \"Mentoring_Language__c\" : \""+Mentlang+"\"\n"
                + "      }\n"
                + "    },\n"
                + "    {\n"
                + "      \"method\": \"PATCH\",\n"
                + "      \"url\": \"/services/data/v53.0/sobjects/Student_Sales_Order__c/Sales_Order_No__c/STUSALORD"+Premiumid+""+counter+"\",\n"
                + "      \"referenceId\": \"RefSTUSALORD"+Premiumid+""+counter+"\",\n"
                + "      \"body\": {\n"
                + "        \"Name\": \"Order : K12 course-1st Order\",\n"
                + "        \"Course_Name__c\": \"9th Physics\",\n"
                + "        \"Order_Start_Date__c\": \"2020-05-11\",\n"
                + "        \"Board__c\": \"ICSE\",\n"
                + "        \"Order_Product_name__c\": \"9th CBSE (SD Card-Byjus) May-2022;10th CBSE (SD Card-Byjus) May-2023\",\n"
                + "        \"Books__c\": \"Book 1;Book 2\",\n"
                + "        \"Active_AWB_Number__c\": \"AWB-1236\",\n"
                + "        \"Active_Order_Delivery_Date__c\": \"2020-05-17\",\n"
                + "        \"K3_Validity_End_Date__c\": \"2020-06-19\",\n"
                + "        \"Active_Order_Value__c\": \"45000\",\n"
                + "        \"Status__c\": \"Punched\",\n"
                + "        \"OMS_Order_Status__c\": \"Punched\",\n"
                + "        \"Active_Order_Shipped_Date__c\": \"2020-06-19\",\n"
                + "        \"K12_Validity_End_Date__c\": \"2020-06-19\",\n"
                + "        \"Order_Type__c\": \"Fresh order\"\n"
                + "      }\n"
                + "    },\n"
                + "    {\n"
                + "      \"method\": \"PATCH\",\n"
                + "      \"url\": \"/services/data/v53.0/composite/sobjects/Order__c/Order_No__c\",\n"
                + "      \"referenceId\": \"orderList\",\n"
                + "      \"body\": {\n"
                + "        \"allOrNone\": true,\n"
                + "        \"records\": [\n"
                + "          {\n"
                + "            \"attributes\": {\n"
                + "              \"type\": \"Order__c\",\n"
                + "              \"referenceId\": \"order1\"\n"
                + "            },\n"
                + "            \"Order_No__c\": \"STUSUBORD1"+Premiumid+""+counter+"\",\n"
                + "            \"Name\": \"Order : K12 course-1st Order\",\n"
                + "            \"Course_Name__c\": \"9th Physics\",\n"
                + "            \"Order_Start_Date__c\": \"2020-05-11\",\n"
                + "            \"Board__c\": \"ICSE\",\n"
                + "            \"Order_Product_name__c\": \"9th CBSE (SD Card-Byjus) May-2022\",\n"
                + "            \"Books__c\": \"Book 1;Book 2\",\n"
                + "            \"Active_AWB_Number__c\": \"AWB-1236\",\n"
                + "            \"Active_Order_Delivery_Date__c\": \"2020-05-17\",\n"
                + "            \"K3_Validity_End_Date__c\": \"2020-06-19\",\n"
                + "            \"Active_Order_Value__c\": \"45000\",\n"
                + "            \"Status__c\": \"Punched\",\n"
                + "            \"OMS_Order_Status__c\": \"Punched\",\n"
                + "            \"Active_Order_Shipped_Date__c\": \"2020-06-19\",\n"
                + "            \"K12_Validity_End_Date__c\": \"2020-06-19\",\n"
                + "            \"Order_Type__c\": \"Fresh order\",\n"
                + "            \"Student_Sales_Order__r\": {\n"
                + "              \"Sales_Order_No__c\": \"STUSALORD"+Premiumid+""+counter+"\"\n"
                + "            }\n"
                + "          },\n"
                + "          {\n"
                + "            \"attributes\": {\n"
                + "              \"type\": \"Order__c\",\n"
                + "              \"referenceId\": \"order2\"\n"
                + "            },\n"
                + "            \"Order_No__c\": \"STUSUBORD2"+Premiumid+""+counter+"\",\n"
                + "            \"Name\": \"Order : K12 course-2nd Order\",\n"
                + "            \"Course_Name__c\": \"9th Math\",\n"
                + "            \"Order_Start_Date__c\": \"2020-05-11\",\n"
                + "            \"Board__c\": \"ICSE\",\n"
                + "            \"Order_Product_name__c\": \"10th CBSE (SD Card-Byjus) May-2023\",\n"
                + "            \"Books__c\": \"Book 1;Book 2\",\n"
                + "            \"Active_AWB_Number__c\": \"AWB-1236\",\n"
                + "            \"Active_Order_Delivery_Date__c\": \"2020-05-17\",\n"
                + "            \"K3_Validity_End_Date__c\": \"2020-06-19\",\n"
                + "            \"Active_Order_Value__c\": \"20000\",\n"
                + "            \"Status__c\": \"Punched\",\n"
                + "            \"OMS_Order_Status__c\": \"Punched\",\n"
                + "            \"Active_Order_Shipped_Date__c\": \"2020-06-19\",\n"
                + "            \"K12_Validity_End_Date__c\": \"2020-06-19\",\n"
                + "            \"Order_Type__c\": \"Fresh order\",\n"
                + "            \"Student_Sales_Order__r\": {\n"
                + "              \"Sales_Order_No__c\": \"STUSALORD"+Premiumid+""+counter+"\"\n"
                + "            }\n"
                + "          }\n"
                + "        ]\n"
                + "      }\n"
                + "    },\n"
                + "    {\n"
                + "      \"method\": \"PATCH\",\n"
                + "      \"url\": \"/services/data/v53.0/composite/sobjects/Payment__c/Payment_Reference_ID__c\",\n"
                + "      \"referenceId\": \"paymentList\",\n"
                + "      \"body\": {\n"
                + "        \"allOrNone\": true,\n"
                + "        \"records\": [\n"
                + "          {\n"
                + "            \"attributes\": {\n"
                + "              \"type\": \"Payment__c\",\n"
                + "              \"referenceId\": \"payment1\"\n"
                + "            },\n"
                + "            \"Payment_Reference_ID__c\": \"PAY1"+Premiumid+""+counter+"\",\n"
                + "            \"Payment_Amount__c\": \"4500\",\n"
                + "            \"Payment_Type__c\": \"EMI\",\n"
                + "            \"Payment_Category__c\": \"Down payment\",\n"
                + "            \"Payment_Method__c\": \"PayU\",\n"
                + "            \"Payment_Date__c\": \"2020-05-21\",\n"
                + "            \"Tenurity__c\": \"\",\n"
                + "            \"Estimated_Monthly_EMI__c\": \"\",\n"
                + "            \"Loan_Reference_Id__c\": \"LoanPay1"+Premiumid+""+counter+"\",\n"
                + "            \"Order__r\": {\n"
                + "              \"Order_No__c\": \"STUSUBORD1"+Premiumid+""+counter+"\"\n"
                + "            },\n"
                + "            \"Student_Sales_Order__r\": {\n"
                + "              \"Sales_Order_No__c\": \"STUSALORD"+Premiumid+""+counter+"\"\n"
                + "            }\n"
                + "          },\n"
                + "          {\n"
                + "            \"attributes\": {\n"
                + "              \"type\": \"Payment__c\",\n"
                + "              \"referenceId\": \"payment2\"\n"
                + "            },\n"
                + "            \"Payment_Reference_ID__c\": \"PAY2"+Premiumid+""+counter+"\",\n"
                + "            \"Payment_Amount__c\": \"40500\",\n"
                + "            \"Payment_Type__c\": \"EMI\",\n"
                + "            \"Payment_Category__c\": \"Loan\",\n"
                + "            \"Payment_Method__c\": \"IIFL\",\n"
                + "            \"Payment_Date__c\": \"2020-05-21\",\n"
                + "            \"Tenurity__c\": \"12\",\n"
                + "            \"Estimated_Monthly_EMI__c\": \"3375\",\n"
                + "            \"Loan_Reference_Id__c\": \"LoanPay2"+Premiumid+""+counter+"\",\n"
                + "            \"Order__r\": {\n"
                + "              \"Order_No__c\": \"STUSUBORD1"+Premiumid+""+counter+"\"\n"
                + "            },\n"
                + "            \"Student_Sales_Order__r\": {\n"
                + "              \"Sales_Order_No__c\": \"STUSALORD"+Premiumid+""+counter+"\"\n"
                + "            }\n"
                + "          }\n"
                + "        ]\n"
                + "      }\n"
                + "    },\n"
                + "    {\n"
                + "      \"method\": \"PATCH\",\n"
                + "      \"url\": \"/services/data/v53.0/sobjects/Student_Program__c/Student_Enrolment_ID__c/"+Premiumid+""+counter+"\",\n"
                + "      \"referenceId\": \"STUPRGM10010621\",\n"
                + "      \"body\": {\n"
                + "        \"Student_Sales_Order__c\": \"@{RefSTUSALORD"+Premiumid+""+counter+".id}\",\n"
                + "        \"Order__c\": \"@{orderList[1].id}\",\n"
                + "        \"Student__c\": \"@{RefStudent"+Premiumid+""+counter+".id}\",\n"
                + "        \"Program__r\": {\n"
                + "          \"Program_ID__c\": \""+ProgId+"\"\n"
                + "        },\n"
                + "        \"Status__c\": \"Active\",\n"
                + "        \"Start_Date__c\": \"2023-01-06\",\n"
                + "        \"Program_Type__c\": \"Regular\",\n"
                + "        \"Duration__c\": \""+Duration+"\",\n"
                + "        \"Product_Type__c\": \""+ProdType+"\",\n"
                + "        \"Trial_Program__c\": \""+TrialProg+"\",\n"
                + "        \"Class_Program_Type__c\": \""+ProgType+"\"\n"
                + "    }},\n"
                + "    {\n"
                + "      \"method\": \"PATCH\",\n"
                + "      \"url\": \"/services/data/v53.0/composite/sobjects/Student_Orders__c/Reference_Id__c\",\n"
                + "      \"referenceId\": \"studentOrderList\",\n"
                + "      \"body\": {\n"
                + "        \"allOrNone\": true,\n"
                + "        \"records\": [\n"
                + "          {\n"
                + "            \"attributes\": {\n"
                + "              \"type\": \"Student_Orders__c\",\n"
                + "              \"referenceId\": \"studentOrder1\"\n"
                + "            },\n"
                + "            \"Name\": \"Student Order : "+Premiumid+""+counter+" 1\",\n"
                + "            \"Order__c\": \"@{orderList[0].id}\",\n"
                + "            \"Student__c\": \"@{RefStudent"+Premiumid+""+counter+".id}\",\n"
                + "            \"Reference_Id__c\": \"@{orderList[0].id}-@{RefStudent"+Premiumid+""+counter+".id}\"\n"
                + "          },\n"
                + "          {\n"
                + "            \"attributes\": {\n"
                + "              \"type\": \"Student_Orders__c\",\n"
                + "              \"referenceId\": \"studentOrder2\"\n"
                + "            },\n"
                + "            \"Name\": \"Student Order : "+Premiumid+""+counter+" 2\",\n"
                + "            \"Order__c\": \"@{orderList[1].id}\",\n"
                + "            \"Student__c\": \"@{RefStudent"+Premiumid+""+counter+".id}\",\n"
                + "            \"Reference_Id__c\": \"@{orderList[1].id}-@{RefStudent"+Premiumid+""+counter+".id}\"\n"
                + "          }\n"
                + "        ]\n"
                + "      }\n"
                + "    },\n"
                + "    {\n"
                + "      \"method\": \"PATCH\",\n"
                + "      \"url\": \"/services/data/v53.0/composite/sobjects/Student_Payment__c/SPayment_Reference_ID__c\",\n"
                + "      \"referenceId\": \"RefPaymentPD1"+Premiumid+""+counter+"\",\n"
                + "      \"body\": {\n"
                + "        \"allOrNone\": true,\n"
                + "        \"records\": [\n"
                + "          {\n"
                + "            \"attributes\": {\n"
                + "              \"type\": \"Student_Payment__c\"\n"
                + "            },\n"
                + "            \"Payment__c\": \"@{paymentList[0].id}\",\n"
                + "            \"Student__c\": \"@{RefStudent"+Premiumid+""+counter+".id}\",\n"
                + "            \"SPayment_Reference_ID__c\": \"@{paymentList[0].id}_@{RefStudent"+Premiumid+""+counter+".id}\"\n"
                + "          },\n"
                + "          {\n"
                + "            \"attributes\": {\n"
                + "              \"type\": \"Student_Payment__c\"\n"
                + "            },\n"
                + "            \"Payment__c\": \"@{paymentList[1].id}\",\n"
                + "            \"Student__c\": \"@{RefStudent"+Premiumid+""+counter+".id}\",\n"
                + "            \"SPayment_Reference_ID__c\":\"@{paymentList[1].id}_@{RefStudent"+Premiumid+""+counter+".id}\"\n"
                + "          }\n"
                + "        ]\n"
                + "      }\n"
                + "    },\n"
                + "    {\n"
                + "      \"method\": \"PATCH\",\n"
                + "      \"url\": \"/services/data/v53.0/sobjects/Student_Shipping_Order__c/Order_Number__c/"+Premiumid+""+counter+"\",\n"
                + "      \"referenceId\": \"SHO100110\",\n"
                + "      \"body\": {\n"
                + "        \"Name\": \"Test39112221\",\n"
                + "        \"Student_Sub_Orders__c\": \"@{orderList[1].id}\",\n"
                + "        \"Student__r\": {\n"
                + "          \"Premium_ID__c\": \""+Premiumid+""+counter+"\"\n"
                + "        },\n"
                + "        \"Active_AWB_Number__c\": \"2322\",\n"
                + "        \"Order_Status__c\": \"Punched\",\n"
                + "        \"Created_At__c\": \"2022-09-23\",\n"
                + "        \"Category__c\": \"CSO_FOC\",\n"
                + "        \"Subtype__c\": \"Books\",\n"
                + "        \"SD_Card_Tablet__c\": \"SD Card\",\n"
                + "        \"Order_Delivery_Date__c\": \"2022-09-30\"\n"
                + "      }\n"
                + "    }\n"
                + "  ]\n"
                + "}";
        counter++;
        return bodycontent;
    }
	
	public static String AccountCreationResponse_UAT(String classNo,String Mentlang,String ProgId,String Duration,String ProdType,String TrialProg ,String ProgType) {
        String val = "OAuth ";
        String StudentCreation="";
        StudentCreation = given().header("Authorization", val + Utils.Access_Token())
                .header("Content-Type", "application/json").body(bodycontent_K4_10(classNo,Mentlang, ProgId, Duration, ProdType, TrialProg, ProgType)).when()
                .post("https://byjusprod--byjusuat.my.salesforce.com/services/data/v53.0/composite").then().log().all()
                .extract().response().asString();
        log.info("The response is: "+StudentCreation);
        return StudentCreation;

    }
    
    public static String AccountCreationResponse_Prod(String classNo,String Mentlang,String ProgId,String Duration,String ProdType,String TrialProg ,String ProgType) {
        String val = "OAuth ";
        String StudentCreation="";
        StudentCreation = given().header("Authorization", val + Utils.Access_TokenProd())
                .header("Content-Type", "application/json").body(bodycontent_K4_10(classNo,Mentlang, ProgId, Duration, ProdType, TrialProg, ProgType)).when()
                .post("https://byjusprod.my.salesforce.com/services/data/v52.0/composite").then().log().all()
                .extract().response().asString();
        log.info("The response is: "+StudentCreation);
        return StudentCreation;

    }
    
    public static String AccountidCreationResponse_UAT(String classNo,String Mentlang,String ProgId,String Duration,String ProdType,String TrialProg, String ProgType) {

        String id="";
        JsonPath js1 = new JsonPath(AccountCreationResponse_UAT(classNo,Mentlang, ProgId, Duration, ProdType, TrialProg, ProgType));
        id = js1.get("compositeResponse[0].body.id");
        System.out.println("The value of id is: " + id);
        return id;

    }
    
    public static String AccountidCreationResponse_Prod(String classNo,String Mentlang,String ProgId,String Duration,String ProdType,String TrialProg, String ProgType) {

        String id="";
        JsonPath js1 = new JsonPath(AccountCreationResponse_Prod(classNo,Mentlang, ProgId, Duration, ProdType, TrialProg, ProgType));
        id = js1.get("compositeResponse[0].body.id");
        System.out.println("The value of id is: " + id);
        return id;

    }
    
    // Inserting a new program in to an existing student account 
    public static String bodycontent_K4_10_prog1(String accID,String ProgId,String duration,String ProdType,String TrialProg,String ProgType) {
        //Add "+Premiumid+""+counter+" to Premium Id and "+randomNum+" to Student Enrollment Id
        //Add "+Auto+ ""+firstName+" to FirstName
        //Add "+lastName+" to LastName
        //Add "+parentName+" to ParentName
        
        Date date = DateUtils.addDays(new Date(), -7);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        //driver.findElement(By.xpath("//label[text()='Due Date']/following::input")).sendKeys(sdf.format(date));
        
        // 
        String bodycontent = "{\"allOrNone\": true,\n"
                + "    \"compositeRequest\": [\n"
                + "           {\n"
                + "      \"method\": \"PATCH\",\n"
                + "      \"url\": \"/services/data/v53.0/sobjects/Student_Program__c/Student_Enrolment_ID__c/"+Premiumid+""+counter+"\",\n"
                + "      \"referenceId\": \"STUPRGM"+Premiumid+""+counter+"\",\n"
                + "      \"body\": {\n"
                + "        \"Student__c\": \""+accID+"\",\n"
                + "        \"Program__r\": {\n"
                + "          \"Program_ID__c\": \""+ProgId+"\"\n"
                + "        },\n"
                + "        \"Status__c\": \"Active\",\n"
                + "        \"Start_Date__c\": \"2023-01-06\",\n"
                + "        \"Program_Type__c\": \"Regular\",\n"
                + "        \"Duration__c\": \""+duration+"\",\n"
                + "        \"Product_Type__c\": \""+ProdType+"\",\n"
                + "        \"Trial_Program__c\": \""+TrialProg+"\",\n"
                + "        \"Class_Program_Type__c\": \""+ProgType+"\"\n"
                + "      }\n"
                + "    }\n"
                + "    ]\n"
                + "}";
        counter++;
        return bodycontent;
    }
    
    public static String AccountCreationResponse_UAT1(String accID,String ProgId,String duration,String ProdType,String TrialProg,String ProgType) {
        String val = "OAuth ";
        String StudentCreation="";
        StudentCreation = given().header("Authorization", val + Utils.Access_Token())
                .header("Content-Type", "application/json").body(bodycontent_K4_10_prog1(accID, ProgId, duration, ProdType, TrialProg,ProgType)).when()
                .post("https://byjusprod--byjusuat.my.salesforce.com/services/data/v53.0/composite").then().log().all()
                .extract().response().asString();
        log.info("The response is: "+StudentCreation);
        return StudentCreation;

    }
    
    
    public static String AccountCreationResponse_Prod1(String accID,String ProgId,String duration,String ProdType,String TrialProg,String ProgType) {
        String val = "OAuth ";
        String StudentCreation="";
        StudentCreation = given().header("Authorization", val + Utils.Access_TokenProd())
                .header("Content-Type", "application/json").body(bodycontent_K4_10_prog1(accID, ProgId,duration, ProdType, TrialProg,ProgType)).when()
                .post("https://byjusprod.my.salesforce.com/services/data/v52.0/composite").then().log().all()
                .extract().response().asString();
        log.info("The response is: "+StudentCreation);
        return StudentCreation;

    }
    
    public static String AccountidCreationResponse_UAT1(String accID,String ProgId,String duration,String ProdType,String TrialProg,String ProgType) {

        String id="";
        JsonPath js1 = new JsonPath(AccountCreationResponse_UAT1(accID, ProgId,duration, ProdType, TrialProg,ProgType));
        id = js1.get("compositeResponse[0].body.id");
        System.out.println("The value of id is: " + id);
        return id;

    }
    
    public static String AccountidCreationResponse_Prod1(String accID,String ProgId,String duration,String ProdType,String TrialProg,String ProgType) {

        String id="";
        JsonPath js1 = new JsonPath(AccountCreationResponse_Prod1(accID, ProgId,duration, ProdType, TrialProg,ProgType));
        id = js1.get("compositeResponse[0].body.id");
        System.out.println("The value of id is: " + id);
        return id;

    }
    
	
}