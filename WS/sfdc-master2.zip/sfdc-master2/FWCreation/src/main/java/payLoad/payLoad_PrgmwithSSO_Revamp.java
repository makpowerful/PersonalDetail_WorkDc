package payLoad;
import static io.restassured.RestAssured.given;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.commons.lang.time.DateUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.github.javafaker.Faker;

import io.restassured.path.json.JsonPath;
import resources.Utils;


public class payLoad_PrgmwithSSO_Revamp{
	
	public static Logger log = LogManager.getLogger(payLoad_PrgmwithSSO_Revamp.class.getName());
	static Faker faker = new Faker();
	static int randomNum = ThreadLocalRandom.current().nextInt(1000, 10000 + 1);
	static String firstName = faker.name().firstName().replaceAll("'","");
	static String lastName = faker.name().lastName().replaceAll("'","");
	static String parentName = faker.name().fullName().replaceAll("'","");
	static String Auto="Dummy ";
	static long Premiumid= 58514495345L+randomNum;
	static int counter=1;
	
   
    // Inserting a new program in an existing student account - with SSO 
    public static String bodycontent_prog(String accID,String ProgId,String duration,String ProdType,String TrialProg,String ProgType) {
        //Add "+Premiumid+""+counter+" to Premium Id and "+randomNum+" to Student Enrollment Id
        //Add "+Auto+ ""+firstName+" to FirstName
        //Add "+lastName+" to LastName
        //Add "+parentName+" to ParentName
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");    
        Date date = new Date(); 
        System.out.println(sdf.format(date));

        String bodycontent = "{\"allOrNone\": true,\n"
                + "    \"compositeRequest\": [\n"
                + "    {\n"
                + "      \"method\": \"PATCH\",\n"
                + "      \"url\": \"/services/data/v53.0/sobjects/Student_Sales_Order__c/Sales_Order_No__c/STUSALORD"+Premiumid+""+counter+"\",\n"
                + "      \"referenceId\": \"RefSTUSALORD"+Premiumid+""+counter+"\",\n"
                + "      \"body\": {\n"
                + "        \"Name\": \"Order : K12 course-1st Order\",\n"
                + "        \"Course_Name__c\": \"9th Physics\",\n"
                + "        \"Order_Start_Date__c\": \"2020-05-11\",\n"
                + "        \"Board__c\": \"ICSE\",\n"
                + "        \"Order_Product_name__c\": \"9th CBSE (SD Card-Byjus) May-2022;10th CBSE (SD Card-Byjus) May-2023\",\n"
                + "        \"Books__c\": \"Book 1;Book 2\",\n"
                + "        \"Active_AWB_Number__c\": \"AWB-1236\",\n"
                + "        \"Active_Order_Delivery_Date__c\": \"2020-05-17\",\n"
                + "        \"K3_Validity_End_Date__c\": \"2020-06-19\",\n"
                + "        \"Active_Order_Value__c\": \"45000\",\n"
                + "        \"Status__c\": \"Punched\",\n"
                + "        \"OMS_Order_Status__c\": \"Punched\",\n"
                + "        \"Active_Order_Shipped_Date__c\": \"2020-06-19\",\n"
                + "        \"K12_Validity_End_Date__c\": \"2020-06-19\",\n"
                + "        \"Order_Type__c\": \"Fresh order\"\n"
                + "      }\n"
                + "    },\n"
                + "    {\n"
                + "      \"method\": \"PATCH\",\n"
                + "      \"url\": \"/services/data/v53.0/composite/sobjects/Order__c/Order_No__c\",\n"
                + "      \"referenceId\": \"orderList\",\n"
                + "      \"body\": {\n"
                + "        \"allOrNone\": true,\n"
                + "        \"records\": [\n"
                + "          {\n"
                + "            \"attributes\": {\n"
                + "              \"type\": \"Order__c\",\n"
                + "              \"referenceId\": \"order1\"\n"
                + "            },\n"
                + "            \"Order_No__c\": \"STUSUBORD1"+Premiumid+""+counter+"\",\n"
                + "            \"Name\": \"SSO1XX\",\n"
                + "            \"Type__c\": \"Parent Order\",\n"
                + "            \"Course_Name__c\": \"9th Physics\",\n"
                + "            \"Order_Start_Date__c\": \"2020-05-11\",\n"
                + "            \"Board__c\": \"ICSE\",\n"
                + "            \"Order_Product_name__c\": \"9th CBSE (SD Card-Byjus) May-2022\",\n"
                + "            \"Books__c\": \"Book 1;Book 2\",\n"
                + "            \"Active_AWB_Number__c\": \"AWB-1236\",\n"
                + "            \"Active_Order_Delivery_Date__c\": \"2020-05-17\",\n"
                + "            \"K3_Validity_End_Date__c\": \"2020-06-19\",\n"
                + "            \"Active_Order_Value__c\": \"45000\",\n"
                + "            \"Status__c\": \"Punched\",\n"
                + "            \"OMS_Order_Status__c\": \"Punched\",\n"
                + "            \"Active_Order_Shipped_Date__c\": \"2020-06-19\",\n"
                + "            \"K12_Validity_End_Date__c\": \"2020-06-19\",\n"
                + "            \"Order_Type__c\": \"Fresh order\",\n"
                + "            \"Student_Sales_Order__r\": {\n"
                + "              \"Sales_Order_No__c\": \"STUSALORD"+Premiumid+""+counter+"\"\n"
                + "            }\n"
                + "          },\n"
                + "          {\n"
                + "            \"attributes\": {\n"
                + "              \"type\": \"Order__c\",\n"
                + "              \"referenceId\": \"order2\"\n"
                + "            },\n"
                + "            \"Order_No__c\": \"STUSUBORD2"+Premiumid+""+counter+"\",\n"
                + "            \"Name\": \"SSO2XX\",\n"
                + "            \"Type__c\": \"Parent Order\",\n"
                + "            \"Course_Name__c\": \"9th Math\",\n"
                + "            \"Order_Start_Date__c\": \"2020-05-11\",\n"
                + "            \"Board__c\": \"ICSE\",\n"
                + "            \"Order_Product_name__c\": \"10th CBSE (SD Card-Byjus) May-2023\",\n"
                + "            \"Books__c\": \"Book 1;Book 2\",\n"
                + "            \"Active_AWB_Number__c\": \"AWB-1236\",\n"
                + "            \"Active_Order_Delivery_Date__c\": \"2020-05-17\",\n"
                + "            \"K3_Validity_End_Date__c\": \"2020-06-19\",\n"
                + "            \"Active_Order_Value__c\": \"20000\",\n"
                + "            \"Status__c\": \"Punched\",\n"
                + "            \"OMS_Order_Status__c\": \"Punched\",\n"
                + "            \"Active_Order_Shipped_Date__c\": \"2020-06-19\",\n"
                + "            \"K12_Validity_End_Date__c\": \"2020-06-19\",\n"
                + "            \"Order_Type__c\": \"Fresh order\",\n"
                + "            \"Student_Sales_Order__r\": {\n"
                + "              \"Sales_Order_No__c\": \"STUSALORD"+Premiumid+""+counter+"\"\n"
                + "            }\n"
                + "          }\n"
                + "        ]\n"
                + "      }\n"
                + "    },\n"
                + "    {\n"
                + "      \"method\": \"PATCH\",\n"
                + "      \"url\": \"/services/data/v53.0/sobjects/Student_Program__c/Student_Enrolment_ID__c/"+Premiumid+""+counter+"\",\n"
                + "      \"referenceId\": \""+Premiumid+""+counter+"\",\n"
                + "      \"body\": {\n"
                + "        \"Student_Sales_Order__c\": \"@{RefSTUSALORD"+Premiumid+""+counter+".id}\",\n"
                + "        \"Order__c\": \"@{orderList[1].id}\",\n"
                + "        \"Student__c\": \""+accID+"\",\n"
                + "        \"Program__r\": {\n"
                + "          \"Program_ID__c\": \""+ProgId+"\"\n"
                + "        },\n"
                + "        \"Status__c\": \"Active\",\n"
                + "        \"Start_Date__c\": \""+sdf.format(date)+"\",\n"
                + "        \"End_Date__c\": \"2026-03-14\",\n"
                + "        \"Program_Type__c\": \"Regular\",\n"
                + "        \"Duration__c\": \""+duration+"\",\n"
                + "        \"Product_Type__c\": \""+ProdType+"\",\n"
                + "        \"Trial_Program__c\": \""+TrialProg+"\",\n"
                + "        \"Class_Program_Type__c\": \""+ProgType+"\",\n"
                //+ "        \"Original_Order_Delivery_Date__c\": \"2023-04-14T11:30:00.000+0000\",\n"
                + "        \"Parent_Orientation_Date__c\" : \""+sdf.format(date)+"\"\n"
                + "      }\n"
                + "    }\n"
                + "    ]\n"
                + "}";
        counter++;
        return bodycontent;
    }
    
    
    public static String AccountCreationResponse_UAT(String accID,String ProgId,String duration,String ProdType,String TrialProg,String ProgType) {
        String val = "OAuth ";
        String StudentCreation="";
        StudentCreation = given().header("Authorization", val + Utils.Access_Token())
                .header("Content-Type", "application/json").body(bodycontent_prog(accID, ProgId, duration, ProdType, TrialProg,ProgType)).when()
                .post("https://byjusprod--byjusuat.sandbox.my.salesforce.com/services/data/v53.0/composite").then().log().all()
                .extract().response().asString();
        log.info("The response is: "+StudentCreation);
        return StudentCreation;

    }
    
    public static String AccountCreationResponse_UATFC(String accID,String ProgId,String duration,String ProdType,String TrialProg,String ProgType) {
        String val = "OAuth ";
        String StudentCreation="";
        StudentCreation = given().header("Authorization", val + Utils.Access_TokenUATFC())
                .header("Content-Type", "application/json").body(bodycontent_prog(accID, ProgId, duration, ProdType, TrialProg,ProgType)).when()
                .post("https://byjusprod--byjusfc.sandbox.my.salesforce.com/services/data/v58.0/composite").then().log().all()
                .extract().response().asString();
        log.info("The response is: "+StudentCreation);
        return StudentCreation;

    }
    
    public static String AccountCreationResponse_Prod(String accID,String ProgId,String duration,String ProdType,String TrialProg,String ProgType) {
        String val = "OAuth ";
        String StudentCreation="";
        StudentCreation = given().header("Authorization", val + Utils.Access_TokenProd())
                .header("Content-Type", "application/json").body(bodycontent_prog(accID, ProgId,duration, ProdType, TrialProg,ProgType)).when()
                .post("https://byjusprod.my.salesforce.com/services/data/v52.0/composite").then().log().all()
                .extract().response().asString();
        log.info("The response is: "+StudentCreation);
        return StudentCreation;

    }
    
    public static String AccountidCreationResponse_UAT(String accID,String ProgId,String duration,String ProdType,String TrialProg,String ProgType) {

        String id="";
        JsonPath js1 = new JsonPath(AccountCreationResponse_UAT(accID, ProgId,duration, ProdType, TrialProg,ProgType));
        id = js1.get("compositeResponse[0].body.id");
        System.out.println("The value of id is: " + id);
        return id;

    }
    
    public static String AccountidCreationResponse_UATFC(String accID,String ProgId,String duration,String ProdType,String TrialProg,String ProgType) {

        String id="";
        JsonPath js1 = new JsonPath(AccountCreationResponse_UATFC(accID, ProgId,duration, ProdType, TrialProg,ProgType));
        id = js1.get("compositeResponse[0].body.id");
        System.out.println("The value of id is: " + id);
        return id;

    }
    
    public static String AccountidCreationResponse_Prod(String accID,String ProgId,String duration,String ProdType,String TrialProg,String ProgType) {

        String id="";
        JsonPath js1 = new JsonPath(AccountCreationResponse_Prod(accID, ProgId,duration, ProdType, TrialProg,ProgType));
        id = js1.get("compositeResponse[0].body.id");
        System.out.println("The value of id is: " + id);
        return id;

    }    
}