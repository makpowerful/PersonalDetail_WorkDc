package payLoad;

import static io.restassured.RestAssured.given;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.github.javafaker.Faker;

import resources.Utils;

public class payLoad_CollectionsAuditCaseCreation {

    public static Logger log = LogManager.getLogger(payLoad_RefundProcess.class.getName());
    static Faker faker = new Faker();
   
    public static String bodycontent_UAT(String payref, String PDID) {
        String bodycontent = "{\"ivrRequests\": [\n"
                + "    {\n"
                + "        \"pdId\":\""+PDID+"\",\n"
                + "        \"amountCollected\":\"1000\",\n"
                + "        \"paymentReference\":\""+payref+"\"\n"
                + "    }\n"
                + "]\n"
                + "}";
        return bodycontent;
    }
    
    public static String AuditCaseCreationResponse_UAT(String payref, String PDID) {
        String val = "OAuth ";
        String caseCreation="";
        caseCreation = given().header("Authorization", val + Utils.Access_Token())
                .header("Content-Type", "application/json").body(bodycontent_UAT(payref,PDID)).when()
                .post("https://byjusprod--byjusuat.my.salesforce.com/services/apexrest/ivrapi").then().log().all()
                .extract().response().asString();
        log.info("The response is: "+caseCreation);
        return caseCreation;

    }
    
    public static String AuditCaseCreationResponse_Prod(String payref, String PDID) {
        String val = "OAuth ";
        String caseCreation="";
        caseCreation = given().header("Authorization", val + Utils.Access_TokenProd())
                .header("Content-Type", "application/json").body(bodycontent_UAT(payref,PDID)).when()
                .post("https://byjusprod.my.salesforce.com/services/apexrest/ivrapi").then().log().all()
                .extract().response().asString();
        log.info("The response is: "+caseCreation);
        return caseCreation;

    }
}
