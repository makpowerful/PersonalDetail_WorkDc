package payLoad;
import static io.restassured.RestAssured.given;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.commons.lang.time.DateUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.github.javafaker.Faker;

import io.restassured.path.json.JsonPath;
import resources.Utils;


public class payLoad_PrgmwithoutSSO_Revamp{
	
	public static Logger log = LogManager.getLogger(payLoad_PrgmwithoutSSO_Revamp.class.getName());
	static Faker faker = new Faker();
	static int randomNum = ThreadLocalRandom.current().nextInt(1000, 10000 + 1);
	static String firstName = faker.name().firstName().replaceAll("'","");
	static String lastName = faker.name().lastName().replaceAll("'","");
	static String parentName = faker.name().fullName().replaceAll("'","");
	static String Auto="Dummy ";
	static long Premiumid= 58514495345L+randomNum;
	static int counter=1;
	
	
    // Inserting a new program in an existing student account - without SSO 
    public static String bodycontent_prog(String accID,String ProgId,String duration,String ProdType,String TrialProg,String ProgType) {
        //Add "+Premiumid+""+counter+" to Premium Id and "+randomNum+" to Student Enrollment Id
        //Add "+Auto+ ""+firstName+" to FirstName
        //Add "+lastName+" to LastName
        //Add "+parentName+" to ParentName
        
        Date date = DateUtils.addDays(new Date(), -7);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        //driver.findElement(By.xpath("//label[text()='Due Date']/following::input")).sendKeys(sdf.format(date));
        
        // 
        String bodycontent = "{\"allOrNone\": true,\n"
                + "    \"compositeRequest\": [\n"
                + "           {\n"
                + "      \"method\": \"PATCH\",\n"
                + "      \"url\": \"/services/data/v53.0/sobjects/Student_Program__c/Student_Enrolment_ID__c/"+Premiumid+""+counter+"\",\n"
                + "      \"referenceId\": \"STUPRGM"+Premiumid+""+counter+"\",\n"
                + "      \"body\": {\n"
                + "        \"Student__c\": \""+accID+"\",\n"
                + "        \"Program__r\": {\n"
                + "          \"Program_ID__c\": \""+ProgId+"\"\n"
                + "        },\n"
                + "        \"Status__c\": \"Active\",\n"
                + "        \"Start_Date__c\": \"2023-01-06\",\n"
                + "        \"Program_Type__c\": \"Regular\",\n"
                + "        \"Duration__c\": \""+duration+"\",\n"
                + "        \"Product_Type__c\": \""+ProdType+"\",\n"
                + "        \"Trial_Program__c\": \""+TrialProg+"\",\n"
                + "        \"Class_Program_Type__c\": \""+ProgType+"\"\n"
                + "      }\n"
                + "    }\n"
                + "    ]\n"
                + "}";
        counter++;
        return bodycontent;
    }
    
    public static String AccountCreationResponse_UAT(String accID,String ProgId,String duration,String ProdType,String TrialProg,String ProgType) {
        String val = "OAuth ";
        String StudentCreation="";
        StudentCreation = given().header("Authorization", val + Utils.Access_Token())
                .header("Content-Type", "application/json").body(bodycontent_prog(accID, ProgId, duration, ProdType, TrialProg,ProgType)).when()
                .post("https://byjusprod--byjusuat.my.salesforce.com/services/data/v53.0/composite").then().log().all()
                .extract().response().asString();
        log.info("The response is: "+StudentCreation);
        return StudentCreation;

    }
    
    
    public static String AccountCreationResponse_Prod(String accID,String ProgId,String duration,String ProdType,String TrialProg,String ProgType) {
        String val = "OAuth ";
        String StudentCreation="";
        StudentCreation = given().header("Authorization", val + Utils.Access_TokenProd())
                .header("Content-Type", "application/json").body(bodycontent_prog(accID, ProgId,duration, ProdType, TrialProg,ProgType)).when()
                .post("https://byjusprod.my.salesforce.com/services/data/v52.0/composite").then().log().all()
                .extract().response().asString();
        log.info("The response is: "+StudentCreation);
        return StudentCreation;

    }
    
    public static String AccountidCreationResponse_UAT(String accID,String ProgId,String duration,String ProdType,String TrialProg,String ProgType) {

        String id="";
        JsonPath js1 = new JsonPath(AccountCreationResponse_UAT(accID, ProgId,duration, ProdType, TrialProg,ProgType));
        id = js1.get("compositeResponse[0].body.id");
        System.out.println("The value of id is: " + id);
        return id;

    }
    
    public static String AccountidCreationResponse_Prod(String accID,String ProgId,String duration,String ProdType,String TrialProg,String ProgType) {

        String id="";
        JsonPath js1 = new JsonPath(AccountCreationResponse_Prod(accID, ProgId,duration, ProdType, TrialProg,ProgType));
        id = js1.get("compositeResponse[0].body.id");
        System.out.println("The value of id is: " + id);
        return id;

    }
    
}