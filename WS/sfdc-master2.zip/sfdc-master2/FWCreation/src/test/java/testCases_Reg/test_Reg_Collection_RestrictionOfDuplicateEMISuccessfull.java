package testCases_Reg;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import pageObjects.CapturePaymentDetailsEMIPO;
import pageObjects.CasesPO;
import pageObjects.CollectionAssistantLoginPO;
import pageObjects.CreatedAccountPO;
import pageObjects.CreatedCaseRecordPO;
import pageObjects.DevConsolePO;
import pageObjects.FirstConnectPO;
import pageObjects.NPPaymentLoanPO;
import pageObjects.NewCaseDetailsPO;
import pageObjects.NewCaseRecordTypePO;
import pageObjects.NewPaymentPO;
import pageObjects.NewPaymentRecordPO;
import pageObjects.PaymentCaseQAPO;
import pageObjects.PaymentsPO;
import pageObjects.UserDetailPO;
import pageObjects.UserSetupPO;
import pageObjects.loginPO;
import payLoad.payLoad_CollectionsAuditCaseCreation;
import resources.ExcelData;
import resources.Queries;
import resources.Utils;
import resources.base;
import testCases.test_CollectionFlow;

public class test_Reg_Collection_RestrictionOfDuplicateEMISuccessfull extends base {

	public WebDriver driver;
	//ThreadLocal<WebDriver> driver = new ThreadLocal<WebDriver>();
	//public String CurrURL;
	public static Logger log = LogManager.getLogger(test_CollectionFlow.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	ArrayList<String> al3 = new ArrayList<String>();
	ArrayList<String> al4 = new ArrayList<String>();
	static Faker faker = new Faker();
	static String firstName = faker.name().firstName();
	static String lastName = faker.name().lastName();
	static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);
	static String PDID="bhavana_"+randomNum;
	
	static String PaymentRecord;
    static String Colluser;
    static ArrayList<String> CaseRecordList = new ArrayList<String>();
    static String CaseRecord;
    static String caseURL;
    static String Firstconnect_status;
    static String Firstconnect_callstatus;
    static String paymentURL;
    String Firstconnect_caseid;
    String CaseStatus;
    String CaseOwner;
    String RelatedCaseRecord;
    String AssignedToOwner;
    String Followup_status;
    String Followup_callstatus;

	
	@BeforeMethod(alwaysRun = true)
	public void initialize() throws IOException, InterruptedException {

		driver = initializeDriver();
	}
	

	@Test(groups = { "Regression","sanity" },priority=3 ,enabled = true)
	public void Reg_Collection_RestDup_EMISuccessfull() throws Exception {
	    
	    loginPO lo=new loginPO(driver);
        CreatedAccountPO ac=new CreatedAccountPO(driver);
        PaymentsPO p = new PaymentsPO(driver);
        NewPaymentPO np = new NewPaymentPO(driver);
        NPPaymentLoanPO npp = new NPPaymentLoanPO(driver);
        NewPaymentRecordPO npr = new NewPaymentRecordPO(driver);
        CreatedCaseRecordPO ccr = new CreatedCaseRecordPO(driver);
        FirstConnectPO fc = new FirstConnectPO(driver);
        CapturePaymentDetailsEMIPO cpd = new CapturePaymentDetailsEMIPO(driver);
        CasesPO cases=new CasesPO(driver);
        DevConsolePO dc = new DevConsolePO(driver);

        if(CurrURL.contains("--byjusuatfc")) 
        {
            al = excelData.getData("TC5", "CollectionFlow", "Tcid");
            al2 = excelData.getData("CollectionAssistant UATFC", "Login", "Type");
            al3 = excelData.getData("CollectionManager UATFC", "Login", "Type");
            al4 = excelData.getData("Adminuatfc", "Login", "Type");
            log.info("Logging in as Admin to UATFC");
            lo.LoginAsAdmin_UATFC();
            
        }
        else if(CurrURL.contains("--byjusuat")) 
        {
            al = excelData.getData("TC5", "CollectionFlow", "Tcid");
            al2 = excelData.getData("CollectionAssistant UAT", "Login", "Type");
            al3 = excelData.getData("CollectionManager UAT", "Login", "Type");
            al4 = excelData.getData("Admin", "Login", "Type");
            log.info("Logging in as Admin to UAT");
            lo.LoginAsAdmin_UAT();
        }
        else 
        {
            al = excelData.getData("TC5", "CollectionFlow", "Tcid");
            al2 = excelData.getData("Dummy Collection Associate", "Login", "Type"); 
            al4 = excelData.getData("AdminProd", "Login", "Type");
            log.info("Logging in as Admin to Prod");
            lo.LoginAsAdmin_Prod();
        }
        
		//Assert.assertTrue(false);
		closeTabWindows();
		log.info("Creating new Payment record");

		ac.Notification();
		p.NavMenuClick();
		p.PaymntNavMenuClick();
		p.NewPaymentClick();
		
		log.info("Selection of Payment - Loan record");
		np.SelectPaymentOptn(al.get(1));
		np.ClickNext();
		
		log.info("Enter New Payment - Loan details");
		
		//entering details to create payment record
		npp.EnterParentFN(firstName);
		npp.EnterParentLN(lastName);
		npp.EnterLoanAmount(al.get(2));
		npp.EnterTenurity(al.get(4));
		npp.EnterProgramName(al.get(3));	
		npp.EnterEPPartner(al.get(5));
		npp.EnterAmount(al.get(6));
		npp.EnterTotalAmountTBC(al.get(7));
		npp.EnterNetPayAmount(al.get(8));
		npp.EnterPaymentAmount(al.get(9));
		npp.EnterPaymentCategory(al.get(10));
		npp.EnterPaymentMS(al.get(11));
		npp.EnterPaymentDate(al.get(12));
		npp.EnterPaymentType(al.get(13));
		npp.ClickSave();
		ac.AdditionalWait();
		
		PaymentRecord = npr.CapturePaymentRcdID();
		System.out.println(PaymentRecord);
		paymentURL = driver.getCurrentUrl();
		log.info("New Payment Record " + PaymentRecord + " created successfully");
		npr.ClickCasesbtn();
		
		// ********** Creating first EMI Case *********** //
		
        // Creating an EMI case
        log.info("Creating first New Case Record for " + PaymentRecord);
		EMICaseCnA();
		
		CaseRecord = CaseRecordList.get(0);
		Firstconnect_caseid = fc.CaptureFCcaseid();
		// Compare the Case Record to First connect case Record
		Assert.assertEquals(CaseRecord, Firstconnect_caseid);
		
		log.info("Providing Capture payment detail for Case record " + Firstconnect_caseid);
		fc.ClickCapturePayment();
		
		cpd.EnterRating(al.get(15));
		cpd.ClickNext();
		
		//EMI successful flow
		cpd.SelectPaymntOptn(al.get(16));
		log.info("Selected the payment option " + al.get(16));
		cpd.ClickNext();		
		
		cpd.EnterAmtpaid(al.get(17));		
		cpd.SelectPaymentMethod(al.get(18));
		cpd.EnterPaymntRefVal(randomNum);
		cpd.SelectCollectionchannel(al.get(19)); 
		cpd.ClickNext();
		
		cpd.SelectEMIcoll(al.get(20));
		cpd.SelectTypofCollPaid(al.get(21));
		cpd.ClickNext();
		
		cpd.SelectElgfrRef(al.get(22));
		cpd.ClickNext();
		ac.AccountLoadwait();
		fc.RefreshPage(); 
		
		Firstconnect_status = fc.CheckFCStatus();
		// Verify the Status for first connect is changed to Completed
		Assert.assertEquals(Firstconnect_status, "Completed");
		
		Firstconnect_callstatus = fc.CheckFCCallStatus();
		// Verify the Call Status for first connect is changed to Payment Confirmed
		Assert.assertEquals(Firstconnect_callstatus, "Payment Confirmed");

		log.info("Logging out as Collection Assistant");
		ac.AdditionalWait();
		lo.Logouthome();
		
		log.info("Verifying the Case Status is correct");
        ac.CloseSubTabs();
        ac.goTo(paymentURL);
        ac.Scrollpagedown();
        ac.AdditionalWait();
        p.NavCaseTab(CaseRecord);
        
		CaseStatus = ccr.CaseStatusval();
		CaseOwner = ccr.CaseOwnerval();	
		log.info("The record number for newly created Case record is " + ccr.CaptureNewCaseRecord());
		// Verify the Case Status is changed to Audit Pending
		Assert.assertEquals(CaseStatus, "Audit Pending");
		// Verify the Case owner is same
		Assert.assertTrue(CaseOwner.equalsIgnoreCase(Colluser));
		
        // Get the Audit case id 
		RelatedCaseRecord= ccr.getAuditCaseCaptureRelatedCase(); 
		ccr.clickAuditRelatedCase();
		//getting the payment reference no from audit case
		String payRef1 = ccr.getPayRef();
		ac.CloseSubTabs();
		npr.ClickCasesbtn();
		
		// ********** Creating second EMI Case *********** //
        // Creating an EMI case
        log.info("Creating second New Case Record for " + PaymentRecord);
        EMICaseCnA();
		
		CaseRecord = CaseRecordList.get(1);
		Firstconnect_caseid = fc.CaptureFCcaseid();
        // Compare the Case Record to First connect case Record
        Assert.assertEquals(CaseRecord, Firstconnect_caseid);
        
        log.info("Providing Capture payment detail for Case record " + Firstconnect_caseid);
		fc.ClickCapturePayment();	
		ac.AdditionalWait(); 
		cpd.navToiframe("accessibility title");
        cpd.SelectPaymntOptn(al.get(16));
        log.info("Selected the payment option " + al.get(16));
        cpd.ClickNext();        
 
        cpd.SelectPaymentMethod(al.get(18));
        //using the same payment reference of 1st EMI case
        cpd.EntergivenPayRef(payRef1);
        cpd.SelectCollectionchannel(al.get(19)); 
        cpd.ClickNext();
        
        //capturing the error message
        String PRerror = cpd.CaptureErrorMess();
        Assert.assertEquals(PRerror,cpd.errorMsg());        
        
        cpd.EnterPaymntRefVal(randomNum);
        cpd.ClickNext();
        
        cpd.SelectEMIcoll(al.get(20));
        cpd.SelectTypofCollPaid(al.get(21));
        cpd.ClickNext();
        
        cpd.SelectElgfrRef(al.get(22));
        cpd.ClickNext();
        ac.AccountLoadwait();
        fc.RefreshPage();  
        
        Firstconnect_status = fc.CheckFCStatus();
        // Verify the Status for first connect is changed to Completed
        Assert.assertEquals(Firstconnect_status, "Completed");
        
        Firstconnect_callstatus = fc.CheckFCCallStatus();
        // Verify the Call Status for first connect is changed to Payment Confirmed
        Assert.assertEquals(Firstconnect_callstatus, "Payment Confirmed");

        log.info("Logging out as Collection Assistant");
        ac.AdditionalWait();
        lo.Logouthome();
        
        log.info("Verifying the Payment/Case Status are correct");
        ac.CloseSubTabs();
        ac.goTo(paymentURL);
        ac.Scrollpagedown();
        ac.AdditionalWait();
        p.NavCaseTab(CaseRecord);

        CaseStatus = ccr.CaseStatusval();
        CaseOwner = ccr.CaseOwnerval();    
        log.info("The record number for newly created Case record is " + ccr.CaptureNewCaseRecord());
        Assert.assertEquals(CaseStatus, "Audit Pending");
        Assert.assertTrue(CaseOwner.equalsIgnoreCase(Colluser));
        
        RelatedCaseRecord= ccr.getAuditCaseCaptureRelatedCase();
        ccr.clickAuditRelatedCase();
        //getting the payment reference no from audit case
        String payRef2 = ccr.getPayRef();
        
        //Assert.assertEquals(payRef2, payRef1);
        
        String auditCaseStatus = ccr.getAuditStatus();
        Assert.assertEquals(auditCaseStatus, "Not Assigned");
        
        //getting 2nd EMI case URL
        String AuditcaseURL = driver.getCurrentUrl();
        String AuditcaseId;
        
        //getting the case id from the case URL
        if(CurrURL.contains("--byjusuat"))
            AuditcaseId = AuditcaseURL.substring(65, 83);
        else
            AuditcaseId = AuditcaseURL.substring(55, 73);
        
        //collection associate address from the URL
        String colluserId = "0055i000000YNWvAAO"; 
        
        //Code to change the status of the audit case to rejected
//        Queries.StatusChange(AuditcaseId, colluserId);
        
        ac.AdditionalWait();
        log.info("Opening developer console");
        
        if(CurrURL.contains("--byjusuat"))
            dc.GetDevConsole("UAT"); 
        else if(CurrURL.contains("--byjusuatfc"))
            dc.GetDevConsole("UATFC");     
        else
            dc.GetDevConsole("Prod"); 
        
        log.info("Changing the status of the audit case to rejected-Case no: "+ RelatedCaseRecord);
        dc.RunApexCode(Queries.StatusChange(AuditcaseId, colluserId), Utils.getOSValue()); //changes the status to pending
        //dc.RunBatchMac(statusChangeCode); //changes the status to rejected
        dc.RunApexCode(Queries.StatusChange(AuditcaseId, colluserId), Utils.getOSValue());
        ac.AdditionalWait();
       
        ac.goTo(AuditcaseURL);
        auditCaseStatus = ccr.getAuditStatus(); 
        //System.out.println(auditCaseStatus);
        //verifying if the audit case status is changed rejected
        Assert.assertEquals(auditCaseStatus, "Rejected");
        
        ccr.closeCurrentTab(RelatedCaseRecord);
        p.NavCaseTab(CaseRecord);
        
        CaseStatus = ccr.CaseStatusval();
        Assert.assertEquals(CaseStatus, "Collection Failure");
        ccr.closeCurrentTab(CaseRecord);
        
        // ********** Creating third EMI Case *********** //
        // Creating an EMI case
        log.info("Creating third New Case Record for " + PaymentRecord);
        EMICaseCnA();
        
        CaseRecord = CaseRecordList.get(2); 
        Firstconnect_caseid = fc.CaptureFCcaseid();
        // Compare the Case Record to First connect case Record
        Assert.assertEquals(CaseRecord, Firstconnect_caseid);
        
        log.info("Providing Capture payment detail for Case record " + Firstconnect_caseid);
        fc.ClickCapturePayment();   
        ac.AdditionalWait(); 
        cpd.navToiframe("accessibility title");
        cpd.SelectPaymntOptn(al.get(16));
        log.info("Selected the payment option " + al.get(16));
        cpd.ClickNext();        
 
        cpd.SelectPaymentMethod(al.get(18));
        //using the same payment reference of 2nd EMI case
        cpd.EntergivenPayRef(payRef2);
        cpd.SelectCollectionchannel(al.get(19)); 
        cpd.ClickNext();
        
        cpd.SelectEMIcoll(al.get(20));
        cpd.SelectTypofCollPaid(al.get(21));
        cpd.ClickNext();
        
        cpd.SelectElgfrRef(al.get(22));
        cpd.ClickNext();
        ac.AccountLoadwait();
        fc.RefreshPage(); 
        
        Firstconnect_status = fc.CheckFCStatus();
        // Verify the Status for first connect is changed to Completed
        Assert.assertEquals(Firstconnect_status, "Completed");
        
        Firstconnect_callstatus = fc.CheckFCCallStatus();
        // Verify the Call Status for first connect is changed to Payment Confirmed
        Assert.assertEquals(Firstconnect_callstatus, "Payment Confirmed");

        log.info("Logging out as Collection Assistant");
        ac.AdditionalWait();
        lo.Logouthome();
        
        log.info("Verifying the Payment/Case Status are correct");
        ac.CloseSubTabs();
        ac.goTo(paymentURL);
        ac.Scrollpagedown();
        ac.AdditionalWait();
        p.NavCaseTab(CaseRecord);

        CaseStatus = ccr.CaseStatusval();
        CaseOwner = ccr.CaseOwnerval();
        
        log.info("The record number for newly created Case record is " + ccr.CaptureNewCaseRecord());
        Assert.assertEquals(CaseStatus, "Audit Pending");
        Assert.assertTrue(CaseOwner.equalsIgnoreCase(Colluser));
        
        String EMIcaseURL = driver.getCurrentUrl();
        String EMIcaseId;
        
        if(CurrURL.contains("--byjusuat"))
            EMIcaseId = EMIcaseURL.substring(65, 83);
        else
            EMIcaseId = EMIcaseURL.substring(55, 73);
        
//        String addpdId = "case c = new case();\n"
//                + "c.id = '"+EMIcaseId+"';\n"
//                + "c.PD_ID__c = 'bhavana12';\n"
//                + "update c;";

        RelatedCaseRecord= ccr.getAuditCaseCaptureRelatedCase();
        
        ccr.clickAuditRelatedCase();
        //getting the payment reference of 3rd EMI case
        String payRef3 = ccr.getPayRef();
        //checking if both 2nd and 3rd EMI audit case have same payment reference
        Assert.assertEquals(payRef2, payRef3);
        
        auditCaseStatus = ccr.getAuditStatus();
        Assert.assertEquals(auditCaseStatus, "Not Assigned");
        //ccr.closeCurrentTab(RelatedCaseRecord); 
        //ccr.closeCurrentTab(CaseRecord);
        
       //check here
        
        AuditcaseURL = driver.getCurrentUrl(); 
        //getting the case id from the case URL        
        if(CurrURL.contains("--byjusuat"))
            AuditcaseId = AuditcaseURL.substring(65, 83);
        else
            AuditcaseId = AuditcaseURL.substring(55, 73);
        
        log.info("Audit case id from url is : "+AuditcaseId);
        
        ac.AdditionalWait();
        log.info("Opening developer console");
        
        if(CurrURL.contains("--byjusuat"))
            dc.GetDevConsole("UAT"); 
        else if(CurrURL.contains("--byjusuatfc"))
            dc.GetDevConsole("UATFC");     
        else
            dc.GetDevConsole("Prod"); 
        
        log.info("Adding pd Id to create another audit case within same EMI case");
        //dc.RunBatchMac(addpdId); //add pdId to EMI case
        dc.RunApexCode(Queries.AddpdId(EMIcaseId,PDID), Utils.getOSValue()); //changes the status to pending
        ac.AdditionalWait();
        
        log.info("Creating audit case with same pay ref in emi case : "+CaseRecord);
        //creating another audit case with same payref3
        if(CurrURL.contains("--byjusuat"))
            payLoad_CollectionsAuditCaseCreation.AuditCaseCreationResponse_UAT(payRef3,PDID);
        else
            payLoad_CollectionsAuditCaseCreation.AuditCaseCreationResponse_Prod(payRef3,PDID);

        
        //Code to change the status of the audit case to rejected
//        statusChangeCode = "case c = new case();\n"
//                + "c.id = '"+AuditcaseId+"';\n"
//                + "c.ownerid = '"+colluserId+"';\n"
//                + "c.Audit_Status__c = 'Rejected';\n"
//                + "update c;";
        
        log.info("Changing the status of the audit case to rejected-Case no: "+ RelatedCaseRecord);
//        dc.RunBatchMac(statusChangeCode); //changes the status to pending
//        dc.RunBatchMac(statusChangeCode); //changes the status to rejected
        
        dc.RunApexCode(Queries.StatusChange(AuditcaseId, colluserId), Utils.getOSValue()); //changes the status to pending
        dc.RunApexCode(Queries.StatusChange(AuditcaseId, colluserId), Utils.getOSValue()); //changes the status to rejected
        ac.AdditionalWait();
        
        ac.goTo(EMIcaseURL);
        RelatedCaseRecord= ccr.getAuditCaseCaptureRelatedCase();
        ccr.clickAuditRelatedCase();
        auditCaseStatus = ccr.getAuditStatus(); 
        //System.out.println(auditCaseStatus);
        //verifying if the audit case status is changed rejected
        Assert.assertEquals(auditCaseStatus, "Rejected");
        ccr.closeCurrentTab(RelatedCaseRecord);
        
        CaseStatus = ccr.CaseStatusval();
        Assert.assertEquals(CaseStatus, "Collection Failure");

        log.info("Creating audit case with same pay ref in emi case : "+CaseRecord);
        //creating another audit case with same payref3 
        if(CurrURL.contains("--byjusuat"))
            payLoad_CollectionsAuditCaseCreation.AuditCaseCreationResponse_UAT(payRef3,PDID);
        else
            payLoad_CollectionsAuditCaseCreation.AuditCaseCreationResponse_Prod(payRef3,PDID);
        
        
        //ac.RefreshTab();
        lo.RefreshURL();
        ac.AdditionalWait();
        //check the second audit case in the EMI case        
        RelatedCaseRecord= ccr.getAuditCaseCaptureRelatedCase();
        
        ccr.clickAuditRelatedCase();
        //getting the payment reference of 3rd EMI case 
        String payRef4 = ccr.getPayRef();
        //checking if both audit cases have same payment reference
        Assert.assertEquals(payRef4, payRef3);
        
        auditCaseStatus = ccr.getAuditStatus();
        Assert.assertEquals(auditCaseStatus, "Not Assigned");
        
        ccr.closeCurrentTab(RelatedCaseRecord); 
        log.info("Deleting the Related Case Record " +RelatedCaseRecord);
        ccr.DeleteRelatedCaseRecord(RelatedCaseRecord);
        //ccr.closeCurrentTab(CaseRecord);
        ac.CloseSubTabs();
        
        //check here

		log.info("Deleting all the Related Case Records and Case Records");		
		// Deleting all the audit cases
		for(int i=0 ; i<CaseRecordList.size() ; i++)
		{
		    //opening EMI cases
		    p.NavCaseTab(CaseRecordList.get(i)); 
		    //capturing audit case no
		    RelatedCaseRecord= ccr.CaptureRelatedCaseno();
	        
		    // Deleting the audit case
		    log.info("Deleting the Related Case Record " +RelatedCaseRecord);
		    ccr.DeleteRelatedCaseRecord(RelatedCaseRecord); 
		    
		    // Deleting the EMI case
		    log.info("Deleting the created Case Record " +CaseRecordList.get(i));
		    p.NavCasesTab();
		    cases.DeleteCCaseRecord(CaseRecordList.get(i));
		    ac.CloseSubTabs();
		}
		
		log.info("Deleting the created Payment Record " + PaymentRecord);
		p.NavMenuClick();
		p.PaymntNavMenuClick();
		// Deleting the Payment record
		p.DeletePayRecord(PaymentRecord);

	}

	public void EMICaseCnA() throws Exception

	{
	    loginPO lo=new loginPO(driver);
        CreatedAccountPO ac=new CreatedAccountPO(driver);
        PaymentCaseQAPO pcqa = new PaymentCaseQAPO(driver);
        NewCaseRecordTypePO ncrt = new NewCaseRecordTypePO(driver);
        NewCaseDetailsPO ncd = new NewCaseDetailsPO(driver);
        CreatedCaseRecordPO ccr = new CreatedCaseRecordPO(driver);
        UserSetupPO us = new UserSetupPO(driver); 
        CollectionAssistantLoginPO cal = new CollectionAssistantLoginPO(driver);
        UserDetailPO ud = new UserDetailPO(driver); 
        
	    log.info("Creating New Case Record for " + PaymentRecord);
        
        pcqa.ClickCaseNewButton(PaymentRecord);

        ncrt.SelectCaseRecordType(al.get(14));
        ncrt.ClickNext();

        ncd.enterEMIamount(al.get(6));
        ncd.EnterSubject(al.get(43));
        ncd.ClickSave();
        
        CaseRecordList.add(ccr.CaptureNewCaseRecord());
        log.info("New Case Record " + CaseRecord + " created successfully"); 
        
         caseURL = driver.getCurrentUrl();
        
        if(!CurrURL.contains("--byjusuatfc")) 
        {
            ccr.ClickAssingedTo();
            ccr.EnterAssingedTo2(al2.get(1));
            ccr.ClickSave();
        }
        else
        {
            lo.SwitchUser(al4.get(3));
            ac.closeTabWindows();
            ac.Notification();
            ac.goTo(caseURL);
            ac.AdditionalWait();
            ccr.ClickAssingedTo();
            ccr.EnterAssingedTo2(al2.get(1));
            ccr.ClickSave();
        }
        
        Colluser = MailFullName(al2.get(1));
        //Logging in as the assigned user
        ccr.ClickAssignedUser2(al2.get(1));
        log.info("Logging in as Collection Assistant " + FullName(al2.get(1)));

        ud.ClickUserDetailbutton();
        us.ClickLoginbutton();
        cal.ClickBellicon();
        if(CurrURL.contains("--byjusuatfc"))
            cal.SelectAssignedTask(taskName(al4.get(3)));
        else
            cal.SelectAssignedTask(taskName(al4.get(1)));     

	}
	
	@AfterMethod(alwaysRun = true)
	public void teardown() throws InterruptedException {

		driver.quit();


	}

}
