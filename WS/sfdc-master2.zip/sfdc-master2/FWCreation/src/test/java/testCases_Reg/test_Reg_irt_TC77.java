package testCases_Reg;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import pageObjects.CreatedAccountPO;
import pageObjects.InboundTaskPO;
import pageObjects.IssueTreePO;
import pageObjects.NewCaseRecordTypePO;
import pageObjects.loginPO;
import payLoad.payLoad_SinglePrgm;
import resources.ExcelData;
import resources.base;



public class test_Reg_irt_TC77 extends base {

	public WebDriver driver;
	//public String CurrURL;
	public static Logger log = LogManager.getLogger(test_Reg_irt_TC77.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> proddummyuser = new ArrayList<String>();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	ArrayList<String> al3 = new ArrayList<String>();
	ArrayList<String> al4 = new ArrayList<String>();
	ArrayList<String> al5 = new ArrayList<String>();
	ArrayList<String> al6 = new ArrayList<String>();
	ArrayList<String> al7 = new ArrayList<String>();
	static Faker faker = new Faker();
	static String firstName = faker.name().firstName();
	static String lastName = faker.name().lastName();
	static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);
	
	@BeforeMethod(alwaysRun = true)
	public void initialize() throws IOException, InterruptedException {

		driver = initializeDriver();

	}
	
	
	@Test(groups = {"sanity", "UAT" }, enabled = true)
	public void TestIRT_Reg_irt_TC77() throws Exception {
        proddummyuser = excelData.getData("TC1", "ProdDummyUser", "Tcid");
        String Accountid = null;
        loginPO lo=new loginPO(driver);
        al = excelData.getData("Logistics", "Multi_Prog", "Tcid");
        if(CurrURL.contains("--byjusuatfc")) {
            
            al2 = excelData.getData("IRT User UATFC", "Login", "Type");
            log.info("Logging in as Admin to UATFC Env then switching user to IRT");
            lo.LoginAsAdmin_UATFC();
            log.info("Submitting the Account creation payload");
            Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_UATFC(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
            log.info("Launching the newly created Account id "+Accountid);
        }
        else if(CurrURL.contains("--byjusuat")) {
        
        al2 = excelData.getData("IRT User UAT", "Login", "Type");
        
        log.info("Logging in as Admin to UAT then switching user to IRT");
        lo.LoginAsAdmin_UAT();
        log.info("Submitting the Account creation payload");
        Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_UAT(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
        log.info("Launching the newly created Account id "+Accountid);
        
        }
        else {
            
            //al2 = excelData.getData("Collection Assistant", "Login", "Type");
            log.info("Logging in as Admin to Prod");
            lo.LoginAsAdmin_Prod();
            log.info("Submitting the Account creation payload");
            Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_Prod(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
            log.info("Launching the newly created Account id "+Accountid);
        }
        closeTabWindows();

        CreatedAccountPO ac=new CreatedAccountPO(driver);
        //Open the account by searching PID
        ac.Notification();
        ac.NavBackToAccount();
        String AccountURL = CurrURL+Accountid;
        ac.goTo(CurrURL+Accountid);
        ac.AccountLoadwait();
        
        if(CurrURL.contains("--byjusuat")||CurrURL.contains("--byjusuatfc")) {
            String AccountOwner= ac.AccOwnerCheck();
            if(!al2.get(1).equalsIgnoreCase(AccountOwner)) {
                ac.AssignAccount(al2.get(1));
            }
        }
        else {
            ac.AssignAccount("Testing User");
        }
        
        if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
        lo.SwitchUser(al2.get(1));
        ac.closeTabWindows();
        ac.Notification();
        ac.NavBackToAccount();
        ac.goTo(AccountURL);
        ac.AccountLoadwait();
        }
        else if(CurrURL.contains("--byjusuatfc")){
            lo.SwitchUser(al2.get(1));
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AccountLoadwait();
        }
        else {
            lo.SwitchUsernProfile_Prod(proddummyuser.get(1),"IRT profile");
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AccountLoadwait();
        }
        
        //Creating Inbound Task  
        log.info("Creating Inbound Task");
        ac.ClickOpenActivitiestoNewTask();
        
        NewCaseRecordTypePO ncrt= new NewCaseRecordTypePO(driver);
        ncrt.SelectCaseRecordTypeInbound();
        ncrt.ClickNext();
        ac.AdditionalWait();
        ncrt.ClickSave();
        ac.AdditionalWait();
        
        InboundTaskPO ibdt= new InboundTaskPO(driver);
     
        ibdt.ClickCaptureDetail();
        ibdt.ClickProceedOptn();
        IssueTreePO it=new IssueTreePO(driver);
        al3 = excelData.getData("Inbound", "Inbound", "Tcid");
        al4 = excelData.getData("TC3", "RefundProcess", "Tcid");
        al5 = excelData.getData("TC8", "Academic", "Tcid");
        al6 = excelData.getData("TC7", "Academic", "Tcid");
        al7 = excelData.getData("TC3", "Academic", "Tcid");
        
        ibdt.SelectSpokeTo3(al3.get(1));//Student
        it.PremiumidSelector();
        it.SpecificProgramSelector("BYJUS Aakash Learning App");
        it.ClickNext();
        ibdt.SelectPSTCT(al3.get(2));// New Issue
        //ibdt.EnterNotesVal(al3.get(3));
        ibdt.ClickNext();
        ac.AdditionalWait();
        it.IssueCategory(al5.get(1));//K11-12 Tech & Program
        it.IssueSubCategory(al6.get(25));//AITS 
        it.IssueType(al7.get(17));//Post-Test
        ac.AdditionalWait();
        //Verifying the 'Issue Sub Type' picklist values
        it.allCheckIssueTypevalues("Academic","TC3",18,"Issue Sub Type");
     
        ac.CloseSubTabs();      
        lo.Logouthome();
        
        ac.closeTabWindows();
        ac.goTo(AccountURL);
        ac.AdditionalWait();
        
        log.info("Deleting the Student Program details");
        ac.ClickAccOwnrTab();
        ac.DeleteAllCreatedStuProg();
        ac.DeleteAllCreatedStuPayment();
        ac.NavBackToAccount();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
       
    }
  
	  @AfterMethod(alwaysRun = true) public void teardown() throws
	  InterruptedException {
	  
	  driver.quit();
	  
	  //ac.AdditionalWait(); 
	  }
	 	
	
}
