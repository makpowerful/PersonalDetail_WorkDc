package testCases_Reg;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pageObjects.BLCIssueTaskPO;
import pageObjects.CasesPO;
import pageObjects.CreatedAccountPO;
import pageObjects.ExamDetailsPO;
import pageObjects.GmailPO;
import pageObjects.InboundTaskPO;
import pageObjects.IssueTreePO;
import pageObjects.NewCaseRecordTypePO;
import pageObjects.OpenActivitiesPO;
import pageObjects.loginPO;
import payLoad.payLoad_BTLAwithBranchAccount;
import payLoad.payLoad_BTLAwithBranchAccount2;
import resources.ExcelData;
import resources.base;

public class test_Reg_BLC_Upgrade extends base {

    public WebDriver driver;
    // public String CurrURL;
    public static Logger log = LogManager.getLogger(test_Reg_BLC_Upgrade.class.getName());
    ExcelData excelData = new ExcelData();
    ArrayList<String> proddummyuser = new ArrayList<String>();
    ArrayList<String> al = new ArrayList<String>();
    ArrayList<String> al2 = new ArrayList<String>();
    ArrayList<String> al3 = new ArrayList<String>();
    ArrayList<String> al4 = new ArrayList<String>();
    ArrayList<String> al5 = new ArrayList<String>();

    @BeforeMethod(alwaysRun = true)
    public void initialize() throws IOException, InterruptedException {

        driver = initializeDriver();

    }

    @Test(groups = { "Regression", "UAT","sanity" },priority =1, enabled = true)
    public void Test_Reg_BLC() throws Exception {
        proddummyuser = excelData.getData("TC1", "ProdDummyUser", "Tcid");
        String Accountid = null;
        loginPO lo = new loginPO(driver);
        al5 = excelData.getData("BTCTest", "Login", "Tcid");
        al2 = excelData.getData("BLC User UATFC", "Login", "Type");
        al3 = excelData.getData("Inbound", "Inbound", "Tcid");
        if (CurrURL.contains("--byjusuat")) {
            al = excelData.getData("TC1", "BLC", "Tcid");

            log.info("Logging in as Admin to UAT");
            lo.LoginAsAdmin_UAT();
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_BTLAwithBranchAccount.AccountidCreationResponse_UAT(al.get(108));
            log.info("Launching the newly created Account id " + Accountid);

        } else {
            al = excelData.getData("TC2", "BLC", "Tcid");
            // al2 = excelData.getData("Collection Assistant", "Login", "Type");
            log.info("Logging in as Admin to Prod");
            lo.LoginAsAdmin_Prod();
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_BTLAwithBranchAccount.AccountidCreationResponse_Prod(al.get(108));
            log.info("Launching the newly created Account id " + Accountid);
        }

        CreatedAccountPO ac = new CreatedAccountPO(driver);

        NewCaseRecordTypePO ncrt = new NewCaseRecordTypePO(driver);

        InboundTaskPO ibdt = new InboundTaskPO(driver);
        IssueTreePO it = new IssueTreePO(driver);
        CasesPO cases = new CasesPO(driver);
        GmailPO gm = new GmailPO(driver);
        ExamDetailsPO ed = new ExamDetailsPO(driver);
        // Open the account by searching PID
        ac.closeTabWindows();
        ac.Notification();
        ac.NavBackToAccount();
        String AccountURL = CurrURL + Accountid;
        ac.goTo(AccountURL);
        ac.AccountLoadwait();

        // Changing the email address of account
        ac.EditAccount();
        ac.UpdateStudentEmailid(al5.get(1));
        ac.UpdateEmail(al5.get(1));
        ac.ClickSave();
        String AccountOwner = null;
        // Changing Account owner to BLC and Logging in as BLC
        if (CurrURL.contains("--byjusuat") || CurrURL.contains("--byjusuatfc")) {
            AccountOwner = ac.AccOwnerCheck();
            System.out.println("AccountOwner value is: " + AccountOwner);
            if (!al2.get(1).equalsIgnoreCase(AccountOwner)) {
                ac.AssignAccount(al2.get(1));
            }
        } else {
            ac.AssignAccount("Testing User");
        }

        if (CurrURL.contains("--byjusuat") && !CurrURL.contains("--byjusuatfc")) {
            lo.SwitchUser(al2.get(1));
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AdditionalWait();
        } else {
            lo.SwitchUsernProfile_Prod(proddummyuser.get(1), "BLC Counsellor");
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AdditionalWait();
        }

        // SFDC-3654
        // Creating Inbound Task //Step 73
        ac.ClickOpenActivitiestoNewTask();
        ncrt.SelectTaskRecordType("Inbound");
        ncrt.ClickNext();
        ncrt.ClickSave();
        ibdt.ClickCaptureDetail();
        ibdt.ClickProceedOptn();

        // BTC Issues - Support Issue
        al4 = excelData.getData("TC3", "BLC", "Tcid");
        ibdt.SelectSpokeTo3(al3.get(1));
        it.PremiumidSelector();
        it.ProgramSelector();
        it.ClickNext();
        ibdt.SelectPSTCT(al3.get(2));
        ibdt.ClickNext();
        it.IssueCategory(al4.get(115));
        it.IssueSubCategory(al4.get(116));
        it.IssueType(al4.get(117));
        it.IssueSubType(al4.get(118));
        it.IssueNotes(al4.get(119));
        it.IstheIssueResolved(al4.get(120));
        it.ClickNext2();
        ac.AdditionalWait();
        ac.RefreshTab_Targetframe_IT();

        log.info("Created case for 'Support Issue' Type is: " + ibdt.CaptureRelatedToCaseNumber());
        String SupportIssue = ibdt.CaptureRelatedToCaseNumber();
        if (CurrURL.contains("byjusprod.")) {
            while (SupportIssue.equalsIgnoreCase(AccountOwner)) {
                ac.AdditionalWait();
                ac.RefreshTab_Targetframe_IT();
            }
            SupportIssue = ibdt.CaptureRelatedToCaseNumber();
        }

        // Navigating to case to figure out the SLA
        ibdt.ClickRelatedToCaseNumber();
        ac.CloseSubTabs();

        // Creating Inbound Task //Step 74
        ac.ClickOpenActivitiestoNewTask();
        ncrt.SelectTaskRecordType("Inbound");
        ncrt.ClickNext();
        ncrt.ClickSave();
        ibdt.ClickCaptureDetail();
        ibdt.ClickProceedOptn();

        // BTC Issues - Academic Issue
        al4 = excelData.getData("TC6", "BLC", "Tcid");
        ibdt.SelectSpokeTo3(al3.get(1));
        it.PremiumidSelector();
        it.ProgramSelector();
        it.ClickNext();
        ibdt.SelectPSTCT(al3.get(2));
        ibdt.ClickNext();
        it.IssueCategory(al4.get(115));
        it.IssueSubCategory(al4.get(116));
        it.IssueType(al4.get(117));
        it.IssueSubType(al4.get(118));
        it.IssueNotes(al4.get(119));
        it.IstheIssueResolved(al4.get(120));
        it.ClickNext2();
        ac.AdditionalWait();
        ac.RefreshTab_Targetframe_IT();

        log.info("Created case for 'Academic Issue' Type is: " + ibdt.CaptureRelatedToCaseNumber());
        String AcademicIssue = ibdt.CaptureRelatedToCaseNumber();
        if (CurrURL.contains("byjusprod.")) {
            while (AcademicIssue.equalsIgnoreCase(AccountOwner)) {
                ac.AdditionalWait();
                ac.RefreshTab_Targetframe_IT();
            }
            AcademicIssue = ibdt.CaptureRelatedToCaseNumber();
        }

        // Navigating to case to figure out the SLA
        ibdt.ClickRelatedToCaseNumber();
        ac.CloseSubTabs();

        // Creating Inbound Task //Step 75
        ac.ClickOpenActivitiestoNewTask();
        ncrt.SelectTaskRecordType("Inbound");
        ncrt.ClickNext();
        ncrt.ClickSave();
        ibdt.ClickCaptureDetail();
        ibdt.ClickProceedOptn();

        // BTC Issues - Technical Issue
        al4 = excelData.getData("TC4", "BLC", "Tcid");
        ibdt.SelectSpokeTo3(al3.get(1));
        it.PremiumidSelector();
        it.ProgramSelector();
        it.ClickNext();
        ibdt.SelectPSTCT(al3.get(2));
        ibdt.ClickNext();
        it.IssueCategory(al4.get(115));
        it.IssueSubCategory(al4.get(116));
        it.IssueType(al4.get(117));
        it.IssueSubType(al4.get(118));
        it.IssueNotes(al4.get(119));
        it.IstheIssueResolved(al4.get(120));
        it.ClickNext2();
        ac.AdditionalWait();
        ac.RefreshTab_Targetframe_IT();

        log.info("Created case for 'Technical Issue' Type is: " + ibdt.CaptureRelatedToCaseNumber());
        String TechnicalIssue = ibdt.CaptureRelatedToCaseNumber();
        if (CurrURL.contains("byjusprod.")) {
            while (TechnicalIssue.equalsIgnoreCase(AccountOwner)) {
                ac.AdditionalWait();
                ac.RefreshTab_Targetframe_IT();
            }
            TechnicalIssue = ibdt.CaptureRelatedToCaseNumber();
        }

        // Navigating to case to figure out the SLA
        ibdt.ClickRelatedToCaseNumber();
        ac.CloseSubTabs();

        // Creating Inbound Task //Step 76
        ac.ClickOpenActivitiestoNewTask();
        ncrt.SelectTaskRecordType("Inbound");
        ncrt.ClickNext();
        ncrt.ClickSave();
        ibdt.ClickCaptureDetail();
        ibdt.ClickProceedOptn();

        // BTC Issues - Sales Issue
        al4 = excelData.getData("TC8", "BLC", "Tcid");
        ibdt.SelectSpokeTo3(al3.get(1));
        it.PremiumidSelector();
        it.ProgramSelector();
        it.ClickNext();
        ibdt.SelectPSTCT(al3.get(2));
        ibdt.ClickNext();
        it.IssueCategory(al4.get(115));
        it.IssueSubCategory(al4.get(116));
        it.IssueType(al4.get(117));
        it.IssueSubType(al4.get(118));
        it.IssueNotes(al4.get(119));
        it.IstheIssueResolved(al4.get(120));
        it.ClickNext2();
        ac.AdditionalWait();
        ac.AdditionalWait();
        it.SSOandAccCombo();
        it.ClickFinish();
        ac.AdditionalWait();
        ac.RefreshTab_Targetframe_IT();

        log.info("Created case for 'Sales Issue' Type is: " + ibdt.CaptureRelatedToCaseNumber());
        String SalesIssue = ibdt.CaptureRelatedToCaseNumber();
        if (CurrURL.contains("byjusprod.")) {
            while (SalesIssue.equalsIgnoreCase(AccountOwner)) {
                ac.AdditionalWait();
                ac.RefreshTab_Targetframe_IT();
            }
            SalesIssue = ibdt.CaptureRelatedToCaseNumber();
        }

        // Navigating to case to figure out the SLA
        ibdt.ClickRelatedToCaseNumber();
        ac.CloseSubTabs();

        // Creating Inbound Task //Step 77
        ac.ClickOpenActivitiestoNewTask();
        ncrt.SelectTaskRecordType("Inbound");
        ncrt.ClickNext();
        ncrt.ClickSave();
        ibdt.ClickCaptureDetail();
        ibdt.ClickProceedOptn();

        // BTC Issues - Hardware Issue
        al4 = excelData.getData("TC7", "BLC", "Tcid");
        ibdt.SelectSpokeTo3(al3.get(1));
        it.PremiumidSelector();
        it.ProgramSelector();
        it.ClickNext();
        ibdt.SelectPSTCT(al3.get(2));
        ibdt.ClickNext();
        it.IssueCategory(al4.get(115));
        it.IssueSubCategory(al4.get(116));
        it.IssueType(al4.get(117));
        it.IssueSubType(al4.get(118));
        it.IssueNotes(al4.get(119));
        it.IstheIssueResolved(al4.get(120));
        it.ClickNext2();
        ac.AdditionalWait();
        ac.RefreshTab_Targetframe_IT();

        log.info("Created case for 'Hardware Issue' Type is: " + ibdt.CaptureRelatedToCaseNumber());
        String HardwareIssue = ibdt.CaptureRelatedToCaseNumber();
        if (CurrURL.contains("byjusprod.")) {
            while (HardwareIssue.equalsIgnoreCase(AccountOwner)) {
                ac.AdditionalWait();
                ac.RefreshTab_Targetframe_IT();
            }
            HardwareIssue = ibdt.CaptureRelatedToCaseNumber();
        }

        // Navigating to case to figure out the SLA
        ibdt.ClickRelatedToCaseNumber();
        ac.CloseSubTabs();

        // Creating Inbound Task //Step 78
        // ac.ClickOpenActivitiestoNewTask();
        // ncrt.SelectTaskRecordType("Inbound");
        // ncrt.ClickNext();
        // ncrt.ClickSave();
        // ibdt.ClickCaptureDetail();
        // ibdt.ClickProceedOptn();

        // BTC Issues - Refund Request Issue
        // al4 = excelData.getData("TC5", "BLC", "Tcid");
        // ibdt.SelectSpokeTo3(al3.get(1));
        // it.PremiumidSelector();
        // it.ProgramSelector();
        // it.ClickNext();
        /// ibdt.SelectPSTCT(al3.get(2));
        // ibdt.ClickNext();
        // it.IssueCategory(al4.get(115));
        // it.IssueSubCategory(al4.get(116));
        // it.IssueType(al4.get(117));
        // it.IssueSubType(al4.get(118));
        // it.IssueNotes(al4.get(119));
        // it.IstheIssueResolved(al4.get(120));
        // it.ClickNext2();
        // ac.AdditionalWait();
        // it.SSOandAccCombo();
        // it.ClickFinish();
        // ac.AdditionalWait();
        // ac.RefreshTab_Targetframe_IT();

        // log.info("Created case for 'Refund Request Issue' Type is:
        // "+ibdt.CaptureRelatedToCaseNumber());
        // String RefundRequestIssue= ibdt.CaptureRelatedToCaseNumber();
        // if(CurrURL.contains("byjusprod.")) {
        // while(RefundRequestIssue.equalsIgnoreCase(AccountOwner)) {
        // ac.AdditionalWait();
        // ac.RefreshTab_Targetframe_IT();
        // }
        // RefundRequestIssue= ibdt.CaptureRelatedToCaseNumber();
        // }

        // Navigating to case to figure out the SLA
        // ibdt.ClickRelatedToCaseNumber();
        // ac.CloseSubTabs();

        lo.Logouthome();
        ac.closeTabWindows();
        ac.goTo(AccountURL);
        ac.AdditionalWait();
        ac.ClickCasesMC2();

        // Verifying the Support Issue case TAT
        //cases.ClickCaseNo(SupportIssue);
        //cases.ClickBTCMilestone();
        //Assert.assertEquals(Integer.parseInt(cases.CaptureTargetResponseTime()) / 60, 24);
        //ac.CloseCurrentSubTab();
        //ac.CloseCurrentSubTab();

        // Verifying the Academic Issue case TAT
        cases.ClickCaseNo(AcademicIssue);
        cases.ClickBTCMilestone();
        ac.RefreshTab();
        Assert.assertEquals(Integer.parseInt(cases.CaptureTargetResponseTime()) / 60, 24);
        ac.CloseCurrentSubTab();
        ac.CloseCurrentSubTab();

        // Verifying the Technical Issue case TAT
        //cases.ClickCaseNo(TechnicalIssue);
        //cases.ClickBTCMilestone();
        //Assert.assertEquals(Integer.parseInt(cases.CaptureTargetResponseTime()) / 60, 24);
        //ac.CloseCurrentSubTab();
        //ac.CloseCurrentSubTab();

        // Verifying the Sales Issue case TAT
        cases.ClickCaseNo(SalesIssue);
        cases.ClickBTCMilestone();
        Assert.assertEquals(Integer.parseInt(cases.CaptureTargetResponseTime()) / 60, 48);
        ac.CloseCurrentSubTab();
        ac.CloseCurrentSubTab();

        // Verifying the Hardware Issue case TAT
        cases.ClickCaseNo(HardwareIssue);
        cases.ClickBTCMilestone();
        Assert.assertEquals(Integer.parseInt(cases.CaptureTargetResponseTime()) / 60, 24);
        ac.CloseCurrentSubTab();
        ac.CloseCurrentSubTab();

        // Verifying the Refund Request case TAT
        // cases.ClickCaseNo(RefundRequestIssue);
        // cases.ClickBTCMilestone();
        // Assert.assertEquals(Integer.parseInt(cases.CaptureTargetResponseTime())/60,24);
        // ac.CloseCurrentSubTab();
        // ac.CloseCurrentSubTab();

        String Mainwin = driver.getWindowHandle();
        // SFDC-3698
        // Login to Gmail

        gm.LoginGmail(al5.get(1), al5.get(2));
        String SecondWin = driver.getWindowHandle();

        // Verifying the mail received and created cases mail count
        // Assert.assertEquals(gm.CheckMailRecievedwithMailcount("btcsupport@byjus.com"),"5");

        // Verifying the Email content
        gm.VerifyEmailnCase("btcsupport@byjus.com", SupportIssue, "24", gm.EmailContent(SupportIssue, "24")); // Step
                                                                                                              // 97,
                                                                                                              // Step
                                                                                                              // 120
        gm.VerifyEmailnCase2("btcsupport@byjus.com", AcademicIssue, "24", gm.EmailContent(AcademicIssue, "24")); // Step
                                                                                                                 // 100
        gm.VerifyEmailnCase2("btcsupport@byjus.com", TechnicalIssue, "24", gm.EmailContent(TechnicalIssue, "24")); // Step
                                                                                                                   // 103
        gm.VerifyEmailnCase2("btcsupport@byjus.com", SalesIssue, "48", gm.EmailContent(SalesIssue, "48")); // Step 112
        gm.VerifyEmailnCase2("btcsupport@byjus.com", HardwareIssue, "24", gm.EmailContent(HardwareIssue, "24")); // Step
                                                                                                                 // 109

        // Changing the Status to resolved
        driver.switchTo().window(Mainwin);

        // Changing for Support Issue
        cases.ClickCaseNo(SupportIssue);
        cases.ChangeStatusValue("Resolved");
        cases.ChangeCaseOrigin("Email");
        cases.EnterResolutionResponsibility("Test");
        cases.ClickSave();
        ac.CloseCurrentSubTab();

        // Changing for Academic Issue
        cases.ClickCaseNo(AcademicIssue);
        cases.ChangeStatusValue("Resolved");
        cases.ChangeCaseOrigin("Email");
        cases.EnterResolutionResponsibility("Test");
        cases.ClickSave();
        ac.CloseCurrentSubTab();

        // Changing for Technical Issue
        cases.ClickCaseNo(TechnicalIssue);
        cases.ChangeStatusValue("Resolved");
        cases.ChangeCaseOrigin("Email");
        cases.EnterResolutionResponsibility("Test");
        cases.ClickSave();
        ac.CloseCurrentSubTab();

        // Changing for Hardware Issue
        cases.ClickCaseNo(HardwareIssue);
        cases.ChangeStatusValue("Closed");
        cases.ChangeCaseOrigin("Email");
        cases.EnterResolutionResponsibility("Test");
        cases.EnterReasonforClosing("Test");
        cases.ChangeActionTakenBy("Sales Team");
        cases.ClickSave();
        ac.CloseCurrentSubTab();

        // Verifying the Email content
        driver.switchTo().window(SecondWin);
        gm.VerifyEmailnCase("btcsupport@byjus.com", "", "", gm.ResolvedEmailContent(SupportIssue)); // Step 99
        gm.VerifyEmailnCase2("btcsupport@byjus.com", "", "", gm.ResolvedEmailContent(AcademicIssue)); // Step 102
        gm.VerifyEmailnCase2("btcsupport@byjus.com", "", "", gm.ResolvedEmailContent(TechnicalIssue)); // Step 105
        gm.VerifyEmailnCase2("btcsupport@byjus.com", "", "", gm.ResolvedEmailContent(HardwareIssue)); // Step 111 ,Step
                                                                                                      // 117

        // SFDC-3916
        // Verifying Reopen counter for Hardware Issue
        driver.switchTo().window(Mainwin);
        ac.RefreshTab();
        cases.ClickCaseNo(HardwareIssue);
        cases.ChangeStatusValue("Open");
        cases.ClickSave();
        ac.AdditionalWait();
        Assert.assertEquals(cases.CaptureReopenCount(), "1"); // Step 63
        ac.CloseCurrentSubTab();

        // Deleting the created cases
        cases.CloseAllCases();

        // SFDC-3122
        // Step 143,Step 144
        // Verify the Exam details are created successfully
        ac.CloseSubTabs();
        log.info("Sending the Assessment Submitted API");
        if (CurrURL.contains("--byjusuat")) {
            payLoad_BTLAwithBranchAccount.AssessmentSubmittedResponse_UAT();
            ac.AdditionalWait();
            ac.Scrollpagedown();
        } else {
            payLoad_BTLAwithBranchAccount.AssessmentSubmittedResponse_Prod();
            ac.AdditionalWait();
        }
        ed.RefreshTab();
        ac.ClickExamDetails();

        String Examid = ed.CaptureExamid();
        log.info("Exam id created for Assessment Submitted is: " + Examid);

        String RecordType = ed.CaptureRecordtypetext();
        Assert.assertEquals(RecordType, "Monthly Test Scheduled");

        ed.ClickExamid();

        log.info("Deleting the created Exam Detail Information");
        ed.DeleteExamDetailslastbtn();

        ed.NavExamInfo();
        // Step 145
        // Verify Monthly Submitted Exam detail is Created
        log.info("Sending the Monthly Test API");
        if (CurrURL.contains("--byjusuat")) {
            payLoad_BTLAwithBranchAccount.MonthlyTestResponse_UAT();
            ac.AdditionalWait();
        } else {
            payLoad_BTLAwithBranchAccount.MonthlyTestResponse_Prod();
            ac.AdditionalWait();
        }
        ed.RefreshTab();

        String Examid1 = ed.CaptureExamid();
        log.info("Exam id created for Monthly Test Submitted is: " + Examid1);

        String RecordType1 = ed.CaptureRecordtypetext();
        Assert.assertEquals(RecordType1, "Monthly Test Scheduled");

        ed.ClickExamid();

        log.info("Deleting the created Exam Detail Information");
        ed.DeleteExamDetailslastbtn();

        // Deleting created Account/payment details
        log.info("Deleting the Student Program details");
        ac.ClickAccOwnrTab();
        ac.DeleteCreatedStuProg();
        ac.DeleteAllCreatedStuPayment();
        ac.NavBackToAccount();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());

    }
    
    
    @Test(groups = { "Regression","sanity", "UAT" },dependsOnMethods = {"Test_Reg_BLC"}, enabled = true)
    public void Test_Reg_BLC1() throws Exception {
        proddummyuser = excelData.getData("TC1", "ProdDummyUser", "Tcid");
        String Accountid = null;
        loginPO lo = new loginPO(driver);
        al5 = excelData.getData("BTCTest", "Login", "Tcid");
        al2 = excelData.getData("PE User UATFC", "Login", "Type");
        // al2 = excelData.getData("BLC User UATFC", "Login", "Type");
        al3 = excelData.getData("Inbound", "Inbound", "Tcid");
        if (CurrURL.contains("--byjusuat")) {
            al = excelData.getData("TC1", "BLC", "Tcid");

            log.info("Logging in as Admin to UAT");
            lo.LoginAsAdmin_UAT();
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_BTLAwithBranchAccount2.AccountidCreationResponse_UAT(al.get(108));
            log.info("Launching the newly created Account id " + Accountid);

        } else {
            al = excelData.getData("TC2", "BLC", "Tcid");
            // al2 = excelData.getData("Collection Assistant", "Login", "Type");
            log.info("Logging in as Admin to Prod");
            lo.LoginAsAdmin_Prod();
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_BTLAwithBranchAccount2.AccountidCreationResponse_Prod(al.get(108));
            log.info("Launching the newly created Account id " + Accountid);
        }

        CreatedAccountPO ac = new CreatedAccountPO(driver);

        CasesPO cases = new CasesPO(driver);

        OpenActivitiesPO oa = new OpenActivitiesPO(driver);
        BLCIssueTaskPO bit = new BLCIssueTaskPO(driver);
        // Open the account by searching PID
        ac.closeTabWindows();
        ac.Notification();
        ac.NavBackToAccount();
        String AccountURL = CurrURL + Accountid;
        ac.goTo(AccountURL);
        ac.AccountLoadwait();
        String MainWin = driver.getWindowHandle();

        // SFDC-3871
        BLCPayload();

        ac.RefreshTab();
        ac.ClickOpenActivities();
        oa.SelectTaskNumber("BLC Issue Task", 1);// Step 80
        Assert.assertEquals("Inbound_PE_Arindam Das", bit.CaptureAssignedTo());// Step 80
        if (CurrURL.contains("--byjusuat")) {
            bit.AssignedTo(al2.get(1));
        } else {
            bit.AssignedTo(proddummyuser.get(1));
        }
        bit.ClickSave();
        ac.CloseSubTabs();

        // Changing Task owner to account owner
        if (CurrURL.contains("--byjusuat") || CurrURL.contains("--byjusuatfc")) {
            String AccountOwner = ac.AccOwnerCheck();
            if (!al2.get(1).equalsIgnoreCase(AccountOwner)) {
                ac.AssignAccount(al2.get(1));
            }
        } else {
            ac.AssignAccount("Testing User");
        }

        if (CurrURL.contains("--byjusuat") && !CurrURL.contains("--byjusuatfc")) {
            lo.SwitchUser(al2.get(1));
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AdditionalWait();
            ac.AdditionalWait();
        } else {
            lo.SwitchUsernProfile_Prod(proddummyuser.get(1), "PE");
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AdditionalWait();
        }

        ac.ClickOpenActivities();
        oa.SelectTaskNumber("BLC Issue Task", 1);

        // Performing Capture call Detail
        bit.ClickCaptureDetail();
        bit.SelectProceed();
        bit.ClickNext();

        // Click Next to move from Troubleshooting manual pop up
        bit.ClickNext();

        // Verify mandate check for 'Is there an issue?' and Comments
        bit.ClickNext();
        Assert.assertEquals(bit.CaptureError_ITAI(), bit.EM_ITAI());
        Assert.assertEquals(bit.CaptureError_Comments(), bit.EM_Comments());

        bit.SelectIsThereAnIssue("Yes");
        // Verify mandate check for Is the Issue Resolved?
        bit.ClickNext();
        Assert.assertEquals(bit.CaptureError_ITIR(), bit.EM_ITIR());

        bit.SelectIsTheIssueResolved("Yes");
        bit.EnterComments("Test");
        bit.ClickNext();
        ac.AdditionalWait();

        ac.AdditionalWait();
        ac.RefreshTab();
        Assert.assertEquals(bit.CaptureStatus(), "Completed");

        // Navigate to case
        bit.ClickRelatedToCaseNumber();
        Assert.assertEquals(cases.CaptureStatus(), "Closed");

        lo.OnlyLogout();
        ac.goTo(AccountURL);
        ac.AdditionalWait();

        ac.ClickCasesMC2();
        cases.CloseAllCases();

        // Deleting created Account/payment details
        log.info("Deleting the Student Program details");
        ac.ClickAccOwnrTab();
        ac.DeleteCreatedStuProg();
        ac.DeleteAllCreatedStuPayment();
        ac.NavBackToAccount();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
        driver.close();
        driver.switchTo().window(MainWin);
        // *****************************************************************************//
        // ac.CloseSubTabs();
        // ac.ClickCasesMC();
        // cases.CloseAllCases();
        // ac.CloseSubTabs();
        al2 = excelData.getData("Mentor User UAT", "Login", "Type");
        if (CurrURL.contains("--byjusuat")) {
            al = excelData.getData("TC1", "BLC", "Tcid");
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_BTLAwithBranchAccount2.AccountidCreationResponse_UAT(al.get(108));
            log.info("Launching the newly created Account id " + Accountid);

        } else {
            al = excelData.getData("TC2", "BLC", "Tcid");
            // al2 = excelData.getData("Collection Assistant", "Login", "Type");
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_BTLAwithBranchAccount2.AccountidCreationResponse_Prod(al.get(108));
            log.info("Launching the newly created Account id " + Accountid);
        }

        // Open the account by searching PID
        ac.closeTabWindows();
        ac.Notification();
        ac.NavBackToAccount();
        AccountURL = CurrURL + Accountid;
        ac.goTo(AccountURL);
        ac.AccountLoadwait();

        BLCPayload();
        ac.RefreshTab();
        ac.ClickOpenActivities();
        oa.SelectTaskNumber("BLC Issue Task", 1);// Step 80
        Assert.assertEquals("Inbound_PE_Arindam Das", bit.CaptureAssignedTo());// Step 80
        if (CurrURL.contains("--byjusuat")) {
            bit.AssignedTo(al2.get(1));
        } else {
            bit.AssignedTo(proddummyuser.get(1));
        }
        bit.ClickSave();
        ac.CloseSubTabs();

        // Changing Task owner to account owner
        if (CurrURL.contains("--byjusuat") || CurrURL.contains("--byjusuatfc")) {
            String AccountOwner = ac.AccOwnerCheck();
            if (!al2.get(1).equalsIgnoreCase(AccountOwner)) {
                ac.AssignAccount(al2.get(1));
            }
        } else {
            ac.AssignAccount("Testing User");
        }

        if (CurrURL.contains("--byjusuat") && !CurrURL.contains("--byjusuatfc")) {
            lo.SwitchUser(al2.get(1));
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AdditionalWait();
            ac.AdditionalWait();
        } else {
            lo.SwitchUsernProfile_Prod(proddummyuser.get(1), "Mentor");
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AdditionalWait();
            ac.AdditionalWait();
        }

        // ac.RefreshTab();
        ac.ClickOpenActivities();
        oa.SelectTaskNumber("BLC Issue Task", 1);

        // Performing Capture call Detail
        bit.ClickCaptureDetail();
        bit.SelectProceed();
        bit.ClickNext();

        // Click Next to move from Troubleshooting manual pop up
        bit.ClickNext();

        bit.SelectIsThereAnIssue("Yes");
        bit.SelectIsTheIssueResolved("No");
        bit.EnterComments("Test");
        bit.ClickNext();
        ac.AdditionalWait();

        ac.RefreshTab();
        Assert.assertEquals(bit.CaptureStatus(), "Completed");

        // Navigate to case
        bit.ClickRelatedToCaseNumber();
        Assert.assertEquals(cases.CaptureStatus(), "Open");

        lo.OnlyLogout();
        ac.goTo(AccountURL);
        ac.AdditionalWait();

        ac.ClickCasesMC2();
        cases.CloseAllCases();

        // Deleting created Account/payment details
        log.info("Deleting the Student Program details");
        ac.ClickAccOwnrTab();
        ac.DeleteCreatedStuProg();
        ac.DeleteAllCreatedStuPayment();
        ac.NavBackToAccount();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
        driver.close();
        driver.switchTo().window(MainWin);
        // *****************************************************************************//

        if (CurrURL.contains("--byjusuat")) {
            al = excelData.getData("TC1", "BLC", "Tcid");
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_BTLAwithBranchAccount2.AccountidCreationResponse_UAT(al.get(108));
            log.info("Launching the newly created Account id " + Accountid);

        } else {
            al = excelData.getData("TC2", "BLC", "Tcid");
            // al2 = excelData.getData("Collection Assistant", "Login", "Type");
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_BTLAwithBranchAccount2.AccountidCreationResponse_Prod(al.get(108));
            log.info("Launching the newly created Account id " + Accountid);
        }

        // Open the account by searching PID
        ac.closeTabWindows();
        ac.Notification();
        ac.NavBackToAccount();
        AccountURL = CurrURL + Accountid;
        ac.goTo(AccountURL);
        ac.AccountLoadwait();

        BLCPayload();

        ac.RefreshTab();
        ac.ClickOpenActivities();
        oa.SelectTaskNumber("BLC Issue Task", 1);

        // Performing Capture call Detail
        bit.ClickCaptureDetail();
        bit.SelectProceed();
        bit.ClickNext();

        // Click Next to move from Troubleshooting manual pop up
        bit.ClickNext();

        bit.SelectIsThereAnIssue("No");
        bit.EnterComments("Test");
        bit.ClickNext();
        ac.AdditionalWait();

        ac.RefreshTab();
        Assert.assertEquals(bit.CaptureStatus(), "Completed");

        // Deleting the created case

        ac.CloseSubTabs();
        ac.ClickCasesMC();
        cases.CloseAllCases();
        ac.CloseSubTabs();
        // Deleting created Account/payment details
        log.info("Deleting the Student Program details");
        ac.ClickAccOwnrTab();
        ac.DeleteCreatedStuProg();
        ac.DeleteAllCreatedStuPayment();
        ac.NavBackToAccount();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());

    }

    public void BLCPayload() throws InterruptedException {
        CreatedAccountPO ac = new CreatedAccountPO(driver);
        if (CurrURL.contains("--byjusuat")) {
            payLoad_BTLAwithBranchAccount2.BLCIssueTask_UAT();
            ac.AdditionalWait();
        } else {
            payLoad_BTLAwithBranchAccount2.BLCIssueTask_Prod();
            ac.AdditionalWait();
        }
    }

 
    @AfterMethod(alwaysRun = true)
    public void teardown() throws InterruptedException {

         driver.quit();

        // Thread.sleep(2000);
    }

}
