package testCases_Reg;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pageObjects.BLCClassesTaskPO;
import pageObjects.CreatedAccountPO;
import pageObjects.OpenActivitiesPO;
import pageObjects.SessionsInformationPO;
import pageObjects.loginPO;
import payLoad.payLoad_BTLAwithBranchAccount3;
import payLoad.payLoad_BTLAwithBranchAccount4;
import resources.ExcelData;
import resources.base;

public class test_Reg_BLC_Rolling7day extends base {

    public WebDriver driver;
    // public String CurrURL;
    public static Logger log = LogManager.getLogger(test_Reg_BLC_Rolling7day.class.getName());
    ExcelData excelData = new ExcelData();
    ArrayList<String> proddummyuser = new ArrayList<String>();
    ArrayList<String> al = new ArrayList<String>();
    ArrayList<String> al2 = new ArrayList<String>();
    ArrayList<String> al3 = new ArrayList<String>();
    ArrayList<String> al4 = new ArrayList<String>();
    ArrayList<String> al5 = new ArrayList<String>();

    @BeforeMethod(alwaysRun = true)
    public void initialize() throws IOException, InterruptedException {

        driver = initializeDriver();

    }

    @Test(groups = { "Regression", "UAT" ,"sanity"}, priority =1,enabled = true)
    public void Test_Reg_BLC_Rolling7day_0() throws Exception {
        proddummyuser = excelData.getData("TC1", "ProdDummyUser", "Tcid");
        String Accountid = null;
        loginPO lo = new loginPO(driver);
        al5 = excelData.getData("BTCTest", "Login", "Tcid");
        al2 = excelData.getData("BLC User UAT1", "Login", "Type");
        al3 = excelData.getData("Inbound", "Inbound", "Tcid");
        if (CurrURL.contains("--byjusuat")) {
            al = excelData.getData("TC1", "BLC", "Tcid");

            log.info("Logging in as Admin to UAT");
            lo.LoginAsAdmin_UAT1();
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_BTLAwithBranchAccount3.AccountidCreationResponse_UAT(al.get(108));
            log.info("Launching the newly created Account id " + Accountid);

        } else {
            al = excelData.getData("TC2", "BLC", "Tcid");
            // al2 = excelData.getData("Collection Assistant", "Login", "Type");
            log.info("Logging in as Admin to Prod");
            lo.LoginAsAdmin_Prod();
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_BTLAwithBranchAccount3.AccountidCreationResponse_Prod(al.get(108));
            log.info("Launching the newly created Account id " + Accountid);
        }

        CreatedAccountPO ac = new CreatedAccountPO(driver);
   
        BLCClassesTaskPO bct = new BLCClassesTaskPO(driver);

        OpenActivitiesPO oa = new OpenActivitiesPO(driver);
        SessionsInformationPO si = new SessionsInformationPO(driver);
        // Open the account by searching PID
        ac.closeTabWindows();
        ac.AdditionalWait();
        ac.Notification();
        ac.NavBackToAccount();
        String AccountURL = CurrURL + Accountid;
        ac.goTo(AccountURL);
        ac.AccountLoadwait();

        // ************SFDC-3727******************//
        SessionMissedAPI("20");

        ac.ClickOpenActivities();
        oa.SelectTaskNumber("BLC Classes - Needs Attention", 1);// Step 2

        bct.ClickCaptureDetail();
        bct.ClickProceedOptn();
        bct.SelectWillyoubejoiningtheclass(al.get(125));
        bct.ClickNext();
        bct.ClickNext();

        // Verifying the Fields (Reason for not attending class, Comments, When will the
        // student attend the next class?) are mandatory with correct error messages
        Assert.assertEquals(bct.CaptureError_RFNAC(), bct.EM_RFNAC());
        Assert.assertEquals(bct.CaptureError_WWSATNC(), bct.EM_WWSATNC());
        Assert.assertEquals(bct.CaptureError_Comments(), bct.EM_Comments());

        // Setting 'Will you be joining the class?' to Yes
        bct.SelectWillyoubejoiningtheclass(al.get(103));
        bct.ClickNext();
        ac.RefreshTab_Targetframe_IT();
        Assert.assertEquals(bct.CaptureStatus(), "Open");

        // Passing Session Missed API again to see the task closes
        SessionMissedAPI("20");

        ac.AdditionalWait();
        // ac.RefreshTab_Targetframe_IT();
        // Assert.assertEquals(bct.CaptureStatus(), "Closed");

        // Deleting the Task and Session Information
        ac.CloseCurrentSubTab();
        oa.DeleteSelectedTask_OpenActivities("BLC Classes - Needs Attention");
        ac.CloseSubTabs();
        ac.RefreshTab();
        si.ClickSessionid_UAT2();
        si.DeleteSessionInfolastbtn();

        // Passing Session Missed API to set 'Will you be joining the class?' to No
        BLCClassCommonFlow("20", al.get(126), al.get(127),"BLC Classes - Needs Attention");

        // Passing Session Missed API to check DNP counter
        SessionMissedAPI("20");

        ac.ClickOpenActivities();
        oa.SelectTaskNumber("BLC Classes - Needs Attention", 1);
        Assert.assertEquals(bct.CaptureDNPCounter(), "0");

        bct.ClickCaptureDetail();
        bct.SelectDNP();
        bct.ClickFinish();
        ac.RefreshTab_Targetframe();
        Assert.assertEquals(bct.CaptureDNPCounter(), "1");

        bct.ClickCaptureDetail();
        bct.SelectDNP();
        bct.ClickFinish();
        ac.RefreshTab_Targetframe();
        Assert.assertEquals(bct.CaptureDNPCounter(), "2");

        bct.ClickCaptureDetail();
        bct.SelectDNP();
        bct.ClickFinish();
        ac.RefreshTab_Targetframe();
        Assert.assertEquals(bct.CaptureDNPCounter(), "3");

        Assert.assertEquals(bct.CaptureStatus(), "Completed");

        // Deleting Session Information
        ac.CloseSubTabs();
        ac.RefreshTab();
        si.ClickSessionid_UAT2();
        si.DeleteSessionInfolastbtn();

        // Deleting the Completed Task
        ac.ClickActivityHistory();
        oa.DeleteSelectedTask_ActivityHistory("BLC Classes - Needs Attention");
        ac.CloseSubTabs();

        // Passing Session Missed API to check Callback Requested
        SessionMissedAPI("20");

        ac.ClickOpenActivities();
        oa.SelectTaskNumber("BLC Classes - Needs Attention", 1);
        bct.ClickCaptureDetail();
        if (CurrURL.contains("--byjusuat")) {
            bct.ClickCallBackRequested();
        } else {
            bct.ClickCallBackRequested_MMddYYYY();
        }
        bct.ClickFinish();
        ac.RefreshTab_Targetframe();
        Assert.assertEquals(bct.CaptureStatus(), "Open");

        // Deleting the Task and Session Information
        ac.CloseCurrentSubTab();
        oa.DeleteSelectedTask_OpenActivities("BLC Classes - Needs Attention");
        ac.CloseSubTabs();
        ac.RefreshTab();
        si.ClickSessionid_UAT2();
        si.DeleteSessionInfolastbtn();

        // Passing Session Missed API to check Callback Requested
        SessionMissedAPI("20");

        // Changing owner to BLC user
        if (CurrURL.contains("--byjusuat") || CurrURL.contains("--byjusuatfc")) {
            String AccountOwner = ac.AccOwnerCheck();
            if (!al2.get(1).equalsIgnoreCase(AccountOwner)) {
                ac.AssignAccount(al2.get(1));
            }
        } else {
            ac.AssignAccount("Testing User");
        }

        // Logging in as BLC user
        if (CurrURL.contains("--byjusuat") && !CurrURL.contains("--byjusuatfc")) {
            lo.SwitchUser(al2.get(1));
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AccountLoadwait();
        } else {
            lo.SwitchUsernProfile_Prod(proddummyuser.get(1), "BLC Counsellor");
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AccountLoadwait();

        }

        ac.ClickOpenActivities();
        oa.SelectTaskNumber("BLC Classes - Needs Attention", 1);
        bct.ClickCaptureDetail();
        bct.ClickCallBackRequested_MMddYYYY();
        bct.ClickFinish();
        ac.RefreshTab_Targetframe();
        Assert.assertEquals(bct.CaptureStatus(), "Open");

        // Now setting 'Will you be joining the class?' to No
        bct.ClickCaptureDetail();
        bct.ClickProceedOptn();
        bct.SelectWillyoubejoiningtheclass(al.get(125));
        bct.SelectReasonfornotattending(al.get(126));
        bct.SelectSubReasonForNotAttending(al.get(127));
        bct.EnterComments(al.get(150));
        bct.EnterWhenWillStudentAttendNxtClass_MMddYYYY();
        bct.ClickNext();
        bct.SelectReasonfornotattending(al.get(126));
        bct.SelectSubReasonForNotAttending(al.get(127));
        bct.ClickNext();
        bct.ClickFinish();

        ac.RefreshTab_Targetframe_IT();
        Assert.assertEquals(bct.CaptureStatus(), "Completed");

        lo.OnlyLogout();
        ac.goTo(AccountURL);
        ac.AdditionalWait();
        ac.AdditionalWait();
        ac.ClickActivityHistory_Scroll();
        oa.DeleteSelectedTask_ActivityHistory("BLC Classes - Needs Attention");
        ac.CloseSubTabs();

        // Deleting Session Information
        si.ClickSessionid_UAT2();
        si.DeleteSessionInfolastbtn();

        // Passing Session Missed API for Reason for not attending class - Technical and
        // Sub reason for not attending class - Link not working
        BLCClassCommonFlow("20", al.get(126), al.get(128),"BLC Classes - Needs Attention");

        // Passing Session Missed API for Reason for not attending class - Sales Issue
        // and Sub reason for not attending class - Distance from the Centre
        BLCClassCommonFlow("20", al.get(129), al.get(130),"BLC Classes - Needs Attention");

        // Passing Session Missed API for Reason for not attending class - Sales Issue
        // and Sub reason for not attending class - Wrongly communicated that all
        // classes will be offline
        BLCClassCommonFlow("20", al.get(129), al.get(131),"BLC Classes - Needs Attention");

        // Passing Session Missed API for Reason for not attending class - Sales Issue
        // and Sub reason for not attending class - Time table mismatch
        BLCClassCommonFlow("20", al.get(129), al.get(132),"BLC Classes - Needs Attention");

        // Passing Session Missed API for Reason for not attending class - Service Issue
        // and Sub reason for not attending class - Change of Centre
        ac.AdditionalWait();
        BLCClassCommonFlow("20", al.get(133), al.get(134),"BLC Classes - Needs Attention");

        // Passing Session Missed API for Reason for not attending class - Service Issue
        // and Sub reason for not attending class - Logistics issue
        BLCClassCommonFlow("20", al.get(133), al.get(135),"BLC Classes - Needs Attention");

        // Passing Session Missed API for Reason for not attending class - Financial
        // Issue and Sub reason for not attending class - Affordability issue
        BLCClassCommonFlow("20", al.get(136), al.get(137),"BLC Classes - Needs Attention");

        // Passing Session Missed API for Reason for not attending class - Financial
        // Issue and Sub reason for not attending class - EMI tenure
        BLCClassCommonFlow("20", al.get(136), al.get(138),"BLC Classes - Needs Attention");

        // Passing Session Missed API for Reason for not attending class - Financial
        // Issue and Sub reason for not attending class - Loan processed without consent
        BLCClassCommonFlow("20", al.get(136), al.get(139),"BLC Classes - Needs Attention");

        // Passing Session Missed API for Reason for not attending class - Personal
        // Issue and Sub reason for not attending class - Medical issue
        ac.AdditionalWait();
        BLCClassCommonFlow("20", al.get(140), al.get(141),"BLC Classes - Needs Attention");

        // Passing Session Missed API for Reason for not attending class - Personal
        // Issue and Sub reason for not attending class - Covid related
        BLCClassCommonFlow("20", al.get(140), al.get(142),"BLC Classes - Needs Attention");

        // Passing Session Missed API for Reason for not attending class - Personal
        // Issue and Sub reason for not attending class - Relocation issue
        BLCClassCommonFlow("20", al.get(140), al.get(143),"BLC Classes - Needs Attention");

        // Passing Session Missed API for Reason for not attending class - Non
        // Contactable and Sub reason for not attending class - Non contactable
        BLCClassCommonFlow("20", al.get(144), al.get(145),"BLC Classes - Needs Attention");

        // Passing Session Missed API for Reason for not attending class - Non
        // Contactable and Sub reason for not attending class - Wrong number
        BLCClassCommonFlow("20", al.get(144), al.get(146),"BLC Classes - Needs Attention");

        // Passing Session Missed API for Reason for not attending class - Academic and
        // Sub reason for not attending class - Content issue
        BLCClassCommonFlow("20", al.get(147), al.get(148),"BLC Classes - Needs Attention");

        // Passing Session Missed API for Reason for not attending class - Academic and
        // Sub reason for not attending class - School Exams
        BLCClassCommonFlow("20", al.get(147), al.get(149),"BLC Classes - Needs Attention");

        // Deleting created Account/payment details
        log.info("Deleting the Student Program details");
        ac.ClickAccOwnrTab();
        ac.DeleteCreatedStuProg();
        ac.DeleteAllCreatedStuPayment();
        ac.NavBackToAccount();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());

    }
    
    @Test(groups = { "Regression", "UAT" ,"sanity"},dependsOnMethods = {"Test_Reg_BLC_Rolling7day_0"}, enabled = true)
    public void Test_Reg_BLC_Rolling7day_20() throws Exception {
        proddummyuser = excelData.getData("TC1", "ProdDummyUser", "Tcid");
        String Accountid = null;
        loginPO lo = new loginPO(driver);
        al5 = excelData.getData("BTCTest", "Login", "Tcid");
        al2 = excelData.getData("BLC User UAT1", "Login", "Type");
        al3 = excelData.getData("Inbound", "Inbound", "Tcid");
        if (CurrURL.contains("--byjusuat")) {
            al = excelData.getData("TC1", "BLC", "Tcid");

            log.info("Logging in as Admin to UAT");
            lo.LoginAsAdmin_UAT1();
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_BTLAwithBranchAccount4.AccountidCreationResponse_UAT(al.get(108));
            log.info("Launching the newly created Account id " + Accountid);

        } else {
            al = excelData.getData("TC2", "BLC", "Tcid");
            // al2 = excelData.getData("Collection Assistant", "Login", "Type");
            log.info("Logging in as Admin to Prod");
            lo.LoginAsAdmin_Prod();
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_BTLAwithBranchAccount4.AccountidCreationResponse_Prod(al.get(108));
            log.info("Launching the newly created Account id " + Accountid);
        }

        CreatedAccountPO ac = new CreatedAccountPO(driver);




        BLCClassesTaskPO bct = new BLCClassesTaskPO(driver);

        OpenActivitiesPO oa = new OpenActivitiesPO(driver);

        SessionsInformationPO si = new SessionsInformationPO(driver);
        // Open the account by searching PID
        ac.closeTabWindows();
        ac.Notification();
        ac.NavBackToAccount();
        String AccountURL = CurrURL + Accountid;
        ac.goTo(AccountURL);
        ac.AccountLoadwait();

        // Passing Session Missed API to check DNP counter
        SessionMissedAPI2("0");

        ac.ClickOpenActivities();
        oa.SelectTaskNumber("BLC Classes - Needs Attention (No attendance in past 7 days)", 1);
        Assert.assertEquals(bct.CaptureDNPCounter(), "0");

        bct.ClickCaptureDetail();
        bct.SelectDNP();
        bct.ClickFinish();
        ac.RefreshTab_Targetframe();
        Assert.assertEquals(bct.CaptureDNPCounter(), "1");

        bct.ClickCaptureDetail();
        bct.SelectDNP();
        bct.ClickFinish();
        ac.RefreshTab_Targetframe();
        Assert.assertEquals(bct.CaptureDNPCounter(), "2");

        bct.ClickCaptureDetail();
        bct.SelectDNP();
        bct.ClickFinish();
        ac.RefreshTab_Targetframe();
        Assert.assertEquals(bct.CaptureDNPCounter(), "3");

        Assert.assertEquals(bct.CaptureStatus(), "Completed");

        // Deleting Session Information
        ac.CloseSubTabs();
        ac.RefreshTab();
        si.ClickSessionid_UAT2();
        si.DeleteSessionInfolastbtn();

        // Deleting the Completed Task
        ac.ClickActivityHistory();
        oa.DeleteSelectedTask_ActivityHistory("BLC Classes - Needs Attention (No attendance in past 7 days)");
        ac.CloseSubTabs();

        // Passing Session Missed API to check Callback Requested
        SessionMissedAPI2("0");

        ac.ClickOpenActivities();
        oa.SelectTaskNumber("BLC Classes - Needs Attention (No attendance in past 7 days)", 1);
        bct.ClickCaptureDetail();
        if (CurrURL.contains("--byjusuat")) {
            bct.ClickCallBackRequested();
        } else {
            bct.ClickCallBackRequested_MMddYYYY();
        }
        bct.ClickFinish();
        ac.RefreshTab_Targetframe();
        Assert.assertEquals(bct.CaptureStatus(), "Open");

        // Deleting the Task and Session Information
        ac.CloseCurrentSubTab();
        oa.DeleteSelectedTask_OpenActivities("BLC Classes - Needs Attention (No attendance in past 7 days)");
        ac.CloseSubTabs();
        ac.RefreshTab();
        si.ClickSessionid_UAT2();
        si.DeleteSessionInfolastbtn();

        // Passing Session Missed API to check Callback Requested
        SessionMissedAPI2("0");

        // Changing owner to BLC user
        if (CurrURL.contains("--byjusuat") || CurrURL.contains("--byjusuatfc")) {
            String AccountOwner = ac.AccOwnerCheck();
            if (!al2.get(1).equalsIgnoreCase(AccountOwner)) {
                ac.AssignAccount(al2.get(1));
            }
        } else {
            ac.AssignAccount("Testing User");
        }

        // Logging in as BLC user
        if (CurrURL.contains("--byjusuat") && !CurrURL.contains("--byjusuatfc")) {
            lo.SwitchUser(al2.get(1));
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AccountLoadwait();
        } else {
            lo.SwitchUsernProfile_Prod(proddummyuser.get(1), "BLC Counsellor");
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AccountLoadwait();

        }

        ac.ClickOpenActivities();
        oa.SelectTaskNumber("BLC Classes - Needs Attention (No attendance in past 7 days)", 1);
        bct.ClickCaptureDetail();
        bct.ClickCallBackRequested_MMddYYYY();
        bct.ClickFinish();
        ac.RefreshTab_Targetframe();
        Assert.assertEquals(bct.CaptureStatus(), "Open");

        // Now setting 'Will you be joining the class?' to No
        bct.ClickCaptureDetail();
        bct.ClickProceedOptn();
        bct.SelectWillyoubejoiningtheclass(al.get(125));
        bct.SelectReasonfornotattending(al.get(126));
        bct.SelectSubReasonForNotAttending(al.get(127));
        bct.EnterComments(al.get(150));
        bct.EnterWhenWillStudentAttendNxtClass_MMddYYYY();
        bct.ClickNext();
        bct.SelectReasonfornotattending(al.get(126));
        bct.SelectSubReasonForNotAttending(al.get(127));
        bct.ClickNext();
        bct.ClickFinish();

        ac.RefreshTab_Targetframe_IT();
        Assert.assertEquals(bct.CaptureStatus(), "Completed");

        lo.OnlyLogout();
        ac.goTo(AccountURL);
        ac.AdditionalWait();
        ac.ClickActivityHistory_Scroll();
        oa.DeleteSelectedTask_ActivityHistory("BLC Classes - Needs Attention (No attendance in past 7 days)");
        ac.CloseSubTabs();

        // Deleting Session Information
        si.ClickSessionid_UAT2();
        si.DeleteSessionInfolastbtn();

        // Passing Session Missed API for Reason for not attending class - Technical and
        // Sub reason for not attending class - Link not working
        BLCClassCommonFlow2("0", al.get(126), al.get(128),"BLC Classes - Needs Attention (No attendance in past 7 days)");

        // Passing Session Missed API for Reason for not attending class - Sales Issue
        // and Sub reason for not attending class - Distance from the Centre
        BLCClassCommonFlow2("0", al.get(129), al.get(130),"BLC Classes - Needs Attention (No attendance in past 7 days)");

        // Passing Session Missed API for Reason for not attending class - Sales Issue
        // and Sub reason for not attending class - Wrongly communicated that all
        // classes will be offline
        BLCClassCommonFlow2("0", al.get(129), al.get(131),"BLC Classes - Needs Attention (No attendance in past 7 days)");

        // Passing Session Missed API for Reason for not attending class - Sales Issue
        // and Sub reason for not attending class - Time table mismatch
        BLCClassCommonFlow2("0", al.get(129), al.get(132),"BLC Classes - Needs Attention (No attendance in past 7 days)");

        // Passing Session Missed API for Reason for not attending class - Service Issue
        // and Sub reason for not attending class - Change of Centre
        BLCClassCommonFlow2("0", al.get(133), al.get(134),"BLC Classes - Needs Attention (No attendance in past 7 days)");

        // Passing Session Missed API for Reason for not attending class - Service Issue
        // and Sub reason for not attending class - Logistics issue
        BLCClassCommonFlow2("0", al.get(133), al.get(135),"BLC Classes - Needs Attention (No attendance in past 7 days)");

        // Passing Session Missed API for Reason for not attending class - Financial
        // Issue and Sub reason for not attending class - Affordability issue
        BLCClassCommonFlow2("0", al.get(136), al.get(137),"BLC Classes - Needs Attention (No attendance in past 7 days)");

        // Passing Session Missed API for Reason for not attending class - Financial
        // Issue and Sub reason for not attending class - EMI tenure
        BLCClassCommonFlow2("0", al.get(136), al.get(138),"BLC Classes - Needs Attention (No attendance in past 7 days)");

        // Passing Session Missed API for Reason for not attending class - Financial
        // Issue and Sub reason for not attending class - Loan processed without consent
        BLCClassCommonFlow2("0", al.get(136), al.get(139),"BLC Classes - Needs Attention (No attendance in past 7 days)");

        // Passing Session Missed API for Reason for not attending class - Personal
        // Issue and Sub reason for not attending class - Medical issue
        BLCClassCommonFlow2("0", al.get(140), al.get(141),"BLC Classes - Needs Attention (No attendance in past 7 days)");

        // Passing Session Missed API for Reason for not attending class - Personal
        // Issue and Sub reason for not attending class - Covid related
        BLCClassCommonFlow2("0", al.get(140), al.get(142),"BLC Classes - Needs Attention (No attendance in past 7 days)");

        // Passing Session Missed API for Reason for not attending class - Personal
        // Issue and Sub reason for not attending class - Relocation issue
        BLCClassCommonFlow2("0", al.get(140), al.get(143),"BLC Classes - Needs Attention (No attendance in past 7 days)");

        // Passing Session Missed API for Reason for not attending class - Non
        // Contactable and Sub reason for not attending class - Non contactable
        BLCClassCommonFlow2("0", al.get(144), al.get(145),"BLC Classes - Needs Attention (No attendance in past 7 days)");

        // Passing Session Missed API for Reason for not attending class - Non
        // Contactable and Sub reason for not attending class - Wrong number
        BLCClassCommonFlow2("0", al.get(144), al.get(146),"BLC Classes - Needs Attention (No attendance in past 7 days)");

        // Passing Session Missed API for Reason for not attending class - Academic and
        // Sub reason for not attending class - Content issue
        BLCClassCommonFlow2("0", al.get(147), al.get(148),"BLC Classes - Needs Attention (No attendance in past 7 days)");

        // Passing Session Missed API for Reason for not attending class - Academic and
        // Sub reason for not attending class - School Exams
        BLCClassCommonFlow2("0", al.get(147), al.get(149),"BLC Classes - Needs Attention (No attendance in past 7 days)");

        // Deleting created Account/payment details
        log.info("Deleting the Student Program details");
        ac.ClickAccOwnrTab();
        ac.DeleteCreatedStuProg();
        ac.DeleteAllCreatedStuPayment();
        ac.NavBackToAccount();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());

    }

    public void BLCClassCommonFlow(String rolling7day, String Reasonfornotattending, String SubReasonForNotAttending, String Tasktype)
            throws Exception {
        al = excelData.getData("TC1", "BLC", "Tcid");
        SessionMissedAPI(rolling7day);
        CreatedAccountPO ac = new CreatedAccountPO(driver);
        OpenActivitiesPO oa = new OpenActivitiesPO(driver);
        SessionsInformationPO si = new SessionsInformationPO(driver);
        BLCClassesTaskPO bct = new BLCClassesTaskPO(driver);
        ac.ClickOpenActivities();
        oa.SelectTaskNumber(Tasktype, 1);
        bct.ClickCaptureDetail();
        bct.ClickProceedOptn();
        bct.SelectWillyoubejoiningtheclass(al.get(125));
        bct.SelectReasonfornotattending(Reasonfornotattending);
        bct.SelectSubReasonForNotAttending(SubReasonForNotAttending);
        bct.EnterComments(al.get(150));
        if (CurrURL.contains("byjusprod.")) {
            bct.EnterWhenWillStudentAttendNxtClass_MMddYYYY();
        } else {
            bct.EnterWhenWillStudentAttendNxtClass();
        }

        bct.ClickNext();
        bct.SelectReasonfornotattending(Reasonfornotattending);
        bct.SelectSubReasonForNotAttending(SubReasonForNotAttending);
        bct.ClickNext();
        bct.ClickFinish();

        ac.RefreshTab_Targetframe_IT();
        Assert.assertEquals(bct.CaptureStatus(), "Completed");

        // Deleting Session Information
        ac.CloseSubTabs();
        ac.AdditionalWait();
        ac.RefreshTab();
        si.ClickSessionid_UAT2();
        si.DeleteSessionInfolastbtn();

        // Deleting the Completed Task
        ac.ClickActivityHistory();
        oa.DeleteSelectedTask_ActivityHistory(Tasktype);
        ac.CloseSubTabs();
    }
    
    public void BLCClassCommonFlow2(String rolling7day, String Reasonfornotattending, String SubReasonForNotAttending, String Tasktype)
            throws Exception {
        al = excelData.getData("TC1", "BLC", "Tcid");
        SessionMissedAPI2(rolling7day);
        CreatedAccountPO ac = new CreatedAccountPO(driver);
        OpenActivitiesPO oa = new OpenActivitiesPO(driver);
        SessionsInformationPO si = new SessionsInformationPO(driver);
        BLCClassesTaskPO bct = new BLCClassesTaskPO(driver);
        ac.ClickOpenActivities();
        oa.SelectTaskNumber(Tasktype, 1);
        bct.ClickCaptureDetail();
        bct.ClickProceedOptn();
        bct.SelectWillyoubejoiningtheclass(al.get(125));
        bct.SelectReasonfornotattending(Reasonfornotattending);
        bct.SelectSubReasonForNotAttending(SubReasonForNotAttending);
        bct.EnterComments(al.get(150));
        if (CurrURL.contains("byjusprod.")) {
            bct.EnterWhenWillStudentAttendNxtClass_MMddYYYY();
        } else {
            bct.EnterWhenWillStudentAttendNxtClass();
        }

        bct.ClickNext();
        bct.SelectReasonfornotattending(Reasonfornotattending);
        bct.SelectSubReasonForNotAttending(SubReasonForNotAttending);
        bct.ClickNext();
        bct.ClickFinish();

        ac.RefreshTab_Targetframe_IT();
        ac.AdditionalWait();
        Assert.assertEquals(bct.CaptureStatus(), "Completed");

        // Deleting Session Information
        ac.CloseSubTabs();
        ac.RefreshTab();
        si.ClickSessionid_UAT2();
        si.DeleteSessionInfolastbtn();

        // Deleting the Completed Task
        ac.ClickActivityHistory();
        oa.DeleteSelectedTask_ActivityHistory(Tasktype);
        ac.CloseSubTabs();
    }

    public void SessionMissedAPI(String rolling7day) {
        if (CurrURL.contains("--byjusuat")) {
            payLoad_BTLAwithBranchAccount3.SessionMissedCreationResponse_UAT1(rolling7day);
        } else {
            payLoad_BTLAwithBranchAccount3.SessionMissedCreationResponse_Prod1(rolling7day);
        }
    }
    
    public void SessionMissedAPI2(String rolling7day) {
        if (CurrURL.contains("--byjusuat")) {
            payLoad_BTLAwithBranchAccount4.SessionMissedCreationResponse_UAT1(rolling7day);
        } else {
            payLoad_BTLAwithBranchAccount4.SessionMissedCreationResponse_Prod1(rolling7day);
        }
    }

    @AfterMethod(alwaysRun = true)
    public void teardown() throws InterruptedException {

         driver.quit();

        // Thread.sleep(2000);
    }

}
