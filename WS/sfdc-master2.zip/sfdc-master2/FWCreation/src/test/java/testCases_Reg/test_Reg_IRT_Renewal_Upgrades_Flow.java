package testCases_Reg;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pageObjects.CreatedAccountPO;
import pageObjects.InboundTaskPO;
import pageObjects.IssueTreePO;
import pageObjects.NewCaseRecordTypePO;
import pageObjects.loginPO;
import payLoad.payLoad_BTLA;
import payLoad.payLoad_BTLA2;
import resources.ExcelData;
import resources.base;

public class test_Reg_IRT_Renewal_Upgrades_Flow extends base {

    public WebDriver driver;

    public static Logger log = LogManager.getLogger(test_Reg_IRT_Renewal_Upgrades_Flow.class.getName());
    ExcelData excelData = new ExcelData();
    ArrayList<String> a1 = new ArrayList<String>();
    ArrayList<String> a2 = new ArrayList<String>();
    ArrayList<String> a3 = new ArrayList<String>();
    ArrayList<String> a4 = new ArrayList<String>();

    @BeforeMethod
    public void intialize() throws IOException, InterruptedException {

        driver = initializeDriver();
    }

    @Test(enabled = false)
    public void TC1_Renewal_Upgrades_Verify_IssueSubTypePicklist() throws Exception {

        String Accountid = null;
        loginPO lo = new loginPO(driver);

        a1 = excelData.getData("TC1", "Logistics", "Tcid");
        a2 = excelData.getData("Inbound", "Inbound", "Tcid");
        a3 = excelData.getData("TC2", "IssueTreeSubIssueType", "Tcid");

      if (CurrURL.contains("--byjusuat")) {
            log.info("Login with Admin profile into UAT");
            lo.LoginAsAdmin_UAT();
            Accountid = payLoad_BTLA.AccountidCreationResponse_UAT();
            log.info("The account id is :" + Accountid);

        } else {
            log.info("Login with Admin profile into Production");
            lo.LoginAsAdmin_Prod();
            Accountid = payLoad_BTLA2.AccountCreationResponse_Prod();
            log.info("The account id is :" + Accountid);
        }

        CreatedAccountPO ac = new CreatedAccountPO(driver);
       ac.closeTabWindows();
        String AccountURL = CurrURL + Accountid;
        driver.get(AccountURL);

        if (CurrURL.contains("--byjusuat")) {
            String AccountOwner = ac.AccOwnerCheck();
            if (!a2.get(1).equalsIgnoreCase(AccountOwner)) {
                ac.AssignAccount(a3.get(8));
            }
        } else {
            ac.AssignAccount("Sumit Dash");
        }

        if (CurrURL.contains("--byjusuat")) {

            lo.SwitchUser(a3.get(8));
        }

        else {
            lo.SwitchUsernProfile_Prod(a3.get(1), "IRT Profile");
            // lo.SwitchUser(a3.get(1));
        }
        Thread.sleep(1000);
        ac.closeTabWindows();
       driver.get(AccountURL);
        InboundTaskPO ibdt = new InboundTaskPO(driver);
        NewCaseRecordTypePO ncrt = new NewCaseRecordTypePO(driver);

        IssueTreePO it = new IssueTreePO(driver);
        //CasesPO co = new CasesPO(driver);
        ac.Scrollpagedown();
        ac.ClickOpenActivitiestoNewTask();

        ncrt.SelectCaseRecordTypeInbound();
        ncrt.ClickNext();
        ac.AdditionalWait();
        ncrt.ClickSave();
        ac.AdditionalWait();
       
        ibdt.ClickCaptureDetail();
        ac.AdditionalWait();
        ibdt.ClickProceedOptn();

        ac.AdditionalWait();
        if (CurrURL.contains("--byjusuat")) {
            ibdt.SelectSpokeTo3(a2.get(1));
            // it.PremiumidSelector();
            it.ProgramSelector();
            it.ClickNext();
        }

        ac.AdditionalWait();
        ibdt.SelectPSTCT(a2.get(2));
        it.ClickNext();
        ibdt.IsThereAnyIssue();
        it.IssueCategory(a3.get(2));
        it.IssueSubCategory(a3.get(3));
        it.IssueType(a3.get(4));
        ibdt.VerifyAllValIssueSubTypeRenewal_Upgrades(1);
        
        ac.AdditionalWait();
        driver.get(AccountURL);

       
 

        if (CurrURL.contains("--byjusuat") || (CurrURL.contains("byjusprod."))) {
            driver.findElement(By.xpath("//a[@class='action-link']")).click();
        }
        /*
         * else {
         * driver.findElement(By.
         * xpath("//a[@class='action-link']/following::a[contains(text(),'Log out')]")).
         * click();
         * }
         */

        driver.get(AccountURL);

        ac.DeleteAllCreatedStuProg();
        ac.AdditionalWait();
        ac.DeleteCreatedStuCase();
        ac.AdditionalWait();
        ac.NavBackToAccount();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());

    }

    
    @Test(enabled = true)
    public void TC2_MarketingAndromotional_Campaign() throws Exception {

        String Accountid = null;
        loginPO lo = new loginPO(driver);

        a1 = excelData.getData("TC1", "Logistics", "Tcid");
        a2 = excelData.getData("Inbound", "Inbound", "Tcid");
        a3 = excelData.getData("TC2", "IssueTreeSubIssueType", "Tcid");

      if (CurrURL.contains("--byjusuat")) {
            log.info("Login with Admin profile into UAT");
            lo.LoginAsAdmin_UAT();
            Accountid = payLoad_BTLA.AccountidCreationResponse_UAT();
            log.info("The account id is :" + Accountid);

        } else {
            log.info("Login with Admin profile into Production");
            lo.LoginAsAdmin_Prod();
            Accountid = payLoad_BTLA2.AccountCreationResponse_Prod();
            log.info("The account id is :" + Accountid);
        }

        CreatedAccountPO ac = new CreatedAccountPO(driver);
       ac.closeTabWindows();
        String AccountURL = CurrURL + Accountid;
        driver.get(AccountURL);
        //String MainWin = driver.getWindowHandle();
        
        if (CurrURL.contains("--byjusuat")) {
            String AccountOwner = ac.AccOwnerCheck();
            if (!a2.get(1).equalsIgnoreCase(AccountOwner)) {
                ac.AssignAccount(a3.get(8));
            }
        } else {
            ac.AssignAccount("Sumit Dash");
        }

        if (CurrURL.contains("--byjusuat")) {

            lo.SwitchUser(a3.get(8));
        }

        else {
            lo.SwitchUsernProfile_Prod(a3.get(1), "IRT Profile");
            // lo.SwitchUser(a3.get(1));
        }
        Thread.sleep(1000);
        ac.closeTabWindows();
       driver.get(AccountURL);
        InboundTaskPO ibdt = new InboundTaskPO(driver);
        NewCaseRecordTypePO ncrt = new NewCaseRecordTypePO(driver);

        IssueTreePO it = new IssueTreePO(driver);
        //CasesPO co = new CasesPO(driver);
        ac.Scrollpagedown();
        ac.ClickOpenActivitiestoNewTask();

        ncrt.SelectCaseRecordTypeInbound();
        ncrt.ClickNext();
        ac.AdditionalWait();
        ncrt.ClickSave();
        ac.AdditionalWait();
      
        ibdt.ClickCaptureDetail();
        ac.AdditionalWait();
        ibdt.ClickProceedOptn();

        ac.AdditionalWait();
        if (CurrURL.contains("--byjusuat")) {
            ibdt.SelectSpokeTo3(a2.get(1));
            // it.PremiumidSelector();
            it.ProgramSelector();
            it.ClickNext();
        }

        ac.AdditionalWait();
        ibdt.SelectPSTCT(a2.get(2));
        it.ClickNext();
        ibdt.IsThereAnyIssue();
        it.IssueCategory(a3.get(2));
        it.IssueSubCategory(a3.get(3));
        it.IssueType(a3.get(4));
        it.IssueSubType(a3.get(5));
        it.IssueNotes(a3.get(6));
        //it.IstheIssueResolved(a3.get(7));
        it.ClickNext();
        
        ac.AdditionalWait();
        ac.RefreshTab_Targetframe_IT();

        Thread.sleep(1000);
       it.caselink();

        it.Casesubjectline(a3.get(9));
        ac.closeTabWindows();
        driver.get(AccountURL);

        // driver.get("https://byjusprod--byjusuat.lightning.force.com/lightning/r/Account/001C2000007K96LIAS/view");
        Thread.sleep(1000);
        it.accountowner();
     

        if (CurrURL.contains("--byjusuat") || (CurrURL.contains("byjusprod."))) {
            driver.findElement(By.xpath("//a[@class='action-link']")).click();
        }
        /*
         * else {
         * driver.findElement(By.
         * xpath("//a[@class='action-link']/following::a[contains(text(),'Log out')]")).
         * click();
         * }
         */

        driver.get(AccountURL);

        ac.DeleteAllCreatedStuProg();
        ac.AdditionalWait();
        ac.DeleteCreatedStuCase();
        ac.AdditionalWait();
        ac.NavBackToAccount();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
   
    }
    @AfterMethod(alwaysRun = false)
    public void teardown() throws InterruptedException {

        driver.quit();

        // Thread.sleep(2000);
    }
}
