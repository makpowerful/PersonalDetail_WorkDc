package testCases_Reg;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pageObjects.AssignmentRulesRefundRequestPO;
import pageObjects.CasesPO;
import pageObjects.CollectionAssistantLoginPO;
import pageObjects.CreatedAccountPO;
import pageObjects.CreatedCaseRecordPO;
import pageObjects.InboundTaskPO;
import pageObjects.IssueTreePO;
import pageObjects.NewCaseDetailsPO;
import pageObjects.NewCaseRecordTypePO;
import pageObjects.Retention1stCallPO;
import pageObjects.TasksPO;
import pageObjects.UserDetailPO;
import pageObjects.UserSetupPO;
import pageObjects.loginPO;
import payLoad.payLoad_ByjusWallet;
import payLoad.payLoad_SinglePrgm;

import payLoad.payLoad_SinglePrgm_RRAssignment;
import payLoad.payLoad_TwoPrgms;
import resources.ExcelData;
import resources.base;

public class test_Reg_Retention extends base{

    public WebDriver driver;
    //public String CurrURL;
    public static Logger log = LogManager.getLogger(test_Reg_Retention.class.getName());
    ExcelData excelData = new ExcelData();
    static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);
    ArrayList<String> proddummyuser = new ArrayList<String>();
    ArrayList<String> al = new ArrayList<String>();
    ArrayList<String> al2 = new ArrayList<String>();
    ArrayList<String> al3 = new ArrayList<String>();
    ArrayList<String> al4 = new ArrayList<String>();
    ArrayList<String> al5 = new ArrayList<String>();
    ArrayList<String> al6 = new ArrayList<String>();
    ArrayList<String> al7 = new ArrayList<String>();
    ArrayList<String> al8 = new ArrayList<String>();
    ArrayList<String> DP_CC = new ArrayList<String>();
    ArrayList<String> OA_CC = new ArrayList<String>();
    ArrayList<String> EA_CC = new ArrayList<String>();
    ArrayList<String> EMI_CC = new ArrayList<String>();
    ArrayList<String> IWC_CC = new ArrayList<String>();
    ArrayList<String> LCF_CC = new ArrayList<String>();
    ArrayList<String> LCR_CC = new ArrayList<String>();
    ArrayList<String> OR_CC = new ArrayList<String>();
    ArrayList<String> NL_CC = new ArrayList<String>();
    
    @BeforeMethod(alwaysRun = true)
    public void initialize() throws IOException, InterruptedException {

        driver = initializeDriver();

    }
    
    //SFDC-4094-TC1,TC2,TC3 ,SFDC-3351 ,SFDC-4163-TC05
    @Test(groups = { "Regression" }, enabled = true)
    public void Test_Reg_Retention1() throws Exception {
    
        loginPO lo = new loginPO(driver);
        CreatedAccountPO ac = new CreatedAccountPO(driver);
        InboundTaskPO ibdt = new InboundTaskPO(driver);
        CasesPO cases= new CasesPO(driver);
        CreatedCaseRecordPO ccr= new CreatedCaseRecordPO(driver);
        Retention1stCallPO rfc = new Retention1stCallPO(driver);
        TasksPO t = new TasksPO(driver);
        NewCaseRecordTypePO ncrt= new NewCaseRecordTypePO(driver);
        
        String Accountid = "";
        
        DP_CC = excelData.getData("TC1", "RetentionChildCases", "Tcid");
        OA_CC = excelData.getData("TC2", "RetentionChildCases", "Tcid");
        LCF_CC = excelData.getData("TC4", "RetentionChildCases", "Tcid");
        
        if(CurrURL.contains("--byjusuat")) 
        {

            al = excelData.getData("TC1", "Retention", "Tcid");
            al2 = excelData.getData("Retention User UAT", "Login", "Type");
            al4 = excelData.getData("Admin", "Login", "Type");
            al5 = excelData.getData("BYJUS Math", "Picklist", "Tcid");
            log.info("Logging in as Admin to UAT");
            lo.LoginAsAdmin_UAT();
            log.info("Submitting the Account creation payload");
            Accountid=payLoad_SinglePrgm.AccountidCreationResponse_UAT(al5.get(1), al5.get(2), al5.get(3), al5.get(4));
            log.info("Launching the newly created Account id "+Accountid);
            
        }
        
        else 
        {
            al = excelData.getData("TC1", "Retention", "Tcid");
            al2 = excelData.getData("TC1", "ProdDummyUser", "Tcid");
            
            al5 = excelData.getData("BYJUS Math", "Picklist", "Tcid");
            log.info("Logging in as Admin to Prod");
            lo.LoginAsAdmin_Prod();
            
            log.info("Submitting the Account creation payload");
            Accountid=payLoad_SinglePrgm.AccountidCreationResponse_Prod(al5.get(1), al5.get(2), al5.get(3), al5.get(4));
            log.info("Launching the newly created Account id "+Accountid);
        }
        
        closeTabWindows();
        ac.Notification();
        ac.NavBackToAccount();
        String AccountURL=CurrURL+Accountid;
        ac.goTo(AccountURL);
        ac.AccountLoadwait();
        String AccountName=ac.CaptureAccOwnrNam();
        // String AccountOwner= ac.CaptureAccOwnrNam();
        
        if(CurrURL.contains("--byjusuat"))
        {
            log.info("Creating 2 Inbound Tasks");
            ac.ClickOpenActivitiestoNewTask();
            ncrt.SelectCaseRecordTypeInbound();
            ncrt.ClickNext();
            ac.AdditionalWait();
            ncrt.ClickSavenNew();
            ncrt.SelectCaseRecordTypeInbound();
            ncrt.ClickNext();
            ac.AdditionalWait();
            ncrt.ClickSave();
            ac.AdditionalWait();
            ac.CloseSubTabs();
        }
        
        log.info("Creating RR case with 1st SSO");
        RRCaseCreation("1st Order");
        
        //capture case no from task
        String CaseNumber_task = ibdt.CaptureRelatedToCaseNumber();
        ibdt.ClickRelatedToCaseNumber();
        log.info("The case number created is: "+CaseNumber_task);
        
        String caseURL = driver.getCurrentUrl();
        
        //capture case status from case
        String caseStatus = ccr.CaptureCaseStatus();
        //verify the case status
        Assert.assertEquals(caseStatus, "Refund Requested");
        
        log.info("Logging in as retention user");
        if(CurrURL.contains("--byjusuat"))
        {
            if(!ccr.CaptureCaseOwner().equals(al2.get(1)))
                ccr.ChangeCaseOwner(al2.get(1));
            ac.AdditionalWait();
            lo.SwitchUser(al2.get(1));
            ac.AdditionalWait();
            ac.Notification();
            ac.closeTabWindows();
            ac.goTo(AccountURL);
        }
        else
        {
            lo.SwitchUsernProfile_Prod(al2.get(1),"Retention Manager");
            ac.goTo(caseURL);
            ccr.CaseOwnrUpdate_Prod("Testing User");
            ac.AdditionalWait();
            ac.closeTabWindows();
            ac.goTo(AccountURL);
        }
        
        //***************SFDC-4163-TC05****************//
        
        ac.AdditionalWait();
        ac.AdditionalWait();
        ac.ClickOpenActivities1();
        //gets the count of open tasks other than retention
        int countofOpenTasks = ac.checkOpenActivitiesRet();
        log.info("Verifying if there are no open tasks other than retention");
        Assert.assertEquals(countofOpenTasks, 0);
        ac.CloseCurrentSubTab();
        
//        if(CurrURL.contains("--byjusuat"))
//            Assert.assertEquals(ac.ActivityHistoryCount(), "(3)");
//        else
//            Assert.assertEquals(ac.ActivityHistoryCount(), "(2)");
//        
        ccr.NavToCaseTab(CaseNumber_task); 
        
        //capture case no from case
        String CaseNumber_case = ccr.CaseNumberCreated();
        //verify the case number is correct
        Assert.assertEquals(CaseNumber_task,CaseNumber_case);
        
        ac.Scrollpagedown();
        ac.Scrollpagedown();
        
        cases.ClickRetentionFirstCall();
        ac.AdditionalWait();
        log.info("Marking the Initial call as Complete");
        rfc.EnterCompletedcall();
        rfc.ClickSave();
        ac.CloseSubTabs();
        
        ac.goTo(caseURL);
        
        caseStatus = ccr.CaptureCaseStatus();
        //verify the case status
        Assert.assertEquals(caseStatus, "Initial Call Completed");   
        
        //*****************SFDC-4094-TC01*******************//
        
        ac.ClickCreatedTaskOpenActivities_1(al.get(66));
        
        //To verify the subject of the task
        log.info("Verifying subject of RCA Analysis task");
        Assert.assertEquals(t.CaptureSubject(), "RCA Analysis - K3");
        
        //To verify the Action-type
        log.info("Verifying Action-type of RCA Analysis task");
        Assert.assertEquals(t.CaptureActiontype(), "RCA - Retention - K3");
        
        String createdDT = t.CaptureCreatedBy();
        //To verify the Expected Close Date-Time
        log.info("Verifying Expected Close Date-Time of RCA Analysis task");
        Assert.assertEquals(t.CalDueDate(createdDT), t.CaptureExpectedDnT());
        
        //*****************SFDC-4094-TC02*******************//
        
        log.info("Capture call details in RCA Analysis task");
        ibdt.ClickCaptureDetail();
        
        t.navToiframe("accessibility title");
        t.IssueCategoryRCA(al.get(67));
        t.ClickNext();
        t.IssueTypeRCA(al.get(68));
        t.ClickNext();
        t.IssueSubTypeRCA(al.get(69));
        t.ClickNext();
        
//        if(CurrURL.contains("--byjusuat"))
//        {
//            t.navToiframe("accessibility title");
//            t.IssueCategoryRCA(al.get(67));
//            t.ClickNext();
//            t.IssueTypeRCA(al.get(68));
//            t.ClickNext();
//            t.IssueSubTypeRCA(al.get(69));
//            t.ClickNext();
//        }
//        else
//        {
//            t.navToiframe("accessibility title");
//            t.IssueCategoryRCA("Product or Program Related");
//            t.ClickNext();
//            t.IssueTypeRCA("Hardware");
//            t.ClickNext();
//            t.IssueSubTypeRCA("Battery issue");
//            t.ClickNext();
//        }
        ac.AdditionalWait();
        ac.RefreshTab_Targetframe();
        ac.AdditionalWait();
        
        Assert.assertEquals(ibdt.CheckCallStatus(), "Call Completed");
        log.info("Verifying status of RCA Analysis task is completed");
        Assert.assertEquals(ibdt.CaptureStatus(), "Completed");
        
        ac.CloseCurrentSubTab();
        
        //*****************SFDC-4094-TC03*******************//
        
        Scrollpagedown();
        log.info("Changing the RR case status");
        //To check if new RCA Analysis task is created
        cases.ChangeStatusValue(al.get(70));
        cases.ClickSave();
        ac.AdditionalWait();
        ac.RefreshTab();
        ccr.ClickOpenActivities();
        Assert.assertFalse(ccr.CheckOpenActivities(al.get(66)));
        ac.CloseCurrentSubTab();
        ac.AdditionalWait();
        
        //Changing the status back to capture retention details
        cases.ChangeStatusValue(al.get(71));
        cases.ClickSave();
        ac.AdditionalWait();
        
        log.info("Capturing Retention Details");
        
        ccr.ClickCaptureRetentnDetail();
        ccr.EnterEscalationCategory(al.get(44));
        ccr.EnterReasonfrRefund(al.get(9));
        ccr.EnterSubReasonfrRefund(al.get(10));
        ccr.EnterRRNotes(al.get(11));
        ccr.EnterModeORetentn(al.get(12));
        ccr.EnterRTSE(al.get(13));
        ccr.EnterRTSR(al.get(14));
        ccr.Selectorder();
        
        if(CurrURL.contains("--byjusuat")) {
         ccr.EnterDeactivateClasses(al.get(64));   
        }
        else {
        ccr.EnterClsTBD(al.get(15));
        }
        
        ccr.EnterTTBR(al.get(16));
        ccr.EnterLTBC(al.get(17));
        ccr.EnterLoanID(al.get(55));
        ccr.EnterDPTBRefunBnk(al.get(18));
        ccr.EnterDPTBRefunWall(al.get(19));
        //ccr.EnterDPRefunWallAmt(al.get(20));
        //ccr.EnterDPBBP(al.get(21));
        ccr.EnterOATBRefunBnk(al.get(22));
        ccr.EnterOATBRefunWall(al.get(23));
        ccr.SelectTypeOfOtherAmount(al.get(45));
        ccr.EnterCashbackAmountIncluded(al.get(46));
        ccr.EnterOtherAmountBank(al.get(47));
        ccr.EnterATBRefunded(al.get(27));
        ccr.EnterARetained(al.get(28));
        ccr.SelectCWTGFOSP(al.get(29));
        ccr.SelectOTBReP(al.get(30));
        ccr.SelectCPTBReP(al.get(31));
        ccr.SelectBTBR(al.get(32));
        ccr.SelectRTPS(al.get(33));
        ccr.EnterRTPSNotes(al.get(34));
        ccr.SelectOwner(AccountName);
        ccr.EnterSPFES(al.get(35));
        ccr.EnterGTBP(al.get(36));
        ccr.EnterClsTBReP(al.get(37));
        ccr.EnterAmount(al.get(38));
        ccr.EnterOtherPD(al.get(39));
        ccr.EnterCompliGTBP(al.get(36));
        ccr.EnterCompliClsTBReP(al.get(37));
        ccr.SelectAFBD(al.get(40));
        ccr.SelectDYWTSTASTTCProd(al.get(41));
        ccr.SelectCOAForm(al.get(42));
        
        lo.Logouthome();
        ac.AdditionalWait();
        
        ac.goTo(caseURL);
        //capture case status from case
        caseStatus = ccr.CaptureCaseStatus();
        //verify the case status
        log.info("Verifying if the case status is Refund Approved");
        Assert.assertEquals(caseStatus, "Refund Approved");
        
        //div/span[text()='Escalation Category']/following::span
        
        ac.CloseSubTabs();
        ac.ClickCasesMC2();
        
        //****************SFDC-3351-TC01******************//
        
        //DP to be Refunded
        cases.ClickChildCase(DP_CC.get(5));
        
        log.info("Verifying DP to be Refunded child case");
        //Verifying the parent case number
        String ParentCase= cases.CaptureParentCaseOwnerDP();
        Assert.assertTrue(ParentCase.equalsIgnoreCase(CaseNumber_case));
        
        String CaseNoDP= cases.CaptureCaseNoCC(DP_CC.get(5));
        log.info("The Case number created for DP to be Refunded: "+CaseNoDP);
        
        //Verifying the case status
        Assert.assertEquals(cases.CaptureStatus(),"Waiting For Bank Details");
        
        //Verifying the case owner
        Assert.assertEquals(cases.CaptureCaseOwnerCC(DP_CC.get(5)), "Process Specialist L0");
        
        cases.ChangeStatusValue(DP_CC.get(6));
        cases.ClickSave();
        ac.AdditionalWait();
        Assert.assertEquals(cases.CaptureStatus(),"L1 Approval Pending");
        
        //Verifying the case owner
        //Assert.assertEquals(cases.CaptureCaseOwnerCC(DP_CC.get(5)), "Process Specialist L1");
        
        cases.ChangeStatusValue(DP_CC.get(7));
        cases.ClickSave();
        ac.AdditionalWait();
        Assert.assertEquals(cases.CaptureStatus(),"L2 Approval Pending");
        
        //Verifying the case owner
       // Assert.assertEquals(cases.CaptureCaseOwnerCC(DP_CC.get(5)), "Process Specialist L2");
        
        ac.CloseCurrentSubTab();
        
        //Other amount to be Refunded
        
        log.info("Verifying Other amount to be Refunded child case");
        cases.ClickChildCase(OA_CC.get(5));
        String CaseNoOA= cases.CaptureCaseNoCC(OA_CC.get(5));
        log.info("The Case number created for Other Amount To Be Refunded To Bank is: "+CaseNoOA);
        
        //Verifying the case status
        Assert.assertEquals(cases.CaptureStatus(),"Waiting For Bank Details");
        
        //Verifying the case owner
        Assert.assertEquals(cases.CaptureCaseOwnerCC(OA_CC.get(5)), "Process Specialist L0");
        
        cases.ChangeStatusValue(OA_CC.get(6));
        cases.ClickSave();
        ac.AdditionalWait();
        Assert.assertEquals(cases.CaptureStatus(),"L1 Approval Pending");
        
        //Verifying the case owner
        //Assert.assertEquals(cases.CaptureCaseOwnerCC(OA_CC.get(5)), "Process Specialist L1");
        
        cases.ChangeStatusValue(OA_CC.get(7));
        cases.ClickSave();
        ac.AdditionalWait();
        Assert.assertEquals(cases.CaptureStatus(),"L2 Approval Pending");
        
        //Verifying the case owner
        //Assert.assertEquals(cases.CaptureCaseOwnerCC(OA_CC.get(5)), "Process Specialist L2");
        
        ac.CloseCurrentSubTab();
        
        //Loan To Be Cancelled - Fintech
        
        log.info("Verifying Loan To Be Cancelled - Fintech child case");
        cases.ClickChildCase(LCF_CC.get(5));
        
        //capture case number of child case - Loan to be Cancelled - Fintech
        String CaseNoLCF= cases.CaptureCaseNoCC(LCF_CC.get(5));
        log.info("The Case number created for Loan to be Cancelled - Fintech : "+CaseNoLCF);
        
        //Verifying the parent case number
        ParentCase= cases.CaptureParentCaseNoCC(LCF_CC.get(5));
        Assert.assertTrue(ParentCase.equalsIgnoreCase(CaseNumber_case));
        
        //Verifying the case owner
//        ccr.ClickCaseOwner1(LCF_CC.get(5));
//        
//        Assert.assertEquals(cases.CaptureCaseOwnerProfile(), "Process Specialist L1");
//        ac.CloseCurrentSubTab();
        
        //Verifying the case status
        Assert.assertEquals(cases.CaptureCaseStatusCC(LCF_CC.get(5)),"L1 Approval Pending");
        
        ac.CloseCurrentSubTab();
        
        //deletes all the cases
        cases.CloseAllCases();
        
        log.info("Deleting the Student Program details");
        ac.ClickAccOwnrTab();
        ac.DeleteCreatedStuProg();
        
        log.info("Deleting the Student Payment details");
        ac.DeleteAllCreatedStuPayment();
        
        ac.NavBackToAccount();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
        
    }
    
    //SFDC-3352
    @Test(groups = { "Regression" }, enabled = true)
    public void Test_Reg_Retention2() throws Exception {

        
        loginPO lo = new loginPO(driver);
        CreatedAccountPO ac = new CreatedAccountPO(driver);
        InboundTaskPO ibdt = new InboundTaskPO(driver);
        CasesPO cases= new CasesPO(driver);
        NewCaseRecordTypePO ncrt= new NewCaseRecordTypePO(driver);
        NewCaseDetailsPO ncd = new NewCaseDetailsPO(driver);
        CreatedCaseRecordPO ccr= new CreatedCaseRecordPO(driver);
        String Accountid = "";
        
        DP_CC = excelData.getData("TC1", "RetentionChildCases", "Tcid");
        OA_CC = excelData.getData("TC2", "RetentionChildCases", "Tcid");
        EA_CC = excelData.getData("TC3", "RetentionChildCases", "Tcid");
        LCF_CC = excelData.getData("TC4", "RetentionChildCases", "Tcid");
        LCR_CC = excelData.getData("TC5", "RetentionChildCases", "Tcid");
        IWC_CC = excelData.getData("TC6", "RetentionChildCases", "Tcid");
        OR_CC = excelData.getData("TC7", "RetentionChildCases", "Tcid");
        EMI_CC = excelData.getData("TC8", "RetentionChildCases", "Tcid");
        NL_CC = excelData.getData("TC9", "RetentionChildCases", "Tcid");
        
        if(CurrURL.contains("--byjusuat")) 
        {
            al = excelData.getData("TC1", "Retention", "Tcid");
            al2 = excelData.getData("Retention User UAT", "Login", "Type");
            al4 = excelData.getData("Admin", "Login", "Type");
            al5 = excelData.getData("BYJUS The Learning App", "Picklist", "Tcid");
            log.info("Logging in as Admin to UAT");
            lo.LoginAsAdmin_UAT();
            log.info("Submitting the Account creation payload");
            Accountid=payLoad_SinglePrgm.AccountidCreationResponse_UAT(al5.get(1), al5.get(2), al5.get(3), al5.get(4));
            log.info("Launching the newly created Account id "+Accountid);
        }
        
        else {
            al = excelData.getData("TC1", "Retention", "Tcid");
            al2 = excelData.getData("TC1", "ProdDummyUser", "Tcid");
            log.info("Logging in as Admin to Prod");
            lo.LoginAsAdmin_Prod();
            
            log.info("Submitting the Account creation payload");
            Accountid=payLoad_ByjusWallet.AccountidCreationResponse_Prod();
            log.info("Launching the newly created Account id "+Accountid);
        }
        
        closeTabWindows();
        ac.Notification();
        String AccountURL=CurrURL+Accountid;
        ac.goTo(AccountURL);
        ac.AccountLoadwait();
        String AccountName=ac.CaptureAccOwnrNam();
        
        log.info("Creating RR case with 1st SSO Order");
        RRCaseCreation("1st Order");
        
        //capture case no from task
        String CaseNumber_task = ibdt.CaptureRelatedToCaseNumber();
        ibdt.ClickRelatedToCaseNumber();
        log.info("The case number created is: "+CaseNumber_task);
        
        //capture case status from case
        String caseStatus = ccr.CaptureCaseStatus();
        //verify the case status
        log.info("Verifying if caseStatus is Refund Requested");
        Assert.assertEquals(caseStatus, "Refund Requested");
        
        //capture case no from case
        String CaseNumber_case = ccr.CaseNumberCreated();
        //verify the case number is correct
        Assert.assertEquals(CaseNumber_task,CaseNumber_case);
        
        //*****************SFDC-3352-TC01*********************//
        
        //DP to be Refunded
        log.info("Creating DP to be Refunded child case");
        ccr.ClickRelatedCasesbtn();
        cases.ClickRelatedCaseNewBtn(CaseNumber_case);
        ncrt.SelectCaseRecordType(DP_CC.get(1));
        ncrt.ClickNext(); 
        ncd.EnterRetApprDate();
        ncd.EnterContactName(AccountName);
        if(CurrURL.contains("--byjusuat"))
            ncd.EnterStudentSalesOrder();
        else
            ncd.EnterStudentSalesOrder_Prod();
        ncd.SelectDropdownOptionCC(DP_CC.get(2), DP_CC.get(3));
        ncd.EnterAmount(DP_CC.get(4));
        ncd.EnterSubject1(DP_CC.get(5));
        ncd.ClickSave();
        ac.AccountLoadwait();
        
        //capture case number of child case - DP to be Refunded
        String CaseNoDP= cases.CaptureCaseNoCC(DP_CC.get(5));
        log.info("The Case number created for DP to be Refunded : "+CaseNoDP);
        
        //Verifying the parent case number
        String ParentCase= cases.CaptureParentCaseNoCC(DP_CC.get(5));
        Assert.assertTrue(ParentCase.equalsIgnoreCase(CaseNumber_case));
        
        //Verifying the case owner
        Assert.assertEquals(cases.CaptureCaseOwnerCC(DP_CC.get(5)), "Process Specialist L0");
        
        //Verifying the case status
        Assert.assertEquals(cases.CaptureCaseStatusCC(DP_CC.get(5)),"Waiting For Bank Details");
        ccr.closeCurrentTab(CaseNoDP);
        
        //Other Amount to be Refunded
        
        log.info("Creating Other Amount to be Refunded child case");
        cases.ClickRelatedCaseNewBtn(CaseNumber_case);
        ncrt.SelectCaseRecordType(OA_CC.get(1));
        ncrt.ClickNext(); 
        ncd.EnterRetApprDate(); //doubt
        ncd.EnterContactName(AccountName);  //doubt
        if(CurrURL.contains("--byjusuat"))
            ncd.EnterStudentSalesOrder();
        else
            ncd.EnterStudentSalesOrder_Prod();
        ncd.SelectDropdownOptionCC(OA_CC.get(2), OA_CC.get(3));
        ncd.EnterAmount(OA_CC.get(4));
        ccr.SelectTypeOfOtherAmount(al.get(45));
        ncd.EnterSubject1(OA_CC.get(5));
        ncd.ClickSave();
        ac.AccountLoadwait();
        
        //capture case number of child case - Other Amount to be Refunded
        String CaseNoOA= cases.CaptureCaseNoCC(OA_CC.get(5));
        log.info("The Case number created for Other to be Refunded : "+CaseNoOA);
        
        //Verifying the parent case number
        ParentCase= cases.CaptureParentCaseNoCC(OA_CC.get(5));
        Assert.assertTrue(ParentCase.equalsIgnoreCase(CaseNumber_case));
        
        //Verifying the case owner
        Assert.assertEquals(cases.CaptureCaseOwnerCC(OA_CC.get(5)), "Process Specialist L0");
        
        //Verifying the case status
        Assert.assertEquals(cases.CaptureCaseStatusCC(OA_CC.get(5)),"Waiting For Bank Details");
        ccr.closeCurrentTab(CaseNoOA);
        
        // Extra Amount to be Refunded
        
        log.info("Creating Extra Amount to be Refunded child case");
        ccr.ClickRelatedCasesbtn();
        cases.ClickRelatedCaseNewBtn(CaseNumber_case);
        ncrt.SelectCaseRecordType(EA_CC.get(1));
        ncrt.ClickNext(); 
        ncd.EnterContactName(AccountName);
        if(CurrURL.contains("--byjusuat"))
            ncd.EnterStudentSalesOrder();
        else
            ncd.EnterStudentSalesOrder_Prod();
        ncd.SelectDropdownOptionCC(EA_CC.get(2), EA_CC.get(3));
        ncd.EnterAmount(EA_CC.get(4));
        ccr.SelectTypeOfOtherAmount(al.get(45));
        ncd.EnterSubject1(EA_CC.get(5));
        ncd.ClickSave();
        ac.AccountLoadwait();
        
        //capture case number of child case - Extra Amount to be Refunded
        String CaseNoEA= cases.CaptureCaseNoCC(EA_CC.get(5));
        log.info("The Case number created for Extra Amount to be Refunded : "+CaseNoEA);
        
        //Verifying the parent case number
        ParentCase= cases.CaptureParentCaseNoCC(EA_CC.get(5));
        Assert.assertTrue(ParentCase.equalsIgnoreCase(CaseNumber_case));
        
        //Verifying the case owner
        Assert.assertEquals(cases.CaptureCaseOwnerCC(EA_CC.get(5)), "Process Specialist L0");
        
        //Verifying the case status
        Assert.assertEquals(cases.CaptureCaseStatusCC(EA_CC.get(5)),"Waiting For Bank Details");
        ccr.closeCurrentTab(CaseNoEA);
        
        //Loan to be Cancelled - Fintech
        
        log.info("CreatingLoan to be Cancelled - Fintech child case");
        ccr.ClickRelatedCasesbtn();
        cases.ClickRelatedCaseNewBtn(CaseNumber_case);
        ncrt.SelectCaseRecordType(LCF_CC.get(1));
        ncrt.ClickNext(); 
        ncd.EnterRetApprDate();
        ncd.EnterContactName(AccountName);
        if(CurrURL.contains("--byjusuat"))
            ncd.EnterStudentSalesOrder();
        else
            ncd.EnterStudentSalesOrder_Prod();
        ncd.SelectDropdownOptionCC(LCF_CC.get(2), LCF_CC.get(3));
        ncd.EnterAmount(LCF_CC.get(4));
        ncd.EnterSubject1(LCF_CC.get(5));
        ncd.ClickSave();
        ac.AccountLoadwait();
        
        //capture case number of child case - Loan to be Cancelled - Fintech
        String CaseNoLCF= cases.CaptureCaseNoCC(LCF_CC.get(5));
        log.info("The Case number created for Loan to be Cancelled - Fintech : "+CaseNoLCF);
        
        //Verifying the parent case number
        ParentCase= cases.CaptureParentCaseNoCC(LCF_CC.get(5));
        Assert.assertTrue(ParentCase.equalsIgnoreCase(CaseNumber_case));
        
        //Verifying the case owner
//        ccr.ClickCaseOwner1(LCF_CC.get(5));
//        
//        Assert.assertEquals(cases.CaptureCaseOwnerProfile(), "Process Specialist L1");
//        ac.CloseCurrentSubTab();
        
        //Verifying the case status
        Assert.assertEquals(cases.CaptureCaseStatusCC(LCF_CC.get(5)),"L1 Approval Pending");
        ccr.closeCurrentTab(CaseNoLCF);
        
        //Loan to be Cancelled - Regular
        
        log.info("Creating Loan to be Cancelled - Regular child case");
        ccr.ClickRelatedCasesbtn();
        cases.ClickRelatedCaseNewBtn(CaseNumber_case);
        ncrt.SelectCaseRecordType(LCR_CC.get(1));
        ncrt.ClickNext(); 
        ncd.EnterRetApprDate();
        ncd.EnterContactName(AccountName);
        if(CurrURL.contains("--byjusuat"))
            ncd.EnterStudentSalesOrder();
        else
            ncd.EnterStudentSalesOrder_Prod();
        ncd.SelectDropdownOptionCC(LCR_CC.get(2), LCR_CC.get(3));
        ncd.EnterAmount(LCR_CC.get(4));
        ncd.EnterSubject1(LCR_CC.get(5));
        ncd.ClickSave();
        ac.AccountLoadwait();
        
        //capture case number of child case - Loan to be Cancelled - Regular
        String CaseNoLCR= cases.CaptureCaseNoCC(LCR_CC.get(5));
        log.info("The Case number created for Loan to be Cancelled - Regular : "+CaseNoLCR);
        
        //Verifying the parent case number
        ParentCase= cases.CaptureParentCaseNoCC(LCR_CC.get(5));
        Assert.assertTrue(ParentCase.equalsIgnoreCase(CaseNumber_case));
        
//        //Verifying the case owner
//        ccr.ClickCaseOwner1(LCR_CC.get(5));
//        Assert.assertEquals(cases.CaptureCaseOwnerProfile(), "Process Specialist L2");
//        ac.CloseCurrentSubTab();
        //Verifying the case status
        Assert.assertEquals(cases.CaptureCaseStatusCC(LCR_CC.get(5)),"L1 Approval Pending");
        ccr.closeCurrentTab(CaseNoLCR);
        
        //Inward Case
        
        log.info("Creating Inward Case child case");
        ccr.ClickRelatedCasesbtn();
        cases.ClickRelatedCaseNewBtn(CaseNumber_case);
        ncrt.SelectCaseRecordType(IWC_CC.get(1));
        ncrt.ClickNext(); 
        ncd.EnterContactName(AccountName);
        if(CurrURL.contains("--byjusuat"))
            ncd.EnterStudentSalesOrder();
        else
            ncd.EnterStudentSalesOrder_Prod();
        ncd.EnterSubject1(IWC_CC.get(5));
        ncd.ClickSave();
        ac.AccountLoadwait();
        
        //capture case number of child case - Inward Case
        String CaseNoIWC= cases.CaptureCaseNoCC(IWC_CC.get(5));
        log.info("The Case number created for Inward Case : "+CaseNoIWC);
        
        //Verifying the parent case number
        ParentCase= cases.CaptureParentCaseNoCC(IWC_CC.get(5));
        Assert.assertTrue(ParentCase.equalsIgnoreCase(CaseNumber_case));
        
        //Verifying the case owner
        Assert.assertEquals(cases.CaptureCaseOwnerCC(IWC_CC.get(5)), "Inward Team");
        
        //Verifying the case status
        Assert.assertEquals(cases.CaptureCaseStatusCC(IWC_CC.get(5)),"Waiting For Product");
        ccr.closeCurrentTab(CaseNoIWC);
        
        //Order to be Repunched 
        
        log.info("Creating Order to be Repunched child case");
        ccr.ClickRelatedCasesbtn();
        cases.ClickRelatedCaseNewBtn(CaseNumber_case);
        ncrt.SelectCaseRecordType(OR_CC.get(1));
        ncrt.ClickNext(); 
        ncd.EnterContactName(AccountName);
        if(CurrURL.contains("--byjusuat"))
            ncd.EnterStudentSalesOrder();
        else
            ncd.EnterStudentSalesOrder_Prod();
        ncd.EnterGTBP1(al.get(36));
        ccr.EnterClsTBReP(al.get(37));
        ncd.EnterAmount(OR_CC.get(4));
        ncd.EnterGTBP2(al.get(36));
        ncd.EnterClsTBReP2(al.get(37));
        ncd.EnterSubject1(OR_CC.get(5));
        ncd.ClickSave();
        ac.AccountLoadwait();
        
        //capture case number of child case - Order to be Re-punched
        String CaseNoOR= cases.CaptureCaseNoCC(OR_CC.get(5));
        log.info("The Case number created for Order to be Re-punched : "+CaseNoOR);
        
        //Verifying the parent case number
        ParentCase= cases.CaptureParentCaseNoCC(OR_CC.get(5));
        Assert.assertTrue(ParentCase.equalsIgnoreCase(CaseNumber_case));
        
        //Verifying the case owner
        Assert.assertEquals(cases.CaptureCaseOwnerCC(OR_CC.get(5)), "Order Punching Manager Queue");
        
        //Verifying the case status
        Assert.assertEquals(cases.CaptureCaseStatusCC(OR_CC.get(5)),"Order To Be Punched");
        ccr.closeCurrentTab(CaseNoOR);

        //EMI to be waived off
        
        log.info("Creating EMI to be waived off child case");
        ccr.ClickRelatedCasesbtn();
        cases.ClickRelatedCaseNewBtn(CaseNumber_case);
        ncrt.SelectCaseRecordType(EMI_CC.get(1));
        ncrt.ClickNext(); 
        ncd.EnterContactName(AccountName);
        if(CurrURL.contains("--byjusuat"))
            ncd.EnterStudentSalesOrder();
        else
            ncd.EnterStudentSalesOrder_Prod();
        ncd.EnterSubject1(EMI_CC.get(5));
        ncd.ClickSave();
        ac.AccountLoadwait();
        
        //capture case number of child case - EMI to be waived off
        String CaseNoEMI= cases.CaptureCaseNoCC(EMI_CC.get(5));
        log.info("The Case number created for EMI to be waived off : "+CaseNoEMI);
        
        //Verifying the parent case number
        ParentCase= cases.CaptureParentCaseNoCC(EMI_CC.get(5));
        Assert.assertTrue(ParentCase.equalsIgnoreCase(CaseNumber_case));
        
        //Verifying the case owner
        Assert.assertEquals(cases.CaptureCaseOwnerCC(EMI_CC.get(5)), "NACH Team");
        
        //Verifying the case status
        Assert.assertEquals(cases.CaptureCaseStatusCC(EMI_CC.get(5)),"Action To Be Taken");
        
        ccr.closeCurrentTab(CaseNoEMI);
        
        //New Loan To Be Created
        
        log.info("Creating New Loan To Be Created child case");
        ccr.ClickRelatedCasesbtn();
        cases.ClickRelatedCaseNewBtn(CaseNumber_case);
        ncrt.SelectCaseRecordType(NL_CC.get(1));
        ncrt.ClickNext(); 
        ncd.EnterContactName(AccountName);
        if(CurrURL.contains("--byjusuat"))
            ncd.EnterStudentSalesOrder();
        else
            ncd.EnterStudentSalesOrder_Prod();
        ncd.EnterSubject1(NL_CC.get(5));
        ncd.ClickSave();
        ac.AccountLoadwait();
        
        //capture case number of child case - New Loan To Be Created
        String CaseNoNL= cases.CaptureCaseNoCC(NL_CC.get(5));
        log.info("The Case number created for New Loan To Be Created : "+CaseNoNL);
        
        //Verifying the parent case number
        ParentCase= cases.CaptureParentCaseNoCC(NL_CC.get(5));
        Assert.assertTrue(ParentCase.equalsIgnoreCase(CaseNumber_case));
        
        //Verifying the case owner
        Assert.assertEquals(cases.CaptureCaseOwnerCC(NL_CC.get(5)), "NACH Team");
        
        //Verifying the case status
        Assert.assertEquals(cases.CaptureCaseStatusCC(NL_CC.get(5)),"New Loan To Be Created");
        
        ac.CloseSubTabs();
        ac.ClickCasesMC2();
        
        //deletes all the cases
        cases.CloseAllCases();
        
        log.info("Deleting the Student Program details");
        ac.ClickAccOwnrTab();
        ac.DeleteCreatedStuProg();
        
        log.info("Deleting the Student Payment details");
        ac.DeleteAllCreatedStuPayment();
        
        ac.NavBackToAccount();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
        
    }
    
    //SFDC-3426
      @Test(groups = { "Regression" }, enabled = true)
    public void Test_Reg_Retention3() throws Exception {
        
        loginPO lo = new loginPO(driver);
        CreatedAccountPO ac = new CreatedAccountPO(driver);
        InboundTaskPO ibdt = new InboundTaskPO(driver);
        IssueTreePO it = new IssueTreePO(driver);
        CasesPO cases= new CasesPO(driver);
        CreatedCaseRecordPO ccr= new CreatedCaseRecordPO(driver);
        NewCaseRecordTypePO ncrt= new NewCaseRecordTypePO(driver);
        String wh = "";
        
        String Accountid = "";
        
        if(CurrURL.contains("--byjusuat")) 
        {
            al = excelData.getData("TC1", "Retention", "Tcid");
            al2 = excelData.getData("Retention User UAT", "Login", "Type");
            al3 = excelData.getData("IRT User UAT", "Login", "Type");
            al4 = excelData.getData("Admin", "Login", "Type");
            al5 = excelData.getData("BYJUS The Learning App", "Picklist", "Tcid");
            al6 = excelData.getData("Mentor User UAT", "Login", "Type");
            log.info("Logging in as Admin to UAT");
            lo.LoginAsAdmin_UAT();
            log.info("Submitting the Account creation payload");
            Accountid=payLoad_SinglePrgm.AccountidCreationResponse_UAT(al5.get(1), al5.get(2), al5.get(3), al5.get(4));
            log.info("Launching the newly created Account id "+Accountid);
        }
        
        else {
            al = excelData.getData("TC1", "Retention", "Tcid");
            al2 = excelData.getData("TC1", "ProdDummyUser", "Tcid");
            al3 = excelData.getData("IRT User UAT", "Login", "Type");
            al4 = excelData.getData("Admin", "Login", "Type");
            al5 = excelData.getData("BYJUS The Learning App", "Picklist", "Tcid");
            al6 = excelData.getData("Mentor User UAT", "Login", "Type");
            log.info("Logging in as Admin to Prod");
            lo.LoginAsAdmin_Prod();
            
            log.info("Submitting the Account creation payload");
            Accountid=payLoad_ByjusWallet.AccountidCreationResponse_Prod();
            log.info("Launching the newly created Account id "+Accountid);
        }
        
        closeTabWindows();
        ac.Notification();
        ac.NavBackToAccount();
        String AccountURL=CurrURL+Accountid;
        ac.goTo(AccountURL);
        ac.AccountLoadwait();
        
        //assigning account to mentor
        if(CurrURL.contains("--byjusuat"))
            ac.AssignAccount(al6.get(1));
        else
            ac.AssignAccount(al2.get(1));
        
        //logging with IRT
        log.info("Logging in as IRT profile in UAT");
        
        if(CurrURL.contains("--byjusuat"))
        {
            lo.SwitchUser(al3.get(1));
            closeTabWindows();
            ac.goTo(AccountURL);
            closeTabWindows();
        }
        else
        {
            wh = driver.getWindowHandle();
            lo.SwitchUsernProfile_Prod(al2.get(1),"IRT profile");
            closeTabWindows();
            ac.Notification();
            ac.goTo(AccountURL);
        }
   
        
        log.info("Creating Inbound Task");
        ac.ClickOpenActivitiestoNewTask();
        ncrt.SelectCaseRecordTypeInbound();
        ncrt.ClickNext();
        ac.AdditionalWait();
        
        ncrt.ClickSave();
        ac.AdditionalWait();
        
        ibdt.ClickCaptureDetail();
        ac.AccountLoadwait();
        
        ibdt.ClickProceedOptn();
        
        ibdt.SelectSpokeTo3(al.get(3));
        it.ProgramSelector();
        ibdt.ClickNext();
        
        ibdt.SelectPSTCT(al.get(1));
        ibdt.ClickNext();
        log.info("Creating RR Case");
        it.IssueCategory(al.get(4));
        it.Reason(al.get(5));
        it.SubReason(al.get(6));
        it.IssueNotes(al.get(7));
        it.IstheIssueResolved(al.get(8));
        it.ClickNext2();
        
        log.info("Selecting SSO Combination");
        it.SSOandAccCombo_IRT();
        ac.AccountLoadwait();
        
        lo.RefreshURL();
        ac.AdditionalWait();
        
        log.info("Verifying task status is completed");
        //verify if the task status is completed
        String Task_status = ibdt.CheckStatus();
        Assert.assertEquals(Task_status, "Completed");
        
        log.info("Logging out as IRT and logging in as Mentor");
        
        if(CurrURL.contains("--byjusuat"))
        {
            lo.onlyLogoutAndSwitchToUser(driver, al6.get(1));
            closeTabWindows();
            ac.goTo(AccountURL);
        }
        else
        {
            lo.Logouthome();
            ac.CloseWindowArrayLast();
            driver.switchTo().window(wh);
            ac.AccountLoadwait();
            lo.SwitchUsernProfile_Prod(al2.get(1),"Mentor");
            closeTabWindows();
            ac.goTo(AccountURL);
            
        }
   
        log.info("Opening created Potential Refund Request Task");
        ac.ClickCreatedTask_OpenActivities("Potential Refund Request Task");
        
        //***************SFDC-3426-TC01****************//
        
        ibdt.ClickCaptureDetail();
        ibdt.ClickDNP();
        ac.AdditionalWait();
        ac.RefreshTab_Targetframe();
        log.info("Verifying if call status is DNP");
        Assert.assertEquals(ibdt.CheckCallStatus(), "DNP");
        
        //***************SFDC-3426-TC02****************//
        
        ibdt.ClickCaptureDetail();
        ibdt.ClickAbruptDisconnection();
        ac.AdditionalWait();
        ac.RefreshTab_Targetframe();
        log.info("Verifying if call status is Abrupt Disconnection");
        Assert.assertEquals(ibdt.CheckCallStatus(), "Abrupt Disconnection");
        
        //***************SFDC-3426-TC03****************//
        
        ibdt.ClickCaptureDetail();
        ibdt.ClickATCB();
        ac.AdditionalWait();
        ac.RefreshTab_Targetframe();
        log.info("Verifying if call status is Asked to Call Back Later");
        Assert.assertEquals(ibdt.CheckCallStatus(), "Asked to Call Back Later");
        
        //***************SFDC-3426-TC04****************//
        
        ibdt.ClickCaptureDetail();
        ibdt.ClickProceedOptn();
        ibdt.SelectPSTCT(al.get(1));
        ibdt.ClickNext();
        it.IssueCategory(al.get(4));
        it.Reason(al.get(5));
        it.SubReason(al.get(6));
        it.IssueNotes(al.get(7));
        it.IstheIssueResolved(al.get(8));
        it.ClickNext2();
        it.SSOandAccCombo();
        ac.AdditionalWait();
        it.ClickFinish();
        ac.AdditionalWait();
        ac.RefreshTab_Targetframe();
        ac.AdditionalWait();
        
        //verify if the task status is completed
        Task_status = ibdt.CheckStatus();
        log.info("Verifying if task status is Completed");
        Assert.assertEquals(Task_status, "Completed");
        
        ibdt.ClickRelatedToCaseNumber();
        log.info("The case number created is: "+ccr.CaseNumberCreated());
        
        //capture case status from case
        String caseStatus = ccr.CaptureCaseStatus();
        //verify the case status
        Assert.assertEquals(caseStatus, "Refund Requested");
        
        lo.Logouthome();
        closeTabWindows();
        ac.goTo(AccountURL);
        
        ac.ClickCasesMC2();
        
        //deletes all the cases
        cases.CloseAllCases();
        
        log.info("Deleting the Student Program details");
        ac.ClickAccOwnrTab();
        ac.DeleteCreatedStuProg();
        
        log.info("Deleting the Student Payment details");
        ac.DeleteAllCreatedStuPayment();
        
        ac.NavBackToAccount();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
        
    }

    //SFDC-4154, SFDC-4163-TC03
    @Test(dataProvider = "testDatapro" , groups = "Regression" , enabled = true)  
    public void Test_Reg_Retention4(String stuPrograms, String shipRegions, String classNo) throws Exception {
        
        loginPO lo = new loginPO(driver);
        CreatedAccountPO ac = new CreatedAccountPO(driver);
        InboundTaskPO ibdt = new InboundTaskPO(driver);
        CasesPO cases= new CasesPO(driver);
        CreatedCaseRecordPO ccr= new CreatedCaseRecordPO(driver);
        AssignmentRulesRefundRequestPO ar = new AssignmentRulesRefundRequestPO(driver);
        UserDetailPO ud = new UserDetailPO(driver); 

        String Accountid = "";
        
        //get random program, shipping address, order delivery date
        
        String prog = ar.GetStuProg(stuPrograms,classNo);
        String shippedRegion = ar.GetShippedRegion(shipRegions, classNo);
        String classNum = ar.GetClassNo(classNo);
        ArrayList<String> lis = ar.GetordDelDate(classNo);
        String ordDelDate = lis.get(0); 
        
        if(CurrURL.contains("--byjusuat")) 
        {
            al = excelData.getData("TC1", "Retention", "Tcid");
            al2 = excelData.getData("Retention User UAT", "Login", "Type");
            al4 = excelData.getData("Admin", "Login", "Type");

            log.info("Logging in as Admin to UAT");
            lo.LoginAsAdmin_UAT();
            
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_SinglePrgm_RRAssignment.AccountidCreationResponse_UAT(prog, shippedRegion, classNum, ordDelDate);
            log.info("Launching the newly created Account id "+Accountid);
        }
        
        else {
            al = excelData.getData("TC1", "Retention", "Tcid");
            log.info("Logging in as Admin to Prod");
            lo.LoginAsAdmin_Prod();
            
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_SinglePrgm_RRAssignment.AccountidCreationResponse_Prod(prog, shippedRegion, classNum, ordDelDate);
            log.info("Launching the newly created Account id "+Accountid);
        }
        
        closeTabWindows();
        ac.Notification();
        String AccountURL=CurrURL+Accountid;
        ac.AdditionalWait();
        ac.goTo(AccountURL);
        
        log.info("prog : "+prog);
        log.info("shippedregion : "+shippedRegion);
        log.info("classNo : "+classNo);
        log.info("ordDelDate :"+ordDelDate);
        
        ac.AccountLoadwait();
        
        log.info("Creating RR case with 1st SSO Order");
        RRCaseCreation("1st Order");
        
        //capture case no from task
        String CaseNumber_task = ibdt.CaptureRelatedToCaseNumber();
        ibdt.ClickRelatedToCaseNumber();
        ac.RefreshTab();
        log.info("The case number created is: "+CaseNumber_task);
        
        //capture case status from case
        String caseStatus = ccr.CaptureCaseStatus();
        //verify the case status
        log.info("Verifying RR Case status");
        Assert.assertEquals(caseStatus, "Refund Requested");
        
        //Deriving the queue name based on the details in parameters
        String expectedQueue = ar.GetQueueName(prog,shippedRegion,classNum,lis.get(1));
        
        String caseOwner = ccr.CaptureCaseOwner1();
        log.info("RR Case Owner1 : "+caseOwner);
        
        //If case owner is not queue, check if the case owner is in the group
        if(!(caseOwner.contains("K3") || caseOwner.contains("K4-K10") || caseOwner.contains("K12")))
        {
            //Assigned to user
            log.info("Entering if loop - If case owner is not queue");
            //Getting the user name
            caseOwner = ccr.CaptureCaseOwner();
            log.info("caseOwnerUser :"+caseOwner);
            
            log.info("Navigating to assignment rules");
            lo.navToAssignmentRules();
            
            log.info("Navigating to specific assignment rule");
            lo.navToAssignmentruleGroup(expectedQueue);
            
            log.info("Navigating to group members");
            ar.navToGrpMem();
            
            log.info("Verifying if the case owner is present in the group members");
            Assert.assertTrue(ar.VerifyCaseOwner(caseOwner));
        }
        //If case owner is queue
        else
        {
            log.info("Entering else loop - If case owner is queue");
            
            log.info("Navigating to assignment rules");
            lo.navToAssignmentRules();
            
            log.info("Navigating to specific assignment rule");
            lo.navToAssignmentruleGroup(expectedQueue);
            
            log.info(ar.getGroupMemCount());
            
            //If case owner is queue, verify if the group members count is 0
            if(ar.getGroupMemCount().equals("(0)"))
            {
                log.info("Entering if loop - If group members count is 0");
                log.info("Verifying if the group members count is 0");
                Assert.assertEquals(ar.getGroupMemCount(),"(0)");
                
                log.info("Verifying if the case owner is queue as group members count is 0 ");
                Assert.assertEquals(caseOwner, expectedQueue);
            }
            
          //If case owner is queue, verify if the group members are in week off
            else
            {
                log.info("Entering else loop - If group members count is not 0");
                ar.navToGrpMem();
                List<WebElement> names = ar.GroupMembers();
                WebElement name;
                int count = names.size();
                log.info("Capturing the count of group members in weekoff/leave");
                for(int i=0;i<names.size();i++)
                {
                    name = names.get(i);
                    jsClick(name);
                    
                    //clicking to user details
                    ud.ClickUserDetailbutton();
                    ar.navToiframe("User");
                    
                    //verifying if the user is available or not
                    if(!ar.checkMemAvailability())
                        count--;
                    lo.SwitchDefaultContent();
                    
                    //navigating back to main
                    lo.ReturntoMain();
                    ac.AdditionalWait();
                    ac.CloseCurrentSubTab();
                }
                if(count == 0)
                {
                    log.info("Verifying if the case owner is queue as group members are in weekoff/leave");
                    Assert.assertEquals(caseOwner, expectedQueue);
                }
            }
        }
        
        ac.closeTabWindows();
        ac.goTo(AccountURL);
        ac.ClickCasesMC2();
        
        //deletes all the cases
        cases.CloseAllCases();
        
        log.info("Deleting the Student Program details");
        ac.ClickAccOwnrTab();
        ac.DeleteCreatedStuProg();
        
        log.info("Deleting the Student Payment details");
        ac.DeleteAllCreatedStuPayment();
        
        ac.NavBackToAccount();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
    }
        
    //SFDC-4163-TC01,TC02 , SFDC-3793-TC01,TC05
    @Test(groups = { "Regression" }, enabled = true)    
    public void Test_Reg_Retention5() throws Exception {

        loginPO lo = new loginPO(driver);
        CreatedAccountPO ac = new CreatedAccountPO(driver);
        InboundTaskPO ibdt = new InboundTaskPO(driver);
        CasesPO cases= new CasesPO(driver);
        CreatedCaseRecordPO ccr= new CreatedCaseRecordPO(driver);
        NewCaseRecordTypePO ncrt= new NewCaseRecordTypePO(driver);
        IssueTreePO it = new IssueTreePO(driver);
        
        String Accountid = "";
        al4 = excelData.getData("K4-10", "RRCaseAssignment", "Tcid");
        al5 = excelData.getData("shippedRegion", "RRCaseAssignment", "Tcid");
       
        //list of 2 programs selected randomly
        //al6 = getTwoRandomProgramID(al4, al4, 1, 8);
        String prog1 = al4.get(4);
        String prog2 = al4.get(6);
        String shippedregion = al5.get(randomNumber(1, 8));
        String classNo = Integer.toString(randomNumber(4,7));
        
        if(CurrURL.contains("--byjusuat")) 
        {
            al = excelData.getData("TC1", "Retention", "Tcid");
            al2 = excelData.getData("Retention User UAT", "Login", "Type");
            al3 = excelData.getData("Admin", "Login", "Type");
            log.info("Logging in as Admin to UAT");
            lo.LoginAsAdmin_UAT();
            log.info("Submitting the Account creation payload");
            Accountid=payLoad_TwoPrgms.AccountidCreationResponse_UAT(prog1, prog2, shippedregion, classNo);
            log.info("Launching the newly created Account id "+Accountid);
        }
        
        else {
            al = excelData.getData("TC1", "Retention", "Tcid");
            al2 = excelData.getData("TC1", "ProdDummyUser", "Tcid");
            al3 = excelData.getData("AdminProd", "Login", "Type");
            log.info("Logging in as Admin to Prod");
            lo.LoginAsAdmin_Prod();
            
            log.info("Submitting the Account creation payload");
            Accountid=payLoad_TwoPrgms.AccountidCreationResponse_Prod(prog1, prog2, shippedregion, classNo);
            log.info("Launching the newly created Account id "+Accountid);
        }
        
        closeTabWindows();
        ac.Notification();
        //ac.NavBackToAccount();
        String AccountURL=CurrURL+Accountid;
        ac.AdditionalWait();
        ac.goTo(AccountURL);
        log.info("prog1 : "+prog1);
        log.info("prog2 : "+prog2);
        log.info("shippedregion : "+shippedregion);
        log.info("classNo : "+classNo);
        ac.AccountLoadwait();
        String accOwner = ac.CaptureAccOwnerNam();
        
        //***************SFDC-4163-TC01****************//
        //creating RR with 1st SSO Order
        log.info("Creating  RR case with 1st SSO Order");
        RRCaseCreation("1st Order");
        
        //capture case no from task
        String CaseNumber_task = ibdt.CaptureRelatedToCaseNumber();
        ibdt.ClickRelatedToCaseNumber();
        ac.RefreshTab();
        log.info("The case number is: "+CaseNumber_task);
        
        //capture case status from case
        String caseStatus = ccr.CaptureCaseStatus();
        //verify the case status
        log.info("Verifying RR Case status");
        Assert.assertEquals(caseStatus, "Refund Requested");
        
        //***************SFDC-3793-TC01****************//
        
        log.info("Verifying if Reason and Sub reason for refund are updated against the RR case");
        Assert.assertEquals(al.get(5), ccr.CaptureReasonForRefund());
        Assert.assertEquals(al.get(6), ccr.CaptureSubReasonRefund());
        
        String caseOwner1 = ccr.CaptureCaseOwner1();
        
        log.info("RR Case Owner1 : "+caseOwner1);
        
        if(!(caseOwner1.contains("K3") || caseOwner1.contains("K4-K10") || caseOwner1.contains("K12")))
        {
            //Getting the owner name
            caseOwner1 = ccr.CaptureCaseOwner();
            log.info("caseOwnerUser :"+caseOwner1);
        }
        
        ac.AdditionalWait();
        ac.CloseSubTabs();
        //***************SFDC-4163-TC02****************//
        
        //creating RR with 2nd SSO Order
        log.info("Creating RR case with 2nd SSO Order");
        log.info("Creating Inbound Task");
        ac.ClickOpenActivitiestoNewTask();
        ncrt.SelectCaseRecordTypeInbound();
        ncrt.ClickNext();
        ac.AdditionalWait();
        
        ncrt.ClickSave();
        ac.AdditionalWait();
        
        ibdt.ClickCaptureDetail();
        ac.AccountLoadwait();
        
        ibdt.ClickProceedOptn();
        ibdt.SelectPSTCT(al.get(1));
        ibdt.ClickNext();
        it.IssueCategory(al.get(4));
        it.Reason(al.get(5));
        it.SubReason(al.get(6));
        it.IssueNotes(al.get(7));
        it.IstheIssueResolved(al.get(8));
        it.ClickNext2();
        
        log.info("Selecting SSO Combination");
        it.SSOandAccCombo();
        //Assert.assertTrue(it.CaptureRRerrormsg().equalsIgnoreCase(" RR Case present for that SO-Combination - "+CaseNumber_task));
        
        //***************SFDC-3793-TC05****************//
        
        String errorMsg = it.CaptureRRerrormsg();
        log.info("Verifying if error occurs when RR case is created with same SSO.");
        Assert.assertTrue(errorMsg.contains(" RR Case present for that SO-Combination - "+CaseNumber_task));
        
        it.SSOandAccCombo();//To deselect the SO-PID combination
        it.SSOandAccCombo1("2nd Order"); // To select another combination
        ac.AccountLoadwait();
        it.ClickFinish();
        ac.AdditionalWait();
        
        ac.goTo(driver.getCurrentUrl());
        ac.AdditionalWait();
        
        log.info("Verifying task status is completed");
        //verify if the task status is completed
        String Task_status = ibdt.CheckStatus();
        Assert.assertEquals(Task_status, "Completed");
        
        
        //capture case no from task
        CaseNumber_task = ibdt.CaptureRelatedToCaseNumber();
        ibdt.ClickRelatedToCaseNumber();
        ac.RefreshTab();
        log.info("The 2nd case number is: "+CaseNumber_task);
        
        //capture case status from case
        caseStatus = ccr.CaptureCaseStatus();
        //verify the case status
        log.info("Verifying RR Case status");
        Assert.assertEquals(caseStatus, "Refund Requested");
        
        String caseOwner2 = ccr.CaptureCaseOwner1();
        log.info("RR Case Owner1 : "+caseOwner2);
        
        if(!(caseOwner2.contains("K3") || caseOwner2.contains("K4-K10") || caseOwner2.contains("K12")))
        {
            //Getting the user name
            caseOwner2 = ccr.CaptureCaseOwner();
            log.info("caseOwnerUser :"+caseOwner2);
        }
        
       // al7 = (ArrayList<String>) Arrays.asList("ACOPKXSY0001", "ACOPKXSY0003", "BCRPUCSY0001");
        //ACOPKXSY0001 , ACOPKXSY0003 , BCRPUCSY0001
        
        List<String> progList = Arrays.asList("ACOPKXSY0001", "ACOPKXSY0003", "BCRPUCSY0001");
        
       //***************SFDC-4163-TC02****************//
        
        log.info("Verifying if both the case owners are same");
        if(caseOwner1.contains("K3") || caseOwner1.contains("K4-K10") || caseOwner1.contains("K12"))
        {
            Assert.assertEquals(caseOwner2, accOwner);
        }
        else
        {
            if(!progList.contains(prog1) && !progList.contains(prog2))
                Assert.assertEquals(caseOwner1, caseOwner2);
                else
                    Assert.assertNotEquals(caseOwner1, caseOwner2);
        }
        
        
        ac.CloseSubTabs();
        ac.goTo(AccountURL);
        
        ac.ClickCasesMC2();
        
        //deletes all the cases
        cases.CloseAllCases();
        
        log.info("Deleting the Student Program details");
        ac.ClickAccOwnrTab();
        ac.DeleteCreatedStuProg();
        
        log.info("Deleting the Student Payment details");
        ac.DeleteAllCreatedStuPayment();
        
        ac.NavBackToAccount();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
        
    }
    
    //SFDC-4163-TC04
    @Test(groups = { "Regression" }, enabled = true)    
    public void Test_Reg_Retention6() throws Exception {


        loginPO lo = new loginPO(driver);
        CreatedAccountPO ac = new CreatedAccountPO(driver);
        InboundTaskPO ibdt = new InboundTaskPO(driver);
        CasesPO cases= new CasesPO(driver);
        CreatedCaseRecordPO ccr= new CreatedCaseRecordPO(driver);
        UserDetailPO ud = new UserDetailPO(driver); 
        UserSetupPO us = new UserSetupPO(driver);
        AssignmentRulesRefundRequestPO ar = new AssignmentRulesRefundRequestPO(driver);
        ArrayList<String> grpMems = new ArrayList<String>();
        
        String Accountid = "";
        al4 = excelData.getData("K4-10", "RRCaseAssignment", "Tcid");
        al5 = excelData.getData("shippedRegion", "RRCaseAssignment", "Tcid");
       
        //list of 2 programs selected randomly
        //al6 = getTwoRandomProgramID(al4, al4, 1, 8);
        String prog1 = al4.get(3);
        String prog2 = al4.get(8);
        String shippedregion = al5.get(randomNumber(1, 8));
        String classNo = Integer.toString(randomNumber(4,7));
        
        if(CurrURL.contains("--byjusuat")) 
        {
            al = excelData.getData("TC1", "Retention", "Tcid");
            al2 = excelData.getData("Retention User UAT", "Login", "Type");
            al3 = excelData.getData("Admin", "Login", "Type");
            log.info("Logging in as Admin to UAT");
            lo.LoginAsAdmin_UAT();
            log.info("Submitting the Account creation payload");
            Accountid=payLoad_TwoPrgms.AccountidCreationResponse_UAT(prog1, prog2, shippedregion, classNo);
            log.info("Launching the newly created Account id "+Accountid);
        }
        
        else {
            al = excelData.getData("TC1", "Retention", "Tcid");
            al2 = excelData.getData("TC1", "ProdDummyUser", "Tcid");
            al3 = excelData.getData("AdminProd", "Login", "Type");
            log.info("Logging in as Admin to Prod");
            lo.LoginAsAdmin_Prod();
            
            log.info("Submitting the Account creation payload");
            Accountid=payLoad_TwoPrgms.AccountidCreationResponse_Prod(prog1, prog2, shippedregion, classNo);
            log.info("Launching the newly created Account id "+Accountid);
        }
        
        closeTabWindows();
        ac.Notification();
        //ac.NavBackToAccount();
        String AccountURL=CurrURL+Accountid;
        ac.AdditionalWait();
        ac.goTo(AccountURL);
        log.info("program 1 : "+prog1);
        log.info("program 2 : "+prog2);
        log.info("shippedregion : "+shippedregion);
        log.info("classNo : "+classNo);
        
        ac.AccountLoadwait();
        String accOwnerName = ac.CaptureAccOwnerNam();
        //creating RR with 1st SSO Order
        
        log.info("Creating 1st RR case with 1st SSO");
        RRCaseCreation("1st Order");
        
        //capture case no from task
        String CaseNumber1= ibdt.CaptureRelatedToCaseNumber();
        ibdt.ClickRelatedToCaseNumber();
        ac.RefreshTab();
        log.info("The case number is: "+CaseNumber1);
        
        //capture case status from case
        String caseStatus = ccr.CaptureCaseStatus();
        //verify the case status
        log.info("Verifying RR Case status");
        Assert.assertEquals(caseStatus, "Refund Requested");
        
        String caseOwner1 = ccr.CaptureCaseOwner1();
        String DucaseOwner1 = caseOwner1;
        log.info("RR Case Owner1 : "+caseOwner1);
        
        String expectedQueue = ar.GetQueueName(prog1,shippedregion,classNo,"4");
        
        //If the case owner is not queue
        if(!(caseOwner1.contains("K3") || caseOwner1.contains("K4-K10") || caseOwner1.contains("K12")))
        {
            log.info("Entering into if loop - Case owner is not queue");
            //Getting the user name
            caseOwner1 = ccr.CaptureCaseOwner();
            log.info("caseOwnerUser :"+caseOwner1);
            DucaseOwner1 = caseOwner1;
            
            log.info("Navigating to assignment rules");
            lo.navToAssignmentRules();
            
            log.info("Navigating to specific assignment rule");
            lo.navToAssignmentruleGroup(expectedQueue);
            
            log.info("Navigating to group members");
            ar.navToGrpMem();
            
            //verify if the user is in the assignment rule group
            log.info("Verifying if the case owner is present in the group members");
            Assert.assertTrue(ar.VerifyCaseOwner(caseOwner1));
            
            grpMems = ar.GetGrpMembers();
            
            ac.closeCurrentTabWindow();
            ac.closeCurrentTabWindow();
            ac.AdditionalWait();
            
            //Mark as long leave
            ccr.ClickCaseOwner(caseOwner1);
            ud.ClickUserDetailbutton();
            log.info("Marking the user availability to long leave");
            us.ChangeUseravailability("Long Leave");
            ac.goTo(AccountURL);
        }
        //If case owner is queue
        else
        {
            log.info("Entering else loop - If case owner is queue");
            
            log.info("Navigating to assignment rules");
            lo.navToAssignmentRules();
            
            log.info("Navigating to specific assignment rule");
            lo.navToAssignmentruleGroup(expectedQueue);
            
            log.info(ar.getGroupMemCount());
            
            //If case owner is queue, verify if the group members count is 0
            if(ar.getGroupMemCount().equals("(0)"))
            {
                log.info("Entering if loop");
                log.info("Verifying if the group members count is 0");
                Assert.assertEquals(ar.getGroupMemCount(),"(0)");
                
                log.info("Verifying if the case owner is queue as group members count is 0 ");
                Assert.assertEquals(caseOwner1, expectedQueue);
                ac.CloseSubTabs();
            }
            
            //If case owner is queue, verify if the group members are in week off
            else
            {
                ac.AdditionalWait();
                log.info("Entering else loop");
                ar.navToGrpMem();
                List<WebElement> names = ar.GroupMembers();
                WebElement name;
                int count = names.size();
                log.info("Verifying if the group members are in weekoff/leave");
                for(int i=0;i<names.size();i++)
                {
                    name = names.get(i);
                    jsClick(name);
                    
                    //clicking to user details
                    ud.ClickUserDetailbutton();
                    ar.navToiframe("User");
                    
                    //verifying if the user is available or not
                    //checkMemAvailability returns false if member is not available
                    if(!ar.checkMemAvailability())
                        count--;
                    lo.SwitchDefaultContent();
                    
                    //navigating back to main
                    lo.ReturntoMain();
                    ac.AdditionalWait();
                }
                if(count == 0)
                {
                    log.info("Verifying if the case owner 1is queue if all group members are in weekoff/leave");
                    Assert.assertEquals(caseOwner1, expectedQueue);
                }
            }
            ac.closeTabWindows();
            ac.goTo(AccountURL);
        }
        
        //creating RR with 2nd SSO Order
        log.info("Creating 2nd RR case with 2nd SSO");
        RRCaseCreation("2nd Order");
        
        //capture case no from task
        String CaseNumber2 = ibdt.CaptureRelatedToCaseNumber();
        ibdt.ClickRelatedToCaseNumber();
        ac.RefreshTab();
        log.info("The 2nd case number is: "+CaseNumber2);
        
        //capture case status from case
        caseStatus = ccr.CaptureCaseStatus();
        //verify the case status
        log.info("Verifying RR Case status");
        Assert.assertEquals(caseStatus, "Refund Requested");
        
        String caseOwner2 = ccr.CaptureCaseOwner1();
        log.info("RR Case Owner1 : "+caseOwner2);
        
        //If case owner is not queue ans if it is poms api or a user 
        if(!(caseOwner2.contains("K3") || caseOwner2.contains("K4-K10") || caseOwner2.contains("K12")))
        {
            log.info("Entering into if loop - Case owner is not queue");
            //Getting the case owner name
            caseOwner2 = ccr.CaptureCaseOwner();
            log.info("caseOwnerUser :"+caseOwner2);
            
            //If 1st RR case owner is queue, then 2nd RR case owner should be the account owner
            if(caseOwner1.equalsIgnoreCase(expectedQueue))
            {
                log.info("Verifying if case owner 2 is account owner when CO1 is queue");
                Assert.assertEquals(caseOwner2, accOwnerName);
                ac.CloseSubTabs();
            }
            
            //If case owner2 is acc owner but case owner 1 is user, check user availability
            else if(caseOwner2.equalsIgnoreCase(accOwnerName))
            {
                log.info("Entering into else loop - CO1 is user , CO2 is acc owner");
                
                log.info("Navigating to assignment rules");
                lo.navToAssignmentRules();
                
                log.info("Navigating to specific assignment rule");
                lo.navToAssignmentruleGroup(expectedQueue);
                
                log.info("Group members count : "+ar.getGroupMemCount());
                
                log.info("Navigating to group members");
                ar.navToGrpMem();
                List<WebElement> names = ar.GroupMembers();
                WebElement name;
                int count = 0;
                log.info("Capturing count of group members in weekoff/leave");
                for(int i=0;i<names.size();i++)
                {
                    name = names.get(i);
                    jsClick(name);
                    
                    //clicking to user details
                    ud.ClickUserDetailbutton();
                    ar.navToiframe("User");
                    
                    //verifying if the user is available or not
                    //checkMemAvailability returns false if member is not available
                    //Goes inside if loop when member is not available
                    if(!ar.checkMemAvailability())
                        count++;
                    lo.SwitchDefaultContent();
                    
                    //navigating back to main
                    lo.ReturntoMain();
                    ac.AdditionalWait();
                    ac.CloseCurrentSubTab();
                }
                closeTabWindows();
                
                //If no grp member is available after marking as long leave, then the case owner 2
                //should be account owner and case owner 1 should change to queue
                
                log.info("Verifying if all the group members are in weekoff/leave");
                Assert.assertEquals(count, grpMems.size());
                
                log.info("Verifying if the case owner 2 is queue as group members are in weekoff/leave");
                Assert.assertEquals(caseOwner2, accOwnerName);
                
                ac.goTo(AccountURL);
                
                ac.ClickCasesMC2();
                log.info("Navigating to 1st case");
                cases.ClickCaseNo(CaseNumber1);
                
                caseOwner1 = ccr.CaptureCaseOwner1();
                log.info("RR Case Owner1 : "+caseOwner1);
                
                
                //If all the grp members are not available, then case owner 1 is queue
                log.info("Verifying if the case owner 1 is queue as group members are in weekoff/leave");
                if(count == grpMems.size())
                Assert.assertEquals(caseOwner1, expectedQueue);
                
                //If case owner 1 is not queue, then 
                else if(!(caseOwner1.contains("K3") || caseOwner1.contains("K4-K10") || caseOwner1.contains("K12")))
                {
                    log.info("Verifying if the case owners of both the cases are same - If case owner 1 is not queue");
                    Assert.assertEquals(caseOwner1, caseOwner2);
                        
                    log.info("Verifying if the case owner is in the list of group members");
                    Assert.assertTrue(grpMems.contains(caseOwner2));
                }
                
                ac.CloseSubTabs();
            }
        }
        //If case owner is queue
        else
        {
            log.info("Entering else loop - If Case owner 2 is queue");
            //If there is only 1 group member and if that person is marked as long leave
            
            log.info("Verifying if Case owner 2 is expected queue");
            if(grpMems.size() == 1)
                Assert.assertEquals(caseOwner2, expectedQueue);
            
            else
            {
                log.info("Entering else loop - If group members>1");
                log.info("Navigating to assignment rules");
                lo.navToAssignmentRules();
                
                log.info("Navigating to specific assignment rule");
                lo.navToAssignmentruleGroup(expectedQueue);
                
                log.info(ar.getGroupMemCount());
                
                //If case owner is queue, verify if the group members are in week off
                log.info("Navigating to group members");
                ar.navToGrpMem();
                
                List<WebElement> names = ar.GroupMembers();
                WebElement name;
                int count = 0;
                log.info("Capturing count of group members in weekoff/leave");
                for(int i=0;i<names.size();i++)
                {
                    name = names.get(i);
                    jsClick(name);
                    
                    //clicking to user details
                    ud.ClickUserDetailbutton();
                    ar.navToiframe("User");
                    
                    //verifying if the user is available or not
                    //checkMemAvailability returns false if member is not available
                    //Goes inside if loop when member is not available
                    if(!ar.checkMemAvailability())
                        count++;
                    lo.SwitchDefaultContent();
                    
                    //navigating back to main
                    lo.ReturntoMain();
                    ac.AdditionalWait();
                    ac.CloseCurrentSubTab();
                }
                if(count == grpMems.size())
                {
                    log.info("Verifying if the case owner is queue as group members are in weekoff/leave");
                    Assert.assertEquals(caseOwner2, expectedQueue);
                }
                closeTabWindows();
            }
            
            ac.CloseCurrentSubTab();
            log.info("Navigating to 1st case");
            ac.ClickCasesMC2();
            cases.ClickCaseNo(CaseNumber1);
            
            caseOwner1 = ccr.CaptureCaseOwner1();
            log.info("RR Case Owner1 : "+caseOwner1);
            
            if(!(caseOwner2.contains("K3") || caseOwner2.contains("K4-K10") || caseOwner2.contains("K12")))
            {
                log.info("Enetering if loop to verify case owner 1");
                log.info("Verifying if the case owners of both the cases are same");
                Assert.assertEquals(caseOwner1, caseOwner2);
                    
                log.info("Verifying if the case owner 1 is in the list of group members");
                Assert.assertTrue(grpMems.contains(caseOwner2));
            }
            
            ac.CloseSubTabs();
        }
        
        String wh = driver.getWindowHandle();
        if(!DucaseOwner1.contains(expectedQueue))
        {
            log.info("Changing back the user availability to Available");
            ac.openUserinSetup(DucaseOwner1);
            us.ChangeUseravailability("Available");
            ac.CloseWindowArrayLast();
            driver.switchTo().window(wh);
            ac.CloseSubTabs();
            //lo.ReturntoMain();
        }
        
        ac.AdditionalWait();
        
        ac.ClickCasesMC2();
        //deletes all the cases
        cases.CloseAllCases();
        
        log.info("Deleting the Student Program details");
        ac.ClickAccOwnrTab();
        ac.DeleteCreatedStuProg();
        
        log.info("Deleting the Student Payment details");
        ac.DeleteAllCreatedStuPayment();
        
        ac.NavBackToAccount();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
        
    }
    
    //SFDC-3793-TC02
    @Test(groups = { "Regression" }, enabled = true)    
    public void Test_Reg_Retention7() throws Exception {

        loginPO lo = new loginPO(driver);
        CreatedAccountPO ac = new CreatedAccountPO(driver);
        CasesPO cases= new CasesPO(driver);
        
        String Accountid = "";
        al4 = excelData.getData("K4-10", "RRCaseAssignment", "Tcid");
        al5 = excelData.getData("shippedRegion", "RRCaseAssignment", "Tcid");
       
        //list of 2 programs selected randomly
        al6 = getTwoRandomProgramID(al4, al4, 1, 8);
        String prog1 = al6.get(0);
        String prog2 = al6.get(1);
        String shippedregion = al5.get(randomNumber(1, 8));
        String classNo = Integer.toString(randomNumber(4,7));
        
        if(CurrURL.contains("--byjusuat")) 
        {
            al = excelData.getData("TC1", "Retention", "Tcid");
            al2 = excelData.getData("Retention User UAT", "Login", "Type");
            al3 = excelData.getData("Admin", "Login", "Type");
            log.info("Logging in as Admin to UAT");
            lo.LoginAsAdmin_UAT();
            log.info("Submitting the Account creation payload");
            Accountid=payLoad_TwoPrgms.AccountidCreationResponse_UAT(prog1, prog2, shippedregion, classNo);
            log.info("Launching the newly created Account id "+Accountid);
        }
        
        else {
            al = excelData.getData("TC1", "Retention", "Tcid");
            al2 = excelData.getData("TC1", "ProdDummyUser", "Tcid");
            al3 = excelData.getData("AdminProd", "Login", "Type");
            log.info("Logging in as Admin to Prod");
            lo.LoginAsAdmin_Prod();
            
            log.info("Submitting the Account creation payload");
            Accountid=payLoad_TwoPrgms.AccountidCreationResponse_Prod(prog1, prog2, shippedregion, classNo);
            log.info("Launching the newly created Account id "+Accountid);
        }
        
        closeTabWindows();
        ac.Notification();
        String AccountURL=CurrURL+Accountid;
        ac.AdditionalWait();
        ac.goTo(AccountURL);
        log.info("program 1 : "+prog1);
        log.info("program 2 : "+prog2);
        log.info("shippedregion : "+shippedregion);
        log.info("classNo : "+classNo);
        ac.AccountLoadwait();
        
        //creating RR with 1st SSO Order
        log.info("Creating RR case by selecting 2 SSO's");
        RRCaseCreation("both");
        ac.CloseSubTabs();
        
        //***************SFDC-3793-TC02****************//
        log.info("Verifying if 2 RR cases are created");
        Assert.assertEquals(ac.CasesCount(), "(2)");
        ac.ClickCasesMC2();
        
        //deletes all the cases
        cases.CloseAllCases();
        
        log.info("Deleting the Student Program details");
        ac.ClickAccOwnrTab();
        ac.DeleteCreatedStuProg();
        
        log.info("Deleting the Student Payment details");
        ac.DeleteAllCreatedStuPayment();
        
        ac.NavBackToAccount();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
        
    }
    
    //SFDC-3793-TC03,TC04 - sibling accounts
    @Test(groups = { "Regression" }, enabled = true)    
    public void Test_Reg_Retention8() throws Exception {

        loginPO lo = new loginPO(driver);
        CreatedAccountPO ac = new CreatedAccountPO(driver);
        CasesPO cases= new CasesPO(driver);
        InboundTaskPO ibdt = new InboundTaskPO(driver);
        CreatedCaseRecordPO ccr= new CreatedCaseRecordPO(driver);
        NewCaseRecordTypePO ncrt= new NewCaseRecordTypePO(driver);
        IssueTreePO it = new IssueTreePO(driver);
        
        String Accountid1 = "";
        String Accountid2 = "";
        al4 = excelData.getData("K4-10", "RRCaseAssignment", "Tcid");
        al5 = excelData.getData("shippedRegion", "RRCaseAssignment", "Tcid");
       
        String prog1;
        String prog2;
        String shippedregion;
        String classNo;
        
        if(CurrURL.contains("--byjusuat")) 
        {
            al = excelData.getData("TC1", "Retention", "Tcid");
            al2 = excelData.getData("Retention User UAT", "Login", "Type");
            al3 = excelData.getData("Admin", "Login", "Type");
            log.info("Logging in as Admin to UAT");
            lo.LoginAsAdmin_UAT();
            log.info("Submitting the Account creation payload");
            
            //list of 2 programs selected randomly
            al6 = getTwoRandomProgramID(al4, al4, 1, 8);
            prog1 = al6.get(0);
            prog2 = al6.get(1);
            shippedregion = al5.get(randomNumber(1, 8));
            classNo = Integer.toString(randomNumber(4,7));
            
            
            Accountid1=payLoad_SinglePrgm.AccountidCreationResponse_UAT(prog1, shippedregion, classNo, "BHLP");
            log.info("Launching the newly created Account id "+Accountid1);
            
            shippedregion = al5.get(randomNumber(1, 8));
            classNo = Integer.toString(randomNumber(4,7));
            
            Accountid2=payLoad_SinglePrgm.AccountidCreationResponse_UAT(prog2, shippedregion, classNo,  "BHLP");
            log.info("Launching the newly created Account id "+Accountid2);
        }
        
        else {
            al = excelData.getData("TC1", "Retention", "Tcid");
            al2 = excelData.getData("TC1", "ProdDummyUser", "Tcid");
            al3 = excelData.getData("AdminProd", "Login", "Type");
            log.info("Logging in as Admin to Prod");
            lo.LoginAsAdmin_Prod();
            
            log.info("Submitting the Account creation payload");
            
            //list of 2 programs selected randomly
            al6 = getTwoRandomProgramID(al4, al4, 1, 8);
            prog1 = al6.get(0);
            prog2 = al6.get(1);
            shippedregion = al5.get(randomNumber(1, 8));
            classNo = Integer.toString(randomNumber(4,7));
            
            Accountid1=payLoad_SinglePrgm.AccountidCreationResponse_Prod(prog1, shippedregion, classNo, "BHLP");
            log.info("Launching the newly created Account id "+Accountid1);
            
            shippedregion = al5.get(randomNumber(1, 8));
            classNo = Integer.toString(randomNumber(4,7));
            
            Accountid2=payLoad_SinglePrgm.AccountidCreationResponse_Prod(prog2, shippedregion, classNo,  "BHLP");
            log.info("Launching the newly created Account id "+Accountid2);
        }
        
        String ssoName= "test"+classNo+randomNum;
        
        closeTabWindows();
        ac.Notification();
        String AccountURL1=CurrURL+Accountid1;
        String AccountURL2=CurrURL+Accountid2;
        ac.AdditionalWait();
        
        //getting 1st account name
        log.info("Opening first account");
        ac.goTo(AccountURL1);
        ac.AdditionalWait();
        ac.appendLastName("1");
        ac.ClickSaveName();
        ac.AdditionalWait();
        //lo.RefreshURL();
        String accName1 = ac.CaptureAccOwnrNam();

        //Changing the subject of SSO
        log.info("Changing the subject of SSO in 1st account");
        ac.AdditionalWait();
        ac.AddSubjectSSO(ssoName);
        ac.AdditionalWait();
        ac.closeCurrentTabWindow();
        
        //getting 2nd account name
        log.info("Opening second account");
        ac.goTo(AccountURL2);
        ac.AdditionalWait();
        ac.appendLastName("2");
        ac.ClickSaveName();
        ac.AdditionalWait();
//        /lo.RefreshURL();
        String accName2 = ac.CaptureAccOwnrNam();
        ac.AccountLoadwait();
        
        //adding 1st account as sibling
//        log.info("Adding 1st account as sibling in 2nd account");
//        ac.ClickRelatedCtctstoAddRS();
//        ac.SelectRole();
//        ac.EnterContactName(accName1);
//        ac.AdditionalWait();
//        ac.CloseCurrentSubTab();
        
        //adding SSO in student program
        log.info("Adding SSO in 2nd account with SSO name");
        ac.AdditionalWait();
        ac.AddSSOinSibling(ssoName);
        ac.AdditionalWait();
        ac.closeCurrentTabWindow();
        
        //adding 2nd account as sibling
        ac.goTo(AccountURL1);
//        ac.ClickRelatedCtctstoAddRS();
//        ac.SelectRole();
//        ac.EnterContactName(accName2);
//        ac.CloseCurrentSubTab();
//        ac.RefreshTab();
//        
        //creating RR with 1st SSO Order
        log.info("Creating Inbound Task");
        ac.AccountLoadwait();
        ac.ClickOpenActivitiestoNewTask1();
        ncrt.SelectCaseRecordTypeInbound();
        ncrt.ClickNext();
        ac.AdditionalWait();
        
        ncrt.ClickSave1();
        ac.AdditionalWait();
        
        ibdt.ClickCaptureDetail();
        ac.AccountLoadwait();
        
        ibdt.ClickProceedOptn();
        ibdt.SelectPSTCT(al.get(1));
        ibdt.ClickNext();
        log.info("Creating 1st RR Case");
        it.IssueCategory(al.get(4));
        it.Reason(al.get(5));
        it.SubReason(al.get(6));
        it.IssueNotes(al.get(7));
        it.IstheIssueResolved(al.get(8));
        it.ClickNext2();
        
        log.info("Selecting SSO Combination");
        it.SSOandAccCombo3(ssoName, accName1);
        ac.AccountLoadwait();
        it.ClickFinish();
        ac.AdditionalWait();
        
        lo.RefreshURL();
        ac.AdditionalWait();
        
        log.info("Verifying task status is completed");
        //verify if the task status is completed
        String Task_status = ibdt.CheckStatus();
        Assert.assertEquals(Task_status, "Completed");
        
        log.info("Opening RR case");
        ibdt.ClickRelatedToCaseNumber();
        //capture case no from case
        String CaseNumber1 = ccr.CaseNumberCreated();
        ac.RefreshTab();
        log.info("The case number is: "+CaseNumber1);
        
        //capture case status from case
        String caseStatus = ccr.CaptureCaseStatus();
        //verify the case status
        log.info("Verifying RR Case status");
        Assert.assertEquals(caseStatus, "Refund Requested");
        
        
        String caseOwner1 = ccr.CaptureCaseOwner1();
        log.info("RR Case Owner1 : "+caseOwner1);
        
        //If the case owner is queue change it to user for information task to be created
        if(caseOwner1.contains("K3") || caseOwner1.contains("K4-K10") || caseOwner1.contains("K12"))
        {
            log.info("Changing case owner to user if the case owner is queue");
            ccr.ChangeCaseOwner(al2.get(1));
            ac.AdditionalWait();
        }
        
        ac.closeCurrentTabWindow();
        
        ac.AdditionalWait();
        log.info("Opening 2nd account");
        ac.goTo(AccountURL2);
        
        //creating RR case with same SSO Order
        ac.AccountLoadwait();
        log.info("Creating Inbound Task");
        ac.ClickOpenActivitiestoNewTask1();
        ncrt.SelectCaseRecordTypeInbound();
        ncrt.ClickNext();
        ac.AdditionalWait();
        
        ncrt.ClickSave1();
        ac.AdditionalWait();
        
        ibdt.ClickCaptureDetail();
        ac.AccountLoadwait();
        
        ibdt.ClickProceedOptn();
        ibdt.SelectPSTCT(al.get(1));
        ibdt.ClickNext();
        log.info("Creating RR Case");
        it.IssueCategory(al.get(4));
        it.Reason(al.get(5));
        it.SubReason(al.get(6));
        it.IssueNotes(al.get(7));
        it.IstheIssueResolved(al.get(8));
        it.ClickNext2();
        
        log.info("Selecting SSO Combination");
        it.SSOandAccCombo3(ssoName, accName2);
        ac.AccountLoadwait();
        it.ClickFinish();
        ac.AdditionalWait();
        
        lo.RefreshURL();
        ac.AdditionalWait();
        
        log.info("Verifying task status is completed");
        //verify if the task status is completed
        Task_status = ibdt.CheckStatus();
        Assert.assertEquals(Task_status, "Completed");
        
        log.info("Opening RR case");
        ibdt.ClickRelatedToCaseNumber();
        //capture case no from case
        String CaseNumber2 = ccr.CaseNumberCreated();
        ac.RefreshTab();
        log.info("The case number is: "+CaseNumber2);
        
        log.info("Verifying if both the cases are same");
        Assert.assertEquals(CaseNumber1, CaseNumber2);
        
        String sibName = ccr.captureSiblingName();
        log.info("Verifying if the sibling name is added under siblings section on case");
        Assert.assertEquals(accName2, sibName);
        
        //***************SFDC-3793-TC04****************//
        
        //To check if Information Task is present 
        log.info("Opening information task");
        ncrt.ClickCreatedTaskActivityHistory("Information Task");
        String status_IT = ncrt.CaptureStatusofIT();
        
        log.info("Verifying if the task status is closed");
        Assert.assertEquals(status_IT, "Closed");
        ac.CloseSubTabs();
        
        ac.ClickCasesMC2();
        //deletes all the cases
        cases.CloseAllCases();
        
        log.info("Deleting the Student Program details");
        ac.ClickAccOwnrTab();
        ac.DeleteCreatedStuProg();
        
        log.info("Deleting the Student Payment details");
        ac.DeleteAllCreatedStuPayment();
        
        ac.NavBackToAccount();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
     
        ac.goTo(AccountURL1);
        
        ac.ClickCasesMC2();
        //deletes all the cases
        cases.CloseAllCases();
        
        log.info("Deleting the Student Program details");
        ac.ClickAccOwnrTab();
        ac.DeleteCreatedStuProg();
        
        
        log.info("Deleting the Student Payment details");
        ac.DeleteAllCreatedStuPayment();
        
        ac.NavBackToAccount();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
    }
    
    //Creates inbound task and RR Case
    public void RRCaseCreation(String order) throws Exception
    {
        CreatedAccountPO ac = new CreatedAccountPO(driver);
        InboundTaskPO ibdt = new InboundTaskPO(driver);
        IssueTreePO it = new IssueTreePO(driver);
        NewCaseRecordTypePO ncrt= new NewCaseRecordTypePO(driver);
        loginPO lo = new loginPO(driver);
        
        log.info("Creating Inbound Task");
        ac.ClickOpenActivitiestoNewTask1(); //doubt
        ncrt.SelectCaseRecordTypeInbound();
        ncrt.ClickNext();
        ac.AdditionalWait();
        
        ncrt.ClickSave1(); //doubt
        ac.AdditionalWait();
        
        ibdt.ClickCaptureDetail();
        ac.AccountLoadwait();
        
        ibdt.ClickProceedOptn();
        ibdt.SelectPSTCT(al.get(1));
        ibdt.ClickNext();
        log.info("Creating RR Case");
        it.IssueCategory(al.get(4));
        it.Reason(al.get(5));
        it.SubReason(al.get(6));
        it.IssueNotes(al.get(7));
        it.IstheIssueResolved(al.get(8));
        it.ClickNext2();
        
        log.info("Selecting SSO Combination");
        
        if(order.equals("both"))
            it.SSOandAccCombo2();
        else
            it.SSOandAccCombo1(order);
        ac.AccountLoadwait();
        it.ClickFinish();
        ac.AdditionalWait();
        
        lo.RefreshURL();
        ac.AdditionalWait();
        
        log.info("Verifying task status is completed");
        //verify if the task status is completed
        String Task_status = ibdt.CheckStatus();
        Assert.assertEquals(Task_status, "Completed");
    }
        
    @AfterMethod(alwaysRun = true)
    public void teardown() throws InterruptedException {

    driver.quit();

    }
    
    @DataProvider
    public Object[][] testDatapro() throws Exception {
        Object[][] data = readData(System.getProperty("user.dir") + "//src//main//java//testData//TestData.xlsx",
                "RRCaseAssignment_3");
        return data;
    }

}
