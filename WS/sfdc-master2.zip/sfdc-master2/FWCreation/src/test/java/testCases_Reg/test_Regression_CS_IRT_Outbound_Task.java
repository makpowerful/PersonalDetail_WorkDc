package testCases_Reg;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import junit.framework.Assert;
import pageObjects.CSInboundPO;
import pageObjects.CreatedAccountPO;
import pageObjects.InboundTaskPO;
import pageObjects.NewCaseRecordTypePO;
import pageObjects.OpenActivitiesPO;
import pageObjects.UnregisteredCustomersDetailCaptureTaskPO;
import pageObjects.loginPO;
import payLoad.payLoad_BTLA_Customer_Support;
import resources.ExcelData;
import resources.base;

public class test_Regression_CS_IRT_Outbound_Task extends base {

    public WebDriver driver;
    ExcelData excelData = new ExcelData();
    public static Logger log = LogManager.getLogger(test_Regression_CS_IRT_Outbound_Task.class.getName());
    ArrayList<String> a1 = new ArrayList<String>();
    ArrayList<String> a2 = new ArrayList<String>();
    ArrayList<String> a3 = new ArrayList<String>();
    ArrayList<String> al3 = new ArrayList<String>();
    ArrayList<String> al4 = new ArrayList<String>();
    ArrayList<String> al5 = new ArrayList<String>();
    ArrayList<String> al6 = new ArrayList<String>();

    @BeforeMethod(alwaysRun = true)
    public void initialize() throws IOException, InterruptedException {

        driver = initializeDriver();

    }

    // Jira Story= SFDC-801
    @Test(priority = 5, enabled = true, groups = { "Regression", "UAT","sanity" })
    public void Test_Reg_CSToLSIntegrationSFDC801() throws Exception {
        String Accountid = null;
        // String AccountOwner = null;

        loginPO lo = new loginPO(driver);
        a1 = excelData.getData("TC1", "CSInbound", "Tcid");
        a2 = excelData.getData("CS User UAT", "Login", "Type");
        al6 = excelData.getData("TC1", "EFA-LIG", "Tcid");
        a3 = excelData.getData("TC2", "ProdDummyUser", "Tcid");

        log.info("Logging in as Admin to UAT then switching user to Customer Support");

        if (CurrURL.contains("--byjusuat")) {

            // al2 = excelData.getData("Collection Assistant", "Login", "Type");

            log.info("Logging in as Admin to UAT");
            lo.LoginAsAdmin_UAT();
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_BTLA_Customer_Support.AccountidCreationResponse_UAT();
            log.info("Launching the newly created Account id " + Accountid);

        }
        if (CurrURL.contains("byjusprod.")) {

            log.info("Login in as Admin into Prod");
            lo.LoginAsAdmin_Prod();
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_BTLA_Customer_Support.AccountidCreationResponse_Prod();
            log.info("Launching the newly created Account id " + Accountid);

        }
        // lo.LoginAsAdmin_UAT();

        // Accountid = payLoad_BTLA_Customer_Support2.AccountidCreationResponse_UAT();
        // log.info("The new account is created" + Accountid);

        CreatedAccountPO ac = new CreatedAccountPO(driver);
        ac.closeTabWindows();
        CSInboundPO cip = new CSInboundPO(driver);
        NewCaseRecordTypePO ncrt = new NewCaseRecordTypePO(driver);
        InboundTaskPO ibdt = new InboundTaskPO(driver);
        UnregisteredCustomersDetailCaptureTaskPO ucdc = new UnregisteredCustomersDetailCaptureTaskPO(driver);
        ac.Notification();
        ac.NavBackToAccount();

        String AccountURL = CurrURL + Accountid;
        ac.goTo(AccountURL);
        ac.AccountLoadwait();

        /*
         * AccountOwner = ac.AccOwnerCheck();
         * if (!a2.get(1).equalsIgnoreCase(AccountOwner)) {
         * ac.AssignAccount(a2.get(1));
         * } else {
         * ac.AssignAccount("Sumit Dash");
         * }
         */
        ac.Scrollpagedown();

        // Switching to CS profile
        /*
         * if (CurrURL.contains("--byjusuat")) {
         * ac.AdditionalWait();
         * lo.SwitchUser(a2.get(1));
         */

        if (CurrURL.contains("--byjusuat")) {
            String AccountOwner = ac.AccOwnerCheck();
            if (!a2.get(1).equalsIgnoreCase(AccountOwner)) {
                ac.AssignAccount(a2.get(1));
            }
        } else {
            ac.AssignAccount("Testing User");
        }

        if (CurrURL.contains("--byjusuat")) {

            lo.SwitchUser(a2.get(1));
        }

        if (CurrURL.contains("--byjusprod")) {
            lo.SwitchUsernProfile_Prod(a3.get(1), "Customer Support");
            // lo.SwitchUser(a3.get(1));
        }

        ac.closeTabWindows();
        ac.Notification();
        ac.NavBackToAccount();
        ac.goTo(AccountURL);
        String AccountName = ac.CaptureAccOwnrNam();
        log.info("Creating Inbound Task");
        ac.ClickOpenActivitiestoNewTask();
        ncrt.UCDetailsCapture();
        ncrt.ClickNext();
        String number = cip.tenDigitNumber();
        cip.textFieldCallBackNumber(number);
        ncrt.ClickSave();
        ibdt.ClickCaptureDetail();
        cip.EnterCallType(a1.get(2));
        cip.EnterCallStatus(a1.get(3));
        cip.EnterCustomerType(a1.get(4));
        cip.textFieldSearchStudentCS(AccountName);
        cip.ClicktextFieldSearchStudentResult(AccountName);
        ncrt.ClickNextButton();
        cip.csstudentnameverify();
        cip.csParentNameverify();
        cip.csPhoneverify();
        cip.csStatusverify();
        cip.csSuperStatusverify();
        cip.csEmailverify();
        ucdc.SelectEnquiryType(a1.get(5));
        ucdc.SelectEnquiryType(a1.get(5));
        ucdc.SelectReasonForCall(a1.get(6));
        ucdc.SelectCourse(a1.get(7));
        ucdc.SelectCountry(a1.get(8));
        ucdc.ClickNext();
        ac.AdditionalWait();
        ucdc.EnterName(AccountName);
        ucdc.EnterLanguage(a1.get(10));
        ucdc.EnterCity(a1.get(9));
        ucdc.EnterReasonForCall(a1.get(11));
        ucdc.EnterGrade(a1.get(12));
        ucdc.EnterCourse(a1.get(13));
        ucdc.EnterEnquiryBy(a1.get(14));
        ucdc.EnterPurchasedCourseBefore(a1.get(15));
        ucdc.EnterIsthisrepeatcall(a1.get(16));
        ucdc.EnterBriefComment(a1.get(17));
        ucdc.EnterHDYKAByjus(a1.get(18));
        ac.AdditionalWait();
        ucdc.ClickNext();
        ucdc.Selecttransfercall(al6.get(21));
        ucdc.ClickNext();
        ac.AdditionalWait();
        ucdc.ClickNext();
        ac.AdditionalWait();
        lo.RefreshURL();
        // Verify Task is added to account
        ac.CloseCurrentSubTab();

        OpenActivitiesPO oa = new OpenActivitiesPO(driver);
        // verify the task 'Primary IRT_Manual -' is present
        Assert.assertTrue(oa.VerifyTaskpresent("Primary IRT_Manual -"));
        if(CurrURL.contains("--byjusuat")) {
            lo.Logouthome();

            ac.closeTabWindows();
            ac.goTo(AccountURL);
            ac.AdditionalWait();  
        }
        else {
            ac.CloseSubTabs(); 
        }
        
        

        log.info("Deleting the Student Program details");
        ac.DeleteCreatedStuProg();
        ac.DeleteAllCreatedStuPayment();
        ac.NavBackToAccount();
        log.info("Deleting the Account details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());

    }

    @AfterMethod(alwaysRun = true)
    public void teardown() throws InterruptedException {

        driver.quit();

        // Thread.sleep(2000);
    }
}
