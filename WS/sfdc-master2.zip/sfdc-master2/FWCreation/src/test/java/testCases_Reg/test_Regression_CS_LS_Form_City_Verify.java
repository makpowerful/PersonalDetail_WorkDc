package testCases_Reg;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import junit.framework.Assert;
import pageObjects.CSInboundPO;
import pageObjects.CasesPO;
import pageObjects.CreatedAccountPO;
import pageObjects.InboundTaskPO;
import pageObjects.IssueTreePO;
import pageObjects.NewCaseRecordTypePO;
import pageObjects.OpenActivitiesPO;
import pageObjects.UnregisteredCustomersDetailCaptureTaskPO;
import pageObjects.loginPO;
import payLoad.payLoad_BTLA_Customer_Support;
import resources.ExcelData;
import resources.base;

public class test_Regression_CS_LS_Form_City_Verify extends base {

    public WebDriver driver;
    ExcelData excelData = new ExcelData();
    public static Logger log = LogManager.getLogger(test_Regression_CS_LS_Form_City_Verify.class.getName());
    ArrayList<String> a1 = new ArrayList<String>();
    ArrayList<String> a2 = new ArrayList<String>();
    ArrayList<String> a3 = new ArrayList<String>();
    ArrayList<String> al3 = new ArrayList<String>();
    ArrayList<String> al4 = new ArrayList<String>();
    ArrayList<String> al5 = new ArrayList<String>();
    ArrayList<String> al6 = new ArrayList<String>();

    @BeforeMethod(alwaysRun = true)
    public void initialize() throws IOException, InterruptedException {

        driver = initializeDriver();

    }


    // Jira Story=SFDC-3878, SFDC-2606+SFTNL-8200
    @Test(priority = 3, enabled = true,groups = { "Regression", "UAT","sanity" })
    public void Test_Reg_CSToLSIntegrationSFDC3878() throws Exception {
        String Accountid = null;
        // String AccountOwner = null;

        CasesPO cases = new CasesPO(driver);

        loginPO lo = new loginPO(driver);
        a1 = excelData.getData("TC1", "CSInbound", "Tcid");
        a2 = excelData.getData("CS User UAT", "Login", "Type");
        al5 = excelData.getData("TC3", "RefundProcess", "Tcid");
        al6 = excelData.getData("TC1", "EFA-LIG", "Tcid");

        log.info("Logging in as Admin to UAT then switching user to Customer Support");

        if (CurrURL.contains("--byjusuat")) {

            // al2 = excelData.getData("Collection Assistant", "Login", "Type");

            log.info("Logging in as Admin to UAT");
            lo.LoginAsAdmin_UAT();
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_BTLA_Customer_Support.AccountidCreationResponse_UAT();
            log.info("Launching the newly created Account id " + Accountid);

        }
        if (CurrURL.contains("byjusprod.")) {

            log.info("Login in as Admin into Prod");
            lo.LoginAsAdmin_Prod();
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_BTLA_Customer_Support.AccountidCreationResponse_Prod();
            log.info("Launching the newly created Account id " + Accountid);

        }

      
        CreatedAccountPO ac = new CreatedAccountPO(driver);
        ac.closeTabWindows();
        CSInboundPO cip = new CSInboundPO(driver);
        NewCaseRecordTypePO ncrt = new NewCaseRecordTypePO(driver);
        InboundTaskPO ibdt = new InboundTaskPO(driver);
        UnregisteredCustomersDetailCaptureTaskPO ucdc = new UnregisteredCustomersDetailCaptureTaskPO(driver);
        ac.Notification();
        ac.NavBackToAccount();

        String AccountURL = CurrURL + Accountid;
        ac.goTo(AccountURL);
        ac.AccountLoadwait();

        if (CurrURL.contains("--byjusuat")) {
            String AccountOwner = ac.AccOwnerCheck();
            if (!a2.get(1).equalsIgnoreCase(AccountOwner)) {
                ac.AssignAccount(a2.get(1));
            }

            else {
                ac.AssignAccount("Testing User");
            }
            ac.Scrollpagedown();

            // Creating an inbound task
            log.info("Creating Inbound Task");
            ac.ClickOpenActivitiestoNewTask();

            ncrt.SelectCaseRecordTypeInbound();
            ncrt.ClickNext();
            ac.AdditionalWait();
            ncrt.ClickSave();
            ac.AdditionalWait();

            // Creating an RR case
            ibdt.ClickCaptureDetail();
            Thread.sleep(3000);

            ibdt.ClickProceedOptn();
            if (CurrURL.contains("--byjusuat") || CurrURL.contains("--byjusuatfc") || CurrURL.contains("byjusprod.")) {
                al3 = excelData.getData("Inbound", "Inbound", "Tcid");
                al4 = excelData.getData("TC2", "EasyPayCollection", "Tcid");
                IssueTreePO it = new IssueTreePO(driver);
                if (!CurrURL.contains("--byjusuatfc")) {
                    ibdt.SelectSpokeTo3(al3.get(1));
                    it.PremiumidSelector();
                    it.ProgramSelector();
                    it.ClickNext();
                }
                ibdt.SelectPSTCT(al3.get(2));
                // ibdt.EnterNotesVal(al3.get(3));
                ibdt.ClickNext();
                ac.AdditionalWait();
                it.IssueCategory(al5.get(13));
                it.Reason(al5.get(14));
                it.SubReason(al5.get(15));
                it.IssueNotes(al4.get(15));
                it.IstheIssueResolved(al4.get(16));
                it.ClickNext();
                it.ClickNext3();
                it.SSOandAccCombo();
                it.ClickFinish();
            }

            // Switching to CS profile
            if (CurrURL.contains("--byjusuat")) {
                ac.AdditionalWait();
                lo.SwitchUser(a2.get(1));
                ac.closeTabWindows();
                ac.Notification();
                ac.NavBackToAccount();
                ac.goTo(AccountURL);
                String AccountName = ac.CaptureAccOwnrNam();
                log.info("Creating Inbound Task");
                ac.ClickOpenActivitiestoNewTask();
                ncrt.UCDetailsCapture();
                ncrt.ClickNext();
                String number = cip.tenDigitNumber();
                cip.InbusinessHours();
                cip.textFieldCallBackNumber(number);
                ncrt.ClickSave();
                ibdt.ClickCaptureDetail();
                cip.EnterCallType(a1.get(2));
                cip.EnterCallStatus(a1.get(3));
                cip.EnterCustomerType(a1.get(4));
                cip.textFieldSearchStudentCS(AccountName);
                cip.ClicktextFieldSearchStudentResult(AccountName);
                ncrt.ClickNextButton();
                cip.csstudentnameverify();
                cip.csParentNameverify();
                cip.csPhoneverify();
                cip.csStatusverify();
                cip.csSuperStatusverify();
                cip.csEmailverify();

                ucdc.SelectEnquiryType(a1.get(5));
                ucdc.SelectEnquiryType(a1.get(5));
                ucdc.SelectReasonForCall(a1.get(6));
                ucdc.SelectCourse(a1.get(7));
                ucdc.SelectCountry(a1.get(8));
                ucdc.ClickNext();
                ac.AdditionalWait();
                ucdc.EnterName(AccountName);
                ucdc.EnterLanguage(a1.get(10));

                // SFDC-3878
                // String bang = ucdc.verifyCity(searchCity1);
                // Assert.assertEquals(city1, bang);
                // String del = ucdc.verifyCity(searchCity2);
                // Assert.assertEquals(city2, del);
                // String ahm = ucdc.verifyCity(searchCity3);
                // Assert.assertEquals(city3, ahm);
                ucdc.EnterCity(a1.get(9));
                ucdc.EnterReasonForCall(a1.get(11));
                ucdc.EnterGrade(a1.get(12));
                ucdc.EnterCourse(a1.get(13));
                ucdc.EnterEnquiryBy(a1.get(14));
                ucdc.EnterPurchasedCourseBefore(a1.get(15));
                ucdc.EnterIsthisrepeatcall(a1.get(16));
                ucdc.EnterBriefComment(a1.get(17));
                ucdc.EnterHDYKAByjus(a1.get(18));
                ac.AdditionalWait();
                ucdc.ClickNext();

                // SFDC-2606+SFTNL-8200
                ucdc.SelectTasktoCentralRetentionTeam(al6.get(21));
                ucdc.ClickNext();
                ac.AdditionalWait();
                ucdc.ClickNext();
                ac.AdditionalWait();
                lo.RefreshURL();
                // Verify Task is added to account
                ac.CloseCurrentSubTab();

                OpenActivitiesPO oa = new OpenActivitiesPO(driver);
                // verify the task 'Primary Retention Outbound Required' is present
                Assert.assertTrue(oa.VerifyTaskpresent("Primary Retention Outbound Required"));
                lo.Logouthome();

                ac.closeTabWindows();
                ac.goTo(AccountURL);
                ac.AdditionalWait();

                // Deleting the created case
                ac.ClickCasesMC2();
                ac.AdditionalWait();
                cases.CloseAllCases();



            }
            log.info("Deleting the Student Program details");
            ac.ClickAccOwnrTab();
            ac.DeleteAllCreatedStuProg();
            ac.DeleteAllCreatedStuPayment();
            ac.NavBackToAccount();
            log.info("Deleting the Account created details");
            ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
        }
    }

    @AfterMethod(alwaysRun = true)
    public void teardown() throws InterruptedException {

        driver.quit();

        // Thread.sleep(2000);
    }
}
