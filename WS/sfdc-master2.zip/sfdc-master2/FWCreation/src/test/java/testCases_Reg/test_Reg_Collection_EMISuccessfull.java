package testCases_Reg;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import pageObjects.CapturePaymentDetailsEMIPO;
import pageObjects.CapturePaymtDetailsPTPPO;
import pageObjects.CasesPO;
import pageObjects.CollectionAssistantLoginPO;
import pageObjects.CreatedAccountPO;
import pageObjects.CreatedCaseRecordPO;
import pageObjects.FirstConnectPO;
import pageObjects.FollowUpPTPPO;
import pageObjects.NPPaymentLoanPO;
import pageObjects.NewCaseDetailsPO;
import pageObjects.NewCaseRecordTypePO;
import pageObjects.NewPaymentPO;
import pageObjects.NewPaymentRecordPO;
import pageObjects.PaymentCaseQAPO;
import pageObjects.PaymentsPO;
import pageObjects.TasksPO;
import pageObjects.UserDetailPO;
import pageObjects.UserSetupPO;
import pageObjects.loginPO;
import resources.ExcelData;
import resources.base;
import testCases.test_CollectionFlow;

public class test_Reg_Collection_EMISuccessfull extends base {

	public WebDriver driver;
	//ThreadLocal<WebDriver> driver = new ThreadLocal<WebDriver>();
	//public String CurrURL;
	public static Logger log = LogManager.getLogger(test_CollectionFlow.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	ArrayList<String> al3 = new ArrayList<String>();
	ArrayList<String> al4 = new ArrayList<String>();
	static Faker faker = new Faker();
	static String firstName = faker.name().firstName();
	static String lastName = faker.name().lastName();
	static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);
	static String PaymentRecord;
	static String Colluser;
	static String CaseRecord;
	static String Firstconnect_status;
	static String Firstconnect_callstatus;
	static String paymentURL;
	String Firstconnect_caseid;
	String CaseStatus;
	String CaseOwner;
	String RelatedCaseRecord;
	String AssignedToOwner;
	String Followup_status;
    String Followup_callstatus;
	
    @BeforeMethod(alwaysRun = true)
    public void initialize() throws IOException, InterruptedException {

        driver = initializeDriver();
    }
    	                            
    
	@Test(groups = { "Regression" ,"sanity"},priority=1, enabled = true)
	public void Reg_Collection_EMISuccessfull() throws Exception {
	    
	    loginPO lo=new loginPO(driver);
	    CreatedAccountPO ac=new CreatedAccountPO(driver);
	    PaymentsPO p = new PaymentsPO(driver);
	    NewPaymentPO np = new NewPaymentPO(driver);
	    NPPaymentLoanPO npp = new NPPaymentLoanPO(driver);
	    NewPaymentRecordPO npr = new NewPaymentRecordPO(driver);
	    CreatedCaseRecordPO ccr = new CreatedCaseRecordPO(driver);
	    TasksPO t = new TasksPO(driver);
	    FirstConnectPO fc = new FirstConnectPO(driver);
	    CapturePaymentDetailsEMIPO cpd = new CapturePaymentDetailsEMIPO(driver);
	    FollowUpPTPPO fuptp = new FollowUpPTPPO(driver);
	    CapturePaymtDetailsPTPPO cpdptp = new CapturePaymtDetailsPTPPO(driver);
	    
	    if(CurrURL.contains("--byjusuat")) 
	    {
	        al = excelData.getData("TC7", "CollectionFlow", "Tcid");
	        al2 = excelData.getData("CollectionAssistant UAT", "Login", "Type");
    		al3 = excelData.getData("CollectionManager UAT", "Login", "Type");
    		al4 = excelData.getData("Admin", "Login", "Type");
    		log.info("Logging in as Admin to UAT");
    		lo.LoginAsAdmin_UAT();
		}
		else 
		{
		    al = excelData.getData("TC7", "CollectionFlow", "Tcid");
            al2 = excelData.getData("Dummy Collection Associate", "Login", "Type"); 
            al4 = excelData.getData("AdminProd", "Login", "Type");
            log.info("Logging in as Admin to Prod");
            lo.LoginAsAdmin_Prod();
		}
	    
		
		closeTabWindows();    
		log.info("Creating new Payment record");
		
		ac.Notification();
		//payment 
        p.NavMenuClick();
        p.PaymntNavMenuClick();
        p.NewPaymentClick();
        
        log.info("Selection of Payment - Loan record");     
        np.SelectPaymentOptn(al.get(1));
        np.ClickNext();
    
        log.info("Enter New Payment - Loan details");

        //entering details to create payment record
        npp.checkPageReady();
        npp.EnterParentFN(firstName);
        npp.EnterParentLN(lastName);
        npp.EnterLoanAmount(al.get(2));
        npp.EnterTenurity(al.get(4));
        npp.EnterProgramName(al.get(3));
        
        //************* SFDC-3499 - TC01 *****************//

        String epPartner1=npp.epPartnerCheck(al.get(5));
        Assert.assertEquals("Poonawalla", epPartner1);  
        log.info("EP Partner is : "+epPartner1); 
        npp.EnterEPPartner(epPartner1);

        npp.EnterAmount(al.get(6));
        npp.EnterTotalAmountTBC(al.get(7));
        npp.EnterNetPayAmount(al.get(8));
        npp.EnterPaymentAmount(al.get(9));
        npp.EnterPaymentCategory(al.get(10));
        npp.EnterPaymentMS(al.get(11));
        npp.EnterPaymentDate(al.get(12));
        npp.EnterPaymentType(al.get(13));
        npp.ClickSave();   
        ac.AdditionalWait();
        
        PaymentRecord = npr.CapturePaymentRcdID();
        System.out.println(PaymentRecord);
        paymentURL = driver.getCurrentUrl();
        log.info("New Payment Record " + PaymentRecord + " created successfully");  
        npr.ClickCasesbtn();

        //************* SFDC-3499 - TC02 *****************//
    
        //creating an EMI Case and case assignment
        EMICaseCnA();
        
        //Executing first connect task
        Firstconnect_caseid = fc.CaptureFCcaseid();
        // Compare the Case Record to First connect case Record 
        Assert.assertEquals(CaseRecord, Firstconnect_caseid);
        
        log.info("Providing Capture payment detail for Case record " + Firstconnect_caseid);
        fc.ClickCapturePayment();

        cpd.EnterRating(al.get(15));
        cpd.ClickNext();
        
        //EMI successful flow
        cpd.SelectPaymntOptn(al.get(16));
        log.info("Selected payment option " + al.get(16));
        cpd.ClickNext();    
        
        //************* SFDC-3498 - TC02 *****************//
        
        Assert.assertEquals(cpd.getAmtpaid(), al.get(6));
        cpd.EnterAmtpaid(al.get(17));
        
        //************* SFDC-3620 - TC01 *****************//
        //verifying payment method as Paytm in first connect task
        
        String paymentMethod1 = cpd.verifyPaymntOptn(al.get(18));
        Assert.assertEquals("Paytm", paymentMethod1);  
        log.info("Payment method is : "+paymentMethod1); 
        
        cpd.SelectPaymentMethod(paymentMethod1);
        cpd.EnterPaymntRefVal(randomNum);
        
        //************* SFDC-3498 - TC04 *****************//
        String collchannel = cpd.getCollchannel(al.get(19));
        Assert.assertEquals("TL Collect", collchannel);  
        log.info("Collection channel is : " + collchannel); 
        
        cpd.SelectCollectionchannel(collchannel);
        cpd.ClickNext();
        
        cpd.SelectEMIcoll(al.get(20));
        cpd.SelectTypofCollPaid(al.get(21));
        cpd.ClickNext();
        
        cpd.SelectElgfrRef(al.get(22));
        cpd.ClickNext();
        ac.AccountLoadwait();
        fc.RefreshPage(); 

        Firstconnect_status = fc.CheckFCStatus();
        // Verify the Status for first connect is changed to Completed
        Assert.assertEquals(Firstconnect_status, "Completed");
        
        Firstconnect_callstatus = fc.CheckFCCallStatus();
        // Verify the Call Status for first connect is changed to Payment Confirmed
        Assert.assertEquals(Firstconnect_callstatus, "Payment Confirmed");
        
        log.info("Logging out as Collection Assistant");
        ac.AdditionalWait();
        //cal.Logout();
        lo.Logouthome();

        //verify epPartner in the audit case and delete all the cases 
        CasesDeletion(epPartner1,paymentMethod1);

       //************* SFDC-3499 - TC03 *****************//
        
        EMICaseCnA();  
        
        al = excelData.getData("TC3", "CollectionFlow", "Tcid");
        //Executing first connect task
        Firstconnect_caseid = fc.CaptureFCcaseid();
        
        // Compare the Case Record to First connect case Record 
        Assert.assertEquals(CaseRecord, Firstconnect_caseid);
        
        log.info("Selecting ptp option for " + Firstconnect_caseid);          
        fc.ClickCapturePayment();
        cpd.navToiframe("accessibility title");
        cpdptp.SelectPaymntOptn(al.get(16));
        log.info("Selected payment option - " + al.get(16));
        cpdptp.ClickNext();   
        cpdptp.SelectNoofEMI(al.get(31));
        cpdptp.EnterPhoneNo(al.get(32));

        //************* SFDC-3498 - TC01 *****************//

        
        if(CurrURL.contains("--byjusuat")) 
        {
           //checking default date and time
            String[] data=cpdptp.getDefaultDateTimePTP("--byjusuat");
            Assert.assertEquals(data[1], data[0]);
            Assert.assertEquals(data[2], "8:00 PM");
            
            //entering wrong to date to check error
            cpdptp.EnterDateerrormess();
            cpdptp.EnterComments(al.get(33));
            cpdptp.SelectPTPGivenBy(al.get(34));
            cpdptp.ClickNext();      
            
            // Verify the error message
            String DateErrorMess = cpdptp.CapturDateError(); 
            Assert.assertEquals(DateErrorMess, "Please fill 'Due Date/Time' within today only.");
            
            //entering correct date
            cpdptp.EnterDateTimePTP();
            cpdptp.ClickNext();
        }
        else 
        { 
            String[] data=cpdptp.getDefaultDateTimePTP("prod");
            Assert.assertEquals(data[1], data[0]);
            Assert.assertEquals(data[2], "8:00 PM");
            cpdptp.EnterDateerrormessProd();
            cpdptp.EnterComments(al.get(33));
            cpdptp.SelectPTPGivenBy(al.get(34));
            cpdptp.ClickNext();
            String DateErrorMess = cpdptp.CapturDateError();
            // Verify the error message
            Assert.assertEquals(DateErrorMess, "Please fill 'Due Date/Time' within today only.");
            cpdptp.EnterDateTimePTPProd();
            cpdptp.ClickNext();
        }
        
        ac.AdditionalWait();
        cpdptp.ClickNextSwitchDefault();
        ac.AdditionalWait();
        fc.RefreshPage();
        
        Firstconnect_status = fc.CheckFCStatus();
        // Verify the Status for first connect is changed to Completed
        Assert.assertEquals(Firstconnect_status, "Completed");
        
        Firstconnect_callstatus = fc.CheckFCCallStatus();
        // Verify the Call Status for first connect is changed to Payment Confirmed
        Assert.assertEquals(Firstconnect_callstatus, "PTP");
        
        closeTabWindows();
        log.info("Verifying the Follow up Task is created");
        t.NavBackToTask();
        t.SelectCR(CaseRecord);

        ccr.ClickFollowPTPRcd(CaseRecord);
        AssignedToOwner = fuptp.CaptureAssignedTo();
        Assert.assertTrue(AssignedToOwner.equalsIgnoreCase(Colluser));
        
        //Capture payment flow - in follow up
        
        al = excelData.getData("TC7", "CollectionFlow", "Tcid");
        
        // Compare the Case Record to First connect case Record 
        Assert.assertEquals(CaseRecord, Firstconnect_caseid);
        log.info("Providing Capture payment detail for Case record " + Firstconnect_caseid);
        fc.ClickCapturePayment(); 
        
        //EMI successful flow 
        cpd.navToiframe("accessibility title");
        cpd.SelectPaymntOptn(al.get(16));
        log.info("Selected the payment option " + al.get(16));
        cpd.ClickNext();    
        
        // ********** SFDC-3620 - TC02 ***********//
        //verifying payment method as Paytm in follow up task
        
        paymentMethod1 = cpd.verifyPaymntOptn(al.get(18));
        Assert.assertEquals("Paytm", paymentMethod1);  
        log.info("Payment method is : "+paymentMethod1); 
        
        cpd.SelectPaymentMethod(al.get(18));
        cpd.SelectCollectionchannel(al.get(19));
        cpd.ClickNext();
        
        cpd.EnterPaymntRefVal(randomNum);
        cpd.ClickNext();
        
        cpd.SelectEMIcoll(al.get(20));
        cpd.SelectTypofCollPaid(al.get(21));
        cpd.ClickNext();
        
        cpd.SelectElgfrRef(al.get(22));
        cpd.ClickNext();
        ac.AccountLoadwait();
        fc.RefreshPage(); 
        
        Followup_status = fc.CheckFCStatus();
        Assert.assertEquals(Followup_status, "Completed");

        Followup_callstatus = fc.CheckFCCallStatus();
        Assert.assertEquals(Followup_callstatus, "Payment Confirmed");
        
        log.info("Logging out as Collection Assistant");
        ac.AdditionalWait();
        lo.Logouthome();

        CasesDeletion(epPartner1,paymentMethod1);

        log.info("Deleting the created Payment Record " + PaymentRecord);
        p.NavMenuClick();
        p.PaymntNavMenuClick();
        p.DeletePayRecord(PaymentRecord);

        
      //*************** Creating new payment record *******************//
        
        al = excelData.getData("TC8", "CollectionFlow", "Tcid");
        
        //payment
        p.NewPaymentClick();
        log.info("Selection of Payment - Loan record");
        np.SelectPaymentOptn(al.get(1));
        np.ClickNext();
        log.info("Enter New Payment - Loan details");

        //entering details to create payment record
        npp.checkPageReady();
        npp.EnterParentFN(firstName);
        npp.EnterParentLN(lastName);
        npp.EnterLoanAmount(al.get(2));
        npp.EnterTenurity(al.get(4));
        npp.EnterProgramName(al.get(3));
        
        //*************SFDC-3499 - TC04*****************//

        String epPartner2=npp.epPartnerCheck(al.get(5));

        Assert.assertEquals("Credit Saison", epPartner2);
        log.info("EP Partner is : "+epPartner2);
        npp.EnterEPPartner(epPartner2);
        npp.EnterAmount(al.get(6));
        npp.EnterTotalAmountTBC(al.get(7));
        npp.EnterNetPayAmount(al.get(8));
        npp.EnterPaymentAmount(al.get(9));
        npp.EnterPaymentCategory(al.get(10));
        npp.EnterPaymentMS(al.get(11));
        npp.EnterPaymentDate(al.get(12));
        npp.EnterPaymentType(al.get(13));
        npp.ClickSave();
        ac.AdditionalWait();
        
        paymentURL = driver.getCurrentUrl();
        PaymentRecord = npr.CapturePaymentRcdID();
        System.out.println(PaymentRecord);
        log.info("New Payment Record " + PaymentRecord + " created successfully");
        npr.ClickCasesbtn();

        //*************SFDC-3499 - TC05*****************//
        
        //creating an EMI Case and case assignment
        EMICaseCnA();
        //Executing first connect task
        Firstconnect_caseid = fc.CaptureFCcaseid();
        // Compare the Case Record to First connect case Record
        Assert.assertEquals(CaseRecord, Firstconnect_caseid);
        log.info("Providing Capture payment detail for Case record " + Firstconnect_caseid);
        fc.ClickCapturePayment();

        cpd.EnterRating(al.get(15));
        cpd.ClickNext();
        //EMI successful flow
        cpd.SelectPaymntOptn(al.get(16));
        log.info("Selected the payment option " + al.get(16));
        cpd.ClickNext();
        
        //************* SFDC-3861 - TC01 *****************//
        //verifying payment method as Payment shell in first connect task
        
        String paymentMethod2 = cpd.verifyPaymntOptn(al.get(18));
        Assert.assertEquals("Payment Shell", paymentMethod2);  
        log.info("Payment method is : "+paymentMethod2); 
        
        cpd.SelectPaymentMethod(paymentMethod2);
        cpd.EnterPaymntRefVal(randomNum);
        cpd.SelectCollectionchannel(al.get(19));
        cpd.ClickNext();
        
        cpd.SelectEMIcoll(al.get(20));
        cpd.SelectTypofCollPaid(al.get(21));
        cpd.ClickNext();
        
        cpd.SelectElgfrRef(al.get(22));
        cpd.ClickNext();
        ac.AccountLoadwait();
        fc.RefreshPage(); 

        Firstconnect_status = fc.CheckFCStatus();
        // Verify the Status for first connect is changed to Completed
        Assert.assertEquals(Firstconnect_status, "Completed");
        
        Firstconnect_callstatus = fc.CheckFCCallStatus();
        // Verify the Call Status for first connect is changed to Payment Confirmed
        Assert.assertEquals(Firstconnect_callstatus, "Payment Confirmed");
        log.info("Logging out as Collection Assistant");
        ac.AdditionalWait();

        lo.Logouthome();

        CasesDeletion(epPartner2,paymentMethod2);

        //*************SFDC-3499 - TC06*****************//
        
        EMICaseCnA();
        //Executing first connect task
        Firstconnect_caseid = fc.CaptureFCcaseid();
        // Compare the Case Record to First connect case Record
        Assert.assertEquals(CaseRecord, Firstconnect_caseid);
        log.info("Selecting no call connect option for " + Firstconnect_caseid);
        //No call connect - in first connect
        fc.clickNoCallConnectBtn();
        fc.clickNoCallConnect("DNP");
        fc.enterPhone();
        fc.enterComments();
        fc.clickNextSwitchDefault();
        ac.AdditionalWait();
        fc.RefreshPage();
        Firstconnect_status = fc.CheckFCStatus();
        // Verify the Status for first connect is changed to Completed
        Assert.assertEquals(Firstconnect_status, "Completed");
        Firstconnect_callstatus = fc.CheckFCCallStatus();
        // Verify the Call Status for first connect is changed to Payment Confirmed
        Assert.assertEquals(Firstconnect_callstatus, "DNP");
        closeTabWindows();
        log.info("Verifying the Follow up Task is created");
        t.NavBackToTask();
        t.SelectCR(CaseRecord);

        ccr.ClickFollowPTPRcd(CaseRecord);
        AssignedToOwner = fuptp.CaptureAssignedTo();
        Assert.assertTrue(AssignedToOwner.equalsIgnoreCase(Colluser));
        //Capture payment flow - in follow up

        // Compare the Case Record to First connect case Record
        Assert.assertEquals(CaseRecord, Firstconnect_caseid);
        log.info("Providing Capture payment detail for Case record " + Firstconnect_caseid);
        fc.ClickCapturePayment(); //element not interactable error
        //EMI successful flow
        cpd.navToiframe("accessibility title");
        cpd.SelectPaymntOptn(al.get(16));
        log.info("Selected the payment option " + al.get(16));
        cpd.ClickNext();
        
        // ********** SFDC-3620 - TC02 ***********//
        //verifying payment method as payment shell in follow up task
        
        paymentMethod2 = cpd.verifyPaymntOptn(al.get(18));
        Assert.assertEquals("Payment Shell", paymentMethod2);  
        log.info("Payment method is : "+paymentMethod2); 
        
        cpd.SelectPaymentMethod(paymentMethod2);
        cpd.SelectCollectionchannel(al.get(19));
        cpd.ClickNext();
        
        cpd.EnterPaymntRefVal(randomNum);
        cpd.ClickNext();
        
        cpd.SelectEMIcoll(al.get(20));
        cpd.SelectTypofCollPaid(al.get(21));
        cpd.ClickNext();
        
        cpd.SelectElgfrRef(al.get(22));
        cpd.ClickNext();
        ac.AccountLoadwait();
        fc.RefreshPage(); 
        
        Followup_status = fc.CheckFCStatus();
        Assert.assertEquals(Followup_status, "Completed");
        
        Followup_callstatus = fc.CheckFCCallStatus();
        Assert.assertEquals(Followup_callstatus, "Payment Confirmed");
        
        log.info("Logging out as Collection Assistant");
        ac.AdditionalWait();
        lo.Logouthome();

        CasesDeletion(epPartner2,paymentMethod2);

        log.info("Deleting the created Payment Record " + PaymentRecord);
        p.NavMenuClick();
        p.PaymntNavMenuClick();
        p.DeletePayRecord(PaymentRecord);

	}

	public void EMICaseCnA() throws Exception 
    {
	    loginPO lo=new loginPO(driver);
	    CreatedAccountPO ac=new CreatedAccountPO(driver);
	    PaymentCaseQAPO pcqa = new PaymentCaseQAPO(driver);
	    NewCaseRecordTypePO ncrt = new NewCaseRecordTypePO(driver);
	    NewCaseDetailsPO ncd = new NewCaseDetailsPO(driver);
	    CreatedCaseRecordPO ccr = new CreatedCaseRecordPO(driver);
	    UserSetupPO us = new UserSetupPO(driver); 
	    CollectionAssistantLoginPO cal = new CollectionAssistantLoginPO(driver);
	    UserDetailPO ud = new UserDetailPO(driver); 
	   
	   
	    log.info("Creating New Case Record for " + PaymentRecord);
        pcqa.ClickCaseNewButton(PaymentRecord);

        ncrt.SelectCaseRecordType(al.get(14));
        ncrt.ClickNext(); 

        ac.AdditionalWait();
        ncd.enterEMIamount(al.get(6));
        ncd.EnterSubject(al.get(43));
        ncd.ClickSave();
        
        CaseRecord = ccr.CaptureNewCaseRecord(); 
        log.info("New Case Record " + CaseRecord + " created successfully");
        
        String caseURL = driver.getCurrentUrl();
        
        
        if(!CurrURL.contains("--byjusuatfc")) 
        {
            ccr.ClickAssingedTo();
            ccr.EnterAssingedTo2(al2.get(1));
            ccr.ClickSave();
        }
        else
        {
            lo.SwitchUser(al4.get(3));
            ac.closeTabWindows();
            ac.Notification();
            ac.goTo(caseURL);
            ac.AdditionalWait();
            ccr.ClickAssingedTo();
            ccr.EnterAssingedTo2(al2.get(1));
            ccr.ClickSave();
        }
        
        Colluser = MailFullName(al2.get(1));
        //Logging in as the assigned user
        ccr.ClickAssignedUser2(al2.get(1));   
        log.info("Logging in as Collection Assistant " + FullName(al2.get(1)));
       
        ud.ClickUserDetailbutton();
        //Logged in collection associate 
        us.ClickLoginbutton();
        cal.ClickBellicon();
        
        if(CurrURL.contains("--byjusuatfc"))
            cal.SelectAssignedTask(taskName(al4.get(3)));
        else
            cal.SelectAssignedTask(taskName(al4.get(1)));
    }

	public void CasesDeletion(String epPartner,String paymentMethod) throws InterruptedException
	{
	    
	    CreatedAccountPO ac=new CreatedAccountPO(driver);
        PaymentsPO p = new PaymentsPO(driver);
        CasesPO cases=new CasesPO(driver);
        CreatedCaseRecordPO ccr = new CreatedCaseRecordPO(driver);
        String EPPartnerCheck;
        String paymentMethodCheck;
        
	    log.info("Verifying the Payment/Case Status are correct");
        ac.CloseSubTabs();
        ac.goTo(paymentURL);
        ac.Scrollpagedown();
        ac.AdditionalWait();
        p.NavCaseTab(CaseRecord);
        CaseStatus = ccr.CaseStatusval();  // EMI-case status
        CaseOwner = ccr.CaseOwnerval();  //EMI-case owner
        log.info("The record number for newly created Case record is " + ccr.CaptureNewCaseRecord());
        // Verify the Case Status is changed to Audit Pending
        Assert.assertEquals(CaseStatus, "Audit Pending");
        // Verify the Case owner is same
        Assert.assertTrue(CaseOwner.equalsIgnoreCase(Colluser));
        
        // Get the Audit case id
        RelatedCaseRecord= ccr.CaptureRelatedCaseno();
        
        //opening audit case
        ccr.clickAuditRelatedCase();
        
        //3499 - Verify the EP Partner is same on the audit case
        EPPartnerCheck = ccr.getEPPartner(); 
        Assert.assertEquals(epPartner, EPPartnerCheck);
        
        //3620 - Verify the payment method is same on the audit case
        paymentMethodCheck = ccr.getPaymentMethod();
        Assert.assertEquals(paymentMethod, paymentMethodCheck);
        
        ccr.closeCurrentTab(RelatedCaseRecord); 
        log.info("Deleting the Related Case Record " +RelatedCaseRecord);
        // Deleting the audit case
        ccr.DeleteRelatedCaseRecord(RelatedCaseRecord);
        
        // Deleting the EMI case
        log.info("Deleting the created Case Record " +CaseRecord);
        p.NavCasesTab();
        cases.DeleteCCaseRecord(CaseRecord);
        
	}
	
	@AfterMethod(alwaysRun = true)
	public void teardown() throws InterruptedException {

		driver.quit();

	}

}
