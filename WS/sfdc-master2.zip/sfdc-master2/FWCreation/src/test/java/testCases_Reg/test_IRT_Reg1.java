package testCases_Reg;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import pageObjects.CasesPO;
import pageObjects.CreatedAccountPO;
import pageObjects.InboundTaskPO;
import pageObjects.IssueTreePO;
import pageObjects.NewCaseRecordTypePO;
import pageObjects.UserDetailPO;
import pageObjects.loginPO;
import payLoad.payLoad_SinglePrgm;
import resources.ExcelData;
import resources.base;



public class test_IRT_Reg1 extends base {

	public WebDriver driver;
	//public String CurrURL;
	public static Logger log = LogManager.getLogger(test_IRT_Reg1.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> proddummyuser = new ArrayList<String>();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	ArrayList<String> al3 = new ArrayList<String>();
	ArrayList<String> al4 = new ArrayList<String>();
	ArrayList<String> al5 = new ArrayList<String>();
	ArrayList<String> al6 = new ArrayList<String>();
	static Faker faker = new Faker();
	static String firstName = faker.name().firstName();
	static String lastName = faker.name().lastName();
	static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);
	
	@BeforeMethod(alwaysRun = true)
	public void initialize() throws IOException, InterruptedException {

		driver = initializeDriver();

	}
	
	
	@Test(groups = {"sanity", "UAT" }, enabled = true)
	public void TestIRT_SFDC2316_TC01() throws Exception {
	    proddummyuser = excelData.getData("TC1", "ProdDummyUser", "Tcid");
		String Accountid = null;
		loginPO lo=new loginPO(driver);
		al = excelData.getData("Reg_TC01", "Multi_Prog", "Tcid");
		if(CurrURL.contains("--byjusuatfc")) {
			
			al2 = excelData.getData("IRT User UATFC", "Login", "Type");
			log.info("Logging in as Admin to UATFC Env then switching user to IRT");
			lo.LoginAsAdmin_UATFC();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_UATFC(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
			log.info("Launching the newly created Account id "+Accountid);
		}
		else if(CurrURL.contains("--byjusuat")) {
		
		al2 = excelData.getData("IRT User UAT", "Login", "Type");
		
		log.info("Logging in as Admin to UAT then switching user to IRT");
		lo.LoginAsAdmin_UAT();
		log.info("Submitting the Account creation payload");
		Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_UAT(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
		log.info("Launching the newly created Account id "+Accountid);
		
		}
		else {
			
			//al2 = excelData.getData("Collection Assistant", "Login", "Type");
			log.info("Logging in as Admin to Prod");
			lo.LoginAsAdmin_Prod();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_Prod(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
			log.info("Launching the newly created Account id "+Accountid);
		}
		//Assert.assertTrue(false);
		closeTabWindows();

		CreatedAccountPO ac=new CreatedAccountPO(driver);
		//Open the account by searching PID
		ac.Notification();
		ac.NavBackToAccount();
		String AccountURL = CurrURL+Accountid;
		ac.goTo(CurrURL+Accountid);
		ac.AccountLoadwait();
		
		if(CurrURL.contains("--byjusuat")||CurrURL.contains("--byjusuatfc")) {
			String AccountOwner= ac.AccOwnerCheck();
			if(!al2.get(1).equalsIgnoreCase(AccountOwner)) {
				ac.AssignAccount(al2.get(1));
			}
		}
		else {
			ac.AssignAccount("Testing User");
		}
		
		if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
		lo.SwitchUser(al2.get(1));
		ac.closeTabWindows();
		ac.Notification();
		ac.NavBackToAccount();
		ac.goTo(AccountURL);
		ac.AccountLoadwait();
		}
		else if(CurrURL.contains("--byjusuatfc")){
			lo.SwitchUser(al2.get(1));
			ac.closeTabWindows();
			ac.Notification();
			ac.NavBackToAccount();
			ac.goTo(AccountURL);
			ac.AccountLoadwait();
		}
		else {
			lo.SwitchUsernProfile_Prod(proddummyuser.get(1),"IRT profile");
			ac.closeTabWindows();
			ac.Notification();
			ac.NavBackToAccount();
			ac.goTo(AccountURL);
			ac.AccountLoadwait();
		}
		
		//Creating Inbound Task to check the Akash CRP helpline followed by Potential RR task creation 
		log.info("Creating Inbound Task");
		ac.ClickOpenActivitiestoNewTask();
		
		NewCaseRecordTypePO ncrt= new NewCaseRecordTypePO(driver);
		IssueTreePO it=new IssueTreePO(driver);
		ncrt.SelectCaseRecordTypeInbound();
		ncrt.ClickNext();
		ac.AdditionalWait();
		ncrt.ClickSave();
		ac.AdditionalWait();
		
		InboundTaskPO ibdt= new InboundTaskPO(driver);
		al6 = excelData.getData("TC01", "IRT", "Tcid");
			
		ibdt.ClickCaptureDetail();	
		ibdt.ClickDNP_CallDrop();
        Assert.assertEquals(it.VerifyMess(),al6.get(3));//"The No. should be present in any of the Phone No fields of the Student record!");
        //ibdt.ClickNext();
        ibdt.ClickFinish();
        ac.RefreshTab_Targetframe();
        String DNPStatus=ibdt.CheckStatus();
        Assert.assertEquals(DNPStatus,al6.get(1) );//"Completed");
        String status=ibdt.callStatus(al6.get(2));//("DNP");
        Assert.assertEquals(status, al6.get(2));
        ibdt.NavBackAccount();
        ac.CloseSubTabs();				
		lo.Logouthome();
		
		ac.closeTabWindows();
		ac.goTo(AccountURL);
		ac.AdditionalWait();
		
		log.info("Deleting the Student Program details");
		ac.ClickAccOwnrTab();
		ac.DeleteAllCreatedStuProg();
		ac.DeleteAllCreatedStuPayment();
		ac.NavBackToAccount();
		log.info("Deleting the Account created details");
		ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
				
		
	}
	
	@Test(groups = {"sanity", "UAT" }, enabled = true)
    public void TestIRT_SFDC2316_TC02() throws Exception {
        proddummyuser = excelData.getData("TC1", "ProdDummyUser", "Tcid");
        String Accountid = null;
        loginPO lo=new loginPO(driver);
        al = excelData.getData("Reg_TC02", "Multi_Prog", "Tcid");
        if(CurrURL.contains("--byjusuatfc")) {
            
            al2 = excelData.getData("IRT User UATFC", "Login", "Type");
            log.info("Logging in as Admin to UATFC Env then switching user to IRT");
            lo.LoginAsAdmin_UATFC();
            log.info("Submitting the Account creation payload");
            Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_UATFC(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
            log.info("Launching the newly created Account id "+Accountid);
        }
        else if(CurrURL.contains("--byjusuat")) {
        
        al2 = excelData.getData("IRT User UAT", "Login", "Type");
        
        log.info("Logging in as Admin to UAT then switching user to IRT");
        lo.LoginAsAdmin_UAT();
        log.info("Submitting the Account creation payload");
        Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_UAT(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
        log.info("Launching the newly created Account id "+Accountid);
        
        }
        else {
            
            //al2 = excelData.getData("Collection Assistant", "Login", "Type");
            log.info("Logging in as Admin to Prod");
            lo.LoginAsAdmin_Prod();
            log.info("Submitting the Account creation payload");
            Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_Prod(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
            log.info("Launching the newly created Account id "+Accountid);
        }
        closeTabWindows();

        CreatedAccountPO ac=new CreatedAccountPO(driver);
        //Open the account by searching PID
        ac.Notification();
        ac.NavBackToAccount();
        String AccountURL = CurrURL+Accountid;
        ac.goTo(CurrURL+Accountid);
        ac.AccountLoadwait();
        
        if(CurrURL.contains("--byjusuat")||CurrURL.contains("--byjusuatfc")) {
            String AccountOwner= ac.AccOwnerCheck();
            if(!al2.get(1).equalsIgnoreCase(AccountOwner)) {
                ac.AssignAccount(al2.get(1));
            }
        }
        else {
            ac.AssignAccount("Testing User");
        }
        
        if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
        lo.SwitchUser(al2.get(1));
        ac.closeTabWindows();
        ac.Notification();
        ac.NavBackToAccount();
        ac.goTo(AccountURL);
        ac.AccountLoadwait();
        }
        else if(CurrURL.contains("--byjusuatfc")){
            lo.SwitchUser(al2.get(1));
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AccountLoadwait();
        }
        else {
            lo.SwitchUsernProfile_Prod(proddummyuser.get(1),"IRT profile");
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AccountLoadwait();
        }
        
        //Creating Inbound Task to check the Akash CRP helpline followed by Potential RR task creation 
        log.info("Creating Inbound Task");
        ac.ClickOpenActivitiestoNewTask();
        
        NewCaseRecordTypePO ncrt= new NewCaseRecordTypePO(driver);
        ncrt.SelectCaseRecordTypeInbound();
        ncrt.ClickNext();
        ac.AdditionalWait();
        ncrt.ClickSave();
        ac.AdditionalWait();
        
        InboundTaskPO ibdt= new InboundTaskPO(driver);
        al6 = excelData.getData("TC02", "IRT", "Tcid");
            
        ibdt.ClickCaptureDetail();  
        ibdt.ClickAbruptDisconnection();      
        ac.RefreshTab_Targetframe();
        String AbruptDisconectStatus=ibdt.CheckStatus();
        Assert.assertEquals(AbruptDisconectStatus,al6.get(1));//"Completed");
        String status=ibdt.callStatus(al6.get(2));//("Abrupt Disconnection");
        Assert.assertEquals(status, al6.get(2));
        ibdt.NavBackAccount();
        ac.CloseSubTabs();      
        
        lo.Logouthome();
        
        ac.closeTabWindows();
        ac.goTo(AccountURL);
        ac.AdditionalWait();
        
        log.info("Deleting the Student Program details");
        ac.ClickAccOwnrTab();
        ac.DeleteAllCreatedStuProg();
        ac.DeleteAllCreatedStuPayment();
        ac.NavBackToAccount();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
                
        
    }
	
	@Test(groups = {"sanity", "UAT" }, enabled = true)
    public void TestIRT_SFDC2316_TC03() throws Exception {
        proddummyuser = excelData.getData("TC1", "ProdDummyUser", "Tcid");
        String Accountid = null;
        loginPO lo=new loginPO(driver);
        al = excelData.getData("IRT_E2E", "Multi_Prog", "Tcid");
        if(CurrURL.contains("--byjusuatfc")) {
            
            al2 = excelData.getData("IRT User UATFC", "Login", "Type");
            log.info("Logging in as Admin to UATFC Env then switching user to IRT");
            lo.LoginAsAdmin_UATFC();
            log.info("Submitting the Account creation payload");
            Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_UATFC(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
            log.info("Launching the newly created Account id "+Accountid);
        }
        else if(CurrURL.contains("--byjusuat")) {
        
        al2 = excelData.getData("IRT User UAT", "Login", "Type");
        
        log.info("Logging in as Admin to UAT then switching user to IRT");
        lo.LoginAsAdmin_UAT();
        log.info("Submitting the Account creation payload");
        Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_UAT(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
        log.info("Launching the newly created Account id "+Accountid);
        
        }
        else {
            
            //al2 = excelData.getData("Collection Assistant", "Login", "Type");
            log.info("Logging in as Admin to Prod");
            lo.LoginAsAdmin_Prod();
            log.info("Submitting the Account creation payload");
            Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_Prod(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
            log.info("Launching the newly created Account id "+Accountid);
        }
        //Assert.assertTrue(false);
        closeTabWindows();

        CreatedAccountPO ac=new CreatedAccountPO(driver);
        //Open the account by searching PID
        ac.Notification();
        ac.NavBackToAccount();
        String AccountURL = CurrURL+Accountid;
        ac.goTo(CurrURL+Accountid);
        ac.AccountLoadwait();
        
        if(CurrURL.contains("--byjusuat")||CurrURL.contains("--byjusuatfc")) {
            String AccountOwner= ac.AccOwnerCheck();
            if(!al2.get(1).equalsIgnoreCase(AccountOwner)) {
                ac.AssignAccount(al2.get(1));
            }
        }
        else {
            ac.AssignAccount("Testing User");
        }
        
        if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
        lo.SwitchUser(al2.get(1));
        ac.closeTabWindows();
        ac.Notification();
        ac.NavBackToAccount();
        ac.goTo(AccountURL);
        ac.AccountLoadwait();
        }
        else if(CurrURL.contains("--byjusuatfc")){
            lo.SwitchUser(al2.get(1));
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AccountLoadwait();
        }
        else {
            lo.SwitchUsernProfile_Prod(proddummyuser.get(1),"IRT profile");
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AccountLoadwait();
        }
        
       //Creating Inbound Task to check the Akash CRP helpline followed by Potential RR task creation 
        log.info("Creating Inbound Task");
        ac.ClickOpenActivitiestoNewTask();
        
        NewCaseRecordTypePO ncrt= new NewCaseRecordTypePO(driver);
        ncrt.SelectCaseRecordTypeInbound();
        ncrt.ClickNext();
        ac.AdditionalWait();
        ncrt.ClickSave();
        ac.AdditionalWait();
        
        InboundTaskPO ibdt= new InboundTaskPO(driver);
        al6 = excelData.getData("TC03", "IRT", "Tcid");
            
        ncrt.EnterCallBackNumber();
        ac.AdditionalWait();
        ibdt.ClickCaptureDetail();
        ibdt.ClickCallBackRequested();
        ibdt.ClickFinish();    
        ac.RefreshTab_Targetframe();
        ac.AdditionalWait();
        String callBackRequested=ibdt.CheckStatus();
        Assert.assertEquals(callBackRequested, al6.get(1));
        String status=ibdt.callStatus(al6.get(2));
        Assert.assertEquals(status, al6.get(2));//"Call Back Requested");
        ibdt.NavBackAccount();
        ac.CloseSubTabs();      
        lo.Logouthome();
        
        ac.closeTabWindows();
        ac.goTo(AccountURL);
        ac.AdditionalWait();
        
        log.info("Deleting the Student Program details");
        ac.ClickAccOwnrTab();
        ac.DeleteAllCreatedStuProg();
        ac.DeleteAllCreatedStuPayment();
        ac.NavBackToAccount();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
                
        
    }
		
	@Test(groups = {"sanity", "UAT" }, enabled = true)
    public void TestIRT_SFDC2316_TC04() throws Exception {
        proddummyuser = excelData.getData("TC1", "ProdDummyUser", "Tcid");
        String Accountid = null;
        loginPO lo=new loginPO(driver);
        al = excelData.getData("Reg_TC01", "Multi_Prog", "Tcid");
        if(CurrURL.contains("--byjusuatfc")) {
            
            al2 = excelData.getData("IRT User UATFC", "Login", "Type");
            log.info("Logging in as Admin to UATFC Env then switching user to IRT");
            lo.LoginAsAdmin_UATFC();
            log.info("Submitting the Account creation payload");
            Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_UATFC(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
            log.info("Launching the newly created Account id "+Accountid);
        }
        else if(CurrURL.contains("--byjusuat")) {
        
        al2 = excelData.getData("IRT User UAT", "Login", "Type");
        
        log.info("Logging in as Admin to UAT then switching user to IRT");
        lo.LoginAsAdmin_UAT();
        log.info("Submitting the Account creation payload");
        Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_UAT(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
        log.info("Launching the newly created Account id "+Accountid);
        
        }
        else {
            
            //al2 = excelData.getData("Collection Assistant", "Login", "Type");
            log.info("Logging in as Admin to Prod");
            lo.LoginAsAdmin_Prod();
            log.info("Submitting the Account creation payload");
            Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_Prod(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
            log.info("Launching the newly created Account id "+Accountid);
        }
        //Assert.assertTrue(false);
        closeTabWindows();

        CreatedAccountPO ac=new CreatedAccountPO(driver);
        //Open the account by searching PID
        ac.Notification();
        ac.NavBackToAccount();
        String AccountURL = CurrURL+Accountid;
        ac.goTo(CurrURL+Accountid);
        ac.AccountLoadwait();
        
        if(CurrURL.contains("--byjusuat")||CurrURL.contains("--byjusuatfc")) {
            String AccountOwner= ac.AccOwnerCheck();
            if(!al2.get(1).equalsIgnoreCase(AccountOwner)) {
                ac.AssignAccount(al2.get(1));
            }
        }
        else {
            ac.AssignAccount("Testing User");
        }
        
        if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
        lo.SwitchUser(al2.get(1));
        ac.closeTabWindows();
        ac.Notification();
        ac.NavBackToAccount();
        ac.goTo(AccountURL);
        ac.AccountLoadwait();
        }
        else if(CurrURL.contains("--byjusuatfc")){
            lo.SwitchUser(al2.get(1));
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AccountLoadwait();
        }
        else {
            lo.SwitchUsernProfile_Prod(proddummyuser.get(1),"IRT profile");
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AccountLoadwait();
        }
        
        //Creating Inbound Task to check the Akash CRP helpline followed by Potential RR task creation 
        log.info("Creating Inbound Task");
        ac.ClickOpenActivitiestoNewTask();
        
        NewCaseRecordTypePO ncrt= new NewCaseRecordTypePO(driver);
        ncrt.SelectCaseRecordTypeInbound();
        ncrt.ClickNext();
        ac.AdditionalWait();
        ncrt.ClickSave();
        ac.AdditionalWait();
        
        InboundTaskPO ibdt= new InboundTaskPO(driver);
     
        ibdt.ClickCaptureDetail();
        ibdt.ClickProceedOptn();
        IssueTreePO it=new IssueTreePO(driver);
        al3 = excelData.getData("Inbound", "Inbound", "Tcid");
        al4 = excelData.getData("TC3", "RefundProcess", "Tcid");
        al5 = excelData.getData("TC1", "Academic", "Tcid");
        
        ibdt.SelectSpokeTo3(al3.get(1));//Student
        it.PremiumidSelector();
        it.SpecificProgramSelector("BYJUS Aakash Learning App");
        it.ClickNext();
        ibdt.SelectPSTCT(al3.get(2));// New Issue
        //ibdt.EnterNotesVal(al3.get(3));
        ibdt.ClickNext();
        ac.AdditionalWait();
        it.IssueCategory(al5.get(1));//Academics/Content
        //Verifying the 'Issue Type' picklist values
        it.allCheckIssueTypevalues("Academic","TC1",9,"Issue Type");       
        it.IssueType(al5.get(2));//Doubts
        ac.AdditionalWait();
        //Verifying the 'Issue Sub Type' picklist values
        it.allCheckIssueTypevalues("Academic","TC1",10,"Issue Sub Type");  
        ac.CloseSubTabs();      
        
        lo.Logouthome();
        
        ac.closeTabWindows();
        ac.goTo(AccountURL);
        ac.AdditionalWait();
        
        log.info("Deleting the Student Program details");
        ac.ClickAccOwnrTab();
        ac.DeleteAllCreatedStuProg();
        ac.DeleteAllCreatedStuPayment();
        ac.NavBackToAccount();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
                
        
    }
	
	@Test(groups = {"sanity", "UAT" }, enabled = true)
    public void TestIRT_SFDC2316_TC05() throws Exception {
        proddummyuser = excelData.getData("TC1", "ProdDummyUser", "Tcid");
        String Accountid = null;
        loginPO lo=new loginPO(driver);
        al = excelData.getData("Reg_TC01", "Multi_Prog", "Tcid");
        if(CurrURL.contains("--byjusuatfc")) {
            
            al2 = excelData.getData("IRT User UATFC", "Login", "Type");
            log.info("Logging in as Admin to UATFC Env then switching user to IRT");
            lo.LoginAsAdmin_UATFC();
            log.info("Submitting the Account creation payload");
            Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_UATFC(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
            log.info("Launching the newly created Account id "+Accountid);
        }
        else if(CurrURL.contains("--byjusuat")) {
        
        al2 = excelData.getData("IRT User UAT", "Login", "Type");
        
        log.info("Logging in as Admin to UAT then switching user to IRT");
        lo.LoginAsAdmin_UAT();
        log.info("Submitting the Account creation payload");
        Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_UAT(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
        log.info("Launching the newly created Account id "+Accountid);
        
        }
        else {
            
            //al2 = excelData.getData("Collection Assistant", "Login", "Type");
            log.info("Logging in as Admin to Prod");
            lo.LoginAsAdmin_Prod();
            log.info("Submitting the Account creation payload");
            Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_Prod(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
            log.info("Launching the newly created Account id "+Accountid);
        }
        //Assert.assertTrue(false);
        closeTabWindows();

        CreatedAccountPO ac=new CreatedAccountPO(driver);
        //Open the account by searching PID
        ac.Notification();
        ac.NavBackToAccount();
        String AccountURL = CurrURL+Accountid;
        ac.goTo(CurrURL+Accountid);
        ac.AccountLoadwait();
        
        if(CurrURL.contains("--byjusuat")||CurrURL.contains("--byjusuatfc")) {
            String AccountOwner= ac.AccOwnerCheck();
            if(!al2.get(1).equalsIgnoreCase(AccountOwner)) {
                ac.AssignAccount(al2.get(1));
            }
        }
        else {
            ac.AssignAccount("Testing User");
        }
        
        if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
        lo.SwitchUser(al2.get(1));
        ac.closeTabWindows();
        ac.Notification();
        ac.NavBackToAccount();
        ac.goTo(AccountURL);
        ac.AccountLoadwait();
        }
        else if(CurrURL.contains("--byjusuatfc")){
            lo.SwitchUser(al2.get(1));
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AccountLoadwait();
        }
        else {
            lo.SwitchUsernProfile_Prod(proddummyuser.get(1),"IRT profile");
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AccountLoadwait();
        }
        
        //Creating Inbound Task to check the Akash CRP helpline followed by Potential RR task creation 
        log.info("Creating Inbound Task");
        ac.ClickOpenActivitiestoNewTask();
        
        NewCaseRecordTypePO ncrt= new NewCaseRecordTypePO(driver);
        ncrt.SelectCaseRecordTypeInbound();
        ncrt.ClickNext();
        ac.AdditionalWait();
        ncrt.ClickSave();
        ac.AdditionalWait();
        
        InboundTaskPO ibdt= new InboundTaskPO(driver);
     
        ibdt.ClickCaptureDetail();
        ibdt.ClickProceedOptn();
        IssueTreePO it=new IssueTreePO(driver);
        al3 = excelData.getData("Inbound", "Inbound", "Tcid");
        al4 = excelData.getData("TC3", "RefundProcess", "Tcid");
        al5 = excelData.getData("TC1", "Academic", "Tcid");
        
        ibdt.SelectSpokeTo3(al3.get(1));//Student
        it.PremiumidSelector();
        it.SpecificProgramSelector("BYJUS Aakash Learning App");
        it.ClickNext();
        ibdt.SelectPSTCT(al3.get(2));// New Issue
        //ibdt.EnterNotesVal(al3.get(3));
        ibdt.ClickNext();
        ac.AdditionalWait();
        it.IssueCategory(al5.get(1));//Academics/Content
        //Verifying the 'Issue Type' picklist values
        it.allCheckIssueTypevalues("Academic","TC1",9,"Issue Type");      
        it.IssueType(al5.get(6));//Study Plan & MPR
        ac.AdditionalWait();
       //Verifying the 'Issue Sub Type' picklist values
        it.allCheckIssueTypevalues("Academic","TC1",11,"Issue Sub Type");  
        ac.CloseSubTabs();      
        
        lo.Logouthome();
        
        ac.closeTabWindows();
        ac.goTo(AccountURL);
        ac.AdditionalWait();
        
        log.info("Deleting the Student Program details");
        ac.ClickAccOwnrTab();
        ac.DeleteAllCreatedStuProg();
        ac.DeleteAllCreatedStuPayment();
        ac.NavBackToAccount();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
                
        
    }
	
	   @Test(groups = {"sanity", "UAT" }, enabled = true)
	    public void TestIRT_SFDC2316_TC06() throws Exception {
	        proddummyuser = excelData.getData("TC1", "ProdDummyUser", "Tcid");
	        String Accountid = null;
	        loginPO lo=new loginPO(driver);
	        al = excelData.getData("Reg_TC01", "Multi_Prog", "Tcid");
	        if(CurrURL.contains("--byjusuatfc")) {
	            
	            al2 = excelData.getData("IRT User UATFC", "Login", "Type");
	            log.info("Logging in as Admin to UATFC Env then switching user to IRT");
	            lo.LoginAsAdmin_UATFC();
	            log.info("Submitting the Account creation payload");
	            Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_UATFC(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
	            log.info("Launching the newly created Account id "+Accountid);
	        }
	        else if(CurrURL.contains("--byjusuat")) {
	        
	        al2 = excelData.getData("IRT User UAT", "Login", "Type");
	        
	        log.info("Logging in as Admin to UAT then switching user to IRT");
	        lo.LoginAsAdmin_UAT();
	        log.info("Submitting the Account creation payload");
	        Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_UAT(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
	        log.info("Launching the newly created Account id "+Accountid);
	        
	        }
	        else {
	            
	            //al2 = excelData.getData("Collection Assistant", "Login", "Type");
	            log.info("Logging in as Admin to Prod");
	            lo.LoginAsAdmin_Prod();
	            log.info("Submitting the Account creation payload");
	            Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_Prod(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
	            log.info("Launching the newly created Account id "+Accountid);
	        }
	        //Assert.assertTrue(false);
	        closeTabWindows();

	        CreatedAccountPO ac=new CreatedAccountPO(driver);
	        //Open the account by searching PID
	        ac.Notification();
	        ac.NavBackToAccount();
	        String AccountURL = CurrURL+Accountid;
	        ac.goTo(CurrURL+Accountid);
	        ac.AccountLoadwait();
	        
	        if(CurrURL.contains("--byjusuat")||CurrURL.contains("--byjusuatfc")) {
	            String AccountOwner= ac.AccOwnerCheck();
	            if(!al2.get(1).equalsIgnoreCase(AccountOwner)) {
	                ac.AssignAccount(al2.get(1));
	            }
	        }
	        else {
	            ac.AssignAccount("Testing User");
	        }
	        
	        if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
	        lo.SwitchUser(al2.get(1));
	        ac.closeTabWindows();
	        ac.Notification();
	        ac.NavBackToAccount();
	        ac.goTo(AccountURL);
	        ac.AccountLoadwait();
	        }
	        else if(CurrURL.contains("--byjusuatfc")){
	            lo.SwitchUser(al2.get(1));
	            ac.closeTabWindows();
	            ac.Notification();
	            ac.NavBackToAccount();
	            ac.goTo(AccountURL);
	            ac.AccountLoadwait();
	        }
	        else {
	            lo.SwitchUsernProfile_Prod(proddummyuser.get(1),"IRT profile");
	            ac.closeTabWindows();
	            ac.Notification();
	            ac.NavBackToAccount();
	            ac.goTo(AccountURL);
	            ac.AccountLoadwait();
	        }
	        
	        //Creating Inbound Task to check the Akash CRP helpline followed by Potential RR task creation 
	        log.info("Creating Inbound Task");
	        ac.ClickOpenActivitiestoNewTask();
	        
	        NewCaseRecordTypePO ncrt= new NewCaseRecordTypePO(driver);
	        ncrt.SelectCaseRecordTypeInbound();
	        ncrt.ClickNext();
	        ac.AdditionalWait();
	        ncrt.ClickSave();
	        ac.AdditionalWait();
	        
	        InboundTaskPO ibdt= new InboundTaskPO(driver);
	     
	        ibdt.ClickCaptureDetail();
	        ibdt.ClickProceedOptn();
	        IssueTreePO it=new IssueTreePO(driver);
	        al3 = excelData.getData("Inbound", "Inbound", "Tcid");
	        al4 = excelData.getData("TC3", "RefundProcess", "Tcid");
	        al5 = excelData.getData("TC1", "Academic", "Tcid");
	        
	        ibdt.SelectSpokeTo3(al3.get(1));//Student
	        it.PremiumidSelector();
	        it.SpecificProgramSelector("BYJUS Aakash Learning App");
	        it.ClickNext();
	        ibdt.SelectPSTCT(al3.get(2));// New Issue
	        //ibdt.EnterNotesVal(al3.get(3));
	        ibdt.ClickNext();
	        ac.AdditionalWait();
	        it.IssueCategory(al5.get(1));//Academics/Content
	        //Verifying the 'Issue Type' picklist values
	        it.allCheckIssueTypevalues("Academic","TC1",9,"Issue Type");
	        it.IssueType(al5.get(7));//SME Related
	        ac.AdditionalWait();
	        //Verifying the 'Issue Sub Type' picklist values
	        it.allCheckIssueTypevalues("Academic","TC1",12,"Issue Sub Type");
	        ac.CloseSubTabs();      
	        
	        lo.Logouthome();
	        
	        ac.closeTabWindows();
	        ac.goTo(AccountURL);
	        ac.AdditionalWait();
	        
	        log.info("Deleting the Student Program details");
	        ac.ClickAccOwnrTab();
	        ac.DeleteAllCreatedStuProg();
	        ac.DeleteAllCreatedStuPayment();
	        ac.NavBackToAccount();
	        log.info("Deleting the Account created details");
	        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
	                
	        
	    }
	   
	   @Test(groups = {"sanity", "UAT" }, enabled = true)
       public void TestIRT_SFDC2316_TC07() throws Exception {
           proddummyuser = excelData.getData("TC1", "ProdDummyUser", "Tcid");
           String Accountid = null;
           loginPO lo=new loginPO(driver);
           al = excelData.getData("Reg_TC01", "Multi_Prog", "Tcid");
           if(CurrURL.contains("--byjusuatfc")) {
               
               al2 = excelData.getData("IRT User UATFC", "Login", "Type");
               log.info("Logging in as Admin to UATFC Env then switching user to IRT");
               lo.LoginAsAdmin_UATFC();
               log.info("Submitting the Account creation payload");
               Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_UATFC(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
               log.info("Launching the newly created Account id "+Accountid);
           }
           else if(CurrURL.contains("--byjusuat")) {
           
           al2 = excelData.getData("IRT User UAT", "Login", "Type");
           
           log.info("Logging in as Admin to UAT then switching user to IRT");
           lo.LoginAsAdmin_UAT();
           log.info("Submitting the Account creation payload");
           Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_UAT(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
           log.info("Launching the newly created Account id "+Accountid);
           
           }
           else {
               
               //al2 = excelData.getData("Collection Assistant", "Login", "Type");
               log.info("Logging in as Admin to Prod");
               lo.LoginAsAdmin_Prod();
               log.info("Submitting the Account creation payload");
               Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_Prod(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
               log.info("Launching the newly created Account id "+Accountid);
           }
           //Assert.assertTrue(false);
           closeTabWindows();

           CreatedAccountPO ac=new CreatedAccountPO(driver);
           //Open the account by searching PID
           ac.Notification();
           ac.NavBackToAccount();
           String AccountURL = CurrURL+Accountid;
           ac.goTo(CurrURL+Accountid);
           ac.AccountLoadwait();
           
           if(CurrURL.contains("--byjusuat")||CurrURL.contains("--byjusuatfc")) {
               String AccountOwner= ac.AccOwnerCheck();
               if(!al2.get(1).equalsIgnoreCase(AccountOwner)) {
                   ac.AssignAccount(al2.get(1));
               }
           }
           else {
               ac.AssignAccount("Testing User");
           }
           
           if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
           lo.SwitchUser(al2.get(1));
           ac.closeTabWindows();
           ac.Notification();
           ac.NavBackToAccount();
           ac.goTo(AccountURL);
           ac.AccountLoadwait();
           }
           else if(CurrURL.contains("--byjusuatfc")){
               lo.SwitchUser(al2.get(1));
               ac.closeTabWindows();
               ac.Notification();
               ac.NavBackToAccount();
               ac.goTo(AccountURL);
               ac.AccountLoadwait();
           }
           else {
               lo.SwitchUsernProfile_Prod(proddummyuser.get(1),"IRT profile");
               ac.closeTabWindows();
               ac.Notification();
               ac.NavBackToAccount();
               ac.goTo(AccountURL);
               ac.AccountLoadwait();
           }
           
           //Creating Inbound Task to check the Akash CRP helpline followed by Potential RR task creation 
           log.info("Creating Inbound Task");
           ac.ClickOpenActivitiestoNewTask();
           
           NewCaseRecordTypePO ncrt= new NewCaseRecordTypePO(driver);
           ncrt.SelectCaseRecordTypeInbound();
           ncrt.ClickNext();
           ac.AdditionalWait();
           ncrt.ClickSave();
           ac.AdditionalWait();
           
           InboundTaskPO ibdt= new InboundTaskPO(driver);
        
           ibdt.ClickCaptureDetail();
           ibdt.ClickProceedOptn();
           IssueTreePO it=new IssueTreePO(driver);
           al3 = excelData.getData("Inbound", "Inbound", "Tcid");
           al4 = excelData.getData("TC3", "RefundProcess", "Tcid");
           al5 = excelData.getData("TC1", "Academic", "Tcid");
           
           ibdt.SelectSpokeTo3(al3.get(1));//Student
           it.PremiumidSelector();
           it.SpecificProgramSelector("BYJUS Aakash Learning App");
           it.ClickNext();
           ibdt.SelectPSTCT(al3.get(2));// New Issue
           //ibdt.EnterNotesVal(al3.get(3));
           ibdt.ClickNext();
           ac.AdditionalWait();
           it.IssueCategory(al5.get(1));//Academics/Content
           //Verifying the 'Issue Type' picklist values
           it.allCheckIssueTypevalues("Academic","TC1",9,"Issue Type");
           it.IssueType(al5.get(8));//Content Related
           ac.AdditionalWait();
         //Verifying the 'Issue Sub Type' picklist values
           it.allCheckIssueTypevalues("Academic","TC1",13,"Issue Sub Type");
           ac.CloseSubTabs();      
           
           lo.Logouthome();
           
           ac.closeTabWindows();
           ac.goTo(AccountURL);
           ac.AdditionalWait();
           
           log.info("Deleting the Student Program details");
           ac.ClickAccOwnrTab();
           ac.DeleteAllCreatedStuProg();
           ac.DeleteAllCreatedStuPayment();
           ac.NavBackToAccount();
           log.info("Deleting the Account created details");
           ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
                   
           
       }
	
       @Test(groups = {"sanity", "UAT" }, enabled = true)
       public void TestIRT_SFDC2316_TC08() throws Exception {
           proddummyuser = excelData.getData("TC1", "ProdDummyUser", "Tcid");
           String Accountid = null;
           loginPO lo=new loginPO(driver);
           CasesPO cases= new CasesPO(driver);
           UserDetailPO us= new UserDetailPO(driver);
           al = excelData.getData("Reg_TC01", "Multi_Prog", "Tcid");
           if(CurrURL.contains("--byjusuatfc")) {
               
               al2 = excelData.getData("IRT User UATFC", "Login", "Type");
               log.info("Logging in as Admin to UATFC Env then switching user to IRT");
               lo.LoginAsAdmin_UATFC();
               log.info("Submitting the Account creation payload");
               Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_UATFC(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
               log.info("Launching the newly created Account id "+Accountid);
           }
           else if(CurrURL.contains("--byjusuat")) {
           
           al2 = excelData.getData("IRT User UAT", "Login", "Type");
           
           log.info("Logging in as Admin to UAT then switching user to IRT");
           lo.LoginAsAdmin_UAT();
           log.info("Submitting the Account creation payload");
           Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_UAT(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
           log.info("Launching the newly created Account id "+Accountid);
           
           }
           else {
               
               //al2 = excelData.getData("Collection Assistant", "Login", "Type");
               log.info("Logging in as Admin to Prod");
               lo.LoginAsAdmin_Prod();
               log.info("Submitting the Account creation payload");
               Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_Prod(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
               log.info("Launching the newly created Account id "+Accountid);
           }
           closeTabWindows();

           CreatedAccountPO ac=new CreatedAccountPO(driver);
           //Open the account by searching PID
           ac.Notification();
           ac.NavBackToAccount();
           String AccountURL = CurrURL+Accountid;
           ac.goTo(CurrURL+Accountid);
           ac.AccountLoadwait();
           
           if(CurrURL.contains("--byjusuat")||CurrURL.contains("--byjusuatfc")) {
               String AccountOwner= ac.AccOwnerCheck();
               if(!al2.get(1).equalsIgnoreCase(AccountOwner)) {
                   ac.AssignAccount(al2.get(1));
               }
           }
           else {
               ac.AssignAccount("Testing User");
           }
           
           if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
           lo.SwitchUser(al2.get(1));
           ac.closeTabWindows();
           ac.Notification();
           ac.NavBackToAccount();
           ac.goTo(AccountURL);
           ac.AccountLoadwait();
           }
           else if(CurrURL.contains("--byjusuatfc")){
               lo.SwitchUser(al2.get(1));
               ac.closeTabWindows();
               ac.Notification();
               ac.NavBackToAccount();
               ac.goTo(AccountURL);
               ac.AccountLoadwait();
           }
           else {
               lo.SwitchUsernProfile_Prod(proddummyuser.get(1),"IRT profile");
               ac.closeTabWindows();
               ac.Notification();
               ac.NavBackToAccount();
               ac.goTo(AccountURL);
               ac.AccountLoadwait();
           }
           
           //Creating Inbound Task to check the Akash CRP helpline followed by Potential RR task creation 
           log.info("Creating Inbound Task");
           ac.ClickOpenActivitiestoNewTask();
           
           NewCaseRecordTypePO ncrt= new NewCaseRecordTypePO(driver);
           ncrt.SelectCaseRecordTypeInbound();
           ncrt.ClickNext();
           ac.AdditionalWait();
           ncrt.ClickSave();
           ac.AdditionalWait();
           
           InboundTaskPO ibdt= new InboundTaskPO(driver);
        
           ibdt.ClickCaptureDetail();
           ibdt.ClickProceedOptn();
           IssueTreePO it=new IssueTreePO(driver);
           al3 = excelData.getData("Inbound", "Inbound", "Tcid");
           al4 = excelData.getData("TC3", "RefundProcess", "Tcid");
           al5 = excelData.getData("TC1", "Academic", "Tcid");
           al6 = excelData.getData("TC04", "IRT", "Tcid");
           
           ibdt.SelectSpokeTo3(al3.get(1));//Student
           it.PremiumidSelector();
           it.SpecificProgramSelector("BYJUS Aakash Learning App");
           it.ClickNext();
           ibdt.SelectPSTCT(al3.get(2));// New Issue
           //ibdt.EnterNotesVal(al3.get(3));
           ibdt.ClickNext();
           ac.AdditionalWait();
           it.IssueCategory(al5.get(1));//Academics/Content      
           it.IssueType(al5.get(2));//Doubts
           ac.AdditionalWait();
          
           it.IssueSubType(al5.get(3));//Minor academic doubts
           it.IssueNotes(al5.get(4));//NA
           it.IstheIssueResolved(al5.get(5));//No
           it.ClickNext2();
           ac.RefreshTab_Targetframe();
           String status=ibdt.CheckStatus();
           Assert.assertEquals(status, al6.get(1));
           String callStatus=ibdt.callStatus(al6.get(2));//("Call Completed");
           Assert.assertEquals(callStatus, al6.get(2));      
           ibdt.NavBackAccount();
           ac.CloseSubTabs();      
           
         //Verify the case is assigned to Task owners Manager
           ac.ClickCasesMC2();
           cases.SelectCaseBySubject(al5.get(2),al5.get(3));
           String CaseOwner = cases.CaptureCaseOwner();
           cases.ClickTaskOwner();
           String Manager =us.CaptureManager();
           Assert.assertEquals(CaseOwner, Manager);
           ac.ClickAccOwnrTab();
           ac.CloseSubTabs();
           lo.Logouthome();
           
           ac.closeTabWindows();
           ac.goTo(AccountURL);
           ac.AdditionalWait();
           
          //Deleting the created case
           ac.ClickCasesMC2();
           String CaseNumber= cases.CaseRN();
           log.info("The case number created is: "+CaseNumber);
           cases.CloseAllCases();
           
           log.info("Deleting the Student Program details");
           ac.ClickAccOwnrTab();
           ac.DeleteAllCreatedStuProg();
           ac.DeleteAllCreatedStuPayment();
           ac.NavBackToAccount();
           log.info("Deleting the Account created details");
           ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
     
       }
       
	  @AfterMethod(alwaysRun = true) public void teardown() throws
	  InterruptedException {
	  
	  driver.quit();
	  
	  //ac.AdditionalWait(); 
	  }
	 
	
	
}
