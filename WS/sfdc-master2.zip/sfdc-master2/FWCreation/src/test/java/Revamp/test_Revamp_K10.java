package Revamp;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.github.javafaker.Faker;

import pageObjects.AssignmentRulesRefundRequestPO;
import pageObjects.CapturePaymentDetailsEMIPO;
import pageObjects.CapturePaymtDetailsPTPPO;
import pageObjects.CasesPO;
import pageObjects.CollectionAssistantLoginPO;
import pageObjects.CreatedAccountPO;
import pageObjects.CreatedCaseRecordPO;
import pageObjects.DevConsolePO;
import pageObjects.FirstConnectPO;
import pageObjects.FollowUpPTPPO;
import pageObjects.NPPaymentLoanPO;
import pageObjects.NewCaseDetailsPO;
import pageObjects.NewCaseRecordTypePO;
import pageObjects.NewPaymentPO;
import pageObjects.NewPaymentRecordPO;
import pageObjects.PaymentCaseQAPO;
import pageObjects.PaymentsPO;
import pageObjects.StudentProgPO;
import pageObjects.TasksPO;
import pageObjects.UserDetailPO;
import pageObjects.UserSetupPO;
import pageObjects.loginPO;
import payLoad.payLoad_PrgmwithSSO_Revamp;
import payLoad.payLoad_PrgmwithoutSSO_Revamp;
import payLoad.payLoad_Revamp_K3;
import payLoad.payLoad_SinglePrgm_Revamp;
import payLoad.payLoad_TwoPrgms_Revamp;
import resources.ExcelData;
import resources.Queries;
import resources.base;
import testCases.test_CollectionFlow;

public class test_Revamp_K10 extends base {

	public WebDriver driver;
	//ThreadLocal<WebDriver> driver = new ThreadLocal<WebDriver>();
	//public String CurrURL;
	public static Logger log = LogManager.getLogger(test_CollectionFlow.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	ArrayList<String> al3 = new ArrayList<String>();
	ArrayList<String> al4 = new ArrayList<String>();
	ArrayList<String> prior_prog_Id = new ArrayList<String>();
    ArrayList<String> sec_prog_Id = new ArrayList<String>();
    HashMap<String,String> tcid_tasktypes=new HashMap<String,String>();
    HashMap<String,ArrayList<String>> priProg_Det=new HashMap<String,ArrayList<String>>();
    HashMap<String,Integer> prog_tasks=new HashMap<String,Integer>();
	static Faker faker = new Faker();
	static String firstName = faker.name().firstName();
	static String lastName = faker.name().lastName();
	static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);
	StudentProgPO sp = new StudentProgPO(driver);
    CreatedAccountPO ac=new CreatedAccountPO(driver);
    int flag = 0;
    String region = "";
    
    @BeforeMethod(alwaysRun = true)
    public void initialize() throws IOException, InterruptedException {

        driver = initializeDriver();
    }
    	                            
    
    //Assignment rules 
    @Test(groups = { "Regression" ,"sanity"}, enabled = false)
    public void Revamp_K10_AR1() throws Exception 
    {
        List<String> prognames = new ArrayList<String>();
        ArrayList<String> progNamesList = new ArrayList<String>();
        StudentProgPO sp = new StudentProgPO(driver);
        loginPO lo=new loginPO(driver);
        CreatedAccountPO ac=new CreatedAccountPO(driver);
        AssignmentRulesRefundRequestPO ar = new AssignmentRulesRefundRequestPO(driver);
        
        String Accountid = "";
        String ruleCat = "PE";
        String prog1 = "",prog2 = "",prog3 = "";
                
        //getting count of rows
        int noofRows = getRowCount("src//main//java//testData//TestData.xlsx", "Revamp_K10");
        //getting a random row number 
        String T1 = "16";
        String Tcid1 = String.valueOf(randomNumber(1,noofRows-1));
        
        al = excelData.getData(T1, "Revamp_K10", "Tcid");
        al2 = excelData.getData(Tcid1, "Revamp_K10", "Tcid");
        
        while(Tcid1.equals(T1) || Tcid1.equalsIgnoreCase("14") || al.get(2).equalsIgnoreCase(al2.get(2)))
        {
            Tcid1 = String.valueOf(randomNumber(1,noofRows-1));
            al2 = excelData.getData(Tcid1, "Revamp_K10", "Tcid");
        }
        
        if(CurrURL.contains("--byjusuat")) 
        {
            
            lo.LoginAsAdmin_UAT();
            
            // Creating a new student account
            Accountid=payLoad_SinglePrgm_Revamp.AccountidCreationResponse_UAT(al.get(16),al.get(15),al.get(2),al.get(5),al.get(3),al.get(7),al.get(4));
        }
        else if (CurrURL.contains("--byjusfc")) {
            lo.LoginAsAdmin_UATFC();

            // Creating a new student account
            Accountid=payLoad_SinglePrgm_Revamp.AccountidCreationResponse_UATFC(al.get(16),al.get(15),al.get(2),al.get(5),al.get(3),al.get(7),al.get(4));
        }

        System.out.println("al : "+al);
        System.out.println("al2 : "+al2);
        
        ac.closeTabWindows(2);    
        ac.Notification();
        
        prior_prog_Id = al;
        
        String AccountURL=CurrURL+Accountid;
        ac.goTo(AccountURL);
        
        System.out.println("prior_prog1_Id :"+prior_prog_Id);
        
        ac.ClickStudentPrograms();
        
        //get the program name
        prognames = sp.getProgNames();
        progNamesList.add(prognames.get(0));
        
        String[] prgmData=sp.verifyIsPrimarychecked();
        log.info("Actual Primary Prog ID is :  "+prgmData[0]+"And expected is : "+prior_prog_Id.get(2));
        
        Assert.assertEquals(prgmData[0],prior_prog_Id.get(2),"1: Combination : "+T1+"-"+Tcid1+" , expected "+prior_prog_Id.get(2)+" but found "+prgmData[0]);
        Assert.assertEquals(prgmData[1],prior_prog_Id.get(3),"1: Combination : "+T1+"-"+Tcid1+" , expected "+prior_prog_Id.get(3)+" but found "+prgmData[1]);
        Assert.assertEquals(prgmData[2],prior_prog_Id.get(7),"1: Combination : "+T1+"-"+Tcid1+" , expected "+prior_prog_Id.get(7)+" but found "+prgmData[2]);
        
        //Closing the sub tabs
        ac.CloseSubTabs();
        ac.AdditionalWait();
        
        String expectedQueue = ar.GetExpAssgnRule(prior_prog_Id, ruleCat, al.get(15));
        System.out.println("expectedQueue1 : "+expectedQueue);
        
        //check if picked up assignment rule is correct
        checkAssignmentRule(prior_prog_Id,expectedQueue,ruleCat,Accountid, al.get(15));
        
        //clone the program and create a new program
        //InsertNewProg(al2);
        
        String sel = ac.getSOSelection(al.get(16));

        //Adding a 2nd program in to an existing student account
        if(sel.equalsIgnoreCase("1"))
        {
            if (CurrURL.contains("--byjusuat")) 
            {
                payLoad_PrgmwithSSO_Revamp.AccountidCreationResponse_UAT(Accountid,al2.get(2),al2.get(5),al2.get(3),al2.get(7),al2.get(4));
            }
            else if (CurrURL.contains("--byjusfc"))
            {
                payLoad_PrgmwithSSO_Revamp.AccountidCreationResponse_UATFC(Accountid,al2.get(2),al2.get(5),al2.get(3),al2.get(7),al2.get(4));
            }
        }
        else 
        {
            ac.AccountLoadwait();
            ac.AccountLoadwait();
            InsertNewProg(al2);
            ac.AdditionalWait();
        }
        
        
        // Comparing the priorities of both the programs
        if(Integer.valueOf(al2.get(8)) < Integer.valueOf(al.get(8)))
        {
            prior_prog_Id = al2;
            sec_prog_Id = al;
            if(sel.equalsIgnoreCase("1"))
                ruleCat = "PE";
            else
                ruleCat = "Mentor";
        }
        else
        {
            prior_prog_Id = al;
            sec_prog_Id = al2;
            ruleCat = "PE";
        }
        
        ac.AdditionalWait();
        ac.CloseSubTabs();
        ac.AdditionalWait();
        
        ac.ClickStudentPrograms();
        
        //get the program name
        prognames = sp.getProgNames();
        for(int j=0;j<prognames.size();j++)
        {
            if(!progNamesList.contains(prognames.get(j)))
            {
                progNamesList.add(prognames.get(j));
            }
        }
        

        System.out.println("prior_prog2_Id :"+prior_prog_Id);
        //Returns the prog id, prod type and trial prog
         prgmData=sp.verifyIsPrimarychecked();
        log.info("Actual Primary Prog ID is :  "+prgmData[0]+"And expected is : "+prior_prog_Id.get(2));
        
        Assert.assertEquals(prgmData[0],prior_prog_Id.get(2),"2: Combination : "+T1+"-"+Tcid1+" , expected "+prior_prog_Id.get(2)+" but found "+prgmData[0]);
        Assert.assertEquals(prgmData[1],prior_prog_Id.get(3),"2: Combination : "+T1+"-"+Tcid1+" , expected "+prior_prog_Id.get(3)+" but found "+prgmData[1]);
        Assert.assertEquals(prgmData[2],prior_prog_Id.get(7),"2: Combination : "+T1+"-"+Tcid1+" , expected "+prior_prog_Id.get(7)+" but found "+prgmData[2]);
        
        //Closing the sub tabs
        ac.CloseSubTabs();       
        ac.AdditionalWait();
        
        expectedQueue = ar.GetExpAssgnRule(prior_prog_Id, ruleCat,al.get(15));
        System.out.println("expectedQueue2 : "+expectedQueue);
        
        //Verify the assignment rule after inserting new program
        checkAssignmentRule(prior_prog_Id,expectedQueue,ruleCat,Accountid,al.get(15));
        
        int numb = randomNumber(1, 5);
        
        if(!sec_prog_Id.get(9).equalsIgnoreCase("Yes"))
        {
         // change status
            if(numb == 1)
            {
                ac.AdditionalWait();
                ac.ClickStudentPrograms();
                sp.goToprimaryProg();
                //change status to inactive
                sp.SelectStatus("Inactive");
                sp.ClickSave();
                
                ac.AccountLoadwait();        
                ac.CloseSubTabs();
                
                ac.AdditionalWait();
                ac.RefreshTab();
                
                //sec prog becomes primary
                if(prior_prog_Id==al)
                {
                  prior_prog_Id = al2;
                  sec_prog_Id = al;
                }
                else
                {
                    prior_prog_Id = al;
                    sec_prog_Id = al2;
                }
                ruleCat = "PE";
                
                System.out.println("after inactive-prior_prog_Id :"+prior_prog_Id);
                System.out.println("after inactive-sec_prog_Id :"+sec_prog_Id);
                
                expectedQueue = ar.GetExpAssgnRule(prior_prog_Id, ruleCat, al.get(15));
                
                //Verify the assignment rule after inserting new program
                checkAssignmentRule(prior_prog_Id,expectedQueue,ruleCat,Accountid, al.get(15));
               
                ac.ClickStudentPrograms();
                sp.goToNonprimaryProg();
                
                //change status back to active
                sp.SelectStatus("Active");
                sp.ClickSave();

                ac.AccountLoadwait();
                ac.CloseSubTabs();
                ac.AdditionalWait();
                ac.RefreshTab();
                
                al3 = prior_prog_Id;
                prior_prog_Id = sec_prog_Id;
                sec_prog_Id = al3;
                
                if(sel.equalsIgnoreCase("1"))
                {
                    if(prior_prog_Id == al)
                        ruleCat = "Mentor";
                    else
                        ruleCat = "PE";
                }
                else 
                    ruleCat = "Mentor";
                
                System.out.println("after active-prior_prog_Id :"+prior_prog_Id);
                System.out.println("after active-sec_prog_Id :"+sec_prog_Id);
                
                expectedQueue = ar.GetExpAssgnRule(prior_prog_Id, ruleCat, al.get(15));
                
                //Verify the assignment rule after inserting new program
                checkAssignmentRule(prior_prog_Id,expectedQueue,ruleCat,Accountid, al.get(15));
                
            }
            // change student unit
            else if(numb == 2)
            {
                UpdateStuUnit(Accountid);
                ac.ClickStudentPrograms();
                
                //get the program name
                prognames = sp.getProgNames();
                for(int j=0;j<prognames.size();j++)
                {
                    if(!progNamesList.contains(prognames.get(j)))
                    {
                        progNamesList.add(prognames.get(j));
                    }
                }
                
                System.out.println("progNamesList : "+progNamesList);
                
                String sheetName = "";
                if(al3.get(16).equalsIgnoreCase("7"))
                    sheetName = "Revamp_K"+al3.get(16);
                else if(al3.get(16).equalsIgnoreCase("8") || al3.get(16).equalsIgnoreCase("9"))
                    sheetName = "Revamp_K8-9";
                else
                    sheetName = "Revamp_"+al3.get(13);
                
                //gets the combinations of all 3 programs with the new student unit
                sp.clickStuProgName(progNamesList.get(0));
                
                ArrayList<String> tcids = sp.getTcids(sheetName, al.get(2));
                if(tcids.size()>0)
                    prog1 = sp.getProgComb(tcids, sheetName, al.get(2));
                if(prog1.isEmpty())
                {
                    prog1 = sp.getCombination(al.get(13),al3.get(13), al);
                    ac.CloseCurrentSubTab();
                }

                
                ac.AdditionalWait();
                ac.CloseCurrentSubTab();
                System.out.println("prog1 : "+prog1);
                
                sp.clickStuProgName(progNamesList.get(1));
                
                tcids = sp.getTcids(sheetName, al2.get(2));
                if(tcids.size()>0)
                    prog2 = sp.getProgComb(tcids, sheetName, al2.get(2));
                if(prog2.isEmpty())
                {
                    prog2 = sp.getCombination(al2.get(13),al3.get(13), al2);
                    ac.CloseCurrentSubTab();
                }
                    
                ac.AdditionalWait();
                ac.CloseCurrentSubTab();
                System.out.println("prog2 : "+prog2);
                
                sp.clickStuProgName(progNamesList.get(2));
                
                tcids = sp.getTcids(sheetName, al3.get(2));
                if(tcids.size()>0)
                    prog3 = sp.getProgComb(tcids, sheetName, al3.get(2));
                if(prog3.isEmpty())
                {
                    prog3 = sp.getCombination(al3.get(13),al3.get(13), al3);
                    ac.CloseCurrentSubTab();
                }
               
                ac.AdditionalWait();
                ac.CloseSubTabs();
                System.out.println("prog3 : "+prog3);
                        
                prior_prog_Id = excelData.getData(sp.getPrimaryProgTcid(prog1, prog2, prog3, al3.get(16)), sheetName, "Tcid");
                System.out.println("prior_prog5_Id :"+prior_prog_Id);
                
                String p2 = al2.get(2);
                
                if(prior_prog_Id.equals(al3))
                {
                    ruleCat = "PE";
                    expectedQueue = ar.GetExpAssgnRule(prior_prog_Id, ruleCat, al.get(15));
                }
                else if(prior_prog_Id.get(2).equals(al.get(2)))
                    expectedQueue = ar.GetExpAssgnRule(al, ruleCat, al.get(15));
                
                else if(prior_prog_Id.get(2).equals(p2))
                    expectedQueue = ar.GetExpAssgnRule(al2, ruleCat, al.get(15));
                
                //Verify the assignment rule after inserting new program
                checkAssignmentRule(prior_prog_Id,expectedQueue,ruleCat,Accountid, al.get(15));

            }
            
            // change trial program
            else if(numb == 3)
            {
                if(!(prior_prog_Id.get(2).equalsIgnoreCase("BCOPKXSY0002") && ((prior_prog_Id.get(3).equalsIgnoreCase("Free") && prior_prog_Id.get(5).equalsIgnoreCase("Monthly")) || prior_prog_Id.get(4).equalsIgnoreCase("Toppr")))) 
                {

                    ac.ClickStudentPrograms();
                    sp.goToprimaryProg();
                    
                    if(prior_prog_Id.get(7).equalsIgnoreCase("No"))
                        updatetrialProg("Yes");
                    else
                        updatetrialProg("No");                  
                    
                    ac.AdditionalWait();
                  
                    System.out.println("prior_prog3_Id : "+prior_prog_Id);
                    
                    ac.CloseCurrentSubTab();
                    ac.AdditionalWait();
                    
                    if(sel.equalsIgnoreCase("1"))
                    {
                        if(prior_prog_Id == al)
                            ruleCat = "Mentor";
                        else
                            ruleCat = "PE";
                    }
                    else 
                        ruleCat = "Mentor";
                    
                    
                    //Returns the prog id, prod type and trial prog
                    prgmData=sp.verifyIsPrimarychecked();
                    log.info("Actual Primary Prog ID is :  "+prgmData[0]+"And expected is : "+prior_prog_Id.get(2));
                    
                    Assert.assertEquals(prgmData[0],prior_prog_Id.get(2),"3: Combination : "+T1+"-"+Tcid1+" , expected "+prior_prog_Id.get(2)+" but found "+prgmData[0]);
                    Assert.assertEquals(prgmData[1],prior_prog_Id.get(3),"3: Combination : "+T1+"-"+Tcid1+" , expected "+prior_prog_Id.get(3)+" but found "+prgmData[1]);
                    Assert.assertEquals(prgmData[2],prior_prog_Id.get(7),"3: Combination : "+T1+"-"+Tcid1+" , expected "+prior_prog_Id.get(7)+" but found "+prgmData[2]);
                    
                    ac.CloseSubTabs();
                    ac.AdditionalWait();
                    
                    expectedQueue = ar.GetExpAssgnRule(prior_prog_Id, ruleCat, al.get(15));
                    
                    //Verify the assignment rule after inserting new program
                    checkAssignmentRule(prior_prog_Id,expectedQueue,ruleCat,Accountid, al.get(15));
                    
                    ac.ClickStudentPrograms();
                    sp.goToNonprimaryProg();
                    
                    //changing back the trial program
                    if(sec_prog_Id.get(7).equalsIgnoreCase("No"))
                        updatetrialProg("No");
                    else
                        updatetrialProg("Yes");
                    
                    System.out.println("prior_prog4_Id :"+prior_prog_Id);
                    ac.CloseSubTabs();
                    ac.AdditionalWait();      
                
                }
            }
            //change product type, program type, duration
            else if(numb == 4)
            {
                ac.ClickStudentPrograms();
                sp.goToNonprimaryProg();
                prog1 = sp.getCombination(sec_prog_Id.get(13),al.get(13),sec_prog_Id);
                al3 = excelData.getData(prog1, "Revamp_Combinations", "Id");
                System.out.println("prog1 : "+prog1);
                
                ac.CloseCurrentSubTab();
                ac.CloseCurrentSubTab();
                ac.AdditionalWait();
                sp.goToprimaryProg();
                //changing class/program type , duration , product type , Trial program in primary program
                updateProgTyDurtnProdTyTrProg();
                
                //getting the details of the primary program in string separated by '-'
                prog2 = sp.getCombination(prior_prog_Id.get(13),al.get(13),prior_prog_Id);
                al4 = excelData.getData(prog2, "Revamp_Combinations", "Id");
                System.out.println("prog2 : "+prog2);
                
                //Changing the primary program based on the new data
                
                //prog2 is in excel - compare priorities
                if(excelData.searchColData("TestData", "Revamp_Combinations", "Id", prog1) && excelData.searchColData("TestData", "Revamp_Combinations", "Id", prog2) )
                {
                    if(Integer.valueOf(al3.get(1)) < Integer.valueOf(al4.get(1)))
                    {
                       prior_prog_Id = excelData.getData(al3.get(3), "Revamp_K11-12", "Tcid");
                    }
                    else
                        prior_prog_Id = excelData.getData(al4.get(3), "Revamp_K11-12", "Tcid");
                }
                //prog2(primary program) is not in excel - prog1(secondary program) is primary
                else
                    prior_prog_Id = excelData.getData(al3.get(3), "Revamp_K11-12", "Tcid");
                
                System.out.println("prior_prog2_Id : "+prior_prog_Id);
                
                //ac.CloseSubTabs();
                ac.CloseCurrentSubTab();
                ac.CloseCurrentSubTab();
                ac.AdditionalWait();
                //ac.ClickStudentPrograms();
                
                //Returns the prog id, prod type and trial prog
                prgmData=sp.verifyIsPrimarychecked();
                log.info("Actual Primary Prog ID is :  "+prgmData[0]+"And expected is : "+prior_prog_Id.get(2));

                Assert.assertEquals(prgmData[0],prior_prog_Id.get(2),"5: Combination : "+T1+"-"+Tcid1+" , expected "+prior_prog_Id.get(2)+" but found "+prgmData[0]);
               // a.assertEquals(prgmData[1],prior_prog_Id.get(3),"Combination : "+T1+"-"+i+" , expected "+prior_prog_Id.get(3)+" but found "+prgmData[1]);
                Assert.assertEquals(prgmData[2],prior_prog_Id.get(7),"5: Combination : "+T1+"-"+Tcid1+" , expected "+prior_prog_Id.get(7)+" but found "+prgmData[2]);
                
                //Closing the sub tabs
                ac.CloseSubTabs();
                ac.AdditionalWait();
                lo.RefreshURL();
                
                if(sel.equalsIgnoreCase("1"))
                {
                    if(prior_prog_Id.equals(al))
                        ruleCat = "Mentor";
                    else
                        ruleCat = "PE";
                }
                else
                    ruleCat = "Mentor";
                expectedQueue = ar.GetExpAssgnRule(prior_prog_Id, ruleCat, al.get(15));
                
                //Verify the assignment rule after inserting new program
                checkAssignmentRule(prior_prog_Id,expectedQueue,ruleCat,Accountid, al.get(15));
                
            }
            //Change in mentoring language
            else
            {
                String mentlang = ac.getMentLang(al.get(15));
                ac.AccountLoadwait();
                ac.changeMentLang(mentlang);
                ac.AccountLoadwait();
                ac.AdditionalWait();
                ac.RefreshTab();
                
                expectedQueue = ar.GetExpAssgnRule(prior_prog_Id, ruleCat, mentlang);
                
                checkAssignmentRule(prior_prog_Id,expectedQueue,ruleCat,Accountid, mentlang);
            }
        }
         
        ac.AdditionalWait();       
        ac.DeleteAllCreatedStuProg();
        ac.NavBackToAccount();
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
    }

    //International 
    //4655 - 13, Order source 
    @Test(groups = { "Regression" ,"sanity"}, enabled = false)
    public void Revamp_K10_Int() throws Exception
    {
        StudentProgPO sp = new StudentProgPO(driver);
        loginPO lo=new loginPO(driver);
        CreatedAccountPO ac=new CreatedAccountPO(driver);
        AssignmentRulesRefundRequestPO ar = new AssignmentRulesRefundRequestPO(driver);
        DevConsolePO dc = new DevConsolePO(driver);
        
        String Accountid = "";
        String ruleCat = "";
        int staticVal = 0;
        int noofTasks = 0;
        int totalTasks = 0;
                
        //getting count of rows
        int noofRows = getRowCount("src//main//java//testData//TestData.xlsx", "Revamp_K10");
        //getting a random row number 
        String Tcid1 = "5";//String.valueOf(randomNumber(1,noofRows-1));
        
        if(CurrURL.contains("--byjusuat")) 
        {
            al = excelData.getData(Tcid1, "Revamp_K10", "Tcid");
            lo.LoginAsAdmin_UAT();
            
            // Creating a new student account
            int num = randomNumber(1,10);
            if(num >= 1 && num <= 5)
            {
                Accountid=payLoad_SinglePrgm_Revamp.AccountidCreationResponse_UAT(al.get(16),al.get(15),al.get(2),al.get(5),al.get(3),al.get(7),al.get(4));
                staticVal = 1;
                ruleCat = "PE";
            }
            else
            {
                Accountid=payLoad_SinglePrgm_Revamp.AccountidCreationResponse_UAT_49(al.get(16),al.get(15),al.get(2),al.get(5),al.get(3),al.get(7),al.get(4));
                staticVal = 2;
                ruleCat = "Mentor";
            }
        }
        else if(CurrURL.contains("--byjusfc")) 
        {
            al = excelData.getData(Tcid1, "Revamp_K10", "Tcid");
            lo.LoginAsAdmin_UATFC();
            
            // Creating a new student account
            int num = randomNumber(1,10);
            if(num >= 1 && num <= 5)
            {
                Accountid=payLoad_SinglePrgm_Revamp.AccountidCreationResponse_UATFC(al.get(16),al.get(15),al.get(2),al.get(5),al.get(3),al.get(7),al.get(4));
                staticVal = 1;
                ruleCat = "PE";
            }
            else
            {
                Accountid=payLoad_SinglePrgm_Revamp.AccountidCreationResponse_UATFC_49(al.get(16),al.get(15),al.get(2),al.get(5),al.get(3),al.get(7),al.get(4));
                staticVal = 2;
                ruleCat = "Mentor";
            }
        }

        System.out.println("al : "+al);
        
        ac.closeTabWindows(2);    
        ac.Notification();
        
        prior_prog_Id = al;
        
        String AccountURL=CurrURL+Accountid;
        ac.goTo(AccountURL);
        
        String accOwner = ac.CaptureAccOwnerNam();
        
        System.out.println("prior_prog1_Id :"+prior_prog_Id);
        
        ac.ClickStudentPrograms();
        
        String[] prgmData=sp.verifyIsPrimarychecked();
        log.info("Actual Primary Prog ID is :  "+prgmData[0]+"And expected is : "+prior_prog_Id.get(2));
        
        Assert.assertEquals(prgmData[0],prior_prog_Id.get(2),"1: Combination : "+Tcid1+" , expected "+prior_prog_Id.get(2)+" but found "+prgmData[0]);
        Assert.assertEquals(prgmData[1],prior_prog_Id.get(3),"1: Combination : "+Tcid1+" , expected "+prior_prog_Id.get(3)+" but found "+prgmData[1]);
        Assert.assertEquals(prgmData[2],prior_prog_Id.get(7),"1: Combination : "+Tcid1+" , expected "+prior_prog_Id.get(7)+" but found "+prgmData[2]);
        
        //Closing the sub tabs
        ac.CloseCurrentSubTab();
        ac.AdditionalWait();
        
        prog_tasks.put(prior_prog_Id.get(0), 0);
        
        // Verifying the task journey
        if(excelData.searchColData("TestData", "Task_Journey", "Program Id", prior_prog_Id.get(2)))
        {
            noofTasks = verifyTaskJourney(prior_prog_Id,staticVal,accOwner,noofTasks);
            totalTasks = noofTasks;
            prog_tasks.put(prior_prog_Id.get(0), noofTasks);
        }
        
        ac.CloseSubTabs();
        ac.AdditionalWait();
        
        ac.ClickStudentPrograms();
        sp.goToprimaryProg();
        sp.ClickSSO();
        
        String ordSrc = sp.getRandOrdSrc();
        sp.enterOrdSrc(ordSrc);
        ac.CloseSubTabs();
        
        region = ac.getRandRegion();
        ac.changeRegion(region);
        ac.AdditionalWait();    
        ac.RefreshTab();        
        String expectedQueue = ar.GetExpAssgnRuleRegion(prior_prog_Id, region, ordSrc);
        System.out.println("expectedQueue : "+expectedQueue);
        
        //check if picked up assignment rule is correct
        String wh = driver.getWindowHandle();
        accOwner = ac.CaptureAccOwnerNam();
        
        if(CurrURL.contains("--byjusuat")) {
            dc.GetDevConsole("UAT");
        }
        else if(CurrURL.contains("--byjusfc")) {
            dc.GetDevConsole("UATFC");
        }
        
        dc.closeconsoleTabs();
        dc.ExecuteQuery1(Queries.getGrpIdRegion(expectedQueue, ruleCat));
            
        String grpId_exp = dc.getId(); 
        System.out.println("grpId_exp :"+grpId_exp);
        ac.AdditionalWait();
       
        //executing 1st query to get group Id from query editor
        dc.closeconsoleTabs();
        dc.ExecuteQuery1(Queries.GetGrpId(Accountid));
        String grpId = dc.getId();
        System.out.println("grpId :"+grpId);
        ac.AdditionalWait();
        
        //verifying if group id from expected queue and account are same
        Assert.assertEquals(grpId, grpId_exp);
        
        // executing 2nd query to get assignment rule Id from query editor
        dc.closeconsoleTabs();
        dc.ExecuteQuery1(Queries.getAssgnIdRegion(grpId,expectedQueue,ruleCat));
        
        String assgnId =  dc.getId(); 
        System.out.println("assgnId :"+assgnId);
        
        ac.AdditionalWait();
        dc.CloseWindowArrayLast();
        
        ac.AdditionalWait();
        driver.switchTo().window(wh);
        ac.AdditionalWait();
        
        if(CurrURL.contains("--byjusuat")) {
            ac.goTo("https://byjusprod--byjusuat.lightning.force.com/lightning/r/Assignment_Rule__c/"+assgnId+"/view");

        }
        else if(CurrURL.contains("--byjusfc")) {
            ac.goTo("https://byjusprod--byjusfc.sandbox.lightning.force.com/lightning/r/Assignment_Rule__c/" + assgnId
                    + "/view");
        }

        String QueueName = ar.getAssgnRuleDetails("Assignment Rule Name");
        
        System.out.println("QueueName :"+QueueName);
        
        //verifies if the expected queue and the actual queue are same
        Assert.assertEquals(QueueName, expectedQueue);
        Assert.assertEquals(ar.getAssgnRuleDetails("Rule Category"), ruleCat);
        Assert.assertEquals(ar.getAssgnRuleDetails("Region"), region);
        
        if(expectedQueue.contains("North America"))
            Assert.assertEquals(ar.getAssgnRuleDetails("Student Unit"), al.get(13));
        
        ar.NavtoGroup(QueueName);
        ar.navToGrpMem();
        Assert.assertTrue(ar.VerifyCaseOwner(accOwner));
        ac.closeCurrentTabWindow();
        
        //******************** SFDC-4655-13 ***********************// - Order Source
         
        if(region.equalsIgnoreCase("Middle East"))
        {
            ac.ClickStudentPrograms();
            sp.goToprimaryProg();
            sp.ClickSSO();
            
            if(ordSrc.equalsIgnoreCase("Byjus India"))
            {
               ordSrc = "More Ideas";
                sp.enterOrdSrc(ordSrc);
                
            }
            else if(ordSrc.equalsIgnoreCase("More Ideas"))
            {
                ordSrc = "Byjus India";
                sp.enterOrdSrc(ordSrc);
            }
            
            ac.CloseSubTabs();
            
            expectedQueue = ar.GetExpAssgnRuleRegion(prior_prog_Id, region, ordSrc);
            System.out.println("expectedQueue : "+expectedQueue);
            
            //check if picked up assignment rule is correct
            wh = driver.getWindowHandle();
            accOwner = ac.CaptureAccOwnerNam();
            
            if(CurrURL.contains("--byjusuat")) {
                dc.GetDevConsole("UAT");
            }
            else if(CurrURL.contains("--byjusfc")) {
                dc.GetDevConsole("UATFC");
            }
            
            dc.closeconsoleTabs();
            dc.ExecuteQuery1(Queries.getGrpIdRegion(expectedQueue, ruleCat));
                
            grpId_exp = dc.getId(); 
            System.out.println("grpId_exp :"+grpId_exp);
            ac.AdditionalWait();
           
            //executing 1st query to get group Id from query editor
            dc.closeconsoleTabs();
            dc.ExecuteQuery1(Queries.GetGrpId(Accountid));
            grpId = dc.getId();
            System.out.println("grpId :"+grpId);
            ac.AdditionalWait();
            
            //verifying if group id from expected queue and account are same
            Assert.assertEquals(grpId, grpId_exp);
            
            // executing 2nd query to get assignment rule Id from query editor
            dc.closeconsoleTabs();
            dc.ExecuteQuery1(Queries.getAssgnIdRegion(grpId,expectedQueue,ruleCat));
            
            assgnId =  dc.getId(); 
            System.out.println("assgnId :"+assgnId);
            
            ac.AdditionalWait();
            dc.CloseWindowArrayLast();
            
            ac.AdditionalWait();
            driver.switchTo().window(wh);
            ac.AdditionalWait();
            
            if(CurrURL.contains("--byjusuat")) {
                ac.goTo("https://byjusprod--byjusuat.lightning.force.com/lightning/r/Assignment_Rule__c/"+assgnId+"/view");

            }
            else if(CurrURL.contains("--byjusfc")) {
                ac.goTo("https://byjusprod--byjusfc.sandbox.lightning.force.com/lightning/r/Assignment_Rule__c/" + assgnId
                        + "/view");
            }

            QueueName = ar.getAssgnRuleDetails("Assignment Rule Name");
            
            System.out.println("QueueName :"+QueueName);
            
            //verifies if the expected queue and the actual queue are same
            Assert.assertEquals(QueueName, expectedQueue);
            Assert.assertEquals(ar.getAssgnRuleDetails("Rule Category"), ruleCat);
            Assert.assertEquals(ar.getAssgnRuleDetails("Region"), region);
            
            if(expectedQueue.contains("North America"))
                Assert.assertEquals(ar.getAssgnRuleDetails("Student Unit"), al.get(13));
            
            ar.NavtoGroup(QueueName);
            ar.navToGrpMem();
            Assert.assertTrue(ar.VerifyCaseOwner(accOwner));
            ac.closeCurrentTabWindow();
        }
        
        ac.ClickStudentPrograms();
        sp.goToprimaryProg();
        
        //Task journey // 8 - region
        if(excelData.searchColData("TestData", "Task_Journey", "Region", region))
        {
            noofTasks = verifyTaskJourney(prior_prog_Id,staticVal,accOwner,noofTasks);
            totalTasks = noofTasks;
            prog_tasks.put(prior_prog_Id.get(0), noofTasks);
        }
        
        ac.CloseSubTabs();
        ac.AdditionalWait();       
        ac.DeleteAllCreatedStuProg();
        ac.NavBackToAccount();
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
        
    }
    
    //Inserting 2 programs one after the other
    @Test(groups = { "Regression" ,"sanity"}, enabled = false)
    public void Revamp_K10_PR1() throws Exception {
        //String T1,String T2,String T3,String T4,String T5,String T6,String T7,String T8,String T9,String T10,String T11,String T12,String T13,String T14,String T15,String T16,String T17,String T18,String T19,String T20,String T21
        StudentProgPO sp = new StudentProgPO(driver);
        loginPO lo=new loginPO(driver);
        CreatedAccountPO ac=new CreatedAccountPO(driver);
        SoftAssert a = new SoftAssert();
        String Accountid = "";
        String prog1 = "",prog2 = "",prog3 = "";
       
        //getting count of rows
        int noofRows = getRowCount("src//main//java//testData//TestData.xlsx", "Revamp_K10");
        
        String T1 = "15";
        int i = randomNumber(1,noofRows-1);
        
        log.info("Logging in as Admin to UAT");
        
        //for(int i=1;i<noofRows;i++) {
            if(Integer.valueOf(T1)!=i) {
                
                al = excelData.getData(T1, "Revamp_K10", "Tcid");                
                al2 = excelData.getData(String.valueOf(i), "Revamp_K10", "Tcid");
                
                log.info("Submitting the Account creation payload");
                // Creating a new student account with one program
                if(CurrURL.contains("--byjusuat")) 
                {
                    lo.LoginAsAdmin_UAT();
                    Accountid=payLoad_SinglePrgm_Revamp.AccountidCreationResponse_UAT(al.get(16),al.get(15),al.get(2),al.get(5),al.get(3),al.get(7),al.get(4));

                }
                else if(CurrURL.contains("--byjusfc"))
                {
                    lo.LoginAsAdmin_UATFC();
                    
                    Accountid=payLoad_SinglePrgm_Revamp.AccountidCreationResponse_UATFC(al.get(16),al.get(15),al.get(2),al.get(5),al.get(3),al.get(7),al.get(4));

                }
                ac.closeTabWindows(2);    
                ac.Notification();
                
                log.info("Launching the newly created Account id "+Accountid);
                
                System.out.println(T1+" "+i);
                
                String AccountURL=CurrURL+Accountid;
                ac.goTo(AccountURL);
                
                System.out.println("al : "+al);
                System.out.println("al2 : "+al2);
                
                prior_prog_Id = al;
                
                ac.AdditionalWait();
                ac.AdditionalWait();
                ac.ClickStudentPrograms();
                ac.AccountLoadwait();
                
                System.out.println("prior_prog1_Id :"+prior_prog_Id);
                //Returns the prog id, prod type and trial prog
                String[] prgmData=sp.verifyIsPrimarychecked();
                log.info("Actual Primary Prog ID is :  "+prgmData[0]+"And expected is : "+prior_prog_Id.get(2));
                
                a.assertEquals(prgmData[0],prior_prog_Id.get(2),"1: Combination : "+T1+"-"+i+" , expected "+prior_prog_Id.get(2)+" but found "+prgmData[0]);
                a.assertEquals(prgmData[1],prior_prog_Id.get(3),"1: Combination : "+T1+"-"+i+" , expected "+prior_prog_Id.get(3)+" but found "+prgmData[1]);
                a.assertEquals(prgmData[2],prior_prog_Id.get(7),"1: Combination : "+T1+"-"+i+" , expected "+prior_prog_Id.get(7)+" but found "+prgmData[2]);
                
                //Closing the sub tabs
                ac.CloseSubTabs();
                ac.AdditionalWait();
                
                //******************** SFDC-4655-1 ***********************// - Adding a new program
                
                //Adding a 2nd program in to an existing student account
                if(CurrURL.contains("--byjusuat")) {
                    payLoad_PrgmwithSSO_Revamp.AccountidCreationResponse_UAT(Accountid,al2.get(2),al2.get(5),al2.get(3),al2.get(7),al2.get(4));

                }
                else if(CurrURL.contains("--byjusfc")) {
                    payLoad_PrgmwithSSO_Revamp.AccountidCreationResponse_UATFC(Accountid,al2.get(2),al2.get(5),al2.get(3),al2.get(7),al2.get(4));

                }
                
                // Comparing the priorities of both the programs
                if(Integer.valueOf(al2.get(8)) < Integer.valueOf(al.get(8)))
                {
                    prior_prog_Id = al2;
                }
                
                System.out.println("prior_prog2_Id :"+prior_prog_Id);
                lo.RefreshURL();
                ac.AdditionalWait();
                ac.ClickStudentPrograms();
                
                //Returns the prog id, prod type and trial prog
                prgmData=sp.verifyIsPrimarychecked();
                log.info("Actual Primary Prog ID is :  "+prgmData[0]+"And expected is : "+prior_prog_Id.get(2));
                
                a.assertEquals(prgmData[0],prior_prog_Id.get(2),"2: Combination : "+T1+"-"+i+" , expected "+prior_prog_Id.get(2)+" but found "+prgmData[0]);
                a.assertEquals(prgmData[1],prior_prog_Id.get(3),"2: Combination : "+T1+"-"+i+" , expected "+prior_prog_Id.get(3)+" but found "+prgmData[1]);
                a.assertEquals(prgmData[2],prior_prog_Id.get(7),"2: Combination : "+T1+"-"+i+" , expected "+prior_prog_Id.get(7)+" but found "+prgmData[2]);
                
                ac.CloseSubTabs();
                ac.AdditionalWait();
                
                //******************** SFDC-4655-8 ***********************// - Trial program
                
                if(!prior_prog_Id.get(2).equalsIgnoreCase("BCOPKXSY0002") && prior_prog_Id.get(4).equalsIgnoreCase("Toppr"))
                {
                    ac.ClickStudentPrograms();
                    sp.goToprimaryProg();
                    
                    if(prior_prog_Id.get(7).equalsIgnoreCase("No"))
                        updatetrialProg("Yes");
                    else
                        updatetrialProg("No");                  
                    
                    ac.AdditionalWait();
                  
                    System.out.println("prior_prog3_Id : "+prior_prog_Id);
                    
                    ac.CloseCurrentSubTab();
                    ac.AdditionalWait();
                    
                    //Returns the prog id, prod type and trial prog
                    prgmData=sp.verifyIsPrimarychecked();
                    log.info("Actual Primary Prog ID is :  "+prgmData[0]+"And expected is : "+prior_prog_Id.get(2));
                    
                    a.assertEquals(prgmData[0],prior_prog_Id.get(2),"3: Combination : "+T1+"-"+i+" , expected "+prior_prog_Id.get(2)+" but found "+prgmData[0]);
                    a.assertEquals(prgmData[1],prior_prog_Id.get(3),"3: Combination : "+T1+"-"+i+" , expected "+prior_prog_Id.get(3)+" but found "+prgmData[1]);
                    a.assertEquals(prgmData[2],prior_prog_Id.get(7),"3: Combination : "+T1+"-"+i+" , expected "+prior_prog_Id.get(7)+" but found "+prgmData[2]);
                    
                    ac.CloseCurrentSubTab();
                    ac.CloseCurrentSubTab();
                    ac.AdditionalWait();
                    
                    sp.goToNonprimaryProg();
                    
                    //changing back the trial program
                    if(sec_prog_Id.get(7).equalsIgnoreCase("No"))
                        updatetrialProg("No");
                    else
                        updatetrialProg("Yes");
                    
                    System.out.println("prior_prog4_Id :"+prior_prog_Id);
                    ac.CloseSubTabs();
                    ac.AdditionalWait();      
                }
                
                //******************** SFDC-4655-5,6 ***********************// - Changing student unit
                
                //Taking a random cohort
                al3 = sp.getNewProg(al.get(13),al.get(16));
                
                System.out.println("al3 :"+al3);
                
                //Inserting student program from above cohort
                if(al3.get(13).equalsIgnoreCase("K3"))
                {
                    log.info("Inserting student program from above cohort");
                    if(CurrURL.contains("--byjusuat"))
                    {
                        payLoad_Revamp_K3.AccountidCreationResponse_UAT2(Accountid,al3.get(2),al3.get(5),al3.get(3),al3.get(7),al3.get(4),al3.get(22));

                    }
                    else if(CurrURL.contains("--byjusfc"))
                    {
                        payLoad_Revamp_K3.AccountidCreationResponse_UATFC2(Accountid,al3.get(2),al3.get(5),al3.get(3),al3.get(7),al3.get(4),al3.get(22));

                    }
                
                }
                else
                {
                    log.info("Inserting student program from above cohort");
                    if(CurrURL.contains("--byjusuat"))
                    {
                        payLoad_PrgmwithSSO_Revamp.AccountidCreationResponse_UAT(Accountid,al3.get(2),al3.get(5),al3.get(3),al3.get(7),al3.get(4));

                    }
                    else if(CurrURL.contains("--byjusfc"))
                    {
                        payLoad_PrgmwithSSO_Revamp.AccountidCreationResponse_UATFC(Accountid,al3.get(2),al3.get(5),al3.get(3),al3.get(7),al3.get(4));

                    }             
                }
                
                //change current class on account
                ac.AdditionalWait();
                log.info("Changing current class"); 
                ac.ChangeClass(al3.get(16));
                ac.AccountLoadwait();
                
                lo.RefreshURL();
                ac.AdditionalWait();
                ac.ClickStudentPrograms();
                
                List<String> progNames = sp.getProgNames();
                
                //gets the combinations of all 3 programs with the new student unit
                sp.clickStuProgName(progNames.get(0));
                ac.AccountLoadwait();
                prog1 = sp.getCombination(al.get(13),al3.get(13), al);
                ac.CloseCurrentSubTab();
                ac.CloseCurrentSubTab();
                System.out.println("prog1 : "+prog1);
                
                sp.clickStuProgName(progNames.get(1));
                ac.AccountLoadwait();
                prog2 = sp.getCombination(al2.get(13),al3.get(13), al2);
                ac.CloseCurrentSubTab();
                ac.CloseCurrentSubTab();
                System.out.println("prog2 : "+prog2);
                
                sp.clickStuProgName(progNames.get(2));
                ac.AccountLoadwait();
                prog3 = sp.getCombination(al3.get(13),al3.get(13), al3);
                ac.CloseCurrentSubTab();
                ac.CloseCurrentSubTab();
                System.out.println("prog3 : "+prog3);
                        
                String sheetName = "Revamp_"+al3.get(13);
                
                if(al3.get(16).equalsIgnoreCase("7"))
                    sheetName = "Revamp_K7";
                else if(al3.get(16).equalsIgnoreCase("8") || al3.get(16).equalsIgnoreCase("9"))
                    sheetName = "Revamp_K8-9";
                
                prior_prog_Id = excelData.getData(sp.getPrimaryProgTcid(prog1, prog2, prog3,al3.get(16)), sheetName, "Tcid");
                System.out.println("prior_prog5_Id :"+prior_prog_Id);

                //Verifying if the new program inserted is primary program
                //Returns the prog id, prod type and trial prog
                prgmData=sp.verifyIsPrimarychecked();  
                log.info("Actual Primary Prog ID is :  "+prgmData[0]+"And expected is : "+prior_prog_Id.get(2));
                
                a.assertEquals(prgmData[0],prior_prog_Id.get(2),"4: Combination : "+T1+"-"+i+" -- New program : "+prior_prog_Id.get(0)+" , expected "+prior_prog_Id.get(2)+" but found "+prgmData[0]);
                a.assertEquals(prgmData[2],prior_prog_Id.get(7),"4: Combination : "+T1+"-"+i+" -- New program : "+prior_prog_Id.get(0)+" , expected "+prior_prog_Id.get(7)+" but found "+prgmData[2]);

                ac.CloseSubTabs();
                ac.AdditionalWait();
                
                
                log.info("Deleting the Student Program details");
                ac.DeleteAllCreatedStuProg();
                
                log.info("Deleting the Student Payment details");
                //ac.DeleteAllCreatedStuPayment();
                
                ac.NavBackToAccount();
                log.info("Deleting the Account created details");
                ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
         
                System.out.println(T1+" "+i);
            }
        //} 
        a.assertAll();
    }
  
    //task journey with 1st program start date as current date
    @Test(dataProvider = "testDatapro",groups = { "Regression" ,"sanity"}, enabled = false)
    public void Revamp_K10_TJ1(String T1,String T2,String T3,String T4,String T5,String T6,String T7,String T8,String T9,String T10,String T11,String T12,String T13,String T14,String T15,String T16,String T17,String T18,String T19,String T20,String T21) throws Exception
    {
        CreatedAccountPO ac=new CreatedAccountPO(driver);
        StudentProgPO sp = new StudentProgPO(driver);
        loginPO lo=new loginPO(driver);        
        String Accountid = "";
        List<String> prognames = new ArrayList<String>();
        ArrayList<String> progNamesList = new ArrayList<String>();      
        
        String prog1 = "",prog2 = "",prog3 = "";
        int staticVal;
       
        //getting count of rows
        int noofRows = getRowCount("src//main//java//testData//TestData.xlsx", "Revamp_K10");
      
        //getting a random row number 
        //String Tcid1 = String.valueOf(randomNumber(1,noofRows-1));
        String Tcid1 = T1;
        String Tcid2 = String.valueOf(randomNumber(1,noofRows-1));  

        al = excelData.getData(Tcid1, "Revamp_K10", "Tcid");
        al2 = excelData.getData(Tcid2, "Revamp_K10", "Tcid");
        
        while(Tcid1.equals(Tcid2) || al.get(2).equalsIgnoreCase(al2.get(2)))
        {
            Tcid2 = String.valueOf(randomNumber(1,noofRows-1));
            al2 = excelData.getData(Tcid2, "Revamp_K10", "Tcid");
        }
        
        if(CurrURL.contains("--byjusuat")) 
        {
            lo.LoginAsAdmin_UAT();
            
            // Creating a new student account
            Accountid=payLoad_SinglePrgm_Revamp.AccountidCreationResponse_UAT(al.get(16),al.get(15),al.get(2),al.get(5),al.get(3),al.get(7),al.get(4));
        }
        else if(CurrURL.contains("--byjusfc")) {
            
            lo.LoginAsAdmin_UATFC();

            // Creating a new student account with one program
            // classNo, Mentlang, ProgId, Duration, ProdType, TrialProg, ProgType, UsageMode
            Accountid=payLoad_SinglePrgm_Revamp.AccountidCreationResponse_UATFC(al.get(16),al.get(15),al.get(2),al.get(5),al.get(3),al.get(7),al.get(4));

        }

        staticVal = 1;
        System.out.println("al : "+al);
        System.out.println("al2 : "+al2);
        
        ac.closeTabWindows(2);    
        ac.Notification();
        
        prior_prog_Id = al;
        priProg_Det.put(al.get(8), al); // storing priority numb with the priority tc row
        
        String AccountURL=CurrURL+Accountid;
        ac.goTo(AccountURL);
        String accOwner = ac.CaptureAccOwnerNam();
        

        System.out.println("prior_prog1_Id :"+prior_prog_Id);
        
        ac.ClickStudentPrograms();
        
        //get the program name
        prognames = sp.getProgNames();
        progNamesList.add(prognames.get(0));
        String[] prgmData=sp.verifyIsPrimarychecked();
        log.info("Actual Primary Prog ID is :  "+prgmData[0]+"And expected is : "+prior_prog_Id.get(2));
        
        Assert.assertEquals(prgmData[0],prior_prog_Id.get(2),"1: Combination : "+Tcid1+" , expected "+prior_prog_Id.get(2)+" but found "+prgmData[0]);
        Assert.assertEquals(prgmData[1],prior_prog_Id.get(3),"1: Combination : "+Tcid1+" , expected "+prior_prog_Id.get(3)+" but found "+prgmData[1]);
        Assert.assertEquals(prgmData[2],prior_prog_Id.get(7),"1: Combination : "+Tcid1+" , expected "+prior_prog_Id.get(7)+" but found "+prgmData[2]);
        
        ac.CloseCurrentSubTab();
        ac.AdditionalWait();
        
        int noofTasks = 0;
        int totalTasks = 0; 
        prog_tasks.put(prior_prog_Id.get(0), 0);
        // Verifying the task journey
        if(excelData.searchColData("TestData", "Task_Journey", "Program Id", prior_prog_Id.get(2)))
        {
            noofTasks = verifyTaskJourney(prior_prog_Id,staticVal,accOwner,noofTasks);
            totalTasks = noofTasks;
            prog_tasks.put(prior_prog_Id.get(0), noofTasks);
        }
        
        String sel = ac.getSOSelection(al.get(16));

        //Adding a 2nd program in to an existing student account
        if(sel.equalsIgnoreCase("1"))
        {
            if(CurrURL.contains("--byjusuat"))
            {
                payLoad_PrgmwithSSO_Revamp.AccountidCreationResponse_UAT(Accountid,al2.get(2),al2.get(5),al2.get(3),al2.get(7),al2.get(4));

            }
            else if(CurrURL.contains("--byjusfc"))
            {
                payLoad_PrgmwithSSO_Revamp.AccountidCreationResponse_UATFC(Accountid,al2.get(2),al2.get(5),al2.get(3),al2.get(7),al2.get(4));

            }
        
        }
        else 
        {
            InsertNewProg(al2);
            ac.AdditionalWait();
        }
        
        priProg_Det.put(al2.get(8), al2);
        
        // Comparing the priorities of both the programs
        //high priority
        if(Integer.valueOf(al2.get(8)) < Integer.valueOf(al.get(8)))
        {
            prior_prog_Id = al2;
            sec_prog_Id = al;            
            if(sel.equalsIgnoreCase("1")) {
                staticVal = 1;
            }
            else {
                staticVal = 2;
            }
            totalTasks = 0;
        }
        //low priority
        else 
        {
            prior_prog_Id = al;
            sec_prog_Id = al2;            
            if(sec_prog_Id.get(9).equalsIgnoreCase("Yes")) {
                staticVal = 3;
            }
            else {
                staticVal = 4;
            }
        }
        
        System.out.println("prior_prog2_Id :"+prior_prog_Id);
        
        lo.RefreshURL();
        ac.AdditionalWait();
        
        ac.CloseSubTabs();
        ac.AdditionalWait();
        
        if(!prior_prog_Id.equals(al)) 
        {
            int exp_count = prog_tasks.get(al.get(0));
            ac.ClickActivityHistory_Scroll();
            int act_count = sp.statusCompletedCount(exp_count,"Cancelled");
            Assert.assertEquals(act_count,exp_count );
            ac.CloseCurrentSubTab();
            ac.AdditionalWait();
        }       
        
        accOwner = ac.CaptureAccOwnerNam();
        ac.ClickStudentPrograms();
       
       //get the program name
        prognames = sp.getProgNames();
        for(int j=0;j<prognames.size();j++)
        {
            if(!progNamesList.contains(prognames.get(j)))
            {
                progNamesList.add(prognames.get(j));
            }
        }
        //Returns the prog id, prod type and trial prog
        prgmData=sp.verifyIsPrimarychecked();
        log.info("Actual Primary Prog ID is :  "+prgmData[0]+"And expected is : "+prior_prog_Id.get(2));
        
        Assert.assertEquals(prgmData[0],prior_prog_Id.get(2),"2: Combination : "+Tcid1+"-"+Tcid2+" , expected "+prior_prog_Id.get(2)+" but found "+prgmData[0]);
        Assert.assertEquals(prgmData[1],prior_prog_Id.get(3),"2: Combination : "+Tcid1+"-"+Tcid2+" , expected "+prior_prog_Id.get(3)+" but found "+prgmData[1]);
        Assert.assertEquals(prgmData[2],prior_prog_Id.get(7),"2: Combination : "+Tcid1+"-"+Tcid2+" , expected "+prior_prog_Id.get(7)+" but found "+prgmData[2]);
        
        ac.CloseSubTabs();
        ac.AdditionalWait();
        ac.ClickStudentPrograms();
        prog_tasks.put(al2.get(0), 0);
        
        if(excelData.searchColData("TestData", "Task_Journey", "Program Id", al2.get(2)))
        {
            if(staticVal == 1 || staticVal == 2)
            {
                sp.goToprimaryProg();
                noofTasks = verifyTaskJourney(prior_prog_Id,staticVal,accOwner,prog_tasks.get(Tcid1));
                prog_tasks.put(prior_prog_Id.get(0), noofTasks);
            }
            
            else if(staticVal == 3 || staticVal == 4)
            {
                sp.goToNonprimaryProg();
                int tasks = prog_tasks.get(Tcid1);
                noofTasks = verifyTaskJourney(sec_prog_Id,staticVal,accOwner, noofTasks);
                prog_tasks.put(sec_prog_Id.get(0), noofTasks);
            }
           
            totalTasks = totalTasks+noofTasks;
            ac.CloseSubTabs();
        }
        
        int numb = randomNumber(1, 4);
        
        // change status
        if(numb == 1)
        {          

            ac.AdditionalWait();
            ac.ClickStudentPrograms();
            sp.goToprimaryProg();
            
            //change status to inactive
            sp.SelectStatus("Inactive");
            sp.ClickSave();
            ac.AdditionalWait();
           
            //sec prog becomes primary
            if(prior_prog_Id==al)
            {
              prior_prog_Id = al2;
              sec_prog_Id = al;
            }
            else
            {
                prior_prog_Id = al;
                sec_prog_Id = al2;
            }
             
             ac.CloseCurrentSubTab();
             ac.AdditionalWait();
             ac.RefreshTab();
             //Returns the prog id, prod type and trial prog
             prgmData=sp.verifyIsPrimarychecked();
             log.info("Actual Primary Prog ID is :  "+prgmData[0]+"And expected is : "+prior_prog_Id.get(2));
             
             Assert.assertEquals(prgmData[0],prior_prog_Id.get(2),"3: Combination : "+Tcid1+"-"+Tcid2+" , expected "+prior_prog_Id.get(2)+" but found "+prgmData[0]);
             Assert.assertEquals(prgmData[1],prior_prog_Id.get(3),"3: Combination : "+Tcid1+"-"+Tcid2+" , expected "+prior_prog_Id.get(3)+" but found "+prgmData[1]);
             Assert.assertEquals(prgmData[2],prior_prog_Id.get(7),"3: Combination : "+Tcid1+"-"+Tcid2+" , expected "+prior_prog_Id.get(7)+" but found "+prgmData[2]);
             
             ac.CloseSubTabs();
             ac.RefreshTab();
             ac.AdditionalWait();
             
             //added here
             accOwner = ac.CaptureAccOwnerNam();
             staticVal = 1;
  /*           if(sel.equalsIgnoreCase("1"))
             {
                 staticVal = 1;
             }
             else 
             {
                 staticVal = 2;
             }
  */           
             ac.ClickStudentPrograms();
             sp.goToprimaryProg();
             
             // verify cancelled open activties
             int exp_count = 0;
             ArrayList<String> Tcids=sp.getTcids("Task_Journey", prior_prog_Id.get(2));
             String tcid=sp.getTcid_TaskJour(Tcids, prior_prog_Id);
             al3 = excelData.getData(tcid, "Task_Journey", "Tcid");
             
             String p_tcid = prior_prog_Id.get(0);
             String se_tcid = sec_prog_Id.get(0);
             
             boolean check_1 = excelData.searchColData("TestData", "Task_Journey", "Program Id", al.get(2));
             boolean check_2 = excelData.searchColData("TestData", "Task_Journey", "Program Id", al2.get(2));
             
             if(!al3.isEmpty()) {
                 if(check_1 && check_2)
                 {
                     if(prior_prog_Id.equals(al)) {
                         exp_count = prog_tasks.get(p_tcid)+prog_tasks.get(se_tcid);
                     }
                     else {
                         if(staticVal == 1)
                         {
                             if(al3.get(13).equalsIgnoreCase(tcid_tasktypes.get(p_tcid)) ) {
                                 exp_count = prog_tasks.get(se_tcid);
                               }
                               else if(!al3.get(13).equalsIgnoreCase(tcid_tasktypes.get(p_tcid)) ) {
                                 exp_count = prog_tasks.get(p_tcid)+prog_tasks.get(se_tcid);
                               }
                         }
                         else if(staticVal == 2)
                         {
                             if(al3.get(16).equalsIgnoreCase(tcid_tasktypes.get(p_tcid)) ) {
                                 exp_count = prog_tasks.get(se_tcid);
                               }
                               else if(!al3.get(16).equalsIgnoreCase(tcid_tasktypes.get(p_tcid)) ) {
                                 exp_count = prog_tasks.get(p_tcid)+prog_tasks.get(se_tcid);
                               }
                         }
                     }
                    
                 }
                 else if(check_1)
                 {
                     exp_count = prog_tasks.get(al.get(0));
                 }
                 else if(check_2)
                 {
                     exp_count = prog_tasks.get(al2.get(0));
                 }
             }   
             else {
                 exp_count = prog_tasks.get(se_tcid);
             }
            
             ac.CloseSubTabs();
             ac.AdditionalWait();

             ac.ClickActivityHistory_Scroll();
             int noOfTasks = sp.statusCompletedCount(exp_count,"Cancelled");
             Assert.assertEquals(noOfTasks, exp_count);
             ac.CloseCurrentSubTab();
             ac.AdditionalWait();
             
             ac.ClickStudentPrograms();
             sp.goToprimaryProg();
             
             // Verifying the task journey
             if(excelData.searchColData("TestData", "Task_Journey", "Program Id", prior_prog_Id.get(2)) )
             {
                 //noofTasks = verifyTaskJourney(prior_prog_Id,staticVal,accOwner,prog_tasks.get(p_tcid));
                 if (staticVal == 1) {
                     if (tcid_tasktypes.keySet().contains(p_tcid))
                         if (!al3.get(13).equalsIgnoreCase(tcid_tasktypes.get(p_tcid))) {
                             noofTasks = verifyTaskJourney(prior_prog_Id,staticVal,accOwner,prog_tasks.get(p_tcid));
                         }
                 } else if (staticVal == 2) {
                     if (tcid_tasktypes.keySet().contains(p_tcid))
                         if (!al3.get(16).equalsIgnoreCase(tcid_tasktypes.get(p_tcid))) {
                             noofTasks = verifyTaskJourney(prior_prog_Id,staticVal,accOwner,prog_tasks.get(p_tcid));
                         }
                 }
             }
                
             ac.CloseSubTabs();
             ac.AdditionalWait();      
                  
        }
        
        // change student unit
        else if(numb == 2)
        {
            ac.CloseSubTabs();
            UpdateStuUnit(Accountid);
            ac.ClickStudentPrograms();
            
            //get the program name
            prognames = sp.getProgNames();
            for(int j=0;j<prognames.size();j++)
            {
                if(!progNamesList.contains(prognames.get(j)))
                {
                    progNamesList.add(prognames.get(j));
                }
            }
            
            System.out.println("progNamesList : "+progNamesList);
            
            String sheetName = "";
            if(al3.get(16).equalsIgnoreCase("7"))
                sheetName = "Revamp_K"+al3.get(16);
            else if(al3.get(16).equalsIgnoreCase("8") || al3.get(16).equalsIgnoreCase("9"))
                sheetName = "Revamp_K8-9";
            else
                sheetName = "Revamp_"+al3.get(13);
            
            //gets the combinations of all 3 programs with the new student unit
            sp.clickStuProgName(progNamesList.get(0));
            
            ArrayList<String> tcids = sp.getTcids(sheetName, al.get(2));
            if(tcids.size()>0)
                prog1 = sp.getProgComb(tcids, sheetName, al.get(2));
            if(prog1.isEmpty())
            {
                prog1 = sp.getCombination(al.get(13),al3.get(13), al);
                ac.CloseCurrentSubTab();
            }

            
            ac.AdditionalWait();
            ac.CloseCurrentSubTab();
            System.out.println("prog1 : "+prog1);
            
            sp.clickStuProgName(progNamesList.get(1));
            
            tcids = sp.getTcids(sheetName, al2.get(2));
            if(tcids.size()>0)
                prog2 = sp.getProgComb(tcids, sheetName, al2.get(2));
            if(prog2.isEmpty())
            {
                prog2 = sp.getCombination(al2.get(13),al3.get(13), al2);
                ac.CloseCurrentSubTab();
            }
                
            ac.AdditionalWait();
            ac.CloseCurrentSubTab();
            System.out.println("prog2 : "+prog2);
            
            sp.clickStuProgName(progNamesList.get(2));
            
            tcids = sp.getTcids(sheetName, al3.get(2));
            if(tcids.size()>0)
                prog3 = sp.getProgComb(tcids, sheetName, al3.get(2));
            if(prog3.isEmpty())
            {
                prog3 = sp.getCombination(al3.get(13),al3.get(13), al3);
                ac.CloseCurrentSubTab();
            }
            
            ac.AdditionalWait();
            ac.CloseSubTabs();
            System.out.println("prog3 : "+prog3);
                    
            boolean check = false;
            
            //If prog1 is sec, check if prog1 exist in new student unit 
            if(prog1.contains(sec_prog_Id.get(2)))
            {
                check = excelData.searchColData("TestData", "Revamp_Combinations", "Id", prog1);
            }
            //Else if prog1 is sec, check if prog1 exist in new student unit 
            else if(prog2.contains(sec_prog_Id.get(2)))
            {
                check = excelData.searchColData("TestData", "Revamp_Combinations", "Id", prog2);
            }
                    
            prior_prog_Id = excelData.getData(sp.getPrimaryProgTcid(prog1, prog2, prog3, al3.get(16)), sheetName, "Tcid");
            System.out.println("prior_prog3_Id :"+prior_prog_Id);
            
            //added here
            accOwner = ac.CaptureAccOwnerNam();

            ac.ClickStudentPrograms();
            sp.clickStuProgName(progNamesList.get(2));
            
            // Verifying the task journey of new program
            
            if(excelData.searchColData("TestData", "Task_Journey", "Program Id", al3.get(2)))
            {
                if(al3.get(0).equalsIgnoreCase(prior_prog_Id.get(0)))
                {
                    staticVal = 1; // '2 - 6
                    int totaltasks = prog_tasks.get(Tcid1)+ prog_tasks.get(Tcid2);
                    if(prog_tasks.keySet().contains(sec_prog_Id.get(0)) && check) {
                        flag = 1;
                    }
                    noofTasks = verifyTaskJourney(prior_prog_Id,staticVal,accOwner,totaltasks);
                }    
                else
                {
                    if(al3.get(9).equalsIgnoreCase("Yes"))
                        staticVal = 3;
                    else 
                        staticVal = 4;
                    
                        noofTasks = verifyTaskJourney(al3,staticVal,accOwner,totalTasks);
                }
            }
            else
            {
                int totaltasks = prog_tasks.get(Tcid1)+ prog_tasks.get(Tcid2);
                ac.ClickActivityHistory_Scroll();
                int noOfTasks = sp.statusCompletedCount(totaltasks,"Cancelled");
                Assert.assertEquals(noOfTasks, totaltasks);
                ac.CloseCurrentSubTab();
                ac.AdditionalWait();
                
            }
        }
        
        // change trial program
        else if(numb == 3)
        {
           // if(!(prior_prog_Id.get(2).equalsIgnoreCase("BCOPKXSY0002") && ((prior_prog_Id.get(3).equalsIgnoreCase("Free") && prior_prog_Id.get(5).equalsIgnoreCase("Monthly")) || prior_prog_Id.get(4).equalsIgnoreCase("Toppr")))) 
            //{ }

            ac.ClickStudentPrograms();
            sp.goToprimaryProg();
            
            if(prior_prog_Id.get(7).equalsIgnoreCase("No"))
                updatetrialProg("Yes");
            else
                updatetrialProg("No");                  
            
            ac.AdditionalWait();
          
            System.out.println("prior_prog4_Id : "+prior_prog_Id);
            
            ac.CloseCurrentSubTab();
            ac.AdditionalWait();
            ac.RefreshTab();
            //Returns the prog id, prod type and trial prog
            prgmData=sp.verifyIsPrimarychecked();
            log.info("Actual Primary Prog ID is :  "+prgmData[0]+"And expected is : "+prior_prog_Id.get(2));
            
            Assert.assertEquals(prgmData[0],prior_prog_Id.get(2),"3: Combination : "+Tcid1+"-"+Tcid2+" , expected "+prior_prog_Id.get(2)+" but found "+prgmData[0]);
            Assert.assertEquals(prgmData[1],prior_prog_Id.get(3),"3: Combination : "+Tcid1+"-"+Tcid2+" , expected "+prior_prog_Id.get(3)+" but found "+prgmData[1]);
            Assert.assertEquals(prgmData[2],prior_prog_Id.get(7),"3: Combination : "+Tcid1+"-"+Tcid2+" , expected "+prior_prog_Id.get(7)+" but found "+prgmData[2]);
            
            ac.CloseSubTabs();
            ac.RefreshTab();
            ac.AdditionalWait();
            
            //added here
            accOwner = ac.CaptureAccOwnerNam();

            if(prior_prog_Id.equals(al))
            {
                staticVal = 2;
            }
            else
            {
                if(sel.equalsIgnoreCase("1"))
                {
                    staticVal = 1;
                }
                else 
                {
                    staticVal = 2;
                }
            }
            
            ac.ClickStudentPrograms();
            sp.goToprimaryProg();
            
            // verify cancelled open activties
            int exp_count = 0;
            ArrayList<String> Tcids=sp.getTcids("Task_Journey", prior_prog_Id.get(2));
            String tcid=sp.getTcid_TaskJour(Tcids, prior_prog_Id);
            al3 = excelData.getData(tcid, "Task_Journey", "Tcid");
            
            String p_tcid = prior_prog_Id.get(0);
            String se_tcid = sec_prog_Id.get(0);
            
            boolean check_1 = excelData.searchColData("TestData", "Task_Journey", "Program Id", al.get(2));
            boolean check_2 = excelData.searchColData("TestData", "Task_Journey", "Program Id", al2.get(2));
            
            if(!al3.isEmpty()) {
                if(check_1 && check_2)
                {
                    if(prior_prog_Id.equals(al)) {
                        exp_count = prog_tasks.get(p_tcid)+prog_tasks.get(se_tcid);
                    }
                    else {
                        if(staticVal == 1)
                        {
                            if(al3.get(13).equalsIgnoreCase(tcid_tasktypes.get(p_tcid)) ) {
                                exp_count = prog_tasks.get(se_tcid);
                              }
                              else if(!al3.get(13).equalsIgnoreCase(tcid_tasktypes.get(p_tcid)) ) {
                                exp_count = prog_tasks.get(p_tcid)+prog_tasks.get(se_tcid);
                              }
                        }
                        else if(staticVal == 2)
                        {
                            if(al3.get(16).equalsIgnoreCase(tcid_tasktypes.get(p_tcid)) ) {
                                exp_count = prog_tasks.get(se_tcid);
                              }
                              else if(!al3.get(16).equalsIgnoreCase(tcid_tasktypes.get(p_tcid)) ) {
                                exp_count = prog_tasks.get(p_tcid)+prog_tasks.get(se_tcid);
                              }
                        }
                    }
                   
                }
                else if(check_1)
                {
                    exp_count = prog_tasks.get(al.get(0));
                }
                else if(check_2)
                {
                    exp_count = prog_tasks.get(al2.get(0));
                }
            }   
            else {
                exp_count = prog_tasks.get(se_tcid);
            }
           
            ac.CloseSubTabs();
            ac.AdditionalWait();

            ac.ClickActivityHistory_Scroll();
            int noOfTasks = sp.statusCompletedCount(exp_count,"Cancelled");
            Assert.assertEquals(noOfTasks, exp_count);
            ac.CloseCurrentSubTab();
            ac.AdditionalWait();
            
            ac.ClickStudentPrograms();
            sp.goToprimaryProg();
            
            // Verifying the task journey
            if (excelData.searchColData("TestData", "Task_Journey", "Program Id", prior_prog_Id.get(2))) {
                // noofTasks =
                // verifyTaskJourney(prior_prog_Id,staticVal,accOwner,prog_tasks.get(p_tcid));
                if (staticVal == 1) {
                    if (tcid_tasktypes.keySet().contains(p_tcid))
                        if (!al3.get(13).equalsIgnoreCase(tcid_tasktypes.get(p_tcid))) {
                            noofTasks = verifyTaskJourney(prior_prog_Id, staticVal, accOwner, prog_tasks.get(p_tcid));
                        }
                } else if (staticVal == 2) {
                    if (tcid_tasktypes.keySet().contains(p_tcid))
                        if (!al3.get(16).equalsIgnoreCase(tcid_tasktypes.get(p_tcid))) {
                            noofTasks = verifyTaskJourney(prior_prog_Id, staticVal, accOwner, prog_tasks.get(p_tcid));
                        }
                }
            }
                      
            ac.CloseSubTabs();
            ac.AdditionalWait();      
        
        }
        
        //change product type, program type, duration
        else 
        {
            ac.ClickStudentPrograms();
            sp.goToNonprimaryProg();
            prog1 = sp.getCombination(sec_prog_Id.get(13),al.get(13),sec_prog_Id);
            al3 = excelData.getData(prog1, "Revamp_Combinations", "Id");
            System.out.println("prog1 : "+prog1);
            
            ac.CloseCurrentSubTab();
            ac.CloseCurrentSubTab();
            ac.AdditionalWait();
            
            sp.goToprimaryProg();
            //changing class/program type , duration , product type , Trial program in primary program
            updateProgTyDurtnProdTyTrProg();
            
            //getting the details of the primary program in string separated by '-'
            prog2 = sp.getCombination(prior_prog_Id.get(13),al.get(13),prior_prog_Id);
            al4 = excelData.getData(prog2, "Revamp_Combinations", "Id");
            System.out.println("prog2 : "+prog2);
            
            //Changing the primary program based on the new data
            
            //prog2 is in excel - compare priorities
            if(excelData.searchColData("TestData", "Revamp_Combinations", "Id", prog1) && excelData.searchColData("TestData", "Revamp_Combinations", "Id", prog2) )
            {
                if(Integer.valueOf(al3.get(1)) < Integer.valueOf(al4.get(1)))
                {
                   prior_prog_Id = excelData.getData(al3.get(3), "Revamp_K10", "Tcid");
                }
                else
                    prior_prog_Id = excelData.getData(al4.get(3), "Revamp_K10", "Tcid");
            }
            //prog2(primary program) is not in excel - prog1(secondary program) is primary
            else
                prior_prog_Id = excelData.getData(al3.get(3), "Revamp_K10", "Tcid");
            
            System.out.println("prior_prog6_Id : "+prior_prog_Id);
            
            if( prior_prog_Id.equals(al))
            {            
              sec_prog_Id = al2;
            }
            else
            {                
              sec_prog_Id= al;             
            }
            
            ac.CloseCurrentSubTab();
            ac.CloseCurrentSubTab();
            ac.AdditionalWait();
            
            //Returns the prog id, prod type and trial prog
            prgmData=sp.verifyIsPrimarychecked();
            log.info("Actual Primary Prog ID is :  "+prgmData[0]+"And expected is : "+prior_prog_Id.get(2));

            Assert.assertEquals(prgmData[0],prior_prog_Id.get(2),"5: Combination : "+Tcid1+"-"+Tcid2+" , expected "+prior_prog_Id.get(2)+" but found "+prgmData[0]);
           // a.assertEquals(prgmData[1],prior_prog_Id.get(3),"Combination : "+T1+"-"+i+" , expected "+prior_prog_Id.get(3)+" but found "+prgmData[1]);
            Assert.assertEquals(prgmData[2],prior_prog_Id.get(7),"5: Combination : "+Tcid1+"-"+Tcid2+" , expected "+prior_prog_Id.get(7)+" but found "+prgmData[2]);
            
            //Closing the sub tabs
            ac.CloseSubTabs();
            ac.RefreshTab();
            ac.AdditionalWait();
                       
            //added here
            accOwner = ac.CaptureAccOwnerNam();           
            
            ac.ClickStudentPrograms();
            sp.goToprimaryProg();
            
            if(sel.equalsIgnoreCase("1"))
            {
              staticVal = 1;
            }
            else
            {
                staticVal = 2;
            }      
                        
            int exp_count = 0;
            ArrayList<String> Tcids=sp.getTcids("Task_Journey", prior_prog_Id.get(2));
            String tcid=sp.getTcid_TaskJour(Tcids, prior_prog_Id);
            al3 = excelData.getData(tcid, "Task_Journey", "Tcid");

            String p_tcid = prior_prog_Id.get(0);
            String se_tcid = sec_prog_Id.get(0);
            
            boolean check_1 = excelData.searchColData("TestData", "Task_Journey", "Program Id", al.get(2));
            boolean check_2 = excelData.searchColData("TestData", "Task_Journey", "Program Id", al2.get(2));
           
            if(!al3.isEmpty()) {
                if(check_1 && check_2)
                {
                    if(prior_prog_Id.equals(al)) {
                        exp_count = prog_tasks.get(p_tcid)+prog_tasks.get(se_tcid);
                    }
                    else {
                        if(staticVal == 1)
                        {
                            if(al3.get(13).equalsIgnoreCase(tcid_tasktypes.get(p_tcid)) ) {
                                exp_count = prog_tasks.get(se_tcid);
                              }
                              else if(!al3.get(13).equalsIgnoreCase(tcid_tasktypes.get(p_tcid)) ) {
                                exp_count = prog_tasks.get(p_tcid)+prog_tasks.get(se_tcid);
                              }
                        }
                        else if(staticVal == 2)
                        {
                            if(al3.get(16).equalsIgnoreCase(tcid_tasktypes.get(p_tcid)) ) {
                                exp_count = prog_tasks.get(se_tcid);
                              }
                              else if(!al3.get(16).equalsIgnoreCase(tcid_tasktypes.get(p_tcid)) ) {
                                exp_count = prog_tasks.get(p_tcid)+prog_tasks.get(se_tcid);
                              }
                        }
                    }
                   
                }
                else if(check_1)
                {
                    exp_count = prog_tasks.get(al.get(0));
                }
                else if(check_2)
                {
                    exp_count = prog_tasks.get(al2.get(0));
                }
            }   
            else {
                exp_count = prog_tasks.get(se_tcid);
            }                     
            
            ac.CloseSubTabs();
            ac.ClickActivityHistory_Scroll();
            int act_count = sp.statusCompletedCount(exp_count,"Cancelled");
            Assert.assertEquals(act_count, exp_count);
            ac.CloseCurrentSubTab();
            
            ac.ClickStudentPrograms();
            sp.goToprimaryProg();
            
         // Verifying the task journey
            if (excelData.searchColData("TestData", "Task_Journey", "Program Id", prior_prog_Id.get(2))) {
                // noofTasks =
                // verifyTaskJourney(prior_prog_Id,staticVal,accOwner,prog_tasks.get(p_tcid));
                if (staticVal == 1) {
                    if (tcid_tasktypes.keySet().contains(p_tcid))
                        if (!al3.get(13).equalsIgnoreCase(tcid_tasktypes.get(p_tcid))) {
                            noofTasks = verifyTaskJourney(prior_prog_Id, staticVal, accOwner, prog_tasks.get(p_tcid));
                        }
                } else if (staticVal == 2) {
                    if (tcid_tasktypes.keySet().contains(p_tcid))
                        if (!al3.get(16).equalsIgnoreCase(tcid_tasktypes.get(p_tcid))) {
                            noofTasks = verifyTaskJourney(prior_prog_Id, staticVal, accOwner, prog_tasks.get(p_tcid));
                        }
                }
            }
 
        }
        ac.CloseSubTabs();
        ac.AdditionalWait();
              
        ac.DeleteAllCreatedStuProg();
        ac.NavBackToAccount();
       
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
    }
    
  //task journey with 1st program start date < 49 days from current date
    @Test(dataProvider = "testDatapro",groups = { "Regression" ,"sanity"}, enabled = false)
    public void Revamp_K10_TJ2(String T1,String T2,String T3,String T4,String T5,String T6,String T7,String T8,String T9,String T10,String T11,String T12,String T13,String T14,String T15,String T16,String T17,String T18,String T19,String T20,String T21) throws Exception 
    {   
        StudentProgPO sp = new StudentProgPO(driver);
        loginPO lo=new loginPO(driver);
        CreatedAccountPO ac=new CreatedAccountPO(driver);
        String Accountid = "";
        List<String> prognames = new ArrayList<String>();
        ArrayList<String> progNamesList = new ArrayList<String>();      
        
        String prog1 = "",prog2 = "",prog3 = "";
        int staticVal;
       
        //getting count of rows
        int noofRows = getRowCount("src//main//java//testData//TestData.xlsx", "Revamp_K10");
       
        //getting a random row number 
        //String Tcid1 = String.valueOf(randomNumber(1,noofRows-1));
        String Tcid1 = T1;
        String Tcid2 = String.valueOf(randomNumber(1,noofRows-1));  

        al = excelData.getData(Tcid1, "Revamp_K10", "Tcid");
        al2 = excelData.getData(Tcid2, "Revamp_K10", "Tcid");
        
        while(Tcid1.equals(Tcid2) || al.get(2).equalsIgnoreCase(al2.get(2)))
        {
            Tcid2 = String.valueOf(randomNumber(1,noofRows-1));
            al2 = excelData.getData(Tcid2, "Revamp_K10", "Tcid");
        }
        
        if(CurrURL.contains("--byjusuat")) 
        {
            lo.LoginAsAdmin_UAT();
            
            // Creating a new student account with prog start less than 49 days from current date
            Accountid=payLoad_SinglePrgm_Revamp.AccountidCreationResponse_UAT_49(al.get(16),al.get(15),al.get(2),al.get(5),al.get(3),al.get(7),al.get(4));
        }
        else if (CurrURL.contains("--byjusfc")) {
            lo.LoginAsAdmin_UATFC();

         // Creating a new student account with prog start less than 49 days from current date
            Accountid=payLoad_SinglePrgm_Revamp.AccountidCreationResponse_UATFC_49(al.get(16),al.get(15),al.get(2),al.get(5),al.get(3),al.get(7),al.get(4));

        }

        staticVal = 2;
        System.out.println("al : "+al);
        System.out.println("al2 : "+al2);
        
        ac.closeTabWindows(2);    
        ac.Notification();
        
        prior_prog_Id = al;
        priProg_Det.put(al.get(8), al); // storing priority numb with the priority tc row
        
        String AccountURL=CurrURL+Accountid;
        ac.goTo(AccountURL);
        String accOwner = ac.CaptureAccOwnerNam();
        

        System.out.println("prior_prog1_Id :"+prior_prog_Id);
        
        ac.ClickStudentPrograms();
        
        //get the program name
        prognames = sp.getProgNames();
        progNamesList.add(prognames.get(0));
        String[] prgmData=sp.verifyIsPrimarychecked();
        log.info("Actual Primary Prog ID is :  "+prgmData[0]+"And expected is : "+prior_prog_Id.get(2));
        
        Assert.assertEquals(prgmData[0],prior_prog_Id.get(2),"1: Combination : "+Tcid1+" , expected "+prior_prog_Id.get(2)+" but found "+prgmData[0]);
        Assert.assertEquals(prgmData[1],prior_prog_Id.get(3),"1: Combination : "+Tcid1+" , expected "+prior_prog_Id.get(3)+" but found "+prgmData[1]);
        Assert.assertEquals(prgmData[2],prior_prog_Id.get(7),"1: Combination : "+Tcid1+" , expected "+prior_prog_Id.get(7)+" but found "+prgmData[2]);
        
        ac.CloseCurrentSubTab();
        ac.AdditionalWait();
        
        int noofTasks = 0;
        int totalTasks = 0; 
        prog_tasks.put(prior_prog_Id.get(0), 0);
        // Verifying the task journey
        if(excelData.searchColData("TestData", "Task_Journey", "Program Id", prior_prog_Id.get(2)))
        {
            noofTasks = verifyTaskJourney(prior_prog_Id,staticVal,accOwner,noofTasks);
            totalTasks = noofTasks;
            prog_tasks.put(prior_prog_Id.get(0), noofTasks);
        }
        
        String sel = ac.getSOSelection(al.get(16));

        //Adding a 2nd program in to an existing student account
        if(sel.equalsIgnoreCase("1"))
        {
            if(CurrURL.contains("--byjusuat")) {
                payLoad_PrgmwithSSO_Revamp.AccountidCreationResponse_UAT(Accountid,al2.get(2),al2.get(5),al2.get(3),al2.get(7),al2.get(4));

            }
            else if(CurrURL.contains("--byjusfc")) {
                payLoad_PrgmwithSSO_Revamp.AccountidCreationResponse_UATFC(Accountid,al2.get(2),al2.get(5),al2.get(3),al2.get(7),al2.get(4));

            }
        
        }
        else 
        {
            InsertNewProg(al2);
            ac.AdditionalWait();
        }
        
        priProg_Det.put(al2.get(8), al2);
        
        // Comparing the priorities of both the programs
        //high priority
        if(Integer.valueOf(al2.get(8)) < Integer.valueOf(al.get(8)))
        {
            prior_prog_Id = al2;
            sec_prog_Id = al;            
            if(sel.equalsIgnoreCase("1")) {
                staticVal = 1;
            }
            else {
                staticVal = 2;
            }
            totalTasks = 0;
        }
        //low priority
        else 
        {
            prior_prog_Id = al;
            sec_prog_Id = al2;            
            if(sec_prog_Id.get(9).equalsIgnoreCase("Yes")) {
                staticVal = 3;
            }
            else {
                staticVal = 4;
            }
        }
        
        System.out.println("prior_prog2_Id :"+prior_prog_Id);
        
        lo.RefreshURL();
        ac.AdditionalWait();
        
        ac.CloseSubTabs();
        ac.AdditionalWait();
        
        if(!prior_prog_Id.equals(al)) 
        {
            int exp_count = prog_tasks.get(al.get(0));
            ac.ClickActivityHistory_Scroll();
            int act_count = sp.statusCompletedCount(exp_count,"Cancelled");
            Assert.assertEquals(act_count,exp_count );
            ac.CloseCurrentSubTab();
            ac.AdditionalWait();
        }       
        
        accOwner = ac.CaptureAccOwnerNam();
        ac.ClickStudentPrograms();
       
       //get the program name
        prognames = sp.getProgNames();
        for(int j=0;j<prognames.size();j++)
        {
            if(!progNamesList.contains(prognames.get(j)))
            {
                progNamesList.add(prognames.get(j));
            }
        }
        //Returns the prog id, prod type and trial prog
        prgmData=sp.verifyIsPrimarychecked();
        log.info("Actual Primary Prog ID is :  "+prgmData[0]+"And expected is : "+prior_prog_Id.get(2));
        
        Assert.assertEquals(prgmData[0],prior_prog_Id.get(2),"2: Combination : "+Tcid1+"-"+Tcid2+" , expected "+prior_prog_Id.get(2)+" but found "+prgmData[0]);
        Assert.assertEquals(prgmData[1],prior_prog_Id.get(3),"2: Combination : "+Tcid1+"-"+Tcid2+" , expected "+prior_prog_Id.get(3)+" but found "+prgmData[1]);
        Assert.assertEquals(prgmData[2],prior_prog_Id.get(7),"2: Combination : "+Tcid1+"-"+Tcid2+" , expected "+prior_prog_Id.get(7)+" but found "+prgmData[2]);
        
        ac.CloseSubTabs();
        ac.AdditionalWait();
        ac.ClickStudentPrograms();
        prog_tasks.put(al2.get(0), 0);
        
        if(excelData.searchColData("TestData", "Task_Journey", "Program Id", al2.get(2)))
        {
            if(staticVal == 1 || staticVal == 2)
            {
                sp.goToprimaryProg();
                noofTasks = verifyTaskJourney(prior_prog_Id,staticVal,accOwner,prog_tasks.get(Tcid1));
                prog_tasks.put(prior_prog_Id.get(0), noofTasks);
            }
            
            else if(staticVal == 3 || staticVal == 4)
            {
                sp.goToNonprimaryProg();
                int tasks = prog_tasks.get(Tcid1);
                noofTasks = verifyTaskJourney(sec_prog_Id,staticVal,accOwner, noofTasks);
                prog_tasks.put(sec_prog_Id.get(0), noofTasks);
            }
           
            totalTasks = totalTasks+noofTasks;
            ac.CloseSubTabs();
        }
        
        int numb = 4;//randomNumber(1, 4);
        
        // change status
        if(numb == 1)
        {          

            ac.AdditionalWait();
            ac.ClickStudentPrograms();
            sp.goToprimaryProg();
            
            //change status to inactive
            sp.SelectStatus("Inactive");
            sp.ClickSave();
            ac.AdditionalWait();
           
            //sec prog becomes primary
            if(prior_prog_Id==al)
            {
              prior_prog_Id = al2;
              sec_prog_Id = al;
            }
            else
            {
                prior_prog_Id = al;
                sec_prog_Id = al2;
            }
             
             ac.CloseCurrentSubTab();
             ac.AdditionalWait();
             ac.RefreshTab();
             //Returns the prog id, prod type and trial prog
             prgmData=sp.verifyIsPrimarychecked();
             log.info("Actual Primary Prog ID is :  "+prgmData[0]+"And expected is : "+prior_prog_Id.get(2));
             
             Assert.assertEquals(prgmData[0],prior_prog_Id.get(2),"3: Combination : "+Tcid1+"-"+Tcid2+" , expected "+prior_prog_Id.get(2)+" but found "+prgmData[0]);
             Assert.assertEquals(prgmData[1],prior_prog_Id.get(3),"3: Combination : "+Tcid1+"-"+Tcid2+" , expected "+prior_prog_Id.get(3)+" but found "+prgmData[1]);
             Assert.assertEquals(prgmData[2],prior_prog_Id.get(7),"3: Combination : "+Tcid1+"-"+Tcid2+" , expected "+prior_prog_Id.get(7)+" but found "+prgmData[2]);
             
             ac.CloseSubTabs();
             ac.RefreshTab();
             ac.AdditionalWait();
             
             //added here
             accOwner = ac.CaptureAccOwnerNam();
                         
             if(!prior_prog_Id.equals(al)) {
                 staticVal = 2;
             }
             else {
                 staticVal = 1;
             }
             ac.ClickStudentPrograms();
             sp.goToprimaryProg();
             
             // verify cancelled open activties
             int exp_count = 0;
             ArrayList<String> Tcids=sp.getTcids("Task_Journey", prior_prog_Id.get(2));
             String tcid=sp.getTcid_TaskJour(Tcids, prior_prog_Id);
             al3 = excelData.getData(tcid, "Task_Journey", "Tcid");
             
             String p_tcid = prior_prog_Id.get(0);
             String se_tcid = sec_prog_Id.get(0);
             
             boolean check_1 = excelData.searchColData("TestData", "Task_Journey", "Program Id", al.get(2));
             boolean check_2 = excelData.searchColData("TestData", "Task_Journey", "Program Id", al2.get(2));
             
             if(!al3.isEmpty()) {
                 if(check_1 && check_2)
                 {
                     if(prior_prog_Id.equals(al)) {
                         exp_count = prog_tasks.get(p_tcid)+prog_tasks.get(se_tcid);
                     }
                     else {
                         if(staticVal == 1)
                         {
                             if(al3.get(13).equalsIgnoreCase(tcid_tasktypes.get(p_tcid)) ) {
                                 exp_count = prog_tasks.get(se_tcid);
                               }
                               else if(!al3.get(13).equalsIgnoreCase(tcid_tasktypes.get(p_tcid)) ) {
                                 exp_count = prog_tasks.get(p_tcid)+prog_tasks.get(se_tcid);
                               }
                         }
                         else if(staticVal == 2)
                         {
                             if(al3.get(16).equalsIgnoreCase(tcid_tasktypes.get(p_tcid)) ) {
                                 exp_count = prog_tasks.get(se_tcid);
                               }
                               else if(!al3.get(16).equalsIgnoreCase(tcid_tasktypes.get(p_tcid)) ) {
                                 exp_count = prog_tasks.get(p_tcid)+prog_tasks.get(se_tcid);
                               }
                         }
                     }
                    
                 }
                 else if(check_1)
                 {
                     exp_count = prog_tasks.get(al.get(0));
                 }
                 else if(check_2)
                 {
                     exp_count = prog_tasks.get(al2.get(0));
                 }
             }   
             else {
                 exp_count = prog_tasks.get(se_tcid);
             }
            
             ac.CloseSubTabs();
             ac.AdditionalWait();

             ac.ClickActivityHistory_Scroll();
             int noOfTasks = sp.statusCompletedCount(exp_count,"Cancelled");
             Assert.assertEquals(noOfTasks, exp_count);
             ac.CloseCurrentSubTab();
             ac.AdditionalWait();
             
             ac.ClickStudentPrograms();
             sp.goToprimaryProg();
             
             // Verifying the task journey
             if(excelData.searchColData("TestData", "Task_Journey", "Program Id", prior_prog_Id.get(2)) )
             {
                 //noofTasks = verifyTaskJourney(prior_prog_Id,staticVal,accOwner,prog_tasks.get(p_tcid));
                 if (staticVal == 1) {
                     if (tcid_tasktypes.keySet().contains(p_tcid))
                         if (!al3.get(13).equalsIgnoreCase(tcid_tasktypes.get(p_tcid))) {
                             noofTasks = verifyTaskJourney(prior_prog_Id,staticVal,accOwner,prog_tasks.get(p_tcid));
                         }
                 } else if (staticVal == 2) {
                     if (tcid_tasktypes.keySet().contains(p_tcid))
                         if (!al3.get(16).equalsIgnoreCase(tcid_tasktypes.get(p_tcid))) {
                             noofTasks = verifyTaskJourney(prior_prog_Id,staticVal,accOwner,prog_tasks.get(p_tcid));
                         }
                 }
             }
             
             ac.CloseSubTabs();
             ac.AdditionalWait();      
                  
        }
        
        // change student unit
        else if(numb == 2)
        {
            ac.CloseSubTabs();
            UpdateStuUnit(Accountid);
            ac.ClickStudentPrograms();
            
            //get the program name
            prognames = sp.getProgNames();
            for(int j=0;j<prognames.size();j++)
            {
                if(!progNamesList.contains(prognames.get(j)))
                {
                    progNamesList.add(prognames.get(j));
                }
            }
            
            System.out.println("progNamesList : "+progNamesList);
            
            String sheetName = "";
            if(al3.get(16).equalsIgnoreCase("7"))
                sheetName = "Revamp_K"+al3.get(16);
            else if(al3.get(16).equalsIgnoreCase("8") || al3.get(16).equalsIgnoreCase("9"))
                sheetName = "Revamp_K8-9";
            else
                sheetName = "Revamp_"+al3.get(13);
            
            //gets the combinations of all 3 programs with the new student unit
            sp.clickStuProgName(progNamesList.get(0));
            
            ArrayList<String> tcids = sp.getTcids(sheetName, al.get(2));
            if(tcids.size()>0)
                prog1 = sp.getProgComb(tcids, sheetName, al.get(2));
            if(prog1.isEmpty())
            {
                prog1 = sp.getCombination(al.get(13),al3.get(13), al);
                ac.CloseCurrentSubTab();
            }
            
            ac.AdditionalWait();
            ac.CloseCurrentSubTab();
            System.out.println("prog1 : "+prog1);
            
            sp.clickStuProgName(progNamesList.get(1));
            
            tcids = sp.getTcids(sheetName, al2.get(2));
            if(tcids.size()>0)
                prog2 = sp.getProgComb(tcids, sheetName, al2.get(2));
            if(prog2.isEmpty())
            {
                prog2 = sp.getCombination(al2.get(13),al3.get(13), al2);
                ac.CloseCurrentSubTab();
            }
                
            ac.AdditionalWait();
            ac.CloseCurrentSubTab();
            System.out.println("prog2 : "+prog2);
            
            sp.clickStuProgName(progNamesList.get(2));
            
            tcids = sp.getTcids(sheetName, al3.get(2));
            if(tcids.size()>0)
                prog3 = sp.getProgComb(tcids, sheetName, al3.get(2));
            if(prog3.isEmpty())
            {
                prog3 = sp.getCombination(al3.get(13),al3.get(13), al3);
                ac.CloseCurrentSubTab();
            }
            
            ac.AdditionalWait();
            ac.CloseSubTabs();
            System.out.println("prog3 : "+prog3);
                    
            boolean check = false;
            
            //If prog1 is sec, check if prog1 exist in new student unit 
            if(prog1.contains(sec_prog_Id.get(2)))
            {
                check = excelData.searchColData("TestData", "Revamp_Combinations", "Id", prog1);
            }
            //Else if prog1 is sec, check if prog1 exist in new student unit 
            else if(prog2.contains(sec_prog_Id.get(2)))
            {
                check = excelData.searchColData("TestData", "Revamp_Combinations", "Id", prog2);
            }
                                
            prior_prog_Id = excelData.getData(sp.getPrimaryProgTcid(prog1, prog2, prog3, al3.get(16)), sheetName, "Tcid");
            System.out.println("prior_prog3_Id :"+prior_prog_Id);
            
            //added here
            accOwner = ac.CaptureAccOwnerNam();

            ac.ClickStudentPrograms();
            sp.clickStuProgName(progNamesList.get(2));
            
            // Verifying the task journey of new program
            
            if(excelData.searchColData("TestData", "Task_Journey", "Program Id", al3.get(2)))
            {
                if(al3.get(0).equalsIgnoreCase(prior_prog_Id.get(0)))
                {
                   // staticVal = 1; // '2 - 6
                    if(!prior_prog_Id.equals(al)) {
                        staticVal = 2;
                    }
                    else {
                        staticVal = 1;
                    }
                    int totaltasks = prog_tasks.get(Tcid1)+ prog_tasks.get(Tcid2);
                    if(prog_tasks.keySet().contains(sec_prog_Id.get(0)) && check) {
                        flag = 1;
                    }
                    noofTasks = verifyTaskJourney(prior_prog_Id,staticVal,accOwner,totaltasks);
                }    
                else
                {
                    if(al3.get(9).equalsIgnoreCase("Yes"))
                        staticVal = 3;
                    else 
                        staticVal = 4;
                    
                        noofTasks = verifyTaskJourney(al3,staticVal,accOwner,totalTasks);
                }
            }
            else
            {
                int totaltasks = prog_tasks.get(Tcid1)+ prog_tasks.get(Tcid2);
                ac.ClickActivityHistory_Scroll();
                int noOfTasks = sp.statusCompletedCount(totaltasks,"Cancelled");
                Assert.assertEquals(noOfTasks, totaltasks);
                ac.CloseCurrentSubTab();
                ac.AdditionalWait();
                
            }
        }
        
        // change trial program
        else if(numb == 3)
        {
           // if(!(prior_prog_Id.get(2).equalsIgnoreCase("BCOPKXSY0002") && ((prior_prog_Id.get(3).equalsIgnoreCase("Free") && prior_prog_Id.get(5).equalsIgnoreCase("Monthly")) || prior_prog_Id.get(4).equalsIgnoreCase("Toppr")))) 
            //{ }

            ac.ClickStudentPrograms();
            sp.goToprimaryProg();
            
            if(prior_prog_Id.get(7).equalsIgnoreCase("No"))
                updatetrialProg("Yes");
            else
                updatetrialProg("No");                  
            
            ac.AdditionalWait();
          
            System.out.println("prior_prog4_Id : "+prior_prog_Id);
            
            ac.CloseCurrentSubTab();
            ac.AdditionalWait();
            ac.RefreshTab();
            //Returns the prog id, prod type and trial prog
            prgmData=sp.verifyIsPrimarychecked();
            log.info("Actual Primary Prog ID is :  "+prgmData[0]+"And expected is : "+prior_prog_Id.get(2));
            
            Assert.assertEquals(prgmData[0],prior_prog_Id.get(2),"3: Combination : "+Tcid1+"-"+Tcid2+" , expected "+prior_prog_Id.get(2)+" but found "+prgmData[0]);
            Assert.assertEquals(prgmData[1],prior_prog_Id.get(3),"3: Combination : "+Tcid1+"-"+Tcid2+" , expected "+prior_prog_Id.get(3)+" but found "+prgmData[1]);
            Assert.assertEquals(prgmData[2],prior_prog_Id.get(7),"3: Combination : "+Tcid1+"-"+Tcid2+" , expected "+prior_prog_Id.get(7)+" but found "+prgmData[2]);
            
            ac.CloseSubTabs();
            ac.RefreshTab();
            ac.AdditionalWait();
            
            //added here
            accOwner = ac.CaptureAccOwnerNam();

            if(prior_prog_Id.equals(al))
            {
                staticVal = 2;
            }
            else
            {
                if(sel.equalsIgnoreCase("1"))
                {
                    staticVal = 1;
                }
                else 
                {
                    staticVal = 2;
                }
            }
            
            ac.ClickStudentPrograms();
            sp.goToprimaryProg();
            
            // verify cancelled open activties
            int exp_count = 0;
            ArrayList<String> Tcids=sp.getTcids("Task_Journey", prior_prog_Id.get(2));
            String tcid=sp.getTcid_TaskJour(Tcids, prior_prog_Id);
            al3 = excelData.getData(tcid, "Task_Journey", "Tcid");
            
            String p_tcid = prior_prog_Id.get(0);
            String se_tcid = sec_prog_Id.get(0);
            
            boolean check_1 = excelData.searchColData("TestData", "Task_Journey", "Program Id", al.get(2));
            boolean check_2 = excelData.searchColData("TestData", "Task_Journey", "Program Id", al2.get(2));
            
            if(!al3.isEmpty()) {
                if(check_1 && check_2)
                {
                    if(prior_prog_Id.equals(al)) {
                        exp_count = prog_tasks.get(p_tcid)+prog_tasks.get(se_tcid);
                    }
                    else {
                        if(staticVal == 1)
                        {
                            if(al3.get(13).equalsIgnoreCase(tcid_tasktypes.get(p_tcid)) ) {
                                exp_count = prog_tasks.get(se_tcid);
                              }
                              else if(!al3.get(13).equalsIgnoreCase(tcid_tasktypes.get(p_tcid)) ) {
                                exp_count = prog_tasks.get(p_tcid)+prog_tasks.get(se_tcid);
                              }
                        }
                        else if(staticVal == 2)
                        {
                            if(al3.get(16).equalsIgnoreCase(tcid_tasktypes.get(p_tcid)) ) {
                                exp_count = prog_tasks.get(se_tcid);
                              }
                              else if(!al3.get(16).equalsIgnoreCase(tcid_tasktypes.get(p_tcid)) ) {
                                exp_count = prog_tasks.get(p_tcid)+prog_tasks.get(se_tcid);
                              }
                        }
                    }
                   
                }
                else if(check_1)
                {
                    exp_count = prog_tasks.get(al.get(0));
                }
                else if(check_2)
                {
                    exp_count = prog_tasks.get(al2.get(0));
                }
            }   
            else {
                exp_count = prog_tasks.get(se_tcid);
            }
           
            ac.CloseSubTabs();
            ac.AdditionalWait();

            ac.ClickActivityHistory_Scroll();
            int noOfTasks = sp.statusCompletedCount(exp_count,"Cancelled");
            Assert.assertEquals(noOfTasks, exp_count);
            ac.CloseCurrentSubTab();
            ac.AdditionalWait();
            
            ac.ClickStudentPrograms();
            sp.goToprimaryProg();
            
            // Verifying the task journey
            if (excelData.searchColData("TestData", "Task_Journey", "Program Id", prior_prog_Id.get(2))) {
                // noofTasks =
                // verifyTaskJourney(prior_prog_Id,staticVal,accOwner,prog_tasks.get(p_tcid));
                if (staticVal == 1) {
                    if (tcid_tasktypes.keySet().contains(p_tcid))
                        if (!al3.get(13).equalsIgnoreCase(tcid_tasktypes.get(p_tcid))) {
                            noofTasks = verifyTaskJourney(prior_prog_Id, staticVal, accOwner, prog_tasks.get(p_tcid));
                        }
                } else if (staticVal == 2) {
                    if (tcid_tasktypes.keySet().contains(p_tcid))
                        if (!al3.get(16).equalsIgnoreCase(tcid_tasktypes.get(p_tcid))) {
                            noofTasks = verifyTaskJourney(prior_prog_Id, staticVal, accOwner, prog_tasks.get(p_tcid));
                        }
                }
            }
            
            ac.CloseSubTabs();
            ac.AdditionalWait();      
        
        }
        
        //change product type, program type, duration
        else 
        {
            ac.ClickStudentPrograms();
            sp.goToNonprimaryProg();
            prog1 = sp.getCombination(sec_prog_Id.get(13),al.get(13),sec_prog_Id);
            al3 = excelData.getData(prog1, "Revamp_Combinations", "Id");
            System.out.println("prog1 : "+prog1);
            
            ac.CloseCurrentSubTab();
            ac.CloseCurrentSubTab();
            ac.AdditionalWait();
            
            sp.goToprimaryProg();
            //changing class/program type , duration , product type , Trial program in primary program
            updateProgTyDurtnProdTyTrProg();
            
            //getting the details of the primary program in string separated by '-'
            prog2 = sp.getCombination(prior_prog_Id.get(13),al.get(13),prior_prog_Id);
            al4 = excelData.getData(prog2, "Revamp_Combinations", "Id");
            System.out.println("prog2 : "+prog2);
            
            //Changing the primary program based on the new data
            
            //prog2 is in excel - compare priorities
            if(excelData.searchColData("TestData", "Revamp_Combinations", "Id", prog1) && excelData.searchColData("TestData", "Revamp_Combinations", "Id", prog2) )
            {
                if(Integer.valueOf(al3.get(1)) < Integer.valueOf(al4.get(1)))
                {
                   prior_prog_Id = excelData.getData(al3.get(3), "Revamp_K10", "Tcid");
                }
                else
                    prior_prog_Id = excelData.getData(al4.get(3), "Revamp_K10", "Tcid");
            }
            //prog2(primary program) is not in excel - prog1(secondary program) is primary
            else
                prior_prog_Id = excelData.getData(al3.get(3), "Revamp_K10", "Tcid");
            
            System.out.println("prior_prog6_Id : "+prior_prog_Id);
            
            if( prior_prog_Id.equals(al))
            {            
              sec_prog_Id = al2;
            }
            else
            {                
              sec_prog_Id= al;             
            }
            
            ac.CloseCurrentSubTab();
            ac.CloseCurrentSubTab();
            ac.AdditionalWait();
            
            //Returns the prog id, prod type and trial prog
            prgmData=sp.verifyIsPrimarychecked();
            log.info("Actual Primary Prog ID is :  "+prgmData[0]+"And expected is : "+prior_prog_Id.get(2));

            Assert.assertEquals(prgmData[0],prior_prog_Id.get(2),"5: Combination : "+Tcid1+"-"+Tcid2+" , expected "+prior_prog_Id.get(2)+" but found "+prgmData[0]);
           // a.assertEquals(prgmData[1],prior_prog_Id.get(3),"Combination : "+T1+"-"+i+" , expected "+prior_prog_Id.get(3)+" but found "+prgmData[1]);
            Assert.assertEquals(prgmData[2],prior_prog_Id.get(7),"5: Combination : "+Tcid1+"-"+Tcid2+" , expected "+prior_prog_Id.get(7)+" but found "+prgmData[2]);
            
            //Closing the sub tabs
            ac.CloseSubTabs();
            ac.RefreshTab();
            ac.AdditionalWait();
                       
            //added here
            accOwner = ac.CaptureAccOwnerNam();           
            
            ac.ClickStudentPrograms();
            sp.goToprimaryProg();
            
            if(prior_prog_Id.equals(al))
            {
                staticVal = 2;
            }
            else {
            if(sel.equalsIgnoreCase("1"))
            {
              staticVal = 1;
            }
            else
            {
                staticVal = 2;
            } 
            }
                        
            int exp_count = 0;
            ArrayList<String> Tcids=sp.getTcids("Task_Journey", prior_prog_Id.get(2));
            String tcid=sp.getTcid_TaskJour(Tcids, prior_prog_Id);
            al3 = excelData.getData(tcid, "Task_Journey", "Tcid");

            String p_tcid = prior_prog_Id.get(0);
            String se_tcid = sec_prog_Id.get(0);
            
            boolean check_1 = excelData.searchColData("TestData", "Task_Journey", "Program Id", al.get(2));
            boolean check_2 = excelData.searchColData("TestData", "Task_Journey", "Program Id", al2.get(2));
           
            if(!al3.isEmpty()) {
                if(check_1 && check_2)
                {
                    if(prior_prog_Id.equals(al)) {
                        exp_count = prog_tasks.get(p_tcid)+prog_tasks.get(se_tcid);
                    }
                    else {
                        if(staticVal == 1)
                        {
                            if(al3.get(13).equalsIgnoreCase(tcid_tasktypes.get(p_tcid)) ) {
                                exp_count = prog_tasks.get(se_tcid);
                              }
                              else if(!al3.get(13).equalsIgnoreCase(tcid_tasktypes.get(p_tcid)) ) {
                                exp_count = prog_tasks.get(p_tcid)+prog_tasks.get(se_tcid);
                              }
                        }
                        else if(staticVal == 2)
                        {
                            if(al3.get(16).equalsIgnoreCase(tcid_tasktypes.get(p_tcid)) ) {
                                exp_count = prog_tasks.get(se_tcid);
                              }
                              else if(!al3.get(16).equalsIgnoreCase(tcid_tasktypes.get(p_tcid)) ) {
                                exp_count = prog_tasks.get(p_tcid)+prog_tasks.get(se_tcid);
                              }
                        }
                    }
                   
                }
                else if(check_1)
                {
                    exp_count = prog_tasks.get(al.get(0));
                }
                else if(check_2)
                {
                    exp_count = prog_tasks.get(al2.get(0));
                }
            }
            else {
                exp_count = prog_tasks.get(se_tcid);
            }
            
            ac.CloseSubTabs();
            ac.ClickActivityHistory_Scroll();
            int act_count = sp.statusCompletedCount(exp_count,"Cancelled");
            Assert.assertEquals(act_count, exp_count);
            ac.CloseCurrentSubTab();
            
            ac.ClickStudentPrograms();
            sp.goToprimaryProg();
            
            // Verifying the task journey
            if (excelData.searchColData("TestData", "Task_Journey", "Program Id", prior_prog_Id.get(2))) {
                // noofTasks =
                // verifyTaskJourney(prior_prog_Id,staticVal,accOwner,prog_tasks.get(p_tcid));
                if (staticVal == 1) {
                    if (tcid_tasktypes.keySet().contains(p_tcid))
                        if (!al3.get(13).equalsIgnoreCase(tcid_tasktypes.get(p_tcid))) {
                            noofTasks = verifyTaskJourney(prior_prog_Id, staticVal, accOwner, prog_tasks.get(p_tcid));
                        }
                } else if (staticVal == 2) {
                    if (tcid_tasktypes.keySet().contains(p_tcid))
                        if (!al3.get(16).equalsIgnoreCase(tcid_tasktypes.get(p_tcid))) {
                            noofTasks = verifyTaskJourney(prior_prog_Id, staticVal, accOwner, prog_tasks.get(p_tcid));
                        }
                }
            }
        }
         
        ac.CloseSubTabs();
        ac.AdditionalWait();
              
        ac.DeleteAllCreatedStuProg();
        ac.NavBackToAccount();
       
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());    
        
    
    }
    
    //Inserting 2 programs at a time
    //4655 - 2,7,9,10 - status , class/program type , duration , product type
     @Test(groups = { "Regression" ,"sanity"}, enabled = true)
     public void Revamp_K10_PR2() throws Exception {
         //String T1,String T2,String T3,String T4,String T5,String T6,String T7,String T8,String T9,String T10,String T11,String T12,String T13,String T14,String T15,String T16,String T17,String T18,String T19,String T20,String T21
         loginPO lo=new loginPO(driver);
         CreatedAccountPO ac=new CreatedAccountPO(driver);
         StudentProgPO sp = new StudentProgPO(driver);
         SoftAssert a=new SoftAssert();
         
         String Accountid = "";
         
         int noofRows = getRowCount("src//main//java//testData//TestData.xlsx", "Revamp_K10");
       
         String T1 = "15";
         int i = randomNumber(1,noofRows-1);
         
         al = excelData.getData(T1, "Revamp_K10", "Tcid");
         al2 = excelData.getData(String.valueOf(i), "Revamp_K10", "Tcid");
         String prog2Id = al2.get(2);
         while(String.valueOf(i).equalsIgnoreCase(T1) || al.get(2).equalsIgnoreCase(prog2Id)){
             i = randomNumber(1,noofRows-1);
         }
         //for(int i=Integer.valueOf(T1)+1;i<noofRows;i++) 
        // {
             if(CurrURL.contains("--byjusuat")) 
             {
                 al = excelData.getData(T1, "Revamp_K10", "Tcid");
                 al2 = excelData.getData(String.valueOf(i), "Revamp_K10", "Tcid");               
                 lo.LoginAsAdmin_UAT();                                                           //classNo,  Mentlang,  Progid1 ,Duration1,ProdType1,TrialProg1,ProgType1, Progid2,  Duration2,  ProdType2,TrialProg2, ProgType2
                 Accountid=payLoad_TwoPrgms_Revamp.AccountidCreationResponse_UAT(al.get(16),al.get(15),al.get(2), al.get(5),al.get(3),al.get(7),al.get(4),al2.get(2), al2.get(5),al2.get(3),al2.get(7),al2.get(4));
             }
             else if(CurrURL.contains("--byjusfc")) {
                 al = excelData.getData(T1, "Revamp_K4-6", "Tcid");
                 al2 = excelData.getData(String.valueOf(i), "Revamp_K4-6", "Tcid");
                 lo.LoginAsAdmin_UATFC();
                 Accountid=payLoad_TwoPrgms_Revamp.AccountidCreationResponse_UATFC(al.get(16),al.get(15),al.get(2), al.get(5),al.get(3),al.get(7),al.get(4),al2.get(2), al2.get(5),al2.get(3),al2.get(7),al2.get(4));
             }
             
             ac.closeTabWindows(2);    
             ac.Notification();
             
             //Displaying the selected combination
             System.out.println(T1+" "+i);
             
             System.out.println("al : "+al);
             System.out.println("al2 : "+al2);

             //Comparing the priorities of both the programs
             if(Integer.valueOf(al2.get(8)) < Integer.valueOf(al.get(8)))
             {
               prior_prog_Id = al2;
               sec_prog_Id = al;
             }
             else
             {
                 prior_prog_Id = al;
                 sec_prog_Id = al2;
             }
             
             System.out.println("prior_prog1_Id : "+prior_prog_Id);
             
             String AccountURL=CurrURL+Accountid;
             ac.goTo(AccountURL);
             ac.AdditionalWait();
             ac.ClickStudentPrograms();
             ac.AdditionalWait();             //Returns the prog id, prod type and trial prog
             String[] prgmData=sp.verifyIsPrimarychecked();
             log.info("Actual Primary Prog ID is :  "+prgmData[0]+"And expected is : "+prior_prog_Id.get(2));

             a.assertEquals(prgmData[0],prior_prog_Id.get(2),"1: Combination : "+T1+"-"+i+" , expected "+prior_prog_Id.get(2)+" but found "+prgmData[0]);
             a.assertEquals(prgmData[1],prior_prog_Id.get(3),"1: Combination : "+T1+"-"+i+" , expected "+prior_prog_Id.get(3)+" but found "+prgmData[1]);
             a.assertEquals(prgmData[2],prior_prog_Id.get(7),"1: Combination : "+T1+"-"+i+" , expected "+prior_prog_Id.get(7)+" but found "+prgmData[2]);
             ac.AdditionalWait();
             ac.CloseCurrentSubTab();
             
             System.out.println("before inactive-prior_prog_Id :"+prior_prog_Id);
             System.out.println("before inactive-sec_prog_Id :"+sec_prog_Id);
             
             //******************** SFDC-4655-2 ***********************// - changing status
             //change status to inactive
             ac.AdditionalWait();
             sp.SelectStatus("Inactive");
             sp.ClickSave();
             ac.AccountLoadwait();         
             ac.CloseCurrentSubTab();           
             
             //sec prog becomes primary
             if(prior_prog_Id==al)
             {
               prior_prog_Id = al2;
               sec_prog_Id = al;
             }
             else
             {
                 prior_prog_Id = al;
                 sec_prog_Id = al2;
             }
             System.out.println("after inactive-prior_prog_Id :"+prior_prog_Id);
             System.out.println("after inactive-sec_prog_Id :"+sec_prog_Id);
             ac.AdditionalWait();
             prgmData=sp.verifyIsPrimarychecked();
             log.info("Actual Primary Prog ID is :  "+prgmData[0]+"And expected is : "+prior_prog_Id.get(2));
             
             a.assertEquals(prgmData[0],prior_prog_Id.get(2),"2: Combination : "+T1+"-"+i+" , expected "+prior_prog_Id.get(2)+" but found "+prgmData[0]);
             a.assertEquals(prgmData[1],prior_prog_Id.get(3),"2: Combination : "+T1+"-"+i+" , expected "+prior_prog_Id.get(3)+" but found "+prgmData[1]);
             a.assertEquals(prgmData[2],prior_prog_Id.get(7),"2: Combination : "+T1+"-"+i+" , expected "+prior_prog_Id.get(7)+" but found "+prgmData[2]);
             
             ac.CloseCurrentSubTab(); 
             ac.CloseCurrentSubTab(); 
             ac.AdditionalWait();
             sp.goToNonprimaryProg(); // navigating to first primary program and changing status back to active
             
             //change status to active
             sp.SelectStatus("Active");
             sp.ClickSave();
             ac.AccountLoadwait();
             ac.CloseCurrentSubTab();
             
             al3 = prior_prog_Id;
             prior_prog_Id = sec_prog_Id;
             sec_prog_Id = al3;
             
             System.out.println("after active-prior_prog_Id :"+prior_prog_Id);
             System.out.println("after active-sec_prog_Id :"+sec_prog_Id);
    
             prgmData = sp.verifyIsPrimarychecked();
             log.info("Actual Primary Prog ID is :  "+prgmData[0]+"And expected is : "+prior_prog_Id.get(2));
      
             a.assertEquals(prgmData[0],prior_prog_Id.get(2),"3: Combination : "+T1+"-"+i+" , expected "+prior_prog_Id.get(2)+" but found "+prgmData[0]);
             a.assertEquals(prgmData[1],prior_prog_Id.get(3),"3: Combination : "+T1+"-"+i+" , expected "+prior_prog_Id.get(3)+" but found "+prgmData[1]);
             a.assertEquals(prgmData[2],prior_prog_Id.get(7),"3: Combination : "+T1+"-"+i+" , expected "+prior_prog_Id.get(7)+" but found "+prgmData[2]);
             
             ac.CloseCurrentSubTab();
             ac.CloseCurrentSubTab();
             ac.AdditionalWait();
             
             //******************** SFDC-4655-7,9,10 -  ***********************// - changing class/program type , duration , product type in secondary program
             
             //Change the data of secondary program if it is neo classes and if primary program is not BHT or Aakash neo classes
              if(sec_prog_Id.get(2).equalsIgnoreCase("BCOPKXSY0002") && (!prior_prog_Id.get(2).equalsIgnoreCase("BYHTKXSY0001") && !prior_prog_Id.get(2).equalsIgnoreCase("ACOPKXSY0003") && !prior_prog_Id.get(2).equalsIgnoreCase("BCOPKXSY0002")))
              {
                 sp.goToNonprimaryProg();
                 
                 String expComb = sp.getCombination(sec_prog_Id.get(13),sec_prog_Id.get(13), sec_prog_Id);
                 System.out.println("expComb_sec : "+expComb);
                 
                 al3 = excelData.getData(expComb, "Revamp_Combinations", "Id");
                 al4 = excelData.getData(al3.get(2), "Revamp_K10", "Tcid");
                 ac.CloseCurrentSubTab();
                 ac.AdditionalWait();
                 sp.SelectProductType(al4.get(3));
                 ac.AdditionalWait();
                 sp.SelectClass_ProgramType(al4.get(4));
                 ac.AdditionalWait();
                 sp.SelectDuration(al4.get(5));
                 sp.ClickSave();
                 ac.AdditionalWait();
                 
                 ac.AdditionalWait();
                 sp.SelectTrialProg(al4.get(7));
                 sp.ClickSave();
                 ac.AccountLoadwait();
                 //Comparing the priorities of both the programs
                 
                 if(Integer.parseInt(prior_prog_Id.get(8)) < Integer.parseInt(al4.get(8)))
                 {
                  sec_prog_Id = al4;
                 }
                 else
                 {
                   sec_prog_Id = prior_prog_Id;
                   prior_prog_Id = al4;
                 }
                
                 //ac.CloseSubTabs();
                 ac.CloseCurrentSubTab();
                 System.out.println("prior_prog2_Id : "+prior_prog_Id);
                 ac.AdditionalWait();
                 
                 //Returns the prog id, prod type and trial prog
                 prgmData=sp.verifyIsPrimarychecked();
                 log.info("Actual Primary Prog ID is :  "+prgmData[0]+"And expected is : "+prior_prog_Id.get(2));
                 a.assertEquals(prgmData[0],prior_prog_Id.get(2),"4: Combination : "+T1+"-"+i+" , expected "+prior_prog_Id.get(2)+" but found "+prgmData[0]);
                 a.assertEquals(prgmData[1],prior_prog_Id.get(3),"4: Combination : "+T1+"-"+i+" , expected "+prior_prog_Id.get(3)+" but found "+prgmData[1]);
                 a.assertEquals(prgmData[2],prior_prog_Id.get(7),"4: Combination : "+T1+"-"+i+" , expected "+prior_prog_Id.get(7)+" but found "+prgmData[2]);                 
                 
                 //Closing the sub tabs
                 ac.CloseCurrentSubTab();
                 ac.CloseCurrentSubTab();
                 ac.AdditionalWait();
             }

             //******************** SFDC-4655-7,9,10 -  ***********************// - changing class/program type , duration , product type in primary program
             
             //getting the details of non primary program in string separated by '-'
             sp.goToNonprimaryProg();
             String prog1="";
             prog1 = sp.getCombination(sec_prog_Id.get(13),al.get(13),sec_prog_Id);
             al3 = excelData.getData(prog1, "Revamp_Combinations", "Id");
             System.out.println("prog1 : "+prog1);
             
             ac.CloseCurrentSubTab();
             ac.CloseCurrentSubTab();
             ac.AdditionalWait();
             
             //changing the primary program details              
             sp.goToprimaryProg();
             
             updateProgTyDurtnProdTyTrProg();
             
             //getting the details of the primary program in string separated by '-'
             String prog2 = sp.getCombination(prior_prog_Id.get(13),al.get(13),prior_prog_Id);
             al4 = excelData.getData(prog2, "Revamp_Combinations", "Id");
             System.out.println("prog2 : "+prog2);
             
             //Changing the primary program based on the new data
             
             //prog2 is in excel - compare priorities
             if(excelData.searchColData("TestData", "Revamp_Combinations", "Id", prog1) && excelData.searchColData("TestData", "Revamp_Combinations", "Id", prog2) )
             {
                 if(Integer.valueOf(al3.get(1)) < Integer.valueOf(al4.get(1)))
                 {
                    prior_prog_Id = excelData.getData(al3.get(3), "Revamp_K10", "Tcid");
                 }
                 else
                     prior_prog_Id = excelData.getData(al4.get(3), "Revamp_K10", "Tcid");
             }
             //prog2(primary program) is not in excel - prog1(secondary program) is primary
             else
                 prior_prog_Id = excelData.getData(al3.get(3), "Revamp_K10", "Tcid"); //here 1 3
             
             System.out.println("prior_prog2_Id : "+prior_prog_Id);
             
             ac.CloseCurrentSubTab();
             ac.CloseCurrentSubTab();
             ac.AdditionalWait();
             
             //Returns the prog id, prod type and trial prog
             prgmData=sp.verifyIsPrimarychecked();
             log.info("Actual Primary Prog ID is :  "+prgmData[0]+"And expected is : "+prior_prog_Id.get(2));
             
             a.assertEquals(prgmData[0],prior_prog_Id.get(2),"5: Combination : "+T1+"-"+i+" , expected "+prior_prog_Id.get(2)+" but found "+prgmData[0]);
             //a.assertEquals(prgmData[1],prior_prog_Id.get(3),"Combination : "+T1+"-"+i+" , expected "+prior_prog_Id.get(3)+" but found "+prgmData[1]);
             a.assertEquals(prgmData[2],prior_prog_Id.get(7),"5: Combination : "+T1+"-"+i+" , expected "+prior_prog_Id.get(7)+" but found "+prgmData[2]);
              
             //Closing the sub tabs
             ac.CloseSubTabs();
             ac.AdditionalWait();
             
             //log.info("Deleting the Student Program details");
             ac.DeleteCreatedStuProg();
             
             //log.info("Deleting the Student Payment details");
             ac.DeleteAllCreatedStuPayment();
             
             ac.NavBackToAccount();
             //log.info("Deleting the Account created details");
             ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
             
             System.out.println(T1+" "+i);
         //}
         a.assertAll();
     }
     
     public void checkAssignmentRule(ArrayList<String> al,String expectedQueue,String ruleCat,String Accountid,String lang) throws InterruptedException
     {
         CreatedAccountPO ac=new CreatedAccountPO(driver);
         DevConsolePO dc = new DevConsolePO(driver);
         AssignmentRulesRefundRequestPO ar = new AssignmentRulesRefundRequestPO(driver);
         
         String wh = driver.getWindowHandle();
         String accOwner = ac.CaptureAccOwnerNam();
         String progId=al.get(2);        
         
         
         if(expectedQueue.equalsIgnoreCase("Admin_Missing_rule")) {
             progId = "";
             ruleCat = expectedQueue;
         }
         
         //if trial program for assignment rule is NA 
           if(al.get(17).equalsIgnoreCase("NA"))
           {
               //Opening dev console
               if(CurrURL.contains("--byjusuat")) {
                   dc.GetDevConsole("UAT");
               }
               else if(CurrURL.contains("--byjusfc")) {
                   dc.GetDevConsole("UATFC");
               }
               dc.closeconsoleTabs();
               dc.ExecuteQuery1(Queries.getGrpIdProdTy(al.get(3), expectedQueue, progId,ruleCat));
           }
           else
           {
               if(CurrURL.contains("--byjusuat")) {
                   dc.GetDevConsole("UAT");
               }
               else if(CurrURL.contains("--byjusfc")) {
                   dc.GetDevConsole("UATFC");
               }
               dc.closeconsoleTabs();
               dc.ExecuteQuery1(Queries.getGrpIdTrPg(al.get(17), expectedQueue, progId,ruleCat));
           }
             
         String grpId_exp = "";
         
         if(al.get(2).equalsIgnoreCase("AFNCKXSY0001") || al.get(2).equalsIgnoreCase("BAFLKXAS0001") || al.get(2).equalsIgnoreCase("BDLCKXAS0001")|| al.get(13).equalsIgnoreCase("K3") || expectedQueue.equalsIgnoreCase("Admin_Missing_rule"))
         {
             grpId_exp = dc.getId(); 
         }
         else
             grpId_exp = dc.getAssgnEntryId();
         
         ac.AdditionalWait();
        
         //executing 1st query to get group Id from query editor
         dc.closeconsoleTabs();
         dc.ExecuteQuery1(Queries.GetGrpId(Accountid));
         String grpId = dc.getId();
         System.out.println("grpId :"+grpId);
         ac.AdditionalWait();
         
         //verifying if group id from expected queue and account are same
         Assert.assertEquals(grpId, grpId_exp);
         
         // executing 2nd query to get assignment rule Id from query editor
         dc.closeconsoleTabs();
         //if trial program for assignment rule is NA 
      // if trial program for assignment rule is NA
         if (al.get(17).equalsIgnoreCase("NA")) {
             dc.ExecuteQuery1(Queries.GetAssgnIdProdTy(al.get(3), grpId, progId, ruleCat, expectedQueue));
         } else {
             dc.ExecuteQuery1(Queries.GetAssgnIdTrpg(al.get(17), grpId, progId, ruleCat, expectedQueue));
         }  
         
         String assgnId = "";
         
         if(al.get(2).equalsIgnoreCase("AFNCKXSY0001") || al.get(2).equalsIgnoreCase("BAFLKXAS0001") || al.get(2).equalsIgnoreCase("BDLCKXAS0001")|| al.get(13).equalsIgnoreCase("K3") || expectedQueue.equalsIgnoreCase("Admin_Missing_rule"))
         {
             assgnId = dc.getId(); 
         }
         else
             assgnId = dc.getAssgnEntryId();
         
         System.out.println("assgnId :"+assgnId);
         
         ac.AdditionalWait();
         dc.CloseWindowArrayLast();
         
         ac.AdditionalWait();
         driver.switchTo().window(wh);
         ac.AdditionalWait();
         
         if(CurrURL.contains("--byjusuat")) {
             ac.goTo("https://byjusprod--byjusuat.lightning.force.com/lightning/r/Assignment_Rule__c/"+assgnId+"/view");
         }
         else if(CurrURL.contains("--byjusfc")) {
             ac.goTo("https://byjusprod--byjusfc.sandbox.lightning.force.com/lightning/r/Assignment_Rule__c/" + assgnId + "/view");
         }
         
         ac.AccountLoadwait();
         ac.AdditionalWait();
         String QueueName = ar.getAssgnRuleDetails("Assignment Rule Name");
         
         System.out.println("QueueName :"+QueueName);
         
        //verifies if the expected queue and the actual queue are same
         Assert.assertEquals(QueueName, expectedQueue);
         
         //if it is ACRP , rule category is PE and assgn rule is not specific to lang, only one rule is there
         if(!QueueName.equalsIgnoreCase("Admin_Missing_rule")) {
             
             if(al.get(2).equalsIgnoreCase("ACRPKXSY0001"))
             {
                 Assert.assertEquals(ar.getAssgnRuleDetails("Rule Category"), ruleCat);
             }
             else
             {
                 Assert.assertEquals(ar.getAssgnRuleDetails("Rule Category"), ruleCat);
                 if(!QueueName.contains("Neo A & Q"))
                 Assert.assertEquals(ar.getAssgnRuleDetails("Mentoring Language"), lang);
             }
             Assert.assertEquals(ar.getAssgnRuleDetails("Region"), al.get(11));
             Assert.assertEquals(ar.getAssgnRuleDetails("Primary Program Id"), al.get(2));
             Assert.assertEquals(ar.getAssgnRuleDetails("Student Unit"), al.get(13));
         }   
         
         ar.NavtoGroup(QueueName);
         ac.AccountLoadwait();
         ar.navToGrpMem();
         Assert.assertTrue(ar.VerifyCaseOwner(accOwner));
         ac.closeCurrentTabWindow();
     }
     
     public void InsertNewProg(ArrayList<String> al) throws Exception {

         StudentProgPO sp = new StudentProgPO(driver);
         CreatedAccountPO ac=new CreatedAccountPO(driver);
         
         try {
             ac.clickProgName();
         }
         catch(Throwable e) {
             Thread.sleep(2000);
             ac.AccountLoadwait();
             ac.clickProgName();
         }
         
         ac.AccountLoadwait();
         ac.AccountLoadwait();
         ac.AdditionalWait();
         sp.selectClone();
         ac.AdditionalWait();
         
         sp.clearData("Student Program Name");
         sp.EnterStudentProgramName(al.get(1));
         
         sp.clearData("Start Date");
         sp.EnterStartDate();
         
         sp.clearData("Student Enrolment ID");
         sp.EnterStudentEnrolmentID("STUPRGM");
         
         sp.clearPrimaryProg();
         Scrollpagedown();
         ac.AdditionalWait();
         
         sp.clearProgramSel();
         sp.EnterProgram(al.get(2));
         sp.SelectProgSel();
         ac.AdditionalWait();
         
         sp.SelectDropdownValues("Product Type", al.get(3));
         sp.SelectDropdownValues("Class/Program Type", al.get(4));
         sp.SelectDropdownValues("Trial Program", al.get(7));
         sp.SelectDropdownValues("Duration", al.get(5));
         sp.ClickSave();
     }
     
     public void updatetrialProg(String val) throws Exception {
         
         StudentProgPO sp = new StudentProgPO(driver);
         
         sp.SelectTrialProg(val);
         sp.ClickSave();
         
         if( prior_prog_Id == al)
         {
             prior_prog_Id = al2;
             sec_prog_Id = al;
         }
         else
         {
             prior_prog_Id = al;
             sec_prog_Id = al2;
         }       
         
     }
    
     public void UpdateStuUnit(String Accountid) throws InterruptedException, IOException
     {  
         CreatedAccountPO ac=new CreatedAccountPO(driver);
         
         //Taking a random cohort
         al3 = sp.getNewProg(al.get(13),al.get(16));
         
         System.out.println("al3 :"+al3);
         
         while(al3.get(2).equalsIgnoreCase(al.get(2)) || al3.get(2).equalsIgnoreCase(al2.get(2)))
         {
             al3 = sp.getNewProg(al.get(13),al.get(16));
         }
         
         System.out.println("al3 :"+al3);
         
         //Inserting student program from above cohort
         if(al3.get(13).equalsIgnoreCase("K3"))
         {
             //log.info("Inserting student program from above cohort");
             if(CurrURL.contains("--byjusuat")) {
                 payLoad_Revamp_K3.AccountidCreationResponse_UAT2(Accountid,al3.get(2),al3.get(5),al3.get(3),al3.get(7),al3.get(4),al3.get(22));

             }
             else if(CurrURL.contains("--byjusfc")) {
                 payLoad_Revamp_K3.AccountidCreationResponse_UATFC2(Accountid,al3.get(2),al3.get(5),al3.get(3),al3.get(7),al3.get(4),al3.get(22));

             }
             }
         else
         {
             //log.info("Inserting student program from above cohort");
             if(CurrURL.contains("--byjusuat")) {
                 payLoad_PrgmwithSSO_Revamp.AccountidCreationResponse_UAT(Accountid,al3.get(2),al3.get(5),al3.get(3),al3.get(7),al3.get(4));

             }
             else if(CurrURL.contains("--byjusfc")) {
                 payLoad_PrgmwithSSO_Revamp.AccountidCreationResponse_UATFC(Accountid,al3.get(2),al3.get(5),al3.get(3),al3.get(7),al3.get(4));

             }
         }
         
         //change current class on account
         ac.AdditionalWait();
         ac.AccountLoadwait();
         //log.info("Changing current class"); 
         ac.ChangeClass(al3.get(16));
         ac.AccountLoadwait();
         }
     
     //changing class/program type , duration , product type , Trial program in primary program
     public void updateProgTyDurtnProdTyTrProg() throws InterruptedException {
         //changing the primary program details 
         //ac.ClickStudentPrograms();
    
         StudentProgPO sp = new StudentProgPO(driver);
         CreatedAccountPO ac=new CreatedAccountPO(driver);
         
         //product type
         if(!prior_prog_Id.get(18).equalsIgnoreCase("NA"))
         {
             if(prior_prog_Id.get(3).equalsIgnoreCase("Free"))
                 sp.SelectProductType("Paid");
             else 
                 sp.SelectProductType("Free");
             
             sp.ClickSave();
             ac.AdditionalWait();
         }
         
         //class/program type 
         if(!prior_prog_Id.get(19).equalsIgnoreCase("NA"))
         {
             sp.clickEditBtn();
             
             if(prior_prog_Id.get(4).equalsIgnoreCase("Regular"))
                 sp.SelectClass_ProgramType("Premium");
             else 
                 sp.SelectClass_ProgramType("Regular");
             
             sp.ClickSave();
             ac.AdditionalWait();
         }
         
         //duration
         if(!prior_prog_Id.get(20).equalsIgnoreCase("NA"))
         {
             sp.clickEditBtn();
             
             if(prior_prog_Id.get(5).equalsIgnoreCase("Annual"))
                 sp.SelectDuration("Quarterly");
             else 
                 sp.SelectDuration("Annual");
             
             sp.ClickSave();
             ac.AdditionalWait();
         }
         
         //Trial program
         if(prior_prog_Id.get(18).equalsIgnoreCase("NA") && prior_prog_Id.get(19).equalsIgnoreCase("NA") && prior_prog_Id.get(20).equalsIgnoreCase("NA"))
         {
             if(prior_prog_Id.get(7).equalsIgnoreCase("No"))
                 sp.SelectTrialProg("Yes");
             else
                 sp.SelectTrialProg("No");
             sp.ClickSave();
             ac.AdditionalWait();
             
         }
         
     }
     
     public int verifyTaskJourney(ArrayList<String> al, int staticVal, String accOwner, int tasks) throws IOException, InterruptedException {

         StudentProgPO sp = new StudentProgPO(driver);
         CreatedAccountPO ac = new CreatedAccountPO(driver);
         DevConsolePO dc = new DevConsolePO(driver);
         AssignmentRulesRefundRequestPO ar = new AssignmentRulesRefundRequestPO(driver);
         HashMap<String, String> dueDates = new HashMap<String, String>();
         HashMap<String, String> assignedTo = new HashMap<String, String>();
         ArrayList<String> Tcids = new ArrayList<String>();
         String[] taskNames = {};
         int totalTasks_cdc = 0;
         int totalTasks_OpAct = 0;
         String tcid = "";

         if(region.isEmpty())
         {
             Tcids = sp.getTcids("Task_Journey", al.get(2));
             tcid = sp.getTcid_TaskJour(Tcids, al);
         }
         else
         {
            tcid = sp.getTcidRegion("Task_Journey", region);
         }
         if ((staticVal == 1 || staticVal == 2) && !tcid.isEmpty()) {

             al3 = excelData.getData(tcid, "Task_Journey", "Tcid");

             if(!al3.get(13).equalsIgnoreCase("-") || !al3.get(16).equalsIgnoreCase("-"))
             {
                 if (staticVal == 1) {
                     al4 = excelData.getData(al3.get(13), "Task_Types", "Tcid");
                 } 
                 else if (staticVal == 2 ) {
                     al4 = excelData.getData(al3.get(16), "Task_Types", "Tcid");
                 }
                 taskNames = al4.get(1).trim().split(";");
                 System.out.println("taskNames length : " + taskNames.length);

                 totalTasks_cdc = taskNames.length;
                 totalTasks_OpAct = taskNames.length;
                 
                 if(flag==1)
                     totalTasks_OpAct = totalTasks_OpAct+prog_tasks.get(sec_prog_Id.get(0));
                 
                 if (!tcid_tasktypes.isEmpty() && tcid_tasktypes.keySet().contains(al.get(0))) {

                     if (!tcid_tasktypes.get(al.get(0)).equalsIgnoreCase(al4.get(0))) {
                         totalTasks_cdc = taskNames.length+tasks;
                     }

                 }

                 if (staticVal == 1)
                     tcid_tasktypes.put(al.get(0), al3.get(13));// Storing the tc id and its task type
                 else if (staticVal == 2)
                     tcid_tasktypes.put(al.get(0), al3.get(16));

                 sp.ClickAsgmtCDCExecutors();

                 ac.AdditionalWait();

                 // Verifying the status in 'Assgnmnt CDC'
                 int noOfTasks = sp.statusCompletedCount(totalTasks_cdc, "Completed");
                 System.out.println("noOfTasks CDC: " + noOfTasks);
                 Assert.assertEquals(noOfTasks, totalTasks_cdc);

                 String crtdDate = sp.getCreatedDate(taskNames[0]);

                 // Getting the due dates from Assgnmnt CDC
                 for (int i = 0; i < taskNames.length; i++) {
                     String date = sp.getTaskDueDate(taskNames[i],crtdDate);
                     dueDates.put(taskNames[i], date);
                     ac.CloseCurrentSubTab();
                 }

                 ac.CloseSubTabs();
                 ac.AdditionalWait();

                 ac.ClickOpenActivities1();

                 // Verifying the due date in 'Open Activities'
                 for (int i = 0; i < taskNames.length; i++) {
                     String actualDate = ac.GetDueDate(taskNames[i], crtdDate); 
                     String expDate = ac.getExpDueDate(dueDates.get(taskNames[i]));
                     Assert.assertEquals(actualDate, expDate);
                     assignedTo.put(taskNames[i], ac.GetAssignedTo(taskNames[i], crtdDate));
                 }

                 // Verifying the task owner
                 for (int i = 0; i < taskNames.length; i++) {
                     Assert.assertEquals(assignedTo.get(taskNames[i]), accOwner);
                 }

                 // Verifying the status in 'Open Activities'
                 noOfTasks = sp.statusCompletedCount(totalTasks_OpAct, "Open");
                 System.out.println("noOfTasks OA: " + noOfTasks);
                 Assert.assertEquals(noOfTasks, totalTasks_OpAct);
                         
                 ac.CloseCurrentSubTab();
             }
         }

         // For Static 3
         else if ((staticVal == 3 || staticVal == 4) && !tcid.isEmpty()) 
         {
             al3 = excelData.getData(tcid, "Task_Journey", "Tcid");
          
             if(!al3.get(19).equalsIgnoreCase("-") || !al3.get(22).equalsIgnoreCase("-"))
             {
                 if (staticVal == 3) 
                 {
                     al4 = excelData.getData(al3.get(19), "Task_Types", "Tcid");
                 } 
                 else if (staticVal == 4) 
                 {
                     al4 = excelData.getData(al3.get(22), "Task_Types", "Tcid");
                 }

                 taskNames = al4.get(1).trim().split(";");
                 
                 totalTasks_cdc = taskNames.length;
                 totalTasks_OpAct = taskNames.length+tasks;
                 
                 if (!tcid_tasktypes.isEmpty() && tcid_tasktypes.keySet().contains(al.get(0))) {

                     if (!tcid_tasktypes.get(al.get(0)).equalsIgnoreCase(al4.get(0))) {
                         totalTasks_cdc = taskNames.length + tasks;
                     }

                 }

                 if (staticVal == 3)
                     tcid_tasktypes.put(al.get(0), al3.get(19));
                 else if (staticVal == 4)
                     tcid_tasktypes.put(al.get(0), al3.get(22));
                 
                 
                 sp.ClickAsgmtCDCExecutors();
                 ac.AdditionalWait();

                 // Verifying the status in 'Assgnmnt CDC'
                 int noOfTasks = sp.statusCompletedCount(totalTasks_cdc, "Completed");
                 System.out.println("noOfTasks : " + noOfTasks);
                 Assert.assertEquals(noOfTasks, totalTasks_cdc);           

                 String crtdDate = sp.getCreatedDate(taskNames[0]);
                 
                 // Getting the due dates from Assgnmnt CDC
                 for (int i = 0; i < taskNames.length; i++) {
                     String date = sp.getTaskDueDate(taskNames[i],crtdDate);
                     dueDates.put(taskNames[i], date);
                     ac.CloseCurrentSubTab();
                 }

                 ac.CloseSubTabs();
                 ac.AdditionalWait();

                 ac.ClickOpenActivities1();

                 // Verifying the due date in 'Open Activities'
                 for (int i = 0; i < taskNames.length; i++) {
                     String actualDate = ac.GetDueDate(taskNames[i], crtdDate);
                     String expDate = ac.getExpDueDate(dueDates.get(taskNames[i]));
                     Assert.assertEquals(actualDate, expDate);
                     assignedTo.put(taskNames[i], ac.GetAssignedTo(taskNames[i], crtdDate));
                 }

                 // Verifying the status in 'Open Activities'
                 noOfTasks = sp.statusCompletedCount(totalTasks_OpAct, "Open");
                 Assert.assertEquals(noOfTasks, totalTasks_OpAct);

                 // Verifying the task owner
                 if (staticVal == 3) 
                 {
                     String expectedQueue = ar.GetExpAssgnRule(al, "PE", this.al.get(15));
                     String wh = driver.getWindowHandle();

                     String taskOwner = ac.GetAssignedTo(taskNames[0], crtdDate); // get task owner

                     // To get group Id
                     // if trial program for assignment rule is NA
                     if (al.get(17).equalsIgnoreCase("NA")) {
                         // Opening dev console
                         if(CurrURL.contains("--byjusuat")) {
                             dc.GetDevConsole("UAT");
                         }
                         else if(CurrURL.contains("--byjusfc")) {
                             dc.GetDevConsole("UATFC");
                         }                        
                         dc.closeconsoleTabs();
                         dc.ExecuteQuery1(Queries.getGrpIdProdTy(al.get(3), expectedQueue, al.get(2), "PE"));
                     } else {
                         if(CurrURL.contains("--byjusuat")) {
                             dc.GetDevConsole("UAT");
                         }
                         else if(CurrURL.contains("--byjusfc")) {
                             dc.GetDevConsole("UATFC");
                         }
                         dc.closeconsoleTabs();
                         dc.ExecuteQuery1(Queries.getGrpIdTrPg(al.get(17), expectedQueue, al.get(2), "PE"));
                     }

                     String grpId_exp = "";
                     
                     if(al.get(2).equalsIgnoreCase("AFNCKXSY0001") || al.get(2).equalsIgnoreCase("BAFLKXAS0001") || al.get(2).equalsIgnoreCase("BDLCKXAS0001")|| al.get(13).equalsIgnoreCase("K3") || expectedQueue.equalsIgnoreCase("Admin_Missing_rule"))
                     {
                         grpId_exp = dc.getId(); 
                     }
                     else
                         grpId_exp = dc.getAssgnEntryId();
                     
                     ac.AdditionalWait();

                     // executing 2nd query to get assignment rule Id from query editor
                     dc.closeconsoleTabs();

                     // To get assignment rule Id
                     // if trial program for assignment rule is NA
                     if (al.get(17).equalsIgnoreCase("NA")) {
                         dc.ExecuteQuery1(
                                 Queries.GetAssgnIdProdTy(al.get(3), grpId_exp, al.get(2), "PE", expectedQueue));
                     } else {
                         dc.ExecuteQuery1(Queries.GetAssgnIdTrpg(al.get(17), grpId_exp, al.get(2), "PE", expectedQueue));
                     }

                     String assgnId = "";
                     
                     if(al.get(2).equalsIgnoreCase("AFNCKXSY0001") || al.get(2).equalsIgnoreCase("BAFLKXAS0001") || al.get(2).equalsIgnoreCase("BDLCKXAS0001")|| al.get(13).equalsIgnoreCase("K3") || expectedQueue.equalsIgnoreCase("Admin_Missing_rule"))
                     {
                         assgnId = dc.getId(); 
                     }
                     else
                         assgnId = dc.getAssgnEntryId();
                     
                     System.out.println("assgnId :" + assgnId);
                     ac.AdditionalWait();

                     dc.CloseWindowArrayLast();
                     ac.AdditionalWait();
                     driver.switchTo().window(wh);
                     ac.AdditionalWait();

                     // Opening the assignment rule
                     if(CurrURL.contains("--byjusuat")) {
                         ac.goTo("https://byjusprod--byjusuat.lightning.force.com/lightning/r/Assignment_Rule__c/" + assgnId
                                 + "/view");
                     }
                     else if(CurrURL.contains("--byjusfc")) {
                         ac.goTo("https://byjusprod--byjusfc.sandbox.lightning.force.com/lightning/r/Assignment_Rule__c/" + assgnId
                                 + "/view");
                     }  

                     ar.NavtoGroup(expectedQueue);
                     ar.navToGrpMem();
                     Assert.assertTrue(ar.VerifyCaseOwner(taskOwner));
                     ac.closeCurrentTabWindow();

                     for (int i = 0; i < taskNames.length; i++) {
                         Assert.assertEquals(assignedTo.get(taskNames[i]), taskOwner);
                     }

                     ac.AccountLoadwait();
                     ac.AccountLoadwait();
                     ac.CloseCurrentSubTab();
                     ac.AccountLoadwait();
                     ac.AccountLoadwait();
                     
                     // If it is static 3 - verify account team if the task owner is present or not
                     Assert.assertTrue(ac.verifyAccTeamMem(taskOwner));

                 } 
                 else if (staticVal == 4) 
                 {
                     for (int i = 0; i < taskNames.length; i++) {
                         Assert.assertEquals(assignedTo.get(taskNames[i]), accOwner);
                     }
                    
                 }

                 ac.CloseCurrentSubTab();

             }
         }
         return taskNames.length;

     }
     
     @AfterMethod(alwaysRun = true)
	public void teardown() throws InterruptedException {

		//driver.quit();

	}
	
	@DataProvider
	public Object[][] testDatapro() throws Exception {
	    Object[][] data = readData(System.getProperty("user.dir") + "//src//main//java//testData//TestData.xlsx",
	               "Revamp_K10");
	    return data;
	}

}
