package Revamp;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import pageObjects.CreatedAccountPO;
import pageObjects.loginPO;
import payLoad.payLoad_SinglePrgm_Revamp_Non_Servicable;
import resources.ExcelData;
import resources.base;
import testCases.test_CollectionFlow;

public class test_Revamp_Non_serviceable extends base {

	public WebDriver driver;
	//ThreadLocal<WebDriver> driver = new ThreadLocal<WebDriver>();
	//public String CurrURL;
	public static Logger log = LogManager.getLogger(test_CollectionFlow.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	ArrayList<String> al3 = new ArrayList<String>();
	ArrayList<String> al4 = new ArrayList<String>();
	static Faker faker = new Faker();
	static String firstName = faker.name().firstName();
	static String lastName = faker.name().lastName();
	static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);
	
    @BeforeMethod(alwaysRun = true)
    public void initialize() throws IOException, InterruptedException {

        driver = initializeDriver();
    }
    	                            
    
	@Test(groups = { "Regression" ,"sanity"}, enabled = true)
	public void Revamp_Non_serviceable() throws Exception {
	    
	    loginPO lo=new loginPO(driver);
	    CreatedAccountPO ac=new CreatedAccountPO(driver);
	    
	    String Accountid = "";
	    
	    //getting count of rows
	    int noofRows = getRowCount("src//main//java//testData//TestData.xlsx", "Revamp_Non-serviceable");
	    //getting a random row number 
	    String Tcid = String.valueOf(randomNumber(0,noofRows));
	    
	    if(CurrURL.contains("--byjusuat")) 
	    {
	        al = excelData.getData(Tcid, "Revamp_Non-serviceable", "Tcid");
	        al2 = excelData.getData("CollectionAssistant UAT", "Login", "Type");
    		al3 = excelData.getData("CollectionManager UAT", "Login", "Type");
    		al4 = excelData.getData("Admin", "Login", "Type");
    		log.info("Logging in as Admin to UAT");
    		lo.LoginAsAdmin_UAT();
    		
    		log.info("Submitting the Account creation payload");
    		Accountid=payLoad_SinglePrgm_Revamp_Non_Servicable.AccountidCreationResponse_UAT(al.get(2));
            log.info("Launching the newly created Account id "+Accountid);
            
		}
		else 
		{
		    al = excelData.getData("TC7", "CollectionFlow", "Tcid");
            al2 = excelData.getData("Dummy Collection Associate", "Login", "Type"); 
            al4 = excelData.getData("AdminProd", "Login", "Type");
            log.info("Logging in as Admin to Prod");
            lo.LoginAsAdmin_Prod();
		}
		
		//closeTabWindows();    
		//ac.Notification();
       
		String AccountURL=CurrURL+Accountid;
        ac.goTo(AccountURL);
        
	}

	@AfterMethod(alwaysRun = true)
	public void teardown() throws InterruptedException {

		//driver.quit();

	}
	
}
