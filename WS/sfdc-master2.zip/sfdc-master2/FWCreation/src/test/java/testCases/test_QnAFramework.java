package testCases;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import pageObjects.CreatedAccountPO;
import pageObjects.DevConsolePO;
import pageObjects.GeneralTaskPO;
import pageObjects.NewCaseRecordTypePO;
import pageObjects.StudentProgPO;
import pageObjects.loginPO;
import payLoad.payLoad_SinglePrgm;
import resources.Batches;
import resources.ExcelData;
import resources.base;



public class test_QnAFramework extends base {

	public WebDriver driver;
	//public String CurrURL;
	public static Logger log = LogManager.getLogger(test_QnAFramework.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> proddummyuser = new ArrayList<String>();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	ArrayList<String> al3 = new ArrayList<String>();
	ArrayList<String> al4 = new ArrayList<String>();
	static Faker faker = new Faker();
	static String firstName = faker.name().firstName();
	static String lastName = faker.name().lastName();
	static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);
	
	@BeforeMethod(alwaysRun = true)
	public void initialize() throws IOException, InterruptedException {
	    Thread.sleep(3000);
		driver = initializeDriver();

	}
	
	
	@Test(groups = {"sanity"}, enabled = true)
	public void TestQnAFramework_NeoClassesFOCPitchCall() throws Exception {
	    proddummyuser = excelData.getData("TC1", "ProdDummyUser", "Tcid");
		String Accountid = null;
		loginPO lo=new loginPO(driver);
		al3 = excelData.getData("Neo Classes FOC Pitch Call", "Outbound", "Tcid");
		if(CurrURL.contains("--byjusuatfc")) {
			al = excelData.getData("BYJUS The Learning App", "Picklist", "Tcid");
			al2 = excelData.getData("PE User UATFC", "Login", "Type");
			log.info("Logging in as Admin to UATFC Env");
			lo.LoginAsAdmin_UATFC();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_SinglePrgm.AccountidCreationResponse_UATFC(al.get(1), al.get(2), al.get(3), al.get(4));
			log.info("Launching the newly created Account id "+Accountid);
		}
		else if(CurrURL.contains("--byjusuat")) {
			al = excelData.getData("BYJUS The Learning App", "Picklist", "Tcid");
		    al2 = excelData.getData("PE User UAT", "Login", "Type");
		
		log.info("Logging in as Admin to UAT");
		lo.LoginAsAdmin_UAT1();
		log.info("Submitting the Account creation payload");
		Accountid=payLoad_SinglePrgm.AccountidCreationResponse_UAT(al.get(1), al.get(2), al.get(3), al.get(4));
		log.info("Launching the newly created Account id "+Accountid);
		
		}
		else {
			al = excelData.getData("BYJUS The Learning App", "Picklist", "Tcid");
			//al2 = excelData.getData("Collection Assistant", "Login", "Type");
			log.info("Logging in as Admin to Prod");
			lo.LoginAsAdmin_Prod();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_SinglePrgm.AccountidCreationResponse_Prod(al.get(1), al.get(2), al.get(3), al.get(4));
			log.info("Launching the newly created Account id "+Accountid);
		}

		closeTabWindows();
		
		CreatedAccountPO ac=new CreatedAccountPO(driver);
		//Open the account by searching PID
		ac.Notification();
		ac.NavBackToAccount();
		String AccountURL = CurrURL+Accountid;
		ac.goTo(AccountURL); 
		ac.AccountLoadwait();
		
        //Verify Neo Classes FOC Pitch Call task flow
        
        log.info("Creating General Task");
        ac.ClickOpenActivitiestoNewTask();
        
        NewCaseRecordTypePO ncrt= new NewCaseRecordTypePO(driver);
        
        ncrt.SelectTaskRecordType("General Task");
        ncrt.ClickNext();
        ncrt.EnterSubject("Neo Classes FOC Pitch Call");
        ncrt.SelectActionType("Neo Classes FOC");
        ncrt.ClickSave();
        ac.AdditionalWait();
        
        
        String TaskURL = driver.getCurrentUrl();
        
        //Logging in as PE		
        if(CurrURL.contains("--byjusuat")||CurrURL.contains("--byjusuatfc")) {
                String AccountOwner= ac.AccOwnerCheck();
                if(!al2.get(1).equalsIgnoreCase(AccountOwner)) {
                    ac.AssignAccount(al2.get(1));
                }
            }
        else {
                ac.AssignAccount("Testing User");
            }
            
        if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
            lo.SwitchUser(al2.get(1));
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(TaskURL);
            ac.AccountLoadwait();

            }
        else if(CurrURL.contains("--byjusuatfc")){
                lo.SwitchUser(al2.get(1));
                ac.closeTabWindows();
                ac.Notification();
                ac.NavBackToAccount();
                ac.goTo(TaskURL);
                ac.AccountLoadwait();

            }
        else {
                lo.SwitchUsernProfile_Prod(proddummyuser.get(1),"PE");
                ac.closeTabWindows();
                ac.Notification();
                ac.NavBackToAccount();
                ac.goTo(TaskURL);
                ac.AccountLoadwait();
            }
		
        
        //Performing Capture call detail
        GeneralTaskPO gt = new GeneralTaskPO(driver);
		gt.ClickCaptureDetail();
		gt.ClickProceedOptn2();
		
		gt.SelectIsNeoFOCpitchedtoCx(al3.get(11));
		gt.SelectDidcustomeragreeforupgrade(al3.get(12));
		gt.SelectIstheorderpunchingcomplete(al3.get(13));
		gt.SelectAretheAddonsprovided(al3.get(14));
		gt.SelectExplainCustomerAboutUsage(al3.get(15));
		if(CurrURL.contains("byjusprod.")) {
		gt.SelectHowInterestedIsCustomer(al3.get(16));
		}
		else {
		    gt.SelectHowInterestedIsCustomer2(al3.get(16));  
		}
		gt.ClickNext();
		
		ac.RefreshTab_Targetframe();
		String Status = gt.CaptureStatus();
		Assert.assertEquals(Status, "Completed");
		
		//Verifying all Task detail values
	    gt.ClickTaskDetail();
	    gt.ClickQuestionAnwer_ViewAll();
		Assert.assertEquals(gt.VerifyTaskDetailvalue("Is Neo FOC pitched to Cx?"), al3.get(11));
		if(CurrURL.contains("byjusprod.")) {
		    Assert.assertEquals(gt.VerifyTaskDetailvalue("Did customer agree for upgrade?"), al3.get(12));
		}
		else {
		Assert.assertEquals(gt.VerifyTaskDetailvalue("Did customer agree for upgrade ?"), al3.get(12));
		}
		Assert.assertEquals(gt.VerifyTaskDetailvalue("Is the order punching complete?"), al3.get(13));
		Assert.assertEquals(gt.VerifyTaskDetailvalue("Are the Add ons provided (e.g. Doubt resolutions, SST classes)?"), al3.get(14));
		Assert.assertEquals(gt.VerifyTaskDetailvalue("Did you explain the customer about the usage?"), al3.get(15));
		Assert.assertEquals(gt.VerifyTaskDetailvalue("How interested is customer?"), al3.get(16));
				
		lo.OnlyLogout();
		ac.goTo(AccountURL);
		ac.AccountLoadwait();
		
		log.info("Deleting the Student Program details");
		//ac.ClickAccOwnrTab();
		ac.DeleteCreatedStuProg();
		ac.DeleteAllCreatedStuPayment();
		ac.NavBackToAccount();
		log.info("Deleting the Account created details");
		ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
			
	}
	
	//Only to be run on UAT
   @Test(groups = {"sanity", "UAT" }, enabled = true)
    public void TestQnAFramework_NeoClassesFOCFUP1() throws Exception {
        String Accountid = null;
        loginPO lo=new loginPO(driver);
        al3 = excelData.getData("Neo FoC FUP 1", "Outbound", "Tcid");
        al4 = excelData.getData("Adminuatfc", "Login", "Type");
        if(CurrURL.contains("--byjusuatfc")) {
            al = excelData.getData("BYJUS Classes Online Premium App", "Picklist", "Tcid");
            al2 = excelData.getData("Mentor User UATFC", "Login", "Type");
            log.info("Logging in as Admin to UATFC Env");
            lo.LoginAsAdmin_UATFC();
            log.info("Submitting the Account creation payload");
            Accountid=payLoad_SinglePrgm.AccountidCreationResponse_UATFC(al.get(1), al.get(2), al.get(3), al.get(4));
            log.info("Launching the newly created Account id "+Accountid);
        }
        else if(CurrURL.contains("--byjusuat")) {
            al = excelData.getData("BYJUS Classes Online Premium App", "Picklist", "Tcid");
            al2 = excelData.getData("Mentor User UAT", "Login", "Type");
        
        log.info("Logging in as Admin to UAT");
        lo.LoginAsAdmin_UAT();
        log.info("Submitting the Account creation payload");
        Accountid=payLoad_SinglePrgm.AccountidCreationResponse_UAT(al.get(1), al.get(2), al.get(3), al.get(4));
        log.info("Launching the newly created Account id "+Accountid);
        
        }
        else {
            al = excelData.getData("BYJUS Classes Online Premium App", "Picklist", "Tcid");
            //al2 = excelData.getData("Collection Assistant", "Login", "Type");
            log.info("Logging in as Admin to Prod");
            lo.LoginAsAdmin_Prod();
            log.info("Submitting the Account creation payload");
            Accountid=payLoad_SinglePrgm.AccountidCreationResponse_Prod(al.get(1), al.get(2), al.get(3), al.get(4));
            log.info("Launching the newly created Account id "+Accountid);
        }

        closeTabWindows();
        
        CreatedAccountPO ac=new CreatedAccountPO(driver);
        StudentProgPO sp=new StudentProgPO(driver);
        //Open the account by searching PID
        ac.Notification();
        ac.NavBackToAccount();
        String AccountURL = CurrURL+Accountid;
        ac.goTo(AccountURL); 
        ac.AccountLoadwait();
        
        //Set the Product type to 'Free'
        ac.SelectStudentProg("Neo Classes");
        sp.SelectProductType("Free");
        sp.ClickSave();
        ac.CloseSubTabs();
        String Mainwin = driver.getWindowHandle();
        
        //Run the Batch
        DevConsolePO dc= new DevConsolePO(driver);
        if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
        dc.GetDevConsole("UAT");
        dc.RunBatch(Batches.NeoFoCFUP1TaskBatch());
        dc.CheckBatchRunSuccess();      
        dc.CloseWindowArrayLast();
        }
        else if(CurrURL.contains("--byjusuatfc")) {
            lo.SwitchUser(al4.get(3));
            ac.closeTabWindows();
            ac.Notification();
            //ac.goTo(AccountURL);
            //ac.AccountLoadwait();
            dc.GetDevConsole("UATFC");
            dc.RunBatch(Batches.NeoFoCFUP1TaskBatch());
            dc.CheckBatchRunSuccess();      
            dc.CloseWindowArrayLast();
            lo.OnlyLogout();
        }
        
        
        //Logging in as Mentor
        driver.switchTo().window(Mainwin);
        if(CurrURL.contains("--byjusuat")||CurrURL.contains("--byjusuatfc")) {
                String AccountOwner= ac.AccOwnerCheck();
                if(!al2.get(1).equalsIgnoreCase(AccountOwner)) {
                    ac.AssignAccount(al2.get(1));
                }
            }
        else {
                ac.AssignAccount("Testing User");
            }
            
        if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
            lo.SwitchUser(al2.get(1));
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AccountLoadwait();

            }
        else if(CurrURL.contains("--byjusuatfc")){
                lo.SwitchUser(al2.get(1));
                ac.closeTabWindows();
                ac.Notification();
                ac.NavBackToAccount();
                ac.goTo(AccountURL);
                ac.AccountLoadwait();

            }
        else {
                lo.SwitchUsernProfile_Prod(proddummyuser.get(1),"Mentor");
                ac.closeTabWindows();
                ac.Notification();
                ac.NavBackToAccount();
                ac.goTo(AccountURL);
                ac.AccountLoadwait();
            }
        
        //Verify the potential refund request task is created
        
        ac.RefreshTab();
        ac.Scrollpagedown();
        Assert.assertTrue(ac.CheckCreatedTask("Neo FoC FUP 1"));
        ac.ClickCreatedTask_OpenActivities("Neo FoC FUP 1");
        
        
        //Performing Capture call detail
        GeneralTaskPO gt = new GeneralTaskPO(driver);
        gt.ClickCaptureDetail();
        gt.ClickProceedOptn2();
        
        gt.SelectHasStudentAttendedClass(al3.get(17));
        gt.SelectCustometFacingIssue(al3.get(18));
        gt.SelectArePunchedClassesReflected(al3.get(19));
        gt.SelectBatchGradeBoard(al3.get(20));
        gt.SelectGuidecxProcess(al3.get(21));
        gt.SelectHowLikelyCustomerClasses(al3.get(22));
        gt.SelectDidSolveCustomerIssue(al3.get(23));
        gt.SelectReasonsForNotSolving(al3.get(24));
        gt.ClickNext();
        
        ac.RefreshTab_Targetframe();
        String Status = gt.CaptureStatus();
        Assert.assertEquals(Status, "Completed");
                
        //Verifying all Task detail values
        gt.ClickTaskDetail();
        gt.ClickQuestionAnwer_ViewAll();
        Assert.assertEquals(gt.VerifyTaskDetailvalue("Has the student attended any class?"), al3.get(17));
        Assert.assertEquals(gt.VerifyTaskDetailvalue("If the customer is facing any issue?"), al3.get(18));
        Assert.assertEquals(gt.VerifyTaskDetailvalue("Are the punched classes reflected on the portal?"), al3.get(19));
        Assert.assertEquals(gt.VerifyTaskDetailvalue("Is the Batch/Grade/Board accurate as per the previous selection?"), al3.get(20));
        Assert.assertEquals(gt.VerifyTaskDetailvalue("Did you guide cx the process to login into the portal?"), al3.get(21));
        Assert.assertEquals(gt.VerifyTaskDetailvalue("How likely is the customer to attend classes?"), al3.get(22));
        Assert.assertEquals(gt.VerifyTaskDetailvalue("Did you solve the customer issue?"), al3.get(23));
        Assert.assertEquals(gt.VerifyTaskDetailvalue("Reasons for not solving"), al3.get(24));
        
        lo.OnlyLogout();
        ac.goTo(AccountURL);
        ac.AccountLoadwait();
        
        log.info("Deleting the Student Program details");
        ac.ClickAccOwnrTab();
        ac.DeleteCreatedStuProg();
        ac.DeleteAllCreatedStuPayment();
        ac.NavBackToAccount();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
            
    }
    
   @Test(groups = {"sanity","UATFC" }, enabled = true)
   public void TestQnAFramework_MidTermExam() throws Exception {
       String Accountid = null;
       loginPO lo=new loginPO(driver);
       al3 = excelData.getData("Mid Term Exam Details", "Outbound", "Tcid");
       if(CurrURL.contains("--byjusuatfc")) {
           al = excelData.getData("Mid term Exam", "Multi_Prog", "Tcid");
           al2 = excelData.getData("PE User UATFC", "Login", "Type");
           log.info("Logging in as Admin to UATFC Env");
           lo.LoginAsAdmin_UATFC();
           log.info("Submitting the Account creation payload");
           Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_UATFC(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
           log.info("Launching the newly created Account id "+Accountid);
       }
       else if(CurrURL.contains("--byjusuat")) {
           al = excelData.getData("Mid term Exam", "Multi_Prog", "Tcid");
           al2 = excelData.getData("PE User UAT", "Login", "Type");
       
       log.info("Logging in as Admin to UAT");
       lo.LoginAsAdmin_UAT1();
       log.info("Submitting the Account creation payload");
       Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_UAT(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
       log.info("Launching the newly created Account id "+Accountid);
       
       }
       else {
           al = excelData.getData("Mid term Exam", "Multi_Prog", "Tcid");
           log.info("Logging in as Admin to Prod");
           lo.LoginAsAdmin_Prod();
           log.info("Submitting the Account creation payload");
           Accountid=payLoad_SinglePrgm.AccountidCreationResponse2_Prod(al.get(1), al.get(2), al.get(3), al.get(4),al.get(5));
           log.info("Launching the newly created Account id "+Accountid);
       }

       closeTabWindows();
       
       CreatedAccountPO ac=new CreatedAccountPO(driver);
       //Open the account by searching PID
       ac.Notification();
       ac.NavBackToAccount();
       String AccountURL = CurrURL+Accountid;
       ac.goTo(AccountURL); 
       ac.AccountLoadwait();
       
       //Verify Mid Term Exam Detail task flow
       
       log.info("Creating General Task");
       ac.ClickOpenActivitiestoNewTask();
       
       NewCaseRecordTypePO ncrt= new NewCaseRecordTypePO(driver);
       
       ncrt.SelectTaskRecordType("General Task");
       ncrt.ClickNext();
       ncrt.EnterSubject("Mid Term Exam Details Capture");
       ncrt.SelectActionType("Mid Term Exam Details Capture");
       ncrt.ClickSave();
       ac.AdditionalWait();
       
       
       //Performing Capture call detail
       GeneralTaskPO gt = new GeneralTaskPO(driver);
       gt.ClickCaptureDetail();
       gt.ClickProceedOptn2();

       gt.SelectPreviousExamStudent(al3.get(25));
       gt.SelectCaptureMarks(al3.get(26));
       gt.EnterMathsMarksPreviousExam(al3.get(27));
       gt.EnterScienceMarksPreviousExam(al3.get(28));
       if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
       gt.EnterMidTermExamDate();
       }
       else {
           gt.EnterMidTermExamDate_Prod();
       }
       gt.EnterMidTermMarksMaths(al3.get(29));
       gt.EnterMidTermMarksScience(al3.get(30));
       gt.ClickNext();
       
       ac.RefreshTab_Targetframe();
       String Status = gt.CaptureStatus();
       Assert.assertEquals(Status, "Completed");
       
       //Verifying all Task detail values
       gt.ClickTaskDetail();
       gt.ClickQuestionAnwer_ViewAll();
       Assert.assertEquals(gt.VerifyTaskDetailvalue("What was previous exam for which the student had appeared ?"), al3.get(25));
       Assert.assertEquals(gt.VerifyTaskDetailvalue("Capture Marks"), al3.get(26));
       Assert.assertEquals(gt.VerifyTaskDetailvalue("Maths Marks scored in previous exam in % (0-100)"), al3.get(27));
       Assert.assertEquals(gt.VerifyTaskDetailvalue("Science Marks scored in previous exam in % (0-100)"), al3.get(28));
       Assert.assertEquals(gt.VerifyTaskDetailvalue("Enter Mid Term Exam Date (If customer is not aware of the exact exam date, please get the tentative date)"), gt.TodayDate());
       Assert.assertEquals(gt.VerifyTaskDetailvalue("Enter Midterm target marks for Maths in % (0-100)"), al3.get(29));
       Assert.assertEquals(gt.VerifyTaskDetailvalue("Enter Midterm target marks for Science in % (0-100)"), al3.get(30));
               
       ac.CloseSubTabs();
       
       log.info("Deleting the Student Program details");
       ac.ClickAccOwnrTab();
       ac.DeleteAllCreatedStuProg();
       ac.DeleteAllCreatedStuPayment();
       ac.NavBackToAccount();
       log.info("Deleting the Account created details");
       ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
           
   }
	
	  @AfterMethod(alwaysRun = true) public void teardown() throws
	  InterruptedException {
	  
	  driver.quit();
	  
	  //Thread.sleep(2000); 
	  }
	 
	
	
}
