package testCases;

import java.io.IOException;
import java.util.ArrayList;

import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.openqa.selenium.WebDriver;

import org.testng.annotations.AfterMethod;

import org.testng.annotations.BeforeMethod;

import org.testng.annotations.Test;


import com.github.javafaker.Faker;

import org.testng.Assert;


import pageObjects.CreatedAccountPO;






import pageObjects.StudentProgPO;


import pageObjects.loginPO;

import payLoad.payLoad_SinglePrgm;
import resources.ExcelData;
import resources.base;



public class test_AakashTestSeries extends base {

	public WebDriver driver;
	//public String CurrURL;
	public static Logger log = LogManager.getLogger(test_AakashTestSeries.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	static Faker faker = new Faker();
	static String firstName = faker.name().firstName();
	static String lastName = faker.name().lastName();
	static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);
	
	@BeforeMethod(alwaysRun = true)
	public void initialize() throws IOException, InterruptedException {

		driver = initializeDriver();

	}
	
	
	@Test(groups = {"sanity", "UAT" }, enabled = true)
	public void TestAakashTestSeries() throws Exception {
		String Accountid = null;
		loginPO lo=new loginPO(driver);
		
		if(CurrURL.contains("--byjusuatfc")) {
			al = excelData.getData("Aakash Test Series", "Picklist", "Tcid");
			//al2 = excelData.getData("Collection Assistant QA", "Login", "Type");
			log.info("Logging in as Admin to UATFC Env");
			lo.LoginAsAdmin_UATFC();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_SinglePrgm.AccountidCreationResponse_UATFC(al.get(1), al.get(2), al.get(3), al.get(4));
			log.info("Launching the newly created Account id "+Accountid);
		}
		else if(CurrURL.contains("--byjusuat")) {
			al = excelData.getData("Aakash Test Series", "Picklist", "Tcid");
		//al2 = excelData.getData("Collection Assistant", "Login", "Type");
		
		log.info("Logging in as Admin to UAT");
		lo.LoginAsAdmin_UAT1();
		log.info("Submitting the Account creation payload");
		Accountid=payLoad_SinglePrgm.AccountidCreationResponse_UAT(al.get(1), al.get(2), al.get(3), al.get(4));
		log.info("Launching the newly created Account id "+Accountid);
		
		}
		else {
			al = excelData.getData("Aakash Test Series", "Picklist", "Tcid");
			//al2 = excelData.getData("Collection Assistant", "Login", "Type");
			log.info("Logging in as Admin to Prod");
			lo.LoginAsAdmin_Prod();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_SinglePrgm.AccountidCreationResponse_Prod(al.get(1), al.get(2), al.get(3), al.get(4));
			log.info("Launching the newly created Account id "+Accountid);
		}

		closeTabWindows();
		
		CreatedAccountPO ac=new CreatedAccountPO(driver);
		StudentProgPO sp= new StudentProgPO(driver);
		//Open the account by searching PID
		ac.Notification();
		ac.NavBackToAccount();
		ac.goTo(CurrURL+Accountid); //Added SFTNL-8782 as part of account creation
		Thread.sleep(5000);
		
		ac.Scrollpagedown();
		
		//Verify  BYJUS The Learning App  program is created in student program related list
		String Progval = ac.CapturePrgCreated();
		Assert.assertEquals(Progval, "Aakash BYJU'S Test Series");
		
		//Verifying there are no task open in Open Activities
		String OpenActivities = ac.OpenActivitiesCount();
		Assert.assertTrue(OpenActivities.contains("0"));
		
		//Verifying the picklist values in Class/Program Type //SFTNL-7987
		ac.SelectStudentProg("Aakash BYJU'S Test Series");
		sp.EditClass_ProgramType();
		sp.VerifyPL_Class_ProgramType("12+ Grade PCB_NEET Ranker");
		sp.VerifyPL_Class_ProgramType("12+ Grade PCM_JEE Ranker");
		sp.VerifyPL_Class_ProgramType("12+ Grade PCB_NEET Scholar");
		sp.VerifyPL_Class_ProgramType("12+ Grade PCM_JEE Scholar");
		sp.VerifyPL_Class_ProgramType("12+ Grade PCB_NEET Daily Practice");
		sp.VerifyPL_Class_ProgramType("12+ Grade PCM_JEE Daily Practice");
		sp.VerifyPL_Class_ProgramType("12+ Grade PCB_NEET Mock");
		sp.VerifyPL_Class_ProgramType("12+ Grade PCM_JEE Mock");
		sp.VerifyPL_Class_ProgramType("12 Grade PCB_NEET Ranker");
		sp.VerifyPL_Class_ProgramType("12 Grade PCM_JEE Ranker");
		sp.VerifyPL_Class_ProgramType("12 Grade PCB_NEET Scholar");
		sp.VerifyPL_Class_ProgramType("12 Grade PCM_JEE Scholar");
		sp.VerifyPL_Class_ProgramType("12 Grade PCB_NEET Daily Practice");
		sp.VerifyPL_Class_ProgramType("12 Grade PCM_JEE Daily Practice");
		sp.VerifyPL_Class_ProgramType("12 Grade PCB_NEET Mock");
		sp.VerifyPL_Class_ProgramType("12 Grade PCM_JEE Mock");
		sp.VerifyPL_Class_ProgramType("11+12 Grade PCB_NEET Ranker");
		sp.VerifyPL_Class_ProgramType("11+12 Grade PCM_JEE Ranker");
		sp.VerifyPL_Class_ProgramType("11+12 Grade PCB_NEET Scholar");
		sp.VerifyPL_Class_ProgramType("11+12 Grade PCM_JEE Scholar");
		sp.VerifyPL_Class_ProgramType("11+12 Grade PCB_NEET Daily Practice");
		sp.VerifyPL_Class_ProgramType("11+12 Grade PCM_JEE Daily Practice");
		sp.VerifyPL_Class_ProgramType("11+12 Grade PCB_NEET Mock");
		sp.VerifyPL_Class_ProgramType("11+12 Grade PCM_JEE Mock");
		
		sp.ClickCancel();
		ac.ClickAccOwnrTab();
		ac.RefreshTab();
		
		if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
		//String AccountOwner = ac.CaptureAccOwnerNam();
		//Assert.assertEquals(AccountOwner, "Kulbhushan Atkar");
		}
				
		log.info("Deleting the Student Program details");
		ac.ClickAccOwnrTab();
		ac.DeleteCreatedStuProg();
		ac.DeleteAllCreatedStuPayment();
		ac.NavBackToAccount();
		log.info("Deleting the Account created details");
		ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
			
				
		
	}
		
	
	  @AfterMethod(alwaysRun = true) public void teardown() throws
	  InterruptedException {
	  
	  driver.quit();
	  
	  //Thread.sleep(2000); 
	  }
	 
	
	
}
