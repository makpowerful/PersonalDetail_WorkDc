package testCases;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import pageObjects.CasesPO;
import pageObjects.CreatedAccountPO;
import pageObjects.GmailPO;
import pageObjects.loginPO;
import payLoad.payLoad_BTLA2;
import resources.ExcelData;
import resources.base;



public class test_Email_UnRegistered extends base {

	public WebDriver driver;
	//public String CurrURL;
	public static Logger log = LogManager.getLogger(test_Email_UnRegistered.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	ArrayList<String> al3 = new ArrayList<String>();
	ArrayList<String> al4 = new ArrayList<String>();
	ArrayList<String> al5 = new ArrayList<String>();
	ArrayList<String> al6 = new ArrayList<String>();
	static Faker faker = new Faker();
	static String firstName = faker.name().firstName();
	static String lastName = faker.name().lastName();
	static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);
	
	@BeforeMethod(alwaysRun = true)
	public void initialize() throws IOException, InterruptedException {

		driver = initializeDriver();

	}
	
	
	@Test(groups = {"sanity", "UAT" }, enabled = true)
	public void TestEmailUnRegistered() throws Exception {
		String Accountid = null;
		loginPO lo=new loginPO(driver);
		al = excelData.getData("TC1", "RefundProcess", "Tcid");
		al5 = excelData.getData("SFEmail", "Login", "Tcid");
		al3 = excelData.getData("SF2Email", "Login", "Tcid");
		if(CurrURL.contains("--byjusuatfc")) {
			al6 = excelData.getData("UATFC", "Email", "Tcid");
			al2 = excelData.getData("PE User UATFC", "Login", "Type");
			log.info("Logging in as Admin to UATFC Env then switching user to PE");
			lo.LoginAsAdmin_UATFC();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_BTLA2.AccountidCreationResponse_UATFC();
			log.info("Launching the newly created Account id "+Accountid);
		}
		else if(CurrURL.contains("--byjusuat")) {
		al6 = excelData.getData("UAT", "Email", "Tcid");
		al2 = excelData.getData("PE User UAT", "Login", "Type");
		
		log.info("Logging in as Admin to UAT then switching user to PE");
		lo.LoginAsAdmin_UAT1();
		log.info("Submitting the Account creation payload");
		Accountid=payLoad_BTLA2.AccountidCreationResponse_UAT();
		log.info("Launching the newly created Account id "+Accountid);
		
		}
		else {
			al6 = excelData.getData("Prod", "Email", "Tcid");
			//al2 = excelData.getData("Collection Assistant", "Login", "Type");
			log.info("Logging in as Admin to Prod");
			lo.LoginAsAdmin_Prod();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_BTLA2.AccountidCreationResponse_Prod();
			log.info("Launching the newly created Account id "+Accountid);
		}
		closeTabWindows();
		
		
		CreatedAccountPO ac=new CreatedAccountPO(driver);
		CasesPO cases= new CasesPO(driver);
		//Open the account by searching PID
		ac.Notification();
		ac.NavBackToAccount();
		String AccountURL = CurrURL+Accountid;
		ac.goTo(CurrURL+Accountid);
		Thread.sleep(5000);
		
		String AccountName1 = ac.CaptureAccOwnrNam();
		
		//Changing the email address of account
		ac.EditAccount();
		ac.UpdateStudentEmailid(al5.get(1));
		ac.UpdateEmail(al5.get(1));
		ac.ClickSave();
		
		
		String MainWin = driver.getWindowHandle();
		
		//Login to Gmail
		GmailPO gm= new GmailPO(driver);
		
		gm.LoginGmail(al3.get(1),al3.get(2));
		String SecondWin = driver.getWindowHandle();
		
		String EmailSubject = gm.EmailSubject();
		gm.SendMail(al6.get(1), EmailSubject, EmailSubject);

		if(CurrURL.contains("byjusprod.")) {
		gm.CheckMailRecieved(al6.get(1));
		}
		else {
			gm.CheckMailRecieved(al6.get(1));
		}
		
		//Swtiching back to Account to check the case is created with Unregistered email
		driver.switchTo().window(MainWin);
		cases.NavMenuClick();
		cases.CaseNavMenuClick();
		cases.NavNEOL2QueueProd();
		cases.AddFilterWebEmail(al3.get(1));
		cases.ClickSave();
		
		cases.ClickUnregisEmailCase(EmailSubject);
		
		//Verifying the Account Name field is empty
		String AccountName = cases.CaptureAccountName();
		Assert.assertEquals(AccountName, "");
		
		
		//Verify the case is created and is closed, Task is created
		String OldReopenCount = cases.CaptureReopenCount();
		driver.switchTo().window(SecondWin);
		if(CurrURL.contains("byjusprod.")) {
		gm.ReplytoByjusMail(al6.get(1), al5.get(1));
		}
		else {
			gm.ReplytoByjusMail(al6.get(1), al5.get(1));
		}
		
		//Swtiching back to Account
		driver.switchTo().window(MainWin);
		
		//Verifying Status change to Open
		cases.StatusChangeCheck();
		ac.AdditionalWait();

		
		//Verifying the reopen counter increment.
		String NewReopenCount = cases.CaptureReopenCount();
		
		log.info("The old reopen count is "+OldReopenCount+" and the new count is "+NewReopenCount+"");
		Assert.assertTrue(!OldReopenCount.equalsIgnoreCase(NewReopenCount));
		//Verifying the Account assignment is correct
		AccountName = cases.CaptureAccountName();
		Assert.assertEquals(AccountName, AccountName1);
		
		//Removing filter
		ac.closeTabWindows();
		cases.RemveFlterAdded_Refresh();

		//Deleting the created case
		ac.goTo(AccountURL);
		Thread.sleep(3000);
		ac.ClickCasesMC2();
		
		cases.CloseAllCases();
		
		log.info("Deleting the Student Program details");
		ac.ClickAccOwnrTab();
		ac.DeleteCreatedStuProg();
		ac.DeleteAllCreatedStuPayment();
		ac.NavBackToAccount();
		log.info("Deleting the Account created details");
		ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
		
		//Sending mail again with a different subject
		driver.switchTo().window(SecondWin);

		gm.ClickInboxnRefresh();
		if(CurrURL.contains("byjusprod.")) {
		gm.VerifyNoMailfromByjus(al6.get(1));
		}
		else {
			gm.VerifyNoMailfromByjus(al6.get(1));
		}
	}
		
	
	  @AfterMethod(alwaysRun = true) public void teardown() throws
	  InterruptedException {
	  
	  driver.quit();
	  
	  //Thread.sleep(2000); 
	  }
	 
	
	
}
