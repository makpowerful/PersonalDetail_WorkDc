package testCases;

import java.io.IOException;
import java.util.ArrayList;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.testng.Assert;

import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.ui.Select;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;



import pageObjects.CreatedAccountPO;
import pageObjects.CreatedCaseRecordPO;

import pageObjects.PaymentsPO;

import pageObjects.loginPO;

import payLoad.payLoad_BTLA;
import resources.ExcelData;
import resources.base;

public class test_7006 extends base{
	
	public WebDriver driver;
	public static Logger log = LogManager.getLogger(test_7006.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	ArrayList<String> al3 = new ArrayList<String>();
	ArrayList<String> al4 = new ArrayList<String>();
	ArrayList<String> al5 = new ArrayList<String>();
	ArrayList<String> al6 = new ArrayList<String>();
	ArrayList<String> al7 = new ArrayList<String>();
	@BeforeMethod(alwaysRun = true)
	public void initialize() throws IOException, InterruptedException {

		driver = initializeDriver();

	}	
	
	@Test(groups = {"sanity", "UAT" }, enabled = true)
	public void testLanguageBarrier() throws Exception {
		String Accountid = null;
		loginPO lo=new loginPO(driver);
		al = excelData.getData("CollectionAssociate", "SFTNL_7006", "Type");
		al2 = excelData.getData("CollectionManager", "SFTNL_7006", "Type");
		al3 = excelData.getData("CollectionAssociate2", "SFTNL_7006", "Type");
		al4 = excelData.getData("SystemAdminOperations", "SFTNL_7006", "Type");
		al5= excelData.getData("LoanAmount", "SFTNL_7006", "Type");
		al6= excelData.getData("PhoneNumber", "SFTNL_7006", "Type");
		al7 = excelData.getData("Comment", "SFTNL_7006", "Type");
		String user1=al.get(1);
		String user2=al2.get(1);
		String user3=al3.get(1);
		String user4=al4.get(1);		
		String user5=null;
		
		CreatedAccountPO ac=new CreatedAccountPO(driver);
		loginPO lp2=new loginPO(driver);
		CreatedCaseRecordPO ccr=new CreatedCaseRecordPO(driver);
		WebElement element;
		JavascriptExecutor js = (JavascriptExecutor) driver;
		if(CurrURL.contains("--byjusuatfc")) {
			log.info("Logging in as Admin to UATFC Env");
			lo.LoginAsAdmin_UATFC();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_BTLA.AccountidCreationResponse_UATFC();			
			log.info("Launching the newly created Account id "+Accountid);
		}
		else if(CurrURL.contains("--byjusuat")) {
		log.info("Logging in as Admin to UAT");
		lo.LoginAsAdmin_UAT();
		closeTabWindows();
		log.info("Submitting the Account creation payload");
		Accountid=payLoad_BTLA.AccountidCreationResponse_UAT();
		System.out.println("Newly Created Account is  " +Accountid);
				
		}
		else if(CurrURL.contains("--byjusqa")) {
			log.info("Logging in as Admin to QA Env");
			lo.LoginAsAdmin_QA();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_BTLA.AccountidCreationResponse_QA();
			log.info("Launching the newly created Account id "+Accountid);
		}
		else {
			log.info("Logging in as Admin to Prod");
			lo.LoginAsAdmin_Prod();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_BTLA.AccountidCreationResponse_Prod();
			log.info("Launching the newly created Account id "+Accountid);
		}
		
		closeTabWindows();
		
		lp2.NavigatetoURL(CurrURL+Accountid);
		Thread.sleep(5000);
		Scrollend();
		Thread.sleep(2000);
		element=PaymentsPO.link_paymentId(driver);
		scrollIntoView(element);
		
		jsClick(PaymentsPO.link_paymentId(driver)); //Click on "Payment id' in "Student Payment" section
		log.info("Clicked on PaymentID in Student Payments section");
		
		PaymentsPO.clickCreateCase(driver);
		
		log.info("Clicked on Create Case button");
		Thread.sleep(5000);
		
		PaymentsPO.enterLoanAmount(driver,al5.get(1));
		
		log.info("Entered loan amount");
		jsClick(PaymentsPO.button_Savebutton(driver)); //Click on 'Save' button
		
		Thread.sleep(5000);					
		Scrollend();
		Thread.sleep(5000);
		 element=PaymentsPO.label_CaseNumber(driver);	
		scrollIntoView(element);
		
		
		Thread.sleep(2000);
		
		String caseNumber=PaymentsPO.returnCaseNumber(driver); //Get the Case number
		
		PaymentsPO.clickCaseNumber(driver);
		log.info("Clicked on case number "+caseNumber+" in Cases section");
		System.out.println("Case Number is "+caseNumber);
		
				
		String AccountURL = driver.getCurrentUrl();
		
		if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
		js.executeScript("scroll(0,700);");
		jsClick(CreatedCaseRecordPO.button_EditAssignedTo(driver));;//click on "Edit' button for the "Assigned To" field
		ccr.EnterAssingedTo2(user1);
		log.info("Case is assigned to user "+user1+" ");
		ccr.ClickSave();
		lo.SwitchUser(user1);
		log.info("Switched to user"+user1+"");
		}
		else if(CurrURL.contains("--byjusuatfc")) {
			lo.SwitchUser(user4);
			ac.closeTabWindows();
			ac.Notification();
			driver.get(AccountURL);
			Thread.sleep(5000);	
			
			js.executeScript("scroll(0,700);");
			jsClick(CreatedCaseRecordPO.button_EditAssignedTo(driver));//click on "Edit' button for the "Assigned To" field
			ccr.EnterAssingedTo2(user1);
			log.info("Case is assigned to user "+user1+" ");
			ccr.ClickSave();
			lo.onlyLogoutAndSwitchToUser(driver,user1);
			log.info("Switched to user"+user1+"");
		}
		
		
		closeTabWindows();
		ac.Notification();
		
		ccr.searchCaseAndClick(caseNumber);
		log.info("Searched the case number# "+caseNumber+" for user "+user1+" ");
		Thread.sleep(1000);//Entered case number will be displayed below the search field which may take some time so sleep statem
		
		CreatedCaseRecordPO.clickFirstConnectlink(driver);
		log.info("Clicked onf First connect link");
		
		CreatedCaseRecordPO.clickNoCallConnectbutton(driver);
		log.info("Clicked on No Call Connect button");
		
		
		Thread.sleep(5000);
		
		retryForDetachedFrame(driver,CreatedCaseRecordPO.iframe_NoCallConnect, 0);
		WebElement frame=CreatedCaseRecordPO.iframe_NoCallConnect(driver);
		Thread.sleep(800);
		driver.switchTo().frame(frame);
		Thread.sleep(800);
		
		jsClick(CreatedCaseRecordPO.rbutton_LanguageBarrier(driver)); //Click on Language Barrier radio button
		log.info("Click on 'Language Barrier' radio button");
		Select PreferredLang= new Select(CreatedCaseRecordPO.dropdown_PreferredLanguage(driver));// code to select drop down
		PreferredLang.selectByVisibleText("Tamil");
		log.info("Selected lanuage");
		
		CreatedCaseRecordPO.enterPhoneNumber(driver, al6.get(1));
		log.info("Entered Phone Number");
		CreatedCaseRecordPO.enterComment(driver, al7.get(1));
		log.info("Entered Comment");
		CreatedCaseRecordPO.clickNextbutton(driver); //Click on 'Next' Button.
		log.info("Clcked on Next button");
		driver.switchTo().defaultContent();
		Thread.sleep(5000);
		
		lp2.onlyLogoutAndSwitchToUser(driver, user2);
		log.info("Logged Out and switched to user "+user2+"");
			
		
		closeTabWindows();
		
		ccr.searchCaseAndClick(caseNumber);
		log.info("Searched the case number# "+caseNumber+" for user "+user2+" ");		
		Thread.sleep(5000);//
		
		Assert.assertEquals(CreatedCaseRecordPO.static_text(driver).getText(),user2);
		log.info("Verified that case is assigned to user "+user2+"");
		CreatedCaseRecordPO.link_FollowUP(driver).click();// Click on the 'Follow-up' link
		ac.Notification();
		
		CreatedCaseRecordPO.button_AssignCase(driver).click();//click on 'Assign case' button
		CreatedCaseRecordPO.button_ClearSelection(driver).click();// click on 'Clear Selection' button (x).
		
		ccr.EnterAssingedTo2(user3);
		log.info("Case "+caseNumber+" is assigned to user "+user3+"");
		
		CreatedCaseRecordPO.button_AssignNext(driver).click();		
		Thread.sleep(5000);
		closeTabWindows();
	
		ccr.searchCaseAndClick(caseNumber);
		log.info("Searched the case number# "+caseNumber+" for user "+user3+" ");		
	
		Thread.sleep(5000);//Entered case number will be displayed below the search field which may take some time so sleep statem
		
		user5=CreatedCaseRecordPO.static_text2(driver).getText();
		Assert.assertEquals(user5,user3);
		log.info("Verified that case is assigned to user "+user3+"");
	}	
	

	  @AfterMethod(alwaysRun = true) public void teardown() throws
	  InterruptedException {  
	  
		 driver.quit(); 
	  
	  }

}

