package testCases;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pageObjects.CasesPO;
import pageObjects.CreatedAccountPO;
import pageObjects.InboundTaskPO;
import pageObjects.IssueTreePO;
import pageObjects.NewCaseRecordTypePO;
import pageObjects.UserSetupPO;
import pageObjects.loginPO;
import payLoad.payLoad_Logistics;
import resources.ExcelData;
import resources.base;



public class test_Logistics_Reg extends base {

	public WebDriver driver;
	//public String CurrURL;
	public static Logger log = LogManager.getLogger(test_Logistics_Reg.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> proddummyuser = new ArrayList<String>();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	ArrayList<String> al3 = new ArrayList<String>();
	
	@BeforeMethod(alwaysRun = true)
	public void initialize() throws IOException, InterruptedException {

		driver = initializeDriver();

	}
	

	@Test(groups = {"sanity", "Regression" },enabled = true)
	public void TestLogistics() throws Exception {
	    proddummyuser = excelData.getData("TC1", "ProdDummyUser", "Tcid");
		String Accountid = null;
		loginPO lo=new loginPO(driver);
		if(CurrURL.contains("--byjusuat")) {
		al = excelData.getData("TC2", "Logistics", "Tcid");
		al2 = excelData.getData("IRTO User UAT", "Login", "Type");
		log.info("Logging in as Admin to UAT");
		lo.LoginAsAdmin_UAT();
		log.info("Submitting the Account creation payload");
		Accountid=payLoad_Logistics.AccountidCreationResponse_UAT();
		log.info("Launching the newly created Account id "+Accountid);
		
		}
		else {
			al = excelData.getData("TC2", "Logistics", "Tcid");
			log.info("Logging in as Admin to Prod");
			lo.LoginAsAdmin_Prod();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_Logistics.AccountidCreationResponse_Prod();
			log.info("Launching the newly created Account id "+Accountid);
		}
		
		CasesPO cases=new CasesPO(driver);
		InboundTaskPO ibdt= new InboundTaskPO(driver);
		UserSetupPO us=new UserSetupPO(driver);
		IssueTreePO it=new IssueTreePO(driver);
		NewCaseRecordTypePO ncrt= new NewCaseRecordTypePO(driver);
		CreatedAccountPO ac= new CreatedAccountPO(driver);
		
		ac.closeTabWindows();
		ac.Notification();
		ac.NavBackToAccount();
		String AccountURL = CurrURL+Accountid;
		ac.goTo(CurrURL+Accountid);
		ac.AccountLoadwait();
		
		String MainWin = driver.getWindowHandle();
		
		//Logging in as IRT Outsourced user
		
		if(CurrURL.contains("--byjusuat")||CurrURL.contains("--byjusuatfc")) {
            String AccountOwner= ac.AccOwnerCheck();
            if(!al2.get(1).equalsIgnoreCase(AccountOwner)) {
                ac.AssignAccount(al2.get(1));
            }
        }
        else {
            ac.AssignAccount("Testing User");
        }
        
        if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
        lo.SwitchUser(al2.get(1));
        ac.CloseWindowArrayLast();
        driver.switchTo().window(MainWin);
        lo.RefreshURL();
        ac.closeTabWindows();
        ac.Notification();
        ac.NavBackToAccount();
        ac.goTo(AccountURL);
        ac.AccountLoadwait();
        }
        else {
            lo.SwitchUsernProfile_Prod(proddummyuser.get(1),"IRT Outsourced");
            ac.CloseWindowArrayLast();
            driver.switchTo().window(MainWin);
            lo.RefreshURL();
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AccountLoadwait();
        }
		
        //Creating Inbound case for Delivery Status Check Issue Type
        log.info("Creating Inbound Task");
        ac.ClickOpenActivitiestoNewTask();
        ncrt.SelectTaskRecordType("Inbound");
        ncrt.ClickNext();
        //ac.AdditionalWait();
        ncrt.ClickSave();
        ibdt.ClickCaptureDetail();		  
        ibdt.ClickProceedOptn();

		al2 = excelData.getData("Inbound", "Inbound", "Tcid");
		ibdt.SelectSpokeTo3(al2.get(1));
	    it.PremiumidSelector();
		it.ProgramSelector();
		it.ClickNext();
		ibdt.SelectPSTCT(al2.get(2));
		ibdt.ClickNext();
		it.IssueCategory(al.get(14));
		it.IssueType(al.get(15));
		if(CurrURL.contains("byjusprod.")) {
		    it.IssueSubType("Delivery is delayed");
		}
		else {
		        it.IssueSubType("Delivery is delayed");   
		    }
		it.IssueNotes(al.get(17));
		it.IstheIssueResolved(al.get(18));
		it.ClickNext2();
		it.ProductDetails(al.get(19));
		it.OrderID();
		it.UpdatedAddress(al.get(21));
		it.PinCode(al.get(22));
		it.CourierPartner(al.get(23));
		it.ClickNext2();
		ac.AdditionalWait();
		ac.RefreshTab_Targetframe_IT();
		log.info("Created case for Delivery Status Check Issue Type is: "+ibdt.CaptureRelatedToCaseNumber());
		
		//Verifying the case owner is a part of the queue
		ibdt.ClickRelatedToCaseNumber();
        String CaseOwner=cases.CaptureCaseOwner();

        //According to Issue tree logic this is to be with Logistics Control Tower queue
        if(CurrURL.contains("byjusprod.")) {
        us.NavtoQueue("Logistics NDR Team");
        }
        else {
        us.NavtoQueue("Logistics NDR Team");
        }
        lo.RefreshURL();
        us.VerifyPersonPresent(CaseOwner);
        ac.CloseWindowArrayLast();
        driver.switchTo().window(MainWin);
        ac.CloseSubTabs();
        
        
        //Creating Inbound case for Shipment Issues Check Issue Type
        log.info("Creating Inbound Task");
        ac.ClickOpenActivitiestoNewTask();
        ncrt.SelectTaskRecordType("Inbound");
        ncrt.ClickNext();
        //ac.AdditionalWait();
        ncrt.ClickSave();
        ibdt.ClickCaptureDetail();        
        ibdt.ClickProceedOptn();

        al = excelData.getData("TC3", "Logistics", "Tcid");
        ibdt.SelectSpokeTo3(al2.get(1));
        it.PremiumidSelector();
        it.ProgramSelector();
        it.ClickNext();
        ibdt.SelectPSTCT(al2.get(2));
        ibdt.ClickNext();
        it.IssueCategory(al.get(14));
        it.IssueType(al.get(15));
        if(CurrURL.contains("byjusprod.")) {
        it.IssueSubType("Missing/Lost Product/Damaged");
        }
        else {
            it.IssueSubType("Missing/Lost Product/Damaged");   
        }
        it.IssueNotes(al.get(17));
        it.IstheIssueResolved(al.get(18));
        it.ClickNext2();
        it.ProductDetails(al.get(19));
        it.OrderID();
        it.CourierPartner(al.get(23));
        it.Contactnumber(al.get(24));
        if(CurrURL.contains("byjusprod.")) {
        //it.Programdetails(al.get(25));
        it.UpdatedAddress(al.get(21));
        it.PinCode(al.get(22));
        it.Replacementreason(al.get(31));
        }
        it.ReasonForRedispatch(al.get(27));
        if(CurrURL.contains("--byjusuat")) {
            it.UpdatedAddress(al.get(21));
            it.PinCode(al.get(22));
            it.Replacementreason(al.get(31));
        }
        it.ClickNext2();
        ac.AdditionalWait();
        ac.RefreshTab_Targetframe_IT();
        log.info("Created case for Shipment Issues Issue Type is: "+ibdt.CaptureRelatedToCaseNumber());
        
        //Verifying the case owner is a part of the queue
        ibdt.ClickRelatedToCaseNumber();
        CaseOwner=cases.CaptureCaseOwner();
        
        //According to Issue tree logic this is to be with Logistics Revenue Team queue
        if(CurrURL.contains("byjusprod.")) {
        us.NavtoQueue("Logistics NDR Team");
        }
        else {
        us.NavtoQueue("Logistics NDR Team");
        }

        lo.RefreshURL();
        us.VerifyPersonPresent(CaseOwner);
        ac.CloseWindowArrayLast();
        driver.switchTo().window(MainWin);
        ac.CloseSubTabs();
        
        //Creating Inbound case for Last Mile Delivery Issues Issue Type
        log.info("Creating Inbound Task");
        ac.ClickOpenActivitiestoNewTask();
        ncrt.SelectTaskRecordType("Inbound");
        ncrt.ClickNext();
        //ac.AdditionalWait();
        ncrt.ClickSave();
        ibdt.ClickCaptureDetail();        
        ibdt.ClickProceedOptn();

        al = excelData.getData("TC4", "Logistics", "Tcid");
        ibdt.SelectSpokeTo3(al2.get(1));
        it.PremiumidSelector();
        it.ProgramSelector();
        it.ClickNext();
        ibdt.SelectPSTCT(al2.get(2));
        ibdt.ClickNext();
        it.IssueCategory(al.get(14));
        it.IssueType(al.get(15));
        it.IssueSubType(al.get(16));
        it.IssueNotes(al.get(17));
        it.IstheIssueResolved(al.get(18));
        it.ClickNext2();
        it.UpdatedAddress(al.get(21));
        it.PinCode(al.get(22));
        it.OrderID();
        it.CourierPartner(al.get(23));
        it.Contactnumber(al.get(24));
        if(CurrURL.contains("byjusprod.")) {
        //it.Productcategory(al.get(26));
        it.ProductDetails(al.get(19));
        }
        if(CurrURL.contains("--byjusuat")) {
            it.ProductDetails(al.get(19));
        }
        it.ClickNext2();
        ac.AdditionalWait();
        ac.RefreshTab_Targetframe_IT();
        log.info("Created case for Last Mile Delivery Issue Type is: "+ibdt.CaptureRelatedToCaseNumber());
        
        //Verifying the case owner is a part of the queue
        ibdt.ClickRelatedToCaseNumber();
        CaseOwner=cases.CaptureCaseOwner();
        
        //According to Issue tree logic this is to be with Logistics Revenue Team queue
        if(CurrURL.contains("byjusprod.")) {
        us.NavtoQueue("Logistics NDR Team");
        }
        else {
        us.NavtoQueue("Logistics NDR Team");
        }
        lo.RefreshURL();
        us.VerifyPersonPresent(CaseOwner);
        ac.CloseWindowArrayLast();
        driver.switchTo().window(MainWin);
        ac.CloseSubTabs();
        
        //Creating Inbound case for No Order Confirmation Issue Type
        log.info("Creating Inbound Task");
        ac.ClickOpenActivitiestoNewTask();
        ncrt.SelectTaskRecordType("Inbound");
        ncrt.ClickNext();
        ac.AdditionalWait();
        ncrt.ClickSave();
        ibdt.ClickCaptureDetail();        
        ibdt.ClickProceedOptn();

        al = excelData.getData("TC5", "Logistics", "Tcid");
        ibdt.SelectSpokeTo3(al2.get(1));
        it.PremiumidSelector();
        it.ProgramSelector();
        it.ClickNext();
        ibdt.SelectPSTCT(al2.get(2));
        ibdt.ClickNext();
        it.IssueCategory(al.get(14));
        it.IssueType(al.get(15));
        it.IssueSubType(al.get(16));
        it.IssueNotes(al.get(17));
        it.IstheIssueResolved(al.get(18));
        it.ClickNext2();
        ac.AdditionalWait();
        ac.RefreshTab_Targetframe_IT();
        log.info("Created case for No Order Confirmation Issue Type is: "+ibdt.CaptureRelatedToCaseNumber());
        
        //Verifying the case owner is a part of the queue
        ibdt.ClickRelatedToCaseNumber();
        CaseOwner=cases.CaptureCaseOwner();
        
        //According to Issue tree logic this is to be with Logistics Revenue Team queue
        us.NavtoQueue("Loan Verification Team");
        lo.RefreshURL();
        us.VerifyPersonPresent(CaseOwner);
        ac.CloseWindowArrayLast();
        driver.switchTo().window(MainWin);
        ac.CloseSubTabs();
        
        //Creating Inbound case for Order Punching Issue Type
        log.info("Creating Inbound Task");
        ac.ClickOpenActivitiestoNewTask();
        ncrt.SelectTaskRecordType("Inbound");
        ncrt.ClickNext();
        ac.AdditionalWait();
        ncrt.ClickSave();
        ibdt.ClickCaptureDetail();        
        ibdt.ClickProceedOptn();

        al = excelData.getData("TC6", "Logistics", "Tcid");
        ibdt.SelectSpokeTo3(al2.get(1));
        it.PremiumidSelector();
        it.ProgramSelector();
        it.ClickNext();
        ibdt.SelectPSTCT(al2.get(2));
        ibdt.ClickNext();
        it.IssueCategory(al.get(14));
        it.IssueType(al.get(15));
        it.IssueSubType(al.get(16));
        it.IssueNotes(al.get(17));
        it.IstheIssueResolved(al.get(18));
        it.ClickNext2();
        it.ProductDetails(al.get(19));
        it.UpdatedAddress(al.get(21));
        it.PinCode(al.get(22));
        it.OrderID();
        it.Programdetails(al.get(25));
        it.ReasonForRedispatch(al.get(27));
        it.Approvedby(al.get(28));
        it.Paymentdetails(al.get(29));
        it.ClickNext2();
        ac.AdditionalWait();
        //ac.RefreshTab_Targetframe_IT();
        
        
        //Verifying the case owner is a part of the queue
       // ibdt.ClickRelatedToCaseNumber();
        ac.AdditionalWait();
        ac.VerifyCSOPageLoad();
        ac.CloseCurrentSubTab();
        //log.info("Created case for Order Punching Issue Type is: "+ibdt.CaptureRelatedToCaseNumber());
        CaseOwner=cases.CaptureCaseOwner();
        
        //According to Issue tree logic this is to be with LSPD team queue
        if(CurrURL.contains("byjusprod.")) {
            us.NavtoQueue("LSPD");  
        }
        else {
        us.NavtoQueue("LSPD");
        }
        lo.RefreshURL();
        ac.AdditionalWait();
        us.VerifyPersonPresent(CaseOwner);
        ac.CloseWindowArrayLast();
        driver.switchTo().window(MainWin);
        ac.CloseSubTabs();
        
        
        //Creating Inbound case for Proof of Delivery Issue Type
        log.info("Creating Inbound Task");
        ac.ClickOpenActivitiestoNewTask();
        ncrt.SelectTaskRecordType("Inbound");
        ncrt.ClickNext();
        ac.AdditionalWait();
        ncrt.ClickSave();
        ibdt.ClickCaptureDetail();        
        ibdt.ClickProceedOptn();

        al = excelData.getData("TC7", "Logistics", "Tcid");
        ibdt.SelectSpokeTo3(al2.get(1));
        it.PremiumidSelector();
        it.ProgramSelector();
        it.ClickNext();
        ibdt.SelectPSTCT(al2.get(2));
        ibdt.ClickNext();
        it.IssueCategory(al.get(14));
        it.IssueType(al.get(15));
        it.IssueSubType(al.get(16));
        it.IssueNotes(al.get(17));
        it.IstheIssueResolved(al.get(18));
        it.ClickNext2();
        it.ProductDetails(al.get(19));
        it.PinCode(al.get(22));
        it.OrderID();
        it.CourierPartner(al.get(23));
        it.Dateoforderdelivery();
        it.ClickNext2();
        ac.AdditionalWait();
        ac.RefreshTab_Targetframe_IT();
        log.info("Created case for Proof of Delivery Issue Type is: "+ibdt.CaptureRelatedToCaseNumber());
        
        //Verifying the case owner is a part of the queue
        ibdt.ClickRelatedToCaseNumber();
        CaseOwner=cases.CaptureCaseOwner();
        
        //According to Issue tree logic this is to be with Logistics Revenue Team queue
        us.NavtoQueue("Logistics Revenue Team");
        lo.RefreshURL();
        us.VerifyPersonPresent(CaseOwner);
        ac.CloseWindowArrayLast();
        driver.switchTo().window(MainWin);
        ac.CloseSubTabs();
        lo.OnlyLogout();
        ac.goTo(AccountURL);
        ac.AdditionalWait();
		//ac.CloseSubTabs();
		
		
		//Deleting the Case record
		ac.ClickCasesMC2();
		cases.CloseAllCases();

		//Deleting the Account and Student payment details
		ac.ClickAccOwnrTab();
		log.info("Deleting the Student Program details");
		ac.DeleteCreatedStuProg();
		ac.DeleteAllCreatedStuPayment();
		ac.NavBackToAccount();
		log.info("Deleting the Account details");
		ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
		
		if(CurrURL.contains("--byjusuatfc")||CurrURL.contains("byjusprod.")) {
		log.info("Deleting the Cases present as My Cases");
		cases.NavMenuClick();
		cases.CaseNavMenuClick();
		cases.NavNEOL2QueueProd();
		cases.FilterbyMyCases();
		String FilterText = cases.CaptureFilterText();
		Assert.assertTrue(FilterText.contains("Filtered by My cases"));
		cases.DeleteAllMyCaseRecord();
		cases.SetBackDefault();
		}
		
	}
	
	  @AfterMethod(alwaysRun = true) public void teardown() throws
	  InterruptedException {
	  
	  driver.quit();
	  
	  //ac.AdditionalWait(); 
	  }
	 
	
	
}
