package testCases;


import java.io.IOException;

import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.openqa.selenium.WebDriver;

import org.testng.annotations.AfterMethod;

import org.testng.annotations.BeforeMethod;


import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import org.testng.Assert;

import pageObjects.CapturePaymentDetailsEMIPO;

import pageObjects.CasesPO;
import pageObjects.CollectionAssistantLoginPO;
import pageObjects.CreatedAccountPO;
import pageObjects.CreatedCaseRecordPO;
import pageObjects.FirstConnectPO;

import pageObjects.NPPaymentLoanPO;
import pageObjects.NewCaseDetailsPO;
import pageObjects.NewCaseRecordTypePO;
import pageObjects.NewPaymentPO;
import pageObjects.NewPaymentRecordPO;
import pageObjects.PaymentCaseQAPO;
import pageObjects.PaymentsPO;

import pageObjects.UserDetailPO;
import pageObjects.UserSetupPO;
import pageObjects.loginPO;
import resources.ExcelData;
import resources.base;

public class test_Collection_EMISuccessfull extends base {

	public WebDriver driver;
	//ThreadLocal<WebDriver> driver = new ThreadLocal<WebDriver>();
	//public String CurrURL;
	public static Logger log = LogManager.getLogger(test_CollectionFlow.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	ArrayList<String> al3 = new ArrayList<String>();
	ArrayList<String> al4 = new ArrayList<String>();
	ArrayList<String> al5 = new ArrayList<String>();
	String Colluser;
	static Faker faker = new Faker();
	static String firstName = faker.name().firstName();
	static String lastName = faker.name().lastName();
	static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);

	
	@BeforeMethod(alwaysRun = true)
	public void initialize() throws IOException, InterruptedException {

		driver = initializeDriver();
	}
	
	 
	 

	@Test(groups = { "sanity", "Regression" }, enabled = true)
	public void Collection_EMISuccessfull() throws Exception {
		
		loginPO lo=new loginPO(driver);
		if(CurrURL.contains("--byjusuatfc")) {
			al = excelData.getData("TC1", "CollectionFlow", "Tcid");
			al2 = excelData.getData("CollectionAssistant UATFC", "Login", "Type");
			al3 = excelData.getData("CollectionManager UATFC", "Login", "Type");
			al4 = excelData.getData("Adminuatfc", "Login", "Type");
			log.info("Logging in as Admin to UATFC");
			lo.LoginAsAdmin_UATFC();
			
			}
		else if(CurrURL.contains("--byjusuat")) {
		al = excelData.getData("TC1", "CollectionFlow", "Tcid");
		al2 = excelData.getData("CollectionAssistant UAT1", "Login", "Type");
		al3 = excelData.getData("CollectionManager UAT1", "Login", "Type");
		al4 = excelData.getData("AdminUAT", "Login", "Type");
		log.info("Logging in as Admin to UAT");
		lo.LoginAsAdmin_UAT1();
		//lo.SwitchUser(al2.get(1));
		
		}
		else {
			al = excelData.getData("TC1", "CollectionFlow", "Tcid");
	        al5 = excelData.getData("Dummy Collection Associate", "Login", "Type"); 
			al4 = excelData.getData("AdminProd", "Login", "Type");
			log.info("Logging in as Admin to Prod");
			lo.LoginAsAdmin_Prod();
		}
		//Assert.assertTrue(false);
		closeTabWindows();
		log.info("Creating new Payment record");
		CreatedAccountPO ac=new CreatedAccountPO(driver);
		PaymentsPO p = new PaymentsPO(driver);
		CasesPO cases=new CasesPO(driver);
		ac.Notification();
		p.NavMenuClick();
		p.PaymntNavMenuClick();
		p.NewPaymentClick();

		//Assert.assertTrue(false);

		log.info("Selection of Payment - Loan record");
		NewPaymentPO np = new NewPaymentPO(driver);
		np.SelectPaymentOptn(al.get(1));
		np.ClickNext();
		
		log.info("Enter New Payment - Loan details");
		NPPaymentLoanPO npp = new NPPaymentLoanPO(driver);
		//npp.EnterPayRefID(randomNum);
		npp.EnterParentFN(firstName);
		npp.EnterParentLN(lastName);
		npp.EnterLoanAmount(al.get(2));
		npp.EnterTenurity(al.get(4));
		npp.EnterProgramName(al.get(3));	
		// User Story SFDC-3499
		String epPartner1=npp.epPartnerCheck("Poonawalla");
		Assert.assertEquals("Poonawalla", epPartner1);	
		System.out.println("ep partner is : "+epPartner1);
		String epPartner2=npp.epPartnerCheck("Credit Saison");
		Assert.assertEquals("Credit Saison", epPartner2);	
		System.out.println("ep partner is : "+epPartner2);
		npp.EnterEPPartner(al.get(5));
		npp.EnterAmount(al.get(6));
		npp.EnterTotalAmountTBC(al.get(7));
		npp.EnterNetPayAmount(al.get(8));
		npp.EnterPaymentAmount(al.get(9));
		npp.EnterPaymentCategory(al.get(10));
		npp.EnterPaymentMS(al.get(11));
		npp.EnterPaymentDate(al.get(12));
		npp.EnterPaymentType(al.get(13));
		npp.ClickSave(); System.out.println("Payment URL : "+driver.getCurrentUrl());
		//Assert.assertTrue(false);
		NewPaymentRecordPO npr = new NewPaymentRecordPO(driver);
		String PaymentRecord = npr.CapturePaymentRcdID();
		log.info("New Payment Record " + PaymentRecord + " created successfully");
		npr.ClickCasesQA();

		log.info("Creating New Case Record for " + PaymentRecord);
		PaymentCaseQAPO pcqa = new PaymentCaseQAPO(driver);
		pcqa.ClickCaseNewButton(PaymentRecord);

		NewCaseRecordTypePO ncrt = new NewCaseRecordTypePO(driver);
		ncrt.SelectCaseRecordType(al.get(14));
		ncrt.ClickNext();

		NewCaseDetailsPO ncd = new NewCaseDetailsPO(driver);
		Thread.sleep(1200);
		//user story SFDC-3498
		ncd.enterEMIamount(al.get(6));
		ncd.EnterSubject(al.get(43));
		if(CurrURL.contains("--byjusuatfc")) {
		ncd.EnterOrders(randomNum);
		ncd.SelectReasonForRefund(al.get(44));
		}
		ncd.ClickSave();System.out.println("Case URL : "+driver.getCurrentUrl());

		CreatedCaseRecordPO ccr = new CreatedCaseRecordPO(driver);
		String CaseRecord = ccr.CaptureNewCaseRecord();
		log.info("New Case Record " + CaseRecord + " created successfully");
		
		String AccountURL = driver.getCurrentUrl();
		
		if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
		ccr.ClickAssingedTo();
		ccr.EnterAssingedTo2(al2.get(1));
		ccr.ClickSave();
		}
		else if(CurrURL.contains("--byjusuatfc")) {
			lo.SwitchUser(al4.get(3));
			ac.closeTabWindows();
			ac.Notification();
			//ac.NavBackToAccount();
			ac.goTo(AccountURL);
			Thread.sleep(5000);	
			ccr.ClickAssingedTo();
			ccr.EnterAssingedTo2(al2.get(1));
			ccr.ClickSave();
		}
		else {// manali here... 
		ccr.ClickAssingedTo();
        ccr.EnterAssingedTo2(al5.get(1));
        ccr.ClickSave();
			//ccr.CaseOwnrUpdate_Prod(al2.get(1));
		}
		
		if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
		Colluser = MailFullName(al2.get(1));
		//Logging in as the assigned user
		ccr.ClickAssignedUser2(al2.get(1));
	    log.info("Logging in as Collection Assistant " + FullName(al2.get(1)));
		} else {
		    Colluser = MailFullName(al5.get(1));
	        //Logging in as the assigned user
	        ccr.ClickAssignedUser2(al5.get(1));
	        log.info("Logging in as Collection Assistant " + FullName(al5.get(1)));
		}
	    UserDetailPO ud = new UserDetailPO(driver); 
	    ud.ClickUserDetailbutton();
	  
	    if(CurrURL.contains("--byjusuatfc")) {
	    	AccountURL = driver.getCurrentUrl();
	    	lo.OnlyLogout();
	    	ac.goTo(AccountURL);
			Thread.sleep(4000);	
	    }
	    
	    UserSetupPO us = new UserSetupPO(driver); 
	    us.ClickLoginbutton();
		 
		CollectionAssistantLoginPO cal = new CollectionAssistantLoginPO(driver);
		cal.ClickBellicon();
//		al2 = excelData.getData("Admin", "Login", "Type");
		if(CurrURL.contains("--byjusuatfc")) {
		cal.SelectAssignedTask(taskName(al4.get(3)));
		}
		else {
			cal.SelectAssignedTask(taskName(al4.get(1)));	
		}
		FirstConnectPO fc = new FirstConnectPO(driver);
		String Firstconnect_caseid = fc.CaptureFCcaseid();
		// Compare the Case Record to First connect case Record
		Assert.assertEquals(CaseRecord, Firstconnect_caseid);
		log.info("Providing Capture payment detail for Case record " + Firstconnect_caseid);
		fc.ClickCapturePayment();

		CapturePaymentDetailsEMIPO cpd = new CapturePaymentDetailsEMIPO(driver);
		cpd.EnterRating(al.get(15));
		cpd.ClickNext();
		cpd.SelectPaymntOptn(al.get(16));
		log.info("Selected the payment option " + al.get(16));
		cpd.ClickNext();
		//user story SFDC-3498
		Assert.assertEquals(cpd.getAmtpaid(), al.get(6));
		cpd.EnterAmtpaid(al.get(17));
		
		// User Story SFDC-3068
		String paymentOption1=cpd.verifyPaymntOptn(al.get(45));
		Assert.assertEquals("ICICI UPI", paymentOption1);	
		System.out.println("New Payment Method added : "+paymentOption1);
		//User Story SFDC-3620
		String paymentOption2=cpd.verifyPaymntOptn(al.get(46));		
		Assert.assertEquals("Paytm", paymentOption2);	
		System.out.println("New Payment Method added : "+paymentOption2);		
		cpd.SelectPaymentMethod(al.get(18));
		cpd.SelectCollectionchannel(al.get(19));
		//Entering duplicate Ref number
		if(CurrURL.contains("--byjusuat")){
		cpd.EnterDupPaymentRef();		
		cpd.ClickNext();
		String PRerror = cpd.CaptureErrorMess();
		// Verify the Error message is Matching.
		Assert.assertEquals(PRerror,
				"Audit Cases are found with the same Payment Reference.Kindly provide the different Payment Reference Id");
		}
		cpd.EnterPaymntRefVal(randomNum);
		cpd.ClickNext();
		cpd.SelectEMIcoll(al.get(20));
		cpd.SelectTypofCollPaid(al.get(21));
		cpd.ClickNext();
		cpd.SelectElgfrRef(al.get(22));
		cpd.ClickNext();
		Thread.sleep(4000);
		
		String Firstconnect_status = fc.CheckFCStatus();
		// Verify the Status for first connect is changed to Completed
		Assert.assertEquals(Firstconnect_status, "Completed");
		String Firstconnect_callstatus = fc.CheckFCCallStatus();
		// Verify the Call Status for first connect is changed to Payment Confirmed
		Assert.assertEquals(Firstconnect_callstatus, "Payment Confirmed");

		log.info("Logging out as Collection Assistant");
		//cal.CloseNotification();
		Thread.sleep(1000);
		//cal.Logout();
		lo.Logouthome();


		log.info("Verifying the Payment/Case Status are correct");
		ac.CloseSubTabs();
		p.NavCaseTab(CaseRecord);
		
		if(CurrURL.contains("--byjusuatfc")) {
			cases.ClickRelatedTab();
			
		}
		
		String CaseStatus = ccr.CaseStatusval();
		String CaseOwner = ccr.CaseOwnerval();
		log.info("The record number for newly created Case record is " + ccr.CaptureNewCaseRecord());
		// Verify the Case Status is changed to Audit Pending
		Assert.assertEquals(CaseStatus, "Audit Pending");
		// Verify the Case owner is same
		Assert.assertTrue(CaseOwner.equalsIgnoreCase(Colluser));
		//user story SFDC-2569
		p.NavPaymentTab(PaymentRecord);
		p.clickCreateCase();
		driver.navigate().refresh();
		Thread.sleep(1000);
		String[] data=p.getPriorityDateTime();
		Assert.assertEquals(data[0], "Priority Date/Time");
		//Assert.assertEquals(data[1], data[2]);
		p.NavCaseTab(CaseRecord);
		String RelatedCaseRecord= ccr.CaptureRelatedCase();
		log.info("Deleting the Related Case Record " +RelatedCaseRecord);
		
		ccr.DeleteRelatedCaseRecord(RelatedCaseRecord);
		
		log.info("Deleting the created Case Record " +CaseRecord);
		p.NavCasesTab();
		

		cases.DeleteCCaseRecord(CaseRecord);
		String caseNumb=p.getCaseNumber();
		cases.DeleteCCaseRecord(caseNumb);
		log.info("Deleting the created Payment Record " + PaymentRecord);
		p.NavMenuClick();
		p.PaymntNavMenuClick();
		p.DeletePayRecord(PaymentRecord);

	}

	
	@AfterMethod(alwaysRun = true)
	public void teardown() throws InterruptedException {

		driver.quit();

	}

}
