package testCases;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import pageObjects.CasesPO;
import pageObjects.CreatedAccountPO;
import pageObjects.InboundTaskPO;
import pageObjects.IssueTreePO;
import pageObjects.NewCaseDetailsPO;
import pageObjects.NewCaseRecordTypePO;
import pageObjects.loginPO;
import payLoad.payLoad_Logistics;
import resources.ExcelData;
import resources.base;



public class test_Logistics extends base {

	public WebDriver driver;
	//public String CurrURL;
	public static Logger log = LogManager.getLogger(test_Logistics.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	static Faker faker = new Faker();
	static String firstName = faker.name().firstName();
	static String lastName = faker.name().lastName();
	static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);
	
	@BeforeMethod(alwaysRun = true)
	public void initialize() throws IOException, InterruptedException {

		driver = initializeDriver();

	}
	

	@Test(priority =5,groups = {"sanity", "Regression" },enabled = true)
	public void TestLogistics() throws Exception {
		String Accountid = null;
		loginPO lo=new loginPO(driver);
		if(CurrURL.contains("--byjusuatfc")) {
			//al = excelData.getData("TC1", "Logistics", "Tcid");
			al = excelData.getData("TC2", "Logistics", "Tcid");
			
			log.info("Logging in as Admin to UATFC");
			lo.LoginAsAdmin_UATFC();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_Logistics.AccountidCreationResponse_UATFC();
			log.info("Launching the newly created Account id "+Accountid);
			
			}
		else if(CurrURL.contains("--byjusuat")) {
		al = excelData.getData("TC2", "Logistics", "Tcid");
		
		
		log.info("Logging in as Admin to UAT");
		lo.LoginAsAdmin_UAT();
		log.info("Submitting the Account creation payload");
		Accountid=payLoad_Logistics.AccountidCreationResponse_UAT();
		log.info("Launching the newly created Account id "+Accountid);
		
		}
		else if(CurrURL.contains("--byjusqa")) {
			//al = excelData.getData("TC1", "Logistics", "Tcid");
			al = excelData.getData("TC2", "Logistics", "Tcid");
			//al2 = excelData.getData("Collection Assistant QA", "Login", "Type");
			log.info("Logging in as Admin to QA Env");
			lo.LoginAsAdmin_QA();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_Logistics.AccountidCreationResponse_QA();
			log.info("Launching the newly created Account id "+Accountid);
		}
		else {
			//al = excelData.getData("TC1", "Logistics", "Tcid");
			al = excelData.getData("TC2", "Logistics", "Tcid");
			//al2 = excelData.getData("Collection Assistant", "Login", "Type");
			log.info("Logging in as Admin to Prod");
			lo.LoginAsAdmin_Prod();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_Logistics.AccountidCreationResponse_Prod();
			log.info("Launching the newly created Account id "+Accountid);
		}
		
		closeTabWindows();
		Thread.sleep(1000);
		CreatedAccountPO ac= new CreatedAccountPO(driver);
		ac.Notification();
		ac.NavBackToAccount();
		ac.goTo(CurrURL+Accountid);
		ac.AccountLoadwait();
		//Assert.assertTrue(false);
		log.info("Creating Inbound Task");
		ac.ClickOpenActivitiestoNewTask();
		
		NewCaseRecordTypePO ncrt= new NewCaseRecordTypePO(driver);
		ncrt.SelectCaseRecordTypeInbound();
		ncrt.ClickNext();
		Thread.sleep(2000);
		ncrt.ClickSave();
		Thread.sleep(2000);
		
		InboundTaskPO ibdt= new InboundTaskPO(driver);
			
		ibdt.ClickCaptureDetail();		  
		ibdt.ClickProceedOptn();

		al2 = excelData.getData("Inbound", "Inbound", "Tcid");		
		if(CurrURL.contains("--byjusuat")||CurrURL.contains("--byjusuatfc")||CurrURL.contains("byjusprod.")) {
		IssueTreePO it=new IssueTreePO(driver);
		if(!CurrURL.contains("--byjusuatfc")) {
	    ibdt.SelectSpokeTo3(al2.get(1));
		it.PremiumidSelector();
		it.ProgramSelector();
		it.ClickNext();
		}
		ibdt.SelectPSTCT(al2.get(2));
		//ibdt.EnterNotesVal(al2.get(3));
		ibdt.ClickNext();
		it.IssueCategory(al.get(14));
		it.IssueType(al.get(15));
		it.IssueSubType(al.get(16));
		it.IssueNotes(al.get(17));
		it.IstheIssueResolved(al.get(18));
		it.ClickNext2();
		it.ProductDetails(al.get(19));
		it.OrderID();
		it.UpdatedAddress(al.get(21));
		it.PinCode(al.get(22));
		it.CourierPartner(al.get(23));
		it.ClickNext2();
		}
		else {
			ibdt.SelectPSTCT(al.get(1));
			//ibdt.EnterNotesVal(al.get(2));
			ibdt.ClickNext();
			ibdt.SelectDevice(al.get(3));
			ibdt.SelectCategory(al.get(4));
			ibdt.SelectSubCategory(al.get(5));
			ibdt.SelectIssueSubType(al.get(6));
			ibdt.SelectIssueResolved(al.get(7));
			ibdt.ClickNext();
			Thread.sleep(2000);
		}
		
		ibdt.NavBackAccount();
		
		if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")){
			ac.Scrollpagedown();
		}
		ac.CloseSubTabs();
		ac.ClickCasesMC();
		
		CasesPO cases= new CasesPO(driver);
		
		String CaseNumber= cases.CaseRN();
		log.info("The case number created is: "+CaseNumber);
		cases.CaseOptnSel();
		
		NewCaseDetailsPO ncd= new NewCaseDetailsPO(driver);
		
		String IssueCategory= ncd.CaptureIssueCategory();
		if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
		Assert.assertEquals(IssueCategory, "Logistics");
		}
		else {
		    Assert.assertEquals(IssueCategory, "Logistics");	
		}
		

		//if(CurrURL.contains("--byjusuatfc") || CurrURL.contains("byjusprod.")) {
		//String Device= ncd.CaptureDevice();
		//Assert.assertEquals(Device, al.get(3));
		//String IssueSubType= ncd.CaptureIssueSubType();
		//Assert.assertEquals(IssueSubType, al.get(6));
		//}
		

		if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
			cases.DeleteCCaseRecord(CaseNumber);
		}
		else {
			cases.DeleteCCaseRecord(CaseNumber);
		}
		
		CreatedAccountPO ac1=new CreatedAccountPO(driver);
		ac1.ClickAccOwnrTab();
		Thread.sleep(1000);
		log.info("Deleting the Student Program details");
		ac1.DeleteCreatedStuProg();
		
		ac1.NavBackToAccount();
		log.info("Deleting the Account details");
		ac1.DeleteAccountCreated(ac1.CaptureAccOwnrNam());
		
		if(CurrURL.contains("--byjusuatfc")||CurrURL.contains("byjusprod.")) {
		log.info("Deleting the Cases present as My Cases");
		cases.NavMenuClick();
		cases.CaseNavMenuClick();
		cases.NavNEOL2QueueProd();
		cases.FilterbyMyCases();
		String FilterText = cases.CaptureFilterText();
		Assert.assertTrue(FilterText.contains("Filtered by My cases"));
		cases.DeleteAllMyCaseRecord();
		cases.SetBackDefault();
		}
		
	}
	
	  @AfterMethod(alwaysRun = true) public void teardown() throws
	  InterruptedException {
	  
	  driver.quit();
	  
	  //Thread.sleep(2000); 
	  }
	 
	
	
}
