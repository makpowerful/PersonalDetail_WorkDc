package testCases;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import pageObjects.CreatedAccountPO;
import pageObjects.ExamDetailsPO;
import pageObjects.MentorFollowUpTaskPO;
import pageObjects.NewCaseRecordTypePO;
import pageObjects.OutboundTaskPO;
import pageObjects.PEFollowUpTaskPO;
import pageObjects.PEOnBoardingTaskPO;
import pageObjects.PEShippedTaskPO;
import pageObjects.SessionsInformationPO;
import pageObjects.StudentAppInfoPO;
import pageObjects.StudentCRAssoPO;
import pageObjects.StudentSubOrderPO;
import pageObjects.loginPO;
import payLoad.payLoad_NeoClasses;
import resources.ExcelData;
import resources.base;



public class test_NeoClasses extends base {

	public WebDriver driver;
	//public String CurrURL;
	public static Logger log = LogManager.getLogger(test_NeoClasses.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> proddummyuser = new ArrayList<String>();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	ArrayList<String> al3 = new ArrayList<String>();
	ArrayList<String> al4 = new ArrayList<String>();
	ArrayList<String> al5 = new ArrayList<String>();
	static Faker faker = new Faker();
	static String firstName = faker.name().firstName();
	static String lastName = faker.name().lastName();
	static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);
	
	@BeforeMethod(alwaysRun = true)
	public void initialize() throws IOException, InterruptedException {

		driver = initializeDriver();

	}
	
	
	@Test(groups = {"sanity", "UAT" }, enabled = true)
	public void TestNeoClasses() throws Exception {
	    proddummyuser = excelData.getData("TC1", "ProdDummyUser", "Tcid");
		String Accountid = null;
		String StudentClassroom = null;
		String StudentAppInfo1 = null;
		String StudentAppInfo2 = null;
		loginPO lo=new loginPO(driver);
		al3 = excelData.getData("Neo", "Outbound", "Tcid");
		al5 = excelData.getData("Mentor-Follow", "Outbound", "Tcid");
		if(CurrURL.contains("--byjusuatfc")) {
		al = excelData.getData("TC1", "Neo", "Tcid");
		//al2 = excelData.getData("Collection Assistant", "Login", "Type");
		
		log.info("Logging in as Admin to UATFC");
		lo.LoginAsAdmin_UATFC();
		log.info("Submitting the Account creation payload");
		Accountid=payLoad_NeoClasses.AccountidCreationResponse_UATFC();
		payLoad_NeoClasses.ClassRoomMappingResponse_UATFC();
		payLoad_NeoClasses.StudentAppInfoResponse_UATFC();
		log.info("Launching the newly created Account id "+Accountid);
		
		}
		else if(CurrURL.contains("--byjusuat")) {
			al = excelData.getData("TC1", "Neo", "Tcid");
			//al2 = excelData.getData("Collection Assistant", "Login", "Type");
			
			log.info("Logging in as Admin to UAT");
			lo.LoginAsAdmin_UAT();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_NeoClasses.AccountidCreationResponse_UAT();
			payLoad_NeoClasses.StudentClassRoomAdd_UAT();
			payLoad_NeoClasses.ClassRoomMappingResponse_UAT();
			payLoad_NeoClasses.StudentAppInfoResponse_UAT();
			StudentClassroom = payLoad_NeoClasses.StudentClassRoomid_UAT();
			StudentAppInfo1 = payLoad_NeoClasses.StudentAppInfoid1_UAT();
			StudentAppInfo2 = payLoad_NeoClasses.StudentAppInfoid2_UAT();
			log.info("Launching the newly created Account id "+Accountid);
		
		}
		else if(CurrURL.contains("--byjusqa")) {
			al = excelData.getData("TC1", "Neo", "Tcid");
			//al2 = excelData.getData("Collection Assistant QA", "Login", "Type");
			log.info("Logging in as Admin to QA Env");
			lo.LoginAsAdmin_QA();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_NeoClasses.AccountidCreationResponse_QA();
			log.info("Launching the newly created Account id "+Accountid);
		}
		else {
			al = excelData.getData("TC1", "Neo", "Tcid");
			//al2 = excelData.getData("Collection Assistant", "Login", "Type");
			log.info("Logging in as Admin to Prod");
			lo.LoginAsAdmin_Prod();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_NeoClasses.AccountidCreationResponse_Prod();
			payLoad_NeoClasses.ClassRoomMappingResponse_Prod();
			payLoad_NeoClasses.StudentAppInfoResponse_Prod();
			log.info("Launching the newly created Account id "+Accountid);
		}
		
		
		
		CreatedAccountPO ac=new CreatedAccountPO(driver);
		//Open the account by searching PID
		ac.closeTabWindows();
		ac.Notification();
		ac.NavBackToAccount();
		String AccountURL = CurrURL+Accountid;
		ac.goTo(CurrURL+Accountid);
		ac.AccountLoadwait();
		
		//Setting  SSO to Shipped status
		log.info("Navigating to Student sales order");
		
		StudentSubOrderPO Ssub=new StudentSubOrderPO(driver);
		ac.ClickStudentSalesOrder();
		Ssub.ClickOrderinOrders();
		Ssub.SelectStatus("Shipped");
		Ssub.ClickSave();
		

		
		ac.ClickAccOwnrTab();
		ac.RefreshTab();
		
		
		String PremiumID = ac.CapturePremiumID();
		if(PremiumID!=null) {
			Assert.assertTrue(true);
		}
		log.info("The Premium id is "+PremiumID);
		
		//Verify Account is created with Student order,Student Payment in it
		Assert.assertTrue(ac.CheckVisSalesStudentOrderid());
		ac.CaptureStudentSalesOrder();	
		
		Assert.assertTrue(ac.CheckVisStudentPayid());
		ac.CaptureAllStudentPayid();
		ac.CheckVisStudentPrgid();
		ac.CaptureAllStudentProgDetails();
		
		//Verify  Neo Classes  program is created in student program related list
		String Progval = ac.CapturePrgCreated();
		Assert.assertEquals(Progval, "Neo Classes");
		
		//Verify Account super status and status is PE/First60 and New
		
		String SuperStatus = ac.CaptureSuperStatus();
		Assert.assertTrue(SuperStatus.contains("First60"));
		
		String Status = ac.CaptureStatus();
		Assert.assertEquals(Status, "New");
		ac.Scrollpagedown();
		
		
		
		//Verify the PE Shipped all is created
		Assert.assertTrue(ac.CheckVisPEShippedCall());
		  
		log.info("Navigating to PE Shipped Call tasks");
		ac.ClickPEShipped();
		
		PEShippedTaskPO pes=new PEShippedTaskPO(driver);
		pes.ClickCaptureDetail();
		log.info("Selecting Capture Call as Proceed for PE Shipped Task");
		pes.SelectProceed_iframe();
		pes.SelectProceedIAFO(al.get(1));
		pes.SelectProceedDOBA(al.get(2));
		pes.SelectProceedLP(al.get(3));
		pes.SelectProceedRFP(al.get(4));
		pes.SelectProceedPCOS(al.get(5));
		pes.SelectProceedCE(al.get(6));
		pes.SelectProceedST(al.get(7));
		pes.SelectProceedWOIS(al.get(12));
		pes.SelectProceedNotes(al.get(13));
		pes.SelectProceedIsThereIssue(al.get(20));
		pes.NavBackAccount();
		
		log.info("Navigating to Student sales order");
	
		ac.ClickStudentSalesOrder();
		Assert.assertTrue(ac.CheckExistingProfile());//Added check for SFTNL-6458
		Ssub.ClickOrderinOrders();
		Ssub.SelectSSOStatus();
		Ssub.ClickSave();

		
		ac.ClickAccOwnrTab();
		ac.RefreshTab();
		
		ac.ClickPersonAccount();
		
		log.info("Navigating to PE On boarding Call tasks");
		//Verify PE Onboarding call task is created when the SSO status moved to Partial delivered/delivered
		Assert.assertTrue(ac.CheckVisPEOnboardingCall());
		ac.CloseSubTabs();
		ac.ClickPEOnboardngCall();
		
		
		PEOnBoardingTaskPO peob=new PEOnBoardingTaskPO(driver);
		peob.ClickCaptureDetail();
		log.info("Selecting Capture Call as Proceed for PE Onboarding Task");
		peob.SelectProceed_iframe();
		peob.ClickOnboardingScreenNext();
		peob.SelectProceedS_T(al.get(92)); //Created with SFDC-2419 2.0
		peob.SelectProceedHTPTMCA(al.get(134));
		peob.EnterNotes(al.get(93)); //Created with SFDC-2419 2.0
		peob.SelectSHAACLOC(al.get(94)); //Created with SFDC-2419 2.0
		peob.SelectProductRating(al.get(95)); //Created with SFDC-2419 2.0
		peob.SelectNotLikeProduct(al.get(96)); //Created with SFDC-2419 2.0
		peob.SelectTeacherRating(al.get(97)); //Created with SFDC-2419 2.0
		peob.SelectNotLikeTeacher(al.get(98)); //Created with SFDC-2419 2.0
		peob.SelectContentRating(al.get(99)); //Created with SFDC-2419 2.0
		peob.SelectNotLikeContent(al.get(100)); //Created with SFDC-2419 2.0
		peob.SelectStudentAppUsage(al.get(101)); //Created with SFDC-2419 2.0
		peob.SelectTLPOnboardngDone(al.get(102)); //Created with SFDC-2419 2.0		
		peob.SelectProceedIsThereIssue2(al.get(33));
		peob.NavBackAccount();
		
		//****************************************************Zoom**********************
		//if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
		//ac.AssignAccount2();
		//}
		//if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
		//Verify once the PE Onboarding call is completed, Follow up task is created on the account 
		Assert.assertTrue(ac.CheckVisFollowUpTutorandMentorCall());
		ac.CloseSubTabs();
		ac.ClickFollowUpTutorandMentorCall();
			
		PEFollowUpTaskPO pefu= new PEFollowUpTaskPO(driver);
		pefu.ClickCaptureDetail();
		log.info("Selecting Capture Call as Proceed for PE Follow Up Task 1");
			
		//Verify once the Follow up  is completed, Follow up 1 task is created on the account
		pefu.SelectProceed_iframe();
				
		String FollowUpheader1 = pefu.FollowUpHeader_iframe();
		Assert.assertTrue(FollowUpheader1.contains("Follow Up"));
		pefu.SelectProceedST(al.get(66));
		pefu.SelectProceedSAU(al.get(67));
		pefu.SelectProceedNotes(al.get(68));
		//pefu.SelectProceedZoom(al.get(135));
		pefu.ClickNext();
		pefu.SelectProceedIsThereIssue2(al.get(45));
		pefu.NavBackAccount();
			


		//Verify once the PE Onboarding call is completed, Follow up task is created on the account 
		Assert.assertTrue(ac.CheckVisFollowUpTutorandMentorCall());
		ac.CloseSubTabs();
		ac.ClickFollowUpTutorandMentorCall();
			
		pefu.ClickCaptureDetail();
		log.info("Selecting Capture Call as Proceed for PE Follow Up Task 2");
			
		//Verify once the Follow up  is completed, Follow up 2 task is created on the account
		pefu.SelectProceed_iframe();

		String FollowUpheader2 = pefu.FollowUpHeader_iframe();
		Assert.assertTrue(FollowUpheader2.contains("Follow Up"));
		pefu.SelectProceedST(al.get(66));
		pefu.SelectProceedSAU(al.get(67));
		pefu.SelectProceedNotes(al.get(68));
		pefu.ClickNext();
		pefu.SelectProceedSHAACSLOC(al.get(59));
		pefu.SelectProceedIsThereIssue2(al.get(59));
		pefu.NavBackAccount();
			
		//Verify once the PE Onboarding call is completed, Follow up task is created on the account 
		Assert.assertTrue(ac.CheckVisFollowUpTutorandMentorCall());
		ac.CloseSubTabs();
		ac.ClickFollowUpTutorandMentorCall();
			
		pefu.ClickCaptureDetail();
		log.info("Selecting Capture Call as Proceed for PE Follow Up Task 3");
			
		//Verify once the Follow up  is completed, Follow up 3 task is created on the account
		pefu.SelectProceed_iframe();

		pefu.SelectProceedST(al.get(66));
		pefu.SelectProceedSAU(al.get(67));
		pefu.SelectProceedNotes(al.get(68));
		pefu.ClickNext();
		pefu.SelectProceedIsThereIssue2(al.get(59));
		pefu.NavBackAccount();
		ac.CloseSubTabs();

		al4 = excelData.getData("Mentor User UAT", "Login", "Type");
		if(CurrURL.contains("--byjusuat")||CurrURL.contains("--byjusuatfc")) {
			String AccountOwner= ac.AccOwnerCheck();
			if(!al4.get(1).equalsIgnoreCase(AccountOwner)) {
				ac.AssignAccount(al4.get(1));
			}
		}
		else {
			ac.AssignAccount("Testing User");
		}
			
		log.info("Creating Mentor Onboarding Task");
		ac.ClickOpenActivitiestoNewTask();
		NewCaseRecordTypePO ncrt= new NewCaseRecordTypePO(driver);
		
		ncrt.SelectCaseRecordType("Mentor - Onboarding Call");
		ncrt.ClickNext();
		ncrt.EnterSubject("Mentor - Onboarding Call");
		ncrt.ClickSave();
		Thread.sleep(2000);
		
		if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
			lo.SwitchUser(al4.get(1));
			ac.closeTabWindows();
			ac.Notification();
			ac.NavBackToAccount();
			ac.goTo(AccountURL);
			ac.AccountLoadwait();	
			}
			else if(CurrURL.contains("--byjusuatfc")) {
				lo.SwitchUser(al4.get(1));
				ac.closeTabWindows();
				ac.Notification();
				ac.NavBackToAccount();
				ac.goTo(AccountURL);
				ac.AccountLoadwait();

			}
			else {
				lo.SwitchUsernProfile_Prod(proddummyuser.get(1),"Mentor");
				ac.closeTabWindows();
				ac.Notification();
				ac.NavBackToAccount();
				ac.goTo(AccountURL);
				ac.AccountLoadwait();
			}
		
		//Verify Mentor Onboarding call task is created 
		Assert.assertTrue(ac.CheckVisMentorOnboardingCall());
		ac.CloseSubTabs();
		ac.ClickMentorOnboardngCall();
		
		OutboundTaskPO ob= new OutboundTaskPO(driver);
		ob.ClickCaptureDetail();
		ob.SelectProceed_iframe();
		ob.SelectProceedST(al3.get(1));
		ob.SelectOnboardingSurvey(al3.get(2));
		ob.SelectStudyPlanStatus(al3.get(3));
		ob.SelectPriCaretakerStudies(al3.get(4));
		ob.ClickNext();
		pefu.SelectProceedSHAACSLOC(al.get(59));
		
		
		if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
			ob.SelectProceedIsThereIssue2(al3.get(5));
			ob.ClickNext();
		}
		else {
			//ob.SelectProceedIsThereIssue(al3.get(5));
		    ob.SelectProceedIsThereIssue2(al3.get(5));
            ob.ClickNext();
		}
			
		peob.NavBackAccount();
			
		//Verify once the Mentor Onboarding call is completed, Mentor Follow up task is created on the account 
		Assert.assertTrue(ac.CheckVisMentorFollowUpCall());
		ac.CloseSubTabs();
		ac.ClickMentorFollowUpCall();
		
		MentorFollowUpTaskPO mfu= new MentorFollowUpTaskPO(driver);
		mfu.ClickCaptureDetail();
		log.info("Selecting Capture Call as Proceed for Mentor Follow Up Task 1");
		
		//Verify once the Follow up  is completed, Follow up 1 task is created on the account
		pefu.SelectProceed_iframe();
			
		String MentorFollowUpheader1 = mfu.FollowUpHeader_iframe();
		Assert.assertTrue(MentorFollowUpheader1.contains("Follow Up"));
		mfu.SelectProceedST(al5.get(1));
		mfu.SelectProceedSPS(al5.get(7));
		mfu.ClickNext();
		mfu.SelectProceedSHAAC(al5.get(10));
			

		mfu.SelectProceedIsThereIssue2(al5.get(10));
		mfu.ClickNext();
	    pefu.NavBackAccount();
			
		lo.OnlyLogout();
		ac.goTo(AccountURL);
		ac.AccountLoadwait();
		ac.CloseSubTabs();
			
		//*****************************************************************************************//
			
		//Verify Session Attended is Created
			
		SessionsInformationPO si = new SessionsInformationPO(driver);
		log.info("Sending the Session Attended API");
		if(CurrURL.contains("--byjusuatfc")) {
			payLoad_NeoClasses.SessionAttendedResponse_UATFC();
		    Thread.sleep(2500);
			}
		else if(CurrURL.contains("--byjusuat")) {
		payLoad_NeoClasses.SessionAttendedResponse_UAT();
	    Thread.sleep(2500);
		}
		else if(CurrURL.contains("--byjusqa")) {
			payLoad_NeoClasses.SessionAttendedResponse_QA();
		    Thread.sleep(2500);
			}
		else {
			payLoad_NeoClasses.SessionAttendedResponse_Prod();
		    Thread.sleep(2500);
			}
	  
		ac.Scrollpagedown();
	    ac.AccountLoadwait();
	    si.RefreshTab();
		
		String SessionAttendedid= si.CaptureSessionid_UAT2();
		log.info("Session id created for Session Attended is: "+SessionAttendedid);
		
		si.ClickSessionid_UAT2();

		String SessionAttend= si.CaptureSessiontext();
		Thread.sleep(800);
		
		Assert.assertEquals(SessionAttend, "Session Attended");
		
		log.info("Deleting the created Session Information");
		si.DeleteSessionInfolastbtn();
		
		//Verify Session Missed is Created
				
		log.info("Sending the Session Missed API");
	    if(CurrURL.contains("--byjusuatfc")) {
			payLoad_NeoClasses.SessionMissedResponse_UATFC();
		    Thread.sleep(2500);
			}
	    else if(CurrURL.contains("--byjusuat")) {
			payLoad_NeoClasses.SessionMissedResponse_UAT();
		    Thread.sleep(4500);
			}
			else if(CurrURL.contains("--byjusqa")) {
				payLoad_NeoClasses.SessionMissedResponse_QA();
			    Thread.sleep(2500);
				}
			else {
				payLoad_NeoClasses.SessionMissedResponse_Prod();
			    Thread.sleep(2500);
				}
		  
	  
	    si.RefreshTab();
		
	    if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
		String SessionMissedid= si.CaptureSessionid_UAT2();
		log.info("Session id created for Session Attended is: "+SessionMissedid);
		
		si.ClickSessionid_UAT2();
	    }
	    else {
			String SessionMissedid= si.CaptureSessionid_UAT2();;
			log.info("Session id created for Session Missed is: "+SessionMissedid);
			
			si.ClickSessionid_UAT2();
	    }
		
		
		String SessionMissed= si.CaptureSessiontext();
		Thread.sleep(800);
		
		Assert.assertEquals(SessionMissed, "Session Missed");
		log.info("Deleting the created Session Information");
		si.DeleteSessionInfolastbtn();

		//Verify Session Feedback is Created
		//***********************************************************//
		
		  log.info("Sending the Session Feedback API");
		  if(CurrURL.contains("--byjusuatfc")) {
		  payLoad_NeoClasses.SessionFeedbackResponse_UATFC(); 
		  Thread.sleep(2500); 
		  }
		  else if(CurrURL.contains("--byjusuat")) {
		  payLoad_NeoClasses.SessionFeedbackResponse_UAT(); 
		  Thread.sleep(4500); 
		  } else
		  if(CurrURL.contains("--byjusqa")) {
		  payLoad_NeoClasses.SessionFeedbackResponse_QA(); 
		  Thread.sleep(2500); } 
		  else {
		  payLoad_NeoClasses.SessionFeedbackResponse_Prod(); 
		  Thread.sleep(2500); }
		  
		  si.RefreshTab();
          String SessionFeedbackid= si.CaptureSessionid_UAT2();
    	  log.info("Session id created for Session Feedback is: "+SessionFeedbackid);
    	  si.ClickSessionid_UAT2();
		  
		  log.info("Deleting the created Session Information");
	      si.DeleteSessionInfolastbtn();

		
		  //Verify Assessment Submitted Exam detail is Created
				
		  ExamDetailsPO ed= new ExamDetailsPO(driver);
		
		  log.info("Sending the Assessment Submitted API");
	      if(CurrURL.contains("--byjusuatfc")) {
	        payLoad_NeoClasses.AssessmentSubmittedResponse_UATFC();
		    Thread.sleep(2500);
			}
	      else if(CurrURL.contains("--byjusuat")) {
	        payLoad_NeoClasses.AssessmentSubmittedResponse_UAT();
		    Thread.sleep(2500);
		    ac.Scrollpagedown();
			}
		  else if(CurrURL.contains("--byjusqa")) {
				payLoad_NeoClasses.AssessmentSubmittedResponse_QA();
			    Thread.sleep(2500);
				}
		  else {
				payLoad_NeoClasses.AssessmentSubmittedResponse_Prod();
			    Thread.sleep(2500);
			    ac.Scrollpagedown();
				}
	    ed.RefreshTab();
		ac.ClickExamDetails();
		
		String Examid= ed.CaptureExamid();
		log.info("Exam id created for Assessment Submitted is: "+Examid);
		
		String RecordType=ed.CaptureRecordtypetext();
		Assert.assertEquals(RecordType, "Monthly Test Scheduled");
		
		ed.ClickExamid();
			
		log.info("Deleting the created Exam Detail Information");
		ed.DeleteExamDetailslastbtn();
		ed.NavExamInfo();
	
		//Verify Monthly Submitted Exam detail is Created	
		log.info("Sending the Monthly Test API");
		 if(CurrURL.contains("--byjusuatfc")) {
		        payLoad_NeoClasses.MonthlyTestResponse_UATFC();
			    Thread.sleep(2500);
				}
		 else if(CurrURL.contains("--byjusuat")) {
	        payLoad_NeoClasses.MonthlyTestResponse_UAT();
		    Thread.sleep(2500);
			}
			else if(CurrURL.contains("--byjusqa")) {
				payLoad_NeoClasses.MonthlyTestResponse_QA();
			    Thread.sleep(2500);
				}
			else {
				payLoad_NeoClasses.MonthlyTestResponse_Prod();
			    Thread.sleep(2500);
				}
	    Thread.sleep(1200);
	    ed.RefreshTab();
		Thread.sleep(1000);
	    
		String Examid1= ed.CaptureExamid();
		log.info("Exam id created for Monthly Test Submitted is: "+Examid1);
		
		String RecordType1=ed.CaptureRecordtypetext();
		Assert.assertEquals(RecordType1, "Monthly Test Scheduled");
		
		ed.ClickExamid();
			
		log.info("Deleting the created Exam Detail Information");
		ed.DeleteExamDetailslastbtn();

		ac.ClickAccOwnrTab();
		
		
		//Verify Student School Informations is Created

		log.info("Sending Student School Information API");
	    String SchoolInfo;
	    if(CurrURL.contains("--byjusuatfc")) {
		 SchoolInfo = payLoad_NeoClasses.StudentSchoolInformationsResponse_UATFC(); 
		  Thread.sleep(2500); 
		  }
		  else if(CurrURL.contains("--byjusuat")) {
		 SchoolInfo =  payLoad_NeoClasses.StudentSchoolInformationsResponse_UAT(); 
		  Thread.sleep(4500); 
		  }
		  else {
		 SchoolInfo =  payLoad_NeoClasses.StudentSchoolInformationsResponse_Prod(); 
		  Thread.sleep(2500); 
		  }
	  
		  ac.CloseSubTabs();
		  si.RefreshTab();
		  
		  
    	  String StudentSchoolInformation= si.CaptureStuSchlInfo();
    	  log.info("Student School Information created is: "+StudentSchoolInformation);
    			
    	  si.ClickStuSchlInfo();
    	  
    	  log.info("Deleting the created Student School Information");

	    si.DeleteStudentSchoolInfolastbtn(); 
			  
		String SchoolInfoURL=CurrURL+SchoolInfo;
		
		
		log.info("Deleting the Student Program details");
		ac.ClickAccOwnrTab();
		ac.DeleteCreatedStuProg();
		ac.NavBackToAccount();
		log.info("Deleting the Account created details");
		ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
		
		if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
		log.info("Deleting the Student Classroom details "+StudentClassroom);
		ac.goTo(CurrURL+StudentClassroom);	
		Thread.sleep(3500);
		StudentCRAssoPO scra= new StudentCRAssoPO(driver);
		scra.ClickDelete();
		// StudentAppInfo1
		
		log.info("Deleting the Student App Info details ");
		ac.goTo(CurrURL+StudentAppInfo1);	
		Thread.sleep(3500);
		StudentAppInfoPO spi = new StudentAppInfoPO(driver);
		spi.DeleteStudentAppInfolastbtn();
		
		ac.goTo(CurrURL+StudentAppInfo2);	
		Thread.sleep(3500);
		spi.DeleteStudentAppInfolastbtn();
		}
		
		log.info("Deleting the School Information details "+SchoolInfo);
		ac.goTo(SchoolInfoURL);	
		Thread.sleep(3500);
		StudentAppInfoPO spi= new StudentAppInfoPO(driver);
		spi.DeleteSchoolInfolastbtn();		
		
	}
		
	
	  @AfterMethod(alwaysRun = true) public void teardown() throws
	  InterruptedException {
	  
	  driver.quit();
	  
	  //Thread.sleep(2000); 
	  }
	 
	
	
}
