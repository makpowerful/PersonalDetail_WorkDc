package testCases;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import junit.framework.Assert;
import pageObjects.CSInboundPO;
import pageObjects.CasesPO;
import pageObjects.CreatedAccountPO;
import pageObjects.InboundTaskPO;
import pageObjects.IssueTreePO;
import pageObjects.NewCaseRecordTypePO;
import pageObjects.OpenActivitiesPO;
import pageObjects.UnregisteredCustomersDetailCaptureTaskPO;
import pageObjects.loginPO;
import payLoad.payLoad_BTLA;
import payLoad.payLoad_BTLA2;
import resources.ExcelData;
import resources.base;

public class test_Regression_CS_Inbound_Process extends base {

    public WebDriver driver;
    ExcelData excelData = new ExcelData();
    public static Logger log = LogManager.getLogger(test_Regression_CS_Inbound_Process.class.getName());
    ArrayList<String> a1 = new ArrayList<String>();
    ArrayList<String> a2 = new ArrayList<String>();
    ArrayList<String> a3= new ArrayList<String>();
    ArrayList<String> al3 = new ArrayList<String>();
    ArrayList<String> al4 = new ArrayList<String>();
    ArrayList<String> al5 = new ArrayList<String>();
    ArrayList<String> al6 = new ArrayList<String>();

    @BeforeMethod(alwaysRun = true)
    public void initialize() throws IOException, InterruptedException {

        driver = initializeDriver();

    }

    // Jira Story=SFDC_732_SFTNL_10047

    @Test(priority = 1, enabled = true)
    public void Test_Reg_CSToLSIntegration() throws Exception {

        String Accountid = null;
        loginPO lo = new loginPO(driver);
        a1 = excelData.getData("TC1", "CSInbound", "Tcid");
        a2 = excelData.getData("CS User UAT", "Login", "Type");
        a3 = excelData.getData("TC2", "ProdDummyUser", "Tcid");

        // TC01------------------------------------->>

        if (CurrURL.contains("--byjusuat")) {

            // al2 = excelData.getData("Collection Assistant", "Login", "Type");

            log.info("Logging in as Admin to UAT");
            lo.LoginAsAdmin_UAT();
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_BTLA.AccountidCreationResponse_UAT();
            log.info("Launching the newly created Account id " + Accountid);

        }
        if (CurrURL.contains("byjusprod.")) {

            log.info("Login in as Admin into Prod");
            lo.LoginAsAdmin_Prod();
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_BTLA2.AccountidCreationResponse_Prod();
            log.info("Launching the newly created Account id " + Accountid);

        }
        log.info("Logging in as Admin to UAT then switching user to Customer Support");

        CreatedAccountPO ac = new CreatedAccountPO(driver);
        CSInboundPO cip = new CSInboundPO(driver);
        NewCaseRecordTypePO ncrt = new NewCaseRecordTypePO(driver);
        InboundTaskPO ibdt = new InboundTaskPO(driver);
        UnregisteredCustomersDetailCaptureTaskPO ucdc = new UnregisteredCustomersDetailCaptureTaskPO(driver);

        ac.closeTabWindows();
        ac.Notification();
        ac.NavBackToAccount();

        String AccountURL = CurrURL + Accountid;
        ac.goTo(AccountURL);
        ac.AccountLoadwait();

        if (CurrURL.contains("--byjusuat")) {
            String AccountOwner = ac.AccOwnerCheck();
            if (!a2.get(1).equalsIgnoreCase(AccountOwner)) {
                ac.AssignAccount(a2.get(1));
            }
        } else {
            ac.AssignAccount(al3.get(1));
        }

        if (CurrURL.contains("--byjusuat")) {

            lo.SwitchUser(a2.get(1));
        }

        else {
            lo.SwitchUsernProfile_Prod(a3.get(1), "Customer Support");
            // lo.SwitchUser(a3.get(1));
        }

        // ac.closeTabWindows();
        // ac.Notification();
        // ac.NavBackToAccount();

        ac.goTo(AccountURL);
        ac.AdditionalWait();

        String AccountName = ac.CaptureAccOwnrNam();
        log.info("Creating Inbound Task");
        ac.ClickOpenActivitiestoNewTask();

        ncrt.UCDetailsCapture();
        ncrt.ClickNext();
        String number = cip.tenDigitNumber();

        // cip.InbusinessHours();
        cip.textFieldCallBackNumber(number);
        ncrt.ClickSave();

        
        // TC02------------------------------------->>
        
        ibdt.ClickCaptureDetail();
        cip.EnterCallType(a1.get(2));
        cip.EnterCallStatus(a1.get(3));
        cip.EnterCustomerType(a1.get(4));
        cip.textFieldSearchStudentCS(AccountName);
        cip.ClicktextFieldSearchStudentResult(AccountName);
        ncrt.ClickNextButton();

        cip.csstudentnameverify();
        cip.csParentNameverify();
        cip.csPhoneverify();
        cip.csStatusverify();
        cip.csSuperStatusverify();
        cip.csEmailverify();

        // TC03------------------------------------->>

        ucdc.SelectEnquiryType(a1.get(5));
        ucdc.SelectReasonForCall(a1.get(6));
        ucdc.SelectCourse(a1.get(7));
        ucdc.SelectCountry(a1.get(8));
        ucdc.ClickNext();

        // ucdc.LSName();
        // ucdc.EnterName2("Dummy Susanne Walsh");
        ucdc.EnterLanguage(a1.get(10));
        ucdc.EnterEmail(a1.get(21));
        ucdc.EnterCity(a1.get(9));
        ucdc.EnterReasonForCall(a1.get(11));
        ucdc.EnterGrade(a1.get(12));
        ucdc.EnterCourse(a1.get(13));
        ucdc.EnterEnquiryBy(a1.get(14));
        ucdc.EnterPurchasedCourseBefore(a1.get(15));
        ucdc.EnterIsthisrepeatcall(a1.get(16));
        ucdc.EnterBriefComment(a1.get(17));
        ucdc.EnterHDYKAByjus(a1.get(18));
        ucdc.EnterName(AccountName);
        ac.AdditionalWait();
        ucdc.ClickNext();

        ucdc.Selecttransfercall(a1.get(19));
        ucdc.ClickNext();
        ucdc.ClickFinish();
        lo.RefreshURL();

        ac.AdditionalWait();
        if (CurrURL.contains("--byjusuat") || (CurrURL.contains("byjusprod."))) {
            driver.findElement(By.xpath("//a[@class='action-link']")).click();
        }
        /*
         * else {
         * driver.findElement(By.
         * xpath("//a[@class='action-link']/following::a[contains(text(),'Log out')]")).
         * click();
         * }
         */
        ac.goTo(AccountURL);
        ac.AdditionalWait();

        ac.closeTabWindows();

        ac.NavBackIntegrationLoginScreen();

        //cip.CSFilterSelection();
        // cip.CSLastOwnerName(a2.get(2));
        cip.IntegrationLoggingName(AccountName);
        ac.NavBackIntegrationLoginScreen();
        ac.NavBackIntegrationLoginScreen1();

        ac.AdditionalWait();
        ac.DeleteCreatedStuProg();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
    }
        

 // Jira Story=SFDC_922
    
    @Test(priority = 1, enabled = false)
    public void Test_Reg_CSFieldValidation() throws Exception {

        String Accountid = null;
        loginPO lo = new loginPO(driver);
        a1 = excelData.getData("TC1", "CSInbound", "Tcid");
        a2 = excelData.getData("CS User UAT", "Login", "Type");
        a3= excelData.getData("TC2", "ProdDummyUser", "Tcid");

        // TC01------------------------------------->>
        
        if(CurrURL.contains("--byjusuat")) {
           

            //al2 = excelData.getData("Collection Assistant", "Login", "Type");
            
            log.info("Logging in as Admin to UAT");
            lo.LoginAsAdmin_UAT();
            log.info("Submitting the Account creation payload");
            Accountid=payLoad_BTLA.AccountidCreationResponse_UAT();
            log.info("Launching the newly created Account id "+Accountid);
            
            }
        if(CurrURL.contains("byjusprod.")) {
           
            log.info("Login in as Admin into Prod");
            lo.LoginAsAdmin_Prod();
            log.info("Submitting the Account creation payload");
            Accountid= payLoad_BTLA2.AccountidCreationResponse_Prod();
            log.info("Launching the newly created Account id "+Accountid);
            
        }
        log.info("Logging in as Admin to UAT then switching user to Customer Support");
        //lo.LoginAsAdmin_UAT();

        
        CreatedAccountPO ac = new CreatedAccountPO(driver);
        ac.closeTabWindows();
        CSInboundPO cip = new CSInboundPO(driver);
        NewCaseRecordTypePO ncrt = new NewCaseRecordTypePO(driver);
        InboundTaskPO ibdt = new InboundTaskPO(driver);
        UnregisteredCustomersDetailCaptureTaskPO ucdc = new UnregisteredCustomersDetailCaptureTaskPO(driver);
        
        
        //ac.Notification();
        //ac.NavBackToAccount();

        String AccountURL = CurrURL + Accountid;
        driver.get(AccountURL);
      ac.AccountLoadwait();

       if (CurrURL.contains("--byjusuat")) {
            String AccountOwner = ac.AccOwnerCheck();
            if (!a2.get(1).equalsIgnoreCase(AccountOwner)) {
                ac.AssignAccount(a2.get(1));
            }
        } else {
            ac.AssignAccount("Sumit Dash");
        }

        if (CurrURL.contains("--byjusuat")) {
            
            lo.SwitchUser(a2.get(1));
        }
        
        else {
            lo.SwitchUsernProfile_Prod(a3.get(1),"Customer Support");
                //lo.SwitchUser(a3.get(1));
            }
        
            //ac.closeTabWindows();
            //ac.Notification();
            //ac.NavBackToAccount();
            
            driver.get(AccountURL);

            String AccountName = ac.CaptureAccOwnrNam();
            log.info("Creating Inbound Task");
            ac.ClickOpenActivitiestoNewTask();
            //driver.get("https://byjusprod--byjusuat.lightning.force.com/lightning/r/Task/00TC2000000ocIDMAY/view?ws=%2Flightning%2Fr%2FTask%2F00TC2000000oxxlMAA%2Fview");

            ncrt.UCDetailsCapture();
            ncrt.ClickNext();
            String number = cip.tenDigitNumber();

           // cip.InbusinessHours();
            cip.textFieldCallBackNumber(number);
            ncrt.ClickSave();
            
            //driver.get("https://byjusprod.lightning.force.com/lightning/r/Task/00TJY000002ERpS2AW/view?ws=%2Flightning%2Fr%2FAccount%2F001JY000002QfseYAC%2Fview");
            // TC02------------------------------------->>
            //driver.get("https://byjusprod--byjusuat.lightning.force.com/lightning/r/Task/00TC2000000s6y5MAA/view?ws=%2Flightning%2Fr%2FAccount%2F001C2000005ltxRIAQ%2Fview");
            ibdt.ClickCaptureDetail();
            cip.EnterCallType(a1.get(2));
            cip.EnterCallStatus(a1.get(3));
            cip.EnterCustomerType(a1.get(4));
            cip.textFieldSearchStudentCS(AccountName);
            cip.ClicktextFieldSearchStudentResult(AccountName);
            ncrt.ClickNextButton();

            cip.csstudentnameverify();
            cip.csParentNameverify();
            cip.csPhoneverify();
            cip.csStatusverify();
            cip.csSuperStatusverify();
            cip.csEmailverify();

            // TC03------------------------------------->>

           
            ucdc.SelectEnquiryType(a1.get(5));
            ucdc.SelectReasonForCall(a1.get(6));
            ucdc.SelectCourse(a1.get(7));
            ucdc.SelectCountry(a1.get(8));
            ucdc.ClickNext();
          

         
            ucdc.EnterLanguage(a1.get(10));
            ucdc.EnterEmail(a1.get(21));
            ucdc.EnterCity(a1.get(9));
            ucdc.EnterReasonForCall(a1.get(11));
            ucdc.EnterGrade(a1.get(12));
            ucdc.EnterCourse(a1.get(13));
            ucdc.EnterEnquiryBy(a1.get(14));
            ucdc.EnterPurchasedCourseBefore(a1.get(15));
            ucdc.EnterIsthisrepeatcall(a1.get(16));
            ucdc.EnterBriefComment(a1.get(17));
            ucdc.EnterHDYKAByjus(a1.get(18));
            ucdc.EnterName(AccountName);
            ac.AdditionalWait();
            ucdc.ClickNext();

            ucdc.Selecttransfercall(a1.get(19));
            ucdc.ClickNext();
            ucdc.ClickFinish();
            lo.RefreshURL();
           
          ac.AdditionalWait();
         
            ac.DeleteCreatedStuProg();
            log.info("Deleting the Account created details");
            ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
            

        }
        

    // Jira Story=SFDC-3878, SFDC-2606+SFTNL-8200
    @Test(priority = 2, enabled = false)
    public void Test_Reg_CSToLSIntegrationSFDC3878() throws Exception {
        String Accountid = null;
        //String AccountOwner = null;
        //String searchCity1 = "Bang";
        //String city1 = "Bangalore";
        //String searchCity2 = "Del";
        //String city2 = "Delhi";
        //String searchCity3 = "Ah";
        //String city3 = "Ahmedabad";
        CasesPO cases = new CasesPO(driver);

        loginPO lo = new loginPO(driver);
        a1 = excelData.getData("TC1", "CSInbound", "Tcid");
        a2 = excelData.getData("CS User UAT", "Login", "Type");
        al5 = excelData.getData("TC3", "RefundProcess", "Tcid");
        al6 = excelData.getData("TC1", "EFA-LIG", "Tcid");

        log.info("Logging in as Admin to UAT then switching user to Customer Support");
        
        if(CurrURL.contains("--byjusuat")) {
            

            //al2 = excelData.getData("Collection Assistant", "Login", "Type");
            
            log.info("Logging in as Admin to UAT");
            lo.LoginAsAdmin_UAT();
            log.info("Submitting the Account creation payload");
            Accountid=payLoad_BTLA.AccountidCreationResponse_UAT();
            log.info("Launching the newly created Account id "+Accountid);
            
            }
        if(CurrURL.contains("byjusprod.")) {
           
            log.info("Login in as Admin into Prod");
            lo.LoginAsAdmin_Prod();
            log.info("Submitting the Account creation payload");
            Accountid= payLoad_BTLA2.AccountidCreationResponse_Prod();
            log.info("Launching the newly created Account id "+Accountid);
            
        }
        
        /*if(CurrURL.contains("--byjusuat")) {
            
        lo.LoginAsAdmin_UAT();

        Accountid = payLoad_BTLA2.AccountidCreationResponse_UAT();
        log.info("The new account is created" + Accountid);*/

        CreatedAccountPO ac = new CreatedAccountPO(driver);
        ac.closeTabWindows();
        CSInboundPO cip = new CSInboundPO(driver);
        NewCaseRecordTypePO ncrt = new NewCaseRecordTypePO(driver);
        InboundTaskPO ibdt = new InboundTaskPO(driver);
        UnregisteredCustomersDetailCaptureTaskPO ucdc = new UnregisteredCustomersDetailCaptureTaskPO(driver);
        ac.Notification();
        ac.NavBackToAccount();

        String AccountURL = CurrURL + Accountid;
        driver.get(AccountURL);
        ac.AccountLoadwait();

        if (CurrURL.contains("--byjusuat")) {
            String AccountOwner = ac.AccOwnerCheck();
            if (!a2.get(1).equalsIgnoreCase(AccountOwner)) {
                ac.AssignAccount(a2.get(1));
            }
        
        else {
            ac.AssignAccount("Sumit Dash");
        }
        ac.Scrollpagedown();

        // Creating an inbound task
        log.info("Creating Inbound Task");
        ac.ClickOpenActivitiestoNewTask();

        ncrt.SelectCaseRecordTypeInbound();
        ncrt.ClickNext();
        ac.AdditionalWait();
        ncrt.ClickSave();
        ac.AdditionalWait();

        // Creating an RR case
        ibdt.ClickCaptureDetail();
        Thread.sleep(3000);

        ibdt.ClickProceedOptn();
        if (CurrURL.contains("--byjusuat") || CurrURL.contains("--byjusuatfc") || CurrURL.contains("byjusprod.")) {
            al3 = excelData.getData("Inbound", "Inbound", "Tcid");
            al4 = excelData.getData("TC2", "EasyPayCollection", "Tcid");
            IssueTreePO it = new IssueTreePO(driver);
            if (!CurrURL.contains("--byjusuatfc")) {
                ibdt.SelectSpokeTo3(al3.get(1));
                it.PremiumidSelector();
                it.ProgramSelector();
                it.ClickNext();
            }
            ibdt.SelectPSTCT(al3.get(2));
            // ibdt.EnterNotesVal(al3.get(3));
            ibdt.ClickNext();
            ac.AdditionalWait();
            it.IssueCategory(al5.get(13));
            it.Reason(al5.get(14));
            it.SubReason(al5.get(15));
            it.IssueNotes(al4.get(15));
            it.IstheIssueResolved(al4.get(16));
            it.ClickNext();
            it.ClickNext3();
            it.SSOandAccCombo();
            it.ClickFinish();
        }

        // Switching to CS profile
        if (CurrURL.contains("--byjusuat")) {
            ac.AdditionalWait();
            lo.SwitchUser(a2.get(1));

            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            driver.get(AccountURL);

            String AccountName = ac.CaptureAccOwnrNam();
            log.info("Creating Inbound Task");
            ac.ClickOpenActivitiestoNewTask();

            ncrt.UCDetailsCapture();
            ncrt.ClickNext();
            String number = cip.tenDigitNumber();

            cip.InbusinessHours();
            cip.textFieldCallBackNumber(number);
            ncrt.ClickSave();

            ibdt.ClickCaptureDetail();
            cip.EnterCallType(a1.get(2));
            cip.EnterCallStatus(a1.get(3));
            cip.EnterCustomerType(a1.get(4));
            cip.textFieldSearchStudentCS(AccountName);
            cip.ClicktextFieldSearchStudentResult(AccountName);
            ncrt.ClickNextButton();

            cip.csstudentnameverify();
            cip.csParentNameverify();
            cip.csPhoneverify();
            cip.csStatusverify();
            cip.csSuperStatusverify();
            cip.csEmailverify();

            ucdc.SelectEnquiryType(a1.get(5));
            ucdc.SelectEnquiryType(a1.get(5));
            ucdc.SelectReasonForCall(a1.get(6));
            ucdc.SelectCourse(a1.get(7));
            ucdc.SelectCountry(a1.get(8));
            ucdc.ClickNext();
            ac.AdditionalWait();
            ucdc.EnterName(AccountName);
            ucdc.EnterLanguage(a1.get(10));

            // SFDC-3878
           // String bang = ucdc.verifyCity(searchCity1);
           // Assert.assertEquals(city1, bang);
            //String del = ucdc.verifyCity(searchCity2);
            //Assert.assertEquals(city2, del);
            //String ahm = ucdc.verifyCity(searchCity3);
            //Assert.assertEquals(city3, ahm);
            ucdc.EnterCity(a1.get(9));
            ucdc.EnterReasonForCall(a1.get(11));
            ucdc.EnterGrade(a1.get(12));
            ucdc.EnterCourse(a1.get(13));
            ucdc.EnterEnquiryBy(a1.get(14));
            ucdc.EnterPurchasedCourseBefore(a1.get(15));
            ucdc.EnterIsthisrepeatcall(a1.get(16));
            ucdc.EnterBriefComment(a1.get(17));
            ucdc.EnterHDYKAByjus(a1.get(18));
            ac.AdditionalWait();
            ucdc.ClickNext();

            // SFDC-2606+SFTNL-8200
            ucdc.SelectTasktoCentralRetentionTeam(al6.get(21));
            ucdc.ClickNext();
            ac.AdditionalWait();
            ucdc.ClickNext();
            ac.AdditionalWait();
            lo.RefreshURL();
            // Verify Task is added to account
            ac.CloseCurrentSubTab();

            OpenActivitiesPO oa = new OpenActivitiesPO(driver);
            // verify the task 'Primary Retention Outbound Required' is present
            Assert.assertTrue(oa.VerifyTaskpresent("Primary Retention Outbound Required"));
            lo.Logouthome();

            ac.closeTabWindows();
            ac.goTo(AccountURL);
            ac.AdditionalWait();

            // Deleting the created case
            ac.ClickCasesMC2();
            ac.AdditionalWait();
            cases.CloseAllCases();

            log.info("Deleting the Student Program details");
            ac.ClickAccOwnrTab();
            ac.DeleteAllCreatedStuProg();
            ac.DeleteAllCreatedStuPayment();
            ac.NavBackToAccount();
            log.info("Deleting the Account created details");
            ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());

        }
        }
        }
    

    // Jira Story= SFDC 2606+SFTNL-10364
    @Test(priority = 3, enabled = true)
    public void Test_Reg_CSToLSIntegrationSFDC2606() throws Exception {
        String Accountid = null;
        // String AccountOwner = null;
        CasesPO cases = new CasesPO(driver);

        loginPO lo = new loginPO(driver);
        a1 = excelData.getData("TC1", "CSInbound", "Tcid");
        a2 = excelData.getData("CS User UAT", "Login", "Type");
        al5 = excelData.getData("TC3", "RefundProcess", "Tcid");
        a3 = excelData.getData("TC2", "ProdDummyUser", "Tcid");

        log.info("Logging in as Admin to UAT then switching user to Customer Support");

        if (CurrURL.contains("--byjusuat")) {

            // al2 = excelData.getData("Collection Assistant", "Login", "Type");

            log.info("Logging in as Admin to UAT");
            lo.LoginAsAdmin_UAT();
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_BTLA.AccountidCreationResponse_UAT();
            log.info("Launching the newly created Account id " + Accountid);

        }
        if (CurrURL.contains("byjusprod.")) {

            log.info("Login in as Admin into Prod");
            lo.LoginAsAdmin_Prod();
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_BTLA2.AccountidCreationResponse_Prod();
            log.info("Launching the newly created Account id " + Accountid);

        }

        CreatedAccountPO ac = new CreatedAccountPO(driver);
        ac.closeTabWindows();
        CSInboundPO cip = new CSInboundPO(driver);
        NewCaseRecordTypePO ncrt = new NewCaseRecordTypePO(driver);
        InboundTaskPO ibdt = new InboundTaskPO(driver);
        UnregisteredCustomersDetailCaptureTaskPO ucdc = new UnregisteredCustomersDetailCaptureTaskPO(driver);
        ac.Notification();
        ac.NavBackToAccount();

        String AccountURL = CurrURL + Accountid;
        driver.get(AccountURL);
        ac.AccountLoadwait();

        if (CurrURL.contains("--byjusuat")) {
            String AccountOwner = ac.AccOwnerCheck();
            if (!a2.get(1).equalsIgnoreCase(AccountOwner)) {
                ac.AssignAccount(a2.get(1));
            }
        } else {
            ac.AssignAccount("Sumit Dash");
        }

        /*
         * if (CurrURL.contains("--byjusuat")) {
         * 
         * lo.SwitchUser(a2.get(1));
         * }
         */

        if (CurrURL.contains("--byjusprod")) {
            lo.SwitchUsernProfile_Prod(a3.get(1), "Customer Support");
            // lo.SwitchUser(a3.get(1));
        }

        /*
         * AccountOwner = ac.AccOwnerCheck();
         * if (!a2.get(1).equalsIgnoreCase(AccountOwner)) {
         * ac.AssignAccount(a2.get(1));
         * } else {
         * ac.AssignAccount("Sumit Dash");
         * }
         */

        driver.get(AccountURL);
        ac.Scrollpagedown();

        // Creating an inbound task
        log.info("Creating Inbound Task");
        ac.ClickOpenActivitiestoNewTask();

        ncrt.SelectCaseRecordTypeInbound();
        ncrt.ClickNext();
        ac.AdditionalWait();
        ncrt.ClickSave();
        ac.AdditionalWait();

        // Creating an RR case
        ibdt.ClickCaptureDetail();
        Thread.sleep(3000);

        ibdt.ClickProceedOptn();
        if (CurrURL.contains("--byjusuat") || CurrURL.contains("--byjusuatfc") || CurrURL.contains("byjusprod.")) {
            al3 = excelData.getData("Inbound", "Inbound", "Tcid");
            al4 = excelData.getData("TC2", "EasyPayCollection", "Tcid");
            IssueTreePO it = new IssueTreePO(driver);
            if (!CurrURL.contains("--byjusuatfc")) {
                ibdt.SelectSpokeTo3(al3.get(1));
                it.PremiumidSelector();
                it.ProgramSelector();
                it.ClickNext();
            }
            ibdt.SelectPSTCT(al3.get(2));
            // ibdt.EnterNotesVal(al3.get(3));
            ibdt.ClickNext();
            ac.AdditionalWait();
            it.IssueCategory(al5.get(13));
            it.Reason(al5.get(14));
            it.SubReason(al5.get(15));
            it.IssueNotes(al4.get(15));
            it.IstheIssueResolved(al4.get(16));
            it.ClickNext();
            ac.AdditionalWait();
            it.SSOandAccCombo();
            // it.ClickNext3();
            it.ClickFinish();
        }

        ac.AdditionalWait();
        // Switching to CS profile
        if (CurrURL.contains("--byjusuat")) {
            ac.AdditionalWait();
            lo.SwitchUser(a2.get(1));
        } else {
            lo.SwitchUsernProfile_Prod(a3.get(1), "Customer Support");
            // lo.SwitchUser(a3.get(1));
        }

        ac.closeTabWindows();
        // ac.Notification();
        // ac.NavBackToAccount();
        driver.get(AccountURL);

        String AccountName = ac.CaptureAccOwnrNam();
        log.info("Creating Inbound Task");
        ac.ClickOpenActivitiestoNewTask();

        ncrt.UCDetailsCapture();
        ncrt.ClickNext();
        String number = cip.tenDigitNumber();

        cip.textFieldCallBackNumber(number);
        ncrt.ClickSave();

        ibdt.ClickCaptureDetail();
        cip.EnterCallType(a1.get(2));
        cip.EnterCallStatus(a1.get(3));
        cip.EnterCustomerType(a1.get(4));
        cip.textFieldSearchStudentCS(AccountName);
        cip.ClicktextFieldSearchStudentResult(AccountName);
        ncrt.ClickNextButton();

        cip.csstudentnameverify();
        cip.csParentNameverify();
        cip.csPhoneverify();
        cip.csStatusverify();
        cip.csSuperStatusverify();
        cip.csEmailverify();

        ucdc.SelectEnquiryType(a1.get(5));

        ucdc.SelectReasonForCall(a1.get(6));
        ucdc.SelectCourse(a1.get(7));
        ucdc.SelectCountry(a1.get(8));
        ucdc.ClickNext();
        ac.AdditionalWait();
        ucdc.EnterName(AccountName);
        ucdc.EnterLanguage(a1.get(10));

        ucdc.EnterCity(a1.get(9));
        ucdc.EnterReasonForCall(a1.get(11));
        ucdc.EnterGrade(a1.get(12));
        ucdc.EnterCourse(a1.get(13));
        ucdc.EnterEnquiryBy(a1.get(14));
        ucdc.EnterPurchasedCourseBefore(a1.get(15));
        ucdc.EnterIsthisrepeatcall(a1.get(16));
        ucdc.EnterBriefComment(a1.get(17));
        ucdc.EnterHDYKAByjus(a1.get(18));
        ac.AdditionalWait();
        ucdc.ClickNext();

        // SFDC-2606+SFTNL-8200
        ucdc.SelectTasktoCentralRetentionTeam(al5.get(17));
        ucdc.ClickNext();
        ac.AdditionalWait();
        ucdc.ClickNext();
        ac.AdditionalWait();
        lo.RefreshURL();
        // Verify Task is added to account
        ac.CloseCurrentSubTab();

        //OpenActivitiesPO oa = new OpenActivitiesPO(driver);
        // verify the task 'Primary Retention Outbound Required' is present
        // Assert.assertFalse(oa.textDisplayed("Primary Retention Outbound Required"));
        lo.Logouthome();

        ac.closeTabWindows();
        ac.goTo(AccountURL);
        ac.AdditionalWait();

        // Deleting the created case
        ac.ClickCasesMC2();
        ac.AdditionalWait();
        cases.CloseAllCases();

        log.info("Deleting the Student Program details");
        ac.ClickAccOwnrTab();
        ac.DeleteAllCreatedStuProg();
        ac.DeleteAllCreatedStuPayment();
        ac.NavBackToAccount();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());

    }
    
    
    // Jira Story= SFDC-801
    @Test(priority = 4, enabled = false)
    public void Test_Reg_CSToLSIntegrationSFDC801() throws Exception {
        String Accountid = null;
        //String AccountOwner = null;

        loginPO lo = new loginPO(driver);
        a1 = excelData.getData("TC1", "CSInbound", "Tcid");
        a2 = excelData.getData("CS User UAT", "Login", "Type");
        al6 = excelData.getData("TC1", "EFA-LIG", "Tcid");

        log.info("Logging in as Admin to UAT then switching user to Customer Support");
       
        if(CurrURL.contains("--byjusuat")) {
            

            //al2 = excelData.getData("Collection Assistant", "Login", "Type");
            
            log.info("Logging in as Admin to UAT");
            lo.LoginAsAdmin_UAT();
            log.info("Submitting the Account creation payload");
            Accountid=payLoad_BTLA.AccountidCreationResponse_UAT();
            log.info("Launching the newly created Account id "+Accountid);
            
            }
        if(CurrURL.contains("byjusprod.")) {
           
            log.info("Login in as Admin into Prod");
            lo.LoginAsAdmin_Prod();
            log.info("Submitting the Account creation payload");
            Accountid= payLoad_BTLA2.AccountidCreationResponse_Prod();
            log.info("Launching the newly created Account id "+Accountid);
            
        }
        // lo.LoginAsAdmin_UAT();

       // Accountid = payLoad_BTLA2.AccountidCreationResponse_UAT();
        //log.info("The new account is created" + Accountid);

        CreatedAccountPO ac = new CreatedAccountPO(driver);
        ac.closeTabWindows();
        CSInboundPO cip = new CSInboundPO(driver);
        NewCaseRecordTypePO ncrt = new NewCaseRecordTypePO(driver);
        InboundTaskPO ibdt = new InboundTaskPO(driver);
        UnregisteredCustomersDetailCaptureTaskPO ucdc = new UnregisteredCustomersDetailCaptureTaskPO(driver);
        ac.Notification();
        ac.NavBackToAccount();

        String AccountURL = CurrURL + Accountid;
        driver.get(AccountURL);
        ac.AccountLoadwait();

       /* AccountOwner = ac.AccOwnerCheck();
        if (!a2.get(1).equalsIgnoreCase(AccountOwner)) {
            ac.AssignAccount(a2.get(1));
        } else {
            ac.AssignAccount("Sumit Dash");
        }*/
        ac.Scrollpagedown();

        // Switching to CS profile
        /*if (CurrURL.contains("--byjusuat")) {
            ac.AdditionalWait();
            lo.SwitchUser(a2.get(1));*/

        if (CurrURL.contains("--byjusuat")) {
             String AccountOwner = ac.AccOwnerCheck();
             if (!a2.get(1).equalsIgnoreCase(AccountOwner)) {
                 ac.AssignAccount(a2.get(1));
             }
         } else {
             ac.AssignAccount("Sumit Dash");
         }

         if (CurrURL.contains("--byjusuat")) {
             
             lo.SwitchUser(a2.get(1));
         }
         
         else {
             lo.SwitchUsernProfile_Prod(a3.get(1),"Customer Support");
                 //lo.SwitchUser(a3.get(1));
             }

            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            driver.get(AccountURL);

            String AccountName = ac.CaptureAccOwnrNam();
            log.info("Creating Inbound Task");
            ac.ClickOpenActivitiestoNewTask();

            ncrt.UCDetailsCapture();
            ncrt.ClickNext();
            String number = cip.tenDigitNumber();

            cip.InbusinessHours();
            cip.textFieldCallBackNumber(number);
            ncrt.ClickSave();

            ibdt.ClickCaptureDetail();
            cip.EnterCallType(a1.get(2));
            cip.EnterCallStatus(a1.get(3));
            cip.EnterCustomerType(a1.get(4));
            cip.textFieldSearchStudentCS(AccountName);
            cip.ClicktextFieldSearchStudentResult(AccountName);
            ncrt.ClickNextButton();

            cip.csstudentnameverify();
            cip.csParentNameverify();
            cip.csPhoneverify();
            cip.csStatusverify();
            cip.csSuperStatusverify();
            cip.csEmailverify();

            ucdc.SelectEnquiryType(a1.get(5));
            ucdc.SelectEnquiryType(a1.get(5));
            ucdc.SelectReasonForCall(a1.get(6));
            ucdc.SelectCourse(a1.get(7));
            ucdc.SelectCountry(a1.get(8));
            ucdc.ClickNext();
            ac.AdditionalWait();
            ucdc.EnterName(AccountName);
            ucdc.EnterLanguage(a1.get(10));

            ucdc.EnterCity(a1.get(9));
            ucdc.EnterReasonForCall(a1.get(11));
            ucdc.EnterGrade(a1.get(12));
            ucdc.EnterCourse(a1.get(13));
            ucdc.EnterEnquiryBy(a1.get(14));
            ucdc.EnterPurchasedCourseBefore(a1.get(15));
            ucdc.EnterIsthisrepeatcall(a1.get(16));
            ucdc.EnterBriefComment(a1.get(17));
            ucdc.EnterHDYKAByjus(a1.get(18));
            ac.AdditionalWait();
            ucdc.ClickNext();

            ucdc.Selecttransfercall(al6.get(21));
            ucdc.ClickNext();
            ac.AdditionalWait();
            ucdc.ClickNext();
            ac.AdditionalWait();
            lo.RefreshURL();
            // Verify Task is added to account
            ac.CloseCurrentSubTab();

            OpenActivitiesPO oa = new OpenActivitiesPO(driver);
            // verify the task 'Primary IRT_Manual -' is present
            Assert.assertTrue(oa.VerifyTaskpresent("Primary IRT_Manual -"));
            lo.Logouthome();

            ac.closeTabWindows();
            ac.goTo(AccountURL);
            ac.AdditionalWait();

            log.info("Deleting the Student Program details");
            ac.ClickAccOwnrTab();
            ac.DeleteAllCreatedStuProg();
            ac.DeleteAllCreatedStuPayment();
            ac.NavBackToAccount();
            log.info("Deleting the Account created details");
            ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());

        }
    


    @AfterMethod(alwaysRun = false)
    public void teardown() throws InterruptedException {

        driver.quit();

        // Thread.sleep(2000);
    }
}
