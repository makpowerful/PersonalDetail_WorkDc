package testCases;



import org.testng.annotations.Test;


import java.io.IOException;

import java.util.ArrayList;

import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.openqa.selenium.WebDriver;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;

import pageObjects.AssignmentRulesRefundRequestPO;
import pageObjects.CreatedAccountPO;
import pageObjects.GmailPO;
import pageObjects.IssueTreePO;


import pageObjects.OutboundBTCTaskPO;

import pageObjects.loginPO;

import resources.ExcelData;

import resources.base;

public class Rough extends base {


	public static Properties prop;
	public WebDriver driver;
	public static Logger log = LogManager.getLogger(Rough.class.getName());
	ExcelData excelData = new ExcelData();

	ArrayList<String> al3 = new ArrayList<String>();
	ArrayList<String> al4 = new ArrayList<String>();

	ArrayList<String> al6 = new ArrayList<String>();
	ArrayList<String> al7 = new ArrayList<String>();
	ArrayList<String> al8 = new ArrayList<String>();

    ArrayList<String> al = new ArrayList<String>();
    ArrayList<String> al2 = new ArrayList<String>();
    ArrayList<String> al5 = new ArrayList<String>();


    @BeforeMethod(alwaysRun = true)
    public void initialize() throws IOException, InterruptedException {

        driver = initializeDriver();
    }



    @Test
    public void setAsset() throws Exception {

        // TODO Auto-generated method stub
        //InboundTaskPO ibdt = new InboundTaskPO(driver);
        loginPO lo = new loginPO(driver);
        CreatedAccountPO ac = new CreatedAccountPO(driver);
        //CasesPO cases = new CasesPO(driver);
        OutboundBTCTaskPO obtc = new OutboundBTCTaskPO(driver);
        GmailPO gm = new GmailPO(driver);
        AssignmentRulesRefundRequestPO ar = new AssignmentRulesRefundRequestPO(driver);
        //boolean LTBC = false; // Loan To Be Cancelled
        //boolean DPTBR = false; // DP to be Refunded
        //boolean OATBR = false; // Other Amount to be Refunded
        //SoftAssert softassert = new SoftAssert();
        // ac.closeTabWindows();
//        al5 = excelData.getData("BTCTest", "Login", "Tcid");
//        lo.FromMiddleUAT("https://byjusprod--byjusuat.lightning.force.com/lightning/r/Task/00TC2000000m33dMAA/view");
//        String SupportIssue ="32826608";
//        String AcademicIssue ="32826610";
//        String TechnicalIssue ="32826612";
//        String SalesIssue ="32826614";
//        String HardwareIssue ="32826616";
//        gm.LoginGmail(al5.get(1),al5.get(2));
//        
//        
//        //gm.VerifyEmailnCase("btcsupport@byjus.com",SupportIssue,"24");
//        gm.VerifyEmailnCase("btcsupport@byjus.com","","",gm.ResolvedEmailContent(SupportIssue));
//        gm.VerifyEmailnCase2("btcsupport@byjus.com","","",gm.ResolvedEmailContent(AcademicIssue));
//        gm.VerifyEmailnCase2("btcsupport@byjus.com","","",gm.ResolvedEmailContent(TechnicalIssue));
//        gm.VerifyEmailnCase2("btcsupport@byjus.com","","",gm.ResolvedEmailContent(HardwareIssue));
        lo.LoginAsAdmin_UAT();
        ac.closeTabWindows(2);    
        ac.goTo("https://byjusprod--byjusuat.lightning.force.com/lightning/r/Group__c/a0b5i000000TOqQAAW/related/Group_Members__r/view?ws=%2Flightning%2Fr%2FAssignment_Rule__c%2Fa0UC2000000MiNGMA0%2Fview");
        Assert.assertTrue(ar.VerifyCaseOwner("Arunima De"));
    }
}
        