package testCases;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pageObjects.AssignmentRulesRefundRequestPO;
import resources.ExcelData;
import resources.base;

public class test_RefundProcess extends base {

    public WebDriver driver;
    ExcelData excelData = new ExcelData();
    public static Logger log = LogManager.getLogger(test_RefundProcess.class.getName());

    @BeforeMethod(alwaysRun = true)
    public void initialize() throws IOException, InterruptedException {

        driver = initializeDriver();

    }

    @Test(groups = { "sanity" }, priority = 1, enabled = false)
    public void AssignmentRuleforK3() throws Exception {
        System.out.println("-------------------Start of K3----------------");
        String shippedregion = "";
        String classValue = "";
        // String currentURL="";
        ArrayList<String> al = new ArrayList<String>();
        ArrayList<String> al3 = new ArrayList<String>(); // Array list for holding all the program ids
        ArrayList<String> al6 = new ArrayList<String>(); // Array list for two program IDs
        ArrayList<String> al8 = new ArrayList<String>(); // Array list for Shipped region
        ArrayList<String> al9 = new ArrayList<String>(); // Array list for class value
        ArrayList<String> al10 = new ArrayList<String>();

        al = excelData.getData("TC1", "RefundProcess", "Tcid");
        al3 = excelData.getData("DBEL+BMATH", "RRCaseAssignment", "Tcid");
        al8 = excelData.getData("shippedRegion", "RRCaseAssignment", "Tcid");
        al9 = excelData.getData("class", "RRCaseAssignment", "Tcid");
        al10 = excelData.getData("DBEL+BMATH", "RRCaseAssignment_2", "Tcid");
        // System.out.println(al3);
        // System.out.println(al);

        al6 = getTwoRandomProgramID(al3, al10, 1, 4);
        excelData.setData2("src\\main\\java\\testData\\TestData.xlsx", "RRCaseAssignment_2", 1, 1, al6.get(0));
        excelData.setData2("src\\main\\java\\testData\\TestData.xlsx", "RRCaseAssignment_2", 1, 2, al6.get(1));

        shippedregion = al8.get(randomNumber(1, 8));
        classValue = al9.get(randomNumber(1, 5));
        //shippedregion="MAHARASHTRA (MH)";
        // currentURL=CurrURL;
        AssignmentRulesRefundRequestPO RR = new AssignmentRulesRefundRequestPO(driver);
        RR.assignmentRuleVerificationRR(driver, al, al3, al6, shippedregion, classValue, CurrURL);

        al.clear();
        al3.clear();
        al6.clear();
        al8.clear();
        al9.clear();
        RR = null;
    }

    @Test(groups = { "sanity" }, priority = 2, enabled = false)
    public void AssignmentRuleforAakash() throws Exception {
        System.out.println("-------------------Start of Aakash----------------");
        String shippedregion = "";
        String classValue = "";
        // String currentURL="";
        ArrayList<String> al = new ArrayList<String>();
        ArrayList<String> al3 = new ArrayList<String>(); // Array list for holding all the program ids
        ArrayList<String> al6 = new ArrayList<String>(); // Array list for two program IDs
        ArrayList<String> al8 = new ArrayList<String>(); // Array list for Shipped region
        ArrayList<String> al9 = new ArrayList<String>(); // Array list for class value
        ArrayList<String> al10 = new ArrayList<String>();

        al = excelData.getData("TC1", "RefundProcess", "Tcid");
        al3 = excelData.getData("Aakash K12", "RRCaseAssignment", "Tcid");
        al8 = excelData.getData("shippedRegion", "RRCaseAssignment", "Tcid");
        al9 = excelData.getData("class", "RRCaseAssignment", "Tcid");
        al10 = excelData.getData("Aakash K12", "RRCaseAssignment_2", "Tcid");

        al6 = getTwoRandomProgramID(al3, al10, 1, 4);
        excelData.setData("src\\main\\java\\testData\\TestData.xlsx", "RRCaseAssignment_2", 3, 1, al6.get(0));
        excelData.setData("src\\main\\java\\testData\\TestData.xlsx", "RRCaseAssignment_2", 3, 2, al6.get(1));

        shippedregion = al8.get(randomNumber(1, 8));
        classValue = al9.get(randomNumber(6, 2));

        // currentURL=CurrURL;
        AssignmentRulesRefundRequestPO RR = new AssignmentRulesRefundRequestPO(driver);
        RR.assignmentRuleVerificationRR(driver, al, al3, al6, shippedregion, classValue, CurrURL);

    } 

    @Test(groups = { "sanity" }, priority = 3, enabled = true)
    public void AssignmentRuleforK4_K10() throws Exception {
        System.out.println("-------------------Start of K4-K10----------------");
        String shippedregion = "";
        String classValue = "";
        // String currentURL="";
        ArrayList<String> al = new ArrayList<String>();
        ArrayList<String> al3 = new ArrayList<String>(); // Array list for holding all the program ids
        ArrayList<String> al6 = new ArrayList<String>(); // Array list for two program IDs
        ArrayList<String> al8 = new ArrayList<String>(); // Array list for Shipped region
       // ArrayList<String> al9 = new ArrayList<String>(); // Array list for class value
        ArrayList<String> al10 = new ArrayList<String>();

        al = excelData.getData("TC1", "RefundProcess", "Tcid");
        al3 = excelData.getData("K4-K10 (BTC)+K4-K10(Byjus Classes)+K4-K10(BTLP)", "RRCaseAssignment", "Tcid");
        al8 = excelData.getData("shippedRegion", "RRCaseAssignment", "Tcid");
       // al9 = excelData.getData("class", "RRCaseAssignment", "Tcid");
        al10 = excelData.getData("K4-K10 (BTC)+K4-K10(Byjus Classes)+K4-K10(BTLP)", "RRCaseAssignment_2", "Tcid");

        al6 = getTwoRandomProgramID(al3, al10, 1, 8);
        excelData.setData("src\\main\\java\\testData\\TestData.xlsx", "RRCaseAssignment_2", 5, 1, al6.get(0));
        excelData.setData("src\\main\\java\\testData\\TestData.xlsx", "RRCaseAssignment_2", 5, 2, al6.get(1));

        shippedregion = al8.get(randomNumber(1, 8));
        classValue = String.valueOf(randomNumber(4, 7));// This randomNumber function will return number from 4 to 10

        // currentURL=CurrURL;
        AssignmentRulesRefundRequestPO RR = new AssignmentRulesRefundRequestPO(driver);
        RR.assignmentRuleVerificationRR(driver, al, al3, al6, shippedregion, classValue, CurrURL);

    }

    @AfterMethod(alwaysRun = true)
    public void teardown() throws InterruptedException {
        driver.quit();
       
    }

}