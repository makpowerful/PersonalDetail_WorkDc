package testCases;


import java.io.IOException;

import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.openqa.selenium.WebDriver;

import org.testng.annotations.AfterMethod;

import org.testng.annotations.BeforeMethod;


import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import org.testng.Assert;


import pageObjects.CollectionAssistantLoginPO;
import pageObjects.CreatedAccountPO;
import pageObjects.CreatedCaseRecordPO;
import pageObjects.FirstConnectPO;

import pageObjects.NPPaymentLoanPO;
import pageObjects.NewCaseDetailsPO;
import pageObjects.NewCaseRecordTypePO;
import pageObjects.NewPaymentPO;
import pageObjects.NewPaymentRecordPO;
import pageObjects.PaymentCaseQAPO;
import pageObjects.PaymentsPO;

import pageObjects.UserDetailPO;
import pageObjects.UserSetupPO;
import pageObjects.loginPO;
import resources.ExcelData;
import resources.base;

public class test_Collection_NoCallConnect extends base {

	public WebDriver driver;
	// ThreadLocal<WebDriver> driver = new ThreadLocal<WebDriver>();
	// public String CurrURL;
	public static Logger log = LogManager.getLogger(test_CollectionFlow.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	ArrayList<String> al3 = new ArrayList<String>();
	ArrayList<String> al4 = new ArrayList<String>();
	static Faker faker = new Faker();
	static String firstName = faker.name().firstName();
	static String lastName = faker.name().lastName();
	static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);

	@BeforeMethod(alwaysRun = true)
	public void initialize() throws IOException, InterruptedException {

		driver = initializeDriver();
	}

	@Test(groups = { "sanity", "Regression" }, enabled = true)
	public void Collection_NoCallConnect() throws Exception {

		loginPO lo = new loginPO(driver);
		if (CurrURL.contains("--byjusuatfc")) {
			al = excelData.getData("TC1", "CollectionFlow", "Tcid");
			al2 = excelData.getData("CollectionAssistant UATFC", "Login", "Type");
			al3 = excelData.getData("CollectionManager UATFC", "Login", "Type");
			al4 = excelData.getData("Adminuatfc", "Login", "Type");
			log.info("Logging in as Admin to UATFC");
			lo.LoginAsAdmin_UATFC();

		} else if (CurrURL.contains("--byjusuat")) {
			al = excelData.getData("TC1", "CollectionFlow", "Tcid");
			al2 = excelData.getData("CollectionAssistant UAT1", "Login", "Type");
			al3 = excelData.getData("CollectionManager UAT1", "Login", "Type");
			al4 = excelData.getData("AdminUAT", "Login", "Type");
			log.info("Logging in as Admin to UAT");
			lo.LoginAsAdmin_UAT1();
			// lo.SwitchUser(al2.get(1));

        } else {
            al = excelData.getData("TC1", "CollectionFlow", "Tcid");
            al2 = excelData.getData("Dummy Collection Associate", "Login", "Type");
            al4 = excelData.getData("AdminProd", "Login", "Type");
            log.info("Logging in as Admin to Prod");
            lo.LoginAsAdmin_Prod();
        }
		// Assert.assertTrue(false);
		
		log.info("Creating new Payment record");
		CreatedAccountPO ac = new CreatedAccountPO(driver);
		PaymentsPO p = new PaymentsPO(driver);
		ac.closeTabWindows();
		ac.Notification();
		p.NavMenuClick();
		p.PaymntNavMenuClick();
		p.NewPaymentClick();

		// Assert.assertTrue(false);

		log.info("Selection of Payment - Loan record");
		NewPaymentPO np = new NewPaymentPO(driver);
		np.SelectPaymentOptn(al.get(1));
		np.ClickNext();

		log.info("Enter New Payment - Loan details");
		NPPaymentLoanPO npp = new NPPaymentLoanPO(driver);
		// npp.EnterPayRefID(randomNum);
		npp.EnterParentFN(firstName);
		npp.EnterParentLN(lastName);
		npp.EnterLoanAmount(al.get(2));
		npp.EnterTenurity(al.get(4));
		npp.EnterProgramName(al.get(3));
		npp.EnterEPPartner(al.get(5));
		npp.EnterAmount(al.get(6));
		npp.EnterTotalAmountTBC(al.get(7));
		npp.EnterNetPayAmount(al.get(8));
		npp.EnterPaymentAmount(al.get(9));
		npp.EnterPaymentCategory(al.get(10));
		npp.EnterPaymentMS(al.get(11));
		npp.EnterPaymentDate(al.get(12));
		npp.EnterPaymentType(al.get(13));
		npp.ClickSave();
		// Assert.assertTrue(false);
		NewPaymentRecordPO npr = new NewPaymentRecordPO(driver);
		String PaymentRecord = npr.CapturePaymentRcdID();
		log.info("New Payment Record " + PaymentRecord + " created successfully");
		
		// User Story SFDC-1502
		npr.ClickStudentPayments();
		log.info("Linking New Account Record for " + PaymentRecord);
		PaymentCaseQAPO pcqa = new PaymentCaseQAPO(driver);
		pcqa.ClickCaseNewButton(PaymentRecord);
		NewCaseDetailsPO ncd = new NewCaseDetailsPO(driver);
		ncd.EnterStudentAcctName("dummy");
		ncd.clickStudentPaymentSave();
		ac.CloseSubTabs();
		
		p.ClickStudentPaymentRecord();
	    String accountName=npr.getStudentAcctName();
	    String accountStatus=npr.getAcctStatus();
	    String accountSuperStatus=npr.getAcctSuprStatus();
	    npr.getStudntAcctName();
	    String accntName = ac.CaptureAccOwnrNam();
	    Assert.assertEquals(accntName, accountName);	
	    String Status = ac.CaptureStatus();
	    Assert.assertTrue(Status.equalsIgnoreCase(accountStatus));	 
	    String SuperStatus = ac.CaptureSuperStatus();
		Assert.assertTrue(SuperStatus.equalsIgnoreCase(accountSuperStatus));		
		ac.CloseSubTabs();     
		
		npr.ClickCasesQA();

		log.info("Creating New Case Record for " + PaymentRecord);		
		pcqa.ClickCaseNewButton(PaymentRecord);

		NewCaseRecordTypePO ncrt = new NewCaseRecordTypePO(driver);
		ncrt.SelectCaseRecordType(al.get(14));
		ncrt.ClickNext();
		ac.AdditionalWait();
		

		ncd.EnterSubject(al.get(43));
		if (CurrURL.contains("--byjusuatfc")) {
			ncd.EnterOrders(randomNum);
			ncd.SelectReasonForRefund(al.get(44));
			ncd.EnterStudentSalesOrder();
		}
		ncd.ClickSave();

		CreatedCaseRecordPO ccr = new CreatedCaseRecordPO(driver);
		String CaseRecord = ccr.CaptureNewCaseRecord();
		log.info("New Case Record " + CaseRecord + " created successfully");

		String AccountURL = driver.getCurrentUrl();

		if (!CurrURL.contains("--byjusuatfc")) {
			ccr.ClickAssingedTo();
			ccr.EnterAssingedTo2(al2.get(1));
			ccr.ClickSave();
		} else if (CurrURL.contains("--byjusuatfc")) {
			lo.SwitchUser(al4.get(3));
			ac.closeTabWindows();
			ac.Notification();
			// ac.NavBackToAccount();
			ac.goTo(AccountURL);
			Thread.sleep(5000);
			ccr.ClickAssingedTo();
			ccr.EnterAssingedTo2(al2.get(1));
			ccr.ClickSave();
		} 

		// Logging in as the assigned user
		ccr.ClickAssignedUser2(al2.get(1));
		log.info("Logging in as Collection Assistant " + FullName(al2.get(1)));
		UserDetailPO ud = new UserDetailPO(driver);
		ud.ClickUserDetailbutton();

		if (CurrURL.contains("--byjusuatfc")) {
			AccountURL = driver.getCurrentUrl();
			lo.OnlyLogout();
			ac.goTo(AccountURL);
			Thread.sleep(4000);
		}

		UserSetupPO us = new UserSetupPO(driver);
		us.ClickLoginbutton();

		CollectionAssistantLoginPO cal = new CollectionAssistantLoginPO(driver);
		cal.ClickBellicon();
		al2 = excelData.getData("Admin", "Login", "Type");
		if (CurrURL.contains("--byjusuatfc")) {
			cal.SelectAssignedTask(taskName(al4.get(3)));
		} else {
			cal.SelectAssignedTask(taskName(al4.get(1)));
		}
		
		// User story SFDC-2045
		FirstConnectPO fc = new FirstConnectPO(driver);
		String Firstconnect_caseid = fc.CaptureFCcaseid();
		// Compare the Case Record to First connect case Record
		Assert.assertEquals(CaseRecord, Firstconnect_caseid);
		log.info("Verifying No Call Connect for Case record " + Firstconnect_caseid);
		String val = fc.verifyNoCallConnectBtn();
		Assert.assertEquals("No Call Connect", val);
		fc.clickNoCallConnectBtn();
		String val1 = fc.verifyCallStatuses("DNP");
		Assert.assertEquals("DNP", val1);
		String val2 = fc.verifyCallStatuses("ATCB");
		Assert.assertEquals("ATCB", val2);
		String val3 = fc.verifyCallStatuses("Language Barrier");
		Assert.assertEquals("Language Barrier", val3);
		String val4 = fc.verifyCallStatuses("CX Disconnected - Blank call");
		Assert.assertEquals("CX Disconnected - Blank call", val4);
		
		// User story SFDC-3181
		Assert.assertTrue(fc.verifyRadioBtn("DNP"), "DNP radio button is not present ");
		Assert.assertTrue(fc.verifyRadioBtn("ATCB"), "ATCB radio button is not present ");
		Assert.assertTrue(fc.verifyRadioBtn("Language Barrier"), "Language Barrier radio button is not present ");
		Assert.assertTrue(fc.verifyRadioBtn("CX Disconnected - Blank call"), "CX Disconnected - Blank call radio button is not present ");
		ac.CloseSubTabs();
		
		String noPaymnt = fc.verifyNoPaymntBtn();
		Assert.assertEquals("No Payment", noPaymnt);
		fc.clickNoPaymntBtn();
		Assert.assertTrue(fc.verifyRadioBtn("No Payment"), "No Payment radio button is not present ");
		Assert.assertTrue(fc.verifyRadioBtn("Loan Closure"), "Loan Closure radio button is not present ");
		Assert.assertTrue(fc.verifyRadioBtn("Facing Issues-BYJUS"), "Facing Issues-BYJUS radio button is not present ");
		Assert.assertTrue(fc.verifyRadioBtn("CX requested for Cancellation"), "CX requested for Cancellation radio button is not present ");	
		Assert.assertTrue(fc.verifyRadioBtn("Intent to Pay"), "Intent to Pay radio button is not present ");
		Assert.assertTrue(fc.verifyRadioBtn("SUP Call"), "SUP Call radio button is not present ");
		Assert.assertTrue(fc.verifyRadioBtn("Refuse to Pay"), "Refuse to Pay radio button is not present ");
		
		log.info("Logging out as Collection Assistant");
		// cal.CloseNotification();
		//Thread.sleep(1000);
		// cal.Logout();
		lo.Logouthome();

		log.info("Deleting the created Payment Record " + PaymentRecord);
		p.NavMenuClick();
		p.PaymntNavMenuClick();
		p.DeletePayRecord(PaymentRecord);
		

	}

	@AfterMethod(alwaysRun = true)
	public void teardown() throws InterruptedException {

		driver.quit();

	}

}
