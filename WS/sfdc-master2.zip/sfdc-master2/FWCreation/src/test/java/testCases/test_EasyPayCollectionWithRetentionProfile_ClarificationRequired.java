package testCases;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import junit.framework.Assert;
import pageObjects.CasesPO;
import pageObjects.CreatedAccountPO;
import pageObjects.InboundTaskPO;
import pageObjects.IssueTreePO;
import pageObjects.NewCaseRecordTypePO;
import pageObjects.loginPO;
import payLoad.payLoad_EasyPay;
import resources.ExcelData;
import resources.base;

public class test_EasyPayCollectionWithRetentionProfile_ClarificationRequired extends base {

    public WebDriver driver;
    // public String CurrURL;
    public static Logger log = LogManager.getLogger(test_EasyPayCollection.class.getName());
    ExcelData excelData = new ExcelData();
    ArrayList<String> al = new ArrayList<String>();
    ArrayList<String> al2 = new ArrayList<String>();
    ArrayList<String> al3 = new ArrayList<String>();
    ArrayList<String> al4 = new ArrayList<String>();
    ArrayList<String> al5 = new ArrayList<String>();
    ArrayList<String> retentionProfileUser=new ArrayList<String>();
    ArrayList<String> auditManager1=new ArrayList<String>();
    static Faker faker = new Faker();
    static String firstName = faker.name().firstName();
    static String lastName = faker.name().lastName();
    static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);

    @BeforeMethod(alwaysRun = true)
    public void initialize() throws IOException, InterruptedException {

        driver = initializeDriver();

    }

    @Test(groups = { "sanity", "Regression" }, enabled = true)
    public void TestEasyPayCollection_RetentionProfile_ClarificationRequired() throws Exception {
        String Accountid = null;
        al5 = excelData.getData("TC4", "EasyPayCollection", "Tcid");
        loginPO lo = new loginPO(driver);
        if (CurrURL.contains("--byjusuatfc")) {
            al = excelData.getData("TC1", "EasyPayCollection", "Tcid");

            log.info("Logging in as Admin to UATFC");
            lo.LoginAsAdmin_UATFC();
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_EasyPay.AccountidCreationResponse_UATFC();
            log.info("Launching the newly created Account id " + Accountid);

        } else if (CurrURL.contains("--byjusuat")) {
            al = excelData.getData("TC1", "EasyPayCollection", "Tcid");

            log.info("Logging in as Admin to UAT");
            lo.LoginAsAdmin_UAT();
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_EasyPay.AccountidCreationResponse_UAT();
            log.info("Launching the newly created Account id " + Accountid);

        } else if (CurrURL.contains("--byjusqa")) {
            al = excelData.getData("TC1", "EasyPayCollection", "Tcid");
            // al2 = excelData.getData("Collection Assistant QA", "Login", "Type");
            log.info("Logging in as Admin to QA Env");
            lo.LoginAsAdmin_QA();
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_EasyPay.AccountidCreationResponse_QA();
            log.info("Launching the newly created Account id " + Accountid);
        } else {
            al = excelData.getData("TC1", "EasyPayCollection", "Tcid");
            // al2 = excelData.getData("Collection Assistant", "Login", "Type");
            log.info("Logging in as Admin to Prod");
            lo.LoginAsAdmin_Prod();
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_EasyPay.AccountidCreationResponse_Prod();
            log.info("Launching the newly created Account id " + Accountid);
        }
        closeTabWindows();
        retentionProfileUser=excelData.getData("Retention User UAT", "Login", "Type");       
        lo.SwitchUser(retentionProfileUser.get(1));
        closeTabWindows();
        CreatedAccountPO ac = new CreatedAccountPO(driver);
        ac.Notification();
        ac.NavBackToAccount();
        String accntUrl=CurrURL + Accountid;
        ac.goTo(accntUrl);
        ac.AccountLoadwait();
        ac.Scrollpagedown();

        log.info("Creating Inbound Task");
        ac.ClickOpenActivitiestoNewTask();

        NewCaseRecordTypePO ncrt = new NewCaseRecordTypePO(driver);

        ncrt.SelectCaseRecordTypeInbound();
        ncrt.ClickNext();
        ac.AdditionalWait();
        ncrt.ClickSave();
        ac.AdditionalWait();

        InboundTaskPO ibdt = new InboundTaskPO(driver);
        ibdt.ClickCaptureDetail();
        Thread.sleep(3000);

        ibdt.ClickProceedOptn();
        if (CurrURL.contains("--byjusuat") || CurrURL.contains("--byjusuatfc") || CurrURL.contains("byjusprod.")) {
            al3 = excelData.getData("Inbound", "Inbound", "Tcid");
            al4 = excelData.getData("TC2", "EasyPayCollection", "Tcid");
            IssueTreePO it = new IssueTreePO(driver);
            if (!CurrURL.contains("--byjusuatfc")) {
                ibdt.SelectSpokeTo3(al3.get(1));
                it.PremiumidSelector();
                it.ProgramSelector();
                it.ClickNext();
            }
            ibdt.SelectPSTCT(al3.get(2));
            // ibdt.EnterNotesVal(al3.get(3));
            ibdt.ClickNext();
            ac.AdditionalWait();
            it.IssueCategory(al4.get(12));
            it.IssueType(al4.get(13));
            it.IssueSubType(al4.get(14));
            it.IssueNotes(al4.get(15));
            it.IstheIssueResolved(al4.get(16));
            it.ClickNext3();
            it.OrderID();
            it.PaymentID();
            it.ClickNext3();
        } else {
            ibdt.SelectPSTCT(al.get(1));
            // ibdt.EnterNotesVal(al.get(2));
            ibdt.ClickNext();
            ac.AdditionalWait();
            ibdt.SelectDevice(al.get(3));
            ibdt.SelectCategory(al.get(4));
            ibdt.SelectSubCategory(al.get(10));
            ibdt.SelectIssueSubType(al.get(11));
            ibdt.SelectIsTICR(al.get(8));
            ibdt.EnterComments(al.get(7));
            ibdt.ClickNext();
            Thread.sleep(3000);
        }
        ac.AdditionalWait();
        ibdt.NavBackAccount();
        ac.CloseSubTabs();
        ac.Scrollpagedown();
        ac.ClickCasesMC();

        CasesPO cases = new CasesPO(driver);
        String casesUrl = driver.getCurrentUrl();
        String CaseNumber = cases.CaseRN();
        cases.CaseOptnSel();
        String easyPayCollectionCaseUrl=driver.getCurrentUrl();
        lo.OnlyLogout();
        
        // Login as Audit Manager
        auditManager1=excelData.getData("Audit Manager", "Login", "Type"); 
        String auditManager = auditManager1.get(1); //"Gowthamkumar B";  
        lo.LogbackwithUser(auditManager);
        closeTabWindows();
        ac.goTo(easyPayCollectionCaseUrl);
        ac.AdditionalWait();
        String caseOwner=cases.easyPayCaseOwner();
        Assert.assertEquals("CGR-Digital Finance", caseOwner);
        cases.easyPayCaseOwnerChangeIcon();
        cases.easyPaySearchUsersField(auditManager);
        cases.easyPayChangeOwnerbtn();
        cases.easyPayTakeActionbtn();
        cases.switchToTheFrame();
        ibdt.ClickNext();
        cases.radiobtnResolved(al5.get(17));//"Clarification Required"
        cases.EnterClarificationReq(al5.get(7));//("Entering test comments"); 
        ibdt.ClickNext();
        ac.AdditionalWait();
        ac.RefreshTab();
        String createdBy = cases.createdBy();
  //      caseOwner=cases.getEasyPayCaseOwnerDetailsSection();
 //       Assert.assertEquals(createdBy, caseOwner);
        
        // Opening the open task and asserting the texts
        if(CurrURL.contains("--byjusuat")) {
            ac.Scrollpagedown();
            ac.Scrollpagedown();
            ac.Scrollend();
        }
        String taskName=cases.easyPayOpenActivityTaskClarificationRequired();
        Assert.assertEquals("Clarification Required", taskName);
        cases.ClickEasyPayOpenActivityTaskClarificationRequired();
        String subject=cases.easyPayTaskSubj();
        Assert.assertEquals("Clarification Required", subject);
       
        String relatedTo = cases.easyPayTaskRelatedToTxt();
        Assert.assertEquals(CaseNumber, relatedTo);
        String assignedTo = cases.easyPayTaskAssignedTo();
        Assert.assertEquals(createdBy, assignedTo);
        String status = cases.easyPayTaskStatus();
        Assert.assertEquals("Open", status);
        cases.easyPayEditStatus();
        cases.easyPaySelectStatus("Completed");
        cases.btnSaveEasyPay();
        ac.AdditionalWait();
        String txtAccess=cases.easyPayTaskInsufficientAccess();
        Assert.assertEquals((al5.get(15)), txtAccess); 
        cases.btnCancelEasyPay();
        lo.OnlyLogout();
        lo.LogbackwithUser(createdBy);
        closeTabWindows();
        ac.goTo(easyPayCollectionCaseUrl);
        ac.AdditionalWait();
        caseOwner=cases.getCaseOwnerEasypay();
        Assert.assertEquals(auditManager, caseOwner);
        if(CurrURL.contains("--byjusuat")) {
            ac.Scrollpagedown();
            ac.Scrollpagedown();
            ac.Scrollend();
        }
        cases.ClickEasyPayOpenActivityTaskClarificationRequired();
        cases.easyPayEditStatus();
        cases.easyPaySelectStatus("Completed");
        cases.EnterClarificationComments("Clarification Comments");
        cases.btnSaveEasyPay();
        //clicking twice due to an issue
        cases.btnSaveEasyPay();
        ac.AdditionalWait();
        lo.RefreshURL();
        ac.RefreshTab();
        status = cases.easyPayTaskStatus();
        Assert.assertEquals("Completed", status);
        
        lo.OnlyLogout();
        ac.goTo(casesUrl);
        ac.AdditionalWait();
        cases.CloseAllCases();

        log.info("Deleting the Student Program details");
        ac.goTo(accntUrl);
        ac.AdditionalWait();
        ac.Scrollpagedown();
        ac.DeleteCreatedStuProg();
        ac.DeleteAllCreatedStuPayment();
        ac.NavBackToAccount();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());

    }

    @AfterMethod(alwaysRun = true)
    public void teardown() throws InterruptedException {

       driver.quit();

        // ac.AdditionalWait();
    }

}
