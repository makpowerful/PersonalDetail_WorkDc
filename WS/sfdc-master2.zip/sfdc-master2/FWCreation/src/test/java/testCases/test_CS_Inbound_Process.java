package testCases;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import junit.framework.Assert;
import pageObjects.CSInboundPO;
import pageObjects.CreatedAccountPO;
import pageObjects.CreatedCaseRecordPO;
import pageObjects.InboundTaskPO;
import pageObjects.NewCaseRecordTypePO;
import pageObjects.UnregisteredCustomersDetailCaptureTaskPO;
import pageObjects.loginPO;
import payLoad.payLoad_BTLA2;
import resources.ExcelData;
import resources.base;

public class test_CS_Inbound_Process extends base {

    public WebDriver driver;
    ExcelData excelData = new ExcelData();
    public static Logger log = LogManager.getLogger(test_CS_Inbound_Process.class.getName());
    ArrayList<String> proddummyuser = new ArrayList<String>();
    ArrayList<String> al = new ArrayList<String>();
    ArrayList<String> al2 = new ArrayList<String>();
    //SoftAssert softassert = new SoftAssert();

    @BeforeMethod(alwaysRun = true)
    public void initialize() throws IOException, InterruptedException {

        driver = initializeDriver();

    }

    @Test(groups = { "sanity", "UAT" }, enabled = true)
    public void TestCS_Inbound_Process() throws Exception {
        
        proddummyuser = excelData.getData("TC1", "ProdDummyUser", "Tcid");
        String Accountid = null;
        loginPO lo = new loginPO(driver);
        CreatedCaseRecordPO ccr = new CreatedCaseRecordPO(driver);

        if (CurrURL.contains("--byjusuat")) {
            al = excelData.getData("TC1", "CSInbound", "Tcid");
            al2 = excelData.getData("CS User UAT", "Login", "Type");

            log.info("Logging in as Admin to UAT then switching user to Customer Support");
            lo.LoginAsAdmin_UAT();
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_BTLA2.AccountidCreationResponse_UAT();
            log.info("Launching the newly created Account id " + Accountid);

        } else {
            al = excelData.getData("TC1", "CSInbound", "Tcid");
            // al2 = excelData.getData("Collection Assistant", "Login", "Type");
            log.info("Logging in as Admin to Prod");
            lo.LoginAsAdmin_Prod();
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_BTLA2.AccountidCreationResponse_Prod();
            log.info("Launching the newly created Account id " + Accountid);
        }

        closeTabWindows();

        CreatedAccountPO ac = new CreatedAccountPO(driver);
        // Open the account by searching PID
        ac.Notification();
        ac.NavBackToAccount();
        String AccountURL = CurrURL + Accountid;
        ac.goTo(AccountURL);
        Thread.sleep(5000);

        if (CurrURL.contains("--byjusuat")) {
            String AccountOwner = ac.AccOwnerCheck();
            if (!al2.get(1).equalsIgnoreCase(AccountOwner)) {
                ac.AssignAccount(al2.get(1));
            }
        } else {
            ac.AssignAccount("Testing User");
        }

        if (CurrURL.contains("--byjusuat")) {
            lo.SwitchUser(al2.get(1));
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);

        } else {
            lo.SwitchUsernProfile_Prod(proddummyuser.get(1),"Customer Support");
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            Thread.sleep(5000);
        }
        CSInboundPO cip = new CSInboundPO(driver);
        NewCaseRecordTypePO ncrt = new NewCaseRecordTypePO(driver);
        InboundTaskPO ibdt = new InboundTaskPO(driver);
        UnregisteredCustomersDetailCaptureTaskPO ucdc = new UnregisteredCustomersDetailCaptureTaskPO(driver);
        
        String AccountName = ac.CaptureAccOwnrNam();
        log.info("Creating Inbound Task");
   
        ac.ClickOpenActivitiestoNewTask();     
        ncrt.UCDetailsCapture();
        ncrt.ClickNext();
        String phoneNumber=cip.tenDigitNumber();
        cip.textFieldCallBackNumber(phoneNumber);
        ac.AdditionalWait(); 
        ncrt.ClickSave();
        ibdt.ClickCaptureDetail();

        cip.EnterCallType(al.get(2));
        cip.EnterCallStatus(al.get(3));
        cip.EnterCustomerType( al.get(4));
        cip.textFieldSearchStudent().sendKeys(AccountName);
        ac.AdditionalWait(); 
        cip.ClicktextFieldSearchStudentResult(AccountName);
        ncrt.ClickNextButton();
        driver.switchTo().defaultContent();
        
        log.info("Verifying Student Details");
        String studentName = cip.studentName();
        Assert.assertNotNull(studentName, "Student Name is not displayed");

        String parentName = cip.parentName();
        Assert.assertNotNull(parentName, "Parent Name is not displayed");

        String email = cip.email();
        Assert.assertNotNull(email, "Email is not displayed");

        //String phone = cip.phone(driver);
        //Assert.assertNotNull(phone, "Phone is not displayed");

        String status = cip.status();
        Assert.assertNotNull(status, "Status is not displayed");

        String superStatus = cip.superStatus();
        Assert.assertNotNull(superStatus, "SuperStatus is not displayed");
        driver.switchTo().defaultContent();
        
        ucdc.switchToFrame();

        ucdc.SelectEnquiryType(al.get(5));
        ucdc.SelectReasonForCall(al.get(6));

        ucdc.SelectCourse(al.get(7));
        ucdc.SelectCountry(al.get(8));
        ucdc.ClickNext();
        driver.switchTo().defaultContent();

        ucdc.EnterName2(AccountName);
        ucdc.EnterLanguage(al.get(10));

        ucdc.EnterCity(al.get(9));
        ucdc.EnterReasonForCall(al.get(11));
        ucdc.EnterGrade(al.get(12));
        ucdc.EnterCourse(al.get(13));
        ucdc.EnterEnquiryBy(al.get(14));
        ucdc.EnterPurchasedCourseBefore(al.get(15));
        ucdc.EnterIsthisrepeatcall(al.get(16));
        ucdc.EnterBriefComment(al.get(17));
        ucdc.EnterHDYKAByjus(al.get(18));
        Thread.sleep(1000);
        ucdc.ClickNext();
        driver.switchTo().defaultContent();

        // ucdc.SelectTasktoCentralRetentionTeam_2(al.get(19));
        ucdc.switchToFrame();
        Thread.sleep(1000);
        ucdc.Selecttransfercall(al.get(19));
        ucdc.ClickNext();
        driver.switchTo().defaultContent();
        ac.AdditionalWait();
        ucdc.switchToFrame();
        ucdc.ClickFinish();       
        
        driver.switchTo().defaultContent();

        ccr.closeCurrentTab("Manual Queue-Details capture");

        // -------------------------------------------------------------------------
        //Code to again create the Manual Queue task and verify that correct information is fetched from LS
        
        ac.ClickOpenActivitiestoNewTask();

        ncrt.UCDetailsCapture();
        ncrt.ClickNext();
        cip.textFieldCallBackNumber(phoneNumber);
        ac.AdditionalWait(); 
        ncrt.ClickSave();
        ibdt.ClickCaptureDetail();

        cip.EnterCallType(al.get(2));
        cip.EnterCallStatus(al.get(3));
        cip.EnterCustomerType(al.get(4));
        cip.textFieldSearchStudent().sendKeys(AccountName);
        ac.AdditionalWait(); 
        cip.ClicktextFieldSearchStudentResult(AccountName);
        ncrt.ClickNextButton();
        driver.switchTo().defaultContent();

        studentName = cip.studentName();
        
        Assert.assertNotNull(studentName, "Student Name is not displayed");

        parentName = cip.parentName();
      
        Assert.assertNotNull(parentName, "Parent Name is not displayed");

        email = cip.email();
        Assert.assertNotNull(email, "Email is not displayed");

        //phone = cip.phone(driver);
        //Assert.assertNotNull(phone, "Phone is not displayed");

        status = cip.status();
        Assert.assertNotNull(status, "Status is not displayed");

        superStatus = cip.superStatus();
        Assert.assertNotNull(superStatus, "SuperStatus is not displayed");
       // ucdc.switchToFrame();
       
        ucdc.SelectEnquiryType(al.get(5));
        ucdc.SelectReasonForCall(al.get(6));

        ucdc.SelectCourse(al.get(7));
        ucdc.SelectCountry(al.get(8));
        ucdc.ClickNext();
        driver.switchTo().defaultContent();
        
        ucdc.switchToFrame();
        String studentName2 = ucdc.getName();
        System.out.println("Student Name "+studentName2);
        Assert.assertEquals(studentName2, studentName);

        String city2 = ucdc.getCity();
        System.out.println("City name "+city2);
        Assert.assertEquals(city2, al.get(9));

        String Language = ucdc.getLanguage();
        System.out.println("Language Name "+Language);
        Assert.assertEquals(Language, al.get(10));

        String reasonCall = ucdc.reasonForCall();
        System.out.println("Reason for Call"+reasonCall);
        Assert.assertEquals(reasonCall, al.get(6));

        String grade = ucdc.getGrade();
        System.out.println("Grade "+grade);
        Assert.assertEquals(grade, al.get(12));

        String course = ucdc.getCourse();
        System.out.println("Course "+course);
        Assert.assertEquals(course, al.get(13));
        
        driver.switchTo().defaultContent();
        
        ucdc.switchToFrame();
        ucdc.EnterEnquiryBy(al.get(14));
        ucdc.EnterPurchasedCourseBefore(al.get(15));
        ucdc.EnterIsthisrepeatcall(al.get(16));
        ucdc.EnterBriefComment(al.get(17));
        ucdc.EnterHDYKAByjus(al.get(18));
        Thread.sleep(1000);
        ucdc.ClickNext();
        driver.switchTo().defaultContent();

        // ucdc.SelectTasktoCentralRetentionTeam_2(al.get(19));
        ucdc.switchToFrame();
        ucdc.Selecttransfercall(al.get(19));
        ucdc.ClickNext();
        driver.switchTo().defaultContent();
        ac.AdditionalWait();
        ucdc.switchToFrame();       
       
        String sucessMsg2 = ucdc.getMessage();
        
        Assert.assertEquals(sucessMsg2, "Task has been completed successfully. Click Next to close the window.");
        ucdc.ClickFinish();
        driver.switchTo().defaultContent();
        ccr.closeCurrentTab("Manual Queue-Details capture");
        
        //-------------------------------------------------
    
        log.info("Verifying OXMS integration");
        ac.ClickOpenActivitiestoNewTask();     
        ncrt.UCDetailsCapture();
        ncrt.ClickNext();
          phoneNumber=cip.tenDigitNumber();
        cip.textFieldCallBackNumber(phoneNumber);
        ac.AdditionalWait(); 
        ncrt.ClickSave();
        ibdt.ClickCaptureDetail();

        cip.EnterCallType(al.get(2));
        cip.EnterCallStatus(al.get(3));
        cip.EnterCustomerType( al.get(20));        
        ncrt.ClickNextButton();
        driver.switchTo().defaultContent();
        Thread.sleep(5000);
        ucdc.switchToFrame();
   
        ucdc.switchToOXMSFrame();
        ucdc.textFieldMobileNumber().sendKeys("9897605099");
        Thread.sleep(15000);
        Scrolldown();
        Scrollend();
       
        driver.switchTo().defaultContent();   
        ucdc.switchToFrame();
        ucdc.ClickNext();
        driver.switchTo().defaultContent();  
        
        ucdc.switchToFrame();

        ucdc.SelectEnquiryType(al.get(5));
        ucdc.SelectReasonForCall(al.get(6));

        ucdc.SelectCourse(al.get(7));
        ucdc.SelectCountry(al.get(8));
        ucdc.ClickNext();
        driver.switchTo().defaultContent();

        ucdc.EnterName2(AccountName);
        ucdc.EnterLanguage(al.get(10));
        ucdc.EnterCity(al.get(9));
        ucdc.EnterReasonForCall(al.get(11));
        ucdc.EnterGrade(al.get(12));
        ucdc.EnterCourse(al.get(13));
        ucdc.EnterEnquiryBy(al.get(14));
        ucdc.EnterPurchasedCourseBefore(al.get(15));
        ucdc.EnterIsthisrepeatcall(al.get(16));
        ucdc.EnterBriefComment(al.get(17));
        ucdc.EnterHDYKAByjus(al.get(18));
        ucdc.ClickNext();
        driver.switchTo().defaultContent();

        ucdc.switchToFrame();
        ucdc.ClickNext();      
        
        driver.switchTo().defaultContent();
        ccr.closeCurrentTab("Manual Queue-Details capture");       
        
        lo.OnlyLogout();
        ac.goTo(AccountURL);
        ac.AdditionalWait();      
        log.info("Deleting the Student Program details");
        ac.ClickAccOwnrTab();
        ac.Scrollpagedown();
        ac.DeleteCreatedStuProg();
        ac.DeleteAllCreatedStuPayment();
        ac.NavBackToAccount();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
       // softassert.assertAll();
        }  
         
    
    @AfterMethod(alwaysRun = true)
    public void teardown() throws InterruptedException {

        driver.quit();

    }

}

