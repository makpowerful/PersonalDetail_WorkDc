package testCases;

import java.io.IOException;
import java.util.ArrayList;

import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.openqa.selenium.WebDriver;

import org.testng.annotations.AfterMethod;

import org.testng.annotations.BeforeMethod;

import org.testng.annotations.Test;


import com.github.javafaker.Faker;

import org.testng.Assert;


import pageObjects.CreatedAccountPO;


import pageObjects.NewCaseRecordTypePO;
import pageObjects.OpenActivitiesPO;

import pageObjects.PreBoardsSurveyTaskPO;




import pageObjects.loginPO;

import payLoad.payLoad_SinglePrgm;
import resources.ExcelData;
import resources.base;



public class test_AnnualMockExam extends base {

	public WebDriver driver;
	//public String CurrURL;
	public static Logger log = LogManager.getLogger(test_AnnualMockExam.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> proddummyuser = new ArrayList<String>();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	ArrayList<String> al3 = new ArrayList<String>();
	
	static Faker faker = new Faker();
	static String firstName = faker.name().firstName();
	static String lastName = faker.name().lastName();
	static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);
	
	@BeforeMethod(alwaysRun = true)
	public void initialize() throws IOException, InterruptedException {

		driver = initializeDriver();

	}
	
	
	@Test(groups = {"sanity", "UAT" }, enabled = true)
	public void TestAnnualMockExam() throws Exception {
	    proddummyuser = excelData.getData("TC1", "ProdDummyUser", "Tcid");
		String Accountid = null;
		loginPO lo=new loginPO(driver);
		al3 = excelData.getData("TC01", "Trial", "Tcid");
		if(CurrURL.contains("--byjusuatfc")) {
			al = excelData.getData("Hybrid Tuitions at BYJU'S Learning Center", "Picklist", "Tcid");
			//al2 = excelData.getData("Collection Assistant QA", "Login", "Type");
			log.info("Logging in as Admin to UATFC Env");
			lo.LoginAsAdmin_UATFC();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_SinglePrgm.AccountidCreationResponse_UATFC(al.get(1), al.get(2), al.get(3), al.get(4));
			log.info("Launching the newly created Account id "+Accountid);
		}
		else if(CurrURL.contains("--byjusuat")) {
			al = excelData.getData("Hybrid Tuitions at BYJU'S Learning Center", "Picklist", "Tcid");
		//al2 = excelData.getData("Collection Assistant", "Login", "Type");
		
		log.info("Logging in as Admin to UAT");
		lo.LoginAsAdmin_UAT1();
		log.info("Submitting the Account creation payload");
		Accountid=payLoad_SinglePrgm.AccountidCreationResponse_UAT(al.get(1), al.get(2), al.get(3), al.get(4));
		log.info("Launching the newly created Account id "+Accountid);
		
		}
		else {
			al = excelData.getData("Hybrid Tuitions at BYJU'S Learning Center", "Picklist", "Tcid");
			//al2 = excelData.getData("Collection Assistant", "Login", "Type");
			log.info("Logging in as Admin to Prod");
			lo.LoginAsAdmin_Prod();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_SinglePrgm.AccountidCreationResponse_Prod(al.get(1), al.get(2), al.get(3), al.get(4));
			log.info("Launching the newly created Account id "+Accountid);
		}

		
		
		CreatedAccountPO ac=new CreatedAccountPO(driver);
		//StudentProgPO sp= new StudentProgPO(driver);
		NewCaseRecordTypePO ncrt= new NewCaseRecordTypePO(driver);
		OpenActivitiesPO oa = new OpenActivitiesPO(driver);
		PreBoardsSurveyTaskPO pbs= new PreBoardsSurveyTaskPO(driver);
		//Open the account by searching PID
		ac.closeTabWindows();
		ac.Notification();
		ac.NavBackToAccount();
		String AccountURL = CurrURL+Accountid;
		ac.goTo(CurrURL+Accountid); 
		ac.AccountLoadwait();
		
		al2 = excelData.getData("PE User UAT", "Login", "Type");
        //Logging in as PE
        if(CurrURL.contains("--byjusuat")||CurrURL.contains("--byjusuatfc")) {
            String AccountOwner= ac.AccOwnerCheck();
            if(!al2.get(1).equalsIgnoreCase(AccountOwner)) {
                ac.AssignAccount(al2.get(1));
            }
        }
        else {
            ac.AssignAccount("Testing User");
        }       
        //String MainWin = driver.getWindowHandle();
		
		//Creating 4 Pre Boards Survey Tasks as Admin
		for(int i=0;i<3;i++) {
		ac.ClickOpenActivitiestoNewTask();
        ncrt.SelectTaskRecordType("Pre Boards Survey");
        ncrt.ClickNext();
        ncrt.EnterSubject("Annual Mock Exams Survey Task");
        ncrt.SelectActionType("Annual Mock Exam");
        ncrt.ClickSave();
        ac.AdditionalWait();
        ac.CloseSubTabs();
		}
        
		//Logging on as PE
        if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
            lo.SwitchUser(al2.get(1));
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AccountLoadwait();   
            }
            else if(CurrURL.contains("--byjusuatfc")) {
                lo.SwitchUser(al2.get(1));
                ac.closeTabWindows();
                ac.Notification();
                ac.NavBackToAccount();
                ac.goTo(AccountURL);
                ac.AccountLoadwait();

            }
            else {
                lo.SwitchUsernProfile_Prod(proddummyuser.get(1),"PE");
                ac.closeTabWindows();
                ac.Notification();
                ac.NavBackToAccount();
                ac.goTo(AccountURL);
                ac.AccountLoadwait();
            }
            
        //Navigating to Open Activities Task - DNP flow
        ac.ClickOpenActivities();
        oa.SelectTaskNumber("Annual Mock Exams Survey Task",1);
        
        Assert.assertEquals(pbs.CaptureDNPCounter(), "0");
        pbs.ClickCaptureDetail();
        pbs.SelectDNP();
        ac.RefreshTab_Targetframe();
        Assert.assertEquals(pbs.CaptureDNPCounter(), "1");
        
        pbs.ClickCaptureDetail();
        pbs.SelectDNP();
        ac.RefreshTab_Targetframe_IT();
        Assert.assertEquals(pbs.CaptureDNPCounter(), "2");
        
        pbs.ClickCaptureDetail();
        pbs.SelectDNP();
        ac.RefreshTab_Targetframe_IT();
        Assert.assertEquals(pbs.CaptureDNPCounter(), "3");
        
        pbs.ClickCaptureDetail();
        pbs.SelectDNP();
        ac.RefreshTab_Targetframe_IT();
        Assert.assertEquals(pbs.CaptureDNPCounter(), "4");
        Assert.assertEquals(pbs.CaptureStatus(), "Completed");
        ac.CloseSubTabs();
        
        //Navigating to Open Activities Task - Customer Call Back Requested flow
        ac.ClickOpenActivities();
        oa.SelectTaskNumber("Annual Mock Exams Survey Task",1);
        
        pbs.ClickCaptureDetail();
        pbs.SelectCallBackRequested();
        
        ac.RefreshTab_Targetframe();
        Assert.assertEquals(pbs.CaptureCallStatus(),"Call Back Requested");
        ac.CloseSubTabs();
        
        //Navigating to Open Activities Task - Proceed flow
        ac.ClickOpenActivities();
        oa.SelectTaskNumber("Annual Mock Exams Survey Task",2);
        
        pbs.ClickCaptureDetail();
        pbs.SelectProceed_iframe();
        
        pbs.EnterPleaseConfirmCurrentClass(al3.get(1));
        pbs.EnterPleaseConfirmCurrentBoard(al3.get(2));
        pbs.EnterStudentParentInterest(al3.get(3));
        pbs.EnterCommunicatedDataTime(al3.get(4));
        pbs.ClickNext();
        pbs.ClickFinish();
        ac.AdditionalWait();
        ac.CloseSubTabs();
        
        lo.OnlyLogout();
        ac.goTo(AccountURL);
        ac.AdditionalWait();
				
		log.info("Deleting the Student Program details");
		ac.ClickAccOwnrTab();
		ac.DeleteCreatedStuProg();
		ac.DeleteAllCreatedStuPayment();
		ac.NavBackToAccount();
		log.info("Deleting the Account created details");
		ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
			
				
		
	}
		
	
	  @AfterMethod(alwaysRun = true) public void teardown() throws
	  InterruptedException {
	  
	  driver.quit();
	  
	  //Thread.sleep(2000); 
	  }
	 
	
	
}
