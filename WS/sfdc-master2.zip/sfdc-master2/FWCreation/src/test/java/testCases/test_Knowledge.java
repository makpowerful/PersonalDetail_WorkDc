package testCases;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import pageObjects.CreatedAccountPO;
import pageObjects.KnowledgePO;
import pageObjects.UserDetailPO;
import pageObjects.UserSetupPO;
import pageObjects.loginPO;
import resources.ExcelData;
import resources.base;



public class test_Knowledge extends base {

	public WebDriver driver;
	//public String CurrURL;
	public static Logger log = LogManager.getLogger(test_Knowledge.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	static Faker faker = new Faker();
	static String firstName = faker.name().firstName();
	static String lastName = faker.name().lastName();
	static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);
	
	@BeforeMethod(alwaysRun = true)
	public void initialize() throws IOException, InterruptedException {

		driver = initializeDriver();

	}
	
	
	@Test(groups = {"sanity", "UAT" }, enabled = true)
	public void TestKnowledgeManagement() throws Exception {
		//String Accountid = null;
		loginPO lo=new loginPO(driver);

		
		if(CurrURL.contains("--byjusuatfc")) {
			al = excelData.getData("TC1", "Knowledge", "Tcid");
			log.info("Logging in as Admin to UATFC Env");
			lo.LoginAsAdmin_UATFC();

		}
		else if(CurrURL.contains("--byjusuat")) {
		al = excelData.getData("TC1", "Knowledge", "Tcid");
		
		log.info("Logging in as Admin to UAT");
		lo.LoginAsAdmin_UAT();
		}
		else {
			al = excelData.getData("TC1", "Knowledge", "Tcid");
			//al2 = excelData.getData("Collection Assistant", "Login", "Type");
			log.info("Logging in as Admin to Prod");
			lo.LoginAsAdmin_Prod();

		}
				
		CreatedAccountPO ac=new CreatedAccountPO(driver);
		UserDetailPO ud= new UserDetailPO(driver);
		UserSetupPO us= new UserSetupPO(driver);
		KnowledgePO kp=new KnowledgePO(driver);
		
		ac.closeTabWindows();
		

		ac.GotoLoggedInUser();
		ud.ClickUserDetailbutton();
		us.KnowledgeUserCheck();

		
		//Creating New Case
		kp.ClickButton("New");
		kp.SelectRecordType("Byjus Process");
		
		//Entering values
		kp.EnterTitle(al.get(1));
		kp.SelectIssueCategory(al.get(2));
		kp.EnterURLName(al.get(3));
		kp.SelectSubCategory(al.get(4));
		kp.EnterSummary(al.get(5));
		kp.SelectIssueType(al.get(6));
		kp.SelectIssueSubType(al.get(7));
		kp.SelectArticleType(al.get(8));
		kp.ClickSave();
		
		String title= kp.CaptureTitle();
		
		//Publish the Aritcle
		if(CurrURL.contains("--byjusuat")){
		kp.ClickPublish();
		}
		
		kp.NavtoKnowledge();
		
		//Archiving the created article
		kp.ArchiveArticleCreated(title);
		
		//Delete the archived article
		kp.DeleteArchiveArticle(title);
		
		//Reverting Knowledge check
		ac.GotoLoggedInUser();
		ud.ClickUserDetailbutton();
		us.UncheckKnowledgeUser();
		us.UnSelectPermissionSet("Knowledge Author");
		
	}		
		
	
		
	
	  @AfterMethod(alwaysRun = true) public void teardown() throws
	  InterruptedException {
	  
	  driver.quit();
	  
	  //Thread.sleep(2000); 
	  }
	 
	
	
}
