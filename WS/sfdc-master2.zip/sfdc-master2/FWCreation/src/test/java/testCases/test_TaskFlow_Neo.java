package testCases;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pageObjects.CasesPO;
import pageObjects.CreatedAccountPO;
import pageObjects.DevConsolePO;
import pageObjects.ExamDetailsPO;
import pageObjects.IssueTreePO;
import pageObjects.MentorFollowUpTaskPO;
import pageObjects.NewCaseRecordTypePO;
import pageObjects.OpenActivitiesPO;
import pageObjects.OutboundTaskPO;
import pageObjects.PEFollowUpTaskPO;
import pageObjects.PEOnBoardingTaskPO;
import pageObjects.PEShippedTaskPO;
import pageObjects.SessionsInformationPO;
import pageObjects.StudentAppInfoPO;
import pageObjects.StudentCRAssoPO;
import pageObjects.StudentSubOrderPO;
import pageObjects.UserDetailPO;
import pageObjects.loginPO;
import payLoad.payLoad_NeoClasses;
import resources.Batches;
import resources.ExcelData;
import resources.base;



public class test_TaskFlow_Neo extends base {

	public WebDriver driver;
	//public String CurrURL;
	public static Logger log = LogManager.getLogger(test_TaskFlow_Neo.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> proddummyuser = new ArrayList<String>();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	ArrayList<String> al3 = new ArrayList<String>();
	ArrayList<String> al4 = new ArrayList<String>();
	ArrayList<String> al5 = new ArrayList<String>();
	ArrayList<String> al6 = new ArrayList<String>();
	ArrayList<String> al7 = new ArrayList<String>();
	ArrayList<String> al8 = new ArrayList<String>();
	ArrayList<String> al9 = new ArrayList<String>();

	
	@BeforeMethod(alwaysRun = true)
	public void initialize() throws IOException, InterruptedException {

		driver = initializeDriver();

	}
	
	
	@Test(groups = {"sanity", "UAT" }, enabled = true)
	public void TestTaskFlow_Neo() throws Exception {
	    proddummyuser = excelData.getData("TC1", "ProdDummyUser", "Tcid");
		String Accountid = null;
		String StudentClassroom = null;
		String StudentAppInfo1 = null;
		String StudentAppInfo2 = null;
		loginPO lo=new loginPO(driver);
		IssueTreePO it=new IssueTreePO(driver);
		al3 = excelData.getData("Neo", "Outbound", "Tcid");
		al5 = excelData.getData("Mentor-Follow", "Outbound", "Tcid");
		al2 = excelData.getData("PE User UAT", "Login", "Type");
		al4 = excelData.getData("Mentor User UAT", "Login", "Type");
		al6 = excelData.getData("K3 Tech & Program", "IssueTree", "Tcid");
		al7 = excelData.getData("K4-10 Tech & Program", "IssueTree", "Tcid");
		al8 = excelData.getData("K11-12 Tech & Program", "IssueTree", "Tcid");
		al9 = excelData.getData("Adminuatfc", "Login", "Type");
		
		if(CurrURL.contains("--byjusuatfc")) {
		al = excelData.getData("TC1", "Neo", "Tcid");		
		log.info("Logging in as Admin to UATFC");
		lo.LoginAsAdmin_UATFC();
		log.info("Submitting the Account creation payload");
		Accountid=payLoad_NeoClasses.AccountidCreationResponse_UATFC();
		payLoad_NeoClasses.ClassRoomMappingResponse_UATFC();
		payLoad_NeoClasses.StudentAppInfoResponse_UATFC();
		log.info("Launching the newly created Account id "+Accountid);
		
		}
		else if(CurrURL.contains("--byjusuat")) {
			al = excelData.getData("TC1", "Neo", "Tcid");			
			log.info("Logging in as Admin to UAT");
			lo.LoginAsAdmin_UAT();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_NeoClasses.AccountidCreationResponse_UAT();
			payLoad_NeoClasses.StudentClassRoomAdd_UAT();
			payLoad_NeoClasses.ClassRoomMappingResponse_UAT();
			payLoad_NeoClasses.StudentAppInfoResponse_UAT();
			StudentClassroom = payLoad_NeoClasses.StudentClassRoomid_UAT();
			StudentAppInfo1 = payLoad_NeoClasses.StudentAppInfoid1_UAT();
			StudentAppInfo2 = payLoad_NeoClasses.StudentAppInfoid2_UAT();
			log.info("Launching the newly created Account id "+Accountid);
		
		}
		else if(CurrURL.contains("--byjusqa")) {
			al = excelData.getData("TC1", "Neo", "Tcid");
			log.info("Logging in as Admin to QA Env");
			lo.LoginAsAdmin_QA();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_NeoClasses.AccountidCreationResponse_QA();
			log.info("Launching the newly created Account id "+Accountid);
		}
		else {
			al = excelData.getData("TC1", "Neo", "Tcid");
			log.info("Logging in as Admin to Prod");
			lo.LoginAsAdmin_Prod();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_NeoClasses.AccountidCreationResponse_Prod();
			payLoad_NeoClasses.ClassRoomMappingResponse_Prod();
			payLoad_NeoClasses.StudentAppInfoResponse_Prod();
			log.info("Launching the newly created Account id "+Accountid);
		}
		
		
		
		CreatedAccountPO ac=new CreatedAccountPO(driver);
		//Open the account by searching PID
		ac.closeTabWindows();
		ac.Notification();
		ac.NavBackToAccount();
		String AccountURL = CurrURL+Accountid;
		ac.goTo(CurrURL+Accountid);
		ac.AccountLoadwait();
		
		//Setting  SSO to Shipped status
		log.info("Navigating to Student sales order");
		
		StudentSubOrderPO Ssub=new StudentSubOrderPO(driver);
		ac.ClickStudentSalesOrder();
		Ssub.ClickOrderinOrders();
		Ssub.SelectStatus("Shipped");
		Ssub.ClickSave();
		

		
		ac.ClickAccOwnrTab();
		ac.RefreshTab();
		
		
		String PremiumID = ac.CapturePremiumID();
		if(PremiumID!=null) {
			Assert.assertTrue(true);
		}
		log.info("The Premium id is "+PremiumID);
		
		//Verify Account is created with Student order,Student Payment in it
		Assert.assertTrue(ac.CheckVisSalesStudentOrderid());
		ac.CaptureStudentSalesOrder();	
		
		Assert.assertTrue(ac.CheckVisStudentPayid());
		ac.CaptureAllStudentPayid();
		ac.CheckVisStudentPrgid();
		ac.CaptureAllStudentProgDetails();
		
		//Verify  Neo Classes  program is created in student program related list
		String Progval = ac.CapturePrgCreated();
		Assert.assertEquals(Progval, "Neo Classes");
		
		//Verify Account super status and status is PE/First60 and New
		
		String SuperStatus = ac.CaptureSuperStatus();
		Assert.assertTrue(SuperStatus.contains("First60"));
		
		String Status = ac.CaptureStatus();
		Assert.assertEquals(Status, "New");
		ac.Scrollpagedown();
		
		//Verify Student App Information is created
        ac.CaptureStudentAppInfo();
        
        //Verify Student Classroom Associations has the record created
        ac.ClickStudentClassroomAssociations();
        StudentCRAssoPO scra = new StudentCRAssoPO(driver);
        
        String StudentClassroomAssociation= scra.CaptureStuCRAid();
        log.info("Student Classroom id created for Assessment Submitted is: "+StudentClassroomAssociation);
        scra.ClickStuCRAid2();
 
        scra.ClickStuClassRoomRcd();
        ac.CloseSubTabs();
       // if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
        //scra.ChangeSTtoRegular();
        //scra.ChangeCRPTtoClassroom();
        //}
        //scra.RefreshTab();
        
        //String ClassroomOwner= scra.CaptureOwner();
        //System.out.println("The value of Owner is: "+ClassroomOwner);
        
        //ac.ClickAccOwnrTab();
       // ac.CloseSubTabs();
       // Thread.sleep(1000);
       // ac.RefreshTab();
		
        //Logging in as PE
        if(CurrURL.contains("--byjusuat")||CurrURL.contains("--byjusuatfc")) {
            String AccountOwner= ac.AccOwnerCheck();
            if(!al2.get(1).equalsIgnoreCase(AccountOwner)) {
                ac.AssignAccount(al2.get(1));
            }
        }
        else {
            ac.AccountLoadwait();
            ac.RefreshTab();
            ac.AdditionalWait();
            String AccountOwner= ac.AccOwnerCheck();
            if(!AccountOwner.equalsIgnoreCase("Testing User")) {
                ac.AssignAccount("Testing User");
            }
        }
        
        String MainWin = driver.getWindowHandle();
        
        if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
        lo.SwitchUser(al2.get(1));
        ac.closeTabWindows();
        ac.Notification();
        ac.NavBackToAccount();
        ac.goTo(AccountURL);
        ac.AccountLoadwait();   
        }
        else if(CurrURL.contains("--byjusuatfc")) {
            lo.SwitchUser(al2.get(1));
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AccountLoadwait();

        }
        else {
            lo.SwitchUsernProfile_Prod(proddummyuser.get(1),"PE");
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AccountLoadwait();
        }
		
		//Verify the PE Shipped all is created
		Assert.assertTrue(ac.CheckVisPEShippedCall());
		  
		log.info("Navigating to PE Shipped Call tasks");
		ac.ClickPEShipped();
		
		PEShippedTaskPO pes=new PEShippedTaskPO(driver);
		pes.ClickCaptureDetail();
		log.info("Selecting Capture Call as Proceed for PE Shipped Task");
		pes.SelectProceed_iframe();
		pes.SelectProceedIAFO(al.get(1));
		pes.SelectProceedDOBA(al.get(2));
		pes.SelectProceedLP(al.get(3));
		pes.SelectProceedRFP(al.get(4));
		pes.SelectProceedPCOS(al.get(5));
		pes.SelectProceedCE(al.get(6));
		pes.SelectProceedST(al.get(7));
		pes.SelectProceedWOIS(al.get(12));
		pes.SelectProceedNotes(al.get(13));
		pes.SelectProceedIsThereIssue(al.get(20));
		ac.CloseSubTabs();
		
		//Verify DNP flow for PE Shipped task
		ac.ClickOpenActivitiestoNewTask();
		NewCaseRecordTypePO ncrt= new NewCaseRecordTypePO(driver);
		ncrt.SelectTaskRecordType("PE - Shipped Call");
	    ncrt.ClickNext();
	    ac.AdditionalWait();
	    ncrt.ClickSave();
	    ac.AdditionalWait();
	    
	    Assert.assertEquals(pes.CaptureDNPCounter(), "0");
	    
	    pes.ClickCaptureDetail();
		pes.SelectDNP();
		ac.RefreshTab_Targetframe();
		Assert.assertEquals(pes.CaptureDNPCounter(), "1");
		
		pes.ClickCaptureDetail();
        pes.SelectDNP();
        ac.RefreshTab_Targetframe();
        Assert.assertEquals(pes.CaptureDNPCounter(), "2");
        
        pes.ClickCaptureDetail();
        pes.SelectDNP();
        ac.RefreshTab_Targetframe();
        Assert.assertEquals(pes.CaptureDNPCounter(), "3");
        
        ac.CloseSubTabs();
        
        //Verify Customer Call Back Requested task flow
        //ac.ClickOpenActivitiestoNewTask();
        //ncrt.SelectTaskRecordType("PE - Shipped Call");
        //ncrt.ClickNext();
        //ac.AdditionalWait();
        //pes.EnterCallBackNumber();
        //ncrt.ClickSave();
        //ac.AdditionalWait();
        
        //pes.ClickCaptureDetail();
        //pes.SelectCallBackRequested();
        
        //ac.RefreshTab_Targetframe();
        //Assert.assertEquals(pes.CaptureCallStatus(),"Call Back Requested");
        //ac.CloseSubTabs();
        
        //Verify Customer will call task flow
        ac.ClickOpenActivitiestoNewTask();
        ncrt.SelectTaskRecordType("PE - Shipped Call");
        ncrt.ClickNext();
        ac.AdditionalWait();
        ncrt.ClickSave();
        ac.AdditionalWait();
        
        pes.ClickCaptureDetail();
        pes.ClickCustomerwillCall();
        pes.ClickFinish();
        ac.RefreshTab_Targetframe();
        Assert.assertEquals(pes.CaptureStatus(),"Closed");
        ac.CloseSubTabs();
        
        //Login back as Admin to delete open PE - Shipped calls and Status change of SSO to Delivered for PE onboarding
        lo.OnlyLogout();
        ac.CloseWindowArrayLast();
        driver.switchTo().window(MainWin);
        if(CurrURL.contains("--byjusuatfc")) {
            lo.SwitchUser(al9.get(3));
        }
        ac.goTo(AccountURL);
        ac.AccountLoadwait();
        ac.ClickOpenActivities();
        
        OpenActivitiesPO oa = new OpenActivitiesPO(driver);
        oa.DeleteSelectedTask_OpenActivities("[No subject]");
        oa.DeleteSelectedTask_OpenActivities("[No subject]");
        ac.CloseSubTabs();
        
		log.info("Navigating to Student sales order");
	
		ac.ClickStudentSalesOrder();
		Assert.assertTrue(ac.CheckExistingProfile());//Added check for SFTNL-6458
		Ssub.ClickOrderinOrders();
		Ssub.SelectSSOStatus();
		Ssub.ClickSave();

		
		ac.ClickAccOwnrTab();
		ac.RefreshTab();
		
		ac.ClickPersonAccount();
		
		if(CurrURL.contains("--byjusuatfc")) {
		    lo.OnlyLogout();
	        ac.CloseWindowArrayLast();
	        driver.switchTo().window(MainWin);
        }
		
		//Logging back as PE to perform PE - Onboarding
        if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
        lo.SwitchUser(al2.get(1));
        ac.closeTabWindows();
        ac.Notification();
        ac.NavBackToAccount();
        ac.goTo(AccountURL);
        ac.AccountLoadwait();   
        }
        else if(CurrURL.contains("--byjusuatfc")) {
            lo.SwitchUser(al2.get(1));
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AccountLoadwait();

        }
        else {
            lo.SwitchUsernProfile_Prod(proddummyuser.get(1),"PE");
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AccountLoadwait();
        }
        
		log.info("Navigating to PE On boarding Call tasks");
		//Verify PE Onboarding call task is created when the SSO status moved to Partial delivered/delivered
		Assert.assertTrue(ac.CheckVisPEOnboardingCall());
		//ac.CloseSubTabs();
		ac.ClickPEOnboardngCall();
		
		
		PEOnBoardingTaskPO peob=new PEOnBoardingTaskPO(driver);
		peob.ClickCaptureDetail();
		log.info("Selecting Capture Call as Proceed for PE Onboarding Task");
		peob.SelectProceed_iframe();
		peob.ClickOnboardingScreenNext();
		if(CurrURL.contains("--byjusuat")) {
		    peob.ClickNext();
		}
		peob.SelectProceedS_T(al.get(92)); //Created with SFDC-2419 2.0
		peob.SelectProceedHTPTMCA(al.get(134));
		peob.EnterNotes(al.get(93)); //Created with SFDC-2419 2.0
		peob.SelectSHAACLOC(al.get(94)); //Created with SFDC-2419 2.0
		peob.SelectProductRating(al.get(95)); //Created with SFDC-2419 2.0
		peob.SelectNotLikeProduct(al.get(96)); //Created with SFDC-2419 2.0
		peob.SelectTeacherRating(al.get(97)); //Created with SFDC-2419 2.0
		peob.SelectNotLikeTeacher(al.get(98)); //Created with SFDC-2419 2.0
		peob.SelectContentRating(al.get(99)); //Created with SFDC-2419 2.0
		peob.SelectNotLikeContent(al.get(100)); //Created with SFDC-2419 2.0
		peob.SelectStudentAppUsage(al.get(101)); //Created with SFDC-2419 2.0
		peob.SelectTLPOnboardngDone(al.get(102)); //Created with SFDC-2419 2.0		
		peob.SelectProceedIsThereIssue2(al.get(33));
		ac.AdditionalWait();
		ac.CloseSubTabs();
		
		ac.RefreshTab();
		Assert.assertEquals(ac.CaptureStatus(), "PE-On-boarded");
		
	    //Verify DNP flow for PE Onboarding task
        ac.ClickOpenActivitiestoNewTask();
        ncrt.SelectTaskRecordType("PE - Onboarding Call");
        ncrt.ClickNext();
        ac.AdditionalWait();
        ncrt.ClickSave();
        ac.AdditionalWait();
        
        Assert.assertEquals(pes.CaptureDNPCounter(), "0");
        
        pes.ClickCaptureDetail();
        pes.SelectDNP();
        ac.RefreshTab_Targetframe();
        Assert.assertEquals(pes.CaptureDNPCounter(), "1");
        
        pes.ClickCaptureDetail();
        pes.SelectDNP();
        ac.RefreshTab_Targetframe_IT();
        Assert.assertEquals(pes.CaptureDNPCounter(), "2");
        
        pes.ClickCaptureDetail();
        pes.SelectDNP();
        ac.RefreshTab_Targetframe();
        Assert.assertEquals(pes.CaptureDNPCounter(), "3");
        
        ac.CloseSubTabs();
        
        //Verify Customer Call Back Requested task
        ac.ClickOpenActivitiestoNewTask();
        ncrt.SelectTaskRecordType("PE - Onboarding Call");
        ncrt.ClickNext();
        ac.AdditionalWait();
        pes.EnterCallBackNumber();
        ncrt.ClickSave();
        ac.AdditionalWait();
        
        pes.ClickCaptureDetail();
        pes.SelectCallBackRequested();
        
        ac.RefreshTab_Targetframe();
        Assert.assertEquals(pes.CaptureCallStatus(),"Call Back Requested");
        ac.CloseSubTabs();
        
        //Verify Customer will call task flow
        ac.ClickOpenActivitiestoNewTask();
        ncrt.SelectTaskRecordType("PE - Onboarding Call");
        ncrt.ClickNext();
        ac.AdditionalWait();
        ncrt.ClickSave();
        ac.AdditionalWait();
        
        pes.ClickCaptureDetail();
        pes.ClickCustomerwillCall();
        //pes.ClickFinish();
        ac.RefreshTab_Targetframe();
        //Assert.assertEquals(pes.CaptureStatus(),"Closed");
        ac.CloseSubTabs();
        
		//Verify once the PE Onboarding call is completed, Follow up task is created on the account 
		Assert.assertTrue(ac.CheckVisFollowUpTutorandMentorCall());
        //ac.CloseSubTabs();
		ac.ClickFollowUpTutorandMentorCall();
			
		PEFollowUpTaskPO pefu= new PEFollowUpTaskPO(driver);

		log.info("Selecting Capture Call as Proceed for PE Follow Up Task 1");
			
		//Verifying Follow up 1 task is created on the account, Completing the flow of (DNP followed by Proceed)
		Assert.assertEquals(pes.CaptureDNPCounter(), "0");
        
        pes.ClickCaptureDetail();
        pes.SelectDNP();
        ac.RefreshTab_Targetframe();
        Assert.assertEquals(pes.CaptureDNPCounter(), "1");
        
        pes.ClickCaptureDetail();
        pes.SelectDNP();
        ac.RefreshTab_Targetframe();
        Assert.assertEquals(pes.CaptureDNPCounter(), "2");
        
        pes.ClickCaptureDetail();
        pes.SelectDNP();
        ac.RefreshTab_Targetframe();
        Assert.assertEquals(pes.CaptureDNPCounter(), "3");
        
        //Proceed flow 
        pes.ClickCaptureDetail();
        pefu.SelectProceed_iframe();
        String FollowUpheader1 = pefu.FollowUpHeader_iframe();
        Assert.assertTrue(FollowUpheader1.contains("Follow Up"));
		pefu.SelectProceedST(al.get(66));
		pefu.SelectProceedSAU(al.get(67));
		pefu.SelectProceedNotes(al.get(68));
		pefu.ClickNext();
		pefu.SelectProceedIsThereIssue2(al.get(45));
		ac.RefreshTab_Targetframe_IT();
		
		
		//it.ProgramSelector();
		//it.ClickNext();
        //it.IssueCategory(al6.get(1));
        //it.IssueSubCategory(al6.get(2));
       // it.IssueType(al6.get(3));
       // it.IssueSubType(al6.get(4));
        //it.IssueNotes(al6.get(5));
        //it.IstheIssueResolved(al6.get(6));
        //it.ClickNext();
        //it.RefreshTab_Targetframe_IT();
        
        //log.info("Created case for K3 flow in Issure Tree no is: "+pefu.CaptureRelatedToCaseNumber());
        //Verifying the case owner is a part of the queue
       // CasesPO cases=new CasesPO(driver);
       // String CaseOwner=cases.CaptureCaseOwner();
        
        //According to Issue tree logic this is to be with WhiteHat Jr Team queue
        //UserSetupPO us=new UserSetupPO(driver);
        //us.NavtoQueue("WhiteHat Jr Team");
        //us.VerifyPersonPresent(CaseOwner);
       // ac.CloseWindowArrayLast();
       // driver.switchTo().window(MainWin);
		ac.CloseSubTabs();
			


		//Verify Follow up task 2 is created on the account (Call Back Requested + Proceed)
		ac.RefreshTab();
		Assert.assertTrue(ac.CheckVisFollowUpTutorandMentorCall());
		ac.ClickFollowUpTutorandMentorCall();	
		pefu.ClickCaptureDetail();
		log.info("Selecting Capture Call as Proceed for PE Follow Up Task 2");
			
		//Verify once the Follow up  is completed, Follow up 2 task is created on the account
		pes.SelectCallBackRequested();
        ac.RefreshTab_Targetframe();
        Assert.assertEquals(pes.CaptureCallStatus(),"Call Back Requested");
        //Proceed
        pefu.ClickCaptureDetail();
		pefu.SelectProceed_iframe();
		String FollowUpheader2 = pefu.FollowUpHeader_iframe();
		Assert.assertTrue(FollowUpheader2.contains("Follow Up"));
		pefu.SelectProceedST(al.get(66));
		pefu.SelectProceedSAU(al.get(67));
		pefu.SelectProceedNotes(al.get(68));
		pefu.ClickNext();
		pefu.SelectProceedSHAACSLOC(al.get(59));
		pefu.SelectProceedIsThereIssue2(al.get(59));
		ac.RefreshTab_Targetframe_IT();
		ac.CloseSubTabs();
			
		//Verify Follow up task 3 is created on the account
		ac.RefreshTab();
		Assert.assertTrue(ac.CheckVisFollowUpTutorandMentorCall());
		ac.ClickFollowUpTutorandMentorCall();
			
		pefu.ClickCaptureDetail();
		log.info("Selecting Capture Call as Proceed for PE Follow Up Task 3");
			
		//Verify once the Follow up  is completed, Follow up 3 task is created on the account
		pefu.SelectProceed_iframe();

		pefu.SelectProceedST(al.get(66));
		pefu.SelectProceedSAU(al.get(67));
		pefu.SelectProceedNotes(al.get(68));
		pefu.ClickNext();
		pefu.SelectProceedIsThereIssue2(al.get(59));
		ac.RefreshTab_Targetframe_IT();
		ac.CloseSubTabs();
		
	     //Verify Follow up task 4 is created on the account
        ac.RefreshTab();
        Assert.assertTrue(ac.CheckVisFollowUpTutorandMentorCall());
        ac.ClickFollowUpTutorandMentorCall();
            
        pefu.ClickCaptureDetail();
        log.info("Selecting Capture Call as Proceed for PE Follow Up Task 3");
            
        //Verify once the Follow up  is completed, Follow up 4 task is created on the account
        pefu.SelectProceed_iframe();

        pefu.SelectProceedST(al.get(66));
        pefu.SelectProceedSAU(al.get(67));
        pefu.SelectProceedNotes(al.get(68));
        pefu.ClickNext();
        pefu.SelectProceedSHAACSLOC(al.get(59));
        pefu.SelectProceedIsThereIssue2(al.get(59));
        ac.RefreshTab_Targetframe_IT();
        ac.CloseSubTabs();
        
        lo.OnlyLogout();
        ac.CloseWindowArrayLast();
        driver.switchTo().window(MainWin);
        
        if(CurrURL.contains("byjusprod.")){
            log.info("Creating Mentor Onboarding Task");
            ac.ClickOpenActivitiestoNewTask();            
            ncrt.SelectCaseRecordType("Mentor - Onboarding Call");
            ncrt.ClickNext();
            ncrt.EnterSubject("Mentor - Onboarding Call");
            ncrt.ClickSave();
            ac.AdditionalWait();
            ac.CloseSubTabs();
            ac.AccountLoadwait();
        }
        
        //Running the Batch to move PE to Mentor
        DevConsolePO dc= new DevConsolePO(driver);
        if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
        dc.GetDevConsole("UAT");
        dc.RunBatch(Batches.PEtoMentor());
        dc.CheckBatchRunSuccess();      
        dc.CloseWindowArrayLast();
        driver.switchTo().window(MainWin);
        ac.CloseSubTabs();
        ac.AdditionalWait();
        ac.RefreshTab();
        ac.ClickAccountOwner();
        UserDetailPO ud= new UserDetailPO(driver);
        Assert.assertEquals(ud.CaptureProfile(),"Mentor");
        ac.CloseCurrentSubTab();
        Assert.assertEquals(ac.CaptureSuperStatus(), "Transition");
        Assert.assertEquals(ac.CaptureStatus(), "PE-Mentor Transition");
        }
        
        if(CurrURL.contains("--byjusuatfc")) {
            lo.SwitchUser(al9.get(3));
            dc.CloseWindowArrayLast();
            driver.switchTo().window(MainWin);
            dc.GetDevConsole("UATFC");
            dc.RunBatch(Batches.PEtoMentor());
            dc.CheckBatchRunSuccess();      
            dc.CloseWindowArrayLast();
            driver.switchTo().window(MainWin);
            lo.OnlyLogout();
            ac.goTo(AccountURL);
            ac.AdditionalWait();
            ac.CloseSubTabs();
            ac.AdditionalWait();
            ac.RefreshTab();
            ac.ClickAccountOwner();
            UserDetailPO ud= new UserDetailPO(driver);
            Assert.assertEquals(ud.CaptureProfile(),"Mentor");
            ac.CloseCurrentSubTab();
            Assert.assertEquals(ac.CaptureSuperStatus(), "Transition");
            Assert.assertEquals(ac.CaptureStatus(), "PE-Mentor Transition");
            
        }
		

        
        //Assigning account to Mentor and Logging in as mentor
		if(CurrURL.contains("--byjusuat")||CurrURL.contains("--byjusuatfc")) {
			String AccountOwner= ac.AccOwnerCheck();
			if(!al4.get(1).equalsIgnoreCase(AccountOwner)) {
				ac.AssignAccount(al4.get(1));
			}
		}
		else {
		    ac.AccountLoadwait();
		    ac.RefreshTab();
		    ac.AdditionalWait();
		    String AccountOwner= ac.AccOwnerCheck();
            if(!AccountOwner.equalsIgnoreCase("Testing User")) {
                ac.AssignAccount("Testing User");
            }
			
		}
		
		if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
			lo.SwitchUser(al4.get(1));
			ac.closeTabWindows();
			ac.Notification();
			ac.NavBackToAccount();
			ac.goTo(AccountURL);
			ac.AccountLoadwait();	
			}
			else if(CurrURL.contains("--byjusuatfc")) {
				lo.SwitchUser(al4.get(1));
				ac.closeTabWindows();
				ac.Notification();
				ac.NavBackToAccount();
				ac.goTo(AccountURL);
				ac.AccountLoadwait();

			}
			else {
				lo.SwitchUsernProfile_Prod(proddummyuser.get(1),"Mentor");
				ac.closeTabWindows();
				ac.Notification();
				ac.NavBackToAccount();
				ac.goTo(AccountURL);
				ac.AccountLoadwait();
			}
		
		//Verify Mentor Onboarding call task is created 
		Assert.assertTrue(ac.CheckVisMentorOnboardingCall());
		ac.ClickMentorOnboardngCall();
		
		OutboundTaskPO ob= new OutboundTaskPO(driver);
		ob.ClickCaptureDetail();
		ob.SelectProceed_iframe();
		ob.SelectProceedST(al3.get(1));
		ob.SelectOnboardingSurvey(al3.get(2));
		ob.SelectStudyPlanStatus(al3.get(3));
		ob.SelectPriCaretakerStudies(al3.get(4));
		ob.ClickNext();
		pefu.SelectProceedSHAACSLOC(al.get(59));
		ob.SelectProceedIsThereIssue2(al3.get(5));
		ob.ClickNext();	
		ac.RefreshTab_Targetframe_IT();
	    ac.CloseSubTabs();
		
		
			
		//Verify once the Mentor Onboarding call is completed, Mentor Follow up task is created on the account 
	    ac.RefreshTab();
		Assert.assertTrue(ac.CheckVisMentorFollowUpCall());
		ac.ClickMentorFollowUpCall();
		
		MentorFollowUpTaskPO mfu= new MentorFollowUpTaskPO(driver);
		log.info("Selecting Capture Call as Proceed for Mentor Follow Up Task 1");
		
		//Verify Mentor follow up call is created with DNP flow
        
        Assert.assertEquals(pes.CaptureDNPCounter(), "0");
        mfu.ClickCaptureDetail();
        pes.SelectDNP();
        ac.RefreshTab_Targetframe();
        Assert.assertEquals(pes.CaptureDNPCounter(), "1");
        
        pes.ClickCaptureDetail();
        pes.SelectDNP();
        ac.RefreshTab_Targetframe_IT();
        Assert.assertEquals(pes.CaptureDNPCounter(), "2");
        
        pes.ClickCaptureDetail();
        pes.SelectDNP();
        ac.RefreshTab_Targetframe_IT();
        Assert.assertEquals(pes.CaptureDNPCounter(), "3");
        
        pes.ClickCaptureDetail();
        pes.SelectDNP();
        ac.RefreshTab_Targetframe_IT();
        Assert.assertEquals(pes.CaptureDNPCounter(), "4");
        Assert.assertEquals(pes.CaptureStatus(), "Completed");
        
        ac.CloseSubTabs();
        
        //Verify Customer Call Back Requested task
        ac.RefreshTab();
        //Assert.assertTrue(ac.CheckVisMentorFollowUpCall());
        ac.ClickMentorFollowUpCall();
        
        mfu.ClickCaptureDetail();
        pes.SelectCallBackRequested();
        
        ac.RefreshTab_Targetframe();
        Assert.assertEquals(pes.CaptureCallStatus(),"Call Back Requested");
        ac.CloseSubTabs();
        
        //Verify Customer will call task flow
        ac.RefreshTab();
       // Assert.assertTrue(ac.CheckVisMentorFollowUpCall());
        ac.ClickMentorFollowUpCall();
        
        mfu.ClickCaptureDetail();
        pes.ClickCustomerwillCall();
        //pes.ClickFinish();
        ac.RefreshTab_Targetframe();
        Assert.assertEquals(pes.CaptureStatus(),"Completed");
        ac.CloseSubTabs();

        //Creating RR case on Mentor follow up call
        ac.RefreshTab();
        //Assert.assertTrue(ac.CheckVisMentorFollowUpCall());
        ac.ClickMentorFollowUpCall();
        mfu.ClickCaptureDetail();
        mfu.SelectProceed_iframe();
			
		String MentorFollowUpheader1 = mfu.FollowUpHeader_iframe();
		Assert.assertTrue(MentorFollowUpheader1.contains("Follow Up"));
		mfu.SelectProceedST(al5.get(1));
		mfu.SelectProceedSPS(al5.get(7));
		mfu.ClickNext();
		mfu.SelectProceedSHAAC(al5.get(10));
		mfu.SelectProceedIsThereIssue2("Yes");
		
		
		al4 = excelData.getData("TC3", "RefundProcess", "Tcid");
        it.ProgramSelector();
        it.ClickNext();
        it.IssueCategory(al4.get(13));
        it.Reason(al4.get(14));
        it.SubReason(al4.get(15));
        it.IssueNotes(al4.get(16));
        it.IstheIssueResolved(al4.get(17));
        it.ClickNext2();
        it.SSOandAccCombo();
        it.ClickFinish();
        ac.RefreshTab_Targetframe_IT();
        ac.CloseSubTabs();
        ac.RefreshTab();
        
        StudentAppInfoPO spi=new StudentAppInfoPO(driver);
       // if(CurrURL.contains("--byjusuat")) {
	    //Verifying the Block Status of Student App Information
       // ac.ClickStudentAppInfo();
       // ac.RefreshTab();
       // spi.CheckBlockStatus();
       // ac.CloseSubTabs();
       // ac.closeCurrentTabWindow();
       // }
			
		lo.OnlyLogout();
		ac.goTo(AccountURL);
		ac.AccountLoadwait();
		ac.CloseSubTabs();
			
		//*****************************************************************************************//
			
		//Verify Session Attended is Created
			
		SessionsInformationPO si = new SessionsInformationPO(driver);
		log.info("Sending the Session Attended API");
		if(CurrURL.contains("--byjusuatfc")) {
			payLoad_NeoClasses.SessionAttendedResponse_UATFC();
		    Thread.sleep(2500);
			}
		else if(CurrURL.contains("--byjusuat")) {
		payLoad_NeoClasses.SessionAttendedResponse_UAT();
	    Thread.sleep(2500);
		}
		else if(CurrURL.contains("--byjusqa")) {
			payLoad_NeoClasses.SessionAttendedResponse_QA();
		    Thread.sleep(2500);
			}
		else {
			payLoad_NeoClasses.SessionAttendedResponse_Prod();
		    Thread.sleep(2500);
			}
	  
		ac.Scrollpagedown();
	    ac.AccountLoadwait();
	    si.RefreshTab();
		
		String SessionAttendedid= si.CaptureSessionid_UAT2();
		log.info("Session id created for Session Attended is: "+SessionAttendedid);
		
		si.ClickSessionid_UAT2();

		String SessionAttend= si.CaptureSessiontext();
		Thread.sleep(800);
		
		Assert.assertEquals(SessionAttend, "Session Attended");
		
		log.info("Deleting the created Session Information");
		si.DeleteSessionInfolastbtn();
		
		//Verify Session Missed is Created
				
		log.info("Sending the Session Missed API");
	    if(CurrURL.contains("--byjusuatfc")) {
			payLoad_NeoClasses.SessionMissedResponse_UATFC();
		    Thread.sleep(2500);
			}
	    else if(CurrURL.contains("--byjusuat")) {
			payLoad_NeoClasses.SessionMissedResponse_UAT();
		    Thread.sleep(2500);
			}
			else if(CurrURL.contains("--byjusqa")) {
				payLoad_NeoClasses.SessionMissedResponse_QA();
			    Thread.sleep(2500);
				}
			else {
				payLoad_NeoClasses.SessionMissedResponse_Prod();
			    Thread.sleep(2500);
				}
		  
	  
	    si.RefreshTab();
		
	    if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
		String SessionMissedid= si.CaptureSessionid_UAT2();
		log.info("Session id created for Session Attended is: "+SessionMissedid);
		
		si.ClickSessionid_UAT2();
	    }
	    else {
			String SessionMissedid= si.CaptureSessionid_UAT2();;
			log.info("Session id created for Session Missed is: "+SessionMissedid);
			
			si.ClickSessionid_UAT2();
	    }
		
		
		String SessionMissed= si.CaptureSessiontext();
		Thread.sleep(800);
		
		Assert.assertEquals(SessionMissed, "Session Missed");
		log.info("Deleting the created Session Information");
		si.DeleteSessionInfolastbtn();

		//Verify Session Feedback is Created
		//***********************************************************//
		
		  log.info("Sending the Session Feedback API");
		  if(CurrURL.contains("--byjusuatfc")) {
		  payLoad_NeoClasses.SessionFeedbackResponse_UATFC(); 
		  Thread.sleep(2500); 
		  }
		  else if(CurrURL.contains("--byjusuat")) {
		  payLoad_NeoClasses.SessionFeedbackResponse_UAT(); 
		  Thread.sleep(4500); 
		  } else
		  if(CurrURL.contains("--byjusqa")) {
		  payLoad_NeoClasses.SessionFeedbackResponse_QA(); 
		  Thread.sleep(2500); } 
		  else {
		  payLoad_NeoClasses.SessionFeedbackResponse_Prod(); 
		  Thread.sleep(2500); }
		  
		  si.RefreshTab();
          String SessionFeedbackid= si.CaptureSessionid_UAT2();
    	  log.info("Session id created for Session Feedback is: "+SessionFeedbackid);
    	  si.ClickSessionid_UAT2();
		  
		  log.info("Deleting the created Session Information");
	      si.DeleteSessionInfolastbtn();

		
		  //Verify Assessment Submitted Exam detail is Created
				
		  ExamDetailsPO ed= new ExamDetailsPO(driver);
		
		  log.info("Sending the Assessment Submitted API");
	      if(CurrURL.contains("--byjusuatfc")) {
	        payLoad_NeoClasses.AssessmentSubmittedResponse_UATFC();
		    Thread.sleep(2500);
			}
	      else if(CurrURL.contains("--byjusuat")) {
	        payLoad_NeoClasses.AssessmentSubmittedResponse_UAT();
		    Thread.sleep(2500);
		    ac.Scrollpagedown();
			}
		  else if(CurrURL.contains("--byjusqa")) {
				payLoad_NeoClasses.AssessmentSubmittedResponse_QA();
			    Thread.sleep(2500);
				}
		  else {
				payLoad_NeoClasses.AssessmentSubmittedResponse_Prod();
			    Thread.sleep(2500);
			    ac.Scrollpagedown();
				}
	    ed.RefreshTab();
	    ac.Scrollpagedown();
		ac.ClickExamDetails();
		
		String Examid= ed.CaptureExamid();
		log.info("Exam id created for Assessment Submitted is: "+Examid);
		
		String RecordType=ed.CaptureRecordtypetext();
		Assert.assertEquals(RecordType, "Monthly Test Scheduled");
		
		ed.ClickExamid();
			
		log.info("Deleting the created Exam Detail Information");
		ed.DeleteExamDetailslastbtn();
		ed.NavExamInfo();
	
		//Verify Monthly Submitted Exam detail is Created	
		log.info("Sending the Monthly Test API");
		 if(CurrURL.contains("--byjusuatfc")) {
		        payLoad_NeoClasses.MonthlyTestResponse_UATFC();
			    Thread.sleep(2500);
				}
		 else if(CurrURL.contains("--byjusuat")) {
	        payLoad_NeoClasses.MonthlyTestResponse_UAT();
		    Thread.sleep(2500);
			}
			else if(CurrURL.contains("--byjusqa")) {
				payLoad_NeoClasses.MonthlyTestResponse_QA();
			    Thread.sleep(2500);
				}
			else {
				payLoad_NeoClasses.MonthlyTestResponse_Prod();
			    Thread.sleep(2500);
				}
	    Thread.sleep(1200);
	    ed.RefreshTab();
		Thread.sleep(1000);
	    
		String Examid1= ed.CaptureExamid();
		log.info("Exam id created for Monthly Test Submitted is: "+Examid1);
		
		String RecordType1=ed.CaptureRecordtypetext();
		Assert.assertEquals(RecordType1, "Monthly Test Scheduled");
		
		ed.ClickExamid();
			
		log.info("Deleting the created Exam Detail Information");
		ed.DeleteExamDetailslastbtn();

		ac.ClickAccOwnrTab();
		
		
		//Verify Student School Informations is Created

		log.info("Sending Student School Information API");
	    String SchoolInfo;
	    if(CurrURL.contains("--byjusuatfc")) {
		 SchoolInfo = payLoad_NeoClasses.StudentSchoolInformationsResponse_UATFC(); 
		  Thread.sleep(2500); 
		  }
		  else if(CurrURL.contains("--byjusuat")) {
		 SchoolInfo =  payLoad_NeoClasses.StudentSchoolInformationsResponse_UAT(); 
		  Thread.sleep(4500); 
		  }
		  else {
		 SchoolInfo =  payLoad_NeoClasses.StudentSchoolInformationsResponse_Prod(); 
		  Thread.sleep(2500); 
		  }
	  
		  ac.CloseSubTabs();
		  si.RefreshTab();
		  
		  
    	  String StudentSchoolInformation= si.CaptureStuSchlInfo();
    	  log.info("Student School Information created is: "+StudentSchoolInformation);
    			
    	  si.ClickStuSchlInfo();
    	  
    	  log.info("Deleting the created Student School Information");

	    si.DeleteStudentSchoolInfolastbtn(); 
			  
		String SchoolInfoURL=CurrURL+SchoolInfo;
		
		ac.ClickCasesMC2();
		CasesPO cases= new CasesPO(driver);
		cases.CloseAllCases();
		ac.CloseSubTabs();
		
		log.info("Deleting the Student Program details");
		ac.ClickAccOwnrTab();
		ac.DeleteCreatedStuProg();
		ac.DeleteAllCreatedStuPayment();
		ac.NavBackToAccount();
		log.info("Deleting the Account created details");
		ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
		
		if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
		log.info("Deleting the Student Classroom details "+StudentClassroom);
		ac.goTo(CurrURL+StudentClassroom);	
		ac.AdditionalWait();
		scra.ClickDelete();
		// StudentAppInfo1
		//Not to go in this code
		int i=1;
		if(i==0) {
		log.info("Deleting the Student App Info details ");
		ac.goTo(CurrURL+StudentAppInfo1);	
		ac.AdditionalWait();
		spi.DeleteStudentAppInfolastbtn();
		
		ac.goTo(CurrURL+StudentAppInfo2);	
		ac.AdditionalWait();
		spi.DeleteStudentAppInfolastbtn();
		}
		}
		
		log.info("Deleting the School Information details "+SchoolInfo);
		ac.goTo(SchoolInfoURL);	
		ac.AdditionalWait();
		spi.DeleteSchoolInfolastbtn();		
		
	}
		
	
	  @AfterMethod(alwaysRun = true) public void teardown() throws
	  InterruptedException {
	  
	  //driver.quit();
	  
	  //Thread.sleep(2000); 
	  }
	 
	
	
}
