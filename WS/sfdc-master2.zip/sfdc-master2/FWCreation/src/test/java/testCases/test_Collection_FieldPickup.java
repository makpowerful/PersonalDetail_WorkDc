package testCases;


import java.io.IOException;

import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.openqa.selenium.WebDriver;

import org.testng.annotations.AfterMethod;

import org.testng.annotations.BeforeMethod;


import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import org.testng.Assert;


import pageObjects.CapturePaymtDetailsFPPO;

import pageObjects.CasesPO;
import pageObjects.CollectionAssistantLoginPO;
import pageObjects.CreatedAccountPO;
import pageObjects.CreatedCaseRecordPO;
import pageObjects.FirstConnectPO;

import pageObjects.NPPaymentLoanPO;
import pageObjects.NewCaseDetailsPO;
import pageObjects.NewCaseRecordTypePO;
import pageObjects.NewPaymentPO;
import pageObjects.NewPaymentRecordPO;
import pageObjects.PaymentCaseQAPO;
import pageObjects.PaymentsPO;

import pageObjects.UserDetailPO;
import pageObjects.UserSetupPO;
import pageObjects.loginPO;
import resources.ExcelData;
import resources.base;

public class test_Collection_FieldPickup extends base {

	public WebDriver driver;
	//ThreadLocal<WebDriver> driver = new ThreadLocal<WebDriver>();
	//public String CurrURL;
	public static Logger log = LogManager.getLogger(test_CollectionFlow.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	ArrayList<String> al3 = new ArrayList<String>();
	ArrayList<String> al4 = new ArrayList<String>();
	static Faker faker = new Faker();
	static String firstName = faker.name().firstName();
	static String lastName = faker.name().lastName();
	static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);

	
	@BeforeMethod(alwaysRun = true)
	public void initialize() throws IOException, InterruptedException {

		driver = initializeDriver();
	}
	
	 
	 

	@Test(groups = { "sanity", "Regression" }, enabled = true)
	public void Collection_FieldPickup() throws Exception {
		
		loginPO lo=new loginPO(driver);
		if(CurrURL.contains("--byjusuatfc")) {
			al = excelData.getData("TC4", "CollectionFlow", "Tcid");
			al2 = excelData.getData("CollectionAssistant UATFC", "Login", "Type");
			al3 = excelData.getData("CollectionManager UATFC", "Login", "Type");
			al4 = excelData.getData("Adminuatfc", "Login", "Type");
			log.info("Logging in as Admin to UATFC");
			lo.LoginAsAdmin_UATFC();
			
			}
		else if(CurrURL.contains("--byjusuat")) {
		al = excelData.getData("TC4", "CollectionFlow", "Tcid");
		al2 = excelData.getData("CollectionAssistant UAT", "Login", "Type");
		al3 = excelData.getData("CollectionManager UAT", "Login", "Type");
		al4 = excelData.getData("Admin", "Login", "Type");
		log.info("Logging in as Admin to UAT");
		lo.LoginAsAdmin_UAT();
		//lo.SwitchUser(al2.get(1));
		
		}
		else {
			al = excelData.getData("TC4", "CollectionFlow", "Tcid");
            al2 = excelData.getData("Dummy Collection Associate", "Login", "Type");
            al4 = excelData.getData("AdminProd", "Login", "Type");
			log.info("Logging in as Admin to Prod");
			lo.LoginAsAdmin_Prod();
		}
		//Assert.assertTrue(false);
		closeTabWindows();
		log.info("Creating new Payment record");
		CreatedAccountPO ac=new CreatedAccountPO(driver);
		PaymentsPO p = new PaymentsPO(driver);
		CasesPO cases=new CasesPO(driver);
		ac.Notification();
		p.NavMenuClick();
		p.PaymntNavMenuClick();
		p.NewPaymentClick();

		//Assert.assertTrue(false);

		log.info("Selection of Payment - Loan record");
		NewPaymentPO np = new NewPaymentPO(driver);
		np.SelectPaymentOptn(al.get(1));
		np.ClickNext();

		log.info("Enter New Payment - Loan details");
		NPPaymentLoanPO npp = new NPPaymentLoanPO(driver);
		//npp.EnterPayRefID(randomNum);
		npp.EnterParentFN(firstName);
		npp.EnterParentLN(lastName);
		npp.EnterLoanAmount(al.get(2));
		npp.EnterTenurity(al.get(4));
		npp.EnterProgramName(al.get(3));
		npp.EnterEPPartner(al.get(5));
		npp.EnterAmount(al.get(6));
		npp.EnterTotalAmountTBC(al.get(7));
		npp.EnterNetPayAmount(al.get(8));
		npp.EnterPaymentAmount(al.get(9));
		npp.EnterPaymentCategory(al.get(10));
		npp.EnterPaymentMS(al.get(11));
		npp.EnterPaymentDate(al.get(12));
		npp.EnterPaymentType(al.get(13));
		npp.ClickSave();
		//Assert.assertTrue(false);
		ac.AdditionalWait();
		NewPaymentRecordPO npr = new NewPaymentRecordPO(driver);
		String PaymentRecord = npr.CapturePaymentRcdID();System.out.println(PaymentRecord);
		log.info("New Payment Record " + PaymentRecord + " created successfully");
		npr.ClickCasesQA();

		log.info("Creating New Case Record for " + PaymentRecord);
		PaymentCaseQAPO pcqa = new PaymentCaseQAPO(driver);
		pcqa.ClickCaseNewButton(PaymentRecord);

		NewCaseRecordTypePO ncrt = new NewCaseRecordTypePO(driver);
		ncrt.SelectCaseRecordType(al.get(14));
		ncrt.ClickNext();

		NewCaseDetailsPO ncd = new NewCaseDetailsPO(driver);
		Thread.sleep(1200);
		
		ncd.EnterSubject(al.get(43));
		if(CurrURL.contains("--byjusuatfc")) {
		ncd.EnterOrders(randomNum);
		ncd.SelectReasonForRefund(al.get(44));
		}
		ncd.ClickSave();

		CreatedCaseRecordPO ccr = new CreatedCaseRecordPO(driver);
		String CaseRecord = ccr.CaptureNewCaseRecord();
		log.info("New Case Record " + CaseRecord + " created successfully");System.out.println(CaseRecord);
		
		String AccountURL = driver.getCurrentUrl();
		
		if(!CurrURL.contains("--byjusuatfc")) {
		ccr.ClickAssingedTo();
		ccr.EnterAssingedTo2(al2.get(1));
		ccr.ClickSave();
		}
		else if(CurrURL.contains("--byjusuatfc")) {
			lo.SwitchUser(al4.get(3));
			ac.closeTabWindows();
			ac.Notification();
			//ac.NavBackToAccount();
			ac.goTo(AccountURL);
			Thread.sleep(5000);	
			ccr.ClickAssingedTo();
			ccr.EnterAssingedTo2(al2.get(1));
			ccr.ClickSave();
		}
/*		else {
		    ccr.ClickAssingedTo();
	        ccr.EnterAssingedTo2(al2.get(1));
	        ccr.ClickSave();
		}
		
*/		
		//String Colluser = MailFullName(al2.get(1));

		//Logging in as the assigned user
		ccr.ClickAssignedUser2(al2.get(1));
	    log.info("Logging in as Collection Assistant " + FullName(al2.get(1)));
	    UserDetailPO ud = new UserDetailPO(driver); 
	    ud.ClickUserDetailbutton();
	  
	    if(CurrURL.contains("--byjusuatfc")) {
	    	AccountURL = driver.getCurrentUrl();
	    	lo.OnlyLogout();
	    	ac.goTo(AccountURL);
			Thread.sleep(4000);	
	    }
	    
	    UserSetupPO us = new UserSetupPO(driver); 
	    us.ClickLoginbutton();
		 
	    ac.closeTabWindows();
		CollectionAssistantLoginPO cal = new CollectionAssistantLoginPO(driver);
		cal.ClickBellicon();
		if(CurrURL.contains("--byjusuatfc")) {
		cal.SelectAssignedTask(taskName(al4.get(3)));
		}
		else {
			cal.SelectAssignedTask(taskName(al4.get(1)));	
		}

		FirstConnectPO fc = new FirstConnectPO(driver);
		String Firstconnect_caseid = fc.CaptureFCcaseid();
		String FCURL=driver.getCurrentUrl();
		
		// Compare the Case Record to First connect case Record
		Assert.assertEquals(CaseRecord, Firstconnect_caseid);
		log.info("Providing Capture payment detail for Case record " + Firstconnect_caseid);
		fc.ClickCapturePayment();

		CapturePaymtDetailsFPPO cpfp = new CapturePaymtDetailsFPPO(driver);
		cpfp.EnterRating(al.get(15));
		cpfp.ClickNext();
		cpfp.SelectPaymntOptn(al.get(16));
		log.info("Selected the payment option " + al.get(16));
		cpfp.ClickNext();
		cpfp.SelectNoofEMI(al.get(35));
		if(!CurrURL.contains("--byjusuat") && !CurrURL.contains("--byjusuatfc")) {
	           cpfp.EnterDateTimePPDProd();
	        }
		else {
		cpfp.EnterDateTimePPD();
		}
		cpfp.ClickNext();
		cpfp.EnterStreetDetails(al.get(36));
		cpfp.EnterCityDetails(al.get(37));
		cpfp.EnterStateDetails(al.get(38));
		cpfp.EnterPinDetails(al.get(39));
		cpfp.EnterCountryDetails(al.get(40));
		cpfp.EnterAPhoneDetails(al.get(41));
		cpfp.EnterFPCommentDetails(al.get(42));
		cpfp.ClickNextSwitchDefault();

		
		
		log.info("Logging out as Collection Assistant");
		//cal.CloseNotification();
		Thread.sleep(1000);
		//cal.Logout();
		lo.OnlyLogout();
		
		ac.goTo(FCURL);
		ac.AdditionalWait();
		
		if(!CurrURL.contains("--byjusuatfc")) {
		String Firstconnect_status = fc.CheckFCStatus();
		// Verify the status First connect is updated to Completed
		Assert.assertEquals(Firstconnect_status, "Completed");
		String Firstconnect_callstatus = fc.CheckFCCallStatus();
		// Verify the Call status First connect is updated to SLA Violation
		Assert.assertEquals(Firstconnect_callstatus, "SLA Violation");
		}

		ac.closeCurrentTabWindow();
		ac.CloseSubTabs();
		lo.RefreshURL();

		log.info("Verifying the Payment/Case Status are correct");
		p.NavCaseTab(CaseRecord);
		
		if(CurrURL.contains("--byjusuatfc")) {
			cases.ClickRelatedTab();
			
		}
		
		log.info("Deleting the created Case Record " +CaseRecord);
		p.NavCasesTab();
		lo.RefreshURL();

		cases.DeleteCCaseRecord(CaseRecord);
		
		log.info("Deleting the created Payment Record " + PaymentRecord);
		p.NavMenuClick();
		p.PaymntNavMenuClick();
		p.DeletePayRecord(PaymentRecord);

	}

	
	@AfterMethod(alwaysRun = true)
	public void teardown() throws InterruptedException {

		driver.quit();

	}

}
