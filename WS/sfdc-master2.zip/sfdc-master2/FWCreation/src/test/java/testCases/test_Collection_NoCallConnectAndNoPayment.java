package testCases;


import java.io.IOException;

import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.openqa.selenium.WebDriver;

import org.testng.annotations.AfterMethod;

import org.testng.annotations.BeforeMethod;


import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import org.testng.Assert;


import pageObjects.CasesPO;
import pageObjects.CollectionAssistantLoginPO;
import pageObjects.CreatedAccountPO;
import pageObjects.CreatedCaseRecordPO;
import pageObjects.FirstConnectPO;
import pageObjects.FollowUpPTPPO;

import pageObjects.NPPaymentLoanPO;
import pageObjects.NewCaseDetailsPO;
import pageObjects.NewCaseRecordTypePO;
import pageObjects.NewPaymentPO;
import pageObjects.NewPaymentRecordPO;
import pageObjects.PaymentCaseQAPO;
import pageObjects.PaymentsPO;
import pageObjects.TasksPO;
import pageObjects.UserDetailPO;
import pageObjects.UserSetupPO;
import pageObjects.loginPO;

import resources.ExcelData;
import resources.base;

public class test_Collection_NoCallConnectAndNoPayment extends base {

	public WebDriver driver;
	public static Logger log = LogManager.getLogger(test_CollectionFlow.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	ArrayList<String> al3 = new ArrayList<String>();
	ArrayList<String> al4 = new ArrayList<String>();
	static Faker faker = new Faker();
	static String firstName = faker.name().firstName();
	static String lastName = faker.name().lastName();
	static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);

	@BeforeMethod(alwaysRun = true)
	public void initialize() throws IOException, InterruptedException {

		driver = initializeDriver();
	}

	@Test(groups = { "sanity", "Regression" }, enabled = true)
	public void NoCallConnectAndNoPayment() throws Exception {

		loginPO lo = new loginPO(driver);
		if (CurrURL.contains("--byjusuatfc")) {
			al = excelData.getData("TC3", "CollectionFlow", "Tcid");
			al2 = excelData.getData("CollectionAssistant UATFC", "Login", "Type");
			al3 = excelData.getData("CollectionManager UATFC", "Login", "Type");
			al4 = excelData.getData("Adminuatfc", "Login", "Type");
			log.info("Logging in as Admin to UATFC");
			lo.LoginAsAdmin_UATFC();

		} else if (CurrURL.contains("--byjusuat")) {
			al = excelData.getData("TC3", "CollectionFlow", "Tcid");
			al2 = excelData.getData("CollectionAssistant UAT", "Login", "Type");
			al3 = excelData.getData("CollectionManager UAT", "Login", "Type");
			al4 = excelData.getData("Admin", "Login", "Type");
			log.info("Logging in as Admin to UAT");
			lo.LoginAsAdmin_UAT();

		} else {
			al = excelData.getData("TC3", "CollectionFlow", "Tcid");
			 al2 = excelData.getData("Dummy Collection Associate", "Login", "Type");
	         al4 = excelData.getData("AdminProd", "Login", "Type");
			log.info("Logging in as Admin to Prod");
			lo.LoginAsAdmin_Prod();
		}
		

		log.info("Creating new Payment record");
		CreatedAccountPO ac = new CreatedAccountPO(driver);
		PaymentsPO p = new PaymentsPO(driver);
		CasesPO cases = new CasesPO(driver);
		ac.closeTabWindows();
		ac.Notification();
		p.NavMenuClick();
		p.PaymntNavMenuClick();
		p.NewPaymentClick();

		log.info("Selection of Payment - Loan record");
		NewPaymentPO np = new NewPaymentPO(driver);
		np.SelectPaymentOptn(al.get(1));
		np.ClickNext();

		log.info("Enter New Payment - Loan details");
		NPPaymentLoanPO npp = new NPPaymentLoanPO(driver);
		// npp.EnterPayRefID(randomNum);
		npp.EnterParentFN(firstName);
		npp.EnterParentLN(lastName);
		npp.EnterLoanAmount(al.get(2));
		npp.EnterTenurity(al.get(4));
		npp.EnterProgramName(al.get(3));
		npp.EnterEPPartner(al.get(5));
		npp.EnterAmount(al.get(6));
		npp.EnterTotalAmountTBC(al.get(7));
		npp.EnterNetPayAmount(al.get(8));
		npp.EnterPaymentAmount(al.get(9));
		npp.EnterPaymentCategory(al.get(10));
		npp.EnterPaymentMS(al.get(11));
		npp.EnterPaymentDate(al.get(12));
		npp.EnterPaymentType(al.get(13));
		npp.ClickSave();
		NewPaymentRecordPO npr = new NewPaymentRecordPO(driver);
		String PaymentRecord = npr.CapturePaymentRcdID();
		log.info("New Payment Record " + PaymentRecord + " created successfully");
		String PaymentRcd = driver.getCurrentUrl();
		npr.ClickCasesQA();

		log.info("Creating New Case Record for " + PaymentRecord);
		PaymentCaseQAPO pcqa = new PaymentCaseQAPO(driver);
		pcqa.ClickCaseNewButton(PaymentRecord);

		NewCaseRecordTypePO ncrt = new NewCaseRecordTypePO(driver);
		ncrt.SelectCaseRecordType(al.get(14));
		ncrt.ClickNext();

		NewCaseDetailsPO ncd = new NewCaseDetailsPO(driver);
		//Thread.sleep(2000);

		ncd.EnterSubject(al.get(43));
		if (CurrURL.contains("--byjusuatfc")) {
			ncd.EnterOrders(randomNum);
			ncd.SelectReasonForRefund(al.get(44));
		}
		ncd.ClickSave();
		ac.AdditionalWait();

		CreatedCaseRecordPO ccr = new CreatedCaseRecordPO(driver);
		String CaseRecord = ccr.CaptureNewCaseRecord();
		log.info("New Case Record " + CaseRecord + " created successfully");

		String AccountURL = driver.getCurrentUrl();

		if (!CurrURL.contains("--byjusuatfc")) {
			ccr.ClickAssingedTo();
			ccr.EnterAssingedTo2(al2.get(1));
			ccr.ClickSave();
		} else if (CurrURL.contains("--byjusuatfc")) {
			lo.SwitchUser(al4.get(3));
			ac.closeTabWindows();
			ac.Notification();
			ac.goTo(AccountURL);
			Thread.sleep(5000);
			ccr.ClickAssingedTo();
			ccr.EnterAssingedTo2(al2.get(1));
			ccr.ClickSave();
		}

		String Colluser = MailFullName(al2.get(1));

		// Logging in as the assigned user
		ccr.ClickAssignedUser2(al2.get(1));
		log.info("Logging in as Collection Assistant " + FullName(al2.get(1)));
		UserDetailPO ud = new UserDetailPO(driver);
		ud.ClickUserDetailbutton();

		if (CurrURL.contains("--byjusuatfc")) {
			AccountURL = driver.getCurrentUrl();
			lo.OnlyLogout();
			ac.goTo(AccountURL);
			Thread.sleep(4000);
		}

		UserSetupPO us = new UserSetupPO(driver);
		us.ClickLoginbutton();
		
		ac.closeTabWindows();
		CollectionAssistantLoginPO cal = new CollectionAssistantLoginPO(driver);
		cal.ClickBellicon();
		if (CurrURL.contains("--byjusuatfc")) {
			cal.SelectAssignedTask(taskName(al4.get(3)));
		} else {
			cal.SelectAssignedTask(taskName(al4.get(1)));
		}
		FirstConnectPO fc = new FirstConnectPO(driver);
		String Firstconnect_caseid = fc.CaptureFCcaseid();
		// Compare the Case Record to First connect case Record
		Assert.assertEquals(CaseRecord, Firstconnect_caseid);
		log.info("Providing Capture payment detail for Case record " + Firstconnect_caseid);

		// DNP Scenario
		fc.clickNoCallConnectBtn();
		fc.clickNoCallConnect("DNP");
		fc.enterPhone();
		fc.enterComments();
		fc.clickNextSwitchDefault();

		String Firstconnect_status = fc.CheckFCStatus();
		// Verify the First connect status is updated to Completed
		Assert.assertEquals(Firstconnect_status, "Completed");
		String Firstconnect_callstatus = fc.CheckFCCallStatus();
		// Verify the First connect call status is updated to PTP
		Assert.assertEquals(Firstconnect_callstatus, "DNP");

		log.info("Verifying the Follow up Task is created");
		TasksPO t = new TasksPO(driver);
		t.NavBackToTask();
		t.SelectCR(CaseRecord);

		ccr.ClickFollowPTPRcd(CaseRecord);
		FollowUpPTPPO fuptp = new FollowUpPTPPO(driver);
		String AssignedToOwner = fuptp.CaptureAssignedTo();
		Assert.assertTrue(AssignedToOwner.equalsIgnoreCase(Colluser));

		// ATCB Scenario
		fc.clickNoCallConnectBtn();
		fc.clickNoCallConnect("ATCB");
        if (!CurrURL.contains("--byjusuat") && !CurrURL.contains("--byjusuatfc")) {
            fc.enterCallBackDateProd();
        } else {
            fc.enterCallBackDate();
        }
		fc.enterPhone();
		fc.enterComments();
		fc.clickNext();
	    fc.EnterRating();
		fc.clickNextSwitchDefault();

		String Followup_status = fc.CheckFCStatus();
		Assert.assertEquals(Followup_status, "Completed");
		String Followup_callstatus = fc.CheckFCCallStatus();
		Assert.assertEquals(Followup_callstatus, "ATCB");

		log.info("Verifying the Follow up Task is created");
		ncd.clickCloseSubTab();
		ccr.ClickFollowPTPRcd(CaseRecord);

		AssignedToOwner = fuptp.CaptureAssignedTo();
		Assert.assertTrue(AssignedToOwner.equalsIgnoreCase(Colluser));

		// CX Disconnected - Blank call
		fc.clickNoCallConnectBtn();
		fc.clickNoCallConnect("CX Disconnected - Blank call");
		fc.enterPhone();
		fc.enterComments();
		fc.clickNextSwitchDefault();
		ac.AdditionalWait();

		Followup_status = fc.CheckFCStatus();
		Assert.assertEquals(Followup_status, "Completed");
		Followup_callstatus = fc.CheckFCCallStatus();
		Assert.assertEquals(Followup_callstatus, "CX Disconnected - Blank call");

		log.info("Verifying the Follow up Task is created");
		ncd.clickCloseSubTab();

		// No Payment scenario with Reason Denial = Loan Closure
		ccr.ClickFollowPTPRcd(CaseRecord);
		AssignedToOwner = fuptp.CaptureAssignedTo();
		Assert.assertTrue(AssignedToOwner.equalsIgnoreCase(Colluser));
		fc.clickNoPaymntBtn();
		fc.switchToTheFrame();
		fc.clickNoPayment("No Payment");
		fc.clickNoPayment("Loan Closure");
		fc.enterComments();
		fc.clickNextSwitchDefault();
		ac.AdditionalWait();

		Followup_status = fc.CheckFCStatus();
		Assert.assertEquals(Followup_status, "Completed");
		Followup_callstatus = fc.CheckFCCallStatus();
		Assert.assertEquals(Followup_callstatus, "No Payment");
		Followup_callstatus = fc.CheckReasonForDenial();
		Assert.assertEquals(Followup_callstatus, "Loan Closure");
		ncd.clickCloseSubTab();

		// No Payment scenario with Reason Denial = Facing Issues-BYJUS
		ccr.ClickFollowPTPRcd(CaseRecord);
		fc.clickNoPaymntBtn();
		fc.switchToTheFrame();
		fc.clickNoPayment("No Payment");
		fc.SelectCxIssue("Mentor Call Back Needed");
		fc.enterComments();
		fc.clickNextSwitchDefault();
		ac.AdditionalWait();

	    Followup_status = fc.CheckFCStatus();
		Assert.assertEquals(Followup_status, "Completed");
		Followup_callstatus = fc.CheckFCCallStatus();
		Assert.assertEquals(Followup_callstatus, "No Payment");
		Followup_callstatus = fc.CheckReasonForDenial();
		Assert.assertEquals(Followup_callstatus, "Facing Issues-BYJUS");
		ncd.clickCloseSubTab();

		// No Payment scenario with Reason Denial = CX requested for Cancellation
		ccr.ClickFollowPTPRcd(CaseRecord);
		fc.clickNoPaymntBtn();
		fc.switchToTheFrame();
		fc.clickNoPayment("No Payment");
		fc.clickNoPayment("CX requested for Cancellation");
		fc.SelectCxIssue("Financial Issue");
		fc.enterComments();
		fc.clickNextSwitchDefault();
		ac.AdditionalWait();

		Followup_status = fc.CheckFCStatus();
		Assert.assertEquals(Followup_status, "Completed");
		Followup_callstatus = fc.CheckFCCallStatus();
		Assert.assertEquals(Followup_callstatus, "No Payment");
		Followup_callstatus = fc.CheckReasonForDenial();
		Assert.assertEquals(Followup_callstatus, "CX requested for Cancellation");
		ncd.clickCloseSubTab();

		// Intent to Pay scenario
		ccr.ClickFollowPTPRcd(CaseRecord);
		fc.clickNoPaymntBtn();
		fc.switchToTheFrame();
		fc.clickNoPayment("Intent to Pay");
        if (!CurrURL.contains("--byjusuat") && !CurrURL.contains("--byjusuatfc")) {
            fc.enterCallBackDateNoPaymentProd();
        } else {
            fc.enterCallBackDateNoPayment();
        }
		fc.enterComments();
		fc.clickNextSwitchDefault();
		ac.AdditionalWait();

		Followup_status = fc.CheckFCStatus();
		Assert.assertEquals(Followup_status, "Completed");
		Followup_callstatus = fc.CheckFCCallStatus();
		Assert.assertEquals(Followup_callstatus, "Intent to Pay");
		ncd.clickCloseSubTab();

		// Refuse to Pay scenario
		ccr.ClickFollowPTPRcd(CaseRecord);
		fc.clickNoPaymntBtn();
		fc.switchToTheFrame();
		fc.clickNoPayment("Refuse to Pay");
		fc.enterComments();
		fc.clickNextSwitchDefault();
		ac.AdditionalWait();

		Followup_status = fc.CheckFCStatus();
		Assert.assertEquals(Followup_status, "Completed");
		Followup_callstatus = fc.CheckFCCallStatus();
		Assert.assertEquals(Followup_callstatus, "Refuse to pay");
		ncd.clickCloseSubTab();

		// SUP Call scenario
		ccr.ClickFollowPTPRcd(CaseRecord);
		fc.clickNoPaymntBtn();
		fc.switchToTheFrame();
		fc.clickNoPayment("SUP Call");
		fc.enterComments();
		fc.clickNextSwitchDefault();
		ac.AdditionalWait();

	    Followup_status = fc.CheckFCStatus();
		Assert.assertEquals(Followup_status, "Completed");
	    Followup_callstatus = fc.CheckFCCallStatus();
		Assert.assertEquals(Followup_callstatus, "SUP Call");
		ncd.clickCloseSubTab();
		String currentSupCallCaseUrl=driver.getCurrentUrl();
		String assignedTo=ccr.getSupCallDueAssignee();
	
		//logging out
		log.info("Logging out as Collection Assistant");
		//Thread.sleep(1000);
		lo.OnlyLogout();
		
		//logging in as Supervisor to complete sup call
		lo.LogbackwithUser(assignedTo);
		ac.closeTabWindows();
		ac.Notification();
		//closeTabWindows();
		//Thread.sleep(5000);
		ac.NavigateTo(currentSupCallCaseUrl);
		ccr.clickSupCallDue();
		fc.saveSupCallDue();
		ncd.clickCloseSubTab();
		lo.RefreshURL();
		String CaseStatus = ccr.CaseStatusval();
		String CaseOwner = ccr.CaseOwnerval();
		log.info("The record number for newly created Case record is " + ccr.CaptureNewCaseRecord());
		// Verify the Case Status is changed to Audit Pending
		Assert.assertEquals(CaseStatus, "Churned");
		// Verify the Case owner is same
		Assert.assertTrue(CaseOwner.equalsIgnoreCase(Colluser));	
		ac.Scrollpagedown();
		ccr.clickSupCallDue();
		String[] data=fc.getSupTaskStatus();
		Assert.assertEquals(data[0], "Completed");
		Assert.assertEquals(data[1], "Issue Resolved");

		log.info("Logging out as Collection Assistant");
		// cal.CloseNotification();
		//Thread.sleep(1000);
		// cal.Logout();
		lo.Logouthome();
		
		log.info("Verifying the Payment/Case Status are correct");
		ac.goTo(PaymentRcd);
		ac.AdditionalWait();
		ac.CloseSubTabs();
		npr.ClickCasesQA();
		//deleting cases
		log.info("Deleting the created Case Record " + CaseRecord); 
		cases.CloseAllCases();

		log.info("Deleting the created Payment Record " + PaymentRecord);
		p.NavMenuClick();
		p.PaymntNavMenuClick();
		p.DeletePayRecord(PaymentRecord);

	}

	@AfterMethod(alwaysRun = true)
	public void teardown() throws InterruptedException {

		driver.quit();

	}

}
