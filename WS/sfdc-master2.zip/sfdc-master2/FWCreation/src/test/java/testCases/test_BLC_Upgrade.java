package testCases;

import java.io.IOException;
import java.util.ArrayList;

import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.openqa.selenium.WebDriver;

import org.testng.annotations.AfterMethod;

import org.testng.annotations.BeforeMethod;

import org.testng.annotations.Test;


import com.github.javafaker.Faker;

import org.testng.Assert;

import pageObjects.AccountTeamPO;
import pageObjects.BranchAccountPO;
import pageObjects.CreatedAccountPO;
import pageObjects.DevConsolePO;

import pageObjects.IssueTreePO;
import pageObjects.NewCaseRecordTypePO;
import pageObjects.OpenActivitiesPO;
import pageObjects.OutboundBTCTaskPO;

import pageObjects.PEShippedTaskPO;


import pageObjects.StudentProgPO;

import pageObjects.StudentSubOrderPO;

import pageObjects.loginPO;

import payLoad.payLoad_BTLAwithBranchAccount;
import resources.Batches;
import resources.ExcelData;
import resources.base;



public class test_BLC_Upgrade extends base {

	public WebDriver driver;
	//public String CurrURL;
	public static Logger log = LogManager.getLogger(test_BLC_Upgrade.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> proddummyuser = new ArrayList<String>();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	static Faker faker = new Faker();
	static String firstName = faker.name().firstName();
	static String lastName = faker.name().lastName();
	static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);
	
	@BeforeMethod(alwaysRun = true)
	public void initialize() throws IOException, InterruptedException {

		driver = initializeDriver();

	}
	
	
	@Test(groups = {"sanity", "UAT" }, enabled = true)
	public void TestBLC() throws Exception {
	    proddummyuser = excelData.getData("TC1", "ProdDummyUser", "Tcid");
		String Accountid = null;
		loginPO lo=new loginPO(driver);
		

		if(CurrURL.contains("--byjusuat")) {
		al = excelData.getData("TC1", "BLC", "Tcid");

		
		log.info("Logging in as Admin to UAT");
		lo.LoginAsAdmin_UAT();
		log.info("Submitting the Account creation payload");
		Accountid=payLoad_BTLAwithBranchAccount.AccountidCreationResponse_UAT(al.get(108));
		log.info("Launching the newly created Account id "+Accountid);
		
		}
		else {
			al = excelData.getData("TC2", "BLC", "Tcid");
			//al2 = excelData.getData("Collection Assistant", "Login", "Type");
			log.info("Logging in as Admin to Prod");
			lo.LoginAsAdmin_Prod();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_BTLAwithBranchAccount.AccountidCreationResponse_Prod(al.get(108));
			log.info("Launching the newly created Account id "+Accountid);
		}
		
		

		CreatedAccountPO ac=new CreatedAccountPO(driver);
		StudentProgPO sp= new StudentProgPO(driver);
		NewCaseRecordTypePO ncrt= new NewCaseRecordTypePO(driver);
		BranchAccountPO ba = new BranchAccountPO(driver);
		AccountTeamPO at = new AccountTeamPO(driver);
	    PEShippedTaskPO pes=new PEShippedTaskPO(driver);
	    OutboundBTCTaskPO obtc = new OutboundBTCTaskPO(driver);
		//Open the account by searching PID
		ac.closeTabWindows();
		ac.Notification();
		ac.NavBackToAccount();
		String AccountURL = CurrURL+Accountid;
		ac.goTo(AccountURL);
		ac.AccountLoadwait();
		
		String AccountAssignedOwner = ac.CaptureAccOwnerNam();
		
		//Navigate to Branch account
		if(CurrURL.contains("byjusprod.")) {
		    ac.SelectStudentProg("Hybrid Tuitions at BYJU'S Learning Center");   
		}
		else {
		ac.SelectStudentProg("Hybrid Tuitions at BYJU'S Tuition Centre");
		}
		sp.ClickBranchAccount();
		
		//Verify the team members under Account Team on Branch Account
		ba.ClickAccountTeamCard();
		at.VerifyAccOwnerBLCRole(AccountAssignedOwner,CurrURL);
		ac.CloseSubTabs();
		
		//Setting  SSO to Shipped status
		log.info("Navigating to Student sales order");
		
		StudentSubOrderPO Ssub=new StudentSubOrderPO(driver);
		ac.ClickStudentSalesOrder();
		Ssub.ClickOrderinOrders();
		Ssub.SelectStatus("Shipped");
		Ssub.ClickSave();
		
		ac.ClickAccOwnrTab();
		ac.RefreshTab();
		
		String MainWin = driver.getWindowHandle();
        //Running the Batch to create BTC Feedback call
        DevConsolePO dc= new DevConsolePO(driver);
        OpenActivitiesPO oa = new OpenActivitiesPO(driver);
        if(CurrURL.contains("--byjusuata")&&!CurrURL.contains("--byjusuatfc")) {
        dc.GetDevConsole("UAT");
        dc.RunBatch(Batches.GenerateBTCFeedbackCall());
        dc.CheckBatchRunSuccess();      
        //dc.CloseWindowArrayLast();
        driver.switchTo().window(MainWin);
        ac.CloseSubTabs();
        ac.AdditionalWait();
        ac.RefreshTab();
        ac.ClickOpenActivities();
        oa.VerifyTaskpresent("BTC Feedback Call");
        Assert.assertEquals(oa.CaptureAssignedUsertoTask("BTC Feedback Call"),AccountAssignedOwner);
        //Assert.assertTrue(false);
        ac.CloseSubTabs();
        //UserDetailPO ud= new UserDetailPO(driver);
        //Assert.assertEquals(ud.CaptureProfile(),"Mentor");
        //ac.CloseCurrentSubTab();
        //Assert.assertEquals(ac.CaptureSuperStatus(), "Transition");
       // Assert.assertEquals(ac.CaptureStatus(), "PE-Mentor Transition");
        }
        
      //Creating 4 Outbound BTC Tasks as Admin
        for(int i=0;i<4;i++) {
        ac.ClickOpenActivitiestoNewTask();
        ncrt.SelectTaskRecordType("Outbound BTC");
        ncrt.ClickNext();
        ncrt.EnterSubject("Primary Outbound – Service Counsellor");
        ncrt.ClickSave();
        ac.AdditionalWait();
        ac.CloseSubTabs();
        }

        if(CurrURL.contains("byjusprod.")) {
            ac.AccountLoadwait();
            ac.AssignAccount("Testing User");
        }
        
        if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
        lo.SwitchUser(AccountAssignedOwner);
        ac.closeTabWindows();
        ac.Notification();
        ac.NavBackToAccount();
        ac.goTo(AccountURL);
        ac.AdditionalWait();
        }
        else {
            lo.SwitchUsernProfile_Prod(proddummyuser.get(1),"BLC Counsellor");
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AdditionalWait();
        }

        if(CurrURL.contains("byjusprod.")) {
		//Verify BTC Welcome Call is created
        ac.Scrollpagedown();
		Assert.assertTrue(ac.CheckVisBTCWelcomeCall_UAT());
		log.info("Navigating to BTC Welcome Call tasks");
		ac.ClickBTCWelcomeCall();
		pes.ClickCaptureDetail();
		log.info("Selecting Capture Call as Proceed for BTC Welcome Call Task");
		pes.SelectProceed_iframe();
		pes.SelectBTCNumberPrimaryContact(al.get(92));
		pes.SelectBTCPrimaryPointOfContact(al.get(93));
		pes.SelectBTCNumberUpdatedOnSF(al.get(94));
		pes.SelectBTCPaymentMethod(al.get(95));
		pes.SelectBTCEMITermNValue(al.get(96));
		pes.SelectBTCCurrentGradeStated(al.get(97));
		pes.SelectBTCCentrePunched(al.get(98));
		pes.SelectBTCBoardPunched(al.get(99));
		pes.SelectBTCTabletReceived(al.get(100));
		pes.SelectBTCExpiryProgramOrderPunched(al.get(101));
		pes.SelectBTCNameOfSchool(al.get(102));
		pes.SelectBTCInClassOrientation(al.get(103));
		pes.SelectBTCLikelyParentsAttendOrientation(al.get(104));
		pes.SelectBTCReasonNotAttendingOrientation_UAT(al.get(105));
		pes.SelectBTCWhatsappOptIn(al.get(106));
		pes.SelectBTCScale(al.get(107));
		pes.SelectProceedVisIsThereIssue();
		pes.SelectProceedIsThereIssue(al.get(20));
		
		ac.RefreshTab_Targetframe_IT();
		pes.NavBackAccount();
		ac.CloseSubTabs();
        }
		
		//Navigating to Open Activities Task - DNP flow
        ac.ClickOpenActivities();
        oa.SelectTaskNumber("Primary Outbound – Service Counsellor",1);
        
        Assert.assertEquals(obtc.CaptureDNPCounter(), "0");
        obtc.ClickCaptureDetail();
        obtc.SelectDNP();
        ac.RefreshTab_Targetframe();
        Assert.assertEquals(obtc.CaptureDNPCounter(), "1");
        Assert.assertEquals(obtc.CaptureStatus(), "Completed");
        ac.CloseSubTabs();
		
        //Navigating to Open Activities Task - Customer Call Back Requested flow
        ac.ClickOpenActivities();
        oa.SelectTaskNumber("Primary Outbound – Service Counsellor",1);
        
        obtc.ClickCaptureDetail();
        obtc.SelectCallBackRequested();
        
        ac.RefreshTab_Targetframe();
        Assert.assertEquals(obtc.CaptureCallStatus(),"Call Back Requested");
        ac.CloseSubTabs();
        
        //Navigating to Open Activities Task - Customer will call  flow
        ac.ClickOpenActivities();
        oa.SelectTaskNumber("Primary Outbound – Service Counsellor",2);
        
        obtc.ClickCaptureDetail();
        obtc.ClickCustomerwillCall();
        
        obtc.ClickFinish();
        
        ac.RefreshTab_Targetframe();
        Assert.assertEquals(obtc.CaptureStatus(),"Closed");
        ac.CloseSubTabs();
        
        //Navigating to Open Activities Task - Proceed flow
        ac.ClickOpenActivities();
        oa.SelectTaskNumber("Primary Outbound – Service Counsellor",2);
        obtc.SelectDecision("Registered with BTC");
        obtc.ClickSave();
        
        obtc.ClickCaptureDetail();
        obtc.SelectProceed_iframe();
        obtc.ClickNext();
        
        IssueTreePO it=new IssueTreePO(driver);
        obtc.SelectSpokeTo(al.get(109));
        it.PremiumidSelector();
        it.ProgramSelector();
        it.ClickNext();
        
        //Verifying values for Reason for Call Type : Academic
        obtc.SelectReasonForCallType("Academic");
        obtc.ClickReasonForCallSubtype();
        obtc.VerifyAllValinReasonForCallSubtype(110);
        
        //Verifying values for Reason for Call Type : Service Related
        obtc.SelectReasonForCallType("Service Related");
        obtc.ClickReasonForCallSubtype();
        obtc.VerifyAllValinReasonForCallSubtype(111);
        
        //Verifying values for Reason for Call Type : Events
        obtc.SelectReasonForCallType("Events");
        obtc.ClickReasonForCallSubtype();
        obtc.VerifyAllValinReasonForCallSubtype(112);
        
        //Verifying values for Reason for Call Type : Refund Request
        obtc.SelectReasonForCallType("Refund Request");
        obtc.ClickReasonForCallSubtype();
        obtc.VerifyAllValinReasonForCallSubtype(113);
        
        //Verifying values for Reason for Call Type : Pre Sale
        obtc.SelectReasonForCallType("Pre Sale");
        obtc.ClickReasonForCallSubtype();
        obtc.VerifyAllValinReasonForCallSubtype(114);
        
        //Selecting value for Reason for Call Type : Pre Sale
        obtc.SelectReasonForCallSubtype("Walkin Invite");
        obtc.ClickNext();
        obtc.SelectProceedVisIsThereIssue(al.get(84));
        obtc.EnterComments(al.get(55));
        obtc.ClickNext();
        
        ac.RefreshTab_Targetframe();
        lo.RefreshURL();
        Assert.assertEquals(obtc.CaptureCallStatus(),"Call Completed");
        Assert.assertEquals(obtc.CaptureStatus(),"Completed");
        
		lo.OnlyLogout();
		ac.goTo(AccountURL);
		ac.AdditionalWait();
		
		//Deleting created Account record
		log.info("Deleting the Student Program details");
		ac.ClickAccOwnrTab();
		ac.DeleteCreatedStuProg();
		ac.DeleteAllCreatedStuPayment();
		ac.NavBackToAccount();
		log.info("Deleting the Account created details");
		ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
			
				
		
	}
		
	
	  @AfterMethod(alwaysRun = true) public void teardown() throws
	  InterruptedException {
	  
	  driver.quit();
	  
	  //Thread.sleep(2000); 
	  }
	 
	
	
}
