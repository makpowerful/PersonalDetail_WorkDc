package testCases;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import pageObjects.CasesPO;
import pageObjects.CreatedAccountPO;
import pageObjects.GmailPO;
import pageObjects.InboundTaskPO;
import pageObjects.IssueTreePO;
import pageObjects.NewCaseRecordTypePO;
import pageObjects.loginPO;
import payLoad.payLoad_BTLA2;
import resources.ExcelData;
import resources.base;



public class test_Email_Registered extends base {

	public WebDriver driver;
	//public String CurrURL;
	public static Logger log = LogManager.getLogger(test_Email_Registered.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> proddummyuser = new ArrayList<String>();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	ArrayList<String> al3 = new ArrayList<String>();
	ArrayList<String> al4 = new ArrayList<String>();
	ArrayList<String> al5 = new ArrayList<String>();
	ArrayList<String> al6 = new ArrayList<String>();
	static Faker faker = new Faker();
	static String firstName = faker.name().firstName();
	static String lastName = faker.name().lastName();
	static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);
	
	@BeforeMethod(alwaysRun = true)
	public void initialize() throws IOException, InterruptedException {

		driver = initializeDriver();

	}
	
	
	@Test(groups = {"sanity", "UAT" }, enabled = true)
	public void TestEmailRegistered() throws Exception {
	    proddummyuser = excelData.getData("TC1", "ProdDummyUser", "Tcid");
		String Accountid = null;
		loginPO lo=new loginPO(driver);
		al = excelData.getData("TC1", "RefundProcess", "Tcid");
		al5 = excelData.getData("SFEmail", "Login", "Tcid");
		if(CurrURL.contains("--byjusuatfc")) {
			al6 = excelData.getData("UATFC", "Email", "Tcid");
			al2 = excelData.getData("PE User UATFC", "Login", "Type");
			log.info("Logging in as Admin to UATFC Env then switching user to PE");
			lo.LoginAsAdmin_UATFC();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_BTLA2.AccountidCreationResponse_UATFC();
			log.info("Launching the newly created Account id "+Accountid);
		}
		else if(CurrURL.contains("--byjusuat")) {
		al6 = excelData.getData("UAT", "Email", "Tcid");
		al2 = excelData.getData("PE User UAT", "Login", "Type");
		
		log.info("Logging in as Admin to UAT then switching user to PE");
		lo.LoginAsAdmin_UAT();
		log.info("Submitting the Account creation payload");
		Accountid=payLoad_BTLA2.AccountidCreationResponse_UAT();
		log.info("Launching the newly created Account id "+Accountid);
		
		}
		else {
			al6 = excelData.getData("Prod", "Email", "Tcid");
			//al2 = excelData.getData("Collection Assistant", "Login", "Type");
			log.info("Logging in as Admin to Prod");
			lo.LoginAsAdmin_Prod();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_BTLA2.AccountidCreationResponse_Prod();
			log.info("Launching the newly created Account id "+Accountid);
		}
		//Assert.assertTrue(false);
		closeTabWindows();
		
		//log.info("Submitting the Account creation payload");
		//String Accountid=payLoad_AccountCreation.AccountidCreationResponse_UAT();
		//log.info("Launching the newly created Account id "+Accountid);
		
		CreatedAccountPO ac=new CreatedAccountPO(driver);
		CasesPO cases= new CasesPO(driver);
		//Open the account by searching PID
		ac.Notification();
		ac.NavBackToAccount();
		String AccountURL = CurrURL+Accountid;
		ac.goTo(CurrURL+Accountid);
		ac.AccountLoadwait();
		
		
		if(CurrURL.contains("--byjusuat")||CurrURL.contains("--byjusuatfc")) {
			String AccountOwner= ac.AccOwnerCheck();
			if(!al2.get(1).equalsIgnoreCase(AccountOwner)) {
				ac.AssignAccount(al2.get(1));
			}
		}
		else {
			ac.AssignAccount("Testing User");
		}
		
		//Changing the email address of account
		ac.EditAccount();
		ac.UpdateStudentEmailid(al5.get(1));
		ac.UpdateEmail(al5.get(1));
		ac.ClickSave();
		
		
		
		if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
		lo.SwitchUser(al2.get(1));
		ac.closeTabWindows();
		ac.Notification();
		ac.NavBackToAccount();
		ac.goTo(AccountURL);
		ac.AccountLoadwait();

		}
		else if(CurrURL.contains("--byjusuatfc")){
			lo.SwitchUser(al2.get(1));
			ac.closeTabWindows();
			ac.Notification();
			ac.NavBackToAccount();
			ac.goTo(AccountURL);
			ac.AccountLoadwait();

		}
		else {
			lo.SwitchUsernProfile_Prod(proddummyuser.get(1),"PE");
			ac.closeTabWindows();
			ac.Notification();
			ac.NavBackToAccount();
			ac.goTo(AccountURL);
			ac.AccountLoadwait();
		}
		//ac.Scrollhome();
		
		String MainWin = driver.getWindowHandle();
		log.info("Creating Inbound Task");//SFTNL-8123 check
		ac.ClickOpenActivitiestoNewTask();
		
		NewCaseRecordTypePO ncrt= new NewCaseRecordTypePO(driver);
		
		ncrt.SelectCaseRecordTypeInbound();
		ncrt.ClickNext();
		ac.AdditionalWait();
		ncrt.ClickSave();
		ac.AdditionalWait();
		
		InboundTaskPO ibdt= new InboundTaskPO(driver);			
		ibdt.ClickCaptureDetail();
		ibdt.ClickProceedOptn();
		
		if(CurrURL.contains("--byjusuat")||CurrURL.contains("--byjusuatfc")||CurrURL.contains("byjusprod.")) {
		al3 = excelData.getData("Inbound", "Inbound", "Tcid");
		al4 = excelData.getData("TC3", "RefundProcess", "Tcid");
		IssueTreePO it=new IssueTreePO(driver);
		ibdt.SelectSpokeTo3(al3.get(1));
		it.PremiumidSelector();
		it.ProgramSelector();
		it.ClickNext();
		ibdt.SelectPSTCT(al3.get(2));
		//ibdt.EnterNotesVal(al3.get(3));
		ibdt.ClickNext();
		ac.AdditionalWait();
		it.IssueCategory(al4.get(13));
		it.Reason(al4.get(14));
		it.SubReason(al4.get(15));
		it.IssueNotes(al4.get(16));
		it.IstheIssueResolved(al4.get(17));
		it.ClickNext2();
		it.SSOandAccCombo();
		it.ClickFinish();
		}
		else {
		ibdt.SelectPSTCT(al.get(1));
		//ibdt.EnterNotesVal(al.get(2));
		ibdt.ClickNext();
		ac.AdditionalWait();
		
		
		ibdt.SelectDevice(al.get(3));
		ibdt.SelectCategory(al.get(4));
		ibdt.SelectPSTRR(al.get(5));
		ibdt.SelectPSSTRR(al.get(6));
		ibdt.EnterComments(al.get(7));
		ibdt.SelectIsTICR(al.get(8));
		
		ibdt.SelectPSTO();
		ac.AdditionalWait();
		ibdt.ClickNext();
		ac.AdditionalWait();
		}
		ibdt.NavBackAccount();
			

		//Login to Gmail
		GmailPO gm= new GmailPO(driver);
		
		gm.LoginGmail(al5.get(1),al5.get(2));
		String SecondWin = driver.getWindowHandle();

		
		String EmailSuject = gm.EmailSubject();
		gm.SendMail(al6.get(1), EmailSuject, EmailSuject);

		if(CurrURL.contains("byjusprod.")) {
		gm.CheckMailRecieved(al6.get(4));
		}
		else {
			gm.CheckMailRecieved(al6.get(1));
		}
		
		//Swtiching back to Account
		driver.switchTo().window(MainWin);
		lo.Logouthome();
		
		ac.closeTabWindows();
		ac.goTo(AccountURL);
		ac.AdditionalWait();
		
		
		//Verify the case is created and is closed, Task is created
		ac.RefreshTab();
		ac.ClickCasesMC2();
		cases.CheckCaseSubject(EmailSuject);
		String Status=cases.CaptureStatus();
		Assert.assertEquals(Status, "Closed");
		
	    ac.Scrollpagedown();
	    ac.Scrollpagedown();
	    ac.Scrollend();
		
		Assert.assertTrue(cases.VerifyEmailReqCancelTask());
		String OldReopenCount = cases.CaptureReopenCount();
		driver.switchTo().window(SecondWin);
		if(CurrURL.contains("byjusprod.")) {
		gm.ReplytoByjusMail(al6.get(4), al5.get(1));
		}
		else {
			gm.ReplytoByjusMail(al6.get(1), al5.get(1));
		}
		
		//Swtiching back to Account
		driver.switchTo().window(MainWin);
		//Verifying Status change to Open
		cases.StatusChangeCheck();
		//Verifying the reopen counter increment.
		String NewReopenCount = cases.CaptureReopenCount();
		
		log.info("The old reopen count is "+OldReopenCount+" and the new count is "+NewReopenCount+"");
		Assert.assertTrue(!OldReopenCount.equalsIgnoreCase(NewReopenCount));
		ac.CloseCurrentSubTab();
		
		//Sending mail again with a different subject
		driver.switchTo().window(SecondWin);
		
		if(CurrURL.contains("byjusprod.")) {
			gm.SendMail(al6.get(4), al6.get(3), al6.get(3));
		}
		else {
			gm.SendMail(al6.get(1), al6.get(3), al6.get(3));
		}
		
		//Verify the case is created and is closed
		driver.switchTo().window(MainWin);
		cases.NavCasesTab();
		ac.RefreshTab();
		cases.CheckCaseSubject_refresh(al6.get(3));
		Status=cases.CaptureStatus();
		//Assert.assertEquals(Status, "Closed");
		
		

		
		//Deleting the created case
		//ac.ClickCasesMC2();
		
		//String CaseNumber= cases.CaseRN();
		//log.info("The case number created is: "+CaseNumber);
		cases.NavCasesTab();
		cases.CloseAllCases();
		
		log.info("Deleting the Student Program details");
		ac.ClickAccOwnrTab();
		ac.DeleteCreatedStuProg();
		ac.DeleteAllCreatedStuPayment();
		ac.NavBackToAccount();
		log.info("Deleting the Account created details");
		ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
		
		//Sending mail again with a different subject
		driver.switchTo().window(SecondWin);
		//if(CurrURL.contains("byjusprod.")) {
		//gm.DeletingAllByjusMail(al6.get(4));
		//}
		//else {
		//	gm.DeletingAllByjusMail(al6.get(1));
		//}
		gm.ClickInboxnRefresh();
		if(CurrURL.contains("byjusprod.")) {
		gm.VerifyNoMailfromByjus(al6.get(4));
		}
		else {
			gm.VerifyNoMailfromByjus(al6.get(1));
		}
	}
		
	
	  @AfterMethod(alwaysRun = true) public void teardown() throws
	  InterruptedException {
	  
	  driver.quit();
	  
	  //ac.AdditionalWait(); 
	  }
	 
	
	
}
