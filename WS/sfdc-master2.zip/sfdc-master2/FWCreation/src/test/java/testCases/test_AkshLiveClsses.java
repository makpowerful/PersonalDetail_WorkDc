package testCases;

import java.io.IOException;

import java.util.ArrayList;

import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.openqa.selenium.WebDriver;

import org.testng.annotations.AfterMethod;

import org.testng.annotations.BeforeMethod;

import org.testng.annotations.Test;


import com.github.javafaker.Faker;

import org.testng.Assert;



import pageObjects.CreatedAccountPO;
import pageObjects.NearestStudentCentersPO;
import pageObjects.NewCaseRecordTypePO;
import pageObjects.SDCTaskPO;
import pageObjects.StudentProgPO;
import pageObjects.loginPO;
import payLoad.payLoad_AakashLive;

import resources.ExcelData;
import resources.base;



public class test_AkshLiveClsses extends base {

	public WebDriver driver;
	//public String CurrURL;
	public static Logger log = LogManager.getLogger(test_AkshLiveClsses.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> proddummyuser = new ArrayList<String>();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	static Faker faker = new Faker();
	static String firstName = faker.name().firstName();
	static String lastName = faker.name().lastName();
	static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);
	
	@BeforeMethod(alwaysRun = true)
	public void initialize() throws IOException, InterruptedException {

		driver = initializeDriver();

	}
	

	@Test(priority = 1,  groups = {"sanity", "Regression" },enabled = true)
	public void TestAakashLive() throws Exception {
	    proddummyuser = excelData.getData("TC1", "ProdDummyUser", "Tcid");
		String Accountid = null;
		loginPO lo=new loginPO(driver);
		if(CurrURL.contains("--byjusuatfc")) {
			al = excelData.getData("TC1", "AakashLive", "Tcid");
			
			
			log.info("Logging in as Admin to UATFC");
			lo.LoginAsAdmin_UATFC();
			lo.SwitchUser("pujari");
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_AakashLive.AccountidCreationResponse_UATFC();
			log.info("Launching the newly created Account id "+Accountid);
			
			}
		else if(CurrURL.contains("--byjusuat")) {
		al = excelData.getData("TC1", "AakashLive", "Tcid");
		
		
		log.info("Logging in as Admin to UAT");
		lo.LoginAsAdmin_UAT();
		lo.SwitchUser("SF_Byjus Admin");
		log.info("Submitting the Account creation payload");
		Accountid=payLoad_AakashLive.AccountidCreationResponse_UAT();
		log.info("Launching the newly created Account id "+Accountid);
		
		}
		else {
			al = excelData.getData("TC1", "AakashLive", "Tcid");
			//al2 = excelData.getData("Collection Assistant", "Login", "Type");
			log.info("Logging in as Admin to Prod");
			lo.LoginAsAdmin_Prod();
			lo.SwitchUsernProfile_Prod(proddummyuser.get(1),"System Admin Operations");
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_AakashLive.AccountidCreationResponse_Prod();
			log.info("Launching the newly created Account id "+Accountid);
		}
		
		closeTabWindows();
		CreatedAccountPO ac= new CreatedAccountPO(driver);
		NearestStudentCentersPO nsc = new NearestStudentCentersPO(driver);
		ac.Notification();
		ac.NavBackToAccount();
		ac.goTo(CurrURL+Accountid);
		Thread.sleep(5000);
		//Click on Capture call details
		log.info("Creating SDC Task");
		
		ac.ClickOpenActivitiestoNewTask();
		
		NewCaseRecordTypePO ncrt= new NewCaseRecordTypePO(driver);
		
		ncrt.SelectCaseRecordTypeSDC();
		ncrt.ClickNext();
		ncrt.EnterSubject_SDC(al.get(1));
		ac.AdditionalWait();

		
		SDCTaskPO sdc=new SDCTaskPO(driver);
		sdc.ClickCaptureDetails();
		sdc.SelectATCDCasN();
		
		//Verify Correct details Captured flow
		log.info("Verify Correct details flow for customer details as No");
		
		sdc.SelectAddrandGrade();
		Assert.assertTrue(sdc.VisStreet().isDisplayed());
		Assert.assertTrue(sdc.VisCity().isDisplayed());
		Assert.assertTrue(sdc.VisState().isDisplayed());
		Assert.assertTrue(sdc.VisZip().isDisplayed());
		Assert.assertTrue(sdc.VisCountry().isDisplayed());
		//crollend();
		Assert.assertTrue(sdc.VisGrade().isDisplayed());
		
		//Verify SDC Pitched flow
		log.info("Verify Correct details flow for customer details as Yes");
		sdc.SelectATCDCasY();
		sdc.SelectvalDiscus(al.get(2));
		
		//Setting Did customer agree as No
		log.info("Setting did customer agree as No");
		sdc.SelectDCAasN();
		Assert.assertTrue(sdc.VisResnCD().isDisplayed());
		Assert.assertTrue(sdc.VisComments().isDisplayed());
		
		//Setting Did customer agree as Will decide and confirm
		log.info("Setting did customer agree as Will decide and confirm");
		sdc.SelectDCAasWillDcde();
		Assert.assertTrue(sdc.VisTentveDate().isDisplayed());
		
		//Setting Did customer agree as Yes
		log.info("Setting did customer agree as Yes");
		sdc.SelectDCAasY();
		sdc.SelectSubjects(al.get(3));
		Assert.assertTrue(sdc.VisPSPB().isDisplayed());
		Assert.assertTrue(sdc.VisBSD().isDisplayed());
		Assert.assertTrue(sdc.VisNOBA().isDisplayed());
		
		sdc.SelectPB();
		sdc.EnterSD();
		sdc.EnterBatchAss(al.get(4));
		sdc.ClickFinish();
		//ac.CloseCurrentSubTab();
		sdc.NavBackAccount();
		
		//Creating Nearest Student Centers
		ac.ClickNearestStudentCenters();
        
        nsc.ClickNewbutton();
        nsc.EnterNearestStudentCenterName(al.get(5));
        nsc.EnterCenterDetails();
        nsc.EnterCenterName(al.get(6));
        nsc.EnterCenterAddressWithPincode(al.get(7));
        nsc.EnterCenterPhoneNumber(al.get(8));
        nsc.EnterCenterGoogleMapLink(al.get(9));
        nsc.EnterApproximateDistance(al.get(10));
        nsc.EnterVacantSeats(al.get(11));
        nsc.ClickPopupSave();
        nsc.EnterUniqueId(al.get(12));
        nsc.ClickSave();
        
        nsc.ClickCenterDetail();

        //Verifying all created details
        String CenterName = nsc.CaptureCenterName();
        Assert.assertEquals(CenterName, al.get(6));
        
        String CenterAddressWithPincode = nsc.CaptureCenterAddressWithPincode();
        Assert.assertEquals(CenterAddressWithPincode, al.get(7));
        
        //String CenterPhoneNumber = nsc.CaptureCenterPhoneNumber();
        //Assert.assertEquals(CenterPhoneNumber, al.get(8));
        
        String CenterGoogleMapLink = nsc.CaptureCenterGoogleMapLink();
        Assert.assertEquals(CenterGoogleMapLink, al.get(9));
        
        String ApproximateDistance = nsc.CaptureApproximateDistance();
        Assert.assertEquals(ApproximateDistance, al.get(10));
        
        //String VacantSeats = nsc.CaptureVacantSeats();
        //Assert.assertEquals(VacantSeats, al.get(11));
        
        nsc.DeleteCenterDetailslastbtn();
        nsc.DeleteNearestStudentCenterlastbtn();
        
        ac.CloseSubTabs();
		ac.Scrollhome();
		
		log.info("Deleting the Student Program details");
		ac.DeleteCreatedStuProg();
		ac.DeleteAllCreatedStuPayment();
		ac.NavBackToAccount();
		log.info("Deleting the Account details");
		ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
		
		//Creating a Account with Aakash Classroom Program to verify the Confirmation call task creation
		if(CurrURL.contains("--byjusuatfc")) {
		    ac.GetDummyAccount("UATFC");
		}
		else if(CurrURL.contains("--byjusuat")) {
		    ac.GetDummyAccount("UAT");
		}
		else {
		    ac.GetDummyAccount("Prod");
		}
		
		StudentProgPO sp = new StudentProgPO(driver);
		ac.Scrollpagedown();
		ac.ClickStudentPrograms();
        
        sp.ClickNewbutton();
        sp.EnterStudentProgramName(al.get(13));
        sp.EnterStartDate();
        sp.EnterStatus(al.get(14));
        sp.EnterStudentEnrolmentID(al.get(15));
        sp.EnterProgram(al.get(16));
        sp.ClickProgramName();
        sp.ClickSave();
        
        ac.CloseSubTabs();
        
        ac.Scrollpagedown();
        ac.ClickStudentPrograms();
        
        sp.ClickNewbutton();
        sp.EnterStudentProgramName(al.get(13));
        sp.EnterStartDate();
        sp.EnterStatus(al.get(14));
        sp.EnterStudentEnrolmentID(al.get(18));
        sp.EnterProgram(al.get(17));
        sp.ClickProgramName();
        sp.ClickSave();
        
        ac.CloseSubTabs();
        ac.AccountLoadwait();
        ac.RefreshTab();
        
        //Verify the Aakash BYJU'S Hybrid Classroom Program-Confirmation Call task is created
        Assert.assertTrue(ac.CheckCreatedTask("Aakash BYJU'S Hybrid Classroom Program-Confirmation Call"));
        ac.DeleteCreatedStuProg();
       
        ac.DeleteCreatedTask_OpenActivities("Aakash BYJU'S Hybrid Classroom Program-Confirmation Call");
		
      
	}
	
	  @AfterMethod(alwaysRun = true) public void teardown() throws
	  InterruptedException {
	  
	  driver.quit();
	  
	  //Thread.sleep(2000); 
	  }
	 
	
	
}
