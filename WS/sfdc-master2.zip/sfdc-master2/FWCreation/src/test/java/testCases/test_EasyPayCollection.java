package testCases;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import pageObjects.CasesPO;
import pageObjects.CreatedAccountPO;
import pageObjects.InboundTaskPO;
import pageObjects.IssueTreePO;
import pageObjects.NewCaseRecordTypePO;
import pageObjects.loginPO;
import payLoad.payLoad_EasyPay;
import resources.ExcelData;
import resources.base;



public class test_EasyPayCollection extends base {

	public WebDriver driver;
	//public String CurrURL;
	public static Logger log = LogManager.getLogger(test_EasyPayCollection.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	ArrayList<String> al3 = new ArrayList<String>();
	ArrayList<String> al4 = new ArrayList<String>();
	static Faker faker = new Faker();
	static String firstName = faker.name().firstName();
	static String lastName = faker.name().lastName();
	static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);
	
	@BeforeMethod(alwaysRun = true)
	public void initialize() throws IOException, InterruptedException {

		driver = initializeDriver();

	}
	

	@Test(groups = {"sanity", "Regression" },enabled = true)
	public void TestEasyPayCollection() throws Exception {
		String Accountid = null;
		loginPO lo=new loginPO(driver);
		if(CurrURL.contains("--byjusuatfc")) {
			al = excelData.getData("TC1", "EasyPayCollection", "Tcid");
			
			
			log.info("Logging in as Admin to UATFC");
			lo.LoginAsAdmin_UATFC();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_EasyPay.AccountidCreationResponse_UATFC();
			log.info("Launching the newly created Account id "+Accountid);
			
			}
		else if(CurrURL.contains("--byjusuat")) {
		al = excelData.getData("TC1", "EasyPayCollection", "Tcid");
		
		
		log.info("Logging in as Admin to UAT");
		lo.LoginAsAdmin_UAT();
		log.info("Submitting the Account creation payload");
		Accountid=payLoad_EasyPay.AccountidCreationResponse_UAT();
		log.info("Launching the newly created Account id "+Accountid);
		
		}
		else if(CurrURL.contains("--byjusqa")) {
			al = excelData.getData("TC1", "EasyPayCollection", "Tcid");
			//al2 = excelData.getData("Collection Assistant QA", "Login", "Type");
			log.info("Logging in as Admin to QA Env");
			lo.LoginAsAdmin_QA();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_EasyPay.AccountidCreationResponse_QA();
			log.info("Launching the newly created Account id "+Accountid);
		}
		else {
			al = excelData.getData("TC1", "EasyPayCollection", "Tcid");
			//al2 = excelData.getData("Collection Assistant", "Login", "Type");
			log.info("Logging in as Admin to Prod");
			lo.LoginAsAdmin_Prod();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_EasyPay.AccountidCreationResponse_Prod();
			log.info("Launching the newly created Account id "+Accountid);
		}
		
		closeTabWindows();
		CreatedAccountPO ac= new CreatedAccountPO(driver);
		ac.AllNotificationRead();
		ac.NavBackToAccount();
		ac.goTo(CurrURL+Accountid);
		Thread.sleep(5000);
		//Assert.assertTrue(false);
		//String OwnerName=ac.CaptureAccOwnrNam();
		ac.Scrollpagedown();
		
		log.info("Creating Inbound Task");
		ac.ClickOpenActivitiestoNewTask();
		
		NewCaseRecordTypePO ncrt= new NewCaseRecordTypePO(driver);
		
		ncrt.SelectCaseRecordTypeInbound();
		ncrt.ClickNext();
		Thread.sleep(2000);
		ncrt.ClickSave();
		Thread.sleep(2000);
		
		InboundTaskPO ibdt= new InboundTaskPO(driver);
		ibdt.ClickCaptureDetail();
		Thread.sleep(3000);		
		  
		ibdt.ClickProceedOptn();
		if(CurrURL.contains("--byjusuat")||CurrURL.contains("--byjusuatfc")||CurrURL.contains("byjusprod.")) {
			al3 = excelData.getData("Inbound", "Inbound", "Tcid");
			al4 = excelData.getData("TC2", "EasyPayCollection", "Tcid");
			IssueTreePO it=new IssueTreePO(driver);
			if(!CurrURL.contains("--byjusuatfc")) {
			ibdt.SelectSpokeTo3(al3.get(1));
			it.PremiumidSelector();
			it.ProgramSelector();
			it.ClickNext();
			}
			ibdt.SelectPSTCT(al3.get(2));
			//ibdt.EnterNotesVal(al3.get(3));
			ibdt.ClickNext();
			Thread.sleep(2000);
			it.IssueCategory(al4.get(12));
			it.IssueType(al4.get(13));
			it.IssueSubType(al4.get(14));
			it.IssueNotes(al4.get(15));
			it.IstheIssueResolved(al4.get(16));
			it.ClickNext3();
			it.OrderID();
			it.PaymentID();
			it.ClickNext3();
			}
		else {
			ibdt.SelectPSTCT(al.get(1));
			//ibdt.EnterNotesVal(al.get(2));
			ibdt.ClickNext();
			Thread.sleep(2000);
			ibdt.SelectDevice(al.get(3));
			ibdt.SelectCategory(al.get(4));
			ibdt.SelectSubCategory(al.get(10));
			ibdt.SelectIssueSubType(al.get(11));
			ibdt.SelectIsTICR(al.get(8));
			ibdt.EnterComments(al.get(7));
			ibdt.ClickNext();
			Thread.sleep(3000);
		}

		ibdt.NavBackAccount();
		ac.CloseSubTabs();
		ac.Scrollpagedown();
		ac.ClickCasesMC();

		CasesPO cases= new CasesPO(driver);
		
		String CaseNumber= cases.CaseRN();
		log.info("The case number created is: "+CaseNumber);
		//cases.CaseOptnSel();
		//Assert.assertTrue(false);
		cases.CloseAllCases();
		
		log.info("Deleting the Student Program details");
		ac.ClickAccOwnrTab();
		ac.DeleteCreatedStuProg();
		ac.NavBackToAccount();
		log.info("Deleting the Account created details");
		ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());
	}
	
	  @AfterMethod(alwaysRun = true) public void teardown() throws
	  InterruptedException {
	  
	  driver.quit();
	  
	  //Thread.sleep(2000); 
	  }
	 
	
	
}
