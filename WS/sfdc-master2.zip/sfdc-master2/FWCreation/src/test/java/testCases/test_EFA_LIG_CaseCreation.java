package testCases;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import junit.framework.Assert;
import pageObjects.CasesPO;
import pageObjects.CreatedAccountPO;
import pageObjects.EFA_LIG_PO;
import pageObjects.StudentProgPO;
import pageObjects.loginPO;
import payLoad.payLoad_EasyPay;
import resources.ExcelData;
import resources.base;

public class test_EFA_LIG_CaseCreation extends base {

    public WebDriver driver;
    // public String CurrURL;
    public static Logger log = LogManager.getLogger(test_EasyPayCollection.class.getName());
    ExcelData excelData = new ExcelData();
    ArrayList<String> al = new ArrayList<String>();
    ArrayList<String> auditLead1 = new ArrayList<String>();
    static Faker faker = new Faker();
    static String firstName = faker.name().firstName();
    static String lastName = faker.name().lastName();
    static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);

    @BeforeMethod(alwaysRun = true)
    public void initialize() throws IOException, InterruptedException {

        driver = initializeDriver();

    }

    @Test(groups = { "sanity", "Regression" }, enabled = true)
    public void testEFA_LIG_CaseCreation() throws Exception {
        String[] Accountid = null;
        CreatedAccountPO ac = new CreatedAccountPO(driver);
        loginPO lo = new loginPO(driver);
        if (CurrURL.contains("--byjusuat")) {
            al = excelData.getData("TC1", "EFA-LIG", "Tcid");

            log.info("Logging in as Admin to UAT");
            lo.LoginAsAdmin_UAT();
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_EasyPay.AccountidCreationResponse_UAT1();
            log.info("Launching the newly created Account id " + Accountid);

        } else {
            al = excelData.getData("TC1", "EFA-LIG", "Tcid");
            // al2 = excelData.getData("Collection Assistant", "Login", "Type");
            log.info("Logging in as Admin to Prod");
            lo.LoginAsAdmin_Prod();
            log.info("Submitting the Account creation payload");
            Accountid = payLoad_EasyPay.AccountidCreationResponse_UAT1();
            // Accountid = payLoad_EasyPay.AccountidCreationResponse_Prod();
            log.info("Launching the newly created Account id " + Accountid);
        }

        String accURL = CurrURL + Accountid[0];

        // Login as Audit Lead
        auditLead1 = excelData.getData("Audit Lead", "Login", "Type");
        String auditLead = auditLead1.get(1); // "anjitha a"
        lo.SwitchUser(auditLead);
        closeTabWindows();
        ac.goTo(accURL);
        ac.AdditionalWait();
        String accntName = ac.CaptureAccOwnrNam();
        // Go to cases section
        ac.ClickCasesMC2();
        String caseUrl = ac.CaptureURL();
        StudentProgPO sp = new StudentProgPO(driver);
        sp.ClickNewbutton();

        EFA_LIG_PO el = new EFA_LIG_PO(driver);
        el.SelectCaseRecordType(al.get(1));
        el.ClickNext();
        ac.AdditionalWait();
        el.SelectDropdownOption(al.get(2), al.get(3));// ("DP Payment Mode", "Salesperson");
        el.clickSave();
        ac.AdditionalWait();
        // To get the parent case id
        String parentCase = el.parentCaseNumb();
        // To verify the case owner default value
        String caseOwner = el.getEfaLigCaseOwnerDetailsSection();
        Assert.assertEquals(al.get(4), caseOwner);// ("EFA-LIG Queue", caseOwner);
        // To verify the Student account name
        String contactName = el.getEfaLigContactName();
        Assert.assertEquals(accntName, contactName);
        // To verify the order name
        String parentOrder = el.getParentOrder();
        // To verify the case origin default value
        String caseOrigin = el.getEfaLigCaseOrigin();
        Assert.assertEquals(al.get(5), caseOrigin);
        // To verify the subject SSO2123456788013
        String sub = el.getEfaLigSub();
        Assert.assertEquals(al.get(6), sub);// ("EFA-LIG _SSO2ORD16576576788", sub);
        // To verify the default status
        String status = el.getEfaLigStatus();
        Assert.assertEquals(al.get(7), status);// ("Direct Refund Partially Retained", status);
        // To get the App id
        String appIdParent = el.getEfaLigDetailsFields(al.get(8));// ("App Id");
        // To get the loan id
        String loanIdParent = el.getEfaLigDetailsFields(al.get(9));// ("Loan ID");
        // To verify the EP Partner
        String epPartner = el.getEfaLigEPpartner();
        Assert.assertEquals(al.get(10), epPartner);
        // To verify DP to be Refunded? value
        // String dpToBeRefunded = el.getEfaLigDetailsFields("DP to be Refunded?");
        // Assert.assertEquals("No", dpToBeRefunded);
        // To verify LC is Required? value
        String lcIsRequired = el.getEfaLigDetailsFields(al.get(11));// ("LC is Required?");
        Assert.assertEquals(al.get(12), lcIsRequired);
        // To verify Is Product Swappable? value
        String isProductSwappable = el.getEfaLigDetailsFields(al.get(13));// ("Is Product Swappable?");
        Assert.assertEquals(al.get(12), isProductSwappable);
        // To verify DP Payment Mode value
        String dpPaymentMode = el.getEfaLigDetailsFields(al.get(2));// ("DP Payment Mode");
        Assert.assertEquals(al.get(3), dpPaymentMode);
        // To verify 'Sub Reasons For Refund' value
        String subReasonsForRefund = el.getEfaLigDetailsFields(al.get(14));// ("Sub Reasons For Refund");
        Assert.assertEquals(al.get(15), subReasonsForRefund);
        // To verify 'Escalation Category' value
        String escalationCategory = el.getEfaLigDetailsFields(al.get(16));
        Assert.assertEquals(al.get(17), escalationCategory);
        // To verify 'Raised By' value
        String raisedBy = el.getEfaLigDetailsFields(al.get(18));// ("Raised By");
        Assert.assertEquals(al.get(19), raisedBy);
        // To verify 'In SLA' value
        String inSLA = el.getEfaLigDetailsFields(al.get(20));// ("In SLA");
        Assert.assertEquals(al.get(21), inSLA);
        // To verify 'Description' value
        String description = el.getEfaLigDetailsFields(al.get(22));// ("Description");
        Assert.assertEquals(al.get(23), description);
        // To verify 'Loan ID' value
        String loanID = el.getEfaLigDetailsFields(al.get(24));
        Assert.assertEquals(al.get(25), loanID);
        // To verify 'Priority' value
        String priority = el.getEfaLigDetailsFields(al.get(26));
        Assert.assertEquals(al.get(27), priority);

        el.clickEfaLigBtn();
        el.switchToTheFrame();
        el.enterEfaLigActionFields(al.get(28));// ("Total Order Amount");
        el.enterEfaLigActionFields(al.get(29));// ("Total Refund Amount");
        el.enterEfaLigActionFields(al.get(30));// ("Total Amount Retained");
        el.enterEfaLigActionFields(al.get(31));
        // ("CashBack Amount");
        /*
         * el.enterEfaLigActionFields("Classes to be Deactivated");
         * el.enterEfaLigActionFields("Courier Charges to be Refunded");
         * el.selectRetentionTeamProductStatus("Wait for product");
         * el.selectRetentionTeamModeofRetention("Direct Refund Partially Retained");
         */ el.clickEfaLigSave();
        ac.AdditionalWait();
        ac.RefreshTab();
        // To verify 'Total Order Amount' value
        String totalOrderAmount = el.getEfaLigDetailsFields(al.get(28));
        assertTrue(totalOrderAmount.contains(al.get(32)));
        // To verify 'Total Refund Amount' value
        String totalRefundAmount = el.getEfaLigDetailsFields(al.get(29));
        assertTrue(totalRefundAmount.contains(al.get(32)));
        // To verify 'Total Amount Retained' value
        String totalAmountRetained = el.getEfaLigDetailsFields(al.get(30));
        assertTrue(totalAmountRetained.contains(al.get(32)));
        // To verify 'Cashback Amount' value
        String cashbackAmount = el.getEfaLigDetailsFields(al.get(51));
        assertTrue(cashbackAmount.contains(al.get(32)));
        // To verify 'Retention Team Product Status' value
        String retentionTeamProductStatus = el.getEfaLigDetailsFields(al.get(33));// ("Retention Team Product Status");
        Assert.assertEquals(al.get(37), retentionTeamProductStatus);
        // To verify 'Retention Team Mode of Retention' value
        String retentionTeamModeofRetention = el.getEfaLigDetailsFields(al.get(34));// ("Retention Team Mode of
                                                                                    // Retention");
        Assert.assertEquals(al.get(38), retentionTeamModeofRetention);
        // To verify 'Classes To Be Deactivated' value
        String classesToBeDeactivated = el.getEfaLigDetailsFields(al.get(35));
        Assert.assertEquals(al.get(12), classesToBeDeactivated);
        // To verify 'Courier Charges To Be Refunded?' value
        String courierChargesToBeRefunded = el.getEfaLigDetailsFields(al.get(36));// ("Courier Charges To Be
                                                                                  // Refunded?");
        Assert.assertEquals(al.get(12), courierChargesToBeRefunded);

        // Clicking Related cases link
        el.clickRelatedCases();
        el.ClickCaseNewButton();
        el.SelectCaseRecordType(al.get(39));// ("DP To Be Refunded");
        el.ClickNext();
        el.clickSave();

        // To get the subject on child case
        String childSub = el.getChildcaseSubject(al.get(40));// ("DP To be Refunded");
        Assert.assertEquals(al.get(41), childSub);
        // To verify the case owner
        String caseOwnerChild = el.getCaseOwner(al.get(40));
        Assert.assertEquals(al.get(42), caseOwnerChild);
        // To get the parent case id on the child case
        String parentCaseId = el.getChildCaseLinkDetails(al.get(40), al.get(43));
        Assert.assertEquals(parentCase, parentCaseId);
        // To verify the contact name on child case
        String contactNameChild = el.getChildCaseLinkDetails(al.get(40), al.get(44));
        Assert.assertEquals(contactName, contactNameChild);
        // To verify the order name on child case
        String order = el.getChildCaseLinkDetails(al.get(40), al.get(45));
        Assert.assertEquals(parentOrder, order);
        // To verify the App id
        String appIdChild = el.getChildCaseDeatils(al.get(8));
        Assert.assertEquals(appIdParent, appIdChild);
        // To verify the loan id
        String loanIdChild = el.getChildCaseDeatils(al.get(9));
        Assert.assertEquals(loanIdParent, loanIdChild);
        // To verify the loan id
        String partnerChild = el.getChildCaseDeatils(al.get(46));
        Assert.assertEquals(epPartner, partnerChild);

        el.clickChildCaseLinkDetails(al.get(43));
        // Clicking Related cases link
        el.clickRelatedCases();
        el.ClickCaseNewButton();
        el.SelectCaseRecordType(al.get(47));// ("Order To Be Re-Punched");
        el.ClickNext();
        el.clickSave();

        // To get the subject on child case
        childSub = el.getChildcaseSubject(al.get(48));// ("Order to be Repunched");
        Assert.assertEquals(al.get(49), childSub);
        // To verify the case owner
        caseOwnerChild = el.getCaseOwner(al.get(48));
        Assert.assertEquals(al.get(50), caseOwnerChild);
        // To get the parent case id on the child case
        parentCaseId = el.getChildCaseLinkDetails(al.get(48), al.get(43));
        Assert.assertEquals(parentCase, parentCaseId);
        // To verify the contact name on child case
        contactNameChild = el.getChildCaseLinkDetails(al.get(48), al.get(44));
        Assert.assertEquals(contactName, contactNameChild);
        // To verify the order name on child case
        order = el.getChildCaseLinkDetails(al.get(48), al.get(45));
        Assert.assertEquals(parentOrder, order);
        // To verify the App id
        appIdChild = el.getChildCaseDeatils(al.get(8));
        Assert.assertEquals(appIdParent, appIdChild);
        // To verify the loan id
        loanIdChild = el.getChildCaseDeatils(al.get(9));
        Assert.assertEquals(loanIdParent, loanIdChild);
        // To verify the loan id
        partnerChild = el.getChildCaseDeatils(al.get(46));// ("EP Partner");
        Assert.assertEquals(epPartner, partnerChild);
        lo.Logouthome();

        ac.closeTabWindows();
        ac.goTo(caseUrl);
        // deleting cases
        log.info("Deleting the created Case Record ");
        CasesPO cases = new CasesPO(driver);
        cases.CloseAllCases();
        log.info("Deleting the Student Program details");
        ac.goTo(accURL);
        ac.AdditionalWait();
        ac.Scrollpagedown();
        ac.DeleteCreatedStuProg();
        ac.DeleteAllCreatedStuPayment();
        ac.NavBackToAccount();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());

    }

    @AfterMethod(alwaysRun = true)
    public void teardown() throws InterruptedException {

        driver.quit();

        // Thread.sleep(2000);
    }

}
