package testCases;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import pageObjects.CreatedAccountPO;
import pageObjects.OpenActivitiesPO;
import pageObjects.PEOnBoardingTaskPO;
import pageObjects.PEShippedTaskPO;
import pageObjects.StudentProgPO;
import pageObjects.StudentSubOrderPO;
import pageObjects.loginPO;
import payLoad.payLoad_SinglePrgm;
import resources.ExcelData;
import resources.base;



public class test_TrialEpic extends base {

	public WebDriver driver;
	//public String CurrURL;
	public static Logger log = LogManager.getLogger(test_TrialEpic.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> proddummyuser = new ArrayList<String>();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	ArrayList<String> al3 = new ArrayList<String>();
	static Faker faker = new Faker();
	static String firstName = faker.name().firstName();
	static String lastName = faker.name().lastName();
	static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);
	
	@BeforeMethod(alwaysRun = true)
	public void initialize() throws IOException, InterruptedException {

		driver = initializeDriver();

	}
	
	
	@Test(groups = {"sanity", "UAT" }, enabled = false)
	public void TestTrail_HomeTuitionsPremium() throws Exception {
	    proddummyuser = excelData.getData("TC1", "ProdDummyUser", "Tcid");
		String Accountid = null;
		loginPO lo=new loginPO(driver);
		
		if(CurrURL.contains("--byjusuatfc")) {
			al = excelData.getData("Trial Home Tuitions Premium", "Picklist", "Tcid");
			//al2 = excelData.getData("Collection Assistant QA", "Login", "Type");
			log.info("Logging in as Admin to UATFC Env");
			lo.LoginAsAdmin_UATFC();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_SinglePrgm.AccountidCreationResponse_UATFC(al.get(1), al.get(2), al.get(3), al.get(4));
			log.info("Launching the newly created Account id "+Accountid);
		}
		else if(CurrURL.contains("--byjusuat")) {
			al = excelData.getData("Trial Home Tuitions Premium", "Picklist", "Tcid");
		//al2 = excelData.getData("Collection Assistant", "Login", "Type");
		
		log.info("Logging in as Admin to UAT");
		lo.LoginAsAdmin_UAT();
		log.info("Submitting the Account creation payload");
		Accountid=payLoad_SinglePrgm.AccountidCreationResponse_UAT(al.get(1), al.get(2), al.get(3), al.get(4));
		log.info("Launching the newly created Account id "+Accountid);
		
		}
		else {
			al = excelData.getData("Trial Home Tuitions Premium", "Picklist", "Tcid");
			//al2 = excelData.getData("Collection Assistant", "Login", "Type");
			log.info("Logging in as Admin to Prod");
			lo.LoginAsAdmin_Prod();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_SinglePrgm.AccountidCreationResponse_Prod(al.get(1), al.get(2), al.get(3), al.get(4));
			log.info("Launching the newly created Account id "+Accountid);
		}
        
        CreatedAccountPO ac=new CreatedAccountPO(driver);
        //Open the account by searching PID
        ac.closeTabWindows();
        ac.Notification();
        ac.NavBackToAccount();
        String AccountURL = CurrURL+Accountid;
        ac.goTo(CurrURL+Accountid);
        ac.AccountLoadwait();
        
        al2 = excelData.getData("PE User UAT", "Login", "Type");
        //Logging in as PE
        if(CurrURL.contains("--byjusuat")||CurrURL.contains("--byjusuatfc")) {
            String AccountOwner= ac.AccOwnerCheck();
            if(!al2.get(1).equalsIgnoreCase(AccountOwner)) {
                ac.AssignAccount(al2.get(1));
            }
        }
        else {
            ac.AssignAccount("Testing User");
        }       
        String MainWin = driver.getWindowHandle();
        String AccountOwner = ac.CaptureAccOwnerNam();
        
        //Setting  SSO to Shipped status
        log.info("Navigating to Student sales order");
        
        StudentSubOrderPO Ssub=new StudentSubOrderPO(driver);
        ac.ClickStudentSalesOrder();
        Ssub.ClickOrderinOrders();
        Ssub.SelectStatus("Shipped");
        Ssub.ClickSave();
        ac.CloseSubTabs();
        
        if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
            lo.SwitchUser(al2.get(1));
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AccountLoadwait();   
            }
            else if(CurrURL.contains("--byjusuatfc")) {
                lo.SwitchUser(al2.get(1));
                ac.closeTabWindows();
                ac.Notification();
                ac.NavBackToAccount();
                ac.goTo(AccountURL);
                ac.AccountLoadwait();

            }
            else {
                lo.SwitchUsernProfile_Prod(proddummyuser.get(1),"PE");
                ac.closeTabWindows();
                ac.Notification();
                ac.NavBackToAccount();
                ac.goTo(AccountURL);
                ac.AccountLoadwait();
            }
            
        //Navigating to PE-Shipped Call
        ac.Scrollpagedown();
        
        //Verify the PE Shipped all is created
        Assert.assertTrue(ac.CheckVisPEShippedCall());
          
        log.info("Navigating to PE Shipped Call tasks");
        ac.ClickPEShipped();
        
        al = excelData.getData("TC1", "Neo", "Tcid");
        PEShippedTaskPO pes=new PEShippedTaskPO(driver);
        Assert.assertEquals(pes.CapturePEShippedAssigned(),AccountOwner);
        //Assert.assertEquals(pes.CaptureDueDate(), pes.DateCompare(3));
        pes.ClickCaptureDetail();
        log.info("Selecting Capture Call as Proceed for PE Shipped Task");
        pes.SelectProceed_iframe();
        pes.SelectProceedIAFO(al.get(1));
        pes.SelectProceedDOBA(al.get(2));
        pes.SelectProceedLP(al.get(3));
        pes.SelectProceedRFP(al.get(4));
        pes.SelectProceedPCOS(al.get(5));
        pes.SelectProceedCE(al.get(6));
        pes.SelectProceedST(al.get(7));
        pes.SelectProceedWOIS(al.get(12));
        pes.SelectProceedNotes(al.get(13));
        pes.SelectProceedIsThereIssue(al.get(20));
        ac.CloseSubTabs();
        
      //Login back as Admin to delete open PE - Shipped calls and Status change of SSO to Delivered for PE onboarding
        lo.OnlyLogout();
        ac.CloseWindowArrayLast();
        driver.switchTo().window(MainWin);
        ac.goTo(AccountURL);
        ac.AccountLoadwait();
        
        log.info("Navigating to Student sales order");
        
        ac.ClickStudentSalesOrder();
        Assert.assertTrue(ac.CheckExistingProfile());//Added check for SFTNL-6458
        Ssub.ClickOrderinOrders();
        Ssub.SelectSSOStatus();
        Ssub.ClickSave();
        ac.CloseSubTabs();
        
        //Logging back as PE to perform PE - Onboarding
        if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
        lo.SwitchUser(al2.get(1));
        ac.closeTabWindows();
        ac.Notification();
        ac.NavBackToAccount();
        ac.goTo(AccountURL);
        ac.AccountLoadwait();   
        }
        else if(CurrURL.contains("--byjusuatfc")) {
            lo.SwitchUser(al2.get(1));
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AccountLoadwait();

        }
        else {
            lo.SwitchUsernProfile_Prod(proddummyuser.get(1),"PE");
            ac.closeTabWindows();
            ac.Notification();
            ac.NavBackToAccount();
            ac.goTo(AccountURL);
            ac.AccountLoadwait();
        }
        
        log.info("Navigating to PE On boarding Call tasks");
        //Verify PE Onboarding call task is created when the SSO status moved to Partial delivered/delivered
        Assert.assertTrue(ac.CheckVisPEOnboardingCall());
        //ac.CloseSubTabs();
        ac.ClickPEOnboardngCall();
        
        
        PEOnBoardingTaskPO peob=new PEOnBoardingTaskPO(driver);
        Assert.assertEquals(peob.CapturePEOnboardingAssigned(),AccountOwner);
        //Assert.assertEquals(peob.CaptureDueDate(), peob.DateCompare(3));
        peob.ClickCaptureDetail();
        log.info("Selecting Capture Call as Proceed for PE Onboarding Task");
        peob.SelectProceed_iframe();
        //peob.ClickOnboardingScreenNext();
        peob.SelectProceedST(al.get(66));
        peob.SelectProceedSAU(al.get(67));
        peob.SelectProceedNotes(al.get(68));
        //peob.ClickNext();
        peob.SelectProceedIsThereIssue2(al.get(45));
        ac.AdditionalWait();
        ac.CloseSubTabs();
				
        lo.OnlyLogout();
        ac.CloseWindowArrayLast();
        driver.switchTo().window(MainWin);
        ac.goTo(AccountURL);
        ac.AccountLoadwait();
        
		log.info("Deleting the Student Program details");
		ac.Scrollpagedown();
		ac.DeleteCreatedStuProg();
		ac.DeleteAllCreatedStuPayment();
		ac.NavBackToAccount();
		log.info("Deleting the Account created details");
		ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());	
		
	    //Navigating to Dummy account
        if(CurrURL.contains("--byjusuatfc")) {
            ac.GetDummyAccount("UATFC");
        }
        else if(CurrURL.contains("--byjusuat")) {
            ac.GetDummyAccount("UAT");
        }
        else {
            ac.GetDummyAccount("Prod");
        }
        al3 = excelData.getData("TC01", "Trial", "Tcid");
        StudentProgPO sp = new StudentProgPO(driver);
        ac.Scrollpagedown();
        ac.ClickStudentPrograms();
        
        sp.ClickNewbutton();
        sp.EnterStudentProgramName(al3.get(5));
        if(CurrURL.contains("byjusprod.")) {
            sp.EnterStartDate();
        }
        else {
        sp.EnterStartDate_dmy();
        }
        sp.EnterStatus(al3.get(6));
        sp.EnterStudentEnrolmentID(al3.get(7));
        sp.SelectProductType2("Paid");
        sp.SelectClass_ProgramType("Premium");
        sp.EnterProgram(al3.get(8));
        sp.ClickProgramName();
        sp.ClickSave();
        
        ac.CloseSubTabs();
        ac.AdditionalWait();
        ac.RefreshTab();
        
        //Verify the BYJU’S Home Tuitions-Confirmation Call task is created
        Assert.assertTrue(ac.CheckCreatedTask("BYJU’S Home Tuitions-Confirmation Call"));
        ac.DeleteCreatedStuProg();
       
        ac.DeleteCreatedTask_OpenActivities("BYJU’S Home Tuitions-Confirmation Call");
        
		
	}
	
	   @Test(groups = {"sanity", "UAT" }, enabled = true)
	    public void TestTrail_HomeTuitionsTrial() throws Exception {
	        String Accountid = null;
	        loginPO lo=new loginPO(driver);
	        
	        if(CurrURL.contains("--byjusuatfc")) {
	            al = excelData.getData("Trial Home Tuitions Trial", "Picklist", "Tcid");
	            //al2 = excelData.getData("Collection Assistant QA", "Login", "Type");
	            log.info("Logging in as Admin to UATFC Env");
	            lo.LoginAsAdmin_UATFC();
	            log.info("Submitting the Account creation payload");
	            Accountid=payLoad_SinglePrgm.AccountidCreationResponse_UATFC(al.get(1), al.get(2), al.get(3), al.get(4));
	            log.info("Launching the newly created Account id "+Accountid);
	        }
	        else if(CurrURL.contains("--byjusuat")) {
	            al = excelData.getData("Trial Home Tuitions Trial", "Picklist", "Tcid");
	        //al2 = excelData.getData("Collection Assistant", "Login", "Type");
	        
	        log.info("Logging in as Admin to UAT");
	        lo.LoginAsAdmin_UAT();
	        log.info("Submitting the Account creation payload");
	        Accountid=payLoad_SinglePrgm.AccountidCreationResponse_UAT(al.get(1), al.get(2), al.get(3), al.get(4));
	        log.info("Launching the newly created Account id "+Accountid);
	        
	        }
	        else {
	            al = excelData.getData("Trial Home Tuitions Trial", "Picklist", "Tcid");
	            //al2 = excelData.getData("Collection Assistant", "Login", "Type");
	            log.info("Logging in as Admin to Prod");
	            lo.LoginAsAdmin_Prod();
	            log.info("Submitting the Account creation payload");
	            Accountid=payLoad_SinglePrgm.AccountidCreationResponse_Prod(al.get(1), al.get(2), al.get(3), al.get(4));
	            log.info("Launching the newly created Account id "+Accountid);
	        }
	        
	        CreatedAccountPO ac=new CreatedAccountPO(driver);
	        //Open the account by searching PID
	        ac.closeTabWindows();
	        ac.Notification();
	        ac.NavBackToAccount();
	        String AccountURL = CurrURL+Accountid;
	        ac.goTo(AccountURL);
	        ac.AccountLoadwait();
	               
	        //Setting  SSO to Shipped status
	        log.info("Navigating to Student sales order");
	        
	        StudentSubOrderPO Ssub=new StudentSubOrderPO(driver);
	        ac.ClickStudentSalesOrder();
	        Ssub.ClickOrderinOrders();
	        Ssub.SelectStatus("Shipped");
	        Ssub.ClickSave();

	        //Now changing the status to Delivered
	        
	        Ssub.SelectSSOStatus();
	        Ssub.ClickSave();
	        ac.CloseSubTabs();
	        
	        ac.ClickOpenActivities();
	        
	        OpenActivitiesPO oa= new OpenActivitiesPO(driver);
	        String[] RecordCount= oa.RecrdCnt();
	        ac.AdditionalWait();
	        int i=0;
	        try {
	        i = Integer.parseInt(RecordCount[0]);
	        }
	        catch(NumberFormatException ex) {
	            ex.printStackTrace();
	        }
	        
	        //Verifying no tasks are created
	        Assert.assertEquals(i, 0);
	        ac.CloseSubTabs();
	        
	        log.info("Deleting the Student Program details");
	        ac.ClickAccOwnrTab();
	        ac.DeleteCreatedStuProg();
	        ac.DeleteAllCreatedStuPayment();
	        ac.NavBackToAccount();
	        log.info("Deleting the Account created details");
	        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());        
	        
	    }
		
	
	  @AfterMethod(alwaysRun = true) public void teardown() throws
	  InterruptedException {
	  
	  driver.quit();
	  
	  //Thread.sleep(2000); 
	  }
	 
	
	
}
