package testCases;

import java.io.IOException;

import java.util.ArrayList;

import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.openqa.selenium.WebDriver;

import org.testng.annotations.AfterMethod;

import org.testng.annotations.BeforeMethod;

import org.testng.annotations.Test;


import com.github.javafaker.Faker;

import org.testng.Assert;


import pageObjects.CasesPO;

import pageObjects.CreatedAccountPO;
import pageObjects.CreatedCaseRecordPO;
import pageObjects.GmailPO;
import pageObjects.InboundTaskPO;
import pageObjects.IssueTreePO;

import pageObjects.NewCaseRecordTypePO;
import pageObjects.Retention1stCallPO;
import pageObjects.loginPO;

import payLoad.payLoad_ByjusWallet;
import payLoad.payLoad_SinglePrgm;
import resources.ExcelData;
import resources.base;



public class test_ByjusWallet extends base {

	public WebDriver driver;
	//public String CurrURL;
	public static Logger log = LogManager.getLogger(test_ByjusWallet.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> proddummyuser = new ArrayList<String>();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	ArrayList<String> al3 = new ArrayList<String>();
	ArrayList<String> al4 = new ArrayList<String>();
	ArrayList<String> al5 = new ArrayList<String>();
	ArrayList<String> al6 = new ArrayList<String>();
	static Faker faker = new Faker();
	static String firstName = faker.name().firstName();
	static String lastName = faker.name().lastName();
	static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);
	
	@BeforeMethod(alwaysRun = true)
	public void initialize() throws IOException, InterruptedException {

		driver = initializeDriver();

	}
	

	@Test(groups = {"sanity", "Regression" },enabled = true)
	public void TestByjusWallet() throws Exception {
	    proddummyuser = excelData.getData("TC1", "ProdDummyUser", "Tcid");
		String Accountid = null;
		loginPO lo=new loginPO(driver);
		al5 = excelData.getData("SFEmail", "Login", "Tcid");
		if(CurrURL.contains("--byjusuatfc")) {
			al = excelData.getData("TC1", "ByjuWallet", "Tcid");
			
			
			
			log.info("Logging in as Admin to UATFC");
			lo.LoginAsAdmin_UATFC();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_ByjusWallet.AccountidCreationResponse_UATFC();
			log.info("Launching the newly created Account id "+Accountid);
			
			}
		else if(CurrURL.contains("--byjusuat")) {
		al = excelData.getData("TC1", "ByjuWallet", "Tcid");
		al6 = excelData.getData("Hybrid Tuitions at BYJU'S Learning Center", "Picklist", "Tcid");
		
		log.info("Logging in as Admin to UAT");
		lo.LoginAsAdmin_UAT();
		log.info("Submitting the Account creation payload");
		Accountid=payLoad_SinglePrgm.AccountidCreationResponse_UAT(al6.get(1), al6.get(2), al6.get(3), al6.get(4));
		log.info("Launching the newly created Account id "+Accountid);
		
		}
		else if(CurrURL.contains("--byjusqa")) {
			al = excelData.getData("TC1", "ByjuWallet", "Tcid");
			//al2 = excelData.getData("Collection Assistant QA", "Login", "Type");
			log.info("Logging in as Admin to QA Env");
			lo.LoginAsAdmin_QA();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_ByjusWallet.AccountidCreationResponse_QA();
			log.info("Launching the newly created Account id "+Accountid);
		}
		else {
			al = excelData.getData("TC1", "ByjuWallet", "Tcid");
			//al2 = excelData.getData("Collection Assistant", "Login", "Type");
			log.info("Logging in as Admin to Prod");
			lo.LoginAsAdmin_Prod();
			log.info("Submitting the Account creation payload");
			Accountid=payLoad_ByjusWallet.AccountidCreationResponse_Prod();
			log.info("Launching the newly created Account id "+Accountid);
		}
		
		closeTabWindows();
		CreatedAccountPO ac= new CreatedAccountPO(driver);
		ac.Notification();
		ac.NavBackToAccount();
		String AccountURL=CurrURL+Accountid;
		ac.goTo(CurrURL+Accountid);
		ac.AccountLoadwait();


		//Changing the email address of account
		ac.EditAccount();
		ac.UpdateStudentEmailid(al5.get(1));
		ac.UpdateEmail(al5.get(1));
		ac.ClickSave();
		
		
		String AccountOwner= ac.CaptureAccOwnrNam();
		//Verify Account is created with Student order,Student Payment in it
		
		if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
			
			Assert.assertTrue(ac.CheckVisSalesStudentOrderid());
			ac.CaptureStudentSalesOrder();	
		}
		else {
		//Assert.assertTrue(ac.CheckVisStudentOrderid());
		//ac.CaptureStudentOrder();
		Assert.assertTrue(ac.CheckVisSalesStudentOrderid());
		ac.CaptureStudentSalesOrder();	
		//ac.CaptureStudentOrderIndvid();
		}
		String OwnerName=ac.CaptureAccOwnrNam();
		Assert.assertTrue(ac.CheckVisStudentPayid());
		ac.CaptureAllStudentPayid();
		ac.CheckVisStudentPrgid();
		ac.CaptureAllStudentProgDetails();		
		
		
		log.info("Creating Inbound Task");
		ac.ClickOpenActivitiestoNewTask();
		
		NewCaseRecordTypePO ncrt= new NewCaseRecordTypePO(driver);
		
		ncrt.SelectCaseRecordTypeInbound();
		ncrt.ClickNext();
		ac.AdditionalWait();
		
		ncrt.ClickSave();
		ac.AdditionalWait();
		
		InboundTaskPO ibdt= new InboundTaskPO(driver);
		ibdt.ClickCaptureDetail();
		Thread.sleep(3000);		
		  
		ibdt.ClickProceedOptn();
		if(CurrURL.contains("--byjusuat")||CurrURL.contains("--byjusuatfc")||CurrURL.contains("byjusprod.")) {
		al3 = excelData.getData("Inbound", "Inbound", "Tcid");
		al4 = excelData.getData("TC3", "RefundProcess", "Tcid");
		IssueTreePO it=new IssueTreePO(driver);
		//ibdt.SelectSpokeTo3(al.get(1));
		if(!CurrURL.contains("--byjusuatfc")) {
		ibdt.SelectSpokeTo3(al3.get(1));
		it.PremiumidSelector();
		it.ProgramSelector();
		it.ClickNext();
		}
		ibdt.SelectPSTCT(al3.get(2));
		//ibdt.EnterNotesVal(al3.get(3));
		ibdt.ClickNext();
		ac.AdditionalWait();
		it.IssueCategory(al4.get(13));
		it.Reason(al4.get(14));
		it.SubReason(al4.get(15));
		it.IssueNotes(al4.get(16));
		it.IstheIssueResolved(al4.get(17));
		it.ClickNext2();
		it.SSOandAccCombo();
		it.ClickFinish();
		}
		else {
			ibdt.SelectPSTCT(al.get(1));
			//ibdt.EnterNotesVal(al.get(2));
			ibdt.ClickNext();
			ac.AdditionalWait();	
			ibdt.SelectDevice(al.get(3));
			ibdt.SelectCategory(al.get(4));
			ibdt.SelectPSTRR(al.get(5));
			ibdt.SelectPSSTRR(al.get(6));
			ibdt.EnterComments(al.get(7));
			ibdt.SelectIsTICR(al.get(8));
			ibdt.SelectPSTO();
			Thread.sleep(1000);
			ibdt.ClickNext();
			Thread.sleep(3000);
		}
		
		//---------picking from here
		ibdt.NavBackAccount();
		ac.CloseSubTabs();
		
		if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
			ac.ClickCasesMC2();
		}
		else {
		    ac.ClickCasesMC2();
		}
		CasesPO cases= new CasesPO(driver);
		
		String CaseNumber= cases.CaseRN();
		log.info("The case number created is: "+CaseNumber);
		cases.CaseOptnSel();
		
		//Logging in as Retention
        if(CurrURL.contains("--byjusuatfc")||CurrURL.contains("--byjusuat")) {
          al2 = excelData.getData("Retention User UAT", "Login", "Type");
          lo.SwitchUser(al2.get(1));
          ac.closeTabWindows();
          ac.Notification();
          ac.goTo(AccountURL);
          ac.AccountLoadwait();
        }
        else if(CurrURL.contains("byjusprod.")) {
          lo.SwitchUsernProfile_Prod(proddummyuser.get(1),"Retention Manager");
          ac.closeTabWindows();
          ac.Notification();
          ac.goTo(AccountURL);
          ac.AccountLoadwait();
        }
        
        String Mainwin= driver.getWindowHandle();
        ac.ClickCasesMC2();
        cases.CaseOptnSel();
        
		CreatedCaseRecordPO ccr= new CreatedCaseRecordPO(driver);
		if(CurrURL.contains("byjusprod.")) {
			ccr.CaseOwnrUpdate_Prod("Testing User");
			ac.Scrollpagedown();
            ac.Scrollpagedown();
            ac.Scrollend();
		     cases.ClickRetentionFirstCall();
		}
		else {
		    ccr.CaseOwnrUpdate_Prod(al2.get(1));
		    ac.AdditionalWait();
		    ac.Scrollpagedown();
		    ac.Scrollpagedown();
		    ac.Scrollend();
		    cases.ClickRetentionFirstCall();
		}

		log.info("Marking the Initial call as Complete");
		Retention1stCallPO rfc=new Retention1stCallPO(driver);
		rfc.EnterCompletedcall();
		rfc.ClickSave();
		
		ibdt.NavToCase();
		//ac.CloseSubTabs();
		//ac.ClickCasesMC2();
		//cases.CaseOptnSel();
		
		log.info("Capturing Retention Details");
		
		ccr.ClickCaptureRetentnDetail();
		if(CurrURL.contains("byjusprod.") ||CurrURL.contains("--byjusuatfc")||CurrURL.contains("--byjusuat")) {
		ccr.EnterEscalationCategory(al.get(44));
		ccr.EnterReasonfrRefund(al.get(9));
		}
		else {
		//ccr.EnterReasonfrRefund_UAT(al.get(9));
		}
		ccr.EnterSubReasonfrRefund(al.get(10));
		ccr.EnterRRNotes(al.get(11));
		ccr.EnterModeORetentn(al.get(12));
		ccr.EnterRTSE(al.get(13));
		ccr.EnterRTSR(al.get(14));
		ccr.Selectorder();
		if(CurrURL.contains("--byjusuat")) {
		 ccr.EnterDeactivateClasses(al.get(64));   
		}
		else {
		ccr.EnterClsTBD(al.get(15));
		}
		ccr.EnterTTBR(al.get(16));
		ccr.EnterLTBC(al.get(17));
		ccr.EnterDPTBRefunBnk(al.get(18));
		ccr.EnterDPTBRefunWall(al.get(19));
		ccr.EnterDPRefunWallAmt(al.get(20));
		ccr.EnterDPBBP(al.get(21));
		ccr.EnterOATBRefunBnk(al.get(22));
		ccr.EnterOATBRefunWall(al.get(23));
		//ccr.EnterORefunWallAmt(al.get(24));
		ccr.SelectTypeOfOtherAmount(al.get(45));
		//ccr.EnterOBBP(al.get(25));
		ccr.EnterCashbackAmountIncluded(al.get(46));
		ccr.EnterOtherAmountBank(al.get(47));
		//ccr.EnterCCTBRefunded(al.get(26));
		ccr.EnterATBRefunded(al.get(27));
		ccr.EnterARetained(al.get(28));
		ccr.SelectCWTGFOSP(al.get(29));
		ccr.SelectOTBReP(al.get(30));
		ccr.SelectCPTBReP(al.get(31));
		ccr.SelectBTBR(al.get(32));
		ccr.SelectRTPS(al.get(33));
		ccr.EnterRTPSNotes(al.get(34));
		ccr.SelectOwner(OwnerName);
		ccr.EnterSPFES(al.get(35));
		ccr.EnterGTBP(al.get(36));
		ccr.EnterClsTBReP(al.get(37));
		ccr.EnterAmount(al.get(38));
		ccr.EnterOtherPD(al.get(39));
		ccr.EnterCompliGTBP(al.get(36));
		ccr.EnterCompliClsTBReP(al.get(37));
		ccr.SelectAFBD(al.get(40));
		ccr.SelectDYWTSTASTTCProd(al.get(41));
		ccr.SelectCOAForm(al.get(42));
		
		if(CurrURL.contains("byjusprod.") ||CurrURL.contains("--byjusuatfc")||CurrURL.contains("--byjusuat")) {
		lo.OnlyLogout();
		}

		//Navigating back to account
		ac.goTo(AccountURL);
		ac.AccountLoadwait();
		
		ac.ClickAccOwnrTab2(AccountOwner);
		
		ac.CloseSubTabs();
		ac.ClickCasesMC2();
		ac.RefreshTab();
		
		cases.CheckInwardTeamUpdate();
		String CaseNumberfrInwardTeamUpdate= cases.CaptureCaseNoInwardTeamUpdate();
        log.info("The Case number created for Inward Team Update is: "+CaseNumberfrInwardTeamUpdate);
        
        
        Assert.assertEquals(cases.CaptureStatus(), "Waiting For Product");
		
		//Login to Gmail
        GmailPO gm= new GmailPO(driver);
        
        gm.LoginGmail(al5.get(1),al5.get(2));
        String SecondWin = driver.getWindowHandle();
        
        if(CurrURL.contains("byjusprod.")) {
        gm.CheckMailRecieved_Prod("cancellation@byjus.com");
        gm.VerifyNoMailfromByjus_Prod("cancellation@byjus.com");
        //gm.CheckMailRecieved("cancellations@byjus.com");
        //gm.SelectShippmentDetailsmail();
        //gm.Clickshipmentdetailslink();
        //gm.EnterShipmentID(al.get(62));
        //gm.EnterShipmentPartner(al.get(63));
        //gm.EnterDateofShipment();
        ///gm.EnterRemarks(al.get(53));
        //gm.ClickSubmit();
        //ac.CloseWindowArrayLast();
       // driver.switchTo().window(SecondWin);
       // gm.ClickInboxnRefresh();
        }
        else {
        //gm.CheckMailRecieved("support@byjus.com");
        //lo.RefreshURL();
        //gm.VerifyNoMailfromByjus("support@byjus.com");
        gm.CheckMailRecieved("cancellations@byjus.com");
        gm.SelectShippmentDetailsmail();
        gm.Clickshipmentdetailslink();
        gm.EnterShipmentID(al.get(62));
        gm.EnterShipmentPartner(al.get(63));
        gm.EnterDateofShipment();
        gm.EnterRemarks(al.get(53));
        gm.ClickSubmit();
        ac.CloseWindowArrayLast();
        driver.switchTo().window(SecondWin);
        gm.ClickInboxnRefresh();
        }
        
        
        if(CurrURL.contains("byjusprod.")) {
            gm.CheckMailRecieved("cancellation@byjus.com");
            gm.NavtoBankForm_Prod("cancellation@byjus.com");
        }
        else if(CurrURL.contains("--byjusuatfc")) {
            gm.CheckMailRecieved("cancellation@byjus.com"); 
        }
        else {
        gm.CheckMailRecieved("cancellationtest3@gmail.com");
        gm.NavtoBankForm("cancellationtest3@gmail.com");
        }
        
        //String ThirdWin = driver.getWindowHandle();
        
        if(CurrURL.contains("byjusprod.")||CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
        gm.EnterAccountHoldersName(AccountOwner);
        gm.EnterAccountNumber(al.get(49));
        gm.EnterConfirmAccountNumber(al.get(50));
        gm.EnterBankName(al.get(51));
        gm.EnterIFSCCode(al.get(52));
        gm.EnterRemarks(al.get(53));
        gm.UploadFiles();
        //driver.switchTo().window(ThirdWin);
        gm.ClickSubmit();
        ac.CloseWindowArrayLast();
        driver.switchTo().window(SecondWin);
        gm.ClickInboxnRefresh();
        }
        

        if(CurrURL.contains("--byjusuatfc")||CurrURL.contains("byjusprod.")) {
            gm.DeleteMailfromByjus("cancellation@byjus.com");
            //gm.VerifyNoMailfromByjus("cancellations@byjus.com");
        }
        else {
        gm.DeleteMailfromByjus("cancellationtest3@gmail.com");
        gm.VerifyNoMailfromByjus("cancellations@byjus.com");
        }
        
        if(CurrURL.contains("byjusprod.")) {
        gm.ClickInboxnRefresh();
        gm.DeleteTestUserMail();
        }
        
        //Changing Status of Inward Case Product Received to trigger email
        driver.switchTo().window(Mainwin);
        if(CurrURL.contains("--byjusuat")){
        ac.AdditionalWait();
        lo.RefreshURL();
        Assert.assertEquals(cases.CaptureStatus(), "Working");
        cases.ChangeStatusValue("Product Received");
        cases.ClickSave();
        ac.AdditionalWait();
        }
        else {
            cases.ChangeStatusValue("Product Received");
            cases.ClickSave();
            ac.AdditionalWait();
        }
        
        ac.CloseCurrentSubTab();
		
		//Verifying the DP amount to be refunded and Other amount to be refunded cases 
        ac.RefreshTab();
		cases.CheckDPRefdWall();
		
		String CaseNumberfrDP= cases.CaptureCaseNoDP();
		log.info("The Case number created for DP to be Refunded to Wallet is: "+CaseNumberfrDP);
		
		String Owner= cases.CaptureCaseOwnerDP();
		Assert.assertTrue(Owner.contains("Process"));
		
		String ParentCase= cases.CaptureParentCaseOwnerDP();
		Assert.assertTrue(ParentCase.equalsIgnoreCase(CaseNumber));// Added as a part of SFTNL-6558
		ac.CloseCurrentSubTab();
		
		cases.NavCasesTab();
		
		
		if(CurrURL.contains("byjusprod.")||CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
		cases.CheckOARefBank();
		
		String CaseNumberfrOA= cases.CaptureCaseNoOA();
		log.info("The Case number created for Other Amount To Be Refunded To Bank is: "+CaseNumberfrOA);
		
		ac.AdditionalWait();
		
		String CaseStatus= cases.CaptureStatus();
		Assert.assertEquals(CaseStatus,"Bank Detail Received");
		}
		
		//String MainWin = driver.getWindowHandle();
        
       // driver.switchTo().window(MainWin);
        cases.NavCasesTab();
		cases.RefreshCurrentTab();
		ac.AdditionalWait();
		cases.CloseAllCases();
		
		log.info("Deleting the Student Program details");
		ac.ClickAccOwnrTab();
		ac.DeleteCreatedStuProg();
		ac.DeleteAllCreatedStuPayment();
		ac.NavBackToAccount();
		log.info("Deleting the Account created details");
		ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());

		if(CurrURL.contains("--byjusuatfc")||CurrURL.contains("byjusprod.")) {
		log.info("Deleting the Cases present as My Cases");
		Thread.sleep(1000);
		cases.NavMenuClick();
		cases.CaseNavMenuClick();
		cases.NavNEOL2QueueProd();
		cases.FilterbyMyCases();
		String FilterText = cases.CaptureFilterText();
		Assert.assertTrue(FilterText.contains("Filtered by My cases"));
		cases.DeleteAllMyCaseRecord();
		cases.SetBackDefault();
		}
		
		 
		driver.switchTo().window(SecondWin);
		//gm.DeleteAcknowledgementReceiptShippmentDetailsmail();
		gm.DeleteAllMails();
		
		
	}
	
	  @AfterMethod(alwaysRun = true) public void teardown() throws
	  InterruptedException {
	  
	  driver.quit();
	  
	  //ac.AdditionalWait(); 
	  }
	 
	
	
}
