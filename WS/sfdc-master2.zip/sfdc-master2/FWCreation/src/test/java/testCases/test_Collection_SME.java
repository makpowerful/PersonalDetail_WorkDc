package testCases;


import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import pageObjects.CasesPO;
import pageObjects.CollectionAssistantLoginPO;
import pageObjects.CreatedAccountPO;
import pageObjects.CreatedCaseRecordPO;
import pageObjects.FirstConnectPO;
import pageObjects.NewCaseDetailsPO;
import pageObjects.NewCaseRecordTypePO;
import pageObjects.NewPaymentRecordPO;
import pageObjects.PaymentCaseQAPO;
import pageObjects.PaymentsPO;
import pageObjects.SMEFirstActionPO;
import pageObjects.SMEFirstConnectPO;
import pageObjects.UserDetailPO;
import pageObjects.UserSetupPO;
import pageObjects.loginPO;
import payLoad.payLoad_SinglePrgm;
import resources.ExcelData;
import resources.base;

public class test_Collection_SME extends base {

	public WebDriver driver;
	//ThreadLocal<WebDriver> driver = new ThreadLocal<WebDriver>();
	//public String CurrURL;
	public static Logger log = LogManager.getLogger(test_CollectionFlow.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	ArrayList<String> al3 = new ArrayList<String>();
	ArrayList<String> al4 = new ArrayList<String>();
	static Faker faker = new Faker();
	static String firstName = faker.name().firstName();
	static String lastName = faker.name().lastName();
	static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);

	
	@BeforeMethod(alwaysRun = true)
	public void initialize() throws IOException, InterruptedException {

		driver = initializeDriver();
	}
	
	 
	 

	@Test(groups = { "sanity", "Regression" }, enabled = true)
	public void Test_Collection_SME() throws Exception {
	    String Accountid = null;
		loginPO lo=new loginPO(driver);
		if(CurrURL.contains("--byjusuat")) {
	        al = excelData.getData("BYJUS Math", "Picklist", "Tcid");
	        al2 = excelData.getData("CollectionAssistant UAT1", "Login", "Type");
	        al3 = excelData.getData("TC1", "CollectionSME", "Tcid");
	        al4 = excelData.getData("AdminUAT", "Login", "Type");
	        log.info("Logging in as Admin to UAT");
	        lo.LoginAsAdmin_UAT1();
	        log.info("Submitting the Account creation payload");
	        Accountid=payLoad_SinglePrgm.AccountidCreationResponse_UAT(al.get(1), al.get(2), al.get(3), al.get(4));
	        log.info("Launching the newly created Account id "+Accountid);
	        
	        }
	        else {
	            al = excelData.getData("BYJUS Math", "Picklist", "Tcid");
	            //al2 = excelData.getData("Collection Assistant", "Login", "Type");
	            log.info("Logging in as Admin to Prod");
	            lo.LoginAsAdmin_Prod();
	            log.info("Submitting the Account creation payload");
	            Accountid=payLoad_SinglePrgm.AccountidCreationResponse_Prod(al.get(1), al.get(2), al.get(3), al.get(4));
	            log.info("Launching the newly created Account id "+Accountid);
	        }
		
		
		CreatedAccountPO ac=new CreatedAccountPO(driver);
		PaymentsPO p = new PaymentsPO(driver);
		CasesPO cases=new CasesPO(driver);
		NewPaymentRecordPO npr = new NewPaymentRecordPO(driver);
		UserDetailPO ud = new UserDetailPO(driver);
		UserSetupPO us = new UserSetupPO(driver); 
		SMEFirstActionPO sfa = new SMEFirstActionPO(driver);
		SMEFirstConnectPO sfc = new SMEFirstConnectPO(driver);
		ac.closeTabWindows();
		ac.Notification();
        ac.NavBackToAccount();
        String AccountURL = CurrURL+Accountid;
        ac.goTo(AccountURL);
        ac.AccountLoadwait();
        
        
        //Capture Account Name
        String AccountName = ac.CaptureAccOwnrNam();
        
        //Capture Account Owner Name
        String AccountOwnerName = ac.CaptureAccOwnerNam();
        
        //Capture Premiumid
        String Premiumid = ac.CapturePremiumID();
        
        //Capture Program Name
        String ProgramName = ac.CapturePrgCreated();
        
        //Navigating to Payments 
        ac.ClickStudentPayments();
        p.ClickLoanPaymentRecord();
        String PaymentRecord = npr.CapturePaymentRcdID();
        String PaymentURL = ac.CaptureURL();
        log.info("New Payment Record " + PaymentRecord + " created successfully");
        
        //Capture Loan Amount
        String PaymentLoanAmount = p.CaptureLoanAmount();
        
        //Capture EMI Amount
        String PaymentEMIAmount = p.CaptureEMIAmount();
        
        //Creating EMI Case
        npr.ClickCasesQA();

        log.info("Creating New Case Record for " + PaymentRecord);
        PaymentCaseQAPO pcqa = new PaymentCaseQAPO(driver);
        pcqa.ClickCaseNewButton(PaymentRecord);
        
        al = excelData.getData("TC1", "CollectionFlow", "Tcid");
        NewCaseRecordTypePO ncrt = new NewCaseRecordTypePO(driver);
        ncrt.SelectCaseRecordType(al.get(14));
        ncrt.ClickNext();
        
        NewCaseDetailsPO ncd = new NewCaseDetailsPO(driver);

        
        ncd.enterEMIamount(al.get(6));
        ncd.EnterSubject(al.get(43));
        ncd.ClickSave();
        
        CreatedCaseRecordPO ccr = new CreatedCaseRecordPO(driver);
        String EMICaseRecord = ccr.CaptureNewCaseRecord();
        log.info("New Case Record " + EMICaseRecord + " created successfully");
        
        String EMICaseURL = ac.CaptureURL();
        
        if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
            ccr.ClickAssingedTo();
            ccr.EnterAssingedTo2(al2.get(1));
            ccr.ClickSave();
            }

        //Logging in as the assigned user
        ccr.ClickAssignedUser2(al2.get(1));
        log.info("Logging in as Collection Assistant " + FullName(al2.get(1)));

        ud.ClickUserDetailbutton();
        
        
        us.ClickLoginbutton();
        ac.closeTabWindows();
        CollectionAssistantLoginPO cal = new CollectionAssistantLoginPO(driver);
        cal.ClickBellicon();
        al2 = excelData.getData("Admin", "Login", "Type");
        if(CurrURL.contains("--byjusuat")) {
            cal.SelectAssignedTask(taskName(al4.get(1)));   
        }
        FirstConnectPO fc = new FirstConnectPO(driver);
        String Firstconnect_caseid = fc.CaptureFCcaseid();
        // Compare the Case Record to First connect case Record
        Assert.assertEquals(EMICaseRecord, Firstconnect_caseid);
        
        //Performing No Payment process
        fc.ClickNoPayment();
        fc.ClickCallStatus(al3.get(1));//No Payment
        fc.ClickReasonForDenial(al3.get(2));//Facing Issues-BYJUS
        fc.SelectCXIssue(al3.get(3));//Mentor Call Back Needed
        fc.EnterComments(al3.get(4));//No comments
        fc.clickNext();
        
        //Enter Rating
        fc.EnterRating();
        fc.clickNextSwitchDefault();
        ac.AdditionalWait();

        String Followup_status = fc.CheckFCStatus();
        Assert.assertEquals(Followup_status, "Completed");
        String Followup_callstatus = fc.CheckFCCallStatus();
        Assert.assertEquals(Followup_callstatus, "No Payment");
        
        ac.goTo(EMICaseURL);
        ac.AdditionalWait();
        
        //Verifying EMI Case status has changed to Facing Issues
        Assert.assertEquals(cases.CaptureStatus(), "Facing Issues");
        
        ac.goTo(PaymentURL);
        ac.AdditionalWait();
        String CaseCount = p.CaptureCaseCount();
        Assert.assertEquals(CaseCount,"(1)");
        
        lo.OnlyLogout();
        ac.goTo(AccountURL);
        ac.AdditionalWait();

        //Navigate to EMI case to check Status which must be Facing issues
        
        //Navigating to Payment record to see the SME case created
        ac.ClickStudentPayments();
        p.ClickLoanPaymentRecord();
        p.ClickCasesTab();
        p.SelectSMECase(EMICaseRecord);
        String SMECaseRecord = ccr.CaptureNewCaseRecord();
        String SMECaseURL = ac.CaptureURL();
        log.info("New SME Case Record " + SMECaseRecord + " created successfully");

        //Verifying Super Status and Status
        Assert.assertEquals(cases.CaptureSuperStatus(), "Mentor Issue");
        Assert.assertEquals(cases.CaptureStatus(), "Open");
        
        //Verifying details on created SME case

        //Capture Payment number and Assert
        Assert.assertEquals(cases.CapturePaymentNumer(), PaymentRecord);
        
        //Capture EMI Amount and Assert
        Assert.assertEquals(cases.CaptureEMIAmount(), PaymentEMIAmount);
        
        //Capture Loan Amount and Assert
        Assert.assertEquals(cases.CaptureLoanAmount(), PaymentLoanAmount);
        
        //Capture Premium id and Assert
        Assert.assertEquals(cases.CapturePremiumid(), Premiumid);
        
        //Capture Account Owner and Assert
        Assert.assertEquals(cases.CaptureAccountOwner(), AccountOwnerName);
        
        //Capture Account Name and Assert
        Assert.assertEquals(cases.CaptureAccountName(), AccountName);
        
        //Capture Loan Amount and Assert
        Assert.assertEquals(cases.CaptureProgramName(), ProgramName);
        
        //Changing Owner to SME Admin
        cases.ChangeCaseOwner(al3.get(5));
        
        //Logging in as SME Admin
        cases.ClickCaseOwner();
        ud.ClickUserDetailbutton();
        us.ClickLoginbutton();
        ac.closeTabWindows();
        ac.Notification();
        ac.goTo(SMECaseURL);
        ac.AdditionalWait();
        ac.AdditionalWait();
        
        cases.ChangeAssignedTo(al3.get(6));
        cases.ClickSave();
        
        ac.Scrollhome();
        ac.RefreshTab();
        ac.AdditionalWait();
        //Checking Status is set to SME WIP
        Assert.assertEquals(cases.CaptureStatus(), "SME WIP");
        
        //Verifying Assigned to is set
        Assert.assertEquals(cases.CaptureAssignedTo(), al3.get(6));
        
        //Logging in as SME Agent
        lo.OnlyLogout();
        us.EnterUserThenLogin(al3.get(6));
        ac.closeTabWindows();
        ac.Notification();
        ac.goTo(SMECaseURL);
        ac.AdditionalWait();
        
        
        
        //Performing 'Pending Resolution' flow on SME First Action Task
        cases.SelectTaskOpenActivities("SME First Action Task");
        
        sfa.ChangeIssues("Pending Resolution");
        sfa.ClickSave();
        ac.RefreshTab();
        Assert.assertEquals(sfa.CaptureStatus(), "Completed");
        ac.CloseCurrentSubTab();
        ac.RefreshTab();
        
        //Performing 'Resolved' flow on SME Follow Up Action Task
        cases.SelectTaskOpenActivities("SME Follow Up Action Task");
        sfa.ChangeIssues("Resolved");
        sfa.ClickSave();
        ac.AdditionalWait();
        Assert.assertEquals(sfa.CaptureStatus(), "Completed");
        
        lo.OnlyLogout();
        ac.goTo(SMECaseURL);
        ac.AdditionalWait();
        
        //Checking Status is changed to SME Calling Pending
        Assert.assertEquals(cases.CaptureStatus(), "SME Calling Pending");
        
        //Adding the Pending On User
        cases.ChangePendingOnUser(al3.get(5));
        cases.ClickSave();
        
        ac.Scrollhome();
        ac.RefreshTab();
        
        //Verifying Pending On User is set
        Assert.assertEquals(cases.CapturePendingOn(), al3.get(5));
        
        //Logging in as SME Admin again
        cases.ClickCaseOwner();
        ud.ClickUserDetailbutton();
        us.ClickLoginbutton();
        ac.closeTabWindows();
        ac.goTo(SMECaseURL);
        ac.AdditionalWait();
        
        //Performing 'No Resolved' flow on SME First Connect Task
        cases.SelectTaskOpenActivities("SME First Connect Task");
        //sfc

        sfc.ChangeIssues("Not Resolved");
        sfa.ClickSave();
        ac.RefreshTab();
        Assert.assertEquals(sfa.CaptureStatus(), "Completed");
        ac.CloseCurrentSubTab();
        
        //Checking Status is set back to to SME WIP
        Assert.assertEquals(cases.CaptureStatus(), "SME WIP");
        
        //Logging in as SME Agent
        lo.OnlyLogout();
        us.EnterUserThenLogin(al3.get(6));
        ac.closeTabWindows();
        ac.Notification();
        ac.goTo(SMECaseURL);
        ac.AdditionalWait();
        
        //Performing 'Resolved' flow on SME Follow Up Action Task
        cases.SelectTaskOpenActivities("SME Follow Up Action Task");
        sfa.ChangeIssues("Resolved");
        sfa.ClickSave();
        ac.AdditionalWait();
        Assert.assertEquals(sfa.CaptureStatus(), "Completed");
        
        lo.OnlyLogout();
        ac.goTo(SMECaseURL);
        ac.AdditionalWait();
        
        //Checking Status is changed to SME Calling Pending
        Assert.assertEquals(cases.CaptureStatus(), "SME Calling Pending");
        
        //Remove and Re assign Pending On User
        cases.RemovePendingOnUser();
        cases.ClickSave();
        cases.ChangePendingOnUser(al3.get(5));
        cases.ClickSave();
        
        //Logging in as SME Admin again
        cases.ClickCaseOwner();
        ud.ClickUserDetailbutton();
        us.ClickLoginbutton();
        ac.closeTabWindows();
        ac.goTo(SMECaseURL);
        ac.AdditionalWait();
        
        //Performing 'No Call Connect' flow on SME Follow Up Action Task
        cases.SelectTaskOpenActivities("SME First Connect Task");
        sfa.ChangeIssues("No Call Connect");
        sfa.ClickSave();
        ac.AdditionalWait();
        Assert.assertEquals(sfa.CaptureStatus(), "Completed");
        ac.CloseCurrentSubTab();
        ac.RefreshTab();
        
        //Performing 'Resolved' flow on SME Follow Up Action Task
        cases.SelectTaskOpenActivities("SME Call Follow Up Task");
        sfa.ChangeIssues("Resolved");
        sfa.ClickSave();
        ac.AdditionalWait();
        Assert.assertEquals(sfa.CaptureStatus(), "Completed");
        ac.CloseCurrentSubTab();
        ac.RefreshTab();
        
        //Checking Status is changed to SME Calling Pending
        Assert.assertEquals(cases.CaptureStatus(), "SME Issue Resolved");
        
        //Logging back as Admin
        lo.OnlyLogout();
        ac.goTo(AccountURL);
        ac.AdditionalWait();
        
        ac.ClickCasesMC2();
        cases.CloseAllCases();
        ac.CloseSubTabs();
        
        //Deleting created Account record
        log.info("Deleting the Student Program details");
        ac.ClickAccOwnrTab();
        ac.DeleteCreatedStuProg();
        ac.DeleteAllCreatedStuPayment();
        ac.NavBackToAccount();
        log.info("Deleting the Account created details");
        ac.DeleteAccountCreated(ac.CaptureAccOwnrNam());

	}

	
	@AfterMethod(alwaysRun = true)
	public void teardown() throws InterruptedException {

	    driver.quit();

	}

}
