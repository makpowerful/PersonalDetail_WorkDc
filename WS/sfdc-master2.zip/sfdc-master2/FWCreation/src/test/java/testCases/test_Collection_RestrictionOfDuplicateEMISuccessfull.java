package testCases;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import pageObjects.CapturePaymentDetailsEMIPO;
import pageObjects.CasesPO;
import pageObjects.CollectionAssistantLoginPO;
import pageObjects.CreatedAccountPO;
import pageObjects.CreatedCaseRecordPO;
import pageObjects.FirstConnectPO;
import pageObjects.NPPaymentLoanPO;
import pageObjects.NewCaseDetailsPO;
import pageObjects.NewCaseRecordTypePO;
import pageObjects.NewPaymentPO;
import pageObjects.NewPaymentRecordPO;
import pageObjects.PaymentCaseQAPO;
import pageObjects.PaymentsPO;
import pageObjects.UserDetailPO;
import pageObjects.UserSetupPO;
import pageObjects.loginPO;
import resources.ExcelData;
import resources.base;

public class test_Collection_RestrictionOfDuplicateEMISuccessfull extends base {

	public WebDriver driver;
	//ThreadLocal<WebDriver> driver = new ThreadLocal<WebDriver>();
	//public String CurrURL;
	public static Logger log = LogManager.getLogger(test_CollectionFlow.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	ArrayList<String> al3 = new ArrayList<String>();
	ArrayList<String> al4 = new ArrayList<String>();
	static Faker faker = new Faker();
	static String firstName = faker.name().firstName();
	static String lastName = faker.name().lastName();
	static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);

	
	@BeforeMethod(alwaysRun = true)
	public void initialize() throws IOException, InterruptedException {

		driver = initializeDriver();
	}
	
	 
	 

	@Test(groups = { "sanity", "Regression" }, enabled = true)
	public void Collection_EMISuccessfull() throws Exception {
		
		loginPO lo=new loginPO(driver);
		if(CurrURL.contains("--byjusuat")) {
		al = excelData.getData("TC5", "CollectionFlow", "Tcid");
		al2 = excelData.getData("CollectionAssistant UAT", "Login", "Type");
		al3 = excelData.getData("CollectionManager UAT", "Login", "Type");
		al4 = excelData.getData("Admin", "Login", "Type");
		log.info("Logging in as Admin to UAT");
		lo.LoginAsAdmin_UAT();
		//lo.SwitchUser(al2.get(1));
		
		}
		else {
			al = excelData.getData("TC5", "CollectionFlow", "Tcid");
			//al2 = excelData.getData("Collection Assistant", "Login", "Type");
			log.info("Logging in as Admin to Prod");
			lo.LoginAsAdmin_Prod();
		}
		//Assert.assertTrue(false);
		closeTabWindows();
		log.info("Creating new Payment record");
		CreatedAccountPO ac=new CreatedAccountPO(driver);
		PaymentsPO p = new PaymentsPO(driver);
		CasesPO cases=new CasesPO(driver);
		ac.Notification();
		p.NavMenuClick();
		p.PaymntNavMenuClick();
		p.NewPaymentClick();
		log.info("Selection of Payment - Loan record");
		NewPaymentPO np = new NewPaymentPO(driver);
		np.SelectPaymentOptn(al.get(1));
		np.ClickNext();
		
		log.info("Enter New Payment - Loan details");
		NPPaymentLoanPO npp = new NPPaymentLoanPO(driver);
		//npp.EnterPayRefID(randomNum);
		npp.EnterParentFN(firstName);
		npp.EnterParentLN(lastName);
		npp.EnterLoanAmount(al.get(2));
		npp.EnterTenurity(al.get(4));
		npp.EnterProgramName(al.get(3));	
		npp.EnterEPPartner(al.get(5));
		npp.EnterAmount(al.get(6));
		npp.EnterTotalAmountTBC(al.get(7));
		npp.EnterNetPayAmount(al.get(8));
		npp.EnterPaymentAmount(al.get(9));
		npp.EnterPaymentCategory(al.get(10));
		npp.EnterPaymentMS(al.get(11));
		npp.EnterPaymentDate(al.get(12));
		npp.EnterPaymentType(al.get(13));
		npp.ClickSave();
		ac.AdditionalWait();
		
		NewPaymentRecordPO npr = new NewPaymentRecordPO(driver);
		String PaymentRecord = npr.CapturePaymentRcdID();
		log.info("New Payment Record " + PaymentRecord + " created successfully");
		npr.ClickCasesQA();

		log.info("Creating New Case Record for " + PaymentRecord);
		PaymentCaseQAPO pcqa = new PaymentCaseQAPO(driver);
		pcqa.ClickCaseNewButton(PaymentRecord);

		NewCaseRecordTypePO ncrt = new NewCaseRecordTypePO(driver);
		ncrt.SelectCaseRecordType(al.get(14));
		ncrt.ClickNext();

		NewCaseDetailsPO ncd = new NewCaseDetailsPO(driver);
		ncd.enterEMIamount(al.get(6));
		ncd.EnterSubject(al.get(43));
		ncd.ClickSave();

		CreatedCaseRecordPO ccr = new CreatedCaseRecordPO(driver);
		String CaseRecord = ccr.CaptureNewCaseRecord();
		log.info("New Case Record " + CaseRecord + " created successfully");
		
		//String AccountURL = driver.getCurrentUrl();
		
		if(CurrURL.contains("--byjusuat")&&!CurrURL.contains("--byjusuatfc")) {
		ccr.ClickAssingedTo();
		ccr.EnterAssingedTo2(al2.get(1));
		ccr.ClickSave();
		}
		else {
			ccr.CaseOwnrUpdate_Prod(al2.get(1));
		}
		String Colluser = MailFullName(al2.get(1));
		//Logging in as the assigned user
		ccr.ClickAssignedUser2(al2.get(1));
	    log.info("Logging in as Collection Assistant " + FullName(al2.get(1)));
	    UserDetailPO ud = new UserDetailPO(driver); 
	    ud.ClickUserDetailbutton();
	    
	    UserSetupPO us = new UserSetupPO(driver); 
	    us.ClickLoginbutton();
		ac.closeTabWindows();
		CollectionAssistantLoginPO cal = new CollectionAssistantLoginPO(driver);
		cal.ClickBellicon();
		al2 = excelData.getData("Admin", "Login", "Type");
			cal.SelectAssignedTask(taskName(al4.get(1)));	
		
		FirstConnectPO fc = new FirstConnectPO(driver);
		String Firstconnect_caseid = fc.CaptureFCcaseid();
		// Compare the Case Record to First connect case Record
		Assert.assertEquals(CaseRecord, Firstconnect_caseid);
		log.info("Providing Capture payment detail for Case record " + Firstconnect_caseid);
		fc.ClickCapturePayment();

		CapturePaymentDetailsEMIPO cpd = new CapturePaymentDetailsEMIPO(driver);
		cpd.EnterRating(al.get(15));
		cpd.ClickNext();
		cpd.SelectPaymntOptn(al.get(16));
		log.info("Selected the payment option " + al.get(16));
		cpd.ClickNext();		
		Assert.assertEquals(cpd.getAmtpaid(), al.get(6));
		cpd.EnterAmtpaid(al.get(17));		
		cpd.SelectPaymentMethod(al.get(18));
		cpd.EnterDupPaymentRef();
		cpd.SelectCollectionchannel(al.get(19)); // Raised defect SFDC-4540
		cpd.ClickNext();
		String PRerror = cpd.CaptureErrorMess();
		// Verify the Error message is Matching.
		Assert.assertEquals(PRerror,cpd.errorMsg());				
		cpd.EnterPaymntRefVal(randomNum);
		cpd.ClickNext();
		cpd.SelectEMIcoll(al.get(20));
		cpd.SelectTypofCollPaid(al.get(21));
		cpd.ClickNext();
		cpd.SelectElgfrRef(al.get(22));
		cpd.ClickNext();
		ac.AdditionalWait();
		
		String Firstconnect_status = fc.CheckFCStatus();
		// Verify the Status for first connect is changed to Completed
		Assert.assertEquals(Firstconnect_status, "Completed");
		String Firstconnect_callstatus = fc.CheckFCCallStatus();
		// Verify the Call Status for first connect is changed to Payment Confirmed
		Assert.assertEquals(Firstconnect_callstatus, "Payment Confirmed");

		log.info("Logging out as Collection Assistant");
		ac.AdditionalWait();
		//cal.Logout();
		lo.Logouthome();

		log.info("Verifying the Payment/Case Status are correct");
		ac.CloseSubTabs();
		p.NavCaseTab(CaseRecord);
		
		String CaseStatus = ccr.CaseStatusval();
		String CaseOwner = ccr.CaseOwnerval();
		log.info("The record number for newly created Case record is " + ccr.CaptureNewCaseRecord());
		// Verify the Case Status is changed to Audit Pending
		Assert.assertEquals(CaseStatus, "Audit Pending");
		// Verify the Case owner is same
		Assert.assertTrue(CaseOwner.equalsIgnoreCase(Colluser));
        // Get the Audit case id 
		String RelatedCaseRecord= ccr.getAuditCaseCaptureRelatedCase();
        // User story SFDC-3861
        ccr.clickAuditRelatedCase();
        String txtPaymentMethod= ccr.getPaymentMethod();
        // Verify the payment method is same
        Assert.assertEquals(al.get(18), txtPaymentMethod);
        ccr.closeCurrentTab(RelatedCaseRecord);
		log.info("Deleting the Related Case Record " +RelatedCaseRecord);
		// Deleting the audit case
		ccr.DeleteRelatedCaseRecord(RelatedCaseRecord);
		// Deleting the EMI case
		log.info("Deleting the created Case Record " +CaseRecord);
		p.NavCasesTab();		
		cases.DeleteCCaseRecord(CaseRecord);
		log.info("Deleting the created Payment Record " + PaymentRecord);
		p.NavMenuClick();
		p.PaymntNavMenuClick();
		// Deleting the Payment record
		p.DeletePayRecord(PaymentRecord);

	}

	
	@AfterMethod(alwaysRun = true)
	public void teardown() throws InterruptedException {

		driver.quit();

	}

}
