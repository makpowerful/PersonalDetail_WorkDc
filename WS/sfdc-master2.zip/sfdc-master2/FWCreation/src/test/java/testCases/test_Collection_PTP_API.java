package testCases;


import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import pageObjects.CapturePaymtDetailsPTPPO;
import pageObjects.CasesPO;
import pageObjects.CollectionAssistantLoginPO;
import pageObjects.CreatedAccountPO;
import pageObjects.CreatedCaseRecordPO;
import pageObjects.FirstConnectPO;
import pageObjects.NPPaymentLoanPO;
import pageObjects.NewPaymentPO;
import pageObjects.NewPaymentRecordPO;
import pageObjects.PaymentsPO;
import pageObjects.TasksPO;
import pageObjects.UserDetailPO;
import pageObjects.UserSetupPO;
import pageObjects.loginPO;
import payLoad.payLoad_Collection;
import resources.ExcelData;
import resources.base;

public class test_Collection_PTP_API extends base {

	public WebDriver driver;
	// ThreadLocal<WebDriver> driver = new ThreadLocal<WebDriver>();
	// public String CurrURL;
	public static Logger log = LogManager.getLogger(test_CollectionFlow.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	ArrayList<String> al3 = new ArrayList<String>();
	ArrayList<String> al4 = new ArrayList<String>();
	static Faker faker = new Faker();
	static String firstName = faker.name().firstName();
	static String lastName = faker.name().lastName();
	static int randomNum = ThreadLocalRandom.current().nextInt(10000000, 100000000 + 1);

	@BeforeMethod(alwaysRun = true)
	public void initialize() throws IOException, InterruptedException {

		driver = initializeDriver();
	}

	@Test(groups = { "sanity", "Regression" }, enabled = true)
	public void Collection_PtpFlow_Api() throws Exception {

		String val = Integer.toString(randomNum);
		loginPO lo = new loginPO(driver);
		if (CurrURL.contains("--byjusuatfc")) {
			al = excelData.getData("TC3", "CollectionFlow", "Tcid");
			al2 = excelData.getData("CollectionAssistant UATFC", "Login", "Type");
			al3 = excelData.getData("CollectionManager UATFC", "Login", "Type");
			al4 = excelData.getData("Adminuatfc", "Login", "Type");
			log.info("Logging in as Admin to UATFC");
			lo.LoginAsAdmin_UATFC();

		} else if (CurrURL.contains("--byjusuat")) {
			al = excelData.getData("TC3", "CollectionFlow", "Tcid");
			al2 = excelData.getData("CollectionAssistant UAT", "Login", "Type");
			al3 = excelData.getData("CollectionManager UAT", "Login", "Type");
			al4 = excelData.getData("Admin", "Login", "Type");
			log.info("Logging in as Admin to UAT");
			lo.LoginAsAdmin_UAT();
			// lo.SwitchUser(al2.get(1));

		} else {
			al = excelData.getData("TC3", "CollectionFlow", "Tcid");
			al2 = excelData.getData("Dummy Collection Associate", "Login", "Type");
			al4 = excelData.getData("AdminProd", "Login", "Type");
			log.info("Logging in as Admin to Prod");
			lo.LoginAsAdmin_Prod();
		}

		closeTabWindows();
		//closeTabWindows();
		log.info("Creating new Payment record");
		CreatedAccountPO ac = new CreatedAccountPO(driver);
		PaymentsPO p = new PaymentsPO(driver);
		CasesPO cases = new CasesPO(driver);
		p.NavMenuClick();
		p.PaymntNavMenuClick();
		p.NewPaymentClick();

		log.info("Selection of Payment - Loan record");
		NewPaymentPO np = new NewPaymentPO(driver);
		np.SelectPaymentOptn(al.get(1));
		np.ClickNext();

		log.info("Enter New Payment - Loan details");
		NPPaymentLoanPO npp = new NPPaymentLoanPO(driver);
		// npp.EnterPayRefID(randomNum);
		npp.EnterParentFN(firstName);
		npp.EnterParentLN(lastName);
		npp.EnterLoanAmount(al.get(2));
		npp.EnterTenurity(al.get(4));
		npp.EnterProgramName(al.get(3));
		npp.EnterEPPartner(al.get(5));
		npp.EnterAmount(al.get(6));
		npp.EnterTotalAmountTBC(al.get(7));
		npp.EnterNetPayAmount(al.get(8));
		npp.EnterPaymentAmount(al.get(9));
		npp.EnterPaymentCategory(al.get(10));
		npp.EnterPaymentMS(al.get(11));
		npp.EnterPaymentDate(al.get(12));
		npp.EnterPaymentType(al.get(13));
		npp.ClickSave();
		// Assert.assertTrue(false);
		NewPaymentRecordPO npr = new NewPaymentRecordPO(driver);
		String PaymentRecord = npr.CapturePaymentRcdID();
		log.info("New Payment Record " + PaymentRecord + " created successfully");

		//===== user Story SFDC-2311 starts
		log.info("Creating message notifiaction Record for " + PaymentRecord);
		String warning= p.createMessageNotification();
		Assert.assertEquals(warning, "You can send only one message per day per payment");
		npr.ClickNotificationsQA();
		String text= p.getMessageNotificationSub();
		if(CurrURL.contains("--byjusuat")) {
		//verifying notification text
		Assert.assertEquals(text, "FINBJC SMS Sent - ******0715");
		}else {
		    Assert.assertEquals(text, "FINBJC SMS Sent - 8105710715");
		}
		cases.DeleteCaseRecord(text);
		p.closeNotification();	
		//======user story SFDC-2311 ends
		
		log.info("Creating New Case Record for " + PaymentRecord);
		p.clickCreateCase(val);
		npr.ClickCasesQA();
		String CaseRecord = p.getCaseNumber();
		p.clickCaseNumber();

		CreatedCaseRecordPO ccr = new CreatedCaseRecordPO(driver);
		// String CaseRecord = ccr.CaptureNewCaseRecord();
		log.info("New Case Record " + CaseRecord + " created successfully");

		String AccountURL = driver.getCurrentUrl();

		if (!CurrURL.contains("--byjusuatfc")) {
			ccr.ClickAssingedTo();
			ccr.EnterAssingedTo2(al2.get(1));
			ccr.ClickSave();
		} else if (CurrURL.contains("--byjusuatfc")) {
			lo.SwitchUser(al4.get(3));
			ac.closeTabWindows();
			ac.Notification();
			// ac.NavBackToAccount();
			ac.goTo(AccountURL);
			Thread.sleep(5000);
			ccr.ClickAssingedTo();
			ccr.EnterAssingedTo2(al2.get(1));
			ccr.ClickSave();
		}

		// Logging in as the assigned user
		ccr.ClickAssignedUser2(al2.get(1));
		log.info("Logging in as Collection Assistant " + FullName(al2.get(1)));
		UserDetailPO ud = new UserDetailPO(driver);
		ud.ClickUserDetailbutton();

		if (CurrURL.contains("--byjusuatfc")) {
			AccountURL = driver.getCurrentUrl();
			lo.OnlyLogout();
			ac.goTo(AccountURL);
			Thread.sleep(4000);
		}

		UserSetupPO us = new UserSetupPO(driver);
		us.ClickLoginbutton();
		ac.closeTabWindows();
		CollectionAssistantLoginPO cal = new CollectionAssistantLoginPO(driver);
		cal.ClickBellicon();
		if (CurrURL.contains("--byjusuatfc")) {
			cal.SelectAssignedTask(taskName(al4.get(3)));
		} else {
			cal.SelectAssignedTask(taskName(al4.get(1)));
		}
		FirstConnectPO fc = new FirstConnectPO(driver);
		String Firstconnect_caseid = fc.CaptureFCcaseid();
		// Compare the Case Record to First connect case Record
		Assert.assertEquals(CaseRecord, Firstconnect_caseid);
		log.info("Providing Capture payment detail for Case record " + Firstconnect_caseid);
		fc.ClickCapturePayment();

		CapturePaymtDetailsPTPPO cpptp = new CapturePaymtDetailsPTPPO(driver);
		cpptp.EnterRating(al.get(15));
		cpptp.ClickNext();
		cpptp.SelectPaymntOptn(al.get(16));
		log.info("Selected the payment option " + al.get(16));
		cpptp.ClickNext();

		cpptp.SelectNoofEMI(al.get(31));
		cpptp.EnterPhoneNo(al.get(32));
		if(CurrURL.contains("--byjusuat")) {
		cpptp.EnterDateTimePTP();
		}else {
		    cpptp.EnterDateTimePTPProd();
		}
		cpptp.EnterComments(al.get(33));
		cpptp.SelectPTPGivenBy(al.get(34));
		cpptp.ClickNext();
		Thread.sleep(500);
		cpptp.ClickNextSwitchDefault();

		String Firstconnect_status = fc.CheckFCStatus();
		// Verify the First connect status is updated to Completed
		Assert.assertEquals(Firstconnect_status, "Completed");
		String Firstconnect_callstatus = fc.CheckFCCallStatus();
		// Verify the First connect call status is updated to PTP
		Assert.assertEquals(Firstconnect_callstatus, "PTP");
		// User story SFDC-1753 
		fc.clickSysInfoBtn();
		String[] ptpData;
		if(CurrURL.contains("--byjusuat")) {
		ptpData = payLoad_Collection.ptpDateTime(val,"--byjusuat");
		Assert.assertEquals(ptpData[0], fc.getLastModifiedPtpDateTime("--byjusuat"));
		}else {
		ptpData = payLoad_Collection.ptpDateTime(val,"Prod");
		Assert.assertEquals(ptpData[0], fc.getLastModifiedPtpDateTime("Prod"));
		}

		log.info("Verifying the Follow up Task is created");
		TasksPO t = new TasksPO(driver);
		t.NavBackToTask();
		t.SelectCR(CaseRecord);

		ccr.ClickFollowPTPRcd(CaseRecord);

		log.info("Logging out as Collection Assistant");
		Thread.sleep(1000);
		lo.Logouthome();

		t.closeTab();
		t.NavBackToCase();
		log.info("Deleting the created Case Record " + CaseRecord);
		cases.DeleteCaseRecord(CaseRecord);
		log.info("Deleting the created Payment Record " + PaymentRecord);
		p.NavMenuClick();
		p.PaymntNavMenuClick();
		p.DeletePayRecord(PaymentRecord);

	}

	@AfterMethod(alwaysRun = true)
	public void teardown() throws InterruptedException {

		driver.quit();

	}

}
