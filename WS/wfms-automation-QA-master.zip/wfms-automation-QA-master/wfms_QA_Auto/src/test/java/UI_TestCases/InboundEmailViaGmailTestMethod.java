package UI_TestCases;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;

import pageObjects.PO_CaseDetails;
import pageObjects.PO_Gmail;

public class InboundEmailViaGmailTestMethod {
    
    public String createInboundEmailViaGmail(WebDriver driver, String email, String password, String mailId) throws InterruptedException {
        
        PO_Gmail gmailPO = new PO_Gmail(driver);
        gmailPO.setupGmailEnvironment(email, password);
        String bodyContent = gmailPO.composeNewEmail(mailId);
        driver.quit();
        return bodyContent;
    }
    
    public void testInboundEmailViaGmail(WebDriver driver, String email, String password, String mailId, String bodyContent) throws InterruptedException {
        
        PO_Gmail gmailPO = new PO_Gmail(driver);
        gmailPO.setupGmailEnvironment(email, password);
        gmailPO.applyFilter(mailId);
        gmailPO.openEmail(mailId);
        String ticketId = gmailPO.getTicketIdFromEmail();
        
        PO_CaseDetails caseDetailsPO = new PO_CaseDetails(driver);
        caseDetailsPO.openSpecificTicket(ticketId);
        System.out.println(caseDetailsPO.getDescriptionContent());
        assertEquals(caseDetailsPO.getDescriptionContent(), bodyContent);
        assertEquals(caseDetailsPO.getTableTag(), "table");
    }
}
