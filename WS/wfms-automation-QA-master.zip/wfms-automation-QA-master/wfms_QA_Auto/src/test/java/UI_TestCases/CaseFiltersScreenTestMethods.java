package UI_TestCases;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.HashMap;

import org.openqa.selenium.WebDriver;

import pageObjects.PO_CaseFilters;

public class CaseFiltersScreenTestMethods {

    public void testCaseFiltersScreen(WebDriver driver, HashMap<String, String> ticketData, String role) {
        // Creating an object of the PO_CaseList class.
        PO_CaseFilters caseFiltersScreenObject= new PO_CaseFilters(driver);
        
        caseFiltersScreenObject.refreshPage();
//        caseFiltersScreenObject.selectProject(ticketData.get("Category"));
        caseFiltersScreenObject.clickFiltersBtn();
        
        // CFS TC-01: Check for all the UI components according to the zeplin screen provided and asserting the results
        assertEquals(caseFiltersScreenObject.getFilterCustomerNameLabel(),"Customer Name");
        assertEquals(caseFiltersScreenObject.getFilterDateCreatedLabel(),"Created At");
        assertEquals(caseFiltersScreenObject.getFilterStatusLabel(),"Status");
        
        // Defect Id: https://byjustech.atlassian.net/browse/WFM-243
        assertTrue(caseFiltersScreenObject.checkStatusOptions());
        
        assertEquals(caseFiltersScreenObject.getFilterCustomerNameInput(),"Search for first name");
        assertEquals(caseFiltersScreenObject.getFilterFromDateCreatedInput(),"From Date");
        assertEquals(caseFiltersScreenObject.getFilterToDateCreatedInput(),"To Date");
        assertEquals(caseFiltersScreenObject.getFilterStatusInput(),"Select Status");
        if(role.equals("requestor") == false) {
            assertEquals(caseFiltersScreenObject.getFilterGroupLabel(),"Group");
            assertEquals(caseFiltersScreenObject.getFilterAgentLabel(),"Agent");
            assertEquals(caseFiltersScreenObject.getFilterPriorityLabel(),"Priority");
            
            // Defect Id: https://byjustech.atlassian.net/browse/WFM-243
            assertTrue(caseFiltersScreenObject.checkPriorityOptions());
            
            assertEquals(caseFiltersScreenObject.getFilterSubCategoryLabel(),"Sub Category");
            assertEquals(caseFiltersScreenObject.getFilterIssueTypeLabel(),"Issue Type");
            assertEquals(caseFiltersScreenObject.getFilterIssueSubTypeLabel(),"Issue Sub Type");
            assertEquals(caseFiltersScreenObject.getFilterGroupInput(),"Select Group");
            assertEquals(caseFiltersScreenObject.getFilterAgentInput(),"Select Agent");
            assertEquals(caseFiltersScreenObject.getFilterPriorityInput(),"Select Priority");
            assertEquals(caseFiltersScreenObject.getFilterSubCategoryInput(),"Select Sub Category");
            assertEquals(caseFiltersScreenObject.getFilterIssueTypeInput(),"Select Issue Type");
            assertEquals(caseFiltersScreenObject.getFilterIssueSubTypeInput(),"Select Issue Sub Type");
        }
        assertEquals(caseFiltersScreenObject.getFilterSliderText(),"Filters");
        assertEquals(caseFiltersScreenObject.getApplyBtnText(),"Apply");
        assertEquals(caseFiltersScreenObject.getResetBtnText(),"Reset");
        
        // CFS TC-02: Filter using customer name and check the results
        // Defect Id: https://byjustech.atlassian.net/browse/WFM-252
        assertTrue(caseFiltersScreenObject.checkCustomerNameFilter(ticketData.get("Customer Name")));
        caseFiltersScreenObject.clickFiltersBtn();
        
        // CFS TC-03: Filter using date created and check the results
        // Defect Id: https://byjustech.atlassian.net/browse/WFM-280
        // Defect Id: https://byjustech.atlassian.net/browse/WFM-261
        // Defect Id: https://byjustech.atlassian.net/browse/WFM-472
        assertTrue(caseFiltersScreenObject.checkCreatedAtFilter());
        caseFiltersScreenObject.clickFiltersBtn();
        
        // CFS TC-06: Filter using status and check the results
        assertTrue(caseFiltersScreenObject.checkStatusFilter(ticketData.get("caseStatus")));
        caseFiltersScreenObject.clickFiltersBtn();
        
        if(role.equals("requestor") == false) {
            // CFS TC-04: Filter using group and check the results
            // Defect Id: https://byjustech.atlassian.net/browse/WFM-459
            assertTrue(caseFiltersScreenObject.checkGroupFilter(ticketData.get("caseGroup")));
            caseFiltersScreenObject.clickFiltersBtn();
            
            // CFS TC-05: Filter using agent and check the results
            assertTrue(caseFiltersScreenObject.checkAgentFilter(ticketData.get("caseAgent")));
            caseFiltersScreenObject.clickFiltersBtn();
            
            // CFS TC-07: Filter using priority and check the results
            assertTrue(caseFiltersScreenObject.checkPriorityFilter(ticketData.get("casePriority")));
            caseFiltersScreenObject.clickFiltersBtn();
            
            // CFS TC-08: Filter using sub category and check the results
            assertTrue(caseFiltersScreenObject.checkSubCategoryFilter(ticketData.get("Sub Category")));
            caseFiltersScreenObject.clickFiltersBtn();
            
            // CFS TC-09: Filter using issue type and check the results
            assertTrue(caseFiltersScreenObject.checkIssueTypeFilter(ticketData.get("Issue Type")));
            caseFiltersScreenObject.clickFiltersBtn();
            
            // CFS TC-10: Filter using issue sub type and check the results
            // Defect Id: https://byjustech.atlassian.net/browse/WFM-285
            assertTrue(caseFiltersScreenObject.checkIssueSubTypeFilter(ticketData.get("Issue Sub Type")));
            caseFiltersScreenObject.clickFiltersBtn();
            
            // CFS TC-11: Filter using customer name, status and priority and check the results
            assertTrue(caseFiltersScreenObject.checkCustomerNameStatusPriorityFilter(ticketData));
            caseFiltersScreenObject.clickFiltersBtn();
            
            // CFS TC-14: Filter using group and sub category and check the results
            assertTrue(caseFiltersScreenObject.checkGroupSubCategoryFilter(ticketData));
            caseFiltersScreenObject.clickFiltersBtn();
            
            // CFS TC-15: Filter using group and issue type and check the results
            assertTrue(caseFiltersScreenObject.checkGroupIssueTypeFilter(ticketData));
        }
    }
}
