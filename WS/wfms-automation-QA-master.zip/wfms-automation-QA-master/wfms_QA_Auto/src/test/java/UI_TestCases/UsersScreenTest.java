package UI_TestCases;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import pageObjects.PO_UserScreen;
import resources.ExcelData;
import resources.base;

public class UsersScreenTest extends base{
    private ArrayList<String> al = new ArrayList<String>();
    public ExcelData excelData = new ExcelData();
     
    //public WebDriver driver;
    
     @Test
     public int changeUserRole(String email, List<String> rolestoAssign,String projectName, String role, WebDriver driver) throws Exception {
        //driver = initializeDriver();
        driver.get("https://identity-auth-staging.byjusweb.com/adminlogin");
        
        //Login
        PO_UserScreen obj = new PO_UserScreen(driver);
        al = excelData.getData(Login, "emailId", "name");
        String emailId = al.get(1);
        String password = al.get(2);
        obj.googleLogin(emailId, password);
        
        // complete the steps in Select App screen.
        obj.selectAppScreen();
        
        // Go the "users" screen.
        obj.goToUsersScreen();
        
        // Edit the given roles for the specified user.
        obj.editRolesForUser(email, rolestoAssign);
        Thread.sleep(3000);
        
        int count=0;
        if(!role.equals("requestor"))count=obj.noOfAgents(projectName);
        driver.quit();
        return count;
    }
}
