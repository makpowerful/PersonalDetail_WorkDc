package UI_TestCases;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pageObjects.PO_Gmail;

import resources.ExcelData;
import resources.base;

public class CaseCreationViaInboundEmailTestMethods extends base {


    public ExcelData excelData = new ExcelData();
    public WebDriver driver;
    public WebDriverWait wait;
    
    @BeforeClass(alwaysRun=true)
    public void initialize() throws Exception{
        driver = initializeDriver();
        
       // PO_LoginPage loginPageObject = new PO_LoginPage(driver);
        
//        al = excelData.getData("ankur", "emailId", "name");
//        String emailId = al.get(1);
//        String password = al.get(2);
//        loginPageObject.googleLogin(emailId, password);
        
        PO_Gmail gmailPageObject = new PO_Gmail(driver);
        gmailPageObject.setupGmailEnvironment("byjuswfmsqa@gmail.com","Qwertyuiop@12345");
    }
    
    @Test(priority = 1)
    public void testCaseCreationViaInboundEmail() {
        
        //PO_Gmail gmailPageObject = new PO_Gmail(driver);
        //gmailPageObject.setupGmailEnvironment();
        
        
        // send a reply
//        gmailPageObject.sendReply();
    }
    
    @AfterClass(alwaysRun = true)
    void quitDriver() {
        
//        driver.quit();
    }
    
}
