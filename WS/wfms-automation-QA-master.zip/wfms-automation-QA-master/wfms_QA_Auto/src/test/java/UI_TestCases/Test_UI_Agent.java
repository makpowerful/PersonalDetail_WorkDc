package UI_TestCases;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import resources.ExcelData;
import resources.base;

public class Test_UI_Agent extends base {
    public WebDriver driver;
    private ArrayList<String> al = new ArrayList<String>();
    public ExcelData excelData = new ExcelData();
    private String username = Login;
    private String role = "agent";
    private boolean check = false;
    public int agentCount;
    
    @BeforeClass(groups= {"ui","regression"})
    public void initialize() throws Exception{
        driver = initializeDriver();
        if(!check) {
            al = excelData.getData(username, "emailId", "name");
            String emailId = al.get(1);
            
            String projectName = "digital-finance";
            
            List<String> rolesToAssign = new ArrayList<String>();
            rolesToAssign.add("requestor");
            rolesToAssign.add(projectName+"-"+role);
            
            UsersScreenTest obj = new UsersScreenTest();
            agentCount = obj.changeUserRole(emailId, rolesToAssign, projectName, role, driver);
            check = true;
            driver = initializeDriver();
        }
    }
    
    @Test(priority=2,groups= {"ui","regression"}, enabled=true)
    public void testTicketFlow_Agent() throws Exception {
        HashMap<String, String> ticketData;
        
        LoginScreenTestMethods loginScreen = new LoginScreenTestMethods();
        loginScreen.loginPageVerification(username, driver);

        CreateCasePageTestMethods caseCreationScreen = new CreateCasePageTestMethods();
        caseCreationScreen.testCreateCasePageUI(driver, role);
        caseCreationScreen.testCancelFunctionalityCreateCase(driver, role);
        ticketData = caseCreationScreen.testCreateNewCase(driver, role);

        CaseDetailsScreenTestMethods caseDetailsScreen = new CaseDetailsScreenTestMethods();
        caseDetailsScreen.testCaseDetailsScreen(driver, ticketData, role);
        caseDetailsScreen.testEditCase(driver, role, ticketData);
        
        TimeLineTestMethods timeLineTestMethods = new TimeLineTestMethods();
        timeLineTestMethods.testTimeLineFunctionality(ticketData, driver);
        
        CaseListScreenTestMethod caseListScreen = new CaseListScreenTestMethod();
        caseListScreen.testCaseListScreen(driver, ticketData.get("ticketId"), role);
        
        CaseFiltersScreenTestMethods caseFiltersScreen = new CaseFiltersScreenTestMethods();
        caseFiltersScreen.testCaseFiltersScreen(driver, ticketData, role);
        
        CaseListScreenTwoTestMethods caseListScreenTwoTestMethods = new CaseListScreenTwoTestMethods();
        caseListScreenTwoTestMethods.runTests(driver, role);
    }

   
    @Test(priority=3,groups= {"ui","regression"}, enabled=true)
    public void testGroupFlow_Agent() throws Exception {
        
//        LoginScreenTestMethods loginScreen = new LoginScreenTestMethods();
//        loginScreen.login(username, driver);
        
        GroupsPageTestMethods groupsPageTestMethods = new GroupsPageTestMethods();
        groupsPageTestMethods.runTests(driver, role);
    }

    @Test(priority=4,groups= {"ui","regression"}, enabled=true)
    public void testAgentListFlow_Agent() throws Exception {        
        //LoginScreenTestMethods loginScreen = new LoginScreenTestMethods();
        //loginScreen.login(username, driver);
        
        agentListScreenTestMethod obj = new agentListScreenTestMethod();
        obj.TestAgentListScreen(driver,role,agentCount);
        
    }

    @AfterClass(groups= {"ui","regression"})
    public void quitDriver() throws InterruptedException {
        driver.quit();
    } 
}
