package UI_TestCases;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;

import pageObjects.PO_MailboxList;
import resources.ExcelData;

public class MailboxListScreenTestMethods {
    protected static ExcelData excelData = new ExcelData();
    protected static ArrayList<String> al = new ArrayList<String>();
    
    public void testMailboxListScreen(WebDriver driver, HashMap<String, String> mailbox) throws Exception {
        
        PO_MailboxList mailboxListPO = new PO_MailboxList(driver);
        
        mailboxListPO.goToMailboxScreen();
        
        // MLS TC-01: Check for all the UI components according to the zeplin screen provided and asserting the results
        // MLS TC-02: Check that the mailbox left side menu icon is selected
        
        assertEquals(mailboxListPO.getHeaderText(), "Mailbox");
        assertEquals(mailboxListPO.getCreateBtn(), "CREATE");
        assertEquals(mailboxListPO.getCasesIcon(), "Cases");
        assertEquals(mailboxListPO.getGroupsIcon(), "Groups");
        assertEquals(mailboxListPO.getAgentsIcon(), "Agents");
        assertEquals(mailboxListPO.getLogoutIcon(), "Logout");
        assertEquals(mailboxListPO.getMailboxIcon(), "Mailbox");
        assertEquals(mailboxListPO.getHeaderNameText(), "Name");
        assertEquals(mailboxListPO.getHeaderEmailText(), "E-mail address");
        assertEquals(mailboxListPO.getHeaderGroupText(), "Group");
        assertTrue(mailboxListPO.checkCLickableSearchBar());
        assertTrue(mailboxListPO.checkCLickableSearchBarInput());
        assertFalse(mailboxListPO.leftPaginationIsEnabled());
        
        // MLS TC-03: Check that the edit and delete buttons are clickable
        
        assertTrue(mailboxListPO.checkCLickableItemEditIcon());
        assertTrue(mailboxListPO.checkCLickableItemDeleteIcon());
        
        // MLS TC-04: Check for a specific mailbox in the mailbox list
        assertTrue(mailboxListPO.checkSpecificMailbox(mailbox));
        
        // MLS TC-05: Check that all the emails are unique in the list
        // Defect Id: https://byjustech.atlassian.net/browse/WFM-419
        assertTrue(mailboxListPO.checkEmailUnique());
        
        // MLS TC-06: Enter wrong email id format in the email input field and check the error message
        mailboxListPO.deleteMailbox(mailbox);
        assertEquals(mailbox.get("deleteMessage"), "Mailbox deleted successfully!");
        mailboxListPO.refreshPage();
        assertFalse(mailboxListPO.checkSpecificMailbox(mailbox));
        
    }
}
