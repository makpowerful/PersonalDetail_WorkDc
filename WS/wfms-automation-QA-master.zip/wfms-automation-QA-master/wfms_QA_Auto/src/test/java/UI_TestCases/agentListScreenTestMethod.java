package UI_TestCases;



import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.PO_AgentList;
import pageObjects.PO_MailboxCreate;
import resources.ExcelData;
import resources.base;

public class agentListScreenTestMethod extends base{
    

    public ExcelData excelData = new ExcelData();
     
    //public WebDriver driver;
    
    @Test
    public void TestAgentListScreen(WebDriver driver,String role, int totalAgentCount) throws Exception {
        
        // Creating an object of the Page Object class.
        PO_AgentList agentListScreenObject = new PO_AgentList(driver);
        
        PO_MailboxCreate mailboxCreatePO = new PO_MailboxCreate(driver);
        
        
        mailboxCreatePO.selectProject("Digital-Finance-May");
        
        //Goint to the AgentList Screen.
        agentListScreenObject.goToAgentListScreen();
        
        
        
        // Assertions
        // ALS TC-01 : Check for all the UI components according to the zeplin screen provided and asserting the results
        Assert.assertEquals(agentListScreenObject.getCasesTile(), "Cases");
        Assert.assertEquals(agentListScreenObject.getGroupsTile(), "Groups");
        if(role.equals("admin")||role.equals("superAdmin"))Assert.assertEquals(agentListScreenObject.getMailboxTile(), "Mailbox");
        Assert.assertEquals(agentListScreenObject.getLogoutTile(), "Logout");
        Assert.assertTrue(agentListScreenObject.checkSearchIcon());
        Assert.assertEquals(agentListScreenObject.getAgentsHeader(), "Agents");
        Assert.assertEquals(agentListScreenObject.getListHeaderAgentName(), "Agent Name");
        Assert.assertEquals(agentListScreenObject.getListHeaderEmail(), "Email");
        Assert.assertEquals(agentListScreenObject.getListHeaderRole(), "Role");
        Assert.assertEquals(agentListScreenObject.getListHeaderGroup(), "Group");
        Assert.assertEquals(agentListScreenObject.getListHeaderLastLogin(), "Last Login");
        Assert.assertEquals(agentListScreenObject.getFilterIcon(), "Filters");
        
        
        
        // ALS TC-02 : Check that the Agent Tile on the left is selected.
        Assert.assertEquals(agentListScreenObject.getSelectedTile(),"Agents");
        
        
        // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-255
        Assert.assertEquals(agentListScreenObject.returnAgentCount(),totalAgentCount);
        
        
        // ALS TC-03 : Check that on clicking the Expand icon, it turns to collapse icon.
        Assert.assertTrue(agentListScreenObject.checkExpandCollapseIcon());
        
        
        
        // ALS TC-04 : Check If the Filter Icon is Clickable
        Assert.assertTrue(agentListScreenObject.isFilterIconClickable());
        
        
        
        // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-410
        // ALS TC-05 : Apply a filter and check if the results are correct.
        // ALS TC-06 : Apply a filter with no results and the "No agents found with the filter applied" screen appears.
        int filterRoleCount = agentListScreenObject.getDropDownListSize();
        
        // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-452
     //   Assert.assertTrue(agentListScreenObject.checkRequestorRole());
        
        
        for(int roleNumber=0; roleNumber<filterRoleCount; roleNumber++) {
            agentListScreenObject.applyFilter(roleNumber);
            int agentCount = agentListScreenObject.getAgentListSize();
            
            for(int i=0; i<agentCount; i++) {
                Assert.assertTrue(agentListScreenObject.checkFilterForAgent(i));
            }
            agentListScreenObject.refresh();
        }
        
        
        
        // ALS TC-07 : Check the Pagination buttons.
        Assert.assertTrue(agentListScreenObject.checkPrevArrow());
        Assert.assertTrue(agentListScreenObject.checkNextArrow());
        
        
        // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-410
        // ALS TC-08 : Apply a email filter and check if the result is correct.
        Assert.assertTrue(agentListScreenObject.applyEmailFilterAndCheck());
        
        
        // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-222
        Assert.assertTrue(agentListScreenObject.applyIncorrectEmailFilterAndCheck());
        
        
        
    }
}
