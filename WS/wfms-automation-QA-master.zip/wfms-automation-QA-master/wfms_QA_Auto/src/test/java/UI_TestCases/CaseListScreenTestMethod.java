package UI_TestCases;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.openqa.selenium.WebDriver;

import pageObjects.PO_CaseList;

public class CaseListScreenTestMethod{
    
    public void testCaseListScreen(WebDriver driver, String id, String role) throws IOException, InterruptedException {
        // Creating an object of the PO_CaseList class.
        PO_CaseList caseListScreenObject= new PO_CaseList(driver);
        
        caseListScreenObject.goToCaseListScreen();
        
        // CLS TC-01 : Check all the UI element according to the zeplin screen and assert the text.
        assertEquals(caseListScreenObject.getByjusLogoTagName(),"img");
        assertEquals(caseListScreenObject.getLogoutIconSidebarText(),"Logout");
        if(role.equals("requestor") == false) {
            assertEquals(caseListScreenObject.getExportBtnText(),"Export");
        }
        else {
            // Defect Id: https://byjustech.atlassian.net/browse/WFM-420
            assertFalse(caseListScreenObject.isExportButtonPresent());
        }
        assertEquals(caseListScreenObject.getFiltersBtnText(),"Filters");
        caseListScreenObject.clickSorterDropDown();
        assertTrue(caseListScreenObject.checkSortOptions());
        caseListScreenObject.clickSorterDropDown();

        // CLS TC-02 : Check "Create" button in the top right corner of the screen and assert the text.
        assertEquals(caseListScreenObject.getCreateButtonText(),"CREATE");

        // CLS TC-03 : Check "Cases" tile in the sidebar in the left of the screen and assert the text.
        assertEquals(caseListScreenObject.getCasesIconSidebarText(),"Cases");
        
        if(role.equals("requestor") == false) {
            // CLS TC-04 : Check "Groups" tile in the sidebar in the left of the screen and assert the text.
            assertEquals(caseListScreenObject.getGroupsIconSidebarText(),"Groups");
            
            // CLS TC-05 : Check the Global search icon in the top right corner of the screen and click on the icon.
            caseListScreenObject.getGlobalSearch();
            
            // CLS TC-06 : Click the Global search icon in the top right corner of the screen and Type an id, assert the suggestion.
            caseListScreenObject.typeInExpandedSearch(id);
        }
        
        // CLS TC-07 : Assert the tickets in the CaseList Screen.
        assertTrue(caseListScreenObject.checkFirstTicket());
        
        caseListScreenObject.goToCaseListScreen();
        
        // CLS TC-08 : Checking all the sort functionalities of the case list screen
        assertTrue(caseListScreenObject.checkSortNewToOld());
        assertTrue(caseListScreenObject.checkSortOldToNew());
        if(role.equals("requestor") == false) {
//            assertTrue(caseListScreenObject.checkSortLastModified());
        }
        assertTrue(caseListScreenObject.checkSortPriorityUrgentToLow());
        assertTrue(caseListScreenObject.checkSortPriorityLowToUrgent());
    }
}
