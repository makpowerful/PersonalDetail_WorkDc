package UI_TestCases;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import pageObjects.PO_CaseListTwo;
import resources.ExcelData;
import resources.base;

public class CaseListScreenTwoTestMethods extends base {
    
    public ExcelData excelData = new ExcelData();
    public WebDriver driver;
    String groupName = "QA_AutomationTesting"; // to run all test cases must save a group which is present in groups page
    
    public void runTests(WebDriver driver, String role) throws Exception {
        
        this.driver = driver;
        
        PO_CaseListTwo caseListPO = new PO_CaseListTwo(driver);
//        caseListPO.changeRole("digital-finance");
        caseListPO.goToCaseListPage();
        
        if(role.equals("agent") || role.equals("admin") || role.equals("supervisor")) {
           
            testBulkAssignFewTickets(); 
            
            testBulkAssignAllTickets();
            
            testBulkUpdateAllTickets();
            
            testBulkUpdateFewTickets();
        }
        
        testViewMyCases();  
    }
    
    @Test(priority=1, groups= {"ui"}, enabled=true)
    public void testGroupsScreen() throws Exception {
        
        driver = initializeDriver();
        
        LoginScreenTestMethods loginScreen = new LoginScreenTestMethods();
        loginScreen.login("ankur", driver);
        
        runTests(driver, "admin");
        
        driver.quit();
    }
    
    // CFS TC-17 : Select all tickets on a page and bulk assign them
    public void testBulkAssignAllTickets() {
        
        PO_CaseListTwo caseListPO = new PO_CaseListTwo(driver);
        
        List<String> ticketIds = caseListPO.getTicketIds();
        int ticketCount = ticketIds.size();
        
        if(ticketCount < 2)
            return;
        
        // select cases
        caseListPO.selectAllCases();
        
        // bulk update
        caseListPO.openBulkUpdateMenu();
        caseListPO.setBulkUpdateMenuGroup(groupName);
        String email1 = caseListPO.setBulkUpdateMenuAgent("");
        String email2 = caseListPO.setBulkUpdateMenuAgent("");
        caseListPO.clickUpdateButton();
        
        // check popup message
        assertEquals(caseListPO.getPopupMessage(), "Cases bulk updated successfully!");                
        caseListPO.closePopup();
        
        // verify result
        email2 = email2.split("-")[1];
        assertTrue(caseListPO.checkEmail(ticketIds, ticketIds.size(), email2));
        
        // select cases
        caseListPO.selectAllCases();
        
        // bulk assign
        caseListPO.openBulkAssignMenu();
        caseListPO.setBulkAssignMenuAgent(email1);
        caseListPO.clickUpdateButton();
        
        // check popup message
        assertEquals(caseListPO.getPopupMessage(), "Cases assigned successfully!");                
        caseListPO.closePopup();            
        
        // verify result
        email1 = email1.split("-")[1];
        assertTrue(caseListPO.checkEmail(ticketIds, ticketIds.size(), email1));
    }
    
    // CFS TC-16 : Assign agent using the bulk assign button and assert the result
    public void testBulkAssignFewTickets() {
        
        PO_CaseListTwo caseListPO = new PO_CaseListTwo(driver);
        
        List<String> ticketIds = caseListPO.getTicketIds();
        int ticketCount = Math.min(5, ticketIds.size());
        
        if(ticketCount < 2)
            return;
        
        // select cases
        for(int i = 0; i < ticketCount; ++i)
            caseListPO.selectCase(ticketIds.get(i));
        
        // bulk update
        caseListPO.openBulkUpdateMenu();
        caseListPO.setBulkUpdateMenuGroup(groupName);
        String email1 = caseListPO.setBulkUpdateMenuAgent("");
        String email2 = caseListPO.setBulkUpdateMenuAgent("");
        caseListPO.clickUpdateButton();
        
        // check message
        assertEquals(caseListPO.getPopupMessage(), "Cases bulk updated successfully!");                
        caseListPO.closePopup();
        
        // verify results
        email2 = email2.split("-")[1];
        assertTrue(caseListPO.checkEmail(ticketIds, ticketCount, email2));
        
        // select cases
        for(int i = 0; i < ticketCount; ++i)
            caseListPO.selectCase(ticketIds.get(i));
        
        // bulk assign
        caseListPO.openBulkAssignMenu();
        caseListPO.setBulkAssignMenuAgent(email1);
        caseListPO.clickUpdateButton();
        
        // check message
        assertEquals(caseListPO.getPopupMessage(), "Cases assigned successfully!");                
        caseListPO.closePopup();
        
        // verify result
        email1 = email1.split("-")[1];
        assertTrue(caseListPO.checkEmail(ticketIds, ticketCount, email1));
    }
    
    // CFS TC-18 : Bulk update case using the bulk update button and assert the result
    public void testBulkUpdateAllTickets() throws InterruptedException {
        
        PO_CaseListTwo caseListPO = new PO_CaseListTwo(driver);
        
        List<String> ticketIds = caseListPO.getTicketIds();
        int ticketCount = ticketIds.size();
        
        if(ticketCount < 2)
            return;
        
        // select cases
        caseListPO.selectAllCases();
        
        // bulk update
        caseListPO.openBulkUpdateMenu();
        String priority = caseListPO.setBulkUpdateMenuPriority("");
        String status = caseListPO.setBulkUpdateMenuStatus("");
        caseListPO.clickUpdateButton();
        
        // check popup message
        assertEquals(caseListPO.getPopupMessage(), "Cases bulk updated successfully!");                
        caseListPO.closePopup();            
        
        // verify result
        assertTrue(caseListPO.checkPriority(ticketIds, ticketCount, priority));
        assertTrue(caseListPO.checkStatus(ticketIds, ticketCount, status));
    }
    
    // CFS TC-19 : Select all tickets on a page and bulk update them
    public void testBulkUpdateFewTickets() throws InterruptedException {
        
        PO_CaseListTwo caseListPO = new PO_CaseListTwo(driver);
        
        // select some tickets and store their ticket ids
        List<String> ticketIds = caseListPO.getTicketIds();
        int ticketCount = Math.min(5, ticketIds.size());
        
        if(ticketCount < 2)
            return;
        
        // select cases
        for(int i = 0; i < ticketCount; ++i)
            caseListPO.selectCase(ticketIds.get(i));
        
        // bulk update
        caseListPO.openBulkUpdateMenu();
        String priority = caseListPO.setBulkUpdateMenuPriority("");
        String status = caseListPO.setBulkUpdateMenuStatus("");
        caseListPO.clickUpdateButton();
        
        // check popup message
        assertEquals(caseListPO.getPopupMessage(), "Cases bulk updated successfully!");                
        caseListPO.closePopup();    
        
        // verify result
        assertTrue(caseListPO.checkPriority(ticketIds, ticketCount, priority));
        assertTrue(caseListPO.checkStatus(ticketIds, ticketCount, status));
    }
    
    // CFS TC-20 : Click the my cases toggle and assert the results
    public void testViewMyCases() throws InterruptedException {
        
        PO_CaseListTwo caseListPO = new PO_CaseListTwo(driver);
        
        // toggle view my cases
        caseListPO.clickViewMyCasesCheckbox();
        
        List<String> ticketIds = caseListPO.getTicketIds();
        int ticketCount = Math.min(5, ticketIds.size());
        
        if(ticketCount == 0)
            return;
            
        String email = caseListPO.getEmail(ticketIds.get(0));
        for(int i = 0; i < ticketCount; ++i)
            assertEquals(caseListPO.getEmail(ticketIds.get(i)), email);
        
        driver.navigate().refresh();
    }
}
