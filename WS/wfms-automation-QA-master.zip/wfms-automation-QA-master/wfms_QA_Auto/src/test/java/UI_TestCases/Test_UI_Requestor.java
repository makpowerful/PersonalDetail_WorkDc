package UI_TestCases;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import resources.ExcelData;
import resources.base;

public class Test_UI_Requestor extends base {
    public WebDriver driver;
    private ArrayList<String> al = new ArrayList<String>();
    public ExcelData excelData = new ExcelData();
    private String username = Login;
    private String role = "requestor";
    private boolean check = false;
    
    @BeforeClass(groups= {"ui","regression"})
    public void initialize() throws Exception{
        driver = initializeDriver();
        if(!check) {
            al = excelData.getData(username, "emailId", "name");
            String emailId = al.get(1);
            
            String projectName = "digital-finance";
            
            List<String> rolesToAssign = new ArrayList<String>();
            rolesToAssign.add("requestor");
            
            UsersScreenTest obj = new UsersScreenTest();
            obj.changeUserRole(emailId, rolesToAssign, projectName, role, driver);
            check = true;
            driver = initializeDriver();
        }
    }
    
    @Test(priority=1,groups= {"ui","regression"}, enabled=true)
    public void testTicketFlow_Requestor() throws Exception {
        HashMap<String, String> ticketData;
        
        LoginScreenTestMethods loginScreen = new LoginScreenTestMethods();
        loginScreen.loginPageVerification(username, driver);
        
        CreateCasePageTestMethods createCasePageTestMethods = new CreateCasePageTestMethods();
        createCasePageTestMethods.testCreateCasePageUI(driver, role);
        createCasePageTestMethods.testCancelFunctionalityCreateCase(driver, role);
        ticketData = createCasePageTestMethods.testCreateNewCase(driver, role);
        
        CaseDetailsScreenTestMethods caseDetailsScreen = new CaseDetailsScreenTestMethods();
        caseDetailsScreen.testCaseDetailsScreen(driver, ticketData, role);
        
        CaseListScreenTestMethod caseListScreen = new CaseListScreenTestMethod();
        caseListScreen.testCaseListScreen(driver, ticketData.get("ticketId"), role);
        
        CaseFiltersScreenTestMethods caseFiltersScreen = new CaseFiltersScreenTestMethods();
        caseFiltersScreen.testCaseFiltersScreen(driver, ticketData, role);
    }

    @AfterClass(groups= {"ui","regression"})
    public void quitDriver() throws InterruptedException {
        driver.quit();
    } 
}
