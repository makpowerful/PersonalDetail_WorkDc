package UI_TestCases;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import resources.ExcelData;
import resources.base;

public class Test_UI_Admin extends base {
    public WebDriver driver;
    private ArrayList<String> al = new ArrayList<String>();
    public ExcelData excelData = new ExcelData();
    private String username = Login;
    private String role = "admin";
    private String mailId = "sfbtctest@gmail.com";
    private boolean check = false;
    public int agentCount;
    private String bodyContent;
    
    @BeforeClass(groups= {"ui","regression"})
    public void initialize() throws Exception{
        driver = initializeDriver();
        if(!check) {
            al = excelData.getData(username, "emailId", "name");
            String emailId = al.get(1);
            
            String projectName = "digital-finance";
            
            List<String> rolesToAssign = new ArrayList<String>();
            rolesToAssign.add("requestor");
            rolesToAssign.add(projectName+"-"+role);
            
            UsersScreenTest obj = new UsersScreenTest();
            agentCount = obj.changeUserRole(emailId, rolesToAssign, projectName, role, driver);
            driver = initializeDriver();
        }
        if(!check) {
            al = excelData.getData(username, "emailId", "name");
            String emailId = al.get(1);
            String password = al.get(2);
            
            InboundEmailViaGmailTestMethod inboundEmailViaGmail = new InboundEmailViaGmailTestMethod();
            bodyContent = inboundEmailViaGmail.createInboundEmailViaGmail(driver, emailId, password, mailId);
            al = excelData.getData("extraContent", "InboundEmail", "Tcid");
            bodyContent = bodyContent + "\n\n" + al.get(1);
            check = true;
            driver = initializeDriver();
        }
    }
    
    
    @Test(priority=8, groups= {"ui","regression"}, enabled=true)
    public void testTicketFlow_Admin() throws Exception {
        HashMap<String, String> ticketData;
        
        LoginScreenTestMethods loginScreen = new LoginScreenTestMethods();
        loginScreen.loginPageVerification(username, driver);
        
        CreateCasePageTestMethods createCasePageTestMethods = new CreateCasePageTestMethods();
        createCasePageTestMethods.testCreateCasePageUI(driver, role);
        createCasePageTestMethods.testCancelFunctionalityCreateCase(driver, role);
        ticketData = createCasePageTestMethods.testCreateNewCase(driver, role);
        
        CaseDetailsScreenTestMethods caseDetailsScreen = new CaseDetailsScreenTestMethods();
        caseDetailsScreen.testCaseDetailsScreen(driver, ticketData, role);
        caseDetailsScreen.testEditCase(driver, role, ticketData);
        
        TimeLineTestMethods timeLineTestMethods = new TimeLineTestMethods();
        timeLineTestMethods.testTimeLineFunctionality(ticketData, driver);
        
        CaseListScreenTestMethod caseListScreen = new CaseListScreenTestMethod();
        caseListScreen.testCaseListScreen(driver, ticketData.get("ticketId"), role);
        
        CaseFiltersScreenTestMethods caseFiltersScreen = new CaseFiltersScreenTestMethods();
        caseFiltersScreen.testCaseFiltersScreen(driver, ticketData, role);
        
        CaseListScreenTwoTestMethods caseListScreenTwoTestMethods = new CaseListScreenTwoTestMethods();
        caseListScreenTwoTestMethods.runTests(driver, role);
    }
    
    
    @Test(priority=9, groups= {"ui","regression"}, enabled=true)
    public void testGroupsScreen_Admin() throws Exception {

        
//        LoginScreenTestMethods loginScreen = new LoginScreenTestMethods();
//        loginScreen.login(username, driver);
        
        GroupsPageTestMethods groupsPageTestMethods = new GroupsPageTestMethods();
        groupsPageTestMethods.runTests(driver, role);
    }
    
    
    
    @Test(priority=10, groups= {"ui","regression"}, enabled=true)
    public void testMailboxFlow_Admin() throws Exception {

        HashMap<String, String> mailbox = new HashMap<>();
        
       // LoginScreenTestMethods loginScreen = new LoginScreenTestMethods();
        //loginScreen.login(username, driver);
        
        MailboxCreateScreenTestMethods mailboxCreateScreen = new MailboxCreateScreenTestMethods();
        mailbox = mailboxCreateScreen.testMailboxCreateScreen(driver);
        
        MailboxListScreenTestMethods mailboxListScreen = new MailboxListScreenTestMethods();
        mailboxListScreen.testMailboxListScreen(driver, mailbox);
    }
    
    
    
    @Test(priority=11, groups= {"ui","regression"}, enabled=true)
    public void testAgentListFlow_Admin() throws Exception {   

        
//        LoginScreenTestMethods loginScreen = new LoginScreenTestMethods();
//        loginScreen.login(username, driver);
        
        agentListScreenTestMethod obj = new agentListScreenTestMethod();
        obj.TestAgentListScreen(driver,role,agentCount);
        
    }
    
    @Test(priority=12, groups= {"ui","regression"}, enabled=true)
    public void testInboundEmail_Admin() throws Exception {   
        al = excelData.getData(username, "emailId", "name");
        String emailId = al.get(1);
        String password = al.get(2);
        
        InboundEmailViaGmailTestMethod inboundEmailViaGmail = new InboundEmailViaGmailTestMethod();
        inboundEmailViaGmail.testInboundEmailViaGmail(driver, emailId, password, mailId, bodyContent);
    }

    @AfterClass(groups= {"ui","regression"})
    public void quitDriver() throws InterruptedException {
        driver.quit();
    } 
}
