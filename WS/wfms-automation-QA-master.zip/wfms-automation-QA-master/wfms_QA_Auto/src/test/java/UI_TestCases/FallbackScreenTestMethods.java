package UI_TestCases;

import static org.testng.Assert.assertEquals;

import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pageObjects.PO_FallbackScreen;
import pageObjects.PO_LoginPage;
import resources.ExcelData;
import resources.base;

public class FallbackScreenTestMethods extends base {

    private ArrayList<String> al = new ArrayList<String>();
    public ExcelData excelData = new ExcelData();
    WebDriver driver;
    
    @BeforeMethod(alwaysRun=true)
    public void initialize() throws Exception{
        driver = initializeDriver();
        
        PO_LoginPage loginPageObject = new PO_LoginPage(driver);
        
        al = excelData.getData("ankur", "emailId", "name");
        String emailId = al.get(1);
        String password = al.get(2);
        loginPageObject.googleLogin(emailId, password);
    }
    
    @Test
    public void testFallbackScreens() {
        
        PO_FallbackScreen fallbackScreenPageObject = new PO_FallbackScreen(driver);
        
        driver.get(driver.getCurrentUrl() + "/abcde");
        
        String result = "";
        
        result = fallbackScreenPageObject.verifyBadRequestFallbackScreenUI();
        assertEquals(result, "", result);
    }
    
    @AfterMethod(alwaysRun=true)
    public void quitDriver() throws InterruptedException {
        Thread.sleep(5000);
        driver.quit();
    }
}
