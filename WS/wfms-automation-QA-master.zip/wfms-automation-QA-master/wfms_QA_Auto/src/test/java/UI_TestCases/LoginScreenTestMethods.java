package UI_TestCases;

import static org.testng.Assert.assertEquals;

import java.util.ArrayList;

import org.openqa.selenium.WebDriver;

import pageObjects.PO_LoginPage;
import resources.ExcelData;

public class LoginScreenTestMethods{
    
    private ArrayList<String> al = new ArrayList<String>();
    public ExcelData excelData = new ExcelData();
    
    public void loginPageVerification(String username, WebDriver driver) throws Exception {
        
        // Creating an object of the PO_LoginPage class.
        PO_LoginPage loginPageObject = new PO_LoginPage(driver);
        
        al = excelData.getData(username, "emailId", "name");
        String emailId = al.get(1);
        String password = al.get(2);
        
        loginPageObject.switchToLoginModuleIframe();
        
        // LS TC-01 : Check for the byjus logo image in the login screen and asserting the result
        assertEquals(loginPageObject.getByjusLogoTagName(), "img");
        
        // LS TC-02 : Check for the Welcome text in the login screen and asserting the result
        assertEquals(loginPageObject.getWelComeText(), "Welcome");
        
        // LS TC-03 : Check for the "Please sign in through your company mail" text in the login screen and asserting the result
        assertEquals(loginPageObject.getPleaseSignInThroughYourCompanyEmailText(), "Please sign in through your company mail");
        
        loginPageObject.switchToSignInWithGoogleButtonIframe();
        
        // LS TC-04 : Check for the "sign-in with google" button in the login screen and asserting the result
//        assertEquals(loginPageObject.getSignInWithGoogleButtonText(), "Sign in with Google");
        
        loginPageObject.switchToMainFrame();
        
        // Defect - https://byjustech.atlassian.net/browse/WFM-403
        // LS TC-05 : Sign-in with the "sign-in with google" button in the login screen
        loginPageObject.googleLogin(emailId, password);

        
    }
    
    public void login(String username, WebDriver driver) throws Exception {
        
        // Creating an object of the PO_LoginPage class.
        PO_LoginPage loginPageObject = new PO_LoginPage(driver);
        
        al = excelData.getData(username, "emailId", "name");
        String emailId = al.get(1);
        String password = al.get(2);
        
        loginPageObject.googleLogin(emailId, password);

        
    }
}
