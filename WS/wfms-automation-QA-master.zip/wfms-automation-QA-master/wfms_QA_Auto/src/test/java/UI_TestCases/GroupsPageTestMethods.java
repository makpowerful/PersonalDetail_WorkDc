package UI_TestCases;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import pageObjects.PO_CreateGroupPage;
import pageObjects.PO_GroupListPage;
import resources.ExcelData;
import resources.base;

public class GroupsPageTestMethods extends base {
    
    public ExcelData excelData = new ExcelData();
    public WebDriver driver;
    public String role;
    public String randomValue;
    
    public void runTests(WebDriver driver, String role) throws InterruptedException {
        
        this.driver = driver;
        this.role = role;
        
        PO_GroupListPage groupListPO = new PO_GroupListPage(driver);
//        groupListPO.changeRole("digital-finance-may");
        groupListPO.goToGroupListPage();
        
        testGroupListPageUI();
        
        if(role.equals("admin") || role.equals("supervisor")) {
    
            testCreateGroupPageUI();
            
            testCreateGroupPageFormValidation();
            
            testCreateNewGroup();
            
            testCreateDuplicateGroup();
            
            testUpdateGroup();
            
            // testUpdateGroupWithGroupNameNotAvailable();
        }
            
        testGroupListSortByFunctionality();
        
        testGroupNameFilter();
        
        testAgentNameFilter();
        
        // testAgentNameFilter2();
            
        if(role.equals("admin") || role.equals("supervisor")) {
            
            testCreatedAfterFilter();
        }
        
        testResetFilterButton();
        
        testNoGroupsFoundFallScreenUI();
    }
    
    @Test(priority=1, groups= {"ui"}, enabled=true)
    public void testGroupsScreen() throws Exception {
        
        driver = initializeDriver();
        
        LoginScreenTestMethods loginScreen = new LoginScreenTestMethods();
        loginScreen.login("ankur", driver);
        
        GroupsPageTestMethods groupsPageTestMethods = new GroupsPageTestMethods();
        groupsPageTestMethods.runTests(driver, "supervisor");
    }
    
    // GLP 01 : verify UI all components in group list page
    void testGroupListPageUI() {
        
        PO_GroupListPage groupListPO = new PO_GroupListPage(driver);
        
        Boolean FALSE = false;
        
        // sidebar
        assertTrue(groupListPO.getSidebarByjusLogoSource().contains("wfmslogo"));
        assertTrue(groupListPO.getSidebarCasesIconSource().contains("cases"));
        assertEquals(groupListPO.getSidebarCasesText(), "cases");
        assertTrue(groupListPO.getSidebarGroupsIconSource().contains("groups-selected"));
        assertEquals(groupListPO.getSidebarGroupsText(), "groups");
        assertTrue(groupListPO.getSidebarAgentsIconSource().contains("agents"));
        assertEquals(groupListPO.getSidebarAgentsText(), "agents");
        
        if(role.equals("admin")) {
         
            assertTrue(groupListPO.getSidebarMailboxIconSource().contains("mailbox"));
            assertEquals(groupListPO.getSidebarMailboxText(), "mailbox");
        }
        else {
            
            assertEquals(groupListPO.isSidebarMailboxIconPresent(), FALSE);
            assertEquals(groupListPO.isSidebarMailboxTextPresent(), FALSE);
        }
        
        assertTrue(groupListPO.getSidebarLogoutIconSource().contains("logout"));
        assertEquals(groupListPO.getSidebarLogoutText(), "logout");
        
        // header
        assertEquals(groupListPO.getHeaderGroupsText(), "groups");
        
        if(role.equals("agent")) {
            
            assertEquals(groupListPO.isHeaderCreateButtonPresent(), FALSE);
        }
        else {
         
            assertEquals(groupListPO.getHeaderCreateButtonText(), "create");
            assertTrue(groupListPO.getHeaderCreateButtonPlusIconSource().contains("add_icon"));
        }
        
        // toolbar
        assertEquals(groupListPO.getSortByDropdownLabel(), "sort by :");
        assertEquals(groupListPO.getSortByDropdownValue(), "date created - new to old");
        assertTrue(groupListPO.getLeftPaginationButtonIconSource().contains("chevronLeft"));
        assertTrue(groupListPO.getRightPaginationButtonIconSource().contains("chevronRight"));
        assertEquals(groupListPO.getFiltersButtonText(), "filters");
        assertTrue(groupListPO.getFiltersButtonFilterIconSource().contains("filtericon"));
        
        // Defect - https://byjustech.atlassian.net/browse/WFM-200
        // filters menu
        groupListPO.openFiltersMenu();
        assertEquals(groupListPO.getFiltersMenuHeaderText(), "filters");
        assertTrue(groupListPO.getFiltersMenuCrossIconSource().contains("close"));
        assertEquals(groupListPO.getGroupNameFieldLabel(), "group name");
        assertEquals(groupListPO.getGroupNameFieldPlaceholder(), "search group");
        assertEquals(groupListPO.getAgentNameFieldLabelText(), "agent name");
        assertEquals(groupListPO.getAgentNameFieldPlaceholderValue(), "search agent");
        assertEquals(groupListPO.getCreatedAfterFieldLabelText(), "created after");
        assertEquals(groupListPO.getCreatedAfterFieldPlaceholderValue(), "select date");
        assertEquals(groupListPO.getApplyButtonText(), "apply");
        assertEquals(groupListPO.getResetButtonText(), "reset");
        groupListPO.closeFiltersMenu();
    }
    
    // CGP 01 : verify UI of all components in create group page
    void testCreateGroupPageUI() throws InterruptedException {
        
        PO_CreateGroupPage createGroupPO = new PO_CreateGroupPage(driver);
        createGroupPO.goToCreateGroupPage();
        
        Boolean FALSE = false;
        
        // sidebar
        assertTrue(createGroupPO.getSidebarByjusLogoSource().contains("wfmslogo"));
        assertTrue(createGroupPO.getSidebarCasesIconSource().contains("cases"));
        assertEquals(createGroupPO.getSidebarCasesText(), "cases");
        assertTrue(createGroupPO.getSidebarGroupsIconSource().contains("groups-selected"));
        assertEquals(createGroupPO.getSidebarGroupsText(), "groups");
        assertTrue(createGroupPO.getSidebarAgentsIconSource().contains("agents"));
        assertEquals(createGroupPO.getSidebarAgentsText(), "agents");
        
        if(role.equals("admin")) {
            assertTrue(createGroupPO.getSidebarMailboxIconSource().contains("mailbox"));
            assertEquals(createGroupPO.getSidebarMailboxText(), "mailbox");
        }
        else {

            assertEquals(createGroupPO.isSidebarMailboxIconPresent(), FALSE);
            assertEquals(createGroupPO.isSidebarMailboxTextPresent(), FALSE);
        }
        
        assertTrue(createGroupPO.getSidebarLogoutIconSource().contains("logout"));
        assertEquals(createGroupPO.getSidebarLogoutText(), "logout");
        
        // header
        assertEquals(createGroupPO.getHeaderGroupsText(), "groups");
        assertEquals(createGroupPO.getHeaderCreateButtonText(), "create");
        assertTrue(createGroupPO.getHeaderCreateButtonPlusIconSource().contains("add_icon"));
        
        // labels
        assertTrue(createGroupPO.getGroupNameFieldLabelText().equals("group name"));
        assertTrue(createGroupPO.getGroupDescriptionFieldLabelText().equals("group description"));
        assertTrue(createGroupPO.getAddAgentsFieldLabelText().equals("add agents"));
        assertTrue(createGroupPO.getGroupPropertyFieldLabelText().equals("group property - escalation settings"));
        
        // placeholder values
        assertEquals(createGroupPO.getGroupNameFieldPlaceholderValue(), "enter here");
        assertEquals(createGroupPO.getGroupDescriptionFieldPlaceholderValue(), "enter here");
        assertEquals(createGroupPO.getGroupPropertyFieldPlaceholderValue(), "enter email id");
        assertEquals(createGroupPO.getAddAgentsFieldPlaceholderValue(), "search for agents");
        
        // asterisk after mandatory fields
        assertTrue(createGroupPO.isGroupNameMandatoryField());
        assertTrue(createGroupPO.isGroupPropertyMandatoryField());
        
        // defect - https://byjustech.atlassian.net/browse/WFM-239
        // field length
//        assertEquals(createGroupPO.getMaxLengthOfGroupNameField(), "50");
//        assertEquals(createGroupPO.getMaxLengthOfGroupDescriptionField(), "250");
        
        // save and cancel buttons
        assertTrue(createGroupPO.getSaveButtonText().equalsIgnoreCase("save"));
        assertTrue(createGroupPO.getCancelButtonText().equalsIgnoreCase("cancel"));  
        
        createGroupPO.clickCancelButton();
    }
    
    // CGP 02 : verify form validations in create group page
    void testCreateGroupPageFormValidation() {
        
        PO_CreateGroupPage createGroupPO = new PO_CreateGroupPage(driver);
        createGroupPO.goToCreateGroupPage();
        
        // check - save button is disabled when all fields are empty
        assertTrue(createGroupPO.isSaveButtonDisabled());
        
        // fill all non-mandatory fields then check - save buttton is still disabled
        createGroupPO.setGroupDescription("This group is created for testing purpose");
        createGroupPO.addAgents(createGroupPO.getAgentNames(1));
        assertTrue(createGroupPO.isSaveButtonDisabled());
        
        // now fill all mandatory fields then check - save button is enabled
        createGroupPO.SetGroupName("Test");
        createGroupPO.setGroupProperty("Test@byjus.com");
        assertTrue((createGroupPO.isSaveButtonEnabled()));
        
        // clear group name then check - save button is disabled
        createGroupPO.clearGroupName();
        assertTrue(createGroupPO.isSaveButtonDisabled());
        
        // fill group property with blanks then check - save button is disabled
        createGroupPO.SetGroupName("    ");
        assertTrue(createGroupPO.isSaveButtonDisabled());
        createGroupPO.SetGroupName("Test");
        
        // clear group property then check - save button is disabled
        createGroupPO.clearGroupProperty();
        assertTrue(createGroupPO.isSaveButtonDisabled());

        // fill group property with invalid value then - check save button is disabled & verify warning message
        createGroupPO.setGroupProperty("test@123");
        assertTrue(createGroupPO.isSaveButtonDisabled());
        assertEquals(createGroupPO.getGroupPropertyWarningMessage(), "please enter a valid email address");
        
        createGroupPO.clickCancelButton();
    }
    
    // CGP 03 : create a group successfully
    public void testCreateNewGroup() throws InterruptedException {
         
        PO_CreateGroupPage createGroupPO = new PO_CreateGroupPage(driver);
        createGroupPO.goToCreateGroupPage();
        
        // generate random data to fill the form
        randomValue = Long.toString(Instant.now().getEpochSecond());
        String groupName = "Test " + randomValue;
        String groupDescription = "This group is created for testing purpose";
        String groupProperty = "test@byjus.com";
        List<String> agentList = createGroupPO.getAgentNames(3);
        
        // fill the form with those randomly generated data
        createGroupPO.SetGroupName(groupName);
        createGroupPO.setGroupDescription(groupDescription);
        createGroupPO.addAgents(agentList);
        createGroupPO.setGroupProperty(groupProperty);
        
        // click save button
        createGroupPO.clickSaveButton();
        
        // verify successfully group created message
        assertTrue(createGroupPO.getPopupMessage().contains("group created successfully!"));
        createGroupPO.closePopup();
        
        // verify result on group list page
        PO_GroupListPage groupListPO = new PO_GroupListPage(driver);
        List<String> groupNames = groupListPO.getGroupNames();
        assertTrue(groupNames.contains(groupName));
        
        // defect - https://byjustech.atlassian.net/browse/WFM-286
        // groupListPO.openFiltersMenu();
        // groupListPO.setGroupName(groupName);
        // groupListPO.applyFilters();
        // groupNames = groupListPO.getGroupNames();
        // assertTrue(groupNames.contains(groupName));
        
        // verify result of create group page
        groupListPO.editGroup(groupName);
        assertEquals(createGroupPO.getGroupName(), groupName);
        assertEquals(createGroupPO.getGroupDescriptionValue(), groupDescription);
        assertEquals(createGroupPO.getGroupPropertyValue(), groupProperty);
        createGroupPO.clickCancelButton();
    }
    
    // CGP 04 : create already existing group
    public void testCreateDuplicateGroup() {
    
        PO_CreateGroupPage createGroupPO = new PO_CreateGroupPage(driver);
        createGroupPO.goToCreateGroupPage();
        
        // generate random data to fill the form
        String groupName = "Test " + randomValue;
        String groupDescription = "This group is created for testing purpose";
        String groupProperty = "Test@byjus.com";
        List<String> agentList = createGroupPO.getAgentNames(3);
        
        // fill the form with those randomly generated data
        createGroupPO.SetGroupName(groupName);
        createGroupPO.setGroupDescription(groupDescription);
        createGroupPO.setGroupProperty(groupProperty);
        createGroupPO.addAgents(agentList);
        
        // click save button
        createGroupPO.clickSaveButton();
        
        // Defect - https://byjustech.atlassian.net/browse/WFM-417
        // check if toast message is present
        assertTrue(createGroupPO.isToastPresent("This name is not available"));
        createGroupPO.clickCancelButton();
    }
    
    // CGP 05 : Update a group successfully
    public void testUpdateGroup() {
        
        PO_CreateGroupPage createGroupPO = new PO_CreateGroupPage(driver);
        PO_GroupListPage groupListPO = new PO_GroupListPage(driver);
        
        // edit a group
        groupListPO.editGroup("Test " + randomValue);
        
        // generate random data to fill the form
        randomValue = Long.toString(Instant.now().getEpochSecond());
        String groupName = "Test " + randomValue;
        String groupDescription = "This group is created for testing purpose";
        String groupProperty = "Test@byjus.com";
        List<String> agentList = createGroupPO.getAgentNames(3);
        
        // fill the form with those randomly generated data
        createGroupPO.SetGroupName(groupName);
        createGroupPO.setGroupDescription(groupDescription);
        createGroupPO.setGroupProperty(groupProperty);
        createGroupPO.addAgents(agentList);
        
        // click save button
        createGroupPO.clickUpdateButton();
        
        // verify successfully group updation message
        assertTrue(createGroupPO.getPopupMessage().contains("group updated successfully!"));
        createGroupPO.closePopup();
        
        // verify result on group list page
        List<String> groupNames = groupListPO.getGroupNames();
        assertTrue(groupNames.contains(groupName));
        
        // verify result of create group page
        groupListPO.editGroup(groupName);
        assertEquals(createGroupPO.getGroupName(), groupName);
        assertEquals(createGroupPO.getGroupDescriptionValue(), groupDescription);
        assertEquals(createGroupPO.getGroupPropertyValue(), groupProperty);
        
        // Defect - https://byjustech.atlassian.net/browse/WFM-426
        createGroupPO.clickCancelButton();
    }
    
    // defect - https://byjustech.atlassian.net/browse/WFM-428
    // CGP 05 : Update a group successfully
    public void testUpdateGroupWithGroupNameNotAvailable() {
        
        PO_CreateGroupPage createGroupPO = new PO_CreateGroupPage(driver);
        PO_GroupListPage groupListPO = new PO_GroupListPage(driver);
        
        // get names of all groups in current group list page
        List<String> groupNames = groupListPO.getGroupNames();
        
        // edit a group
        groupListPO.editGroup("Test " + randomValue);
        
        // generate random data to fill the form
        String groupName = groupNames.get(1 + new Random().nextInt(groupNames.size() - 1));
        
        // fill the form with those randomly generated data
        createGroupPO.SetGroupName(groupName);
        
        // click save button
        createGroupPO.clickUpdateButton();
        
        // check if toast message is present
        assertTrue(createGroupPO.isToastPresent("This name is not available"));
        createGroupPO.clickCancelButton();
    }
    
    // GLP 02 - Verify working of sort by feature
    public void testGroupListSortByFunctionality() {
        driver.navigate().refresh();
        PO_GroupListPage groupListPO = new PO_GroupListPage(driver);
        
        // get names of all groups in current group list page
        List<String> groupNamesAsc = groupListPO.getGroupNames();
        

        // change sort by dropdown value from "new to old" to "old to new"
        groupListPO.setSortByDropdownValue("old to new");
        
        // Defect - // Defect - https://byjustech.atlassian.net/browse/WFM-426
        groupListPO.goToLastPage();
        List<String> groupNamesDsc = groupListPO.getGroupNames();
        Collections.reverse(groupNamesDsc);
        
        // verify the result
        assertEquals(groupNamesAsc.get(0), groupNamesDsc.get(0));
    }
    
    // GLP 03 - Verfiy group name filter
    public void testGroupNameFilter() throws InterruptedException {
        
        PO_GroupListPage groupListPO = new PO_GroupListPage(driver);
        
        // slect any one random group name
        List<String> groupNames = groupListPO.getGroupNames();
        
        if(groupNames.size() == 0)
            return;
         
        String groupName = groupNames.get(new Random().nextInt(groupNames.size()));
        
        // set group name field value in filters menu
        groupListPO.openFiltersMenu();
        groupListPO.setGroupName(groupName);
        groupListPO.applyFilters();
        
        // get name of all groups present on group list page after applying the filter
        List<String> filteredGroupNames = groupListPO.getGroupNames();
        
        // verify the results
        for(int i = 0; i < filteredGroupNames.size(); ++i) {
            System.out.println(filteredGroupNames.get(i));
            assertTrue(filteredGroupNames.get(i).contains(groupName));
        }
        
        // reset filters
        groupListPO.openFiltersMenu();
        groupListPO.resetFilters();
    }
    
    // Defect - https://byjustech.atlassian.net/browse/WFM-208
    // GLP 04 - Verify agent name filter
    public void testAgentNameFilter() {
        
        PO_GroupListPage groupListPO = new PO_GroupListPage(driver);
        
        List<String> groupNames = groupListPO.getGroupNames();
        
        if(groupNames.size() > 0) {
            
            List<String> agentNames = new ArrayList<String>();
            
            while(agentNames.size() == 0) {
                
                String groupName = groupNames.get(new Random().nextInt(groupNames.size()));
                agentNames = groupListPO.getAgentNames(groupName);
            }
            
            // select an agent name
            String agentName = agentNames.get(new Random().nextInt(agentNames.size()));
        
            // set agent name field value in filters menu
            groupListPO.openFiltersMenu();
            groupListPO.setAgentName(agentName);
            groupListPO.applyFilters();
            
            // verify the results
            groupNames = groupListPO.getGroupNames();
            for(int i = 0; i < groupNames.size(); ++i)
                assertTrue(groupListPO.getAgentNames(groupNames.get(i)).contains(agentName));
            
            // reset filters
            groupListPO.openFiltersMenu();
            groupListPO.resetFilters();
        }
    }
    
    // Defect - https://byjustech.atlassian.net/browse/WFM-202
    public void testAgentNameFilter2() {
        
        PO_GroupListPage groupListPO = new PO_GroupListPage(driver);
        
        // set agent name field value in filters menu
        groupListPO.openFiltersMenu();
        groupListPO.setAgentName("a");
        groupListPO.applyFilters();
        
        // verify the results
        List<String> groupNames = groupListPO.getGroupNames();
        for(int i = 1; i < groupNames.size(); i += 2) {
            
            if(groupNames.get(i).equals(groupNames.get(i - 1))) {
               
                assertTrue(false);
                break;
            }
        }
        
        // reset filters
        groupListPO.openFiltersMenu();
        groupListPO.resetFilters();
    }
    
    // GLP 05 - verify created after filter
    public void testCreatedAfterFilter() {
        
        PO_GroupListPage groupListPO = new PO_GroupListPage(driver);
        
        // set current date in current date filter
        groupListPO.openFiltersMenu();
        groupListPO.setCreatedAfter();
        groupListPO.applyFilters();
        
        // verify results
        String groupName = "Test " + randomValue;
        assertTrue(groupListPO.getGroupNames().contains(groupName));
        
        // reset filters
        groupListPO.openFiltersMenu();
        groupListPO.resetFilters();
    }
    
    // GLP 06 - Test reset filters button
    public void testResetFilterButton() {
        
        PO_GroupListPage groupListPO = new PO_GroupListPage(driver);
        
        // get name of all the groups on current page
        List<String> oldGroupNames = groupListPO.getGroupNames();
        
        // open filters menu
        groupListPO.openFiltersMenu();
        
        // apply some filters
        String randomValue = Long.toString(Instant.now().getEpochSecond());
        groupListPO.setGroupName(randomValue);
        groupListPO.applyFilters();
        
        // reset filters
        groupListPO.openFiltersMenu();
        groupListPO.resetFilters();
        
        // get name of all the groups on current page
        List<String> newGroupNames = groupListPO.getGroupNames();
        
        int n = oldGroupNames.size();
        int m = newGroupNames.size();
        
        // verify the results
        for(int i = 0; i < n && i < m; ++i)
            assertTrue(oldGroupNames.get(i).equalsIgnoreCase(newGroupNames.get(i)));
        
        groupListPO.openFiltersMenu();
        assertEquals(groupListPO.getGroupName(), "");
        assertEquals(groupListPO.getAgentNameValue(), "");
        assertEquals(groupListPO.getCreateAfter(), "");
        groupListPO.closeFiltersMenu();
    } 
    
    // GLP 07 - Verify UI on no groups screen
    public void testNoGroupsFoundFallScreenUI() throws InterruptedException {
        
        PO_GroupListPage groupListPO = new PO_GroupListPage(driver);
        
        // apply some filters
        groupListPO.openFiltersMenu();
        String randomValue = Long.toString(Instant.now().getEpochSecond());
        groupListPO.setGroupName(randomValue);
        groupListPO.applyFilters();
        
        // verify ui component
        assertEquals(groupListPO.getPaginatiorText(),"showing 0 - 0 of 0 groups");
        assertTrue(groupListPO.getNoGroupsScreenImageSource().contains("norecordfound"));
        assertEquals(groupListPO.getNoGroupsScreenText(),"no groups found with the filter applied");
        
        driver.navigate().refresh();
    }
}
