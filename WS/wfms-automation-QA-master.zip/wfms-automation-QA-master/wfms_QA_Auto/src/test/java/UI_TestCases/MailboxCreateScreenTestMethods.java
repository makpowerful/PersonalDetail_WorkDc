package UI_TestCases;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;

import pageObjects.PO_MailboxCreate;
import resources.ExcelData;

public class MailboxCreateScreenTestMethods {
    protected static ExcelData excelData = new ExcelData();
    protected static ArrayList<String> al = new ArrayList<String>();
    
    public HashMap<String, String> testMailboxCreateScreen(WebDriver driver) throws Exception {
        
        PO_MailboxCreate mailboxCreatePO = new PO_MailboxCreate(driver);
        HashMap<String, String> mailbox = new HashMap<>();
        
        mailboxCreatePO.selectProject("Digital-Finance-May");
        
        mailboxCreatePO.goToMailboxCreateScreen();
        
        // MCS TC-01: Check for all the UI components according to the zeplin screen provided and asserting the results
        // MCS TC-02: Check that the mailbox left side menu icon is selected
        
        assertEquals(mailboxCreatePO.getHeaderText(), "Mailbox");
        assertEquals(mailboxCreatePO.getCreateBtn(), "CREATE");
        assertEquals(mailboxCreatePO.getCasesIcon(), "Cases");
        assertEquals(mailboxCreatePO.getGroupsIcon(), "Groups");
        assertEquals(mailboxCreatePO.getAgentsIcon(), "Agents");
        assertEquals(mailboxCreatePO.getLogoutIcon(), "Logout");
        assertEquals(mailboxCreatePO.getMailboxIcon(), "Mailbox");
        assertTrue(mailboxCreatePO.checkCLickableSearchBar());
        assertTrue(mailboxCreatePO.checkCLickableSearchBarInput());
        assertEquals(mailboxCreatePO.getTitleText(), "Mailbox Settings");
        assertEquals(mailboxCreatePO.getNameLabel(), "Name");
        assertEquals(mailboxCreatePO.getEmailLabel(), "Your support email");
        assertEquals(mailboxCreatePO.getPasswordLabel(), "Mailbox Token id");
        assertEquals(mailboxCreatePO.getAssignToGroupLabel(), "Assign to Group");
        assertEquals(mailboxCreatePO.getNameInputPlaceholder(), "Enter Name");
        assertEquals(mailboxCreatePO.getEmailInputPlaceholder(), "Enter your email address");
        assertEquals(mailboxCreatePO.getPasswordInputPlaceholder(), "Enter your mailbox token id here");
        assertEquals(mailboxCreatePO.getGroupDropdownLabel(), "Select Group");
        
        // MCS TC-03: Create a mailbox and assert that the mailbox is created
        
        mailbox = mailboxCreatePO.createRandomMailbox();
        assertEquals(mailbox.get("successfulMessage"), "Mailbox added successfully!");
        
        // Defect Id: https://byjustech.atlassian.net/browse/WFM-225
        assertTrue(mailboxCreatePO.checkSpecificMailbox(mailbox));
        
        // MCS TC-04: Create a mailbox that is already created and assert the error message
        mailboxCreatePO.goToMailboxCreateScreen();
        assertEquals(mailboxCreatePO.checkDuplicateMailbox(mailbox), "email already registered for an existing mailbox");
        
        // MCS TC-05: Check the cancel functionality of the cancel button
        mailboxCreatePO.clickCancelBtn();
        mailboxCreatePO.goToMailboxCreateScreen();
        assertEquals(mailboxCreatePO.getNameInputPlaceholder(), "Enter Name");
        assertEquals(mailboxCreatePO.getEmailInputPlaceholder(), "Enter your email address");
        assertEquals(mailboxCreatePO.getPasswordInputPlaceholder(), "Enter your mailbox token id here");
        assertEquals(mailboxCreatePO.getGroupDropdownLabel(), "Select Group");
        
        // MCS TC-06: Enter wrong email id format in the email input field and check the error message
        mailboxCreatePO.goToMailboxCreateScreen();
        assertEquals(mailboxCreatePO.checkWrongEmailErrorMessage(), "Please enter a valid email address");
        
        // Defect Id: https://byjustech.atlassian.net/browse/WFM-241
        assertFalse(mailboxCreatePO.isErrorMessageStillPresent());
        
        return mailbox;
    }
}
