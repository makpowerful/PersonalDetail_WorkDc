package UI_TestCases;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import pageObjects.PO_CreateCaseDigitalFinance;
import pageObjects.PO_CreateCasePage;
import pageObjects.PO_LoginPage;
import resources.ExcelData;
import resources.base;

public class CreateCasePageTestMethods extends base {

    private ArrayList<String> al = new ArrayList<String>();
    public ExcelData excelData = new ExcelData();
    public WebDriver driver;
    public String role;
    public HashMap<String, String> ticketData;

    @BeforeClass(alwaysRun = true)
    void init() {

        try {

            driver = initializeDriver();
            PO_LoginPage loginPageObject = new PO_LoginPage(driver);

            al = excelData.getData("ankur", "emailId", "name");
            String emailId = al.get(1);
            String password = al.get(2);

            loginPageObject.googleLogin(emailId, password);

            role = "admin";

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    // CCFS_01 : Check sidebar and header components
    public void testCreateCasePageUI(WebDriver driver, String role) {

        PO_CreateCasePage createCasePO = new PO_CreateCasePage(driver);
        if (!role.equals("requestor")) {

            createCasePO.changeRole("digital-finance-may");
        }
        createCasePO.goToCreateCasePage();

        Boolean FALSE = false;

        // sidebar
        assertTrue(createCasePO.getSidebarByjusLogoSource().contains("wfmslogo"));
        assertTrue(createCasePO.getSidebarCasesIconSource().contains("cases-selected"));
        assertEquals(createCasePO.getSidebarCasesText(), "cases");

        if (role.equals("requestor")) {

            assertEquals(createCasePO.isSidebarGroupsIconPresent(), FALSE);
            assertEquals(createCasePO.isSidebarGroupsTextPresent(), FALSE);
            assertEquals(createCasePO.isSidebarAgentsIconPresent(), FALSE);
            assertEquals(createCasePO.isSidebarAgentsTextPresent(), FALSE);
        } else {

            assertTrue(createCasePO.getSidebarGroupsIconSource().contains("groups"));
            assertEquals(createCasePO.getSidebarGroupsText(), "groups");
            assertTrue(createCasePO.getSidebarAgentsIconSource().contains("agents"));
            assertEquals(createCasePO.getSidebarAgentsText(), "agents");
        }

        if (role.equals("admin")) {

            assertTrue(createCasePO.getSidebarMailboxIconSource().contains("mailbox"));
            assertEquals(createCasePO.getSidebarMailboxText(), "mailbox");
        } else {

            assertEquals(createCasePO.isSidebarMailboxIconPresent(), FALSE);
            assertEquals(createCasePO.isSidebarMailboxTextPresent(), FALSE);
        }

        assertTrue(createCasePO.getSidebarLogoutIconSource().contains("logout"));
        assertEquals(createCasePO.getSidebarLogoutText(), "logout");

        // header
        assertEquals(createCasePO.getHeaderCasesText(), "cases");
        assertEquals(createCasePO.getHeaderCreateButtonText(), "create");
        assertTrue(createCasePO.getHeaderCreateButtonPlusIconSource().contains("Add_Icon"));

        // defect - https://byjustech.atlassian.net/browse/WFM-405
        // buttons
        // assertEquals(createCasePO.getCreateButtonText(), "Create");
        // assertEquals(createCasePO.getCancelButtonText(), "Cancel");
    }
    
    // CCFS_06 : Check the cancel functionality of the create case page
    public void testCancelFunctionalityCreateCase(WebDriver driver, String role) throws InterruptedException {
        PO_CreateCasePage createCasePO = new PO_CreateCasePage(driver);

        createCasePO.goToCreateCasePage();
        PO_CreateCaseDigitalFinance createCaseDigitalFinancePO = new PO_CreateCaseDigitalFinance(driver);
        createCaseDigitalFinancePO.fillForm(false);
        createCasePO.clickCancelButton();
        assertFalse(createCasePO.getCurrentUrl());
    }

    // CCFS_02 : Create a new case successfully
    public HashMap<String, String> testCreateNewCase(WebDriver driver, String role) throws InterruptedException {

        PO_CreateCasePage createCasePO = new PO_CreateCasePage(driver);

        // if(!role.equals("requestor"))
        // createCasePO.changeRole("digital-finance-may");

        createCasePO.goToCreateCasePage();

        PO_CreateCaseDigitalFinance createCaseDigitalFinancePO = new PO_CreateCaseDigitalFinance(driver);
        return createCaseDigitalFinancePO.fillForm(true);

        // defect - https://byjustech.atlassian.net/browse/WFM-430
        // assertTrue(createCasePO.getProject(), "digital-finance-may");
    }

    @AfterClass(alwaysRun = true)
    public void quitDriver() {

//        driver.quit();
    }
}
