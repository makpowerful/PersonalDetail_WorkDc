package UI_TestCases;

import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import pageObjects.PO_TimeLine;
import resources.base;



public class TimeLineTestMethods extends base{
    
    @Test
    public void testTimeLineFunctionality(HashMap<String, String> ticketData, WebDriver driver) throws Exception {
        // creating an object of PO_TimeLine class.
        PO_TimeLine obj = new PO_TimeLine(driver);
        obj.setName();
        
        // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-260
        // CDS TC-07 : Update the case status using the properties side menu and check the timeline.
        obj.timeLineForStatus(ticketData);
        
        // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-260
        // CDS TC-08 : Update the case Priority using the properties side menu and check the timeline.
        obj.timeLineForPriority(ticketData);
        
        // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-359
        // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-260
        // CDS TC-09 : Update the case Date using the properties side menu and check the timeline.
        obj.timeLineForDate(ticketData);
        
        // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-260
        // CDS TC-11 : Update the case Group using the properties side menu and check the timeline.
        // CDS TC-10 : Update the case Agent using the properties side menu and check the timeline.
        obj.timeLineForGroupAndAgent(ticketData);
        
    }
}
