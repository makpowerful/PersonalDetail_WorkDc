package testCases;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import payLoad.Payload_TicketController;
import resources.base;

public class Test_TicketController extends base {
    private int id;
    private String sheetName = "TicketCreation_API";
    private int limit = 1, offset = 1, negativeNum = -1;
    private int wrongId = -145;
    private static SoftAssert softAssert = new SoftAssert();
    public static Logger log = LogManager.getLogger(Test_TicketController.class.getName());
    private String role;

    @BeforeClass(alwaysRun = true)
    @Parameters({ "sessionToken", "role", "projectId" })
    public void setToken(String sessionToken, String role, String projectId) {
        this.role = role;
        Payload_TicketController.setHeaderMap(projectId, sessionToken);
    }

    // CTA TC-01: Hitting the API then checking the status code and response
    // validation
    // Defect Id: https://byjustech.atlassian.net/browse/WFM-394

    @Test(priority = 1, groups = { "ticketController", "api", "regression" })
    public void createTicket() throws IOException {

        Response response = Payload_TicketController.postTicketControllerResponse("POST", sheetName);
        response.then().assertThat().statusCode(201);
        JsonPath js = Payload_TicketController.getJsonPath(response);

        // Assertion for this Test
        assertEquals(js.getInt("code"), 20100);
        softAssert.assertEquals(js.getString("message"), "ticket created successfully", "message createTicket");
        id = js.getInt("data.ticketId");

        log.info("Response of createTicket is: " + response.asString());
    }
    
    // Defect Id: https://byjustech.atlassian.net/browse/WFM-229

    @Test(priority = 1, groups = { "ticketController", "api", "regression" })
    public void createTicketWrongRequestBody() throws IOException {

        Response response = Payload_TicketController.postTicketControllerResponseWrongBody("POST", sheetName);
        response.then().assertThat().statusCode(400);
        JsonPath js = Payload_TicketController.getJsonPath(response);

        // Assertion for this Test
        assertEquals(js.getInt("code"), 40000);

        log.info("Response of createTicket is: " + response.asString());
    }


    // CTA TC-06: Sending string as value in projectId field, which requires an
    // integer value

    @Test(priority = 1, groups = { "ticketController", "api", "regression" })
    public void createTicketStringId() throws IOException {
        Response response = Payload_TicketController.postTicketControllerResponse("POST_Wrong_Id", sheetName);
        response.then().assertThat().statusCode(400);
        JsonPath js = Payload_TicketController.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("status"), 400, "checking status code");
        softAssert.assertEquals(js.getString("error"), "Bad Request", "checking error message");
        softAssert.assertEquals(js.getString("path"), "/wfms-ticket-service/api/v1/tickets", "checking path field");

        log.info("Response of createTicketStringId is: " + response.asString());
    }

    // CTA TC-02: Hitting the API then checking the status code and response
    // validation

    @Test(priority = 2, groups = { "ticketController", "api", "regression" })
    public void testUpdateTicket() throws IOException {
        Response response = Payload_TicketController.putTicketControllerResponse(id, "PUT", sheetName);
        JsonPath js = Payload_TicketController.getJsonPath(response);

        // Assertion for this Test
        if (role.equals("supervisor") || role.equals("projectAdmin") || role.equals("superAdmin")
                || role.equals("agent")) {
            response.then().assertThat().statusCode(200);
            assertEquals(js.getInt("code"), 20102);
            softAssert.assertEquals(js.getString("message"), "ticket updated successfully",
                    "message 200 testUpdateTicket");
            softAssert.assertEquals(js.getInt("data.ticketId"), id, "id 200 testUpdateTicket");
        } else if (role.equals("requester")) {
            response.then().assertThat().statusCode(403);
            softAssert.assertEquals(js.getString("message"), "Not authorised to perform action on this resource",
                    "message 403 testUpdateTicket");
        }
        log.info("Response of testUpdateTicket is: " + response.asString());
    }

    // CTA TC-05: Update a ticket with wrong id

    @Test(priority = 2, groups = { "ticketController", "api", "regression" })
    public void testUpdateTicketWrongId() throws IOException {
        Response response = Payload_TicketController.putTicketControllerResponse(wrongId, "PUT", sheetName);
        JsonPath js = Payload_TicketController.getJsonPath(response);

        // Assertion for this Test
        response.then().assertThat().statusCode(404);
        assertEquals(js.getInt("code"), 40003);
        softAssert.assertEquals(js.getString("message"),
                "exception while updating ticket for ticketId: "
                        + Integer.toString(wrongId)
                        + ",with exception: invalid ticketId/externalSourceId: " + Integer.toString(wrongId),
                "checking for error message testUpdateTicketWrongId");

        log.info("Response of testUpdateTicketWrongId is: " + response.asString());
    }
    
    // Defect Id: https://byjustech.atlassian.net/browse/WFM-357

    @Test(priority = 2, groups = { "ticketController", "api", "regression" })
    public void testUpdateTicketWrongAgent() throws IOException {
        Response response = Payload_TicketController.putTicketControllerResponse(id, "PUT_Wrong_Agent", sheetName);
        JsonPath js = Payload_TicketController.getJsonPath(response);

        // Assertion for this Test
        if (role.equals("supervisor") || role.equals("projectAdmin") || role.equals("superAdmin")
                || role.equals("agent")) {
            response.then().assertThat().statusCode(404);
            assertEquals(js.getInt("code"), 40003);
            softAssert.assertEquals(js.getString("message"),
                    "exception while updating ticket for ticketId: "
                            + Integer.toString(id)
                            + ",with exception: exception in configuration service get group call",
                    "checking for error message testUpdateTicketWrongAgent");
        } else if (role.equals("requester")) {
            response.then().assertThat().statusCode(403);
            softAssert.assertEquals(js.getString("message"), "Not authorised to perform action on this resource",
                    "message 403 testUpdateTicket");
        }
        

        log.info("Response of testUpdateTicketWrongAgent is: " + response.asString());
    }

    // CTA TC-13 Update multiple tickets at once using this API and check for the
    // status code
    // Defect Id: https://byjustech.atlassian.net/browse/WFM-402

    @Test(priority = 2, groups = { "ticketController", "api", "regression" })
    public void testBulkUpdateTicket() throws IOException {
        ArrayList<Integer> ids = new ArrayList<>();
        ids.add(id);
        ids.add(id);
        ids.add(id);
        Response response = Payload_TicketController.bulkUpdateTicketControllerResponse(ids, "PUT", sheetName);
        JsonPath js = Payload_TicketController.getJsonPath(response);

        // Assertion for this Test
        if (role.equals("supervisor") || role.equals("projectAdmin") || role.equals("superAdmin")
                || role.equals("agent")) {
            response.then().assertThat().statusCode(200);
            assertEquals(js.getInt("code"), 20103);
            softAssert.assertEquals(js.getString("message"), "tickets updated successfully",
                    "message 200 testBulkUpdateTicket");
            softAssert.assertEquals(js.getInt("data.ids[0]"), id, "id 200 testBulkUpdateTicket");
        } else if (role.equals("requester")) {
            response.then().assertThat().statusCode(403);
            softAssert.assertEquals(js.getString("message"), "Not authorised to perform action on this resource",
                    "message 403 testBulkUpdateTicket");
        }
        log.info("Response of testBulkUpdateTicket is: " + response.asString());
    }

    // CTA TC-14 Update multiple tickets at once with invalid ticketIds using this
    // API and check for the status code
    // Defect Id: https://byjustech.atlassian.net/browse/WFM-120

    @Test(priority = 2, groups = { "ticketController", "api", "regression" })
    public void testBulkUpdateTicketInvalidIds() throws IOException {
        ArrayList<Integer> ids = new ArrayList<>();
        ids.add(-12);
        ids.add(-1);
        ids.add(-2);
        Response response = Payload_TicketController.bulkUpdateTicketControllerResponse(ids, "PUT", sheetName);
        JsonPath js = Payload_TicketController.getJsonPath(response);

        // Assertion for this Test

        response.then().assertThat().statusCode(400);
        assertEquals(js.getInt("code"), 40000);
        softAssert.assertEquals(js.getString("message"), "no ticket updated ",
                "message testBulkUpdateTicketInvalidIds");

        log.info("Response of testBulkUpdateTicketInvalidIds is: " + response.asString());
    }

    // CTA TC-15 Update no ticket using this API, send an empty array in the
    // ticketIds field and check for the status code
    // Defect Id: https://byjustech.atlassian.net/browse/WFM-120

    @Test(priority = 2, groups = { "ticketController", "api", "regression" })
    public void testBulkUpdateNoTicket() throws IOException {
        ArrayList<Integer> ids = new ArrayList<>();
        Response response = Payload_TicketController.bulkUpdateTicketControllerResponse(ids, "PUT", sheetName);
        JsonPath js = Payload_TicketController.getJsonPath(response);

        // Assertion for this Test
        response.then().assertThat().statusCode(400);
        assertEquals(js.getInt("code"), 40000);
        softAssert.assertEquals(js.getString("message"), "no ticket updated ", "message testBulkUpdateNoTicket");

        log.info("Response of testBulkUpdateNoTicket is: " + response.asString());
    }

    // CTA TC-03: Hitting the API and checking the status code + response validation

    @Test(priority = 3, groups = { "ticketController", "api", "regression" })
    public void getTicketId() {
        Response response = Payload_TicketController.getTicketControllerResponse(id);
        response.then().assertThat().statusCode(200);
        JsonPath js = Payload_TicketController.getJsonPath(response);

        // Assertion for this Test
        assertEquals(js.getInt("code"), 20105);
        softAssert.assertEquals(js.getString("message"), "get tickets successful", "message getTicketId");
        softAssert.assertEquals(js.getInt("data.tickets[0].id"), id);
        log.info("Response of getTicketId is: " + response.asString());

    }

    // CTA TC-07: Fetching a ticket with wrong id as path parameter

    @Test(priority = 3, groups = { "ticketController", "api", "regression" })
    public void getTicketWrongId() {
        Response response = Payload_TicketController.getTicketControllerResponse(wrongId);
        response.then().assertThat().statusCode(404);
        JsonPath js = Payload_TicketController.getJsonPath(response);

        // Assertion for this Test
        assertEquals(js.getInt("code"), 40003);
        softAssert.assertEquals(js.getString("message"),
                "invalid ticketId/externalSourceId: " + Integer.toString(wrongId),
                "message getTicketWrongId");
        log.info("Response of getTicketWrongId is: " + response.asString());

    }

    // CTA TC-10: Hitting the API then checking the status code and response
    // validation

//    @Test(priority = 3, groups = { "ticketController", "api","regression" })
//    public void getTicketsLimitOffset() {
//        Response response = Payload_TicketController.getLimitOffsetTicketControllerResponse(limit, offset);
//        JsonPath js = Payload_TicketController.getJsonPath(response);
//
//        // Assertion for this Test
//        if(role.equals("supervisor") || role.equals("projectAdmin") || role.equals("superAdmin") || role.equals("agent")) {
//            response.then().assertThat().statusCode(200);
//            assertEquals(js.getInt("code"), 20105);
//            softAssert.assertEquals(js.getString("message"), "get tickets successful", "message getTicketsLimitOffset");
//            softAssert.assertEquals(js.getInt("data.tickets.size()"), limit, "check number of tickets returned");
//        }
//        else if (role.equals("requester")) {
//            response.then().assertThat().statusCode(403);
//            softAssert.assertEquals(js.getString("message"),"Not authorised to perform action on this resource","message 403 testUpdateTicket");
//        }
//        
//        log.info("Response of getTicketsLimitOffset is: " + response.asString());
//
//    }

    // CTA TC-11: Checking the number of tickets returned and the number of pages

//    @Test(priority = 3, groups = { "ticketController", "api","regression" })
//    public void getTicketsNumTickets() {
//        Response response = Payload_TicketController.getLimitOffsetTicketControllerResponse(limit, offset);
//        JsonPath js = Payload_TicketController.getJsonPath(response);
//
//        // Assertion for this Test
//        if(role.equals("supervisor") || role.equals("projectAdmin") || role.equals("superAdmin") || role.equals("agent")) {
//            response.then().assertThat().statusCode(200);
//            assertEquals(js.getInt("code"), 20105);
//            softAssert.assertEquals(js.getString("message"), "get tickets successful", "message getTicketsNumTickets");
//            softAssert.assertEquals(js.getInt("data.pageSize"), limit, "check for page size");
//        }
//        else if (role.equals("requester")) {
//            response.then().assertThat().statusCode(403);
//            softAssert.assertEquals(js.getString("message"),"Not authorised to perform action on this resource","message 403 testUpdateTicket");
//        }
//        
//        log.info("Response of getTicketsNumTickets is: " + response.asString());
//
//    }

    // CTA TC-12: Sending negative number in the limit and offset parameter

    @Test(priority = 3, groups = { "ticketController", "api", "regression" })
    public void getTicketsLimitOffsetNegativeNum() {
        Response response = Payload_TicketController.getLimitOffsetTicketControllerResponse(negativeNum, negativeNum);
        JsonPath js = Payload_TicketController.getJsonPath(response);

        // Assertion for this Test
        response.then().assertThat().statusCode(404);
        assertEquals(js.getInt("code"), 40003);
        softAssert.assertEquals(js.getString("message"), "exception in getTickets while fetching paginated tickets",
                "message getTicketsLimitOffsetNegativeNum");

        log.info("Response of getTicketsLimitOffsetNegativeNum is: " + response.asString());

    }

    // CTA TC-04: Hitting the API and checking the status code + response validation

    @Test(priority = 4, dependsOnMethods = { "createTicket" }, groups = { "ticketController", "api", "regression" })
    public void testDeleteTicket() {
        Response response = Payload_TicketController.deleteTicketControllerResponse(id);
        response.then().assertThat().statusCode(200);
        JsonPath js = Payload_TicketController.getJsonPath(response);

        // Assertion for this Test
        assertEquals(js.getInt("code"), 20106);
        softAssert.assertEquals(js.getString("data.message"),
                "ticket: " + Integer.toString(id) + " , successfully deleted!", "message testDeleteTicket");

        log.info("Response of testDeleteTicket is: " + response.asString());
    }

    // CTA TC-08: Deleting a record which has previously been deleted

    @Test(priority = 4, dependsOnMethods = { "createTicket", "testDeleteTicket" }, groups = { "ticketController", "api",
            "regression" })
    public void testDeleteTicketAlreadyDeleted() {
        Response response = Payload_TicketController.deleteTicketControllerResponse(id);
        response.then().assertThat().statusCode(404);
        JsonPath js = Payload_TicketController.getJsonPath(response);

        // Assertion for this Test
        assertEquals(js.getInt("code"), 40003);
        softAssert.assertEquals(js.getString("message"),
                "exception while get/ delete ticket for ticketId: "
                        + Integer.toString(id)
                        + ",with exception: invalid ticketId/externalSourceId: "
                        + Integer.toString(id),
                "message testDeleteTicketAlreadyDeleted");

        log.info("Response of testDeleteTicketAlreadyDeleted is: " + response.asString());
    }

    // CTA TC-08: Deleting a record which has previously been deleted

    @Test(priority = 4, groups = { "ticketController", "api", "regression" })
    public void testDeleteTicketWrongId() {
        Response response = Payload_TicketController.deleteTicketControllerResponse(wrongId);
        response.then().assertThat().statusCode(404);
        JsonPath js = Payload_TicketController.getJsonPath(response);

        // Assertion for this Test
        assertEquals(js.getInt("code"), 40003);
        softAssert.assertEquals(js.getString("message"),
                "exception while get/ delete ticket for ticketId: "
                        + Integer.toString(wrongId)
                        + ",with exception: invalid ticketId/externalSourceId: "
                        + Integer.toString(wrongId),
                "message testDeleteTicketWrongId");

        log.info("Response of testDeleteTicketWrongId is: " + response.asString());
    }

    @AfterClass(alwaysRun = true)
    public void checkAssertions() {
        softAssert.assertAll();
    }
}
