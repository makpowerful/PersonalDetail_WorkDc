package testCases;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ThreadLocalRandom;

public class RandomDateAndDayGenerator {
    public static void main(String[] args) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy EEEE");
        LocalDate start = LocalDate.of(2023, 1, 1);
        LocalDate end = LocalDate.of(2023, 12, 31);
        long numOfDays = 100;
        for (int i = 0; i < numOfDays; i++) {
            LocalDate randomDate = generateRandomDate(start, end);
            DayOfWeek dayOfWeek = randomDate.getDayOfWeek();
            String formattedDate = formatter.format(randomDate);
            System.out.println(formattedDate);
        }
    }

    public static LocalDate generateRandomDate(LocalDate start, LocalDate end) {
        long startEpochDay = start.toEpochDay();
        long endEpochDay = end.toEpochDay();
        long randomEpochDay = ThreadLocalRandom.current().nextLong(startEpochDay, endEpochDay + 1);
        return LocalDate.ofEpochDay(randomEpochDay);
    }
}