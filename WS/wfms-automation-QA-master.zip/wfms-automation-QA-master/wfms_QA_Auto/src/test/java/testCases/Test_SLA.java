package testCases;

import java.io.IOException;
import java.util.ArrayList;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import payLoad.PayLoad_SLA;
import payLoad.PayLoad_TimeLine;
import payLoad.PayLoad_SLA;
import resources.ExcelData;
import resources.base;


public class Test_SLA extends base{
    
    private static SoftAssert softAssert = new SoftAssert();
    public ExcelData excelData = new ExcelData();
    public ArrayList<String> al = new ArrayList<String>();
    
    
    @Parameters({"sessionToken","role","projectId"})
    @BeforeClass(alwaysRun = true, groups = { "SLA", "api","regression" })
    public void setValues(String token, String role,int projectId) throws IOException {
        PayLoad_SLA.role = role;

        al = excelData.getData(url, "GlobalProjectIds", "Tcid");
        PayLoad_SLA.projectId = Integer.parseInt(al.get(1));  
        
        PayLoad_SLA.sessionToken = token;
        PayLoad_SLA.setHeaderMap();
    }
    
    
    
    
    @Test(priority=1, groups = { "SLA", "api","regression" })
    // SLAA TC-01 : Hitting the POST API and creating a new Policy for a project Id checking the status code and response validation
    public void testPost_SLA() throws Exception {
        Response res = PayLoad_SLA.getResPost();
        JsonPath response = PayLoad_SLA.getJsonPath(res);
        
        //Asserts
        if(PayLoad_SLA.role.equals("projectAdmin") || PayLoad_SLA.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 201);
            softAssert.assertEquals(response.getString("message"), "Sla Created", "testPost__message_failed");
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
    }
    
    
    
    
    
    @Test(priority=6, groups = { "SLA", "api","regression" })
    // SLAA TC-08 : Hitting the POST API and creating a new Policy for a project Id providing incorrect email formats and checking the status code and response validation
    public void testPost_Negative_IncorrectEmailFormat_SLA() throws Exception {
        Response res = PayLoad_SLA.getResPost_Negative_IncorrectEmailFormat();
        JsonPath response = PayLoad_SLA.getJsonPath(res);
        
        //Asserts
        if(PayLoad_SLA.role.equals("projectAdmin") || PayLoad_SLA.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 400);
            softAssert.assertEquals(response.getString("message"), "INVALID ESCALATION ENTRY", "testPost_Negative_IncorrectEmailFormat__message_Failed, getting response message as - "+response.getString("message"));
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
    }
    
    
    
    
    
    @Test(priority=2, groups = { "SLA", "api","regression" })
    // SLAA TC-02 : Hitting the PUT API and editing an existing Policy for a projectId then checking the status code and response validation
    public void testPut_SLA() throws Exception {
        Response res = PayLoad_SLA.getResPut();
        JsonPath response = PayLoad_SLA.getJsonPath(res);
        
        //Asserts
        if(PayLoad_SLA.role.equals("projectAdmin") || PayLoad_SLA.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 200);
            softAssert.assertEquals(response.getString("message"), "Sla Updated Successfully", "testPut__message_Failed");
            softAssert.assertEquals(response.getInt("data.policyId"), PayLoad_SLA.policyId, "testPut__policyId_Failed");
        }else {
            Assert.assertEquals(res.statusCode(), 404);
        }
    }
    
    
    
    
    
    @Test(priority=4, groups = { "SLA", "api","regression" })
    // SLAA TC-03 : Hitting the PUT API and editing an Policy for a Invalid projectId then checking the status code and response validation
    public void testPut_Negative_NonExistentProjectId_SLA() throws Exception {
        Response res = PayLoad_SLA.getResPut_Negative_NonExistentProjectId();
        JsonPath response = PayLoad_SLA.getJsonPath(res);
        
        //Asserts
            Assert.assertEquals(res.statusCode(), 404);
        
    }
    
    
    
    
    
    @Test(priority=3, groups = { "SLA", "api","regression" })
    // SLAA TC-04 : Hitting the GET API and getting existing Policy for a valid projectId then checking the status code and response validation
    public void testGet_SLA() throws Exception {
        Response res = PayLoad_SLA.getResGet();
        JsonPath response = PayLoad_SLA.getJsonPath(res);
        
        //Asserts
        if(PayLoad_SLA.role.equals("supervisor")) {
            Assert.assertEquals(res.statusCode(), 400);
            return;
        }
        else if(PayLoad_SLA.role.equals("projectAdmin") || PayLoad_SLA.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 200);
            softAssert.assertEquals(response.getInt("data.policyId"), PayLoad_SLA.policyId, "testGet__policyId_Failed");
            softAssert.assertEquals(response.getInt("data.projectId"), PayLoad_SLA.projectId, "testGet__projectId_Failed");
            softAssert.assertEquals(response.getString("data.policyName"), PayLoad_SLA.policyName, "testGet__policyName_Failed");
            
            softAssert.assertEquals(response.getString("data.escalations[0].escalationType"), "FIRST_RESPONSE_TIME", "testGet__FirstReplyEscalationType_Failed");
            softAssert.assertEquals(response.getInt("data.escalations[0].escalationTime"), PayLoad_SLA.FIRST_REPLY_ESCALATION_TIME, "testGet__FirstReplyEscalationTime_Failed");
            softAssert.assertEquals(response.getString("data.escalations[0].emailIds[0]"), PayLoad_SLA.FIRST_REPLY_ESCALATION_EMAILID, "testGet__FirstReplyEscalationEmailId_Failed");
            
            softAssert.assertEquals(response.getString("data.escalations[1].escalationType"), "RESOLUTION_TIME", "testGet__ResolutionEscalationType_Failed");
            softAssert.assertEquals(response.getInt("data.escalations[1].escalationTime"), PayLoad_SLA.RESOLUTION_ESCALATION_TIME, "testGet__ResolutionEscalationTime_Failed");
            softAssert.assertEquals(response.getString("data.escalations[1].emailIds[0]"), PayLoad_SLA.RESOLUTION_ESCALATION_EMAILID1, "testGet__ResolutionEscalationEmailId1_Failed");
            softAssert.assertEquals(response.getString("data.escalations[1].emailIds[1]"), PayLoad_SLA.RESOLUTION_ESCALATION_EMAILID2, "testGet__ResolutionEscalationEmailId2_Failed");
            
            softAssert.assertEquals(response.getInt("data.targets[0].targetTime"), PayLoad_SLA.FIRST_REPLY_TIME_URGENT, "testGet__targetsTime[0]_Failed");
            softAssert.assertEquals(response.getInt("data.targets[1].targetTime"), PayLoad_SLA.FIRST_REPLY_TIME_HIGH, "testGet__targetsTime[1]_Failed");
            softAssert.assertEquals(response.getInt("data.targets[2].targetTime"), PayLoad_SLA.FIRST_REPLY_TIME_NORMAL, "testGet__targetsTime[2]_Failed");
            softAssert.assertEquals(response.getInt("data.targets[3].targetTime"), PayLoad_SLA.FIRST_REPLY_TIME_LOW, "testGet__targetsTime[3]_Failed");
            softAssert.assertEquals(response.getInt("data.targets[4].targetTime"), PayLoad_SLA.RESOLUTION_TIME_URGENT, "testGet__targetsTime[4]_Failed");
            softAssert.assertEquals(response.getInt("data.targets[5].targetTime"), PayLoad_SLA.RESOLUTION_TIME_HIGH, "testGet__targetsTime[5]_Failed");
            softAssert.assertEquals(response.getInt("data.targets[6].targetTime"), PayLoad_SLA.RESOLUTION_TIME_NORMAL, "testGet__targetsTime[6]_Failed");
            softAssert.assertEquals(response.getInt("data.targets[7].targetTime"), PayLoad_SLA.RESOLUTION_TIME_LOW, "testGet__targetsTime[7]_Failed");
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
        
    }
    
    
    
    
    
    @Test(priority=3, groups = { "SLA", "api","regression" })
    // SLAA TC-05 : Hitting the GET API and getting Policy for a Invalid projectId then checking the status code and response validation
    public void testGet_Negative_NonExistentProjectId_SLA() throws Exception {
        Response res = PayLoad_SLA.getResGet_Negative_NonExistentProjectId();
        JsonPath response = PayLoad_SLA.getJsonPath(res);
        
        //Asserts
        if(PayLoad_SLA.role.equals("projectAdmin") || PayLoad_SLA.role.equals("superAdmin") || PayLoad_SLA.role.equals("supervisor")) {
            Assert.assertEquals(res.statusCode(), 400);
            softAssert.assertEquals(response.getString("message"), "Sla of this Project Id does not Exist ", "testGet_Negative_NonExistentProjectId__message_Failed");
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
        
    }
    
    
    
    
    
    @Test(priority=5, groups = { "SLA", "api","regression" })
    // SLAA TC-06 : Hitting the DELETE API and deleting Policy for a valid projectId then checking the status code and response validation
    public void testDelete_SLA() throws Exception {
        Response res = PayLoad_SLA.getResDelete();
        JsonPath response = PayLoad_SLA.getJsonPath(res);
        
        //Asserts
        if(PayLoad_SLA.role.equals("projectAdmin") || PayLoad_SLA.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 200);
            softAssert.assertEquals(response.getString("data.message"), "Sla Deleted Successfully", "testDelete__data.message_Failed");
            softAssert.assertEquals(response.getString("message"), "Sla Deleted ", "testDelete__message_Failed");
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
        
    }
    
    
    
    
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-199
    @Test(priority=5, groups = { "SLA", "api","regression" })
    // SLAA TC-07 : Hitting the DELETE API and deleting Policy for a Invalid projectId then checking the status code and response validation
    public void testDelete_Negative_NonExistentProjectId_SLA() throws Exception {
        Response res = PayLoad_SLA.getResDelete_Negative_NonExistentProjectId();
        JsonPath response = PayLoad_SLA.getJsonPath(res);
        
        //Asserts
        if(PayLoad_SLA.role.equals("projectAdmin") || PayLoad_SLA.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 400);
            softAssert.assertEquals(response.getString("message"), "project Id not valid", "testDelete_Negative_NonExistentProjectId__message_Failed");
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
       
    }
    
    
    
    @AfterClass(alwaysRun = true, groups = { "SLA", "api","regression" })
    public void assertAll() {
        softAssert.assertAll();
    }
}
