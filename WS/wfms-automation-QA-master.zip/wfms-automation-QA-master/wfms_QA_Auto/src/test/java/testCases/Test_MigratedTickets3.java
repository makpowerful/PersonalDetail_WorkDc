package testCases;

import static io.restassured.RestAssured.given;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import UI_TestCases.LoginScreenTestMethods;
import io.restassured.path.json.JsonPath;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import payLoad.Payload_RuleTest;
import payLoad.payLoad_AllProgram;
import resources.ExcelData;
import resources.Utils;
import resources.base;

public class Test_MigratedTickets3 extends base {

	public static Properties prop;
	public static Logger log = LogManager.getLogger(Test_MigratedTickets3.class.getName());
	static Faker faker = new Faker();
	static int randomNum = ThreadLocalRandom.current().nextInt(1000, 10000 + 1);
	static String firstName = faker.name().firstName().replaceAll("'","");
	static String lastName = faker.name().lastName().replaceAll("'","");
	static String parentName = faker.name().fullName().replaceAll("'","");
	static String Auto="Dummy ";
	static long Premiumid= 52512495345L+randomNum;
	ExcelData excelData = new ExcelData();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	static int counter=1;
	static int i=0;
	WebDriver driver;
	private String username = Login;
	
	  @BeforeClass()
	    public void initialize() throws Exception{
	      Thread.sleep(60000);
	      Thread.sleep(60000);
	      Thread.sleep(60000);
	      Thread.sleep(60000);
	        driver = initializeDriver();
	        LoginScreenTestMethods loginScreen = new LoginScreenTestMethods();
	        loginScreen.loginPageVerification(username, driver);
	  }
	
	//dataProvider = "Datapro" //String Progid,String ShippingRegion,String Class
	@Test(dataProvider = "Datapro",enabled = true)
	public void Test1RuleCombo(String ticket_id,String project_id,String attachments, String JSONCountAttachment, String comments, String JSONCountComment) throws Exception {
        //setData("src\\main\\java\\testData\\3.xlsx","output3", i + 1, 0, zendesk_ticket_id);
        setData("src\\main\\java\\testData\\3.xlsx","output3", i + 1, 0, ticket_id);
        setData("src\\main\\java\\testData\\3.xlsx","output3", i + 1, 1, project_id);
        setData("src\\main\\java\\testData\\3.xlsx","output3", i + 1, 2, attachments);
        setData("src\\main\\java\\testData\\3.xlsx","output3", i + 1, 3, JSONCountAttachment);
        setData("src\\main\\java\\testData\\3.xlsx","output3", i + 1, 4, comments);
        setData("src\\main\\java\\testData\\3.xlsx","output3", i + 1, 5, JSONCountComment);
        String PRD = "https://workflow-managment-system.byjusweb.com/tickets/";
        String STG = "https://workflow-managment-system-staging.byjusweb.com/tickets/";
    
       driver.get(PRD+ticket_id);
	       visibleText(By.xpath("//div[@data-testid='ticket-id']"));
	       
	       List<WebElement> ConvList = driver.findElements(By.xpath("//div[@class='stepper__container'][contains(@style,'248')]"));
	       setData("src\\main\\java\\testData\\3.xlsx","output3", i + 1, 7,Integer.toString(ConvList.size()));
	       
	       
	       if(checkElementExists("//div[@class='stepper__container'][contains(@style,'248')]//div[@class='stepper__author'][text()='undefined']")) {
	           setData("src\\main\\java\\testData\\3.xlsx","output3", i + 1, 8,"Yes");
	       }
	       else {
	           setData("src\\main\\java\\testData\\3.xlsx","output3", i + 1, 8,"No");
	       }
	       
	       if(Integer.parseInt(JSONCountAttachment)!=0) {
	           List<WebElement> AttchList = driver.findElements(By.xpath("(//div[@class='caseDetailsAttachments__frame'])[1]/descendant::div[@class='attachment__frame']"));
	           setData("src\\main\\java\\testData\\3.xlsx","output3", i + 1, 9,Integer.toString(AttchList.size()));  
	       }
	       else {
	           setData("src\\main\\java\\testData\\3.xlsx","output3", i + 1, 9,Integer.toString(0));  
	       }
	       
	       List<WebElement> TotalCaseDetailElements = driver.findElements(By.xpath("//div[@class='caseProperties__accordions__caseDetails']//div[@class='accordion__wrapper__content__item__header']"));
	       setData("src\\main\\java\\testData\\3.xlsx","output3", i + 1, 10,Integer.toString(TotalCaseDetailElements.size()));
	     //div[@class='caseDetailsAttachments__frame']/descendant::div[@class='attachment__frame']
	        //JsonPath js1 = new JsonPath(StudentCreation);
	       // String id = js1.get("compositeResponse[0].body.id");
			//log.info("The value of id is: " + id);

	       i++;
		
	}
	
	 public boolean checkElementExists(String xpath) {
	        boolean result = false;
	        try {
	            driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
	            driver.findElement(By.xpath(xpath));
	            result = true;
	        }
	        catch(org.openqa.selenium.NoSuchElementException ex) {
	            result = false;
	        }
	        finally {
	            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	        }
	        return result;
	    }
	
	@DataProvider(name = "Datapro")
	public Object[][] testpro() throws Exception {
	    String OSValue = "";
        String OS = System.getProperty("os.name", "generic").toLowerCase(Locale.ENGLISH);
        if ((OS.indexOf("mac") >= 0) || (OS.indexOf("darwin") >= 0)) {
            OSValue = "//src//main//java//testData//output.xlsx";
        } else if (OS.indexOf("win") >= 0) {
            OSValue = "\\src\\main\\java\\testData\\output.xlsx";
        }
		Object[][] data = readData(System.getProperty("user.dir") + OSValue,
				"output3");
		return data;
	}

    @AfterClass(groups= {"ui","regression"})
    public void quitDriver() throws InterruptedException {
        driver.quit();
    } 
}
