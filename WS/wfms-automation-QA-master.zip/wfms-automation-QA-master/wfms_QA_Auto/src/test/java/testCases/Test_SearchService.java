package testCases;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import payLoad.Payload_SearchService;
import payLoad.Payload_TicketController;
import resources.ExcelData;
import resources.base;

public class Test_SearchService extends base {
    private String sheetName = "SearchService_API";
    private int projectId;
    private ArrayList<Integer> id = new ArrayList<Integer>();
    private String createdAt;
    private static SoftAssert softAssert = new SoftAssert();
    public static Logger log = LogManager.getLogger(Test_ChannelController.class.getName());
    private static ExcelData excelData = new ExcelData();
    private static ArrayList<String> al = new ArrayList<String>();

    @BeforeClass(alwaysRun = true)
    @Parameters({"sessionToken", "role", "projectId"})
    public void createProject(String sessionToken,String role, String projectId) throws IOException, InterruptedException {
        
        al = excelData.getData(url, "GlobalProjectIds", "Tcid");
        this.projectId =Integer.parseInt(al.get(1));
        
        Payload_SearchService.setHeaderMap(Integer.toString(this.projectId), sessionToken);
        Payload_TicketController.setHeaderMap(Integer.toString(this.projectId), "dbda17601d48e2dcae355d0d7a1476affef4d24b1731f2c45183d277a1096d34");
        
        al = excelData.getData("CreateProject1", sheetName, "Tcid");
        Response response;
        JsonPath js;
        for(int i=0; i<3; i++) {
            response = Payload_TicketController.postTicketControllerResponse("CreateProject"+Integer.toString(i+1), sheetName);
            response.then().assertThat().statusCode(201);
            js = Payload_TicketController.getJsonPath(response);
            id.add(js.getInt("data.ticketId"));
        }
        
        

        response = Payload_TicketController.putTicketControllerResponse(id.get(2), "UpdateProject", sheetName);
        response.then().assertThat().statusCode(200);

        response = Payload_TicketController.getTicketControllerResponse(id.get(2));
        response.then().assertThat().statusCode(200);
        js = Payload_TicketController.getJsonPath(response);

        createdAt = js.getString("data.tickets[0].createdAt");
        if(createdAt.length() == 19) {
            createdAt += ".";
        }
        for(int i=createdAt.length(); i<23; i++) {
            createdAt += "0";
        }
        Thread.sleep(3000);
    }
    
    // SSA TC-01: Hitting the API then checking the status code and response
    // validation

    @Test(priority=100, groups = { "searchService", "api","regression" })
    public void testSearchProjectId() throws IOException {
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("projectId", Integer.toString(projectId));
        Response response = Payload_SearchService.getSearchAndFilterQuery(params);
        response.then().assertThat().statusCode(200);
        JsonPath js = Payload_SearchService.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("code"), 20000, "code testSearchProjectId");
        softAssert.assertEquals(js.getString("message"), "completed successfully", "message testSearchProjectId");
        softAssert.assertEquals(js.getString("data.tickets[0].ticketId"), Integer.toString(id.get(2)),
                "ticketId testSearchProjectId");
        log.info("Response of testSearchProjectId is: " + response.asString());
    }
    
    // SSA TC-02: Hitting the API then sorting the search with the sortByField and
    // response validation

    @Test(priority=100, groups = { "searchService", "api","regression" })
    public void testSearchSortByField() throws IOException {
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("sortByField", "createdAt");
        params.put("projectId", Integer.toString(projectId));
        Response response = Payload_SearchService.getSearchAndFilterQuery(params);
        response.then().assertThat().statusCode(200);
        JsonPath js = Payload_SearchService.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("code"), 20000, "code testSearchSortByField");
        softAssert.assertEquals(js.getString("message"), "completed successfully", "message testSearchSortByField");
        softAssert.assertEquals(js.getString("data.tickets[0].ticketId"), Integer.toString(id.get(2)),
                "ticketId testSearchSortByField");
        
        for(int i=1; i<3; i++) {
            softAssert.assertTrue(js.getInt("data.tickets["+Integer.toString(i-1)+"].ticketId") > js.getInt("data.tickets["+Integer.toString(i)+"].ticketId"),
                    "checking sorting testSearchSortByField");
        }
        log.info("Response of testSearchSortByField is: " + response.asString());
    }

    // SSA TC-03: Hitting the API then sorting the search with the sortByOrder and
    // response validation
    
    @Test(priority=100, groups = { "searchService", "api","regression" })
    public void testSearchSortByOrder() throws IOException {
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("sortByOrder", "ASC");
        params.put("projectId", Integer.toString(projectId));
        Response response = Payload_SearchService.getSearchAndFilterQuery(params);
        response.then().assertThat().statusCode(200);
        JsonPath js = Payload_SearchService.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("code"), 20000, "code testSearchSortByOrder");
        softAssert.assertEquals(js.getString("message"), "completed successfully", "message testSearchSortByOrder");
        for(int i=1; i<3; i++) {
            softAssert.assertTrue(js.getInt("data.tickets["+Integer.toString(i-1)+"].ticketId") < js.getInt("data.tickets["+Integer.toString(i)+"].ticketId"),
                    "checking sorting testSearchSortByOrder");
        }
        log.info("Response of testSearchSortByOrder is: " + response.asString());
    }
    
    // SSA TC-05: Hitting the API then filtering the search with the requesterEmail
    // and response validation

    @Test(priority=100, groups = { "searchService", "api","regression" })
    public void testSearchRequesterEmail() throws IOException {
        al = excelData.getData("CreateProject1", sheetName, "Tcid");
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("requesterEmail", al.get(5));
        params.put("projectId", Integer.toString(projectId));
        Response response = Payload_SearchService.getSearchAndFilterQuery(params);
        response.then().assertThat().statusCode(200);
        JsonPath js = Payload_SearchService.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("code"), 20000, "code testSearchRequesterEmail");
        softAssert.assertEquals(js.getString("message"), "completed successfully", "message testSearchRequesterEmail");
        softAssert.assertEquals(js.getString("data.tickets[0].ticketId"), Integer.toString(id.get(2)),
                "ticketId testSearchRequesterEmail");
        softAssert.assertEquals(js.getString("data.tickets[0].requesterEmail"), al.get(5),
                "requesterEmail testSearchRequesterEmail");
        log.info("Response of testSearchRequesterEmail is: " + response.asString());
    }
    
    // SSA TC-06: Hitting the API then filtering the search with the customerEmail
    // and response validation

    @Test(priority=100, groups = { "searchService", "api","regression" })
    public void testSearchCustomerEmail() throws IOException {
        al = excelData.getData("CreateProject1", sheetName, "Tcid");
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("customerEmail", al.get(13));
        params.put("projectId", Integer.toString(projectId));
        Response response = Payload_SearchService.getSearchAndFilterQuery(params);
        response.then().assertThat().statusCode(200);
        JsonPath js = Payload_SearchService.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("code"), 20000, "code testSearchCustomerEmail");
        softAssert.assertEquals(js.getString("message"), "completed successfully", "message testSearchCustomerEmail");
        softAssert.assertEquals(js.getString("data.tickets[0].ticketId"), Integer.toString(id.get(2)),
                "ticketId testSearchCustomerEmail");
        softAssert.assertEquals(js.getString("data.tickets[0].customerEmail"), al.get(13),
                "customerEmail testSearchCustomerEmail");
        log.info("Response of testSearchCustomerEmail is: " + response.asString());
    }
    
    // SSA TC-07: Hitting the API then filtering the search with the customerName
    // and response validation

    @Test(priority=100, groups = { "searchService", "api","regression" })
    public void testSearchCustomerName() throws IOException {
        al = excelData.getData("CreateProject1", sheetName, "Tcid");
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("customerName", al.get(12));
        params.put("projectId", Integer.toString(projectId));
        Response response = Payload_SearchService.getSearchAndFilterQuery(params);
        response.then().assertThat().statusCode(200);
        JsonPath js = Payload_SearchService.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("code"), 20000, "code testSearchCustomerName");
        softAssert.assertEquals(js.getString("message"), "completed successfully", "message testSearchCustomerName");
        softAssert.assertEquals(js.getString("data.tickets[0].ticketId"), Integer.toString(id.get(2)),
                "ticketId testSearchCustomerName");
        log.info("Response of testSearchCustomerName is: " + response.asString());
    }
    
    // SSA TC-08: Hitting the API then filtering the search with the createdAt and
    // response validation

    @Test(priority=100, groups = { "searchService", "api","regression" })
    public void testSearchCreatedAt() throws IOException {
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("createdAt", createdAt);
        params.put("projectId", Integer.toString(projectId));
        Response response = Payload_SearchService.getSearchAndFilterQuery(params);
        response.then().assertThat().statusCode(200).log().all();
        JsonPath js = Payload_SearchService.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("code"), 20000, "code testSearchCreatedAt");
        softAssert.assertEquals(js.getString("message"), "completed successfully", "message testSearchCreatedAt");
        softAssert.assertEquals(js.getString("data.tickets[0].ticketId"), Integer.toString(id.get(2)),
                "ticketId testSearchCreatedAt");
        softAssert.assertEquals(js.getString("data.tickets[0].createdAt"), createdAt, "createdAt testSearchCreatedAt");
        log.info("Response of testSearchCreatedAt is: " + response.asString());
    }
    
    // SSA TC-09: Hitting the API then filtering the search with the status and
    // response validation

    @Test(priority=100, groups = { "searchService", "api","regression" })
    public void testSearchStatus() throws IOException {
        al = excelData.getData("UpdateProject", sheetName, "Tcid");
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("status", al.get(14));
        params.put("projectId", Integer.toString(projectId));
        Response response = Payload_SearchService.getSearchAndFilterQuery(params);
        response.then().assertThat().statusCode(200);
        JsonPath js = Payload_SearchService.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("code"), 20000, "code testSearchStatus");
        softAssert.assertEquals(js.getString("message"), "completed successfully", "message testSearchStatus");
        softAssert.assertEquals(js.getString("data.tickets[0].ticketId"), Integer.toString(id.get(2)),
                "ticketId testSearchStatus");
        softAssert.assertEquals(js.getString("data.tickets[0].status"), al.get(14), "status testSearchStatus");
        log.info("Response of testSearchStatus is: " + response.asString());
    }
    
    // SSA TC-10: Hitting the API then filtering the search with the priority and
    // response validation

    @Test(priority=100, groups = { "searchService", "api","regression" })
    public void testSearchPriority() throws IOException {
        al = excelData.getData("UpdateProject", sheetName, "Tcid");
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("priority", al.get(17));
        params.put("projectId", Integer.toString(projectId));
        Response response = Payload_SearchService.getSearchAndFilterQuery(params);
        response.then().assertThat().statusCode(200);
        JsonPath js = Payload_SearchService.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("code"), 20000, "code testSearchPriority");
        softAssert.assertEquals(js.getString("message"), "completed successfully", "message testSearchPriority");
        softAssert.assertEquals(js.getString("data.tickets[0].ticketId"), Integer.toString(id.get(2)),
                "ticketId testSearchPriority");
        softAssert.assertEquals(js.getString("data.tickets[0].priority"), al.get(17), "priority testSearchPriority");
        log.info("Response of testSearchPriority is: " + response.asString());
    }
    
    // SSA TC-11: Hitting the API then filtering the search with the groupId and
    // response validation

    @Test(priority=100, groups = { "searchService", "api","regression" })
    public void testSearchGroupId() throws IOException {
        al = excelData.getData("UpdateProject", sheetName, "Tcid");
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("groupId", al.get(21));
        params.put("projectId", Integer.toString(projectId));
        Response response = Payload_SearchService.getSearchAndFilterQuery(params);
        response.then().assertThat().statusCode(200);
        JsonPath js = Payload_SearchService.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("code"), 20000, "code testSearchGroupId");
        softAssert.assertEquals(js.getString("message"), "completed successfully", "message testSearchGroupId");
        softAssert.assertEquals(js.getString("data.tickets[0].ticketId"), Integer.toString(id.get(2)),
                "ticketId testSearchGroupId");
        log.info("Response of testSearchGroupId is: " + response.asString());
    }
    
    // SSA TC-15: Hitting the API then searching all the records in the database
    // with the searchQuery and response validation

    @Test(priority=100, groups = { "searchService", "api","regression" })
    public void testSearchQuery() throws IOException {
        al = excelData.getData("CreateProject1", sheetName, "Tcid");
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("searchQuery", al.get(9));
        params.put("sortByField", "createdAt");
        params.put("projectId", Integer.toString(projectId));
        Response response = Payload_SearchService.getSearchAndFilterQuery(params);
        response.then().assertThat().statusCode(200);
        JsonPath js = Payload_SearchService.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("code"), 20000, "code testSearchQuery");
        softAssert.assertEquals(js.getString("message"), "completed successfully", "message testSearchQuery");
        softAssert.assertEquals(js.getString("data.tickets[0].ticketId"), Integer.toString(id.get(2)),
                "ticketId testSearchQuery");
        softAssert.assertEquals(js.getString("data.tickets[0].subject"), al.get(9), "subject testSearchQuery");
        log.info("Response of testSearchQuery is: " + response.asString());
    }
    
    // SSA TC-16: Hitting the API then searching with alphanumeric projectId
    // Defect Id: https://byjustech.atlassian.net/browse/WFM-117
    
    @Test(priority=100, groups = { "searchService", "api","regression" })
    public void testSearchWrongProjectId() throws IOException {
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("projectId", "random");
        Response response = Payload_SearchService.getSearchAndFilterQuery(params);
        response.then().assertThat().statusCode(403);
        JsonPath js = Payload_SearchService.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("code"), 40002, "code testSearchWrongProjectId");
        softAssert.assertEquals(js.getString("message"), "User does not have access for this project",
                "message testSearchWrongProjectId");
        log.info("Response of testSearchWrongProjectId is: " + response.asString());
    }

    @AfterClass(alwaysRun = true)
    public void checkAssertions() {
        for(int i=0; i<3; i++) {
            Response response = Payload_TicketController.deleteTicketControllerResponse(id.get(i));
            response.then().assertThat().statusCode(200);
        }
        softAssert.assertAll();
    }
}
