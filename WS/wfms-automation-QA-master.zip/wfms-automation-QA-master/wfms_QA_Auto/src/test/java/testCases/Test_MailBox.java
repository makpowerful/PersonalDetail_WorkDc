package testCases;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import payLoad.PayLoad_MailBox;
import resources.ExcelData;
import resources.base;

public class Test_MailBox extends base{
    private static SoftAssert softAssert = new SoftAssert();
    public ExcelData excelData = new ExcelData();
    public ArrayList<String> al = new ArrayList<String>();
    
    @BeforeClass(alwaysRun=true, groups = { "SLA", "api","regression" })
    @Parameters({"sessionToken","role","projectId"})
    public void setToken(String token,String role,int projectId) throws IOException {
        PayLoad_MailBox.role = role;

        al = excelData.getData(url, "GlobalProjectIds", "Tcid");
        PayLoad_MailBox.projectId = Integer.parseInt(al.get(1));  
        
        PayLoad_MailBox.sessionToken = token;
        PayLoad_MailBox.setHeaderMap();
    }
    
    
    
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-181
    @Test(priority=1, groups = { "MailBox", "api","regression" })
    // MBA TC-01 : Hitting the POST API and creating a new Credential and then checking the status code and response validation
    public void testPost_MailBox() throws Exception {
        Response res = PayLoad_MailBox.getResPost();
        JsonPath response = PayLoad_MailBox.getJsonPath(res);
        
        //Asserts
        if(PayLoad_MailBox.role.equals("projectAdmin") || PayLoad_MailBox.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 201);
            softAssert.assertEquals(response.getInt("data.id"),PayLoad_MailBox.MailBoxId, "testPost__id_Failed");
            softAssert.assertEquals(response.getString("message"),"Mailbox created", "testPost__message_failed");
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
    }
    
    
    
    
    
    @Test(priority=2, groups = { "MailBox", "api","regression" })
    // MBA TC-02 : Hitting the POST API and creating a new Credential by passing an invalid email Id format and then checking the status code and response validation
    public void testPost_Negative_WrongEmailFormat_MailBox() throws IOException {
        Response res = PayLoad_MailBox.getResPost_Negative_WrongEmailFormat();
        JsonPath response = PayLoad_MailBox.getJsonPath(res);
        
        
        //Asserts
        if(PayLoad_MailBox.role.equals("projectAdmin") || PayLoad_MailBox.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 400);
            softAssert.assertEquals(response.getInt("code"),40000, "testPost_Negative_WrongEmailFormat__code_failed");
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
    }
    
    
    
    
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-340
    @Test(priority=2, groups = { "MailBox", "api","regression" })
    // MBA TC-03 : Hitting the POST API and creating a new Credential using an already registered email Id and then checking the status code and response validation
    public void testPost_Negative_RepeatEmail_MailBox() throws IOException {
        Response res = PayLoad_MailBox.getResPost_Negative_RepeatEmail();
        JsonPath response = PayLoad_MailBox.getJsonPath(res);
        
        
        //Asserts
        if(PayLoad_MailBox.role.equals("projectAdmin") || PayLoad_MailBox.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 400);
            softAssert.assertEquals(response.getInt("code"),40000, "testPost_Negative_RepeatEmail__code_failed");
            softAssert.assertEquals(response.getString("message"),"email already registered for an existing mailbox", "testPost_Negative_RepeatEmail__message_failed");
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
    }
    
    
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-471
    @Test(priority=2, groups = { "MailBox", "api","regression" })
    public void testPostMailBoxWithLargeName() throws IOException {
        Response res = PayLoad_MailBox.getResPostMailBoxWithLargeName();
        JsonPath response = PayLoad_MailBox.getJsonPath(res);
        
        //Asserts
        if(PayLoad_MailBox.role.equals("projectAdmin") || PayLoad_MailBox.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 400);
            softAssert.assertEquals(response.getInt("code"),40000, "testPostMailBoxWithLargeName__code_failed");
            softAssert.assertEquals(response.getString("message"),"[Name must not exceed 50 characters]", "testPostMailBoxWithLargeName__message_failed");
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
    }
    
    
    @Test(priority=2, groups = { "MailBox", "api","regression" })
    // MBA TC-04 : Hitting the POST API and creating a new Credential while keeping the name field empty and then checking the status code and response validation
    public void testPost_EmptyName_MailBox() throws IOException {
        Response res = PayLoad_MailBox.getResPost_Negative_EmptyName();
        JsonPath response = PayLoad_MailBox.getJsonPath(res);
        
        
        //Asserts
        if(PayLoad_MailBox.role.equals("projectAdmin") || PayLoad_MailBox.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 400);
            softAssert.assertEquals(response.getInt("code"),40000, "testPost_EmptyName__code_failed");
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
    }
    
    
    
    
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-340
    @Test(priority=2, groups = { "MailBox", "api","regression" })
    // MBA TC-05 : Hitting the POST API and creating a new Credential assigning a group that has already been assigned and then checking the status code and response validation
    public void testPost_Negative_AssignedGroup_MailBox() throws IOException {
        Response res = PayLoad_MailBox.getResPost_Negative_AssignedGroup();
        JsonPath response = PayLoad_MailBox.getJsonPath(res);
        
        
        //Asserts
        if(PayLoad_MailBox.role.equals("projectAdmin") || PayLoad_MailBox.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 400);
            softAssert.assertEquals(response.getInt("code"),40000, "testPost_Negative_AssignedGroup__code_failed");
            softAssert.assertEquals(response.getString("message"),"group is already assigned to an existing mailbox", "testPost_Negative_AssignedGroup__message_failed");
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
        
    }
    
    
    
    
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-360
    @Test(priority=3, groups = { "MailBox", "api","regression" })
    // MBA TC-06 : Hitting the PUT API to update the fields using MailBox Id and then checking the status code 
    public void testPut_MailBox() throws IOException {
        Response res = PayLoad_MailBox.getResPut();
        JsonPath response = PayLoad_MailBox.getJsonPath(res);
        
        
        //Asserts
        if(PayLoad_MailBox.role.equals("projectAdmin") || PayLoad_MailBox.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 200);
            softAssert.assertEquals(response.getInt("data.id"),PayLoad_MailBox.MailBoxId, "testPut__id_failed");
            softAssert.assertEquals(response.getString("data.name"),PayLoad_MailBox.update_name, "testPut__name_failed");
            softAssert.assertEquals(response.getString("data.email"),PayLoad_MailBox.emailId, "testPut__email_failed");
            softAssert.assertEquals(response.getString("message"),"Mailbox Updated", "testPut__message_failed");
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
        
    }
    
    
    
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-340
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-182
    @Test(priority=3, groups = { "MailBox", "api","regression" })
    // MBA TC-07 : Hitting the PUT API to update the fields using incorrect MailBox Id and then checking the status code 
    public void testPut_Negative_NonExistentMailBoxId() throws IOException {
        Response res = PayLoad_MailBox.getResPut_Negative_NonExistentMailBoxId();
        JsonPath response = PayLoad_MailBox.getJsonPath(res);
        
        
        //Asserts
        if(PayLoad_MailBox.role.equals("projectAdmin") || PayLoad_MailBox.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 404);
            softAssert.assertEquals(response.getInt("code"),40003, "testPut_Negative_NonExistentMailBoxId__code_failed");
            softAssert.assertEquals(response.getString("message"),"exception while get/ update mailbox", "testPut_Negative_NonExistentMailBoxId__message_failed");
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
        
    }
    
    
    
    
    
    @Test(priority=4, groups = { "MailBox", "api","regression" })
    // MBA TC-09 : Hitting the PUT API to update the Account Status (DeActivate) of MailBox and then checking the status code 
    public void testPut_Deactivate_MailBox() throws IOException {
        Response res = PayLoad_MailBox.getResPut_Deactivate();
        JsonPath response = PayLoad_MailBox.getJsonPath(res);
        
        
        //Asserts
        if(PayLoad_MailBox.role.equals("projectAdmin") || PayLoad_MailBox.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 200);
            softAssert.assertEquals(response.getString("data.message"),"Mailbox deactivated successfully", "testPut_Deactivate__data.message_failed");
            softAssert.assertEquals(response.getString("message"),"Mailbox Active status updated", "testPut_Deactivate__message_failed");
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
        
    }
    
    
    
    
    
    @Test(priority=5, groups = { "MailBox", "api","regression" })
    // MBA TC-08 : Hitting the PUT API to update the Account Status (Activate) of MailBox and then checking the status code 
    public void testPut_Activate_MailBox() throws IOException {
        Response res = PayLoad_MailBox.getResPut_Activate();
        JsonPath response = PayLoad_MailBox.getJsonPath(res);
        
        
        //Asserts
        if(PayLoad_MailBox.role.equals("projectAdmin") || PayLoad_MailBox.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 200);
            softAssert.assertEquals(response.getString("data.message"),"Mailbox activated successfully", "testPut_Activate__data.message_failed");
            softAssert.assertEquals(response.getString("message"),"Mailbox Active status updated", "testPut_Activate__message_failed");
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
        
    }
    
    @Test(priority=7, groups = { "MailBox", "api","regression" })
    public void testPut_Deactivate_MailBox_Again() throws IOException {
        Response res = PayLoad_MailBox.getResPut_Deactivate();
        JsonPath response = PayLoad_MailBox.getJsonPath(res);
        
        
        //Asserts
        if(PayLoad_MailBox.role.equals("projectAdmin") || PayLoad_MailBox.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 200);
            softAssert.assertEquals(response.getString("data.message"),"Mailbox deactivated successfully", "testPut_Deactivate__data.message_failed");
            softAssert.assertEquals(response.getString("message"),"Mailbox Active status updated", "testPut_Deactivate__message_failed");
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
        
    }
    
    
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-340
    @Test(priority=5, groups = { "MailBox", "api","regression" })
    // MBA TC-10 : Hitting the PUT API to update the Account Status (Activate) of MailBox using a incorrect MailBox Id and then checking the status code 
    public void testPut_Activate_Negative_WrongMailBoxId() throws IOException {
        Response res = PayLoad_MailBox.getResPut_Activate_Negative_WrongMailBoxId();
        JsonPath response = PayLoad_MailBox.getJsonPath(res);
        
        
        //Asserts
        if(PayLoad_MailBox.role.equals("projectAdmin") || PayLoad_MailBox.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 404);
            softAssert.assertEquals(response.getInt("code"),40003, "testPut_Activate_Negative_WrongMailBoxId__code_failed");
            softAssert.assertEquals(response.getString("message"),"exception while get/ delete mailbox", "testPut_Activate_Negative_WrongMailBoxId__message_failed");
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
        
    }
    
    
    
    
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-360
    @Test(priority=6, groups = { "MailBox", "api","regression" })
    // MBA TC-11 : Hitting the GET API to get the credentials of a particular Id as a query Param and then checking the status code and response validation
    public void testGet_MailBoxId() throws IOException {
        HashMap<String,Object> hashMap = new HashMap<String,Object>();
        hashMap.put("id", PayLoad_MailBox.MailBoxId);
        
        Response res = PayLoad_MailBox.getRes_Get(hashMap);
        JsonPath response = PayLoad_MailBox.getJsonPath(res);
        
        //Asserts
        if(PayLoad_MailBox.role.equals("projectAdmin") || PayLoad_MailBox.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 200);
            softAssert.assertEquals(response.getInt("data.mailboxes[0].id"),PayLoad_MailBox.MailBoxId, "testGet_MailBoxId__id_failed");
            softAssert.assertEquals(response.getString("data.mailboxes[0].name"),PayLoad_MailBox.update_name, "testGet_MailBoxId__name_failed");
            softAssert.assertEquals(response.getString("data.mailboxes[0].email"),PayLoad_MailBox.emailId, "testGet_MailBoxId__email_failed");
            //softAssert.assertEquals(response.getString("data.mailboxes[0].password"),PayLoad_MailBox.password, "testGet_MailBoxId__password_failed");
            softAssert.assertEquals(response.getString("data.mailboxes[0].groupName"),PayLoad_MailBox.groupName, "testGet_MailBoxId__groupName_failed");
            softAssert.assertEquals(response.getInt("data.mailboxes[0].groupId"),PayLoad_MailBox.groupId, "testGet_MailBoxId__gropId_failed");
            softAssert.assertEquals(response.getInt("data.mailboxes[0].projectId"),PayLoad_MailBox.projectId, "testGet_MailBoxId__projectId_failed");
            softAssert.assertEquals(response.getString("message"),"Mailbox", "testGet_MailBoxId__message_failed");
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
        
    }
    
    
    
    
    
    @Test(priority=6, groups = { "MailBox", "api","regression" })
    // MBA TC-12 : Hitting the GET API to get the credentials of a Non-existent Id as a query Param and then checking the status code and response validation
    public void testGet_Negative_NonExistentMailBoxId() throws IOException {
        HashMap<String,Object> hashMap = new HashMap<String,Object>();
        hashMap.put("id", 37282);
        Response res = PayLoad_MailBox.getRes_Get(hashMap);
        JsonPath response = PayLoad_MailBox.getJsonPath(res);
        
        
        //Asserts
        if(PayLoad_MailBox.role.equals("projectAdmin") || PayLoad_MailBox.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 200);
            softAssert.assertEquals(response.getInt("data.mailboxes.size()"),0, "testGet_Negative_NonExistentMailBoxId_mailBoxSize_failed");
            softAssert.assertEquals(response.getString("message"),"Mailbox", "testGet_Negative_NonExistentMailBoxId__message_failed");
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
        
    }
    
    
    
    
    @Test(priority=6, groups = { "MailBox", "api","regression" })
    // MBA TC-13 : Hitting the GET API to get the credentials using Email-Id as query Param and then checking the status code and response validation
    public void testGet_EmailId_MailBox() throws IOException {
        HashMap<String,Object> hashMap = new HashMap<String,Object>();
        hashMap.put("email", PayLoad_MailBox.emailId);
        Response res = PayLoad_MailBox.getRes_Get(hashMap);
        JsonPath response = PayLoad_MailBox.getJsonPath(res);
        
        
        //Asserts
        if(PayLoad_MailBox.role.equals("projectAdmin") || PayLoad_MailBox.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 200);
            softAssert.assertEquals(response.getInt("data.mailboxes[0].id"),PayLoad_MailBox.MailBoxId, "testGet_EmailId__id_failed");
            softAssert.assertEquals(response.getString("data.mailboxes[0].name"),PayLoad_MailBox.update_name, "testGet_EmailId__name_failed");
            softAssert.assertEquals(response.getString("data.mailboxes[0].email"),PayLoad_MailBox.emailId, "testGet_EmailId__email_failed");
            softAssert.assertEquals(response.getString("data.mailboxes[0].groupName"),PayLoad_MailBox.groupName, "testGet_EmailId__groupName_failed");
            softAssert.assertEquals(response.getInt("data.mailboxes[0].groupId"),PayLoad_MailBox.groupId, "testGet_EmailId__gropId_failed");
            softAssert.assertEquals(response.getInt("data.mailboxes[0].projectId"),PayLoad_MailBox.projectId, "testGet_EmailId__projectId_failed");
            softAssert.assertEquals(response.getString("message"),"Mailbox", "testGet_EmailId__message_failed");
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
    }
    
    
    
    @Test(priority=6, groups = { "MailBox", "api","regression" })
    // MBA TC-14 : Hitting the GET API to get the credentials using "offset" and "limit" as query Params and then checking the status code and response validation
    public void testGet_offset_Limit_MailBox() throws IOException {
        HashMap<String,Object> hashMap = new HashMap<String,Object>();
        hashMap.put("offset", 0);
        hashMap.put("limit", 1);
        Response res = PayLoad_MailBox.getRes_Get(hashMap);
        JsonPath response = PayLoad_MailBox.getJsonPath(res);
        
        
        //Asserts
        if(PayLoad_MailBox.role.equals("projectAdmin") || PayLoad_MailBox.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 200);
            softAssert.assertEquals(response.getInt("data.mailboxes.size()"),1, "testGet_offset_Limit__mailBoxSize_failed");
            softAssert.assertEquals(response.getInt("data.currentEntry"),0, "testGet_offset_Limit__currentEntry_failed");
            softAssert.assertEquals(response.getInt("data.pageSize"),1, "testGet_offset_Limit__pageSize_failed");
            softAssert.assertEquals(response.getString("message"),"Mailbox", "testGet_offset_Limit__message_failed");
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
        
    }
    
    
    
    
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-406
    @Test(priority=6, groups = { "MailBox", "api","regression" })
    // MBA TC-15 : Hitting the GET API to get all the credentials by not passing any query Param and then checking the status code and response validation
    public void testGet_NoParam_MailBox() throws IOException {
        HashMap<String,Object> hashMap = new HashMap<String,Object>();
        Response res = PayLoad_MailBox.getRes_Get(hashMap);
        JsonPath response = PayLoad_MailBox.getJsonPath(res);
        
        
        //Asserts
        if(PayLoad_MailBox.role.equals("projectAdmin") || PayLoad_MailBox.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 400);
            softAssert.assertEquals(response.getInt("code"),40000, "testGet_NoParam_MailBox__code_failed");
            softAssert.assertEquals(response.getString("message"),"exception in getting mailbox", "testGet_NoParam__message_failed");
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
        
    }
    
    
    
    
    
    @Test(priority=6, groups = { "MailBox", "api","regression" })
    // MBA TC-16 : Hitting the GET API to get the credentials with projectId as query Param and then checking the status code and response validation
    public void testGet_projectId_MailBox() throws IOException {
        HashMap<String,Object> hashMap = new HashMap<String,Object>();
        hashMap.put("projectId", PayLoad_MailBox.projectId);
        Response res = PayLoad_MailBox.getRes_Get(hashMap);
        JsonPath response = PayLoad_MailBox.getJsonPath(res);
        
        
        //Asserts
        if(PayLoad_MailBox.role.equals("projectAdmin") || PayLoad_MailBox.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 200);
            int numberOfMailBox = response.getInt("data.mailboxes.size()");
            for(int i=0; i<numberOfMailBox; i++) {
                softAssert.assertEquals(response.getInt("data.mailboxes["+Integer.toString(i)+"].projectId"),PayLoad_MailBox.projectId, "testGet_projectId__"+Integer.toString(i)+"th_projectId_failed");
            }
            softAssert.assertEquals(response.getString("message"),"Mailbox", "testGet_projectId__message_failed");
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
    }
    
    
    
    
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-177
    @Test(priority=6, groups = { "MailBox", "api","regression" })
    // MBA TC-17 : Hitting the GET API to get the credentials with Incorrect projectId as query Param and then checking the status code and response validation
    public void testGet_IncorrectProjectId_MailBox() throws IOException {
        HashMap<String,Object> hashMap = new HashMap<String,Object>();
        hashMap.put("projectId", 34472);
        hashMap.put("id",PayLoad_MailBox.MailBoxId);
        Response res = PayLoad_MailBox.getRes_Get(hashMap);
        JsonPath response = PayLoad_MailBox.getJsonPath(res);
        
        
        //Asserts
        if(PayLoad_MailBox.role.equals("projectAdmin") || PayLoad_MailBox.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 200);
            softAssert.assertEquals(response.getInt("data.mailboxes.size()"),0, "testGet_IncorrectProjectId__mailBoxSize_failed");
            softAssert.assertEquals(response.getString("message"),"Mailbox", "testGet_IncorrectProjectId__message_failed");
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
    }
    
    
    
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-177
    @Test(priority=6, groups = { "MailBox", "api","regression" })
    // MBA TC-18 : Hitting the GET API to get the credentials using Non-Existent Email-Id as query Param and then checking the status code and response validation
    public void testGet_NonExistentEmailId_MailBox() throws IOException {
        HashMap<String,Object> hashMap = new HashMap<String,Object>();
        hashMap.put("email", "randomNonExistent@byjus.com");
        hashMap.put("id",PayLoad_MailBox.MailBoxId);
        Response res = PayLoad_MailBox.getRes_Get(hashMap);
        JsonPath response = PayLoad_MailBox.getJsonPath(res);
        
        
        //Asserts
        if(PayLoad_MailBox.role.equals("projectAdmin") || PayLoad_MailBox.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 200);
            softAssert.assertEquals(response.getInt("data.mailboxes.size()"),0, "testGet_IncorrectProjectId__mailBoxSize_failed");
            softAssert.assertEquals(response.getString("message"),"Mailbox", "testGet_IncorrectProjectId__message_failed");
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
        
    }
    
    
    @AfterClass(alwaysRun = true, groups = { "MailBox", "api","regression" })
    public void assertAll() throws IOException {
        PayLoad_MailBox.getResPut_DeactivateServiceToken();
        PayLoad_MailBox.getResPut_DeactivateServiceToken();
    }
    
}
