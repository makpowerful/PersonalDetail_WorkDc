package testCases;

import static io.restassured.RestAssured.given;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import io.restassured.path.json.JsonPath;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Properties;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import payLoad.Payload_RuleTest;
import payLoad.payLoad_AllProgram;
import resources.ExcelData;
import resources.Utils;
import resources.base;

public class Test_RuleOneCombo extends base {

	public static Properties prop;
	public static Logger log = LogManager.getLogger(Test_RuleOneCombo.class.getName());
	static Faker faker = new Faker();
	static int randomNum = ThreadLocalRandom.current().nextInt(1000, 10000 + 1);
	static String firstName = faker.name().firstName().replaceAll("'","");
	static String lastName = faker.name().lastName().replaceAll("'","");
	static String parentName = faker.name().fullName().replaceAll("'","");
	static String Auto="Dummy ";
	static long Premiumid= 52512495345L+randomNum;
	ExcelData excelData = new ExcelData();
	ArrayList<String> al = new ArrayList<String>();
	ArrayList<String> al2 = new ArrayList<String>();
	static int counter=1;
	static int i=0;

	
	//dataProvider = "Datapro" //String Progid,String ShippingRegion,String Class
	@Test(dataProvider = "Datapro",enabled = true)
	public void Test1RuleCombo(String Operator1,String Operator2,String Conditiontype) throws Exception {

		// TODO Auto-generated method stub
		//loginPO lo=new loginPO(driver);
		//lo.FromMiddleUAT("https://byjusprod--byjusuat.lightning.force.com/lightning/r/Account/0010k00001AbVZ9AAN/view");
			String val = "OAuth ";
			String Rule="";
			Rule = given().header("Content-Type", "application/json").body(Payload_RuleTest.RulePayload_oneCombo(Operator1,Operator2,Conditiontype)).when()
					.get("https://h-stage-apigateway.byjus.onl/wfms-rule-engine/api/v1/triggerAction").then().log().all()
					.extract().response().asString();
			log.info(Rule);
	       
	        
	        //JsonPath js1 = new JsonPath(StudentCreation);
	       // String id = js1.get("compositeResponse[0].body.id");
			//log.info("The value of id is: " + id);
			excelData.setData("Rule1Combo", i + 1, 0, Operator1);
			excelData.setData("Rule1Combo", i + 1, 1, Operator2);
			excelData.setData("Rule1Combo", i + 1, 2, Conditiontype);
			excelData.setData("Rule1Combo", i + 1, 3, Rule);
			i++;
		
	}
	
	@DataProvider(name = "Datapro")
	public Object[][] testpro() throws Exception {
	    String OSValue = "";
        String OS = System.getProperty("os.name", "generic").toLowerCase(Locale.ENGLISH);
        if ((OS.indexOf("mac") >= 0) || (OS.indexOf("darwin") >= 0)) {
            OSValue = "//src//main//java//testData//TestData.xlsx";
        } else if (OS.indexOf("win") >= 0) {
            OSValue = "\\src\\main\\java\\testData\\TestData.xlsx";
        }
		Object[][] data = readData(System.getProperty("user.dir") + OSValue,
				"Rule1Combo");
		return data;
	}

}
