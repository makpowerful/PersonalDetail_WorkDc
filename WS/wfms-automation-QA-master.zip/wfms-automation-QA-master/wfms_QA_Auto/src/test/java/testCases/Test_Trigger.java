package testCases;

import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Properties;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import payLoad.Payload_Trigger;
import resources.ExcelData;
import resources.base;

public class Test_Trigger extends base {
    
    public static Properties prop;
    public static Logger log = LogManager.getLogger(Test_RuleTwoCombo.class.getName());
    static Faker faker = new Faker();
    static int randomNum = ThreadLocalRandom.current().nextInt(1000, 10000 + 1);
    static String firstName = faker.name().firstName().replaceAll("'","");
    static String lastName = faker.name().lastName().replaceAll("'","");
    static String parentName = faker.name().fullName().replaceAll("'","");
    static String Auto="Dummy ";
    static long Premiumid= 52512495345L+randomNum;
    ExcelData excelData = new ExcelData();
    ArrayList<String> al = new ArrayList<String>();
    ArrayList<String> al2 = new ArrayList<String>();
    static int counter=1;
    static int i=0;
    
    @Test(dataProvider = "Datapro",enabled = true)
    public void Test1RuleCombo(String property, String operator, String value, String action, String status) throws Exception {
        
        System.out.println(property + "\t" + operator + "\t" + value + "\t" + action + "\t" + status);
        
        // TODO Auto-generated method stub
        //loginPO lo=new loginPO(driver);
        //lo.FromMiddleUAT("https://byjusprod--byjusuat.lightning.force.com/lightning/r/Account/0010k00001AbVZ9AAN/view");
//            String val = "OAuth ";
//            String Rule="";
//            Rule = given().header("Content-Type", "application/json").body(Payload_Trigger.RulePayload_twoCombo(property, operator, value, Integer.parseInt(action))).when()
//                    .post("https://h-stage-apigateway.byjus.onl/wfms-rule-engine/api/v1/rules").then().log().all()
//                    .extract().response().asString();
//            log.info(Rule);
        
        String rule = "";
        Response response;
        
            
        String payload = Payload_Trigger.RulePayload_twoCombo(property, operator, value, Integer.parseInt(action));
//            System.out.println(payload);
        
        response = given().header("Content-Type", "application/json").body(payload).when() 
                .post("https://h-stage-apigateway.byjus.onl/wfms-rule-engine/api/v1/rules");
        response.then().log().all();
        
        rule = response.asString();
        JsonPath js = response.jsonPath();
        
        int id = js.getInt("data.ruleDto.id");
        System.out.println("This is id: " + id);

        //JsonPath js1 = new JsonPath(StudentCreation);
       // String id = js1.get("compositeResponse[0].body.id");
        //log.info("The value of id is: " + id);
        excelData.setData("Rule2Combo", i + 1, 0, property);
        excelData.setData("Rule2Combo", i + 1, 1, operator);
        excelData.setData("Rule2Combo", i + 1, 2, value);
        excelData.setData("Rule2Combo", i + 1, 3, action);
        excelData.setData("Rule2Combo", i + 1, 4, rule);
        
        i++;
        
        response = given().header("Content-Type", "application/json").when().delete("https://h-stage-apigateway.byjus.onl/wfms-rule-engine/api/v1/rules/" + id);
        response.then().log().all();
    }
    
    @DataProvider(name = "Datapro")
    public Object[][] testpro() throws Exception {
        String OSValue = "";
        String OS = System.getProperty("os.name", "generic").toLowerCase(Locale.ENGLISH);
        if ((OS.indexOf("mac") >= 0) || (OS.indexOf("darwin") >= 0)) {
            OSValue = "//src//main//java//testData//TriggersTestSheet.xlsx";
        } else if (OS.indexOf("win") >= 0) {
            OSValue = "\\src\\main\\java\\testData\\TriggersTestSheet.xlsx";
        }
        Object[][] data = readData(System.getProperty("user.dir") + OSValue,
                "triggerTest");
        return data;
    }
    
}
