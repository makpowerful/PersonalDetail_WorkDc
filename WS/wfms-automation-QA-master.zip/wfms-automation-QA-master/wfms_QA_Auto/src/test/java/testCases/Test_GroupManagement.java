package testCases;

import java.io.IOException;
import java.util.ArrayList;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import payLoad.Payload_GroupManagement;
import resources.ExcelData;
import resources.base;

public class Test_GroupManagement extends base {
    private static SoftAssert softAssert = new SoftAssert();
    public ExcelData excelData = new ExcelData();
    public ArrayList<String> al = new ArrayList<String>();
    
    @Parameters({"sessionToken","role","projectId"})
    @BeforeClass(alwaysRun = true)
    public void setValues(String token, String role, int projectId) throws IOException, InterruptedException {
        Payload_GroupManagement.role = role;

        al = excelData.getData(url, "GlobalProjectIds", "Tcid");
        Payload_GroupManagement.projectId = Integer.parseInt(al.get(1));  
        
        Payload_GroupManagement.sessionToken = token;
        Payload_GroupManagement.setHeaderMap();
    }


    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-398
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-139
    @Test(priority=1, groups = { "GroupManagement", "api","regression" })
    // GMGA TC-01 : Hitting the API and creating a record then checking the status code and response validation
    public void testPostGroupManagement() throws IOException {
        Response res = Payload_GroupManagement.getResponsePost();
        JsonPath response = Payload_GroupManagement.getJsonPath(res);
        
        al = excelData.getData("CreateGroup", "GroupManagement_API", "Tcid");
        //Asserts
        if(Payload_GroupManagement.role.equals("supervisor") || Payload_GroupManagement.role.equals("projectAdmin") || Payload_GroupManagement.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 201);
            softAssert.assertEquals(Payload_GroupManagement.al.get(1),response.getString("data.group.groupName"),"post_GroupName_Assert_Failed");
            softAssert.assertEquals(Payload_GroupManagement.projectId,response.getInt("data.group.projectId"),"post_projectId_Assert_Failed");
            softAssert.assertEquals(al.get(2),response.getString("data.group.ownerEmail"),"post_ownerEmail_Assert_Failed");
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
        
    }
    
    
    @Test(priority=2, groups = { "GroupManagement", "api","regression" })
    // GMGA TC-13 : Sending string in fields group id and project_id
    public void testPostNegative_StringProjectId_GroupManagement() throws IOException {
        Response res = Payload_GroupManagement.getResponsePostNegative_StringProjectId();
        JsonPath response = Payload_GroupManagement.getJsonPath(res);

        //Assertions
        if(Payload_GroupManagement.role.equals("supervisor") || Payload_GroupManagement.role.equals("projectAdmin") || Payload_GroupManagement.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 400);
        }else {
            Assert.assertEquals(res.statusCode(), 400);
        }
        
    }
    
    
    @Test(priority=2, groups = { "GroupManagement", "api","regression" })
    // GMGA TC-14 : Sending negative number in fields project_id
    public void testPostNegative_NegativeProjectIdNumber_GroupManagement() throws IOException {
        Response res = Payload_GroupManagement.getResponsePostNegative_NegativeProjectIdNumber();
        JsonPath response = Payload_GroupManagement.getJsonPath(res);

        //Assertions
        if(Payload_GroupManagement.role.equals("supervisor") || Payload_GroupManagement.role.equals("projectAdmin") || Payload_GroupManagement.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 400);
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
        
    }
    
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-139
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-119
    @Test(priority=2, groups = { "GroupManagement", "api","regression" })
    // GMGA TC-02 : Hitting the API and editing an existing record then checking the status code and response validation
    public void testPutGroupManagement() throws IOException {
        Response res = Payload_GroupManagement.getResponsePut();
        JsonPath response = Payload_GroupManagement.getJsonPath(res);
        
        al = excelData.getData("PutGroup", "GroupManagement_API", "Tcid");
        //Asserts
        if(Payload_GroupManagement.role.equals("supervisor") || Payload_GroupManagement.role.equals("projectAdmin") || Payload_GroupManagement.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 200);
            softAssert.assertEquals(Payload_GroupManagement.al.get(1),response.getString("data.group.groupName"),"put_GroupName_Assert_Failed");
            softAssert.assertEquals(Payload_GroupManagement.projectId,response.getInt("data.group.projectId"),"put_projectId_Assert_Failed");
            softAssert.assertEquals(al.get(2),response.getString("data.group.ownerEmail"),"put_ownerEmail_Assert_Failed");
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
    }
    
    
    @Test(priority=3, groups = { "GroupManagement", "api","regression" })
    // GMGA TC-15 : Sending string in fields group id and project_id
    public void testPutNegative_StringProjectId_GroupManagement() throws IOException {
        Response res = Payload_GroupManagement.getResponsePutNegative_StringProjectId();
        JsonPath response = Payload_GroupManagement.getJsonPath(res);
        
        //Assertions
        if(Payload_GroupManagement.role.equals("supervisor") || Payload_GroupManagement.role.equals("projectAdmin") || Payload_GroupManagement.role.equals("superAdmin")) {
            Assert.assertEquals(res.statusCode(), 200);
        }else {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }
        
    }
    
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-135
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-121
    @Test(priority=3, groups = { "GroupManagement", "api","regression" })
    // GMGA TC-16 : Sending negative number in fields group id and project_id
    public void testPutNegative_NegativeProjectIdNumber_GroupManagement() throws IOException {
        Response res = Payload_GroupManagement.getResponsePutNegative_NegativeProjectIdNumber();
        JsonPath response = Payload_GroupManagement.getJsonPath(res);
        
        //Assertions
        Assert.assertEquals(res.statusCode(), 400);
    }
    
    
    
    @Test(priority=3, groups = { "GroupManagement", "api","regression" })
    // GMGA TC-05 : Hitting the GET api to get details of groups of a project with id as projectID and assert the response.
    public void testGetWithProjectId_GroupManagement() {
        Response res = Payload_GroupManagement.getResponseGetWithProjectId();
        JsonPath response = Payload_GroupManagement.getJsonPath(res);
        
        //Asserts
            Assert.assertEquals(res.statusCode(), 200);
            //softAssert.assertEquals(Payload_GroupManagement.groupId,response.getInt("data[0].group.groupId"),"Get_ProjectId_GroupID_Assert_Failed");
            softAssert.assertEquals(Payload_GroupManagement.projectId,response.getInt("data[0].group.projectId"),"Get_ProjectId_ProjectId_Assert_Failed");
        
    }
    
    
    @Test(priority=3, groups = { "GroupManagement", "api","regression" })
    // GMGA TC-08 : Hitting the GET api to get details of a group with given ProjectId, GroupName and Date and assert the response.
    public void testGet_ByProjectId_groupName_date_GroupManagement() {
        Response res = Payload_GroupManagement.getResponseGet_ByProjectId_groupName_date();
        JsonPath response = Payload_GroupManagement.getJsonPath(res);
        
        //Asserts
            Assert.assertEquals(res.statusCode(), 200);
//            //softAssert.assertEquals(Payload_GroupManagement.groupId,response.getInt("data[0].group.groupId"),"Get_ByProjectId_groupName_date_GroupID_Assert_Failed, getting "+response.getInt("data[0].group.groupId")+" "+Payload_GroupManagement.groupId);
//            softAssert.assertEquals(Payload_GroupManagement.projectId,response.getInt("data[0].group.projectId"),"Get_ByProjectId_groupName_date_ProjectId_Assert_Failed getting "+response.getInt("data[0].group.projectId")+" "+Payload_GroupManagement.projectId);
//            softAssert.assertEquals(Payload_GroupManagement.date,response.getString("data[0].group.createdAt").split("T")[0],"Get_ByProjectId_groupName_date_ProjectId_Assert_Failed");
    }
    
    
    @Test(priority=4, groups = { "GroupManagement", "api","regression" })
    // GMGA TC-09 : Hitting the GET api to the list of all GROUPS with a given projectID which does not exist and assert the response.
    public void testGetNegativeNonExistentProjectId_GroupManagement() {
        Response res = Payload_GroupManagement.getResponseGetNegativeNonExistentProjectId();
        JsonPath response = Payload_GroupManagement.getJsonPath(res);
        
        //Asserts
        Assert.assertEquals(res.statusCode(), 200);
        softAssert.assertEquals(response.getInt("data.size()"),0,"Get_Negative_ByProjectID_assert_Failed");
    }
    
    
    
    @Test(priority=3, groups = { "GroupManagement", "api","regression" })
    // GMGA TC-12 : Hitting the GET api to the list of all GROUPS with given projectId and AgentName and assert the response.
    public void testGet_ByProjectIDAndAgentName_GroupManagement() {
        Response res = Payload_GroupManagement.getResponseGet_ByProjectIDAndAgentName();
        JsonPath response = Payload_GroupManagement.getJsonPath(res);
        
        //Asserts
            Assert.assertEquals(res.statusCode(), 200);
            softAssert.assertEquals(Payload_GroupManagement.projectId,response.getInt("data[0].group.projectId"),"Get_ProjectId&groupName_ProjectId_Assert_Failed");
    }
    
    
    
    
    @Test(priority=3, groups = { "GroupManagement", "api","regression" }, enabled=false)
    // GMGA TC-20 : Hitting the GET api to the list of all Agents with given projectId and assert the response.
    public void testGet_AgentList_GroupManagement() {
        Response res = Payload_GroupManagement.getResponseGet_AgentList();
        JsonPath response = Payload_GroupManagement.getJsonPath(res);
        
        //Asserts
        if(Payload_GroupManagement.role.equals("requester")) {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }else {
            Assert.assertEquals(res.statusCode(), 200);
        }
    }
    
    
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-416
    @Test(priority=8, groups = { "GroupManagement", "api","regression" })
    // GMGA TC-21 : Hitting the GET api to the list of all Agents with a Non-Existent projectId and assert the response.
    public void testGet_AgentList_Negative_GroupManagement() {
        Response res = Payload_GroupManagement.getResponseGet_Negative_AgentList();
        JsonPath response = Payload_GroupManagement.getJsonPath(res);
        
        //Asserts
        Assert.assertEquals(res.statusCode(), 200);
        softAssert.assertEquals(response.getInt("data.size()"),0,"testGet_AgentList_Negative_GroupManagement__dataSize_assert_Failed");
       
    }
    
    
    
    @Test(priority=4, groups = { "GroupManagement", "api","regression" })
    // GMGA TC-12 : Hitting the GET api to the list of all GROUPS with given projectId and AgentName and assert the response.
    public void testGetNegative_ByProjectIDAndNon_Existent_AgentName_GroupManagement() {
        Response res = Payload_GroupManagement.getResponseGetNegative_ByProjectIDAndNon_Existent_AgentName();
        JsonPath response = Payload_GroupManagement.getJsonPath(res);
        
        //Asserts
            Assert.assertEquals(res.statusCode(), 200);
            softAssert.assertEquals(response.getInt("data.size()"),0,"Get_Negative_ByProjectIDAndNon_Existent_AgentName_assert_Failed");
    }
    
    @Test(priority=6, groups = { "GroupManagement", "api","regression" })
    // GMGA TC-17 : Hitting the GET api to the list of all GROUPS with given projectId, sortBy and sortType and assert the response.
    public void testGet_ByProjectID_sortBy_sortType_GroupManagement() throws IOException {
        Response res = Payload_GroupManagement.getResponseGet_ByProjectID_sortBy_sortType();
        JsonPath response = Payload_GroupManagement.getJsonPath(res);

        //Assertions
            Assert.assertEquals(res.statusCode(), 200);
            Boolean checkSort = Payload_GroupManagement.checkSortAndDelete();
            //Asserts
            softAssert.assertTrue(checkSort, "Get_ByProjectID_sortBy_sortType_assert_Failed");
        
    }
    
    
    @Test(priority=7, groups = { "GroupManagement", "api","regression" })
    // GMGA TC-18 : Hitting the GET api to the list of all GROUPS with given projectId, pageSize and pageNumber and assert the response.
    public void testGet_ByProjectID_pageNumber_pageSize_GroupManagement() throws IOException {
        Response res = Payload_GroupManagement.getResponseGet_ByProjectID_pageNumber_pageSize();
        JsonPath response = Payload_GroupManagement.getJsonPath(res);
        
        //Asserts
            Assert.assertEquals(res.statusCode(), 200);
            softAssert.assertEquals(response.getInt("data.size()"),Payload_GroupManagement.pageSize,"Get_ByProjectID_pageNumber_pageSize_assert_Failed");
            System.out.println("what count am i getting = "+response.getInt("data.size()"));
        
    }



    @Test(priority=5, groups = { "GroupManagement", "api","regression" })
    // GMGA TC-10 : Hitting the DELETE api to delete a group with the provided GroupId as a parameter and validating the response.
    public void testDeleteGroupManagement() {
        Response res = Payload_GroupManagement.getResponseDelete(Payload_GroupManagement.groupId);
        JsonPath response = Payload_GroupManagement.getJsonPath(res);

        //Assertions
        if(Payload_GroupManagement.role.equals("requester") || Payload_GroupManagement.role.equals("agent")) {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }else {
            Assert.assertEquals(res.statusCode(), 200);
        }
    }
    
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-136
    @Test(priority=10, groups = { "GroupManagement", "api","regression" })
    // GMGA TC-11 : Hitting the DELETE api to delete a group with the provided GroupId which does not exist as a parameter and validating the response.
    public void testDeleteNegativeNonExistentGroupId_GroupManagement() {
        Response res = Payload_GroupManagement.getResponseDeleteNegativeNonExistentGroupId();
        JsonPath response = Payload_GroupManagement.getJsonPath(res);

        //Assertions
        if(Payload_GroupManagement.role.equals("requester") || Payload_GroupManagement.role.equals("agent")) {
            Assert.assertEquals(res.statusCode(), 403);
            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
        }else {
            Assert.assertEquals(res.statusCode(), 404);
        }
    }
    
    
    
    @AfterClass(alwaysRun = true)
    public void testAssertAll() {
        softAssert.assertAll();
    }
   
}
