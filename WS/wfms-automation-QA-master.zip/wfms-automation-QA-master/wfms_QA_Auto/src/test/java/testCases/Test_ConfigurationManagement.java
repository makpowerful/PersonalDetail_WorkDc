package testCases;


import java.io.IOException;
import java.util.ArrayList;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import payLoad.Payload_ProjectConfiguration;
import resources.ExcelData;
import resources.base;

public class Test_ConfigurationManagement extends base{
    private static SoftAssert softAssert = new SoftAssert();
    public static int version =0;
    private String role;
    public ExcelData excelData = new ExcelData();
    public ArrayList<String> al = new ArrayList<String>();
    public int versionNumber;
    
    @Parameters({"sessionToken","role","projectId"})
    @BeforeClass(alwaysRun = true, groups = { "ConversationManagement", "api","regression" })
    public void initialize(String token,String role,int projectId) throws IOException, InterruptedException {
        this.role =role;

        al = excelData.getData(url, "GlobalProjectIds", "Tcid");
        Payload_ProjectConfiguration.projectId = Integer.parseInt(al.get(1));  
        
        Payload_ProjectConfiguration.sessionToken = token;
        Payload_ProjectConfiguration.setHeaderMap();
    }

    
    // CA_TC-1: Hitting the API's POST method and checking the status code + response validation
    @Test(priority=1, groups = { "ConfigurationManagement", "api","regression" }, invocationCount =2)
    public void testPostProjectConfiguration() throws IOException {

        Response res = Payload_ProjectConfiguration.getResponsePost();
        JsonPath response = Payload_ProjectConfiguration.getJsonPath(res);
        version++;

        //Assertions 
        Assert.assertEquals(res.statusCode(), 200);
        softAssert.assertEquals(Payload_ProjectConfiguration.projectId,response.getInt("data.projectId"),"Post Id assert failed");
        softAssert.assertEquals(Payload_ProjectConfiguration.al.get(2),response.getString("data.projectName"),"Post name assert failed");
        softAssert.assertEquals(Payload_ProjectConfiguration.al.get(3), response.getString("data.resourceType"),"Post resource assert failed");
    }
   
    
    // CA_TC-3 : Hitting the API's GET ("/wfms/configurationManagement/v1/projectList/{resourceType}") method and checking the status code + response validation
//    @Test(priority=3, groups = { "ConfigurationManagement", "api","regression" })
//    public void testGetProjectList() {
//        JSONArray response = Payload_ProjectConfiguration.getResponseGetProjectList();
//        
//        //Assertions
//        softAssert.assertEquals(Payload_ProjectConfiguration.al.get(2),response.get(0),"getList response failed");
//        //Status Code assertion has already been done inside the called method above.
//    }
    

    // CA_TC-4 : Hitting the API's GET("/wfms/configurationManagement/v1/projectConfiguration/{id}/{resourceType}") method and checking the status code + response validation
    @Test(priority=2, groups = { "ConfigurationManagement", "api","regression" })
    public void testGetProjectConfigurationId() {
        Response res = Payload_ProjectConfiguration.getResponseGetProjectConfigurationID();
        JsonPath response = Payload_ProjectConfiguration.getJsonPath(res);
        
        //Assertions
        Assert.assertEquals(res.statusCode(), 200);
        versionNumber = response.getInt("data.versionNumber");
        softAssert.assertEquals(Payload_ProjectConfiguration.projectId,response.getInt("data.projectId"),"getById__ProjectId_assert_failed");
        softAssert.assertEquals(Payload_ProjectConfiguration.al.get(2),response.getString("data.projectName"),"getId name assert failed");
        softAssert.assertEquals(Payload_ProjectConfiguration.al.get(3), response.getString("data.resourceType"),"getId resource assert failed");
    }
    
    
    // CA_TC-5 : Hitting the API's GET("/wfms/configurationManagement/v1/projectConfiguration/{id}/{versionNumber}/{resourceType}") method and checking the status code + response validation
    @Test(priority=3, groups = { "ConfigurationManagement", "api","regression" })
    public void testGetProjectConfigurationVersionNumber() {
        Response res = Payload_ProjectConfiguration.getResponseGetProjectConfigurationVersionNumber(versionNumber);
        JsonPath response = Payload_ProjectConfiguration.getJsonPath(res);
        
        //Assertions
        Assert.assertEquals(res.statusCode(), 200);
        softAssert.assertEquals(Payload_ProjectConfiguration.projectId,response.getInt("data.projectId"),"GetVersion Id assert failed");
        softAssert.assertEquals(Payload_ProjectConfiguration.al.get(2),response.getString("data.projectName"),"GetVersion name assert failed");
        softAssert.assertEquals(Payload_ProjectConfiguration.al.get(3), response.getString("data.resourceType"),"GetVersion resource assert failed");
    }
    
    
    // CA_TC-9 : Hitting the API's DELETE method and checking the status code + response validation
//    @Test(priority=4, groups = { "ConfigurationManagement", "api","regression" },enabled=false)
//    public void testDeleteProjectConfiguration() {
//        Response res= Payload_ProjectConfiguration.getResponseDELETEProjectConfiguration();
//        JsonPath response = Payload_ProjectConfiguration.getJsonPath(res);
//        
//        //Assertions
//        Assert.assertEquals(res.statusCode(), 200);
//        softAssert.assertEquals(response.getString("message"),"Config deleted", "delete assert failed");
//    }
    
    // CA_TC-11 : Hitting the API's DELETE(particular Version) method with existing project parameters and checking the status code + response validation
//    @Test(priority=2, groups = { "ConfigurationManagement", "api","regression" })
//    public void testDeleteVersion() {
//        Response response= Payload_ProjectConfiguration.getResponseDELETEVersionProjectConfiguration();
//        
//        //Assertions
//        softAssert.assertEquals("Successfully deleted", response, "deleteVersion assert failed");
//        //Status Code assertion has already been done inside the called method above.
//        version--;
//    }
    

    // CA_TC-2 : Hitting the API's POST method with a Long Unacceptable ProjectId + status code validation
    @Test(priority=1, groups = { "ConfigurationManagement", "api","regression" })
    public void testPostProjectConfigurationLongId() throws Exception {
        Response res = Payload_ProjectConfiguration.getFailureResponsePostLongId();
        JsonPath response = Payload_ProjectConfiguration.getJsonPath(res);
        
        //Assertions
        Assert.assertEquals(res.statusCode(), 400);
        softAssert.assertEquals("Bad Request", response.get("error"), "Invalid LongId assert failed");
    }
    
    
    // CA_TC-6 : Hitting the API's GET method with a Non-existing ProjectId + status code validation
    @Test(priority=2, groups = { "ConfigurationManagement", "api","regression" })
    public void testGetProjectConfigurationWrongId() throws Exception {
        Response res = Payload_ProjectConfiguration.getConfigWrongId();
        JsonPath response = Payload_ProjectConfiguration.getJsonPath(res);
        
        //Assertions
        Assert.assertEquals(res.statusCode(), 404);
        softAssert.assertEquals("Not Found", response.get("error"), "wrongId assert failed");
    }
    
    
    // CA_TC-7 : Hitting the API's GET method with a Non-existing Resource Type + status code validation
    @Test(priority=2, groups = { "ConfigurationManagement", "api","regression" })
    public void testGetProjectConfigurationWrongResource() throws Exception {
        Response res = Payload_ProjectConfiguration.getConfigWrongResource();
        JsonPath response = Payload_ProjectConfiguration.getJsonPath(res);
        
        //Assertions
        Assert.assertEquals(res.statusCode(), 404);
        softAssert.assertEquals("Not Found", response.get("error"), "WrongResource assert failed");
    }
    
    
    // CA_TC-8 : Hitting the API's GET method with a Non-existing versionNumber + status code validation
    @Test(priority=2, groups = { "ConfigurationManagement", "api","regression" })
    public void testGetProjectConfigurationUnrealVersion() throws Exception {
        Response res = Payload_ProjectConfiguration.getConfigUnrealVersion(version+103424);
        
        //Assertions
        Assert.assertEquals(res.statusCode(), 404);
    }
    
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-397
    // CA_TC-10 : Hitting the API's DELETE(all Version) method with Non-existing project parameters and checking the status code + response validation
    @Test(priority=5, groups = { "ConfigurationManagement", "api","regression" })
    public void testDeleteNon_existingProjectConfiguration() {
        Response res= Payload_ProjectConfiguration.getResponseDELETENon_existingProjectConfiguration();
        JsonPath response = Payload_ProjectConfiguration.getJsonPath(res);
        
        //Assertions
        Assert.assertEquals(res.statusCode(), 404);
        softAssert.assertEquals("Not Found", response.getString("error"), "deleteNon_existing assert failed");
    }
    
    
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-397
    // CA_TC-12 : Hitting the API's DELETE(particular Version) method with Non-existing project parameters and checking the status code + response validation
//    @Test(priority=3, groups = { "ConfigurationManagement", "api","regression" })
//    public void testDeleteVersionNon_existing() {
//        Response res= Payload_ProjectConfiguration.getResponseDELETEVersionNon_existingProjectConfiguration();
//        JsonPath response = Payload_ProjectConfiguration.getJsonPath(res);
//        
//        //Assertions
//        softAssert.assertEquals("Not Found", response.getString("error"), "deleteVersionNon_existing assert failed");
//        //Status Code assertion has already been done inside the called method above.
//    }
      
    
    
    
    @AfterClass(alwaysRun = true, groups = { "ConfigurationManagement", "api","regression" })
    public void checkAssertions() {
        softAssert.assertAll();
    }
}
