package testCases;

import java.io.IOException;
import java.util.ArrayList;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import payLoad.Payload_ProjectManagement;
import payLoad.Payload_TicketController;
import resources.ExcelData;
import resources.base;

public class Test_ProjectManagement extends base{
    public ExcelData excelData = new ExcelData();
    public ArrayList<String> al = new ArrayList<String>();
    private SoftAssert softAssert = new SoftAssert();
    private Response response;
    private JsonPath js;
    private String payload;
    private int id;
    private String role;
    
    @BeforeClass(alwaysRun = true)
    @Parameters({"sessionToken", "role", "projectId"})
    public void setToken(String sessionToken,String role, String projectId) throws IOException {
        this.role = role;
        
        al = excelData.getData(url, "GlobalProjectIds", "Tcid");
        Payload_TicketController.setHeaderMap(Integer.toString(Integer.parseInt(al.get(1))), sessionToken);
    }
    
    // ----------------------------------------------------------------------------------------------------
    // PMA-POST01-01 : Create a new project with a unique project id
    // ----------------------------------------------------------------------------------------------------
    @Test(priority = 1, groups = {"projectManagement", "api","regression"})
    public void testCreateProject() throws IOException {
        
        payload = Payload_ProjectManagement.getCreateProjectPayload("POST1");
        
        response = Payload_ProjectManagement.createProject(payload);
        js = response.jsonPath();
        al = excelData.getData("POST1", "ProjectManagement_API", "Tcid");
        
        // softAssert.assertEquals(response.statusCode(), 201, "PMA_POST_01 - error in status code");
        softAssert.assertEquals(response.statusCode(), 200, "PMA_POST_01 - error in status code");
        
        softAssert.assertEquals(js.getInt("data.projectId"), Integer.parseInt(al.get(1)), "PMA_POST_01 - error in project id");
        softAssert.assertEquals(js.get("data.name"), al.get(2), "PMA_POST_01 - error in name");
        softAssert.assertEquals(js.get("data.description"), al.get(3), "PMA_POST_01 - error in description");
        softAssert.assertEquals(js.getBoolean("data.inUse"), Boolean.parseBoolean(al.get(4)), "PMA_POST_01 - error in inUse");
        softAssert.assertEquals(js.get("data.createdBy"), al.get(6), "PMA_POST_01 - error in created by");
        softAssert.assertEquals(js.get("data.updatedBy"), al.get(8), "PMA_POST_01 - error in updated by");
        softAssert.assertEquals(js.get("message"), "Project Added", "PMA_POST_01 - error in message");
        
        id = Integer.parseInt(al.get(1));
    }
    
    // ----------------------------------------------------------------------------------------------------
    // PMA-GET02-01 : Get Details of a project using its id
    // ----------------------------------------------------------------------------------------------------
    @Test(priority = 2, groups= {"projectManagement", "api","regression"})
    public void testGetProjectDetail() throws IOException {
        
        response = Payload_ProjectManagement.getProjectDetail(id);
        js = response.jsonPath();
        al = excelData.getData("GET", "ProjectManagement_API", "Tcid");
        
        softAssert.assertEquals(response.statusCode(), 200);
        
        softAssert.assertEquals(js.getInt("data.projectId"), Integer.parseInt(al.get(1)), "PMA_POST_02 - error in project id");
        softAssert.assertEquals(js.get("data.name"), al.get(2), "PMA_POST_02 - error in name");
        softAssert.assertEquals(js.get("data.description"), al.get(3), "PMA_POST_02 - error in description");
        softAssert.assertEquals(js.getBoolean("data.inUse"), Boolean.parseBoolean(al.get(4)), "PMA_POST_02 - error in inUse");
        softAssert.assertEquals(js.get("data.createdBy"), al.get(6), "PMA_POST_02 - error in created by");
        softAssert.assertEquals(js.get("data.updatedBy"), al.get(8), "PMA_POST_02 - error in updated by");
    }
    
    // ----------------------------------------------------------------------------------------------------
    // PMA_POST01_02 : Update a project using its id
    // ----------------------------------------------------------------------------------------------------
    @Test(priority = 3, groups= {"projectManagement", "api","regression"})
    public void testUpdateProject() throws IOException {
        
        payload = Payload_ProjectManagement.getUpdateProjectPayload();
        
        response = Payload_ProjectManagement.updateProject(payload);
        js = response.jsonPath();
        al = excelData.getData("POST1", "ProjectManagement_API", "Tcid");

        softAssert.assertEquals(response.statusCode(), 200, "PMA_POST_01_02 - error in status code");
        
        softAssert.assertEquals(js.getInt("data.projectId"), Integer.parseInt(al.get(1)), "PMA_POST_01_02 - error in project id");
        softAssert.assertEquals(js.get("data.name"), al.get(2), "PMA_POST_01_02 - error in name");
        softAssert.assertEquals(js.get("data.description"), al.get(3), "PMA_POST_01_02 - error in description");
        softAssert.assertEquals(js.getBoolean("data.inUse"), Boolean.parseBoolean(al.get(4)), "PMA_POST_01_02 - error in project isUse");
        softAssert.assertEquals(js.get("data.createdBy"), al.get(6), "PMA_POST_01_02 - error in project created by");
        softAssert.assertEquals(js.get("data.updatedBy"), al.get(8), "PMA_POST_01_02 - error in project updated by");
    }
    
    // ----------------------------------------------------------------------------------------------------
    // PMA_GET01_01 : Get list of details of all projects
    // ----------------------------------------------------------------------------------------------------
    @Test(priority = 4, groups= {"projectManagement", "api","regression"})
    public void testGetProjectDetailsList() throws IOException {
        
        response = Payload_ProjectManagement.getProjectDetailsList();
        js = response.jsonPath();
        al = excelData.getData("GET", "ProjectManagement_API", "Tcid");
        
        softAssert.assertEquals(response.statusCode(), 200, "PMA_GET01__01 - error in status code");
    }

    // ---------------------------------------------------------------------------------------------------- 
    // PMA_DELETE_01_01 : Delete a project using id
    // ----------------------------------------------------------------------------------------------------
    @Test(priority = 6, groups= {"projectManagement", "api","regression"})
    public void testDeleteProject() {
        
        response = Payload_ProjectManagement.deleteProject(id);
        js = response.jsonPath();
        
        softAssert.assertEquals(response.statusCode(), 200, "PMA_DELETE_01_01 - error in status code");
        
        softAssert.assertEquals(js.get("message"), "Project deleted", "PMA_DELETE_01_01 - error in message");
    }
    
    // ----------------------------------------------------------------------------------------------------
    // PMA_GET02_02 : Get details of a project using non-existing project id
    // ----------------------------------------------------------------------------------------------------
    @Test(priority = 7, groups= {"projectManagement", "api","regression"})
    public void testGetProjectDetailNonExistingProject() {
        
        response = Payload_ProjectManagement.getProjectDetail(id);
        
         softAssert.assertEquals(response.statusCode(), 404, "PMA_GET02_02 - error in status code");
    }
    
    // ---------------------------------------------------------------------------------------------------- 
    // PMA_DELETE01_02 : Delete a project using non-existing id
    // ----------------------------------------------------------------------------------------------------
    @Test(priority = 8, groups= {"projectManagement", "api","regression"})
    public void testDeleteNonExistingProject() {
        
        response = Payload_ProjectManagement.deleteProject(id);
        
        softAssert.assertEquals(response.statusCode(), 404, "PMA_DELETE_02 - error in status code");
    }
    
    // ----------------------------------------------------------------------------------------------------
    // PMA_GET02_03 : Get details of a project using invalid id path parameter
    // ----------------------------------------------------------------------------------------------------
    @Test(priority = 9, groups= {"projectManagement", "api","regression"})
    public void testGetProjectDetailInvalidProjectId() {
        
        response = Payload_ProjectManagement.getProjectDetail("abc");
        
        softAssert.assertEquals(response.statusCode(), 400, "PMA_GET_02_03 - error in status code");
    }
    
    // ----------------------------------------------------------------------------------------------------
    // PMA_DELETE01_03 : Delete a project using invalid id path parameter
    // ----------------------------------------------------------------------------------------------------
    @Test(priority = 10, groups= {"projectManagement", "api","regression"})
    public void testDeleteProjectInvalidProjectId() {
        
        response = Payload_ProjectManagement.deleteProject("abc");
        
        softAssert.assertEquals(response.statusCode(), 400, "PMA_DELETE_01_03 - error in status code");
    }
    
    @AfterClass(alwaysRun = true)
    public void softAssertAll() {
        
        softAssert.assertAll();
    }
}
