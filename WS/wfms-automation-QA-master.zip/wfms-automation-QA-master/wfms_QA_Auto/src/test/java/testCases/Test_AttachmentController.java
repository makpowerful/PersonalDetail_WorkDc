package testCases;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import payLoad.Payload_AttachmentController;
import resources.ExcelData;
import resources.base;

public class Test_AttachmentController extends base{
    private String id = "";
    private static SoftAssert softAssert = new SoftAssert();
    public static Logger log = LogManager.getLogger(Test_TicketController.class.getName());
    private static ExcelData excelData = new ExcelData();
    private static ArrayList<String> al = new ArrayList<String>();
    
    @BeforeClass(alwaysRun = true)
    @Parameters({"sessionToken", "role", "projectId"})
    public void setToken(String sessionToken,String role, String projectId) throws IOException {
        
//        Payload_AttachmentController.setHeaderMap(projectId, sessionToken);
        
        al = excelData.getData(url, "GlobalProjectIds", "Tcid");
        Payload_AttachmentController.setHeaderMap(Integer.toString(Integer.parseInt(al.get(1))), sessionToken);
    }
    
    // AA TC-01: Hitting the API and checking the status code + response validation
    // Defect Id: https://byjustech.atlassian.net/browse/WFM-395

    @Test(priority = 1, groups= {"attachmentController", "api","regression"})
    public void testCreateAttachmentId() throws IOException {
        al = excelData.getData("fileUnder5", "AttachmentController_API", "Tcid");
        Response response = Payload_AttachmentController.postAttachmentResponse(al.get(0), al.get(3));
        response.then().assertThat().statusCode(201);
        JsonPath js = Payload_AttachmentController.getJsonPath(response);
        id = js.getString("data.id");

        // Assertion for this Test
        assertEquals(js.getInt("code"), 20001);
        softAssert.assertTrue(js.getString("data.fileName").contains("fileUnder5.jpeg"), "Check for fileName");
        log.info("Response of testCreateAttachmentId is: " + response.asString());
    }
    
    // AA TC-03: File type check (only image and pdf allowed) and status code verification 
    
    @Test(priority = 1, groups= {"attachmentController", "api","regression"})
    public void testFileType() throws IOException {
        al = excelData.getData("sample-3", "AttachmentController_API", "Tcid");
        Response response = Payload_AttachmentController.postAttachmentResponse(al.get(0), al.get(3));
        response.then().assertThat().statusCode(415);
        JsonPath js = Payload_AttachmentController.getJsonPath(response);

        // Assertion for this Test
        assertEquals(js.getInt("code"), 40006);
        softAssert.assertEquals(js.getString("message"), "Not supported file type", "message testFileType");
        log.info("Response of testFileType is: " + response.asString());
    }
    
    // AA TC-05: Hitting the API then checking the status code and response validation

    @Test(priority = 3, dependsOnMethods = { "testCreateAttachmentId" }, groups= {"attachmentController", "api","regression"})
    public void testDeleteAttachment() {
        Response response = Payload_AttachmentController.deleteAttachmentResponse(id);
        response.then().assertThat().statusCode(200);
        JsonPath js = Payload_AttachmentController.getJsonPath(response);

        // Assertion for this Test
        assertEquals(js.getInt("code"), 20000);
        softAssert.assertTrue(js.getBoolean("data.attachmentDeleted"), "Check for Boolean field attachmentDeleted");
        log.info("Response of testDeleteAttachment is: " + response.asString());
    }
    
    // AA TC-06: Sending wrong Id as a parameter 
    
    @Test(priority = 3, groups= {"attachmentController", "api","regression"})
    public void testDeleteAttachmentWrongId() throws IOException {
        al = excelData.getData("WrongId", "AttachmentController_API", "Tcid");
        Response response = Payload_AttachmentController.deleteAttachmentResponse(al.get(2));
        response.then().assertThat().statusCode(404);
        JsonPath js = Payload_AttachmentController.getJsonPath(response);

        // Assertion for this Test
        assertEquals(js.getInt("code"), 40003);
        softAssert.assertEquals(js.getString("message"), "resource not found, unable to delete", "message testDeleteAttachmentWrongId");
        log.info("Response of testDeleteAttachmentWrongId is: " + response.asString());
    }
    
    // AA TC-07: Sending large Id as a parameter
    
    @Test(priority = 3, groups= {"attachmentController", "api","regression"})
    public void testDeleteAttachmentLargeId() throws IOException {
        al = excelData.getData("LargeId", "AttachmentController_API", "Tcid");
        Response response = Payload_AttachmentController.deleteAttachmentResponse(al.get(2));
        response.then().assertThat().statusCode(404);
        JsonPath js = Payload_AttachmentController.getJsonPath(response);

        // Assertion for this Test
        assertEquals(js.getInt("code"), 40003);
        softAssert.assertEquals(js.getString("message"), "resource not found, unable to delete", "message testDeleteAttachmentLargeId");
        log.info("Response of testDeleteAttachmentLargeId is: " + response.asString());
    }
    
    // Defect Id: https://byjustech.atlassian.net/browse/WFM-396

    @Test(priority = 3, dependsOnMethods = { "testCreateAttachmentId" }, groups= {"attachmentController", "api","regression"})
    public void testDeleteAttachmentAgain() {
        Response response = Payload_AttachmentController.deleteAttachmentResponse(id);
        response.then().assertThat().statusCode(404);
        JsonPath js = Payload_AttachmentController.getJsonPath(response);

        // Assertion for this Test
        assertEquals(js.getInt("code"), 40003);
        softAssert.assertEquals(js.getString("message"), "resource not found, unable to delete", "message testDeleteAttachmentLargeId");
        log.info("Response of testDeleteAttachmentLargeId is: " + response.asString());
    }
    
    @AfterClass(alwaysRun = true)
    public void checkAssertions() {
        softAssert.assertAll();
    }
}
