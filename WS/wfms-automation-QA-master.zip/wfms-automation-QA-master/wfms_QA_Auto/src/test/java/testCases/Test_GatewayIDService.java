package testCases;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import payLoad.Payload_GatewayIDService;

public class Test_GatewayIDService {

    private SoftAssert softAssert = new SoftAssert();
    private Response response;
    private JsonPath js;
    private String sessionToken;

    @BeforeClass(alwaysRun = true)
    @Parameters({ "sessionToken", "role", "projectId" })
    public void setToken(String sessionToken, String role, String projectId) {
        this.sessionToken = sessionToken;
    }

    @Test(priority = 1, groups = { "gatewayIDService", "api","regression" })
    public void testValidSessionToken() {
        
        response = Payload_GatewayIDService.getAuthorizationDetails(this.sessionToken);
        js = response.jsonPath();

        softAssert.assertEquals(response.statusCode(), 200, "GISA_POST_01 - error in status code");

        softAssert.assertEquals(js.get("message"), "completed successfully");
    }

    @Test(priority = 2, groups = { "gatewayIDService", "api","regression" })
    public void testInvalidSessionToken() {

        response = Payload_GatewayIDService.getAuthorizationDetails("dskfjsd");

        softAssert.assertEquals(response.statusCode(), 200, "GISA_POST_02 - error in status code");
    }

    @AfterClass(alwaysRun = true)
    public void checkAssertions() {
        softAssert.assertAll();
    }
}
