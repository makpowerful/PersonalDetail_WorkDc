package testCases;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import payLoad.Payload_ChannelController;
import resources.ExcelData;
import resources.base;

public class Test_ChannelController extends base {
    private int id;
    private int wrongId=0;
    private static SoftAssert softAssert = new SoftAssert();
    public static Logger log = LogManager.getLogger(Test_ChannelController.class.getName());
    private static ExcelData excelData = new ExcelData();
    private static ArrayList<String> al = new ArrayList<String>();
    
    @BeforeClass(alwaysRun = true)
    @Parameters({"sessionToken", "role", "projectId"})
    public void setToken(String sessionToken,String role, String projectId) throws IOException {
        
//        Payload_ChannelController.setHeaderMap(projectId, sessionToken);
        
        al = excelData.getData(url, "GlobalProjectIds", "Tcid");
        Payload_ChannelController.setHeaderMap(Integer.toString(Integer.parseInt(al.get(1))), sessionToken);
        Payload_ChannelController.generateChannelName();
    }
    
    // CCA-POST01-01: Create a new channel by calling POST method of Channel
    // Controller API

    @Test(priority = 1, groups = { "channelController", "api","regression" })
    public void testCreateChannel() throws IOException {
        al = excelData.getData("POST", "ChannelController_API", "Tcid");
        Response response = Payload_ChannelController.postChannelController("POST");
        response.then().assertThat().statusCode(201);
        JsonPath js = Payload_ChannelController.getJsonPath(response);
        id = js.getInt("data.channel.id");
        // Assertion for this Test
        softAssert.assertEquals(js.getString("data.channel.name"), Payload_ChannelController.channelName, "name testCreateChannel");
        softAssert.assertEquals(js.getString("data.channel.description"), al.get(2), "description testCreateChannel");
        log.info("Response of testCreateChannel is: " + response.asString());
    }
    
    // CCA-POST01-02: Create a new channel having empty property values for
    // properties name, description and status by calling POST method of Channel
    // controller API

    @Test(priority = 1, groups = { "channelController", "api","regression" })
    public void testCreateChannelEmptyString() throws IOException {
        al = excelData.getData("POST_Empty_String", "ChannelController_API", "Tcid");
        Response response = Payload_ChannelController.postChannelController("POST_Empty_String");
        response.then().assertThat().statusCode(400);
        JsonPath js = Payload_ChannelController.getJsonPath(response);
        
        // Assertion for this Test
        softAssert.assertEquals(js.getString("message"), "[name cannot be empty]", "message testCreateChannelEmptyString");
        softAssert.assertEquals(js.getInt("code"), 40000, "code testCreateChannelEmptyString");
        log.info("Response of testCreateChannelEmptyString is: " + response.asString());
    }
    
    // CCA-PUT01-01: Update details of a channel ( name, description, status ) using
    // its id by calling PUT method of Channel Controller API

    @Test(priority = 2, groups = { "channelController", "api","regression" })
    public void testUpdateChannel() throws IOException {
        al = excelData.getData("PUT", "ChannelController_API", "Tcid");
        Response response = Payload_ChannelController.putChannelController("PUT", id);
        response.then().assertThat().statusCode(200);
        JsonPath js = Payload_ChannelController.getJsonPath(response);
        
        // Assertion for this Test
        softAssert.assertEquals(js.getInt("data.channel.id"), id, "id testUpdateChannel");
        softAssert.assertEquals(js.getString("data.channel.name"), Payload_ChannelController.channelName, "name testUpdateChannel");
        softAssert.assertEquals(js.getString("data.channel.description"), al.get(2), "description testUpdateChannel");
        log.info("Response of testUpdateChannel is: " + response.asString());
    }
    
    // CCA-PUT01-02: Update details of a non-existing channel using a random integer
    // id by calling PUT method of Channel Controller API
    // Defect Id: https://byjustech.atlassian.net/browse/WFM-167

    @Test(priority = 2, groups = { "channelController", "api","regression" })
    public void testUpdateChannelNonExisting() throws IOException {
        Response response = Payload_ChannelController.putChannelController("PUT", wrongId);
        response.then().assertThat().statusCode(404);
        JsonPath js = Payload_ChannelController.getJsonPath(response);
        
        // Assertion for this Test
        softAssert.assertEquals(js.getInt("code"), 40003, "code testUpdateChannelNonExisting");
        softAssert.assertEquals(js.getString("message"), "Channel with Given id not found", "message testUpdateChannelNonExisting");
        log.info("Response of testUpdateChannelNonExisting is: " + response.asString());
    }
    
    // CCA-PUT01-03: Update details of a channel using a random alphanumeric string
    // id ( made of numbers and alphabets ) by calling PUT method of Channel
    // Controller API

    @Test(priority = 2, groups = { "channelController", "api","regression" })
    public void testUpdateChannelAlphaNumericId() throws IOException {
        Response response = Payload_ChannelController.putChannelController("PUT", "abc123");
        response.then().assertThat().statusCode(400);
        JsonPath js = Payload_ChannelController.getJsonPath(response);
        
        // Assertion for this Test
        softAssert.assertEquals(js.getString("error"), "Bad Request", "error testUpdateChannelAlphaNumericId");
        log.info("Response of testUpdateChannelAlphaNumericId is: " + response.asString());
    }
    
    /*
     
    // CCA-PUT01-04: Update createdAt property of a channel by calling PUT method of
    // Channel Controller API

    @Test(priority = 2, groups = { "channelController", "api","regression" })
    public void testUpdateChannelCreatedAt() throws IOException {
        al = excelData.getData("PUT_CreatedAt", "ChannelController_API", "Tcid");
        Response response = Payload_ChannelController.putChannelControllerCreatedAt("PUT_CreatedAt", id);
        response.then().assertThat().statusCode(200);
        JsonPath js = Payload_ChannelController.getJsonPath(response);
        
        // Assertion for this Test
        softAssert.assertEquals(js.getInt("data.channel.id"), id, "id testUpdateChannelCreatedAt");
        softAssert.assertEquals(js.getString("data.channel.name"), al.get(1), "name testUpdateChannelCreatedAt");
        softAssert.assertEquals(js.getString("data.channel.description"), al.get(2), "description testUpdateChannelCreatedAt");
        log.info("Response of testUpdateChannelCreatedAt is: " + response.asString());
    }
    
    */
    
    // CCA-PUT01-05 Make all the field value empty of a user by calling post method of Channel Controller API.
    
    @Test(priority = 2, groups = { "channelController", "api","regression" })
    public void testUpdateChannelEmptyString() throws IOException {
        al = excelData.getData("POST_Empty_String", "ChannelController_API", "Tcid");
        Response response = Payload_ChannelController.putChannelController("POST_Empty_String", id);
        response.then().assertThat().statusCode(400);
        JsonPath js = Payload_ChannelController.getJsonPath(response);
        
        // Assertion for this Test
        softAssert.assertEquals(js.getString("message"), "Null Description in update channel request", "error testUpdateChannelEmptyString");
        log.info("Response of testUpdateChannelEmptyString is: " + response.asString());
    }
    
    // CCA-GET01-01: Get details of a channel using its id by calling GET method of
    // Channel Controller API

    @Test(priority = 3, groups = { "channelController", "api","regression" })
    public void testGetChannelById() throws IOException {
        al = excelData.getData("PUT", "ChannelController_API", "Tcid");
        Response response = Payload_ChannelController.getChannelController(id);
        response.then().assertThat().statusCode(200);
        JsonPath js = Payload_ChannelController.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("data.channel.id"), id, "id testGetChannelById");
        softAssert.assertEquals(js.getString("data.channel.name"), Payload_ChannelController.channelName, "name testGetChannelById");
        softAssert.assertEquals(js.getString("data.channel.description"), al.get(2), "description testGetChannelById");
        log.info("Response of testGetChannelById is: " + response.asString());
    }
    
    // CCA-GET01-02: Get details of a non-existing channel using a random integer id
    // by calling GET method of Channel Controller API

    @Test(priority = 3, groups = { "channelController", "api","regression" })
    public void testGetChannelByNonExistingId() throws IOException {
        Response response = Payload_ChannelController.getChannelController(wrongId);
        response.then().assertThat().statusCode(404);
        JsonPath js = Payload_ChannelController.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("code"), 40003, "code testGetChannelByNonExistingId");
        softAssert.assertEquals(js.getString("message"), "Channel with Given id not found", "message testGetChannelByNonExistingId");
        log.info("Response of testGetChannelByNonExistingId is: " + response.asString());
    }
    
    // CCA-GET01-03: Get details of a channel using a random alphanumeric id ( id
    // made of numbers and letters ) by calling GET method of Channel Controller API

    @Test(priority = 3, groups = { "channelController", "api","regression" })
    public void testGetChannelByAlphaNumericId() throws IOException {
        Response response = Payload_ChannelController.getChannelController("abc123");
        response.then().assertThat().statusCode(400);
        JsonPath js = Payload_ChannelController.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getString("error"), "Bad Request", "error testGetChannelByAlphaNumericId");
        softAssert.assertEquals(js.getInt("status"), 400, "description testGetChannelByAlphaNumericId");
        log.info("Response of testGetChannelByAlphaNumericId is: " + response.asString());
    }
    
    // CCA-GET02-01 Get details of list of all channels by calling GET method of Channel Controller API
    
    @Test(priority = 3, groups = { "channelController", "api","regression" })
    public void testGetAllChannels() {
        Response response = Payload_ChannelController.getAllChannelController();
        response.then().assertThat().statusCode(200);
        
        log.info("Response of testGetAllChannels is: " + response.asString());
    }
    
    /*
     * 
    // CCA-DELETE01-01: Delete a channel using its id by calling DELETE method of
    // Channel Controller API

    @Test(priority = 4, groups = { "channelController", "api","regression" })
    public void testDeleteChannelById() throws IOException {
        Response response = Payload_ChannelController.deleteChannelController(id);
        response.then().assertThat().statusCode(202);

        // Assertion for this Test
        softAssert.assertEquals(response.asString(), "Channel deleted successfully", "message testDeleteChannelById");
        log.info("Response of testDeleteChannelById is: " + response.asString());
    }
    
    // CCA-DELETE01-02: Delete a non-existing channel using a random integer id by
    // calling DELETE method of Channel Controller API

    @Test(priority = 4, groups = { "channelController", "api","regression" })
    public void testDeleteChannelByNonExistingId() throws IOException {
        Response response = Payload_ChannelController.deleteChannelController(wrongId);
        response.then().assertThat().statusCode(404);
        JsonPath js = Payload_ChannelController.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("code"), 40003, "code testDeleteChannelByNonExistingId");
        softAssert.assertEquals(js.getString("message"), "No channel found for channelId: " + Integer.toString(wrongId), "message testDeleteChannelByNonExistingId");
        log.info("Response of testDeleteChannelByNonExistingId is: " + response.asString());
    }
    
    // CCA-DELETE01-03: Delete a channel using a random alphanumeric id ( made of
    // numbers and alphabets ) by calling DELETE method of Channel controller API

    @Test(priority = 4, groups = { "channelController", "api","regression" })
    public void testDeleteChannelByAlphaNumericId() throws IOException {
        Response response = Payload_ChannelController.deleteChannelController("abc123");
        response.then().assertThat().statusCode(400);
        JsonPath js = Payload_ChannelController.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getString("error"), "Bad Request", "error testDeleteChannelByAlphaNumericId");
        softAssert.assertEquals(js.getInt("status"), 400, "description testDeleteChannelByAlphaNumericId");
        log.info("Response of testDeleteChannelByAlphaNumericId is: " + response.asString());
    }
    
    */

    @AfterClass(alwaysRun = true)
    public void checkAssertions() {
        softAssert.assertAll();
    }
}
