package testCases;

import java.io.IOException;
import java.util.ArrayList;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import payLoad.Payload_ConversationController;
import resources.ExcelData;
import resources.base;

public class Test_ConversationController extends base{
    private static SoftAssert softAssert = new SoftAssert();
    public String role;
    public ExcelData excelData = new ExcelData();
    public ArrayList<String> al = new ArrayList<String>();
    
    @Parameters({"sessionToken","role","projectId"})
    @BeforeClass(alwaysRun = true, groups = { "ConversationManagement", "api","regression" })
    public void initialize(String token,String role,int projectId) throws IOException, InterruptedException {
        this.role =role;
        Payload_ConversationController.role=role;

        al = excelData.getData(url, "GlobalProjectIds", "Tcid");
        Payload_ConversationController.projectId = Integer.parseInt(al.get(1));  
        
        Payload_ConversationController.sessionToken = token;
        Payload_ConversationController.setHeaderMap();
        
        Response res = Payload_ConversationController.getResPostTicket();
        
        //Asserts
        Assert.assertEquals(res.statusCode(), 201);
    }

    
    
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-413
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-221
    // CCA TC-01 : Hitting the API and creating a conversation by passing the ticketID param then checking the status code and response validation
    @Test(priority = 1, groups = { "ConversationManagement", "api","regression" })
    public void testPost_ConversationController() throws InterruptedException, IOException {
        Thread.sleep(2000);
        Response res = Payload_ConversationController.getResponsePost_ConversationController();
        JsonPath response = Payload_ConversationController.getJsonPath(res);

        // Asserts
        Assert.assertEquals(res.statusCode(), 201);
        softAssert.assertEquals(response.getInt("data.ticketId"), Payload_ConversationController.ticketId,"Post_ConversationController_ticketId_Assert_Failed");
        softAssert.assertEquals(response.getString("message"), "created successfully","Post_ConversationController_message_Assert_Failed");
    }

    
    // CCA TC-02 : Hitting the API and creating a conversation by passing an invalid ticketID param then checking the status code and response validation
    @Test(priority = 2, groups = { "ConversationManagement", "api","regression" })
    public void testPostNegative_ConversationController() throws IOException {
        // first delete the existing ticketId
        Payload_ConversationController.deleteTicketControllerResponse();

        // Now that the ticketId doesnot exist anymore, we proceed to actual test.
        Response res = Payload_ConversationController.getResponsePostNegative_ConversationController();

        // Asserts
        Assert.assertEquals(res.statusCode(), 404);
    }

    
    
    @AfterClass(alwaysRun = true, groups = { "ConversationManagement", "api","regression" })
    public void checkAssertions() {
        softAssert.assertAll();
    }

}
