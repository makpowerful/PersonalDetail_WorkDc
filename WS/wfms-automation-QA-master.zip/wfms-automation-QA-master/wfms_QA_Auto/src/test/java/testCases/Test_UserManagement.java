package testCases;

import java.util.ArrayList;
import java.util.Random;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.github.javafaker.Faker;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import payLoad.Payload_UserManagement;
import resources.ExcelData;
import resources.base;

public class Test_UserManagement extends base{
    private String payload;
    private Response response;
    JsonPath js;
    private SoftAssert softAssert = new SoftAssert();
    private String firstName, lastName, emailId, phoneNumber, invalidEmailId, newPhoneNumber;
    private int id;
    private Faker faker = new Faker();
    
    // ------------------------------------------------------------------------------------------------
    // UMA_POST01_01 : Create a new user
    // ------------------------------------------------------------------------------------------------
    
    @Test(priority = 1, groups= {"userManagement", "api","regression"})
    public void testCreateUser() {
        
        firstName = faker.name().firstName().replaceAll("'","");
        lastName = faker.name().lastName().replaceAll("'","");
        emailId = firstName.toLowerCase() + "." + lastName.toLowerCase() + new Random().nextInt(1000000000) + "@byjus.com";
        phoneNumber = "9" + Integer.toString(100000000 + new Random().nextInt(100000000));
        
        payload = Payload_UserManagement.getCreateUserPayload(firstName, lastName, emailId, phoneNumber);
        response = Payload_UserManagement.createUser(payload);
        js = response.jsonPath();
        
        softAssert.assertEquals(response.statusCode(), 201, "UMA POST 01 01 - error in status code");
        softAssert.assertEquals(js.get("data.firstName"), firstName, "UMA POST 01 01 - error in first name");
        softAssert.assertEquals(js.get("data.lastName"), lastName, "UMA POST 01 01 - error in last name");
        softAssert.assertEquals(js.get("data.emailId"), emailId, "UMA POST 01 01 - error in email id");
        softAssert.assertEquals(js.get("data.phoneNumber"), phoneNumber, "UMA POST 01 01 - error in phone number");
        softAssert.assertEquals(js.get("message"), "user created successfully", "UMA POST 01 01 - error in message");
    }
    
    // ------------------------------------------------------------------------------------------------ 
    // UMA_POST01_02 : Create existing user
    // ------------------------------------------------------------------------------------------------
    
    @Test(priority = 2, groups= {"userManagement", "api","regression"})
    public void testCreateExistingUser() {
        
        payload = Payload_UserManagement.getCreateUserPayload(firstName, lastName, emailId, phoneNumber);
        response = Payload_UserManagement.createUser(payload);
        js = response.jsonPath();
        
        softAssert.assertEquals(response.statusCode(), 400, "UMA POST 01 02 - error in status code");
        softAssert.assertEquals(js.get("message"), "user already exist", "UMA POST 01 02 - error in message");
    }
    
    // ------------------------------------------------------------------------------------------------- 
    // UMA_POST01_03 : Create new user with empty field values (firstName, lastname, phoneNumber)
    // -------------------------------------------------------------------------------------------------
    
    @Test(priority = 3, groups= {"userManagement", "api","regression"})
    public void testCreateUserWithEmptyFieldValues() {
        
        payload = Payload_UserManagement.getCreateUserPayload("", "", emailId, "");
        response = Payload_UserManagement.createUser(payload);
        
        softAssert.assertEquals(response.statusCode(), 400, "UMA POST 01 03 - error in status code");
        softAssert.assertEquals(js.get("message"), "user already exist", "UMA POST 01 03 - error in message");
    }
    
    // ------------------------------------------------------------------------------------------------- 
    // UMA_POST01_04 : Create a new user with invalid email Id
    // -------------------------------------------------------------------------------------------------
    
    @Test(priority = 4, groups= {"userManagement", "api","regression"})
    public void testCreateUserInvalidEmailId() {
        
        invalidEmailId = firstName.toLowerCase() + "." + lastName.toLowerCase();
        
        // defect - https://byjustech.atlassian.net/browse/WFM-400
        payload = Payload_UserManagement.getCreateUserPayload("", lastName, invalidEmailId, phoneNumber);
        response = Payload_UserManagement.createUser(payload);
        
        // Defect - https://byjustech.atlassian.net/browse/WFM-381
        // Defect - https://byjustech.atlassian.net/browse/WFM-401
        Assert.assertEquals(response.statusCode(), 400, "UMA POST 01 04 - error in status code");
    }
    
    // -------------------------------------------------------------------------------------------------
    // UMA_GET01_01 : Get detail of single user
    // -------------------------------------------------------------------------------------------------
    
    @Test(priority = 5, groups= {"userManagement", "api","regression"})
    public void testDetailOfSingleUser() {
        
        response = Payload_UserManagement.getUserList(emailId);
        js = response.jsonPath();
        
        softAssert.assertEquals(response.statusCode(), 200, "UMA GET 01 01 - error in status code");
        softAssert.assertEquals(js.get("data.users[0].emailId"), emailId, "UMA GEt 01 01 - error in email id");
        
        id = js.getInt("data.users[0].id");
    }
    
    // --------------------------------------------------------------------------------------------------- 
    // UMA_GET01_02 : Get details of multiple users
    // ---------------------------------------------------------------------------------------------------
    
    @ Test(priority = 6, groups= {"userManagement", "api","regression"})
    public void testGetDetailsOfMultipleUsers() {
        
        String emailId1 = "ankur.singh14@byjus.com";
        String emailId2 = "gaurang.agarwal1@byjus.com";
        
        response = Payload_UserManagement.getUserList(emailId1 + "," + emailId2);
        js = response.jsonPath();
        
        softAssert.assertEquals(response.statusCode(), 200, "UMA GET 01 02 - error in status code");    
        softAssert.assertEquals(js.get("data.users[0].emailId"), emailId1, "UMA GET 01 02 - error in email id 1");
        softAssert.assertEquals(js.get("data.users[1].emailId"), emailId2, "UMA GET 01 02 - error in email id 2");
    }
    
    // --------------------------------------------------------------------------------------------------- 
    // UMA_PUT01_01 : Update details of existing user
    // ---------------------------------------------------------------------------------------------------
    
    @Test(priority = 7, groups= {"userManagement", "api","regression"})
    public void testUpdateDetailsOfExistingUser() {
        
        newPhoneNumber = "9" + Integer.toString(100000000 + new Random().nextInt(100000000));
        
        payload = Payload_UserManagement.getCreateUserPayload(firstName, lastName, emailId, newPhoneNumber);
        response = Payload_UserManagement.updateUserDetails(id, payload);
        js = response.jsonPath();
        
        softAssert.assertEquals(response.statusCode(), 200, "UMA PUT 01 01 - error in status code");
        softAssert.assertEquals(js.get("data.firstName"), firstName, "UMA PUT 01 01 - error in first name");
        softAssert.assertEquals(js.get("data.lastName"), lastName, "UMA PUT 01 01 - error in last name");
        softAssert.assertEquals(js.get("data.emailId"), emailId, "UMA PUT 01 01 - error in email id");
        softAssert.assertEquals(js.get("data.phoneNumber"), newPhoneNumber, "UMA PUT 01 01 - error in phone number");
    }
    
    // --------------------------------------------------------------------------------------------------- 
    // UMA_DELETE01_01 : Delete a user
    // ---------------------------------------------------------------------------------------------------
    
    @Test(priority = 8, groups= {"userManagement", "api","regression"})
    public void testDeleteUser() {
        
        response = Payload_UserManagement.deleteUser(id);
        js = response.jsonPath();
        
        softAssert.assertEquals(response.statusCode(), 200, "UMA DELETE 01 01 - error in status code");
        softAssert.assertEquals(js.get("message"), "user deleted successfully", "UMA DELETE 01 01 - error in message");
    }
    
    // ---------------------------------------------------------------------------------------------------
    // UMA_GET01_03 : Get details of non existing user
    // ---------------------------------------------------------------------------------------------------
    
    @Test(priority = 9, groups= {"userManagement", "api","regression"})
    public void testGetDetailOfNonExistingUser() {
        
        response = Payload_UserManagement.getUserList(emailId);
        
        softAssert.assertEquals(response.statusCode(), 200, "UMA GET 01 03 - error in status code");
    }
    
    // --------------------------------------------------------------------------------------------------- 
    // UMA_PUT01_02 : Update details of non existing user
    // ---------------------------------------------------------------------------------------------------
    
    @Test(priority = 10, groups= {"userManagement", "api","regression"})
    public void testUpdateDetailsOfNonExistingUser() {
        
        payload = Payload_UserManagement.getCreateUserPayload(firstName, lastName, emailId, phoneNumber);
        response = Payload_UserManagement.updateUserDetails(id, payload);
        
        softAssert.assertEquals(response.statusCode(), 404, "UMA PUT 01 02 - error in status code");
    }
    
    // ----------------------------------------------------------------------------------------------------- 
    // UMA_DELETE01_02 : Delete non existing user
    // -----------------------------------------------------------------------------------------------------
    
    @Test(priority = 11, groups= {"userManagement", "api","regression"})
    public void testDeleteNonExistingUser() {
        
        response = Payload_UserManagement.deleteUser(id);
        
        softAssert.assertEquals(response.statusCode(), 400, "UMA DELETE 01 02 - error in status code");
    }
    
    @AfterClass(alwaysRun = true)
    public void softAssertAll() {
        softAssert.assertAll();
    }
}
