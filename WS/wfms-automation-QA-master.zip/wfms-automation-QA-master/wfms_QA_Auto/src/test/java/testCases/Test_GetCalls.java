package testCases;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import payLoad.PayLoad_GetCalls_PRD;
import payLoad.Payload_BulkViewOfTickets;
import payLoad.Payload_ChannelController;
import payLoad.Payload_GatewayIDService;
import payLoad.Payload_ProjectRoleController;
import payLoad.Payload_SearchService;
import payLoad.Payload_TicketController;
import resources.ExcelData;
import resources.base;

public class Test_GetCalls extends base{
    private int id = 5;
    private int wrongId = -145;
    private int projectId_G;
    private String projectId;
    private String sessionToken;
    private int limit = 1, offset = 1, negativeNum = -1;
    private static SoftAssert softAssert = new SoftAssert();
    public static Logger log = LogManager.getLogger(Test_TicketController.class.getName());
    private static ExcelData excelData = new ExcelData();
    private static ArrayList<String> al = new ArrayList<String>();
    private Response response;
    private String sheetName = "SearchService_API";
    
    
    @BeforeClass(alwaysRun = false)
    @Parameters({"sessionToken", "projectId"})
    public void setToken(String sessionToken, String projectId) {
        
        Payload_TicketController.setHeaderMap(projectId, sessionToken);
        Payload_SearchService.setHeaderMap(projectId, sessionToken);
        Payload_ChannelController.setHeaderMap(projectId, sessionToken);
        Payload_ProjectRoleController.setHeaderMap(projectId, sessionToken);
        PayLoad_GetCalls_PRD.setHeaderMap(projectId, sessionToken);
        this.projectId = projectId;
        this.projectId_G = Integer.parseInt(projectId);
        this.sessionToken = sessionToken;
    }
    
 // CTA TC-03: Hitting the API and checking the status code + response validation

    @Test(priority = 3, groups = { "ticketController", "api","regression" }, enabled=false)
    public void getTicketId() {
        Response response = Payload_TicketController.getTicketControllerResponse(id);
        response.then().assertThat().statusCode(200);
        JsonPath js = Payload_TicketController.getJsonPath(response);

        // Assertion for this Test
        assertEquals(js.getInt("code"), 20105);
        softAssert.assertEquals(js.getString("message"), "get tickets successful", "message getTicketId");
        softAssert.assertEquals(js.getInt("data.tickets[0].id"), id);
        log.info("Response of getTicketId is: " + response.asString());

    }
    
    // CTA TC-07: Fetching a ticket with wrong id as path parameter

    @Test(priority = 3, groups = { "ticketController", "api","regression" }, enabled=false)
    public void getTicketWrongId() {
        Response response = Payload_TicketController.getTicketControllerResponse(wrongId);
        response.then().assertThat().statusCode(404);
        JsonPath js = Payload_TicketController.getJsonPath(response);

        // Assertion for this Test
        assertEquals(js.getInt("code"), 40003);
        softAssert.assertEquals(js.getString("message"),
                "invalid ticket id: " + Integer.toString(wrongId),
                "message getTicketWrongId");
        log.info("Response of getTicketWrongId is: " + response.asString());

    }
    
    // CTA TC-10: Hitting the API then checking the status code and response validation
    
    @Test(priority = 3, groups = { "ticketController", "api","regression" }, enabled=true)
    public void getTicketsLimitOffset() {
        Response response = Payload_TicketController.getLimitOffsetTicketControllerResponse(limit, offset);
        response.then().assertThat().statusCode(200);
        JsonPath js = Payload_TicketController.getJsonPath(response);

        // Assertion for this Test
        assertEquals(js.getInt("code"), 20105);
        softAssert.assertEquals(js.getString("message"), "get tickets successful", "message getTicketsLimitOffset");
        softAssert.assertEquals(js.getInt("data.tickets.size()"), limit, "check number of tickets returned");
        log.info("Response of getTicketsLimitOffset is: " + response.asString());

    }
    
    // CTA TC-11: Checking the number of tickets returned and the number of pages
    
    @Test(priority = 3, groups = { "ticketController", "api","regression" }, enabled=false)
    public void getTicketsNumTickets() {
        Response response = Payload_TicketController.getLimitOffsetTicketControllerResponse(limit, offset);
        response.then().assertThat().statusCode(200);
        JsonPath js = Payload_TicketController.getJsonPath(response);

        // Assertion for this Test
        assertEquals(js.getInt("code"), 20105);
        softAssert.assertEquals(js.getString("message"), "get tickets successful", "message getTicketsNumTickets");
        softAssert.assertEquals(js.getInt("data.pageSize"), limit, "check for page size");
        log.info("Response of getTicketsNumTickets is: " + response.asString());

    }
    
    // CTA TC-12: Sending negative number in the limit and offset parameter
    
    @Test(priority = 3, groups = { "ticketController", "api","regression" }, enabled=false)
    public void getTicketsLimitOffsetNegativeNum() {
        Response response = Payload_TicketController.getLimitOffsetTicketControllerResponse(negativeNum, negativeNum);
        response.then().assertThat().statusCode(404);
        JsonPath js = Payload_TicketController.getJsonPath(response);

        // Assertion for this Test
        assertEquals(js.getInt("code"), 40003);
        softAssert.assertEquals(js.getString("message"), "exception in getTickets while fetching paginated tickets", "message getTicketsLimitOffsetNegativeNum");
        log.info("Response of getTicketsLimitOffsetNegativeNum is: " + response.asString());

    }
    
 // SSA TC-01: Hitting the API then checking the status code and response
    // validation

    @Test(priority=1, groups = { "searchService", "api","regression" }, enabled=false)
    public void testSearchProjectId() throws IOException {
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("projectId", Integer.toString(projectId_G));
        Response response = Payload_SearchService.getSearchAndFilterQuery(params);
        response.then().assertThat().statusCode(200);
        
    }
    
    // SSA TC-02: Hitting the API then sorting the search with the sortByField and
    // response validation

    @Test(priority=1, groups = { "searchService", "api","regression" }, enabled=false)
    public void testSearchSortByField() throws IOException {
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("projectId", Integer.toString(projectId_G));
        params.put("sortByField", "createdAt");
        Response response = Payload_SearchService.getSearchAndFilterQuery(params);
        response.then().assertThat().statusCode(200);
        
    }

    // SSA TC-03: Hitting the API then sorting the search with the sortByOrder and
    // response validation
    
    @Test(priority=1, groups = { "searchService", "api","regression" }, enabled=false)
    public void testSearchSortByOrder() throws IOException {
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("projectId", Integer.toString(projectId_G));
        params.put("sortByOrder", "ASC");
        Response response = Payload_SearchService.getSearchAndFilterQuery(params);
        response.then().assertThat().statusCode(200);
        
    }
    
    // SSA TC-05: Hitting the API then filtering the search with the requesterEmail
    // and response validation

    @Test(priority=1, groups = { "searchService", "api","regression" }, enabled=false)
    public void testSearchRequesterEmail() throws IOException {
        al = excelData.getData("GetCalls", sheetName, "Tcid");
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("projectId", Integer.toString(projectId_G));
        params.put("requesterEmail", al.get(5));
        Response response = Payload_SearchService.getSearchAndFilterQuery(params);
        response.then().assertThat().statusCode(200);
        
    }
    
    // SSA TC-06: Hitting the API then filtering the search with the customerEmail
    // and response validation

    @Test(priority=1, groups = { "searchService", "api","regression" }, enabled=false)
    public void testSearchCustomerEmail() throws IOException {
        al = excelData.getData("GetCalls", sheetName, "Tcid");
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("projectId", Integer.toString(projectId_G));
        params.put("customerEmail", al.get(13));
        Response response = Payload_SearchService.getSearchAndFilterQuery(params);
        response.then().assertThat().statusCode(200);
        
    }
    
    // SSA TC-07: Hitting the API then filtering the search with the customerName
    // and response validation

    @Test(priority=1, groups = { "searchService", "api","regression" }, enabled=false)
    public void testSearchCustomerName() throws IOException {
        al = excelData.getData("GetCalls", sheetName, "Tcid");
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("projectId", Integer.toString(projectId_G));
        params.put("customerName", al.get(12));
        Response response = Payload_SearchService.getSearchAndFilterQuery(params);
        response.then().assertThat().statusCode(200);
        
    }
    
    // SSA TC-08: Hitting the API then filtering the search with the createdAt and
    // response validation

//    @Test(priority=2, groups = { "searchService", "api","regression" }, enabled=false)
//    public void testSearchCreatedAt() throws IOException {
//        HashMap<String, String> params = new HashMap<String, String>();
//        params.put("projectId", Integer.toString(projectId_G));
//        params.put("createdAt", createdAt);
//        Response response = Payload_SearchService.getSearchAndFilterQuery(params);
//        response.then().assertThat().statusCode(200).log().all();
//        JsonPath js = Payload_SearchService.getJsonPath(response);
//
//        // Assertion for this Test
//        softAssert.assertEquals(js.getInt("code"), 20000, "code testSearchCreatedAt");
//        softAssert.assertEquals(js.getString("message"), "completed successfully", "message testSearchCreatedAt");
//        softAssert.assertEquals(js.getString("data.tickets[0].ticketId"), Integer.toString(id),
//                "ticketId testSearchCreatedAt");
//        softAssert.assertEquals(js.getString("data.tickets[0].createdAt"), createdAt, "createdAt testSearchCreatedAt");
//        log.info("Response of testSearchCreatedAt is: " + response.asString());
//    }
    
    // SSA TC-09: Hitting the API then filtering the search with the status and
    // response validation

    @Test(priority=1, groups = { "searchService", "api","regression" }, enabled=false)
    public void testSearchStatus() throws IOException {
        al = excelData.getData("GetCalls", sheetName, "Tcid");
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("projectId", Integer.toString(projectId_G));
        params.put("status", al.get(14));
        Response response = Payload_SearchService.getSearchAndFilterQuery(params);
        response.then().assertThat().statusCode(200);
        
    }
    
    // SSA TC-10: Hitting the API then filtering the search with the priority and
    // response validation

    @Test(priority=1, groups = { "searchService", "api","regression" }, enabled=false)
    public void testSearchPriority() throws IOException {
        al = excelData.getData("GetCalls", sheetName, "Tcid");
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("projectId", Integer.toString(projectId_G));
        params.put("priority", al.get(17));
        Response response = Payload_SearchService.getSearchAndFilterQuery(params);
        response.then().assertThat().statusCode(200);
        
    }
    
    // SSA TC-11: Hitting the API then filtering the search with the groupId and
    // response validation

    @Test(priority=1, groups = { "searchService", "api","regression" }, enabled=false)
    public void testSearchGroupId() throws IOException {
        al = excelData.getData("GetCalls", sheetName, "Tcid");
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("projectId", Integer.toString(projectId_G));
        params.put("groupId", al.get(21));
        Response response = Payload_SearchService.getSearchAndFilterQuery(params);
        response.then().assertThat().statusCode(200);
        
    }
    
    // SSA TC-15: Hitting the API then searching all the records in the database
    // with the searchQuery and response validation

    @Test(priority=1, groups = { "searchService", "api","regression" }, enabled=false)
    public void testSearchQuery() throws IOException {
        al = excelData.getData("GetCalls", sheetName, "Tcid");
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("projectId", Integer.toString(projectId_G));
        params.put("searchQuery", al.get(9));
        params.put("sortByField", "createdAt");
        Response response = Payload_SearchService.getSearchAndFilterQuery(params);
        response.then().assertThat().statusCode(200);
        
    }
    
    // SSA TC-16: Hitting the API then searching with alphanumeric projectId_G

    @Test(priority=1, groups = { "searchService", "api","regression" }, enabled=false)
    public void testSearchWrongProjectId() throws IOException {
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("projectId", "random");
        Response response = Payload_SearchService.getSearchAndFilterQuery(params);
        response.then().assertThat().statusCode(403);
        JsonPath js = Payload_SearchService.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("code"), 40002, "code testSearchWrongProjectId");
        softAssert.assertEquals(js.getString("message"), "User does not have access for this project",
                "message testSearchWrongProjectId");
        log.info("Response of testSearchWrongProjectId is: " + response.asString());
    }
    
// PRCA TC-07: Fetch a role with the get API then validating the response code and response body
    
    @Test(priority=3, groups = { "ProjectRoleController", "api","regression" }, enabled=false)
    public void testGetProjectRole() throws IOException {
        al = excelData.getData("Get_Calls", "ProjectRoleController_API", "Tcid");
        Response response = Payload_ProjectRoleController.getProjectRoleController(Integer.parseInt(al.get(1)), al.get(2));
        response.then().assertThat().statusCode(200);
        JsonPath js = Payload_ProjectRoleController.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("code"), 2000, "code testGetProjectRole");
        softAssert.assertEquals(js.getInt("data.projectRoles[0].projectId"), Integer.parseInt(al.get(1)), "projectId testGetProjectRole");
        softAssert.assertEquals(js.getString("data.projectRoles[0].genericName"), al.get(2),
                "genericName testGetProjectRole");
        softAssert.assertEquals(js.getString("data.projectRoles[0].specificName"), al.get(3),
                "specificName testGetProjectRole");
        softAssert.assertEquals(js.getString("message"), "Project Role ",
                "message testGetProjectRole");
        log.info("Response of testGetProjectRole is: " + response.asString());
    }
    
    // PRCA TC-08: Fetch a role with projectId_G that doesn't exist with the get API then validating the response code and response body
    
    @Test(priority=3, groups = { "ProjectRoleController", "api","regression" }, enabled=false)
    public void testGetProjectRoleInvalidProjectId() throws IOException {
        al = excelData.getData("PUT_Invalid_ProjectId", "ProjectRoleController_API", "Tcid");
        Response response = Payload_ProjectRoleController.getProjectRoleController(Integer.parseInt(al.get(1)), al.get(2));
        response.then().assertThat().statusCode(400);
        JsonPath js = Payload_ProjectRoleController.getJsonPath(response);

        // Assertion for this Test
      softAssert.assertEquals(js.getInt("code"), 400, "code testUpdateProjectEmpty");
        log.info("Response of testGetProjectRoleInvalidProjectId is: " + response.asString());
    }
    
 // CCA-GET01-01: Get details of a channel using its id by calling GET method of
    // Channel Controller API

    @Test(priority = 3, groups = { "channelController", "api","regression" }, enabled=false)
    public void testGetChannelById() throws IOException {
        Response response = Payload_ChannelController.getChannelController(1);
        response.then().assertThat().statusCode(200);
    }
    
    // CCA-GET01-02: Get details of a non-existing channel using a random integer id
    // by calling GET method of Channel Controller API

    @Test(priority = 3, groups = { "channelController", "api","regression" }, enabled=false)
    public void testGetChannelByNonExistingId() throws IOException {
        Response response = Payload_ChannelController.getChannelController(wrongId);
        response.then().assertThat().statusCode(404);
        JsonPath js = Payload_ChannelController.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("code"), 40003, "code testGetChannelByNonExistingId");
        softAssert.assertEquals(js.getString("message"), "No channel found for channelId: " + Integer.toString(wrongId), "message testGetChannelByNonExistingId");
        log.info("Response of testGetChannelByNonExistingId is: " + response.asString());
    }
    
    // CCA-GET01-03: Get details of a channel using a random alphanumeric id ( id
    // made of numbers and letters ) by calling GET method of Channel Controller API

    @Test(priority = 3, groups = { "channelController", "api","regression" }, enabled=false)
    public void testGetChannelByAlphaNumericId() throws IOException {
        Response response = Payload_ChannelController.getChannelController("abc123");
        response.then().assertThat().statusCode(400);
        JsonPath js = Payload_ChannelController.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getString("error"), "Bad Request", "error testGetChannelByAlphaNumericId");
        softAssert.assertEquals(js.getInt("status"), 400, "description testGetChannelByAlphaNumericId");
        log.info("Response of testGetChannelByAlphaNumericId is: " + response.asString());
    }
    
    // CCA-GET02-01 Get details of list of all channels by calling GET method of Channel Controller API
    
    @Test(priority = 3, groups = { "channelController", "api","regression" }, enabled=false)
    public void testGetAllChannels() {
        Response response = Payload_ChannelController.getAllChannelController();
        response.then().assertThat().statusCode(200);
        
        log.info("Response of testGetAllChannels is: " + response.asString());
    }
    
//---------------------------------GROUP MANAGEMENT---------------------------------------------
    
    
    
    @Test(enabled=false)
    public void testGetWithProjectId_GroupManagement() {
        Response res = PayLoad_GetCalls_PRD.getResponseGetWithProjectId(projectId_G);
        JsonPath response = PayLoad_GetCalls_PRD.getJsonPath(res);
        
        //Asserts
            Assert.assertEquals(res.statusCode(), 200);
        
    }
    
    
//    @Test()
//    public void testGet_ByProjectId_groupName_date_GroupManagement() {
//        Response res = GET_Pratik_PayLoad.getResponseGet_ByProjectId_groupName_date(groupName, projectId, date);
//        JsonPath response = GET_Pratik_PayLoad.getJsonPath(res);
//        
//        //Asserts
//        if(GET_Pratik_PayLoad.role.equals("requestor")) {
//            Assert.assertEquals(res.statusCode(), 403);
//            softAssert.assertEquals(response.getString("message"),"Not authorised to perform action on this resource","post_Unauthorized_message_Failed");
//        }else {
//            Assert.assertEquals(res.statusCode(), 200);
//            softAssert.assertEquals(GET_Pratik_PayLoad.groupId,response.getInt("data[0].group.groupId"),"Get_ByProjectId_groupName_date_GroupID_Assert_Failed");
//            softAssert.assertEquals(GET_Pratik_PayLoad.projectId,response.getInt("data[0].group.projectId"),"Get_ByProjectId_groupName_date_ProjectId_Assert_Failed");
//            softAssert.assertEquals(GET_Pratik_PayLoad.date,response.getString("data[0].group.createdAt").split("T")[0],"Get_ByProjectId_groupName_date_ProjectId_Assert_Failed");
//        }
//       
//    }
    
    
    
    @Test(enabled=false)
    public void testGet_ByProjectIDAndAgentName_GroupManagement() {
        Response res = PayLoad_GetCalls_PRD.getResponseGet_ByProjectIDAndAgentName(projectId_G, "Abul");
        JsonPath response = PayLoad_GetCalls_PRD.getJsonPath(res);
        
        //Asserts
            Assert.assertEquals(res.statusCode(), 200);
            //softAssert.assertEquals(GET_Pratik_PayLoad.al.get(1),response.getString("data[0].group.groupName"),"Get_ProjectI&GroupName_groupName_Assert_Failed");
            //softAssert.assertEquals(projectId_G,response.getInt("data[0].group.projectId"),"Get_ProjectId&groupName_ProjectId_Assert_Failed");
        
    }
    
    
    
    
    @Test(enabled=false)
    public void testGet_AgentList_GroupManagement() {
        Response res = PayLoad_GetCalls_PRD.getResponseGet_AgentList(projectId_G);
        JsonPath response = PayLoad_GetCalls_PRD.getJsonPath(res);
        
        //Asserts
        
            Assert.assertEquals(res.statusCode(), 200);
    }
    
    
    @Test(enabled=false)
    public void testGet_ByProjectID_pageNumber_pageSize_GroupManagement() throws IOException {
        Response res = PayLoad_GetCalls_PRD.getResponseGet_ByProjectID_pageNumber_pageSize(projectId_G, 1, 5);
        JsonPath response = PayLoad_GetCalls_PRD.getJsonPath(res);
        
        //Asserts
        
            Assert.assertEquals(res.statusCode(), 200);
        
    }
    
    
    
    //-------------------------------SLA-------------------------------------------------

    
    
    @Test(enabled=false)
    public void testGet_SLA() throws Exception {
        Response res = PayLoad_GetCalls_PRD.getResGet(projectId_G);
        JsonPath response = PayLoad_GetCalls_PRD.getJsonPath(res);
        
        //Asserts
        Assert.assertEquals(res.statusCode(), 200);
    }
    
    
    
    
    
    //---------------------------------------MAILBOX API--------------------------------------
    
 
    
    
    
    @Test(enabled=false)
    public void testGet_MailBoxId() throws IOException {
        HashMap<String,Object> hashMap = new HashMap<String,Object>();
        hashMap.put("id", 3);
        
        Response res = PayLoad_GetCalls_PRD.getRes_Get(hashMap);
        JsonPath response = PayLoad_GetCalls_PRD.getJsonPath(res);
        
        //Asserts
        Assert.assertEquals(res.statusCode(), 200);
    }
    
    
    
    
    @Test(enabled=false)
    public void testGet_EmailId_Mailbox() throws IOException {
        HashMap<String,Object> hashMap = new HashMap<String,Object>();
        hashMap.put("email", "sfbtctest@gmail.com");
        Response res = PayLoad_GetCalls_PRD.getRes_Get(hashMap);
        JsonPath response = PayLoad_GetCalls_PRD.getJsonPath(res);
        
        
        //Asserts
        Assert.assertEquals(res.statusCode(), 200);
    }
    
    
    
    @Test(enabled=false)
    public void testGet_offset_Limit_Mailbox() throws IOException {
        HashMap<String,Object> hashMap = new HashMap<String,Object>();
        hashMap.put("offset", 0);
        hashMap.put("limit", 1);
        Response res = PayLoad_GetCalls_PRD.getRes_Get(hashMap);
        JsonPath response = PayLoad_GetCalls_PRD.getJsonPath(res);
        
        
        //Asserts
        Assert.assertEquals(res.statusCode(), 200);
    }
    
    
    
    
    
    @Test(enabled=false)
    public void testGet_NoParam_Mailbox() throws IOException {
        HashMap<String,Object> hashMap = new HashMap<String,Object>();
        Response res = PayLoad_GetCalls_PRD.getRes_Get(hashMap);
        JsonPath response = PayLoad_GetCalls_PRD.getJsonPath(res);
        
        
        //Asserts
        Assert.assertEquals(res.statusCode(), 200);
    }
    
    
    
    
    
    @Test(enabled=false)
    public void testGet_projectId_Mailbox() throws IOException {
        HashMap<String,Object> hashMap = new HashMap<String,Object>();
        hashMap.put("projectId", projectId_G);
        Response res = PayLoad_GetCalls_PRD.getRes_Get(hashMap);
        JsonPath response = PayLoad_GetCalls_PRD.getJsonPath(res);
        
        
        //Asserts
        Assert.assertEquals(res.statusCode(), 200);
    }
    
    
    
    
    //-------------------------------CONFIGURATION MANAGEMENT-----------------------------------------

    
    
    @Test(enabled=false)
    public void testGetProjectConfigurationId() {
        Response res = PayLoad_GetCalls_PRD.getResponseGetProjectConfigurationID("project", projectId_G);
        JsonPath response = PayLoad_GetCalls_PRD.getJsonPath(res);
        
        //Assertions
        Assert.assertEquals(res.statusCode(), 200);
    }
    
    
    @Test(enabled=false)
    public void testGetProjectConfigurationVersionNumber() {
        Response res = PayLoad_GetCalls_PRD.getResponseGetProjectConfigurationVersionNumber("project",projectId_G,1);
        JsonPath response = PayLoad_GetCalls_PRD.getJsonPath(res);
        
        //Assertions
        Assert.assertEquals(res.statusCode(), 200);
    }
    
    
    // project management api
    
    @Test(priority = 2, groups= {"projectManagement", "api","regression"}, enabled=false)
    public void testGetProjectDetail() throws IOException {
        
        response = PayLoad_GetCalls_PRD.getProjectDetail(projectId);
        response.then().assertThat().statusCode(200);
    }
    
    @Test(priority = 4, groups= {"projectManagement", "api","regression"}, enabled=false)
    public void testGetProjectDetailsList() throws IOException {
        
        response = PayLoad_GetCalls_PRD.getProjectDetailsList();
        response.then().assertThat().statusCode(200);
    }
    
    @Test(priority = 7, groups= {"projectManagement", "api","regression"}, enabled=false)
    public void testGetProjectDetailNonExistingProject() {
        
        response = PayLoad_GetCalls_PRD.getProjectDetail(1234);
        response.then().assertThat().statusCode(404);
    }
    
    @Test(priority = 9, groups= {"projectManagement", "api","regression"}, enabled=false)
    public void testGetProjectDetailInvalidProjectId() {
        
        response = PayLoad_GetCalls_PRD.getProjectDetail("abc");
        response.then().assertThat().statusCode(400);
    }
    
    // user management api
    
    @Test(priority = 5, groups= {"userManagement", "api","regression"}, enabled=false)
    public void testDetailOfSingleUser() {
        
        String emailId1 = "abul.kalam@byjus.com";
        response = PayLoad_GetCalls_PRD.getUserList(emailId1);
        
        response.then().assertThat().statusCode(200);
        
//        softAssert.assertEquals(js.get("data.users[0].emailId"), emailId1, "UMA GEt 01 01 - error in email id");
    }
    
    @ Test(priority = 6, groups= {"userManagement", "api","regression"}, enabled=false)
    public void testGetDetailsOfMultipleUsers() {
        
        String emailId1 = "abul.kalam@byjus.com";
        String emailId2 = "maitrayee.vatsa@byjus.com";
        
        response = PayLoad_GetCalls_PRD.getUserList(emailId1 + "," + emailId2);
        
        response.then().assertThat().statusCode(200);
         
//        softAssert.assertEquals(js.get("data.users[0].emailId"), emailId1, "UMA GET 01 02 - error in email id 1");
//        softAssert.assertEquals(js.get("data.users[1].emailId"), emailId2, "UMA GET 01 02 - error in email id 2");
    }
    
    @Test(priority = 9, groups= {"userManagement", "api","regression"}, enabled=false)
    public void testGetDetailOfNonExistingUser() {
        
        response = PayLoad_GetCalls_PRD.getUserList("abc4545@gmail.com");
        response.then().assertThat().statusCode(200);
        
//        softAssert.assertEquals(response.statusCode(), 404, "UMA GET 01 03 - error in status code");
    }
    
    // bulk view of tickets api
    
    @Test(priority = 1, groups= {"bulkViewOfTickets", "api","regression"}, enabled=false)
    void testGetBulkView() throws IOException {
        al = excelData.getData(url, "GlobalProjectIds", "Tcid");
        response = Payload_BulkViewOfTickets.getBulkView("5", al.get(1));
        response.then().assertThat().statusCode(200);
    }
    
    @Test(priority = 2, groups= {"bulkViewOfTickets", "api","regression"}, enabled=false)
    void testGetBulkViewOfNonExistingTickets() throws IOException {
        al = excelData.getData(url, "GlobalProjectIds", "Tcid");
        response = Payload_BulkViewOfTickets.getBulkView("-1", al.get(1));
        response.then().assertThat().statusCode(404);
    }
    
    @Test(priority = 3, groups= {"bulkViewOfTickets", "api","regression"}, enabled=false)
    void testGetBulkViewNoTickets() throws IOException {
        al = excelData.getData(url, "GlobalProjectIds", "Tcid");
        response = Payload_BulkViewOfTickets.getBulkView("", al.get(1));
        response.then().assertThat().statusCode(400);
    }
    
    // Gateway
    
    @Test(priority = 1, groups = { "gatewayIDService", "api","regression" }, enabled=false)
    public void testValidSessionToken() {

        response = Payload_GatewayIDService.getAuthorizationDetails(sessionToken);

        softAssert.assertEquals(response.statusCode(), 200, "GISA_POST_01 - error in status code");

    }

    @Test(priority = 2, groups = { "gatewayIDService", "api","regression" }, enabled=false)
    public void testInvalidSessionToken() {

        response = Payload_GatewayIDService.getAuthorizationDetails("dskfjsd");

        softAssert.assertEquals(response.statusCode(), 400, "GISA_POST_01 - error in status code");
    }

    @AfterClass(alwaysRun = false)
    public void checkAssertions() {
        softAssert.assertAll();
    }
}
