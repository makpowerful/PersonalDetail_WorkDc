package testCases;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import payLoad.Payload_BulkViewOfTickets;
import payLoad.Payload_SearchService;
import payLoad.Payload_TicketController;
import resources.ExcelData;
import resources.base;

public class Test_BulkViewOfTickets extends base {
    private SoftAssert softAssert = new SoftAssert();
    private Response response;
    private JsonPath js;
    private String role;
    public ExcelData excelData = new ExcelData();
    public ArrayList<String> al = new ArrayList<String>();

    @BeforeClass(alwaysRun = true)
    @Parameters({ "sessionToken", "role", "projectId" })
    public void setToken(String sessionToken, String role, String projectId) throws IOException {
        this.role = role;
        
        al = excelData.getData(url, "GlobalProjectIds", "Tcid");
        Payload_SearchService.setHeaderMap(Integer.toString(Integer.parseInt(al.get(1))), sessionToken);
        Payload_TicketController.setHeaderMap(Integer.toString(Integer.parseInt(al.get(1))), sessionToken);
    }

    // ----------------------------------------------------------------------------------------------------
    // BVA TC-01 : Get Details of multiple tickets using their id
    // ----------------------------------------------------------------------------------------------------
    @Test(priority = 1, groups = { "bulkViewOfTickets", "api","regression" })
    void testGetBulkView() {
        String ticketIds = "";
        HashMap<String, String> params = new HashMap<>();
        params.put("limit", "5");
        params.put("offset", "1");
        params.put("projectId", al.get(1));
        Response response = Payload_SearchService.getSearchAndFilterQuery(params);
        if (response.statusCode() == 200) {

            js = response.jsonPath();

            int s = js.getInt("data.tickets.size()");
           

            for (int i = 0; i < s; i++) {

                ticketIds += js.getString("data.tickets[" + i + "].ticketId");

                if (i < s - 1)
                    ticketIds += ",";
            }
            System.out.println(ticketIds+"---------------------------------");
            response = Payload_BulkViewOfTickets.getBulkView(ticketIds, al.get(1));
            if (role.equals("supervisor") || role.equals("projectAdmin") || role.equals("superAdmin")
                    || role.equals("agent")) {
                assertEquals(response.statusCode(), 200);
            } 
            else if (role.equals("requester")){
                response.then().assertThat().statusCode(403);
                js = Payload_BulkViewOfTickets.getJsonPath(response);
                softAssert.assertEquals(js.getString("message"), "Not authorised to perform action on this resource",
                        "message 403 testUpdateTicket");
            }
        }

    }

    // ----------------------------------------------------------------------------------------------------
    // BVA TC-02 : Get details of tickets with non-existing id
    // ----------------------------------------------------------------------------------------------------
    // Defect Id: https://byjustech.atlassian.net/browse/WFM-468
    @Test(priority = 2, groups = { "bulkViewOfTickets", "api","regression" })
    void testGetBulkViewOfNonExistingTickets() {

        String invalidId = Integer.toString(0);

        response = Payload_BulkViewOfTickets.getBulkView(invalidId, al.get(1));

        if (role.equals("supervisor") || role.equals("projectAdmin") || role.equals("superAdmin")
                || role.equals("agent")) {
            assertEquals(response.statusCode(), 400);
        } else if (role.equals("requester")) {
            response.then().assertThat().statusCode(403);
            js = Payload_BulkViewOfTickets.getJsonPath(response);
            softAssert.assertEquals(js.getString("message"), "Not authorised to perform action on this resource",
                    "message 403 testUpdateTicket");
        }
    }

    // ----------------------------------------------------------------------------------------------------
    // BVA TC-03 : Get details of no tickets
    // ----------------------------------------------------------------------------------------------------
    @Test(priority = 3, groups = { "bulkViewOfTickets", "api","regression" })
    void testGetBulkViewNoTickets() {

        response = Payload_BulkViewOfTickets.getBulkView("", al.get(1));

        if (role.equals("supervisor") || role.equals("projectAdmin") || role.equals("superAdmin")
                || role.equals("agent")) {
            assertEquals(response.statusCode(), 400);
        } else if (role.equals("requester")) {
            response.then().assertThat().statusCode(403);
            js = Payload_BulkViewOfTickets.getJsonPath(response);
            softAssert.assertEquals(js.getString("message"), "Not authorised to perform action on this resource",
                    "message 403 testUpdateTicket");
        }
    }

    @AfterClass(alwaysRun = true)
    public void softAssertAll() {
        softAssert.assertAll();
    }
}
