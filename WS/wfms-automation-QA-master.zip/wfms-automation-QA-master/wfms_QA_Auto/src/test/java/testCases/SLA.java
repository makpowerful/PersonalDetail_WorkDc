package testCases;
import java.io.IOException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import resources.ExcelData;
import resources.base;

public class SLA extends base{

    ExcelData excelData = new ExcelData();
    static int i=0;
    
    @Test(dataProvider="testDatapro")
    public void testSLA(String Date,String Weekday) throws Exception {
        String holidays = "2023-04-18,2023-04-21,2023-04-22,2023-04-26,2023-04-24,2023-04-25,2023-04-27";
        Set<LocalDate> setOfHolidays = Arrays.stream(holidays.split(","))
                .map(LocalDate::parse)
                .collect(Collectors.toSet());
        //System.out.println(Date);
        String[] Date1 = Date.split("-");
        //System.out.println(Date1[0]+" "+Date1[1]);
        int Day= Integer.parseInt(Date1[0]);
        int Month= Integer.parseInt(Date1[1]);
        int slaInMinutes = 30;
        //System.out.println(calculateSLA(LocalDateTime.of(2023, 4,20 , 18, 30), setOfHolidays, slaInMinutes));
        String response = calculateSLA(LocalDateTime.of(2023, Month, Day, 18, 30), setOfHolidays, slaInMinutes).toString();
        setData("src\\main\\java\\testData\\Book1.xlsx", "SLATest", i + 1, 0, Date);
        setData("src\\main\\java\\testData\\Book1.xlsx", "SLATest", i + 1, 1, Weekday);
        setData("src\\main\\java\\testData\\Book1.xlsx", "SLATest", i + 1, 2, response);
        i++;

    }

	public static LocalDateTime calculateSLA(LocalDateTime reportDate, Set<LocalDate> setOfHolidays, int slaInMinute) {
		   LocalDateTime responseDate = reportDate;
		   LocalTime START_TIME = LocalTime.of(9, 0);
		   LocalTime END_TIME = LocalTime.of(17, 0);
		   int workdayMinutes = (int) ChronoUnit.MINUTES.between(START_TIME, END_TIME);
		   DayOfWeek MONDAY = DayOfWeek.MONDAY;

		   int workdays = slaInMinute / workdayMinutes;
		   responseDate = responseDate.plusDays(workdays);

		   int remainingMinutes = slaInMinute % workdayMinutes;
		   // if time is before 8:00 (working hours) skip to 8:00
		   if (responseDate.toLocalTime().isBefore(START_TIME)) {
		       responseDate = responseDate.with(START_TIME);
		   // if time is after 17:00 (working hours) skip to next day at 8:00
		   } else if (responseDate.toLocalTime().isAfter(END_TIME)) {
		       responseDate = responseDate.plusDays(1).with(START_TIME);
		   }
		   while (remainingMinutes > 0) {
		       responseDate = responseDate.plusMinutes(1);
		       // if time is before 8:00 (working hours) skip to 8:00
		       if (responseDate.toLocalTime().isBefore(START_TIME)) {
		           responseDate = responseDate.with(START_TIME);
		       // if time is after 17:00 (working hours) skip to next day at 8:00
		       } else if (responseDate.toLocalTime().isAfter(END_TIME)) {
		           responseDate = responseDate.plusDays(1).with(START_TIME);
		       }
		       // if at any time it is weekend skip to monday at 8:00
		       if (responseDate.getDayOfWeek() == DayOfWeek.SATURDAY || responseDate.getDayOfWeek() == DayOfWeek.SUNDAY) {
		           responseDate = responseDate.with(TemporalAdjusters.next(MONDAY)).with(START_TIME);
		       }
		       //  if the calculated Date is holiday then skip one day
		       if (setOfHolidays.contains(responseDate.toLocalDate())) {
		           responseDate = responseDate.plusDays(1).with(START_TIME);
		       }
		       remainingMinutes--;
		   }
		   return responseDate;
		}
    @DataProvider
    public Object[][] testDatapro() throws Exception {
        Object[][] data = readData(System.getProperty("user.dir") + "//src//main//java//testData//TestData.xlsx",
                   "SLATest");
        return data;
    }
}
