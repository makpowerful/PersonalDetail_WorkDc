package testCases;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import payLoad.Payload_ProjectRoleController;
import resources.ExcelData;
import resources.base;

public class Test_ProjectRoleController extends base{
    private String sheetName = "ProjectRoleController_API";
    private static SoftAssert softAssert = new SoftAssert();
    public static Logger log = LogManager.getLogger(Test_ChannelController.class.getName());
    private static ExcelData excelData = new ExcelData();
    private static ArrayList<String> al = new ArrayList<String>();
    
    @BeforeClass(alwaysRun = true)
    @Parameters({"sessionToken", "role", "projectId"})
    public void setToken(String sessionToken,String role, String projectId) throws IOException {
        
//        Payload_ProjectRoleController.setHeaderMap(projectId, sessionToken);
        
        al = excelData.getData(url, "GlobalProjectIds", "Tcid");
        Payload_ProjectRoleController.setHeaderMap(Integer.toString(Integer.parseInt(al.get(1))), sessionToken);
    }

    
    // PRCA TC-01: Creating a new role with the post API then validating the response code and response body
    // Defect Id: https://byjustech.atlassian.net/browse/WFM-124

    @Test(priority=1, groups = { "ProjectRoleController", "api","regression" })
    public void testCreateProjectRole() throws IOException {
        al = excelData.getData("POST", sheetName, "Tcid");
        Response response = Payload_ProjectRoleController.postProjectRoleController("POST", sheetName);
        response.then().assertThat().statusCode(201);
        JsonPath js = Payload_ProjectRoleController.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("code"), 201, "code testCreateProjectRole");
        softAssert.assertEquals(js.getInt("data.projectId"), Integer.parseInt(al.get(1)), "projectId testCreateProjectRole");
        softAssert.assertEquals(js.getString("data.genericName"), al.get(2),
                "genericName testCreateProjectRole");
        softAssert.assertEquals(js.getString("data.specificName"), al.get(3),
                "specificName testCreateProjectRole");
        softAssert.assertEquals(js.getString("message"), "Creating Role",
                "message testCreateProjectRole");
        
        log.info("Response of testCreateProjectRoleAlreadyPresent is: " + response.asString());
    }
    
    // PRCA TC-02: Creating a role that is already present with the post API then validating the response code and response body
    
    @Test(priority=2, groups = { "ProjectRoleController", "api","regression" })
    public void testCreateProjectRoleAlreadyPresent() throws IOException {
        al = excelData.getData("POST", sheetName, "Tcid");
        Response response = Payload_ProjectRoleController.postProjectRoleController("POST", sheetName);
        response.then().assertThat().statusCode(400);
        JsonPath js = Payload_ProjectRoleController.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("code"), 40000, "code testCreateProjectRoleAlreadyPresent");
        softAssert.assertEquals(js.getString("message"), "role already present",
                "message testCreateProjectRoleAlreadyPresent");
        log.info("Response of testCreateProjectRoleAlreadyPresent is: " + response.asString());
    }
    
    // PRCA TC-03: Creating a role that has empty genericName and empty specificNmae with the post API then validating the response code and response body
    
    @Test(priority=2, groups = { "ProjectRoleController", "api","regression" })
    public void testCreateProjectRoleEmpty() throws IOException {
        al = excelData.getData("POST", sheetName, "Tcid");
        Response response = Payload_ProjectRoleController.postProjectRoleController("POST_Empty", sheetName);
        response.then().assertThat().statusCode(400);
        JsonPath js = Payload_ProjectRoleController.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("code"), 40000, "code testCreateProjectRoleEmpty");
        softAssert.assertEquals(js.getString("message"), "exception in createProjectRole ",
                "message testCreateProjectRoleEmpty");
        log.info("Response of testCreateProjectRoleEmpty is: " + response.asString());
    }
    
    // PRCA TC-04: Updating a role with the put API then validating the response code and response body
    
    @Test(priority=2, groups = { "ProjectRoleController", "api","regression" })
    public void testUpdateProject() throws IOException {
        al = excelData.getData("PUT", sheetName, "Tcid");
        Response response = Payload_ProjectRoleController.putProjectRoleController("PUT", sheetName, Integer.parseInt(al.get(1)), al.get(2));
        response.then().assertThat().statusCode(200);
        JsonPath js = Payload_ProjectRoleController.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("code"), 2000, "code testUpdateProject");
        softAssert.assertEquals(js.getInt("data.projectId"), Integer.parseInt(al.get(1)), "projectId testUpdateProject");
        softAssert.assertEquals(js.getString("data.genericName"), al.get(2),
                "genericName testUpdateProject");
        softAssert.assertEquals(js.getString("data.specificName"), al.get(3),
                "specificName testUpdateProject");
        softAssert.assertEquals(js.getString("message"), "Project Role Updated",
                "message testUpdateProject");
        log.info("Response of testUpdateProject is: " + response.asString());
    }
    
    // PRCA TC-05: Updating a role that has empty specificName with the put API then validating the response code and response body
    
    @Test(priority=2, groups = { "ProjectRoleController", "api","regression" })
    public void testUpdateProjectEmpty() throws IOException {
        al = excelData.getData("PUT_Empty", sheetName, "Tcid");
        Response response = Payload_ProjectRoleController.putProjectRoleController("PUT_Empty", sheetName, Integer.parseInt(al.get(1)), al.get(2));
        response.then().assertThat().statusCode(400);
        JsonPath js = Payload_ProjectRoleController.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("code"), 40000, "code testUpdateProjectEmpty");
        softAssert.assertEquals(js.getString("message"), "exception in updateProjectRole",
                "message testUpdateProjectEmpty");
        log.info("Response of testUpdateProjectEmpty is: " + response.asString());
    }
    
    // PRCA TC-06: Updating a role with projectId that doesn't exist with the put API then validating the response code and response body
    // Defect Id: https://byjustech.atlassian.net/browse/WFM-130
    
    @Test(priority=2, groups = { "ProjectRoleController", "api","regression" })
    public void testUpdateProjectInvalidProjectId() throws IOException {
        al = excelData.getData("PUT_Invalid_ProjectId", sheetName, "Tcid");
        Response response = Payload_ProjectRoleController.putProjectRoleController("PUT_Invalid_ProjectId", sheetName, Integer.parseInt(al.get(1)), al.get(2));
        response.then().assertThat().statusCode(400);
        JsonPath js = Payload_ProjectRoleController.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("code"), 40000, "code testUpdateProjectEmpty");
        log.info("Response of testUpdateProjectInvalidProjectId is: " + response.asString());
    }
    
    // PRCA TC-07: Fetch a role with the get API then validating the response code and response body
    
    @Test(priority=3, groups = { "ProjectRoleController", "api","regression" })
    public void testGetProjectRole() throws IOException {
        al = excelData.getData("PUT", sheetName, "Tcid");
        Response response = Payload_ProjectRoleController.getProjectRoleController(Integer.parseInt(al.get(1)), al.get(2));
        response.then().assertThat().statusCode(200);
        JsonPath js = Payload_ProjectRoleController.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("code"), 2000, "code testGetProjectRole");
        softAssert.assertEquals(js.getInt("data.projectRoles[0].projectId"), Integer.parseInt(al.get(1)), "projectId testGetProjectRole");
        softAssert.assertEquals(js.getString("data.projectRoles[0].genericName"), al.get(2),
                "genericName testGetProjectRole");
        softAssert.assertEquals(js.getString("data.projectRoles[0].specificName"), al.get(3),
                "specificName testGetProjectRole");
        softAssert.assertEquals(js.getString("message"), "Project Role ",
                "message testGetProjectRole");
        log.info("Response of testGetProjectRole is: " + response.asString());
    }
    
    // PRCA TC-08: Fetch a role with projectId that doesn't exist with the get API then validating the response code and response body
    // Defect Id: https://byjustech.atlassian.net/browse/WFM-130
    
    @Test(priority=3, groups = { "ProjectRoleController", "api","regression" })
    public void testGetProjectRoleInvalidProjectId() throws IOException {
        al = excelData.getData("PUT_Invalid_ProjectId", sheetName, "Tcid");
        Response response = Payload_ProjectRoleController.getProjectRoleController(Integer.parseInt(al.get(1)), al.get(2));
        response.then().assertThat().statusCode(400);
        JsonPath js = Payload_ProjectRoleController.getJsonPath(response);

        // Assertion for this Test
      softAssert.assertEquals(js.getInt("code"), 40000, "code testUpdateProjectEmpty");
        log.info("Response of testGetProjectRoleInvalidProjectId is: " + response.asString());
    }
    
    // PRCA TC-09: Deleting a role with the delete API then validating the response code and response body
    
    @Test(priority=4, groups = { "ProjectRoleController", "api","regression" })
    public void testDeleteProjectRole() throws IOException {
        al = excelData.getData("PUT", sheetName, "Tcid");
        Response response = Payload_ProjectRoleController.deleteProjectRoleController(Integer.parseInt(al.get(1)), al.get(2));
        response.then().assertThat().statusCode(200);
        JsonPath js = Payload_ProjectRoleController.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("code"), 2000, "code testDeleteProjectRole");
        softAssert.assertEquals(js.getString("message"), "Project Role Deleted",
                "message testDeleteProjectRole");
        log.info("Response of testDeleteProjectRole is: " + response.asString());
    }
    
    // PRCA TC-10: Deleting a role that is already present with the delete API then validating the response code and response body
    
    @Test(priority=5, groups = { "ProjectRoleController", "api","regression" })
    public void testDeleteProjectRoleAgain() throws IOException {
        al = excelData.getData("PUT", sheetName, "Tcid");
        Response response = Payload_ProjectRoleController.deleteProjectRoleController(Integer.parseInt(al.get(1)), al.get(2));
        response.then().assertThat().statusCode(400);
        JsonPath js = Payload_ProjectRoleController.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("code"), 40000, "code testDeleteProjectRoleAgain");
        log.info("Response of testDeleteProjectRoleAgain is: " + response.asString());
    }
    
    // Defect Id: https://byjustech.atlassian.net/browse/WFM-130
    
    @Test(priority=4, groups = { "ProjectRoleController", "api","regression" })
    public void testDeleteProjectRoleInvalidId() throws IOException {
        al = excelData.getData("PUT_Invalid_ProjectId", sheetName, "Tcid");
        Response response = Payload_ProjectRoleController.deleteProjectRoleController(Integer.parseInt(al.get(1)), al.get(2));
        response.then().assertThat().statusCode(400);
        JsonPath js = Payload_ProjectRoleController.getJsonPath(response);

        // Assertion for this Test
        softAssert.assertEquals(js.getInt("code"), 40000, "code testDeleteProjectRoleAgain");
        log.info("Response of testDeleteProjectRoleAgain is: " + response.asString());
    }
    
    @AfterClass(alwaysRun = true)
    public void checkAssertions() {
        softAssert.assertAll();
    }
}
