package testCases;

import java.io.IOException;
import java.util.ArrayList;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import payLoad.PayLoad_TimeLine;
import payLoad.Payload_ConversationController;
import resources.ExcelData;
import resources.base;


public class Test_TimeLine extends base{
    private static SoftAssert softAssert = new SoftAssert();
    public String role;
    public ExcelData excelData = new ExcelData();
    public ArrayList<String> al = new ArrayList<String>();
    
    @Parameters({"sessionToken","role","projectId"})
    @BeforeClass(groups = {  "TimeLine", "api","regression" })
    public void preRequisites_TimeLine(String token,String role,int projectId) throws IOException, InterruptedException {
        this.role = role;
        
        al = excelData.getData(url, "GlobalProjectIds", "Tcid");
        PayLoad_TimeLine.projectId = Integer.parseInt(al.get(1));  
        
        PayLoad_TimeLine.sessionToken = token;
        PayLoad_TimeLine.setHeaderMap();
        Response res = PayLoad_TimeLine.getResPostTicket();
        JsonPath response = PayLoad_TimeLine.getJsonPath(res);
        
        //Assertions
        Assert.assertEquals(res.statusCode(), 201);
    }
    
    
    
    
    
    
    @Test(priority=1, groups = {  "TimeLine", "api","regression" })
    // TLA TC-05 : Hit the GET API to get all the timelines of a Non-Existent ticket then status and response validation.
    public void testTimeline_Negative() throws Exception {
        Response res = PayLoad_TimeLine.getResGetTimeline_Negative_Non_existentId();
        JsonPath response = PayLoad_TimeLine.getJsonPath(res);
        
        
        //Asserts
        Assert.assertEquals(res.statusCode(), 404);
        softAssert.assertEquals(response.getString("message"),"Ticket does not exists: "+Integer.toString(PayLoad_TimeLine.nonExistentTicketId),"testTimeline_Negative__message_failed");
    }
    
    
    
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-226
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-412
    @Test(priority=3, groups = {  "TimeLine", "api","regression" })
    // TLA TC-06 : Update the  "Case Status"of a ticket and Hit the GET API to check if timeline got created, then status and response validation.
    public void testTimeline_CaseStatus() throws Exception {
        if(role.equals("requester")) {
            return;
        }
        Response res = PayLoad_TimeLine.getResUpdate("caseStatus");
        JsonPath response = PayLoad_TimeLine.getJsonPath(res);
        
        //Asserts
        Assert.assertEquals(res.statusCode(), 200);
        
        Boolean check = false;
        int count =0;
        
        while(!check && count<=5) {
            Thread.sleep(3000);
            res = PayLoad_TimeLine.getResGetTimeline();
            response = PayLoad_TimeLine.getJsonPath(res);
            
            
            //Asserts
            Assert.assertEquals(res.statusCode(), 200);
            if(response.getInt("data.timelineDetails.size()")==2) {
                check=true;
            }count++;
        }
        
        Assert.assertEquals(response.getInt("data.timelineDetails.size()"),2, "testTimeline_CaseStatus__timelineSize_failed getting "+response.getInt("data.timelineDetails.size()"));
        softAssert.assertEquals(response.getInt("data.timelineDetails[0].ticketId"),PayLoad_TimeLine.ticketId, "testTimeline_CaseStatus__ticketId_failed");
        softAssert.assertEquals(response.getString("data.timelineDetails[0].type"),"FIELD_CHANGE", "testTimeline_CaseStatus__type_failed");
        softAssert.assertEquals(response.getString("data.timelineDetails[0].event"),"changed the status", "testTimeline_event__ticketId_failed");
        softAssert.assertEquals(response.getString("data.timelineDetails[0].oldValue"),"NEW", "testTimeline_CaseStatus__oldValue_failed");
        softAssert.assertEquals(response.getString("data.timelineDetails[0].newValue"),PayLoad_TimeLine.caseStatus, "testTimeline_CaseStatus__newValue_failed");
        softAssert.assertEquals(response.getString("data.timelineDetails[0].status"),PayLoad_TimeLine.caseStatus, "testTimeline_CaseStatus__status_failed");
    }
    
    
    
    
    
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-409
    @Test(priority=4, groups = {  "TimeLine", "api","regression" })
    // TLA TC-07 : Update the  "Prioity"of a ticket and Hit the GET API to check if timeline got created, then status and response validation.
    public void testTimeline_Priority() throws Exception {
        if(role.equals("requester")) {
            return;
        }
        Response res = PayLoad_TimeLine.getResUpdate("priority");
        JsonPath response = PayLoad_TimeLine.getJsonPath(res);
        
        //Asserts
        Assert.assertEquals(res.statusCode(), 200);
        Boolean check = false;
        int count =0;
        
        while(!check && count<=5) {
            Thread.sleep(3000);
            res = PayLoad_TimeLine.getResGetTimeline();
            response = PayLoad_TimeLine.getJsonPath(res);
            
            
            //Asserts
            Assert.assertEquals(res.statusCode(), 200);
            if(response.getInt("data.timelineDetails.size()")==3) {
                check=true;
            }count++;
        }
        
        Assert.assertEquals(response.getInt("data.timelineDetails.size()"),3, "testTimeline_Priority__timelineSize_failed "+response.getInt("data.timelineDetails.size()"));
        softAssert.assertEquals(response.getInt("data.timelineDetails[0].ticketId"),PayLoad_TimeLine.ticketId, "testTimeline_Priority__ticketId_failed");
        softAssert.assertEquals(response.getString("data.timelineDetails[0].type"),"FIELD_CHANGE", "testTimeline_Priority__type_failed");
        softAssert.assertEquals(response.getString("data.timelineDetails[0].event"),"changed the priority", "testTimeline_Priority__event_failed");
        softAssert.assertEquals(response.getString("data.timelineDetails[0].oldValue"),"None", "testTimeline_Priority__oldValue_failed");
        softAssert.assertEquals(response.getString("data.timelineDetails[0].newValue"),PayLoad_TimeLine.priority, "testTimeline_Priority__newValue_failed");
        softAssert.assertEquals(response.getString("data.timelineDetails[0].status"),PayLoad_TimeLine.caseStatus, "testTimeline_Priority__status_failed");
    }
    
    
    
    
    
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-408
    @Test(priority=5, groups = {  "TimeLine", "api","regression" })
    // TLA TC-08 : Update the  "Due Date"of a ticket and Hit the GET API to check if timeline got created, then status and response validation.
    public void testTimeline_DueDate() throws Exception {
        if(role.equals("requester")) {
            return;
        }
        Response res = PayLoad_TimeLine.getResUpdate("dueDate");
        JsonPath response = PayLoad_TimeLine.getJsonPath(res);
        
        //Asserts
        Assert.assertEquals(res.statusCode(), 200);
        Boolean check = false;
        int count =0;
        
        while(!check && count<=5) {
            Thread.sleep(3000);
            res = PayLoad_TimeLine.getResGetTimeline();
            response = PayLoad_TimeLine.getJsonPath(res);
            
            
            //Asserts
            Assert.assertEquals(res.statusCode(), 200);
            if(response.getInt("data.timelineDetails.size()")==4) {
                check=true;
            }count++;
        }
        
        Assert.assertEquals(response.getInt("data.timelineDetails.size()"),4, "testTimeline_DueDate__timelineSize_failed "+response.getInt("data.timelineDetails.size()"));
        softAssert.assertEquals(response.getInt("data.timelineDetails[0].ticketId"),PayLoad_TimeLine.ticketId, "testTimeline_DueDate__ticketId_failed");
        softAssert.assertEquals(response.getString("data.timelineDetails[0].type"),"FIELD_CHANGE", "testTimeline_DueDate__type_failed");
        softAssert.assertEquals(response.getString("data.timelineDetails[0].event"),"changed the due date", "testTimeline_DueDate__event_failed");
        softAssert.assertEquals(response.getString("data.timelineDetails[0].oldValue"),"None", "testTimeline_DueDate__oldValue_failed");
        softAssert.assertEquals(response.getString("data.timelineDetails[0].newValue"),PayLoad_TimeLine.dueDate, "testTimeline_DueDate__newValue_failed");
        softAssert.assertEquals(response.getString("data.timelineDetails[0].status"),PayLoad_TimeLine.caseStatus, "testTimeline_DueDate__status_failed");
    }
    
    
    
    
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-408
    @Test(priority=2, groups = {  "TimeLine", "api","regression" })
    // TLA TC-09 : Update the  "Group"of a ticket and Hit the GET API to check if timeline got created, then status and response validation.
    public void testTimeline_Group() throws Exception {
        if(role.equals("requester")) {
            return;
        }
        Response res = PayLoad_TimeLine.getResUpdate("group");
        JsonPath response = PayLoad_TimeLine.getJsonPath(res);
        
        //Asserts
        Assert.assertEquals(res.statusCode(), 200);
        Boolean check = false;
        int count =0;
        
        while(!check && count<=6) {
            Thread.sleep(3000);
            res = PayLoad_TimeLine.getResGetTimeline();
            response = PayLoad_TimeLine.getJsonPath(res);
            
            
            //Asserts
            Assert.assertEquals(res.statusCode(), 200);
            if(response.getInt("data.timelineDetails.size()")==1) {
                check=true;
            }count++;
        }
        
        //Asserts
        Assert.assertEquals(response.getInt("data.timelineDetails.size()"),1, "testTimeline_Group__timelineSize_failed getting "+response.getInt("data.timelineDetails.size()"));
        Assert.assertEquals(response.getInt("data.timelineDetails[0].ticketId"),PayLoad_TimeLine.ticketId, "testTimeline_Group__ticketId_failed");
        softAssert.assertEquals(response.getString("data.timelineDetails[0].type"),"FIELD_CHANGE", "testTimeline_Group__type_failed");
        softAssert.assertEquals(response.getString("data.timelineDetails[0].event"),"changed the group", "testTimeline_Group__event_failed");
        softAssert.assertEquals(response.getString("data.timelineDetails[0].oldValue"),"None", "testTimeline_Group__oldValue_failed");
        softAssert.assertEquals(response.getString("data.timelineDetails[0].newValue"),PayLoad_TimeLine.groupName, "testTimeline_Group__newValue_failed");
        softAssert.assertEquals(response.getString("data.timelineDetails[0].status"),PayLoad_TimeLine.caseStatus, "testTimeline_Group__status_failed");
    }
    
    
    
    
    // DEFECT ID : https://byjustech.atlassian.net/browse/WFM-412
    @Test(priority=6, groups = {  "TimeLine", "api","regression" })
    // TLA TC-10 : Update the  "Agent"of a ticket and Hit the GET API to check if timeline got created, then status and response validation.
    public void testTimeline_Agent() throws Exception {
        if(role.equals("requester")) {
            return;
        }
        Response res = PayLoad_TimeLine.getResUpdate("agent");
        JsonPath response = PayLoad_TimeLine.getJsonPath(res);
        
        //Asserts
        Assert.assertEquals(res.statusCode(), 200);
        Boolean check = false;
        int count =0;
        
        while(!check && count<=5) {
            Thread.sleep(3000);
            res = PayLoad_TimeLine.getResGetTimeline();
            response = PayLoad_TimeLine.getJsonPath(res);
            
            
            //Asserts
            Assert.assertEquals(res.statusCode(), 200);
            if(response.getInt("data.timelineDetails.size()")==5) {
                check=true;
            }count++;
        }
        
        Assert.assertEquals(response.getInt("data.timelineDetails.size()"),5, "testTimeline_Agent__timelineSize_failed getting "+response.getInt("data.timelineDetails.size()"));
        softAssert.assertEquals(response.getInt("data.timelineDetails[0].ticketId"),PayLoad_TimeLine.ticketId, "testTimeline_Agent__ticketId_failed");
        softAssert.assertEquals(response.getString("data.timelineDetails[0].type"),"FIELD_CHANGE", "testTimeline_Agent__type_failed");
        softAssert.assertEquals(response.getString("data.timelineDetails[0].event"),"changed the agent", "testTimeline_Agent__event_failed");
        softAssert.assertEquals(response.getString("data.timelineDetails[0].oldValue"),"None", "testTimeline_Agent__oldValue_failed");
        softAssert.assertEquals(response.getString("data.timelineDetails[0].newValue"),PayLoad_TimeLine.agentNameFirst+" "+PayLoad_TimeLine.agentNameLast, "testTimeline_Agent__newValue_failed");
        softAssert.assertEquals(response.getString("data.timelineDetails[0].status"),PayLoad_TimeLine.caseStatus, "testTimeline_Agent__status_failed");
    }
    
    
    
    
    
//    @AfterClass(groups = {  "TimeLine", "api","regression" })
//    public void deleteAndAssertall_TimeLine() {
//        Response res = PayLoad_TimeLine.deleteTicketResponse();
//        JsonPath response = PayLoad_TimeLine.getJsonPath(res);
//        
//        //Asserts
//        Assert.assertEquals(res.statusCode(), 200);
//        softAssert.assertAll();
//    }
}
