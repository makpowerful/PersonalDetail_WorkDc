package pageObjects;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import resources.ExcelData;
import resources.base;

public class PO_CaseList extends base{
    WebDriver driver;
    private static ExcelData excelData = new ExcelData();
    private static ArrayList<String> al = new ArrayList<String>();
    
    public PO_CaseList(WebDriver driver) {
        this.driver = driver;
    }
    
    
    
    // xpaths of all WebElements of CaseList Screen.
    private By createButton = By.xpath("//button[@data-testid='custom-button-component']");
    
    private By globalSearch = By.xpath("//div[@class='search-bar']");
    
    private By casesIconSidebar = By.xpath("//div[contains(@class,'menuItems-Wrapper')]//div[contains(text(),'Cases')]");
    
    private By groupsIconSidebar = By.xpath("//div[@class='menuItems-Wrapper']//div[contains(text(),'Groups')]");
    
    private By logoutIconSidebar = By.xpath("//div[@class='menuItems-Wrapper']//div[contains(text(),'Logout')]");
    
    private By byjusLogo = By.xpath("//div[@data-testid='navMenu']/img");
    
    private By expandedSearch = By.xpath("//input[@data-testid='search-bar-input']");
    private By exportBtn = By.xpath("//button[contains(text(),'Export')]");
    private By filtersBtn = By.xpath("//button[contains(text(),'Filters')]");
    protected By ticketCards = By.xpath("//a[@class='cardLink']");
    private By cardTicketId = By.xpath("//span[@class='ticketCard__textTicketId']");
    private By cardTicketSubject = By.xpath("//span[@class='ticketCard__textSubject']");
    private By sorterDropDown = By.xpath("//div[@class='ticket_sorter']//div[contains(@class,'sorter_dropdown')]");
    private By sorterDropDownOptions = By.xpath("//div[@class='dropdown__dropdownSheet']//div[contains(@class,'dropdown__dropdownOption')]");
    private By titleText = By.className("caseDetails__left__title");
    private By ticketIdText = By.className("caseDetails__left__ticketDetails__ticketId");
    protected By createdAtText = By.xpath("//span[@class='ticketCard__textCreatedAt']");
    private By priorityText = By.xpath("//div[@class='ticketCard__textPriority']");
    private By caseStatusLabel = By.xpath("//div[@class='caseProperties']//div[contains(text(),'Case Status')]//following-sibling::div[1]");
    private By dropDownOption = By.xpath("//div[@data-testid='dropdown__singleOption']");
    private By updateBtn = By.xpath("//button[contains(text(),'Update')]");
    protected By rightPaginationButton = By.xpath("//button[contains(@class,'button_right_icon')]");
    
    // ------------------------------------------------------------------------------------------------ 
    // Pratik Methods
    // ------------------------------------------------------------------------------------------------
    
    
    //@Author : Pratik
    //Capture the "Create+" button on the top right of screen.
    public String getCreateButtonText() {
        visibleText(createButton);
        return driver.findElement(createButton).getText();
    }
    
    
    
    //@Author : Pratik
    //Capture the Gloabl Search Icon on top right of screen.
    public void getGlobalSearch() {
        visibleText(globalSearch);
        clickButton(driver.findElement(globalSearch));
    }
    
    
    
    //@Author : Pratik
    //Capture the "Cases" icon from menu bar on left side of the screen.
    public String getCasesIconSidebarText() {
        visibleText(casesIconSidebar);
        return driver.findElement(casesIconSidebar).getText();
    }
    
    
    
    //@Author : Pratik
    //Capture the "Groups" icon from menu bar on left side of the screen.
    public String getGroupsIconSidebarText() {
        visibleText(groupsIconSidebar);
        return driver.findElement(groupsIconSidebar).getText();
    }
    
    
    
    
    //@Author : Pratik
    //Capture and type in the expanded search icon from top right of the screen.
    public void typeInExpandedSearch(String caseId) {
        visibleText(expandedSearch);
        driver.findElement(expandedSearch).sendKeys(caseId);
    }
    
    // ------------------------------------------------------------------------------------------------ 
    // Gaurang Methods
    // ------------------------------------------------------------------------------------------------
    
    //@Author : Gaurang
    //Capture the logo img tag from menu bar on left side of the screen.
    public String getByjusLogoTagName() {
        visibleText(byjusLogo);
        return driver.findElement(byjusLogo).getTagName();
    }
    
    //@Author : Gaurang
    //Capture the logout text from menu bar on left side of the screen.
    public String getLogoutIconSidebarText() {
        visibleText(logoutIconSidebar);
        return driver.findElement(logoutIconSidebar).getText();
    }
    
    //@Author : Gaurang
    //Capture the export button text
    public String getExportBtnText() {
        visibleText(exportBtn);
        return driver.findElement(exportBtn).getText();
    }
    
    //@Author : Gaurang
    //Capture the filters button text
    public String getFiltersBtnText() {
        visibleText(filtersBtn);
        return driver.findElement(filtersBtn).getText();
    }
    
    //@Author : Gaurang
    //Check if all the options match the excel data
    public Boolean checkSortOptions() throws IOException {
        al = excelData.getData("DropDownOptions", "CaseListScreen", "Tcid");
        visibleText(sorterDropDown);
        WebElement parent = driver.findElement(sorterDropDown);
        
        try {
            visibleText(parent.findElements(sorterDropDownOptions));
            List<WebElement> options;
            options = parent.findElements(sorterDropDownOptions);
            List<String> optionsText = new ArrayList<String>();
            options.forEach((option) -> {
                optionsText.add(option.getText());
//                System.out.println(option.getText());
            });
//            System.out.println("----------------------------");
            for(int i=1; i<=optionsText.size(); i++) {
                if(optionsText.contains(al.get(i)) != true) {
//                    System.out.println(al.get(i));
                    return false;
                }
            }
        }
        catch(Exception ex)
        {
            visibleText(parent.findElements(sorterDropDownOptions));
            List<WebElement> options;
            options = parent.findElements(sorterDropDownOptions);
            List<String> optionsText = new ArrayList<String>();
            options.forEach((option) -> {
                optionsText.add(option.getText());
            });
            for(int i=1; i<=optionsText.size(); i++) {
                if(optionsText.contains(al.get(i)) != true) {
                    return false;
                }
            }
        }
        return true;
    }
    
    //@Author : Gaurang
    //Click the sorter drop down menu
    public void clickSorterDropDown() {
        visibleText(sorterDropDown);
       jsClick(driver.findElement(sorterDropDown));
    }
    
    public void jsClick(WebElement el) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].click();", el);
            System.out.println("Element clicked");
        } catch (Exception e) {
            System.out.println("=============================================================");
            System.out.println("Exception-jsClick(): " + e.getMessage());
            //takeScreenShot();
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }
    
    //@Author : Gaurang
    //check the first ticket and assert its subject ticket Id and other
    public Boolean checkFirstTicket() {
        visibleText(ticketCards);
        List<WebElement> tickets = driver.findElements(ticketCards);
        String subject = tickets.get(0).findElement(cardTicketSubject).getText();
        String ticketId =tickets.get(0).findElement(cardTicketId).getText().substring(1);
        clickTicketCard(0);
        visibleText(titleText);
        if(!driver.findElement(titleText).getText().equalsIgnoreCase(subject)) {
            return false;
        }
        visibleText(ticketIdText);
        if(!driver.findElement(ticketIdText).getText().split("-")[1].equalsIgnoreCase(ticketId)) {
            return false;
        }
        return true;
    }
    
    //@Author : Gaurang
    //convert string to time
    public double stringToTime(WebElement ele) {
        if(ele.getText().contains("seconds")) {
            return 1/86400;
        }
        else if(ele.getText().contains("minutes")) {
            return (Integer.parseInt(ele.getText().split(" ")[1]))/1440;
        }
        else if(ele.getText().contains("hours")) {
            return (Integer.parseInt(ele.getText().split(" ")[1]))/24;
        }
        else {
            return (Integer.parseInt(ele.getText().split(" ")[1]));
        }
    }
    
    //@Author : Gaurang
    //click specific sorter option
    public void clickSorterOption(String option) throws IOException {
        clickSorterDropDown();
        visibleText(sorterDropDown);
        WebElement parent = driver.findElement(sorterDropDown);
        visibleText(parent.findElements(sorterDropDownOptions));
        List<WebElement> options = parent.findElements(sorterDropDownOptions);
        for(int i=0; i<=options.size(); i++) {
            if(options.get(i).getText().compareToIgnoreCase(option) == 0) {
               jsClick(options.get(i));
                break;
            }
        }
    }
    
    //@Author : Gaurang
    //Checking the date created new to old sort functionality of the case list screen
    public Boolean checkSortNewToOld() throws IOException {
        al = excelData.getData("DropDownOptions", "CaseListScreen", "Tcid");
        clickSorterOption(al.get(1));
        visibleText(ticketCards);
        List<WebElement> tickets = driver.findElements(ticketCards);
        for(int i=0; i<tickets.size()-1; i++) {
            double time1, time2;
            time1 = stringToTime(tickets.get(i).findElement(createdAtText));
            time2 = stringToTime(tickets.get(i+1).findElement(createdAtText));
            if(time1 > time2) {
                return false;
            }
        }
        return true;
    }
    
    //@Author : Gaurang
    //Checking the date created old to new sort functionality of the case list screen
    public Boolean checkSortOldToNew() throws IOException {
        al = excelData.getData("DropDownOptions", "CaseListScreen", "Tcid");
        clickSorterOption(al.get(2));
        visibleText(ticketCards);
        List<WebElement> tickets = driver.findElements(ticketCards);
        for(int i=0; i<tickets.size()-1; i++) {
            double time1, time2;
            time1 = stringToTime(tickets.get(i).findElement(createdAtText));
            time2 = stringToTime(tickets.get(i+1).findElement(createdAtText));
            if(time1 < time2) {
                return false;
            }
        }
        return true;
    }
    
    //@Author : Gaurang
    //convert string priority to integer value
    public int priorityToInt(String priority){
        if(priority.compareToIgnoreCase("urgent") == 0)
            return 1;
        else if(priority.compareToIgnoreCase("high") == 0)
            return 2;
        else if(priority.compareToIgnoreCase("medium") == 0)
            return 3;
        else if(priority.compareToIgnoreCase("low") == 0)
            return 4;
        return -1;
    }
    
    //@Author : Gaurang
    //Checking the priority urgent to low sort functionality of the case list screen
    public Boolean checkSortPriorityUrgentToLow() throws IOException, InterruptedException {
        al = excelData.getData("DropDownOptions", "CaseListScreen", "Tcid");
        clickSorterOption(al.get(4));
        visibleText(ticketCards);
        List<WebElement> tickets = driver.findElements(ticketCards);
        for(int i=0; i<tickets.size()-1; i++) {
            int p1, p2;
            p1 = priorityToInt(tickets.get(i).findElement(priorityText).getText());
            p2 = priorityToInt(tickets.get(i+1).findElement(priorityText).getText());
            if(p1 == -1 || p2 == -1) {
                return false;
            }
            else if(p1 > p2)
                return false;
        }
        return true;
    }
    
    //@Author : Gaurang
    //Checking the priority urgent to low sort functionality of the case list screen
    public Boolean checkSortPriorityLowToUrgent() throws IOException, InterruptedException {
        al = excelData.getData("DropDownOptions", "CaseListScreen", "Tcid");
        try {
        clickSorterOption(al.get(5));
        }
        catch(Exception e) {
            clickSorterOption(al.get(5));   
        }
        visibleText(ticketCards);
        List<WebElement> tickets = driver.findElements(ticketCards);
        for(int i=0; i<tickets.size()-1; i++) {
            int p1, p2;
            p1 = priorityToInt(tickets.get(i).findElement(priorityText).getText());
            p2 = priorityToInt(tickets.get(i+1).findElement(priorityText).getText());
            if(p1 == -1 || p2 == -1) {
                return false;
            }
            else if(p1 < p2)
                return false;
        }
        return true;
    }
    
    //@Author : Gaurang
    //Checking the last modified sort functionality of the case list screen
    public Boolean checkSortLastModified() throws IOException, InterruptedException{
        al = excelData.getData("DropDownOptions", "CaseListScreen", "Tcid");
        clickSorterOption(al.get(2));
        clickTicketCard(0);
        visibleText(ticketIdText);
        String ticketId = driver.findElement(ticketIdText).getText().split("-")[1];
        visibleText(titleText);
        String ticketTitle = driver.findElement(titleText).getText();
        visibleText(caseStatusLabel);
        String currentCaseStatus = driver.findElement(caseStatusLabel).getText();
        driver.findElement(caseStatusLabel).click();
        visibleText(driver.findElement(caseStatusLabel).findElements(dropDownOption));
        List<WebElement> eles = driver.findElement(caseStatusLabel).findElements(dropDownOption);
        for(int i=0; i<eles.size(); i++) {
            if(eles.get(i).getText().compareToIgnoreCase(currentCaseStatus) != 0) {
                eles.get(i).click();
                break;
            }
        }
        clickable(updateBtn);
        driver.findElement(updateBtn).click();
        goToCaseListScreen();
        Thread.sleep(1000);
        clickSorterOption(al.get(3));
        visibleText(ticketCards);
        Thread.sleep(1000);
        List<WebElement> tickets = driver.findElements(ticketCards);
        if(ticketTitle.compareTo(tickets.get(0).findElement(cardTicketSubject).getText()) != 0) {
            System.out.println(ticketTitle);
            System.out.println(tickets.get(0).findElement(cardTicketSubject).getText());
            return false;
        }
        if(ticketId.compareTo(tickets.get(0).findElement(cardTicketId).getText().substring(1)) != 0) {
            System.out.println(ticketId);
            System.out.println(tickets.get(0).findElement(cardTicketId).getText().substring(1));
            return false;
        }
        clickTicketCard(0);
        visibleText(caseStatusLabel);
        driver.findElement(caseStatusLabel).click();
        eles = driver.findElement(caseStatusLabel).findElements(dropDownOption);
        for(int i=0; i<eles.size(); i++) {
            if(eles.get(i).getText().compareToIgnoreCase(currentCaseStatus) == 0) {
                eles.get(i).click();
                break;
            }
        }
        clickable(updateBtn);
        driver.findElement(updateBtn).click();
        goToCaseListScreen();
        return true;
    }
    
    //@Author : Gaurang
    //Click the sorter drop down menu
    public void clickTicketCard(int num) {
        visibleText(ticketCards);
        List<WebElement> tickets = driver.findElements(ticketCards);
        tickets.get(num).click();
    }
    
    //@Author : Gaurang
    //go to case list screen 
    public void goToCaseListScreen() {
        visibleText(casesIconSidebar);
        clickable(casesIconSidebar);
        driver.findElement(casesIconSidebar).click();
    }
    
    //@Author : Gaurang
    //check export button
    public boolean isExportButtonPresent() {
        return checkElementExists(exportBtn);
    }
    
    //@Author : Gaurang
    //Click the rightPaginationButton
    public void clickRightPaginationButton() {
        visibleText(rightPaginationButton);
        clickable(rightPaginationButton);
        driver.findElement(rightPaginationButton).click();
    }
    
    // ------------------------------------------------------------------------------------------------
    
    public void implicitWait(int time) {
        driver.manage().timeouts().implicitlyWait(time, TimeUnit.SECONDS);
    }
    
    
    public String getCurrentWindowHandle() {
        return driver.getWindowHandle();
    }
    
    
    public boolean visibleText(By element) {
        WebDriverWait wait = new WebDriverWait(driver, 10);

        wait.ignoring(StaleElementReferenceException.class)
                .until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));

        return false;
    }
    
    public boolean visibleText(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, 10);

        wait.ignoring(StaleElementReferenceException.class)
                .until(ExpectedConditions.visibilityOfAllElements(element));

        return false;
    }
    
    public boolean visibleText(List<WebElement> element) {
        WebDriverWait wait = new WebDriverWait(driver, 10);

        wait.ignoring(StaleElementReferenceException.class)
                .until(ExpectedConditions.visibilityOfAllElements(element));

        return false;
    }
    
    
    public void clickButton(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, 10);

        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));

        element.click();
    }
    
    public boolean clickable(By element){
        WebDriverWait wait= new WebDriverWait(driver, 10);
        
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));

        return false;
    }
    
    public boolean checkElementExists(By xpath) {
        boolean result = false;
        try {
            driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
            driver.findElement(xpath);
            result = true;
        }
        catch(NoSuchElementException ex) {
            result = false;
        }
        finally {
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        return result;
    }
}
