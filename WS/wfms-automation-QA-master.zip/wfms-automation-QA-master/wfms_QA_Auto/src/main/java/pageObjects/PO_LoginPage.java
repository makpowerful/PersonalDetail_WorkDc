package pageObjects;

import java.util.Iterator;
import java.util.Set;

import org.jboss.aerogear.security.otp.Totp;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import resources.base;

public class PO_LoginPage extends base {

    private WebDriver driver;
    private WebDriverWait wait;
    private WebElement frame;

    public String byjusLogoXpath = "//img[@alt='Byjus logo']";
    public String welcomeTextXpath = "//h1[text()='Welcome']";
    public String pleaseSignInThroughYourCompanyEmailTextXpath = "//h2[text()='Please sign in through your company mail']";
    public String signInWithGoogleButtonXpath = "//span[text()='Sign in with Google'][1]";

    // constructor
    public PO_LoginPage(WebDriver driver) {

        this.driver = driver;
    }

    // @Author : Ankur
    // get tag name of an element
    public String getTagName(String xpath) {

        By element = By.xpath(xpath);
        visibleText(element);
        return driver.findElement(element).getTagName();
    }

    // @Author : Ankur
    // get text of an element
    public String getText(String xpath) {

        By element = By.xpath(xpath);
        visibleText(element);
        return driver.findElement(element).getText();
    }

    // @Author : Ankur
    // get byjus logo tag name
    public String getByjusLogoTagName() {

        return getTagName(byjusLogoXpath);
    }

    // @Author : Ankur
    // get welcome text
    public String getWelComeText() {

        return getText(welcomeTextXpath);
    }

    // @Author : Ankur
    // get please sign through your company email text
    public String getPleaseSignInThroughYourCompanyEmailText() {

        return getText(pleaseSignInThroughYourCompanyEmailTextXpath);
    }

    // @Author : Ankur
    // switch to login module iframe
    public void switchToLoginModuleIframe() throws Exception {

        retryForDetachedFrame(driver, "//iframe[@title='Login Module']", 0);
        frame = driver.findElement(By.xpath("//iframe[@title='Login Module']"));
        Thread.sleep(500);
        driver.switchTo().frame(frame);
    }

    // @Author : Ankur
    // switch to sign in with google button iframe
    public void switchToSignInWithGoogleButtonIframe() throws Exception {

        retryForDetachedFrame(driver, "//iframe[@title='Sign in with Google Button']", 0);
        frame = driver.findElement(By.xpath("//iframe[@title='Sign in with Google Button']"));
        Thread.sleep(500);
        driver.switchTo().frame(frame);
    }

    // @Author : Ankur
    // switch to main frame
    public void switchToMainFrame() {

        driver.switchTo().defaultContent();
    }

    // @Author : Ankur
    // get sign in with google button text
    public String getSignInWithGoogleButtonText() {

        return getText(signInWithGoogleButtonXpath);
    }

    // @Author = Ankur
    // click on sign in with google button
    private void clickOnSignInWithGoogleButton() throws Exception {

        switchToLoginModuleIframe();

        switchToSignInWithGoogleButtonIframe();

        Thread.sleep(1000);

        driver.findElement(By.xpath(signInWithGoogleButtonXpath)).click();
    }

    // @Author = Ankur
    // google login using email id and password
    public void googleLogin(String email, String password) throws Exception {

        clickOnSignInWithGoogleButton();

        Set<String> windows = driver.getWindowHandles();
        Iterator<String> it = windows.iterator();

        it.next();
        String c = (String) it.next();

        driver.switchTo().window(c);

        wait = new WebDriverWait(driver, 10);

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='email']")));

        driver.findElement(By.xpath("//input[@type='email']")).sendKeys(email);
        driver.findElement(By.xpath("//span[text()='Next']")).click();

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='password']")));

        driver.findElement(By.xpath("//input[@type='password']")).sendKeys(password);
        driver.findElement(By.xpath("//span[text()='Next']")).click();
        
        driver.findElement(By.id("totpPin")).sendKeys(getTwoFactorCode());
        
        driver.findElement(By.id("totpNext")).click();

        windows = driver.getWindowHandles();
        it = windows.iterator();

        c = (String) it.next();

        driver.switchTo().window(c);

        visibleText(By.xpath("//img[contains(@src,media/WFMSLogo)]"));
    }

    public static String getTwoFactorCode() {
        // Replace with your security key copied from step 12
        Totp totp = new Totp("6x5urekir6iwsubej2zrpmtbeypvkxxv"); // 2FA secret key
        String twoFactorCode = totp.now(); // Generated 2FA code here
        return twoFactorCode;
    }

    // @Author = Ankur
    // go to case creation page
    public void goToCaseCreationPage() {

        visibleText(By.xpath("//button[1]"));

        driver.findElement(By.xpath("//button[1]")).click();
    }

    // ------------------------------------------------------------------------------------------------
    // Pratik Methods
    // ------------------------------------------------------------------------------------------------

    // ------------------------------------------------------------------------------------------------
    // Gaurang Methods
    // ------------------------------------------------------------------------------------------------

    // @Author = Gaurang
    // switch to the login window
    public void switchToWindow() {
        String windowHandle = driver.getWindowHandle();
        driver.switchTo().window(windowHandle);
    }

    // @Author = Gaurang
    // switch to frame number
    public void switchToFrame(int frame) {
        driver.switchTo().frame(frame);
    }

    // ------------------------------------------------------------------------------------------------

    public void retryForDetachedFrame(final WebDriver driver, final String elementXpath, final int frameId)
            throws Exception {
        int webDriverExceptionCounter = 0;
        while (webDriverExceptionCounter < 5) {
            try {
                driver.findElement(By.xpath(elementXpath));
                break;
            } catch (final WebDriverException ex) {
                webDriverExceptionCounter++;
                if (webDriverExceptionCounter == 5) {
                    // log.error("WebDriverException, not trying again: {}",
                    // webDriverExceptionCounter);
                    throw ex;
                } else {
                    // log.info("WebDriverException, retrying: {}", webDriverExceptionCounter);
                    Thread.sleep(500);
                    final WebDriverWait wait = new WebDriverWait(driver, 15);
                    wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameId));
                }
            } catch (final Exception e) {
                // log.error("Exception: {}", e.getClass());
                throw e;
            }
        }
    }

    public boolean visibleText(By element) {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        wait.ignoring(StaleElementReferenceException.class)
                .until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));

        return false;
    }
}
