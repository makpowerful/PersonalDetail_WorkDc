package pageObjects;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.jboss.aerogear.security.otp.Totp;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PO_UserScreen{
    public WebDriver driver;
    private WebDriverWait wait;
    private WebElement frame;

    public String byjusLogoXpath = "//img[@alt='Byjus logo']";
    public String welcomeTextXpath = "//h1[text()='Welcome']";
    public String pleaseSignInThroughYourCompanyEmailTextXpath = "//h2[text()='Please sign in through your company mail']";
    public String signInWithGoogleButtonXpath = "//span[text()='Sign in with Google'][1]";
    
    // Select App Screen Xpaths
    private By workFlowApp = By.xpath("//li[text()='workflow-management-demo']");
    private By confirmButton = By.xpath("//button[text()='Confirm']");
    
    
    private By usersTile = By.xpath("//div[text()='Users']");
    private By editIcon = By.xpath("//img[@alt='edit_button']");
    private By saveButton = By.xpath("//button[text()='Save']");
    
    //Filter Section
    private By filterButton = By.xpath("//button[@data-testid='filter-button']");
    private By emailInputField = By.xpath("//input[@placeholder='Enter Email']");
    private By applyButton = By.xpath("//button[text()='Apply']");
    
    // constructor
    public PO_UserScreen(WebDriver driver) {
        this.driver = driver;
    }
    
    // @author - Pratik Jain
    // completes the steps in Select App screen.
    public void selectAppScreen() {
        clickable(workFlowApp);
        driver.findElement(workFlowApp).click();
        clickable(confirmButton);
        driver.findElement(confirmButton).click();
    }
    
    // @author - Pratik Jain
    // clicks on "users" Tile.
    public void goToUsersScreen() {
        clickable(usersTile);
        driver.findElement(usersTile).click();
    }
    
    // @author - Pratik Jain
    // Selects the provided user through the userEmail provided, removes all previously assigned roles
    // And selects the newly provided roles in "roles" arrayList to the user.
    public void editRolesForUser(String userEmail,List<String> roles) throws InterruptedException {
        
        visibleText(editIcon);
        
        //click on Filter Icon.
        clickable(filterButton);
        driver.findElement(filterButton).click();
        
        //Fill Email Input Field and Apply.
        clickable(emailInputField);
        driver.findElement(emailInputField).sendKeys(userEmail);
        Thread.sleep(1000);
        clickable(applyButton);
        driver.findElement(applyButton).click();
        //Thread.sleep(1000);
        
        //Check if the required EmailId is shown in the screen.
        //visibleText(By.xpath("//p[text()='"+userEmail+"']"));
        visibleText(By.xpath("//p[contains(text(),'"+userEmail+"')]"));
        visibleText(By.xpath("//p[contains(text(),'"+userEmail+"')]//following::img[1]"));
        clickable((By.xpath("//p[contains(text(),'"+userEmail+"')]//following::img[1]")));
        Thread.sleep(1500);
        try {
        driver.findElement((By.xpath("//p[contains(text(),'"+userEmail+"')]//following::img[1]"))).click();
        }
        catch (Exception e) {
            // TODO: handle exception
            try {
                jsClick(driver.findElement((By.xpath("//p[contains(text(),'"+userEmail+"')]//following::img[1]"))));
            }
            catch(Exception ex) {
                //driver.get(driver.getCurrentUrl());
                //editRolesForUser(userEmail, roles);
                //return;
                driver.findElement(filterButton).click();
                jsClick(driver.findElement((By.xpath("//p[contains(text(),'"+userEmail+"')]//following::img[1]"))));
            }
        }

        //remove all previous roles.
        int prevNoOfRoles = driver.findElements(By.xpath("//div[@class='ml-2 focus:outline-none']")).size();
        for(int i=0;i<prevNoOfRoles;i++) {
            driver.findElement(By.xpath("//div[@class='ml-2 focus:outline-none']")).click();
        }
        
        
        //add new roles provided in the "roles" arrayList.
        driver.findElement(By.xpath("//img[@class='transition-all  absolute right-4 w-4 h-4 ml-2']")).click();
        prevNoOfRoles = roles.size();
        
        for(int i=0;i<prevNoOfRoles;i++) {
                    jsClick(driver.findElement(By.xpath("//p[text()='"+roles.get(i)+"']")));
        }
        driver.findElement(By.xpath("//img[@class='transition-all transform rotate-180 absolute right-4 w-4 h-4 ml-2']")).click();
        
        // Save the roles.
        driver.findElement(saveButton).click();
    }
    
    
    // @Author - Pratik jain
    // return the number of agents 
    public int noOfAgents(String projectName) throws InterruptedException {
        driver.navigate().refresh();
        List<String> roles = new ArrayList<String>();
        roles.add(projectName+"-agent");
        roles.add(projectName+"-admin");
        roles.add(projectName+"-supervisor");
        roles.add("superadmin");
        
        visibleText(editIcon);
        
        //click on Filter Icon.
        clickable(filterButton);
        driver.findElement(filterButton).click();
        
      //add new roles provided in the "roles" arrayList.
        driver.findElement(By.xpath("//div[@data-testid='open dropdown']")).click();
        int totalRolestoAssign = roles.size();
        
        for(int i=0;i<totalRolestoAssign;i++) {
                  jsClick(driver.findElement(By.xpath("//p[text()='"+roles.get(i)+"']")));
      }
        jsClick(driver.findElement(applyButton));
        clickable(editIcon);
        Thread.sleep(3000);
        String count = driver.findElement(By.xpath("//p[contains(text(),'Showing')]")).getText().split(" ")[5];
        
        return Integer.valueOf(count);
    }
    
    
    
    
    
    
    // @Author : Ankur
    // switch to sign in with google button iframe
    public void switchToSignInWithGoogleButtonIframe() throws Exception {
        retryForDetachedFrame(driver, "//iframe[@title='Sign in with Google Button']", 0);
        frame = driver.findElement(By.xpath("//iframe[@title='Sign in with Google Button']"));
        Thread.sleep(1000);
        driver.switchTo().frame(frame);
    }
    
    
    // @Author : Ankur
    // switch to main frame
    public void switchToMainFrame() {
        driver.switchTo().defaultContent();
    }
    
    
    // @Author = Ankur
    // click on sign in with google button
    private void clickOnSignInWithGoogleButton() throws Exception {
        //switchToLoginModuleIframe();
        switchToSignInWithGoogleButtonIframe();
        Thread.sleep(1000);
        driver.findElement(By.xpath(signInWithGoogleButtonXpath)).click(); 
    }
    
    // @Author = Ankur
    // google login using email id and password 
    public void googleLogin(String email, String password) throws Exception {
        clickOnSignInWithGoogleButton();
        Set<String> windows = driver.getWindowHandles();
        Iterator<String> it = windows.iterator();
        it.next();
        String c = (String) it.next();
        driver.switchTo().window(c);
        wait = new WebDriverWait(driver, 10);
        clickButton(driver.findElement(By.xpath("//input[@type='email']")));
        driver.findElement(By.xpath("//input[@type='email']")).sendKeys(email);
        driver.findElement(By.xpath("//span[text()='Next']")).click();
        
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='password']")));
        
        driver.findElement(By.xpath("//input[@type='password']")).sendKeys(password);
        driver.findElement(By.xpath("//span[text()='Next']")).click();
        
        driver.findElement(By.id("totpPin")).sendKeys(getTwoFactorCode());
        
        driver.findElement(By.id("totpNext")).click();
        
        windows = driver.getWindowHandles();
        it = windows.iterator();
        c = (String) it.next();
        
        driver.switchTo().window(c);
        //visibleText(By.xpath("//img[contains(@src,media/Byjus)]"));
    }
    
    public static String getTwoFactorCode() {
        // Replace with your security key copied from step 12
        Totp totp = new Totp("6x5urekir6iwsubej2zrpmtbeypvkxxv"); // 2FA secret key
        String twoFactorCode = totp.now(); // Generated 2FA code here
        return twoFactorCode;
    }
    
    public void clickButton(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, 10);

        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));

        System.out.println("Element is clickable");
        element.click();
    }
    // @author - Ankur
    public void switchToWindow() {
        String windowHandle = driver.getWindowHandle();
        driver.switchTo().window(windowHandle);
    }
    
    
    // @Author = Gaurang
    // switch to frame number
    public void switchToFrame(int frame) {
        driver.switchTo().frame(frame);
    }
    
   
    // @ author - Ankur
    public void retryForDetachedFrame(final WebDriver driver, final String elementXpath, final int frameId)
            throws Exception {
        int webDriverExceptionCounter = 0;
        while (webDriverExceptionCounter < 5) {
            try {
                driver.findElement(By.xpath(elementXpath));
                break;
            } catch (final WebDriverException ex) {
                webDriverExceptionCounter++;
                if (webDriverExceptionCounter == 5) {
                    // log.error("WebDriverException, not trying again: {}",
                    // webDriverExceptionCounter);
                    throw ex;
                } else {
                    // log.info("WebDriverException, retrying: {}", webDriverExceptionCounter);
                    Thread.sleep(500);
                    final WebDriverWait wait = new WebDriverWait(driver, 15);
                    wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameId));
                }
            } catch (final Exception e) {
                // log.error("Exception: {}", e.getClass());
                throw e;
            }
        }
    }
    

    // @author - Kalam
    // waits for the visibility of an element.
    public boolean visibleText(By element) {
        WebDriverWait wait = new WebDriverWait(driver, 15);
        wait.ignoring(StaleElementReferenceException.class)
                .until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));
        //System.out.println("Element is visible");
        return false;
    }
    
    
    // @author - Kalam
    // Check if the Element is Clickable.
    public boolean clickable(By element) {
        WebDriverWait wait= new WebDriverWait(driver, 15);
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));
        //System.out.println("Element is visible");
        return false;
    }
    
    public void jsClick(WebElement el) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].click();", el);
//            System.out.println("Element clicked");
        } catch (Exception e) {
            System.out.println("=============================================================");
            System.out.println("Exception-jsClick(): " + e.getMessage());
            //takeScreenShot();
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }
}
