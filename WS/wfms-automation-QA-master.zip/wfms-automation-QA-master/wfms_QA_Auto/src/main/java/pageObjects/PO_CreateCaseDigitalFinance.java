package pageObjects;

import java.util.HashMap;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PO_CreateCaseDigitalFinance {

    public WebDriver driver;
    public WebDriverWait wait;
    public HashMap<String, String> data;

    public PO_CreateCaseDigitalFinance(WebDriver driver) {

        this.driver = driver;
        data = new HashMap<>();
        wait = new WebDriverWait(driver, 10);
    }

    // form xpath
    public String createButtonXpath = "//button[text()='Create']";

    // popup xpath
    public String successFulTestCreationMessageXpath = "//div[@class='modal-ui_message']";
    public String closeModalButtonXpath = "//button[contains(@class,'modal__close-btn')]";

    String description = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus vitae porta mauris. Aliquam dapibus laoreet ligula in elementum. Maecenas pellentesque auctor efficitur. Etiam posuere magna vestibulum, aliquet lorem sed, consequat mi. Nulla facilisi. Curabitur finibus interdum sapien. Ut nec pharetra dolor.\n"
            + "\n"
            + "Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Praesent consequat quam id ex sollicitudin mollis. Vivamus volutpat tristique mattis. Aenean rhoncus eros ultrices, convallis felis eget, auctor nisl. Aliquam quis rutrum nisl. Proin eros justo, hendrerit ac imperdiet eget, condimentum nec nulla. Duis sed sagittis nibh. Praesent vitae urna rhoncus, dapibus augue sed, pretium lectus. Maecenas bibendum pharetra posuere. Praesent eu porttitor dolor.\n"
            + "\n"
            + "Ut sodales turpis ex, nec aliquam sem fringilla id. Vivamus mattis tortor a elit euismod sagittis. Vestibulum lobortis, massa vel molestie malesuada, urna quam interdum nisl, a congue nisl nulla ac risus. In dictum metus eu magna pharetra finibus. Proin neque justo, fringilla non varius quis, posuere condimentum nibh. Interdum et malesuada fames ac ante ipsum primis in faucibus. Proin finibus, nisl sit amet vehicula sagittis, neque nisl malesuada arcu, vel vehicula erat mauris eget nulla. Proin sollicitudin dolor est, vitae efficitur diam faucibus ut. Nunc efficitur nisi eu ultricies sodales. Duis vehicula urna pellentesque vulputate iaculis. Cras varius, metus in lobortis pulvinar, lacus dolor dictum augue, at aliquam diam urna vel felis. In interdum tortor a massa pharetra, ac suscipit tortor laoreet.\n"
            + "\n"
            + "Maecenas et malesuada lorem. Nullam sed tempus dui. Vestibulum aliquam, lectus ut commodo fermentum, leo erat sodales nunc, quis lobortis nisi augue eget lectus. Nam laoreet ultricies orci, eget vestibulum nunc vulputate eu. Quisque a quam ut ipsum cursus fermentum ut convallis urna. Nulla facilisi. Nam nec magna sit amet enim dictum ullamcorper tempor at dui. Morbi posuere vehicula diam, quis blandit ligula dapibus a. In ultricies orci justo, vitae tincidunt dui congue non. Donec condimentum elit nisl, ac posuere arcu hendrerit sit amet.\n"
            + "\n"
            + "Vestibulum felis nibh, sollicitudin sed sem ac, aliquet interdum eros. Nullam lobortis hendrerit scelerisque. Sed at diam et lorem congue porta. Nunc eros enim, tempus ut lectus eu, pellentesque efficitur neque. Fusce facilisis metus eget est eleifend ullamcorper. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent aliquam nulla odio, porttitor cursus purus lacinia sit amet.\n"
            + "\n"
            + "Donec pretium cursus ligula bibendum interdum. Cras porttitor mi sed leo cursus luctus. Pellentesque suscipit nunc mollis, dignissim massa congue, malesuada lorem. Cras sit amet dapibus ipsum. Phasellus pulvinar vestibulum elit, in molestie quam tempus id. In aliquet lacinia metus sed sagittis. Quisque nisi velit, auctor at eleifend a, bibendum placerat dui. Etiam mattis vel tellus eu condimentum.\n"
            + "\n"
            + "Suspendisse potenti. Sed id felis quis purus blandit luctus. Vestibulum tempus risus nec venenatis rhoncus. Aenean interdum sagittis nisl, at vulputate dolor faucibus at. Proin ut suscipit erat. Pellentesque lectus tellus, elementum nec velit ultricies, porttitor faucibus dolor. Nulla scelerisque quam ornare mattis venenatis. Donec mi quam, venenatis et pulvinar gravida, vehicula vel elit. Nunc ut pellentesque velit. Aliquam sed quam velit. Phasellus id gravida nunc.\n"
            + "\n"
            + "Phasellus auctor dui quis lobortis rutrum. Donec orci dui, volutpat eget feugiat tempus, porttitor lobortis urna. Proin placerat, elit nec fermentum venenatis, tortor quam pretium ex, sed tempor mi enim quis enim. Morbi at neque mauris. Aliquam erat volutpat. Aliquam porttitor tortor nisi, vitae egestas tortor tincidunt vitae. Nulla in blandit mauris. Praesent nec augue semper, fermentum diam non, imperdiet erat. Integer commodo aliquam mauris id tempus. Etiam egestas ex et efficitur molestie. Suspendisse a lorem a tellus dapibus posuere. Sed vestibulum, magna volutpat convallis consectetur, sem nulla tincidunt neque, et suscipit augue leo eget lorem. In venenatis odio quis convallis iaculis. Etiam in sem lacus. Donec imperdiet tempus mi et tempus. Nulla et rhoncus felis.\n"
            + "\n"
            + "Pellentesque dolor ipsum, fringilla nec metus ac, lacinia gravida eros. Integer accumsan metus at mi tempus, eu dapibus dui commodo. Proin eleifend commodo eleifend. Phasellus vehicula nibh gravida neque aliquam semper. Nunc maximus pellentesque turpis non tincidunt. Proin dignissim odio porttitor justo facilisis, sit amet rhoncus mi egestas. In hac habitasse platea dictumst. Pellentesque nibh est, dignissim quis lorem in, rutrum fermentum lacus. Duis feugiat lobortis eros eget commodo. Nullam diam dui, efficitur sed ultrices eu, fringilla ac risus. Nulla facilisi. Pellentesque dignissim ex ligula.\n"
            + "\n"
            + "Proin venenatis porta iaculis. Etiam quam massa, sollicitudin semper convallis eu, ultrices vel lectus. Curabitur vel lorem et erat accumsan gravida ac ut urna. Vestibulum porttitor, arcu a pellentesque porta, nulla justo bibendum nibh, vel varius enim felis ac eros. Integer eget purus a magna laoreet tempus ac elementum nisi. Donec id urna vel dolor placerat ultrices vitae et nibh. Pellentesque ultrices quam fringilla molestie cursus. Morbi eleifend mi sed posuere iaculis. Etiam tempus, sapien sit amet suscipit vehicula, risus ipsum accumsan leo, nec euismod est tellus mollis nisl. Fusce efficitur nunc leo, ut congue nisl bibendum at. Aliquam consectetur, est in faucibus volutpat, nisl ante feugiat neque, luctus condimentum elit nisi sed massa. Suspendisse ac commodo augue, ullamcorper malesuada lorem. Vestibulum mollis erat sit amet pretium efficitur.\n"
            + "\n"
            + "Donec ornare, neque a eleifend elementum, velit risus viverra nunc, eu dignissim tellus ante nec sapien. Suspendisse non consectetur erat. Donec ante velit, porta ut nunc ultrices, congue iaculis risus. Donec efficitur nunc accumsan mauris luctus, ac porta odio feugiat. Pellentesque vehicula erat gravida odio malesuada, nec condimentum libero venenatis. Donec vel metus neque. Etiam id lacus ullamcorper, volutpat sem ac, tincidunt ante. Nunc vestibulum imperdiet pharetra. Aenean pretium quam quis mi scelerisque, sed varius justo maximus.\n"
            + "\n"
            + "Praesent bibendum viverra pretium. Vestibulum tincidunt eu velit id auctor. Aenean ipsum nisl, mattis sit amet mauris vel, placerat gravida ex. Praesent laoreet sem eu tortor elementum, a egestas felis efficitur. Aenean sed est sit amet nulla varius aliquam. Vivamus tincidunt odio turpis. Suspendisse vitae suscipit quam, id tincidunt nisl. Donec mi ex, fermentum ac tristique non, ultricies non risus. Aenean euismod arcu in turpis efficitur consequat.\n"
            + "\n"
            + "Nunc consequat metus ac euismod varius. Suspendisse aliquam elit et enim venenatis, vel placerat nibh dictum. In at nunc a purus scelerisque pretium. Fusce ut risus ut massa luctus vestibulum sed.";

    // @defect - https://byjustech.atlassian.net/browse/WFM-144
    // @Author = Ankur
    // @Description = fill form
    public HashMap<String, String> fillForm(Boolean val) throws InterruptedException {

        setDropdownValue("Category", "Digital Finance-UAT");

        // defect - https://byjustech.atlassian.net/browse/WFM-203
        // driver.navigate().back();
        // driver.navigate().forward();
        // assertTrue(getDropdownValue("Category", "Select Category");

        setDropdownValue("Sub Category", "");

        if (getDropdownValue("Sub Category").equals("Digital Finance")) {

            setDropdownValue("Digital Finance Types", "");
            data.put("Issue Type", data.get("Digital Finance Types"));

            if (getDropdownValue("Digital Finance Types").equals("Loan Verfication")) {

                setDropdownValue("Loan Verification Types", "");
                data.put("Issue Sub Type", data.get("Loan Verification Types"));

                if (getDropdownValue("Loan Verification Types").equals("New Email")) {

                    setDropdownValue("Priority", "");
                    setInputField("Order ID", "Test");
                } else if (getDropdownValue("Loan Verification Types").equals("New Ticket")) {

                    setDropdownValue("Priority", "");
                }

                setDropdownValue("Associate", "");
            } else if (getDropdownValue("Digital Finance Types").equals("Customer Grievance")) {

                setInputField("Name of the Student", "Test");
                setDropdownValue("Language Preference", "");
                setInputField("Application ID", "Test");

                setDropdownValue("Ticket Source", "");
                data.put("Issue Sub Type", data.get("Ticket Source"));

                setInputField("Order ID", "Test");
                setDropdownValue("Lender", "");
                setDropdownValue("QRC Type", "");

                if (getDropdownValue("QRC Type").equals("Complaint")) {

                    setDropdownValue("Complaint Issue Type", "");

                    if (getDropdownValue("Complaint Issue Type").equals("Repayment & Collection Team Assistance")) {

                        setDropdownValue("Repayment & Collection team Assistance-Complaint", "");
                    } else if (getDropdownValue("Complaint Issue Type").equals("Other Finance Issues")) {

                        setDropdownValue("Other finance issues-Complaint", "");
                    }
                } else if (getDropdownValue("QRC Type").equals("Query")) {

                    setDropdownValue("Query Issue Type", "");

                    if (getDropdownValue("Query Issue Type").equals("EMI Details")) {

                        setDropdownValue("EMI Details Issues", "");
                    } else if (getDropdownValue("Query Issue Type").equals("EMI Payment Issue")) {

                        setDropdownValue("EMI Payment Issue - Query", "");
                    } else if (getDropdownValue("Query Issue Type").equals("Other Finance Issues")) {

                        setDropdownValue("Other finance issues - Query", "");
                    }
                } else if (getDropdownValue("QRC Type").equals("Request")) {

                    setDropdownValue("Request Issue Type", "");

                    if (getDropdownValue("Request Issue Type").equals("Loan Documents")) {

                        setDropdownValue("Loan Documents - Request", "");
                    } else if (getDropdownValue("Request Issue Type")
                            .equals("Repayment & Collection Team Assistance")) {

                        setDropdownValue("Repayment & Collection team Assistance - Request", "");
                    } else if (getDropdownValue("Request Issue Type").equals("EMI Payment Issue")) {

                        setDropdownValue("EMI Payment Issue - Request", "");
                    } else if (getDropdownValue("Request Issue Type").equals("Other Finance Issues")) {

                        setDropdownValue("Other finance issues - Request", "");
                    }
                }

                setDropdownValue("Priority", "");
            } else if (getDropdownValue("Digital Finance Types").equals("NACH Ops")) {

                setDropdownValue("Ticket Source", "");
                data.put("Issue Sub Type", data.get("Ticket Source"));

                setDropdownValue("Priority", "");
            }
        } else if (getDropdownValue("Sub Category").equals("Loan Verification-CB Request")) {

            setDropdownValue("Request Type", "");
            data.put("Issue Type", data.get("Request Type"));

            if (getDropdownValue("Request Type").equals("Callback Request")) {

                setInputField("Order-ID", "Test");

                setDropdownValue("Team Heads", "");
                data.put("Issue Sub Type", data.get("Team Heads"));

                setDate("Call back Date", "");
                setDropdownValue("Call back Time slot", "");
            } else if (getDropdownValue("Request Type").equals("DP Reconciled")) {

                setInputField("Order-ID", "Test");

                setDropdownValue("Team Heads", "");
                data.put("Issue Sub Type", data.get("Team Heads"));

                setDropdownValue("MOP Status", "");
            }
        }

        setInputField("Customer Name", "Test");

        // defect - https://byjustech.atlassian.net/browse/WFM-355
        setInputField("Customer Email", "test@byjus.com");

        setInputField("Subject", "Test");
        setTextboxValue("Description", "Test");

        // defect - https://byjustech.atlassian.net/browse/WFM-263
        // setTextboxValue("Description", description);

        if (val) {
            // defect - https://byjustech.atlassian.net/browse/WFM-146
            wait.ignoring(StaleElementReferenceException.class)
                    .until(ExpectedConditions.visibilityOfElementLocated(By.xpath(createButtonXpath))).click();
            try {
                wait.ignoring(StaleElementReferenceException.class).until(
                        ExpectedConditions.visibilityOfElementLocated(By.xpath(successFulTestCreationMessageXpath)));
            } catch (Exception e) {
                wait.ignoring(StaleElementReferenceException.class).until(
                        ExpectedConditions.visibilityOfElementLocated(By.xpath(successFulTestCreationMessageXpath)));
            }

            String ticketId = driver.findElement(By.xpath(successFulTestCreationMessageXpath)).getText().split(" ")[3];
            data.put("ticketId", ticketId);

            System.out.println(ticketId);

            wait.ignoring(StaleElementReferenceException.class)
                    .until(ExpectedConditions.visibilityOfElementLocated(By.xpath(closeModalButtonXpath)));
            Thread.sleep(1000);
            driver.findElement(By.xpath(closeModalButtonXpath)).click();
        }
        return data;
    }

    // @Author = Ankur
    // @Description = set dropdown value
    public void setDropdownValue(String label, String value) {

        // if value is empty string then select random option from dropdown

        By e = By.xpath("//div[text()='" + label + "']/parent::div/parent::div//div[@class='dropdown__selectedLabel']");

//        try {
//            jsClick(driver.findElement(e));
//        }
//        catch(Exception t){
//            wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(e)).click();
//        }

        try {

            wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(e))
                    .click();
        } catch (Exception t) {

            jsClick(driver.findElement(e));
        }

        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions
                .visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='dropdown__dropdownOption']")));
        List<WebElement> options = driver.findElements(By.xpath("//div[@class='dropdown__dropdownOption']"));

//        if(value.equals(""))
//             value = options.get(new Random().nextInt(options.size())).getAttribute("innerHTML");
//        
//        
//        try {
//            
//            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dropdown__dropdownOption' and text()='" + value + "']"))).click();
//            
//        }
//        catch (StaleElementReferenceException e2) {
//            
//            wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(e)).click();
//            wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(e)).click();
//            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dropdown__dropdownOption' and text()='" + value + "']"))).click();
//        }

        if (value.equals(""))
            value = options.get(new Random().nextInt(options.size())).getText();

        try {

            for (int i = 0; i < options.size(); ++i) {
                if (options.get(i).getText().equals(value)) {
                    options.get(i).click();
                    break;
                }
            }
        } catch (StaleElementReferenceException e1) {

            wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions
                    .visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='dropdown__dropdownOption']")));
            options = driver.findElements(By.xpath("//div[@class='dropdown__dropdownOption']"));

            for (int i = 0; i < options.size(); ++i) {
                if (options.get(i).getText().equals(value)) {
                    options.get(i).click();
                    break;
                }
            }
        }

        System.out.println(label + " :\t" + value);
        data.put(label, value);
    }

    public void jsClick(WebElement el) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].click();", el);
            System.out.println("Element clicked");
        } catch (Exception e) {
            System.out.println("=============================================================");
            System.out.println("Exception-jsClick(): " + e.getMessage());
            // takeScreenShot();
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }

    // @Author = Ankur
    // @Description = get dropdown value
    public String getDropdownValue(String label) {

        By e = By.xpath("//div[text()='" + label + "']/parent::div/parent::div//div[@class='dropdown__selectedLabel']");

        return wait.ignoring(StaleElementReferenceException.class)
                .until(ExpectedConditions.visibilityOfElementLocated(e)).getText();
    }

    // @Author = Ankur
    // @Description = set input field
    public void setInputField(String label, String value) {

        By e = By.xpath("//div[text()='" + label + "']/parent::div/parent::div//input");

        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(e))
                .sendKeys(value);

        System.out.println(label + " :\t" + value);
        data.put(label, value);
    }

    // @Author = Ankur
    // @Description = get input field value
    public String getInputField(String label) {

        By e = By.xpath("//div[text()='" + label + "']/parent::div/parent::div//input");

        return wait.ignoring(StaleElementReferenceException.class)
                .until(ExpectedConditions.visibilityOfElementLocated(e)).getAttribute("value");
    }

    // @Author = Ankur
    // @Descriptioin = set textbox value
    public void setTextboxValue(String label, String value) {
        driver.switchTo().frame(0);

        By e = By.xpath("//p");
//        By e = By.xpath("//div[@class='ql-editor ql-blank']//p");

        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(e))
                .sendKeys(value);

        // defect - https://byjustech.atlassian.net/browse/WFM-312
        // driver.findElement(e).sendKeys(Keys.COMMAND + "A");
        // driver.findElement(e).sendKeys(Keys.COMMAND + "X");

        // defect - https://byjustech.atlassian.net/browse/WFM-148
        // assertTrue(!driver.findElement(By.xpath("//button[text()='Create']")).isEnabled());

        // driver.findElement(e).sendKeys(Keys.COMMAND + "V");

        // defect - https://byjustech.atlassian.net/browse/WFM-145
        // add attachments
        // driver.findElement(By.xpath(".//input[@type='file']")).sendKeys("//src//main//java//testcasesResources//fileUnder5.jpeg");

        System.out.println(label + " :\t" + value);
        data.put(label, value);
        driver.switchTo().defaultContent();
    }

    // @Author = Ankur
    // @Description = set data
    public void setDate(String label, String value) {

        By e = By.xpath("//div[text()='" + label + "']/parent::div/parent::div//input");
        try {
            jsClick(driver.findElement(e));
        } catch (Exception d) {
            wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(e))
                    .click();
        }
        wait.ignoring(StaleElementReferenceException.class)
                .until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@aria-current='date']"))).click();
        value = convertDate(getInputField(label));

        System.out.println(label + " :\t" + value);
        data.put(label, value);
    }

    // @Author = Ankur
    // @Description = convert date
    public String convertDate(String date) {

        HashMap<String, String> month = new HashMap<>();
        month.put("01", "Jan");
        month.put("02", "Feb");
        month.put("03", "Mar");
        month.put("04", "Apr");
        month.put("05", "May");
        month.put("06", "Jun");
        month.put("07", "Jul");
        month.put("08", "Aug");
        month.put("09", "Sep");
        month.put("10", "Oct");
        month.put("11", "Nov");
        month.put("12", "Dec");

        String dd = date.substring(0, 2);
        String mm = date.substring(3, 5);
        String yy = date.substring(6);

        String newDate = dd + "-" + month.get(mm) + "-" + yy;

        return newDate;
    }

    // @Author = Ankur
    // @Description = wait for seconds
    public void waitForSeconds(int time) {

        try {

            Thread.sleep(time * 1000);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }
}
