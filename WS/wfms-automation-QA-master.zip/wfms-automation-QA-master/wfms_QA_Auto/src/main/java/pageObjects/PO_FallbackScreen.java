package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PO_FallbackScreen {
    
    WebDriver driver;
    
    // constructor
    public PO_FallbackScreen(WebDriver driver) {
        
        this.driver = driver;
    }
    
    private String badRequestFallbackScreenMessageXpath = "//div[@class='fallback-ui']//div[contains(@class,'message')]";
    private String badRequestFallbackScreenImageXpath = "//div[@class='fallback-ui']//img";
    
    // @Author = Ankur
    // verify Bad Request Fallback Screen UI
    public String verifyBadRequestFallbackScreenUI() {
        
        if(!getAttributeValue(By.xpath(badRequestFallbackScreenImageXpath), "src").toLowerCase().contains("fallback"))
            return "error in bad request fllback screen - image";
        
        if(!getText(By.xpath(badRequestFallbackScreenMessageXpath)).equalsIgnoreCase("We can't find the page you're looking for"))
            return "error in bad request fllback screen - message text";
        
        return "";
    }
    
    // @Author = Ankur
    // get text in an element
    public String getText(By e) {
        
        return new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(e)).getText();
    }
    
    // @Author = Ankur
    // get attribute value of an element
    public String getAttributeValue(By e, String attributeName) {
        
        return new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(e)).getAttribute(attributeName);
    }    
}
