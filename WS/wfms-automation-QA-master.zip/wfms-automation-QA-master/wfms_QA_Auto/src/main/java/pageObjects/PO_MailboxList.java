package pageObjects;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PO_MailboxList {
    WebDriver driver;
    
    // header section
    private By headerText = By.className("header__left-section");
    private By createBtn = By.xpath("//button[contains(text(),'CREATE')]");
    private By searchBar = By.xpath("//div[@data-testid='search-bar']");
    private By searchBarInput = By.xpath("//input[@data-testid='search-bar-input']");
    
    // left side hamburger menu
    private By casesIcon = By.xpath("//div[@class='menuItems-Wrapper']//div[text()='Cases']");
    private By groupsIcon = By.xpath("//div[@class='menuItems-Wrapper']//div[text()='Groups']");
    private By agentsIcon = By.xpath("//div[@class='menuItems-Wrapper']//div[text()='Agents']");
    private By mailboxIcon = By.xpath("//div[contains(@class,'menuItems-Wrapper')]//div[text()='Mailbox']");
    private By logoutIcon = By.xpath("//div[@class='menuItems-Wrapper']//div[text()='Logout']");
    
    // mailbox list container header
    private By rightPaginationButton = By.xpath("//button[contains(@class,'button_right_icon')]");
    private By leftPaginationButton = By.xpath("//button[contains(@class,'button_left_icon')]");
    private By headerNameText = By.xpath("//div[@class='mailboxList__container__card__header mailboxList__container__card__common']//div[contains(text(),'Name')]");
    private By headerEmailText = By.xpath("//div[@class='mailboxList__container__card__header mailboxList__container__card__common']//div[contains(text(),'E-mail address')]");
    private By headerGroupText = By.xpath("//div[@class='mailboxList__container__card__header mailboxList__container__card__common']//div[contains(text(),'Group')]");
    
    // mailbox list container
    private By mailboxListItem = By.xpath("//div[@class='mailboxList__container__card__item mailboxList__container__card__common']");
    private By itemName = By.xpath("descendant::div[contains(@class,'name')]");
    private By itemEmail = By.xpath("descendant::div[contains(@class,'email')]");
    private By itemGroup = By.xpath("descendant::div[contains(@class,'group')]");
    private By itemEditIcon = By.xpath("descendant::img[contains(@alt,'Edit')]");
    private By itemDeleteIcon = By.xpath("descendant::img[contains(@alt,'Delete')]");
    
    // popup after mailbox is created
    private By closeBtn = By.xpath("//img[@class='button__icon--style']");
    private By createdSuccessfullyMessage = By.xpath("//div[@class='modal-ui_message']");
    private By deleteBtn = By.xpath("//button[contains(text(),'Delete')]");
    
    public PO_MailboxList(WebDriver driver) {
        super();
        this.driver = driver;
    }
    
    // ------------------------------------------------------------------------------------------------ 
    // Gaurang Methods
    // ------------------------------------------------------------------------------------------------
    
    //@Author : Gaurang
    // goto specific url
    public void goToUrl(String url) {
        driver.get(url);
    }

    //@Author : Gaurang
    // get header text
    public String getHeaderText() {
        visibleText(headerText);
        return driver.findElement(headerText).getText();
    }

    //@Author : Gaurang
    // get create button text
    public String getCreateBtn() {
        visibleText(createBtn);
        return driver.findElement(createBtn).getText();
    }

    //@Author : Gaurang
    // get case icon text
    public String getCasesIcon() {
        visibleText(casesIcon);
        return driver.findElement(casesIcon).getText();
    }
    
    //@Author : Gaurang
    // get groups icon text
    public String getGroupsIcon() {
        visibleText(groupsIcon);
        return driver.findElement(groupsIcon).getText();
    }
    
    //@Author : Gaurang
    // get agents icon text
    public String getAgentsIcon() {
        visibleText(agentsIcon);
        return driver.findElement(agentsIcon).getText();
    }

    //@Author : Gaurang
    // get mailbox icon text
    public String getMailboxIcon() {
        visibleText(mailboxIcon);
        return driver.findElement(mailboxIcon).getText();
    }

    //@Author : Gaurang
    // get logout icon text
    public String getLogoutIcon() {
        visibleText(logoutIcon);
        return driver.findElement(logoutIcon).getText();
    }

    //@Author : Gaurang
    // get header name text
    public String getHeaderNameText() {
        visibleText(headerNameText);
        return driver.findElement(headerNameText).getText();
    }

    //@Author : Gaurang
    // get header email text
    public String getHeaderEmailText() {
        visibleText(headerEmailText);
        return driver.findElement(headerEmailText).getText();
    }

    //@Author : Gaurang
    // get header group text
    public String getHeaderGroupText() {
        visibleText(headerGroupText);
        return driver.findElement(headerGroupText).getText();
    }
    
    //@Author : Gaurang
    // check if the edit icon button is clickable
    public Boolean checkCLickableItemEditIcon() {
        visibleText(mailboxListItem);
        List<WebElement> parent = driver.findElements(mailboxListItem);
        parent.forEach(ele -> {
            clickable(ele.findElement(itemEditIcon));
        });
        return true;
    }

    //@Author : Gaurang
    // check if the delete icon button is clickable
    public Boolean checkCLickableItemDeleteIcon() {
        visibleText(mailboxListItem);
        List<WebElement> parent = driver.findElements(mailboxListItem);
        parent.forEach(ele -> {
            clickable(ele.findElement(itemDeleteIcon));
        });
        return true;
    }
    
    //@Author : Gaurang
    // check if the search bar is clickable
    public Boolean checkCLickableSearchBar() {
        clickable(searchBar);
        return true;
    }
    
    //@Author : Gaurang
    // check if the search bar input is clickable
    public Boolean checkCLickableSearchBarInput() {
        driver.findElement(searchBar).click();
        clickable(searchBarInput);
        return true;
    }
    
    //@Author : Gaurang
    // refresh the page
    public void refreshPage() {
        driver.navigate().refresh();
    }
    
    //@Author : Gaurang
    // goto mailbox list screen
    public void goToMailboxScreen() {
        clickable(mailboxIcon);
        driver.findElement(mailboxIcon).click();
    }
    
    //@Author : Gaurang
    // check if the left pagination button is enabled
    public Boolean leftPaginationIsEnabled() {
        return driver.findElement(leftPaginationButton).isEnabled();
    }
    
    //@Author : Gaurang
    // check for unique email validation
    public boolean checkEmailUnique() {
        int totalMailbox = 0;
        List<WebElement> parent = new ArrayList<>();
        HashSet<String> emails = new HashSet<>();
        do{
            visibleText(mailboxListItem);
            parent = driver.findElements(mailboxListItem);
            totalMailbox += parent.size();
            for(int i=0; i<parent.size(); i++) {
                emails.add(parent.get(i).findElement(itemEmail).getText());
            }
            if(driver.findElement(rightPaginationButton).isEnabled()) {
                driver.findElement(rightPaginationButton).click();
            }
            else {
                break;
            }
        }while(true);
        
        
        return (emails.size() == totalMailbox) ? true : false;
    }
    
    //@Author : Gaurang
    // delete a specific mailbox from the list
    public void deleteMailbox(HashMap<String, String> mailbox) {
        List<WebElement> parent = new ArrayList<>();
        boolean deleted = false;
        do {
            visibleText(mailboxListItem);
            parent = driver.findElements(mailboxListItem);
            for (int i = 0; i < parent.size(); i++) {
                String email = parent.get(i).findElement(itemEmail).getText();
                String name = parent.get(i).findElement(itemName).getText();
                String group = parent.get(i).findElement(itemGroup).getText();
                if (email.compareTo(mailbox.get("email")) == 0 &&
                        name.compareTo(mailbox.get("name")) == 0 &&
                        group.compareTo(mailbox.get("group")) == 0) {
                    clickable(itemDeleteIcon);
                    parent.get(i).findElement(itemDeleteIcon).click();
                    visibleText(deleteBtn);
                    clickable(deleteBtn);
                    driver.findElement(deleteBtn).click();
                    visibleText(createdSuccessfullyMessage);
                    mailbox.put("deleteMessage", driver.findElement(createdSuccessfullyMessage).getText());
                    visibleText(closeBtn);
                    clickable(closeBtn);
                    jsClick(driver.findElement(closeBtn));
                    deleted = true;
                    break;
                }
            }
            if (driver.findElement(rightPaginationButton).isEnabled() && !deleted) {
                driver.findElement(rightPaginationButton).click();
            } else {
                break;
            }
        } while (true);
    }
    
    //@Author : Gaurang
    // check for a specific mailbox from the list
    public Boolean checkSpecificMailbox(HashMap<String, String> mailbox) {
        List<WebElement> parent = new ArrayList<>();
        do {
            visibleText(mailboxListItem);
            parent = driver.findElements(mailboxListItem);
            for (int i = 0; i < parent.size(); i++) {
                String email = parent.get(i).findElement(itemEmail).getText();
                String name = parent.get(i).findElement(itemName).getText();
                String group = parent.get(i).findElement(itemGroup).getText();
                if (email.compareTo(mailbox.get("email")) == 0 &&
                        name.compareTo(mailbox.get("name")) == 0 &&
                        group.compareTo(mailbox.get("group")) == 0) {
                    return true;
                }
            }
            if (driver.findElement(rightPaginationButton).isEnabled()) {
                driver.findElement(rightPaginationButton).click();
            } else {
                break;
            }
        } while (true);
        return false;
    }
    
    // ------------------------------------------------------------------------------------------------
    
    public boolean visibleText(By element)
    {
        WebDriverWait wait= new WebDriverWait(driver, 10);
        
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));
        return false;
    }
    
    public boolean clickable(By element)
    {
        WebDriverWait wait= new WebDriverWait(driver, 10);
        
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));
        
        return false;
    }

    public boolean clickable(WebElement element)
    {
        WebDriverWait wait= new WebDriverWait(driver, 10);
        
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));
        
        return false;
    }
    public void jsClick(WebElement el) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].click();", el);
        } catch (Exception e) {
            System.out.println("=============================================================");
            System.out.println("Exception-jsClick(): " + e.getMessage());
            //takeScreenShot();
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }
}
