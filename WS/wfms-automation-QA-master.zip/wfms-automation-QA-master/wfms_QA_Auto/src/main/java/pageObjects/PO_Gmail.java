package pageObjects;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PO_Gmail {

    public WebDriver driver;
    public WebDriverWait wait;

    // xpaths
    private By composeBtnXpath = By.xpath("//div[text()='Compose']");
    private By emailInput = By.xpath("//input[@type='email']");
    private By passwordInput = By.xpath("//input[@type='password']");
    private By nextBtn = By.xpath("//span[text()='Next']");
    private By subjectInput = By.xpath("//input[@name='subjectbox']");
    private By emailBodyInput = By.xpath("//div[@aria-label='Message Body']");
    private By mailBody = By.xpath("//center[contains(.,'Unsubscribe')]//parent::div");

    // constructor
    public PO_Gmail(WebDriver driver) {
        super();
        this.driver = driver;
    }

    // Author = Gaurang
    // Description = initialize gmail environment
    public void setupGmailEnvironment(String email, String password) {

        // open gmail in new tab
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript(
                "window.open('https://accounts.google.com/v3/signin/identifier?dsh=S386029718%3A1684910364786191&authuser=0&continue=https%3A%2F%2Fmail.google.com&ec=GAlAFw&hl=en&service=mail&flowName=GlifWebSignIn&flowEntry=AddSession', '_blank');");

        // switch to newly opened tab
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));

        // login to gmail
        visibleText(emailInput);
        driver.findElement(emailInput).sendKeys(email);
        visibleText(nextBtn);
        driver.findElement(nextBtn).click();
        visibleText(passwordInput);
        driver.findElement(passwordInput).sendKeys(password);
        driver.findElement(nextBtn).click();

        // wait for gmail screen to appear
        visibleText(composeBtnXpath);
    }

    public String composeNewEmail(String mailId) throws InterruptedException {

        // Compose a new email
        visibleText(composeBtnXpath);
        driver.findElement(composeBtnXpath).click();

        // Fill in the recipient email address
        visibleText(By.xpath("//input[@peoplekit-id='BbVjBd']"));
        driver.findElement(By.xpath("//input[@peoplekit-id='BbVjBd']"))
                .sendKeys(Keys.chord(mailId, Keys.RETURN));
        Thread.sleep(500);

        addSubject();
        String bodyContent = addDescription();

        // Send the email
        driver.findElement(By.xpath("//div[text()='Send']")).click();

        visibleText(By.xpath("//span[text()='Message sent']"));
        return bodyContent;
    }

    // @Author = Gaurang
    // @Description = Add subject
    public void addSubject() throws InterruptedException {
        visibleText(subjectInput);
        driver.findElement(subjectInput).sendKeys("This is the subject");
        Thread.sleep(500);
    }

    // @Author = Gaurang
    // @Description = Add description
    public String addDescription() throws InterruptedException {
        visibleText(emailBodyInput);
        driver.findElement(emailBodyInput)
                .sendKeys(Keys.chord("This is the email body for automation script", Keys.RETURN));
        Thread.sleep(500);

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript(
                "window.open('https://docs.google.com/spreadsheets/d/1-ZY5r79hBe6vgXEvFZLqBp3hzJTXs6mH/edit#gid=957364889', '_blank');");
        Thread.sleep(2000);

        // switch to newly opened tab
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(2));

        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(By.xpath("//div[@class='goog-inline-block fixed4-inner-container']")))
                .click().keyDown(Keys.COMMAND).sendKeys("c").build().perform();

        tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));

        actions.moveToElement(driver.findElement(emailBodyInput)).click().keyDown(Keys.COMMAND).sendKeys("v").build()
                .perform();
        System.out.println(driver.findElement(emailBodyInput).getText());
        System.out.println("---------------------------------------");
        return driver.findElement(emailBodyInput).getText();
    }

    public void applyFilter(String mailId) {
        driver.findElement(By.xpath("//input[@aria-label='Search in mail']"))
                .sendKeys("is:unread from:(" + mailId + ") ");
        driver.findElement(By.xpath("//input[@aria-label='Search in mail']")).sendKeys(Keys.RETURN);
    }

    public void openEmail(String mailId) throws InterruptedException {
        for (int i = 0; i < 60; i++) {
            try {
                jsClick(driver.findElement(By.xpath("//*[@class='zA zE']//span[text()='" + mailId.split("@")[0] + "']")));
                return;
            } catch (Exception e) {
                driver.get(driver.getCurrentUrl());
                Thread.sleep(10000);
            }
        }
    }
    
    public String getTicketIdFromEmail() {
        visibleText(mailBody);
        System.out.println(driver.findElement(mailBody).getText());
        System.out.println(driver.findElement(mailBody).getText().split("#")[1]);
        System.out.println(driver.findElement(mailBody).getText().split("#")[1].split(" ")[0]);
        String ticketId = driver.findElement(mailBody).getText().split("#")[1].split(" ")[0];
        ticketId = ticketId.substring(1, ticketId.length()-2);
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(0));
        return ticketId;
    }

    // ------------------------------------------------------------------------------------------------

    public boolean visibleText(By element) {
        WebDriverWait wait = new WebDriverWait(driver, 10);

        wait.ignoring(StaleElementReferenceException.class)
                .until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));

        return false;
    }
    
    public void jsClick(WebElement el) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].click();", el);
        } catch (Exception e) {
            System.out.println("=============================================================");
            System.out.println("Exception-jsClick(): " + e.getMessage());
            //takeScreenShot();
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }
}
