package pageObjects;

import java.util.HashMap;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class PO_CreateCaseHR extends PO_CreateCaseDigitalFinance {

    public PO_CreateCaseHR(WebDriver driver) {
        super(driver);
    }
    
    // @Author = Ankur
    // @Description = fill form
    public HashMap<String, String> fillForm() throws InterruptedException {
        
        setDropdownValue("Category", "HR-UAT");
        
        setDropdownValue("Sub Category", "");
        
        if(getDropdownValue("Sub Category").equals("Employee Assets ")) {
            
            setDropdownValue("Folder", "");
            
            setDropdownValue("Category", 2, "");
            
            setInputField("Priority", "Test");
        }
        
        setInputField("Customer Name", "Test");
        setInputField("Customer Email", "test@byjus.com");
        setInputField("Subject", "Test");
        setTextboxValue("Description", "Test");
        
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(createButtonXpath))).click();
        
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(successFulTestCreationMessageXpath)));
        
        String ticketId = driver.findElement(By.xpath(successFulTestCreationMessageXpath)).getText().split(" ")[3];
        data.put("ticketId", ticketId);
        
        System.out.println(ticketId);
        
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(closeModalButtonXpath)));
        Thread.sleep(1000);
        driver.findElement(By.xpath(closeModalButtonXpath)).click();
        
        return data;
    }
    
    // @Author = Ankur
    // @Description = set dropdown value
    public void setDropdownValue(String label, int index, String value) {
        
        By e = By.xpath("//(div[text()='" + label + "'])[" + index + "]/parent::div/parent::div//div[@class='dropdown__selectedLabel']");
        
        try {
            
            wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(e)).click();
        }
        catch(Exception t){
            
            jsClick(driver.findElement(e));
        }
        
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='dropdown__dropdownOption']")));
        List<WebElement> options = driver.findElements(By.xpath("//div[@class='dropdown__dropdownOption']"));
        
        if(value.equals(""))
            value = options.get(new Random().nextInt(options.size())).getText();
        
        try {
            
            for(int i = 0; i < options.size(); ++i) {
                if(options.get(i).getText().equals(value)) {
                    options.get(i).click();
                    break;
                }
            }
        }
        catch(StaleElementReferenceException e1) {
            
            wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='dropdown__dropdownOption']")));
            options = driver.findElements(By.xpath("//div[@class='dropdown__dropdownOption']"));
            
            for(int i = 0; i < options.size(); ++i) {
                if(options.get(i).getText().equals(value)) {
                    options.get(i).click();
                    break;
                }
            }
        }
        
        System.out.println(label + " :\t" + value);
        data.put(label, value);
    }
    

}
