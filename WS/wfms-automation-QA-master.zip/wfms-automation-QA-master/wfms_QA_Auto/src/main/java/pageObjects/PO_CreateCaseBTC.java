package pageObjects;

import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PO_CreateCaseBTC {
    
    public WebDriver driver;
    public WebDriverWait wait;
    
    public PO_CreateCaseBTC(WebDriver driver) {
        
        this.driver = driver;
        wait = new WebDriverWait(driver, 10);
    }
    
    
    // relative xpath
    //private String ltd = "/parent::div/parent::div//div[@class='dropdown__selectedLabel']"; // label to dropdown selected option
    //private String lti = "/parent::div/parent::div//input"; // label to input field
    //private String ltt = "/parent::div/parent::div//p"; // label to textbox
    
    
    // @Author = Ankur
    // @Description = Fill form 
    public void fillForm() throws InterruptedException {
        
        String subCategory = "Byjus Tuition Center - BTC";
        setDropdownValue("Sub Category", subCategory);
        
        String city = "Aagra";
        setDropdownValue("City - BTC", city);
        
        String area = "Kargil";
        setDropdownValue(city + " - BTC", area);
        
        String issueType = "Academic";
        setDropdownValue("Issue Type - BTC", issueType);
        
        if(issueType.equals("Academic")) {
            
            String userContactNumber = "9999999999";
            setInputFieldValue("User Contact Number", userContactNumber);
            
            String ticketType = "Query";
            setDropdownValue("Ticket Type", ticketType);
            
            String issueCategoryAcademics = "Batch Merge";
            setDropdownValue("Issue Category Academics - BTC", issueCategoryAcademics);
            
            if(issueCategoryAcademics.equals("Batch Merge")) {
             
                setDate("Effective Date of Change - BTC", "");
            
                String reasonOfMerging = "Other";
                setDropdownValue("Reason of Merging - Batch Merge", reasonOfMerging);
            
                if(reasonOfMerging.equals("Other"))
                    setInputFieldValue("Specify Other - Reason of Merging BTC", "");
                
                setDropdownValue("From Grade of batch - Batch merge BTC", "");
                
                String fromBoardOfBatch = "Others";
                setDropdownValue("From Board of batch - Batch merge BTC", fromBoardOfBatch);
                
                if(fromBoardOfBatch.equals("Others"))
                    setInputFieldValue("Specify Others Board-BTC", "Test");
                    
                setDate("From Start date of Batch - Batch merge BTC", "");
                
                setTextboxFieldValue("From 3 Students PID - Batch merge BTC" , "Test");
                
                setDropdownValue("To Grade of batch - Batch merge BTC", "");
                
                String toBoardOfBatch = "Others";
                setDropdownValue("To Board of batch - Batch merge BTC", toBoardOfBatch);
                
                if(toBoardOfBatch.equals("Others"))
                    setInputFieldValue("Specify Others Board-BTC", "Test");
                
                setDate("To Start date of Batch - Batch merge BTC", "");
                
                setTextboxFieldValue("To 3 Students PID - Batch merge BTC", "");
            }
            else if(issueCategoryAcademics.equals("Operational Issue (Tute Portal)")) {
                
                setTextboxFieldValue("Details of classes not visible on the teachers' schedule -  Classes not visible BTC", "Test");
                
                String operationalIssueTutePortal = "Class not visible";
                setDropdownValue("Operational Issue Tute Portal" , operationalIssueTutePortal);
                
                if(operationalIssueTutePortal.equals("Class not visible")) {
                   
                    setDate("Date Class Not Visible On - BTC", "");
                }
            }
            else if(issueCategoryAcademics.equals("Content Issue")) {
                
                String contentIssue = "Assessment is wrong";
                setDropdownValue("Content Issue - BTC", contentIssue);
                
                if(contentIssue.equals("Assessment is Wrong") || contentIssue.equals("Slide Posted Is Wrong"))
                    setTextboxFieldValue("Please mention Slide/Assessment ID", "Test");
                
                setDropdownValue("Academic Subject", "Physics");
            }
            else if(issueCategoryAcademics.equals("Create a new Batch")) {
                
                setDropdownValue("Grade - BTC", "");
                
                String board = "Others";
                setDropdownValue("Board - BTC", board);
                
                if(board.equals("Others"))
                    setInputFieldValue("Specify Others Board-BTC", "Test");
                
                setDropdownValue("Batch Preferences - BTC", "Weekday Tutorial");
                setDate("Batch Enrolment Start Date - BTC", "");
                setDate("Class Start Date - BTC", "");
            }
            else if(issueCategoryAcademics.equals("Create a new Course")) {
                
                // pending *****************
                
            }
            else if(issueCategoryAcademics.equals("Faculty Absence")) {
                
            }
            else if(issueCategoryAcademics.equals("Timetable change")) {
                
            }
            else if(issueCategoryAcademics.equals("Curriculum Sequencing")) {
                
                
            }
        }
        else if(issueType.equals("Assessment")) {
            
        }
        else if(issueType.equals("IT/Technical")) {
            
            String technicalIssueCategory = "";
            setDropdownValue("Technical Issue Category", technicalIssueCategory);
            
            if(technicalIssueCategory.equals("Login Issue")) {
                
                String loginIssue = "";
                setDropdownValue("Login Issue", loginIssue);
                
                if(loginIssue.equals("Create Login")) {
                    
                    String createLoginFor = "";
                    setDropdownValue("Create Login For:", createLoginFor);
                    
                    if(createLoginFor.equals("Others"))
                        setInputFieldValue("Others - Please Specify", "Test");
                }
                else if(loginIssue.equals("Unable To Login")) {
                    
                    String unableToLoginTo = "";
                    setDropdownValue("Unable to login to", unableToLoginTo);
                    
                    if(unableToLoginTo.equals("Others"))
                        setInputFieldValue("Others - Please Specify", "Test");
                    
                    // tick the checkbox
                }
                
                setInputFieldValue("User Contact Number", "9999999999");
            }
            else if(technicalIssueCategory.equals("Tute Portal Issue")) {
                
                String tutePortalIssues = "";
                setDropdownValue("Tute Portal Issues", tutePortalIssues);
                
                if(tutePortalIssues.equals("Classes Are Not Reflecting On Portal")) {
                    
                    // tick the checkbox
                    
                    setDate("Date Class Not Visible On - BTC", "");
                }
                else if(tutePortalIssues.equals("Page Is Unresponsive") || tutePortalIssues.equals("Students Faces Not Visible")) {
                    
                    // tick the checkbox
                }
                else if(tutePortalIssues.equals("Issue With Poll Slides") || tutePortalIssues.equals("Scribling Is Not Reflecting At Student Side/Whiteboard")) {
                    
                    // tick the checkbox
                    
                    setInputFieldValue("Name of the Student", "Test");
                }
                else if(tutePortalIssues.equals("Students Unable To Hear Tutor") || tutePortalIssues.equals("Students Unable To See Tutor")) {
                    
                    setInputFieldValue("Name of the Student", "test");
                }
                
                setInputFieldValue("User Contact Number", "9999999999");
                setInputFieldValue("Class Session ID/URL", "test");
            }
            else if(technicalIssueCategory.equals("Network Issue")) {
                
                setDropdownValue("Network Issue", "Network Unstable");
                setInputFieldValue("User Contact Number", "9999999999");
                setDropdownValue("Type of Impact", "Complete Center Is Facing This Issue");
                
                String isClassAffected = "";
                setDropdownValue("Is this issue currently affecting the class?", isClassAffected);
                
                if(isClassAffected.equals("Yes"))
                    setInputFieldValue("Enter Channel ID/Class URL", "Test");
                
                setInputFieldValue("Please mention the URL you were trying to reach.", "Test");
            }
            else if(technicalIssueCategory.equals("Hardware Issue")) {
                
                String issue = "";
                setDropdownValue("Issue - Please Select", issue);
                
                if(issue.equals("Interactive Panel Issue") || issue.equals("Pentab Issue"))
                    // tick the checkbox
                
                setInputFieldValue("User Contact Number", "9999999999");
                
                String isClassAffected = "";
                setDropdownValue("Is this issue currently affecting the class?", isClassAffected);
                
                if(isClassAffected.equals("Yes"))
                    setInputFieldValue("Enter Channel ID/Class URL", "Test");
            }
            else if(technicalIssueCategory.equals("Tooljet")) {
                
                String tooljet = "";
                setDropdownValue("Tooljet - BTC", tooljet);
                
                if(tooljet.equals("Tooljet Login Creation")) {
                    
                    setInputFieldValue("Requestor's Email ID - BTC", "test@byjus.com");
                    // tick the checkbox
                }
                else if(tooljet.equals("Batch Not Found")) {
                    
                    setInputFieldValue("Batch name and ID", "Test");
                }
                else if(tooljet.equals("Student Name Not Found")) {
                    
                    setInputFieldValue("Student PID", "Test");
                }
                else if(tooljet.equals("Unable To Upload File")) {
                    
                    // tick the checkbox
                    
                    setInputFieldValue("File Name and Type", "Test");
                }
                else if(tooljet.equals("Unable To View File")) {
                    
                    setInputFieldValue("File Name", "Test");
                    setDate("Date of Upload", "");
                }
                else if(tooljet.equals("CC-Curriculum Sequencing Access")) {
                    
                    String role = "";
                    setDropdownValue("Role", role);
                    
                    if(role.equals("ZBH") || role.equals("RD"))
                        setTextboxFieldValue("Enter all the centers you will be looking after", "Test");
                }
                else if(technicalIssueCategory.equals("Lecture Audit")) {
                    
                    setInputFieldValue("Faculty Name", "Test");
                    setInputFieldValue("Faculty Email", "test@byjus.com");
                    setInputFieldValue("Lecture Topic", "Test");
                    setInputFieldValue("Grade", "Test");
                    setInputFieldValue("Channel ID", "Test");
                    setInputFieldValue("Lecture Recording Link", "Test");
                    
                    // pending **********************
                }
                
                setInputFieldValue("User Contact Number", "9999999999");
            }
            
            setDropdownValue("Ticket Type", "Query");
        }
        else if(issueType.equals("Platform Issues")) {
            
            String issueCategory = "Knowlarity";
            setDropdownValue("Platform Issues - Category", issueCategory);
            
            if(issueCategory.equals("Knowlarity")) {
                
                setDropdownValue("BTC - Knowlarity Vertical", "BTC - Knowlarity K10");
                
                String knowlarityIssue = "";
                setDropdownValue("Select Knowlarity Issue", knowlarityIssue);
                
                setInputFieldValue("LS Account Number", "Test");
                setInputFieldValue("Registered Phone Number", "9999999999");

                if(knowlarityIssue.equals("ISD Calling Issues")) {
                    
                    setInputFieldValue("ISD Number with Country Code", "91");
                }
                else if(knowlarityIssue.equals("Number Marked As Spam")) {
                    
                    setInputFieldValue("Spam number", "9999999999");
                }
                else if(knowlarityIssue.equals("Phone Number Change Request")) {
                    
                    setInputFieldValue("New Number", "9999999999");
                }
                else if(knowlarityIssue.equals("Knowlarity Reports Issue")) {
                    
                    setDate("Date of report", "");
                }
                else if(knowlarityIssue.equals("Voice-Breaking Issue")) {
                    
                    setTextboxFieldValue("Sample numbers", "");
                }
            }
            else if(issueCategory.equals("Lead Squared")) {
                
                String leadSquaredCategory = "Create Login";
                setDropdownValue("Lead Squared - Category", leadSquaredCategory);
                
                if(leadSquaredCategory.equals("Create Login")) {
                    
                    setInputFieldValue("Email ID", "Test");
                    setInputFieldValue("TNL ID", "Test");
                    setInputFieldValue("Reporting Manager", "Test");
                    setInputFieldValue("ABH", "Test");
                    setInputFieldValue("ZBH", "Test");
                }
                else if(leadSquaredCategory.equals("Unable To Access Lead Walk-In Form")) {
                    
                    setInputFieldValue("requestor's mail id", "Test");
                    // one thing is left here
                }
                else if(leadSquaredCategory.equals("Unable To See The Leads")) {
                    
                    setInputFieldValue("Lead Contact Number/ Lead Link", "Test");
                    
                    String leadSource = "";
                    setDropdownValue("Lead Source", leadSource);
                    
                    if(leadSource.equals("Others"))
                        setInputFieldValue("If others", "Test");
                    
                    setDropdownValue("requestor's mail id", "Test");
                }
                else if(leadSquaredCategory.equals("Unable To Punch Order")) {
                    
                    String categoryOfIssue = "";
                    setDropdownValue("Category of issue", categoryOfIssue);
                    
                    if(categoryOfIssue.equals("Others"))
                        setDropdownValue("If others", "Test");
                    
                    setInputFieldValue("Lead no. you are unable to punch", "Test");
                    setInputFieldValue("requestor's mail id", "");
                }
                else if(leadSquaredCategory.equals("Wrong Mapping Of Sales Team")) {
                    
                    setInputFieldValue("requestor's mail id", "Test");
                    setInputFieldValue("Manager's mail id", "Test");
                    setInputFieldValue("ABH", "Test");
                    setInputFieldValue("ZBH", "Test");
                }
                
                setDropdownValue("Ticket Type", "Query");
            }
            else if(issueCategory.equals("Salesforce")) {
                
                String salesforceCategory = "";
                setDropdownValue("Salesforce - Category", salesforceCategory);
                
                if(salesforceCategory.equals("Create Login (WIP)")) {
                    
                    setInputFieldValue("First Name", "Test");
                    setInputFieldValue("Last Name", "Test");
                    setInputFieldValue("Email ID", "test@byjus.com");
                    
                    String role = "";
                    setDropdownValue("Role", role);
                    
                    if(role.equals("ZBH") || role.equals("RD"))
                        setTextboxFieldValue("Enter all the centers you will be looking after", "Test");
                }
                else {
                    
                    setInputFieldValue("Impacted user email ID", "test@byjus.com");
                    setInputFieldValue("Sales Force URL", "test");
                    
                    // one thing is left here
                    
                    setDropdownValue("Mention ZBH Name", "Anand Kadache");
                }
                
                setDropdownValue("Ticket Type", "Query");
            }
            else if(issueCategory.equals("Ameyo")) {
                
                String ameyoCategory = "";
                setDropdownValue("Ameyo Category - BTC", ameyoCategory);
                
                if(ameyoCategory.equals("Create Login")) {
                    
                    setInputFieldValue("User ID", "Test");
                    setInputFieldValue("Role of User", "");
                    setInputFieldValue("User Name", "");
                }
                else if(ameyoCategory.equals("Unable To Login")) {
                    
                    setInputFieldValue("User ID", "Test");
                    setInputFieldValue("Role of User", "");
                    
                    // click on checkbox 
                    
                    setInputFieldValue("User Name", "");
                }
                else if(ameyoCategory.equals("Unable To Connect To Customer")) {
                    
                    setInputFieldValue("User ID", "Test");
                    
                    // click on checkbox 
                    
                    setInputFieldValue("User Name", "");
                    setInputFieldValue("Role of User", "");
                    setInputFieldValue("Sample Numbers along time of call", "");
                }
                else if(ameyoCategory.equals("Voice Issue")) {
                    
                    setInputFieldValue("User Name", "");
                    setInputFieldValue("User ID", "Test");
                    setInputFieldValue("Role of User", "");
                    
                    // click on checkbox 
                    
                    setInputFieldValue("Sample Numbers along time of call", "");
                }
            }
        }
        else if(issueType.equals("Admin ")) {
            
            String issueCategory = "Manpower";
            setDropdownValue("Issue Category Admin - BTC", issueCategory);
            
            if(issueCategory.equals("Manpower")) {
                
                setDropdownValue("Manpower Category", "Absenteeism - MST");
            }
            else if(issueCategory.equals("Plumbing")) {
                
                setDropdownValue("Plumbing Category", "No Water Supply In Wash Room");
            }
            else if(issueCategory.equals("Electrical")) {
                   
                setDropdownValue("Electrical Category", "No Power Supply To Centre");
            }
            else if(issueCategory.equals("Air Conditioner")) {
                
                setDropdownValue("Air Conditioner Category", "Water Leakage / Smell / No Cooling");
            }
            else if(issueCategory.equals("Carpentry")) {
                
                setDropdownValue("Carpentry Category", "Drawers Not Closing Properly");
            }
            else if(issueCategory.equals("Housekeeping Services")) {
                
                setDropdownValue("Housekeeping Services Category", "Non Availability Of Toiletries ( Hand Wash & T Rolls )");
            }
            else if(issueCategory.equals("Pantry Services")) {
                
                setDropdownValue("Pantry Services Category", "Micro Wave Not Working");
            }
            else if(issueCategory.equals("Pest Control Services")) {
                
                setDropdownValue("Pest Control Services Category", "Issues Related To Pest Control");
            }
            
            setInputFieldValue("User Contact Number", "9999999999");
        }
        else if(issueType.equals("Summer Camp")) {
            
            setDropdownValue("Issue Category Summer Camp - BTC", "Login");
            setInputFieldValue("PID", "Test");
            setInputFieldValue("Student Name", "Test");
            setInputFieldValue("Registered Phone No", "9999999999");
            setDropdownValue("Ticket Type", "Query");            
        }
        else if(issueType.equals("Reachout")) {
            
            String reachoutIssueSubCategory = "Internal Issue";
            setDropdownValue("Reachout Issue Sub Category", reachoutIssueSubCategory);
            
            if(reachoutIssueSubCategory.equals("Internal Issue")) {
                
                String team = "BMS (Student Issue)";
                setInputFieldValue("Select the Team you want to reach out to - Reachout Issue", team);
                
                if(team.equals("BMS (Student Issue)")) {
                    
                    String BMSStudentIssue = "Batch Transfer";
                    
                    if(BMSStudentIssue.equals("Batch Transfer")) {
                        
                        setInputFieldValue("Name of the student - Batch Transfer", "Test");
                        setInputFieldValue("Current Centre - Batch Transfer", "Test");
                        setInputFieldValue("Grade - Batch Transfer", "Test");
                        setInputFieldValue("Centre where the PID needs to be transferred - Batch Transfer", "Test");
                        setInputFieldValue("Board - Batch Transfer", "Test");
                        setInputFieldValue("Reason of transfer - Batch Transfer", "Test");
                    }
                }
                
                setInputFieldValue("Phone number of the requestor - Reachout Issue", "");
            }
            else if(reachoutIssueSubCategory.equals("Students Issue")) {
                
                setInputFieldValue("Student's PID - Reachout Issue", "");
                setInputFieldValue("Case ID/Task Link", "");
                
                String team = "BMS (Student Issue)";
                setInputFieldValue("Select the Team you want to reach out to - Reachout Issue", team);
                
                if(team.equals("BMS (Student Issue)")) {
                    
                    String BMSStudentIssue = "Batch Transfer";
                    
                    if(BMSStudentIssue.equals("Batch Transfer")) {
                        
                        setInputFieldValue("Name of the student - Batch Transfer", "Test");
                        setInputFieldValue("Current Centre - Batch Transfer", "Test");
                        setInputFieldValue("Grade - Batch Transfer", "Test");
                        setInputFieldValue("Centre where the PID needs to be transferred - Batch Transfer", "Test");
                        setInputFieldValue("Board - Batch Transfer", "Test");
                        setInputFieldValue("Reason of transfer - Batch Transfer", "Test");
                    }
                }
                
                setInputFieldValue("Phone number of the requestor - Reachout Issue", "");
            }
        }
        
        setInputFieldValue("Customer Name", "");
        setInputFieldValue("Customer Email", "");
        setInputFieldValue("Subject", "");
        setTextboxFieldValue("Description", "");
    }
    
    // miscellaneous methods
    
    // @Author = Ankur
    // set textbox field value
    public void setTextboxFieldValue(String xpath, String data) {
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
        driver.findElement(By.xpath(xpath)).sendKeys(data);
    }
    
    // @Author = Ankur
    // @Description = set date
    public void setDate(String xpath, String date) {
        
    }
    
    // @Author = Ankur
    // @Description = get text of element
    public String getText(String xpath) {
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
        return driver.findElement(By.xpath(xpath)).getText();
    }
    
    // @Author = Ankur
    // @Description = select an option from dropdown 
    public void setDropdownValue(String xpath, String data) throws InterruptedException {
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
        driver.findElement(By.xpath(xpath)).click();
        
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='dropdown__dropdownSheet']/div")));
        List<WebElement> elements = driver.findElements(By.xpath("//div[@class='dropdown__dropdownSheet']/div"));
        
        if(data.equalsIgnoreCase("select random option")) {
            
            elements.get(new Random().nextInt(elements.size())).click();
        }
        else {
            
            for(WebElement element: elements) {
                
                if(element.getText().equalsIgnoreCase(data)) {
                    
                    element.click();
                    break;
                }
            }  
        }
    }
    
    // @Author 
    // @Description = set input field value
    public void setInputFieldValue(String xpath, String data) {
     
//        visibleText(e);
        driver.findElement(By.xpath(xpath)).clear();
        driver.findElement(By.xpath(xpath)).sendKeys(data);
    }
}
