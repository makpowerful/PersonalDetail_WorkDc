package pageObjects;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;

import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class PO_TimeLine {
    
    private WebDriver driver;
    private String updatedStatus;
    //private String date1 = "16-05-2024";
    //private String date2 = "17-04-2025";
    private String name = "";
    
    //XPath for elements.
    private By userName = By.xpath("//div[@class='projectDropdown__content__userName'] | //div[@class='projectDropdown__container__content__userName']");
    
    private By statusInput = By.xpath("(//div[@class='dropdown__selectedLabel'])[2]");
    private String dropDown = "(//div[@class='dropdown__dropdownOption'])[";
    private String dropDownGeneric = "//div[@class='dropdown__dropdownOption']";
    private By priorityInput = By.xpath("(//div[@class='dropdown__selectedLabel'])[3]");
    private By groupInput = By.xpath("(//input[@class='singleSelectSearch__container__input'])[1]");
    private By agentInput = By.xpath("(//input[@class='singleSelectSearch__container__input'])[2]");
    private By dateInput = By.xpath("//div[@class='react-datepicker__input-container ']//input |//div[@class='react-datepicker__input-container']//input");
    private By updateButton = By.xpath("//button[contains(text(),'Update')]");
    private By caseDueDateLabel = By.xpath("//div[@class='caseProperties']//div[contains(text(),'Due Date')]//following-sibling::div[1]//input");
    private By nextMonth = By.xpath("//button[@aria-label='Next Month']");
    private By caseAgentLabel = By.xpath("(//input[@class='singleSelectSearch__container__input'])[2]");
    private By caseGroupLabel = By.xpath("(//input[@class='singleSelectSearch__container__input'])[1]");
    private By dropDownSearchable = By.xpath("//div[@class='singleSelectSearch__searchOptionsList__item__label']");
    
    //TIMELINE section
    private By timelineMenu = By.xpath("//div[contains(text(),'TIMELINE')]");
    private By event1 = By.xpath("(//div[@class='case-timeline__event'])[1]");
    private By change1 = By.xpath("(//div[@class='case-timeline__status-change'])[1]");
    private By status1 = By.xpath("(//div[@class='case-timeline__status'])[1]");
    private By event2 = By.xpath("(//div[@class='case-timeline__event'])[2]");
    private By change2 = By.xpath("(//div[@class='case-timeline__status-change'])[2]");
    private By status2 = By.xpath("(//div[@class='case-timeline__status'])[2]");
    
    
    // @author : Pratik Jain
    // Constructor
    public PO_TimeLine(WebDriver driver) {
        this.driver = driver;
    }
    
    
    // @author : Pratik Jain
    // Sets the user Name in "name" field.
    public void setName() {
        name = driver.findElement(userName).getText();
    }
    
    
    // @author : Pratik Jain
    // Updates the Status and verifies the Timeline.
    public Boolean timeLineForStatus(HashMap<String, String> ticketData) throws InterruptedException {
        clickable(statusInput);
        String prevStatus = driver.findElement(statusInput).getText();
        jsClick(driver.findElement(statusInput));
        
        int itemNumber = 1;
        try {
        while(driver.findElement(By.xpath("(//div[@class='dropdown__dropdownOption'])["+Integer.toString(itemNumber)+"]")).getText().equalsIgnoreCase(prevStatus)) {
            itemNumber++;
        }
        }
        catch(Exception e) {
            while(driver.findElement(By.xpath("(//div[@class='dropdown__dropdownOption'])["+Integer.toString(itemNumber)+"]")).getText().equalsIgnoreCase(prevStatus)) {
                itemNumber++;
            }  
        }
        By currentXpath = By.xpath("(//div[@class='dropdown__dropdownOption'])["+Integer.toString(itemNumber)+"]");
        try {
        updatedStatus = driver.findElement(currentXpath).getText();
        }
        catch(Exception e) {
            Thread.sleep(200);
            updatedStatus = driver.findElement(currentXpath).getText();
        }
        ticketData.put("caseStatus", updatedStatus);
        try {
            driver.findElement(currentXpath).click();
        }
        catch(Exception e) {
        jsClick(driver.findElement(currentXpath));
        }
        clickable(updateButton);
        driver.findElement(updateButton).click();
        
        clickable(timelineMenu);
        Thread.sleep(1000);
        
        for(int i=0;i<5;i++) {
            Thread.sleep(2000);
            driver.get(driver.getCurrentUrl());
            clickable(timelineMenu);
            driver.findElement(timelineMenu).click();
            visibleText(event1);
            if(driver.findElement(event1).getText().equalsIgnoreCase(name+" changed the status")) {
              break;  
            }
            
            System.out.println(driver.findElement(event1).getText());
            System.out.println(name+" changed the status");

        }
        
        Assert.assertTrue(driver.findElement(event1).getText().equalsIgnoreCase(name+" changed the status"));
        Assert.assertTrue(driver.findElement(change1).getText().split(" ")[0].equalsIgnoreCase(prevStatus));
        Assert.assertTrue(driver.findElement(change1).getText().split(" ")[2].equalsIgnoreCase(updatedStatus));
        Assert.assertTrue(driver.findElement(status1).getText().split(" ")[1].equalsIgnoreCase(updatedStatus));
        
        driver.navigate().refresh();
        return true;
    }
    
    
    // @author : Pratik Jain
    // Changes the Priority and verifies the Timeline.
    public Boolean timeLineForPriority(HashMap<String, String> ticketData) throws InterruptedException {
        clickable(priorityInput);
        String prevPriority = driver.findElement(priorityInput).getText();
        if(prevPriority.equals("Select Priority"))prevPriority = "None";
        updatedStatus = driver.findElement(statusInput).getText();
        jsClick(driver.findElement(priorityInput));
        
        int itemNumber = 1;
        try {
        while(driver.findElement(By.xpath("(//div[@class='dropdown__dropdownOption'])["+Integer.toString(itemNumber)+"]")).getText().equalsIgnoreCase(prevPriority)) {
            itemNumber++;
        }
        }
        catch(Exception e) {
            while(driver.findElement(By.xpath("(//div[@class='dropdown__dropdownOption'])["+Integer.toString(itemNumber)+"]")).getText().equalsIgnoreCase(prevPriority)) {
                itemNumber++;
            }   
        }
        By currentXpath = By.xpath("(//div[@class='dropdown__dropdownOption'])["+Integer.toString(itemNumber)+"]");
        String updatedPriority;
        try {
            updatedPriority = driver.findElement(currentXpath).getText();
            ticketData.put("casePriority", updatedPriority);
            System.out.println(currentXpath);  
            driver.findElement(currentXpath).click(); 
        }
        catch(Exception e) {
            updatedPriority = driver.findElement(currentXpath).getText();
            ticketData.put("casePriority", updatedPriority);
            jsClick(driver.findElement(currentXpath));
        }
        
        
        clickable(updateButton);
        driver.findElement(updateButton).click();
        
        clickable(timelineMenu);
        Thread.sleep(1000);
        for(int i=0;i<5;i++) {
            Thread.sleep(2000);
            driver.get(driver.getCurrentUrl());
            clickable(timelineMenu);
            driver.findElement(timelineMenu).click();
            visibleText(event1);
            if(driver.findElement(event1).getText().equalsIgnoreCase(name+" changed the priority")) {
              break;  
            }
        }
        Assert.assertTrue(driver.findElement(event1).getText().equalsIgnoreCase(name+" changed the priority"));
        Assert.assertTrue(driver.findElement(change1).getText().split(" ")[0].equalsIgnoreCase(prevPriority));
        Assert.assertTrue(driver.findElement(change1).getText().split(" ")[2].equalsIgnoreCase(updatedPriority));
        Assert.assertTrue(driver.findElement(status1).getText().split(" ")[1].equalsIgnoreCase(updatedStatus));
        driver.navigate().refresh();
        return true;
    }
    
    //@Author : Gaurang
    //Set case group property
    public String setCaseGroupRandom() {
        visibleText(caseGroupLabel);
        WebElement parent = driver.findElement(caseGroupLabel);
        jsClick(parent);
//        visibleText(parent.findElements(dropDownOption));
        List<WebElement> eles = parent.findElements(dropDownSearchable);
        Random random = new Random();
        String value = eles.get(random.nextInt(eles.size())).getText();
        System.out.println("Selected group is : "+value);
        selectSearchableOption(value);
        return value;
    }
    
    //@Author : Gaurang
    //Set case agent property
    public String setCaseAgentRandom() throws InterruptedException {
        visibleText(caseAgentLabel);
        WebElement parent = driver.findElement(caseAgentLabel);
        jsClick(parent);
        driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
//        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
//        LocalDateTime now = LocalDateTime.now();  
//        System.out.println(dtf.format(now));
        visibleText(parent.findElements(dropDownSearchable), 1);
        List<WebElement> eles = parent.findElements(dropDownSearchable);
        Random random = new Random();
        String value = eles.get(random.nextInt(eles.size())).getText();
        selectSearchableOption(value);
        return value;
    }
    
    //@Author : Gaurang
    //Select option from the right side property menu for group and agent
    public void selectSearchableOption(String value) {
        List<WebElement> eles = driver.findElements(dropDownSearchable);
        for(int i=0; i<eles.size(); i++) {
            if(eles.get(i).getText().compareToIgnoreCase(value) == 0) {
                System.out.println("clicked the option: "+value);
                eles.get(i).click();
                break;
            }
        }
    }
    
    // @author : Pratik Jain
    // Changes the Group along with Agent and verifies the Timeline.
    public Boolean timeLineForGroupAndAgent(HashMap<String, String> ticketData) throws InterruptedException {
        clickable(caseGroupLabel);
        String prevGroup = driver.findElement(caseGroupLabel).getAttribute("value");
//        if(prevGroup.equalsIgnoreCase("Select Group"))prevGroup = "None";
        String prevAgent = driver.findElement(caseAgentLabel).getAttribute("value");
//        if(prevAgent.equals("Select Agent"))prevAgent = "None";
//        updatedStatus = driver.findElement(statusInput).getText();
//        
//        String updatedGroup = "";
//        String updatedAgent = "";
//        
//        int itemNumber = 1;
//        Boolean check = false;
//        while(!check) {
//            Thread.sleep(1000);
//            try {
//            clickButton(driver.findElement(groupInput));
//            visibleText(driver.findElement(By.xpath(dropDownGeneric)));
//            }
//            catch(Exception e) {
//                jsClick(driver.findElement(groupInput));
//                visibleText(driver.findElement(By.xpath(dropDownGeneric)));  
//            }
//            itemNumber++;
//            if(!driver.findElement(By.xpath(dropDown+Integer.toString(itemNumber)+"]")).getText().equalsIgnoreCase(prevGroup)) {
//                By currentXpathGroup = By.xpath(dropDown+Integer.toString(itemNumber)+"]");
//                updatedGroup = driver.findElement(currentXpathGroup).getText();
//                try {
//                    clickButton(driver.findElement(currentXpathGroup));
//                }
//                catch(Exception e) {
//                    jsClick(driver.findElement(currentXpathGroup));   
//                }
//                clickable(agentInput);
//                clickable(agentInput);
//                driver.findElement(agentInput).click();
//                //System.out.println("No of agents found for "+updatedGroup+" group is"+driver.findElements(By.xpath(dropDownGeneric)).size());
//                if(driver.findElements(By.xpath(dropDownGeneric)).size()!=0) {
//                    By currentXpathAgent = By.xpath(dropDown+"1]");
//                    updatedAgent = driver.findElement(currentXpathAgent).getText();
//                    driver.findElement(currentXpathAgent).click();
//                    check=true;
//                }
//                else {
//                    System.out.println("No Agent in Group");
//                }
//                }
//            
//        }
        while(true) {
            try {
                ticketData.put("caseGroup", setCaseGroupRandom());
                ticketData.put("caseAgent", setCaseAgentRandom());
                break;
            }
            catch(Exception e) {
                System.out.println(e.getMessage());
                driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            }
        }
//        ticketData.put("caseGroup", updatedGroup);
//        ticketData.put("caseAgent", updatedAgent);
        clickable(updateButton);
        driver.findElement(updateButton).click();
        
        clickable(timelineMenu);
        Thread.sleep(1000);
        
        if(prevAgent==ticketData.get("caseAgent")) {
            for(int i=0;i<5;i++) {
                Thread.sleep(2000);
                driver.get(driver.getCurrentUrl());
                clickable(timelineMenu);
                driver.findElement(timelineMenu).click();
                visibleText(event1);
                if(driver.findElement(event1).getText().equalsIgnoreCase(name+" changed the group")) {
                  break;  
                }
            }
            String changeStatement = driver.findElement(change1).getText();
            String firstGroup = changeStatement.substring(0,prevGroup.length());
            String secondGroup = changeStatement.substring(prevGroup.length()+3);
            Assert.assertTrue(driver.findElement(event1).getText().equalsIgnoreCase(name+" changed the group"));
            Assert.assertTrue(firstGroup.equalsIgnoreCase(prevGroup));
            Assert.assertTrue(secondGroup.equalsIgnoreCase(ticketData.get("caseGroup")));
            Assert.assertTrue(driver.findElement(status1).getText().split(" ")[1].equalsIgnoreCase(updatedStatus));
        }else {
            for(int i=0;i<5;i++) {
                Thread.sleep(2000);
                driver.get(driver.getCurrentUrl());
                clickable(timelineMenu);
                driver.findElement(timelineMenu).click();
                visibleText(event1);
                if(driver.findElement(event1).getText().equalsIgnoreCase(name+" changed the agent")) {
                  break;  
                }
            }
            String changeStatement = driver.findElement(change1).getText();
            String firstAgent = changeStatement.substring(0,prevAgent.length());
            String secondAgent = changeStatement.substring(prevAgent.length()+3);
            Assert.assertTrue(driver.findElement(event1).getText().equalsIgnoreCase(name+" changed the agent"));
            Assert.assertTrue(firstAgent.equalsIgnoreCase(prevAgent));
            Assert.assertTrue(secondAgent.equalsIgnoreCase(ticketData.get("caseAgent")));
            Assert.assertTrue(driver.findElement(status1).getText().split(" ")[1].equalsIgnoreCase(updatedStatus));
            
            changeStatement = driver.findElement(change2).getText();
            String firstGroup = changeStatement.substring(0,prevGroup.length());
            String secondGroup = changeStatement.substring(prevGroup.length()+3);
            Assert.assertTrue(driver.findElement(event2).getText().equalsIgnoreCase(name+" changed the group"));
            Assert.assertTrue(firstGroup.equalsIgnoreCase(prevGroup));
            Assert.assertTrue(secondGroup.equalsIgnoreCase(ticketData.get("caseGroup")));
            Assert.assertTrue(driver.findElement(status2).getText().split(" ")[1].equalsIgnoreCase(updatedStatus));
        }
        driver.navigate().refresh();
        return true;
    }
    
    public void clickButton(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, 10);

        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));

        System.out.println("Element is clickable");
        element.click();
    }
    
    // @author : Pratik Jain
    // Changes the Due Date and verifies the Timeline.
    public Boolean timeLineForDate(HashMap<String, String> ticketData) throws InterruptedException {
        clickable(dateInput);
        updatedStatus = driver.findElement(statusInput).getText();
        String prevDate = driver.findElement(dateInput).getAttribute("value");
        if(prevDate.equals(""))prevDate = "None";
        String updatedDate = setCaseDueDate();
        System.out.println(updatedDate);
        
        clickable(updateButton);
        driver.findElement(updateButton).click();
        
        clickable(timelineMenu);
        Thread.sleep(1000);
        for(int i=0;i<5;i++) {
            Thread.sleep(2000);
            driver.get(driver.getCurrentUrl());
            clickable(timelineMenu);
            driver.findElement(timelineMenu).click();
            visibleText(event1);
            if(driver.findElement(event1).getText().equalsIgnoreCase(name+" changed the due date")) {
              break;  
            }
        }
        Assert.assertTrue(driver.findElement(event1).getText().equalsIgnoreCase(name+" changed the due date"));
        Assert.assertTrue(driver.findElement(status1).getText().split(" ")[1].equalsIgnoreCase(updatedStatus));

        driver.navigate().refresh();
        return true;
    }
    
    
  //Capture case due date label
    public String getCaseDueDateLabel() {
        visibleText(caseDueDateLabel);
        return driver.findElement(caseDueDateLabel).getAttribute("placeholder");
    }
    
    
    public String setCaseDueDate() throws InterruptedException {
        visibleText(caseDueDateLabel);
        WebElement parent = driver.findElement(caseDueDateLabel);
        parent.click();
        visibleText(parent.findElement(nextMonth));
        int month = new Random().nextInt(10);
        for(int i=0; i<month; i++) {
            jsClick(parent.findElement(nextMonth));
        }
        Thread.sleep(100);
        String currMonth = driver.findElement(By.xpath("//div[contains(@class,'react-datepicker__current-month')]")).getText().split(" ")[0];        
        jsClick(driver.findElement(By.xpath("(//div[contains(@aria-label,'" + currMonth + "')])[" + Integer.toString(1 + new Random().nextInt(28)) + "]")));
        String date = getCaseDueDateLabel();
        return date;
    }
    
    
    // @author : Kalam
    // METHODS FROM BASE CLASS--------------------------------------------------------------------------------------------------
    
    
    // Wait till the parameter element is visible.
    public boolean visibleText(By element)
    {
        WebDriverWait wait= new WebDriverWait(driver, 10);
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));
        //System.out.println("Element is visible");
        return false;
    }
    
    
    public boolean visibleText(WebElement element)
    {
        WebDriverWait wait= new WebDriverWait(driver, 10);
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElements(element));
        //System.out.println("Element is visible");
        return false;
    }
    
    
    // Check if the Element is Clickable.
    public boolean clickable(By element)
    {
        WebDriverWait wait= new WebDriverWait(driver, 10);
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));
        //System.out.println("Element is visible");
        return false;
    }
    public void jsClick(WebElement el) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].click();", el);
        } catch (Exception e) {
            System.out.println("=============================================================");
            System.out.println("Exception-jsClick(): " + e.getMessage());
            //takeScreenShot();
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }
    public boolean visibleText(List<WebElement> element, int sec)
    {
        WebDriverWait wait= new WebDriverWait(driver, sec);
        
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElements(element));
        
        return false;
    }
}
