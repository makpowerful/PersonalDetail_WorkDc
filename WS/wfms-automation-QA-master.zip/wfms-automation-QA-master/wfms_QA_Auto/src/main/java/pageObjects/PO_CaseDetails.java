package pageObjects;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import resources.ExcelData;

public class PO_CaseDetails {
    WebDriver driver;
    private static ExcelData excelData = new ExcelData();
    private static ArrayList<String> al = new ArrayList<String>();
    
    private By globalSearch = By.xpath("//div[@class='search-bar']");
    private By expandedSearch = By.xpath("//input[@data-testid='search-bar-input']");
    private By projectDropdown = By.xpath("//div[@class='projectDropdown__container'] | //div[@class='projectDropdown__container__content__userName__dropDownDisabled']");
    private By dropdownOption = By.xpath("//div[@class='dropdown__dropdownOption']");
    private By userName = By.xpath("//div[contains(@class,'projectDropdown__content__userName')] | //div[contains(@class,'dropDownDisabled')] | //div[contains(@class,'projectDropdown__container__content__userName')]");
    private By horizontalLine = By.xpath("//hr");
    private By createBtn = By.xpath("//button[text()='CREATE']");
    
    // tickets details
    private By caseDetailsHeader = By.className("header__left-section");
    private By ticketIdText = By.className("caseDetails__left__ticketDetails__ticketId");
    private By createdByText = By.className("caseDetails__left__ticketDetails__wrapper__createdBy");
    private By createdAtText = By.className("caseDetails__left__ticketDetails__wrapper__createdAt");
    private By titleText = By.className("caseDetails__left__title");
    private By descriptionHeading = By.className("caseDetails__left__descriptionHeading");
    private By descriptionContent = By.className("caseDetails__left__descriptionContent");
    private By attachmentHeader = By.className("caseDetailsAttachments__header");
    private By allAttachmets = By.xpath("//div[@class='caseDetailsAttachments__header']//following-sibling::div[@class='caseDetailsAttachments__frame']/div[@class='attachment__frame']");
    
    
    // Reply and notes section
    private By stepperContainer = By.className("stepper__container");
    private By stepperAuthor = By.className("stepper__author");
    private By replyTimestamp = By.xpath("//div[@class='stepper__timestamp'][1]");
    private By replyEmailTo = By.xpath("//div[@class='stepper__timestamp'][2]");
    private By replyEmailCc = By.xpath("//div[@class='stepper__timestamp'][3]");
    private By replyEmailBcc = By.xpath("//div[@class='stepper__timestamp'][4]");
    private By stepperContent = By.className("stepper__description");
    private By replyButton = By.className("caseDetailsButton__reply");
    private By replyAllButton = By.xpath("//button[text()='Reply All']");
    private By addNoteButton = By.className("caseDetailsButton__addnote");
    private By emailToInput = By.xpath("//div[@class='email_template__to'] //input[@id='email__input__box']");
    private By ccBtn = By.xpath("//button[contains(text(),'Cc')]");
    private By bccBtn = By.xpath("//button[contains(text(),'Bcc')]");
    private By emailCcInput = By.xpath("//div[@class='email_template__cc'] //input[@id='email__input__box']");
    private By emailBccInput = By.xpath("//div[@class='email_template__bcc'] //input[@id='email__input__box']");
    private By emailCcClose = By.xpath("//div[@class='email_template__cc'] //button[contains(text(),'X')]");
    private By emailBccClose = By.xpath("//div[@class='email_template__bcc'] //button[contains(text(),'X')]");
//    private By emailBody = By.xpath("//div[@class='ql-editor ql-blank']//p");
    private By emailBody = By.xpath("//p");
    private By sendBtn = By.xpath("//button[contains(text(),'Send')]");
    private By submitNoteBtn = By.xpath("//button[contains(text(),'Add Note')]");
    private By deleteBtn = By.xpath("//img[@alt='delete']"); 
    private By discardMessage = By.xpath("//div[@class='discard__message']");
    private By yesBtn = By.xpath("//button[text()='Yes']");
    private By editorBox = By.xpath("//div[@class='email_template__frame']");
    private By cancelBtn = By.xpath("//button[text()='Cancel']");
    private By removeFileBtn = By.xpath("(//button[@class='filename__close'])[1]");
    private By numberOfAttachments = By.xpath("//div[@class='attachment__header__number']");
    private By leaveWithoutSavingBtn = By.xpath("//button[text()='Leave Without Saving']");
    private By addAllAttachmentsBtn = By.xpath("//button[@aria-label='Add all attachment link(s)']");
//    private By addAllAttachmentsBtn = By.xpath("//div[@class='all-attachment']");
    private By addAllAttachmentsText = By.xpath("//p[contains(.,'------Attachment(s)------')]//following-sibling::p");
    
    // right side properties menu
    private By propertiesHeading = By.className("caseProperties__heading__text");
    private By caseStatusText = By.xpath("//div[contains(@class,'caseProperties')]//div[contains(text(),'Case Status')]");
    private By caseStatusLabel = By.xpath("//div[contains(@class,'caseProperties')]//div[contains(text(),'Case Status')]//following-sibling::div[1]");
    private By casePriorityText = By.xpath("//div[contains(@class,'caseProperties')]//div[(text()='Priority')]");
    private By casePriorityLabel = By.xpath("//div[contains(@class,'caseProperties')]//div[(text()='Priority')]//following-sibling::div[1][@data-testid]");
    private By caseDueDateText = By.xpath("//div[contains(@class,'caseProperties')]//div[contains(text(),'Due Date')]");
    private By caseDueDateLabel = By.xpath("//div[contains(@class,'caseProperties')]//div[contains(text(),'Due Date')]//following-sibling::div[1]//input");
    private By caseAgentText = By.xpath("//div[contains(@class,'caseProperties')]//div[contains(text(),'Agent')]");
    private By caseAgentLabel = By.xpath("(//input[@class='singleSelectSearch__container__input'])[2]");
    private By caseGroupText = By.xpath("//div[contains(@class,'caseProperties')]//div[contains(text(),'Group')]");
    private By caseGroupLabel = By.xpath("(//input[@class='singleSelectSearch__container__input'])[1]");
    private By customerDetailsText = By.xpath("(//div[@data-testid='accordion-header'])[1]");
    private By updateBtn = By.xpath("//button[contains(text(),'Update')]");
    private By dropDownOption = By.xpath("//div[@data-testid='dropdown__singleOption']");
    private By dropDownSearchable = By.xpath("//div[@class='singleSelectSearch__searchOptionsList__item__label']");
    private By nextMonth = By.xpath("//button[@aria-label='Next Month']");
    private By errorMessageSelectGroupFirst = By.xpath("//div[@class='caseProperties__groupNotSelected']");
    
    // accordians
    private By agentDetailsText = By.xpath("(//div[@data-testid='accordion-header'])[2]");
    private By caseDetailsText = By.xpath("(//div[@data-testid='accordion-header'])[3]");
    private By timelineText = By.xpath("(//div[@data-testid='accordion-header'])[4]");
    private By accordianHeading1 = By.xpath("following::div[contains(@class,'item__header')][1]");
    private By accordianDescription1 = By.xpath("following::div[contains(@class,'item__description')][1]");
    private By accordianHeading2 = By.xpath("following::div[contains(@class,'item__header')][2]");
    private By accordianDescription2 = By.xpath("following::div[contains(@class,'item__description')][2]");
    private By accordianHeading3 = By.xpath("following::div[contains(@class,'item__header')][3]");
    private By accordianDescription3 = By.xpath("following::div[contains(@class,'item__description')][3]");
    private By accordianHeading4 = By.xpath("following::div[contains(@class,'item__header')][4]");
    private By accordianDescription4 = By.xpath("following::div[contains(@class,'item__description')][4]");
    private By accordianHeading5 = By.xpath("following::div[contains(@class,'item__header')][5]");
    private By accordianDescription5 = By.xpath("following::div[contains(@class,'item__description')][5]");
    private By accordianHeading6 = By.xpath("following::div[contains(@class,'item__header')][6]");
    private By accordianDescription6 = By.xpath("following::div[contains(@class,'item__description')][6]");
    private By accordianHeading7 = By.xpath("following::div[contains(@class,'item__header')][7]");
    private By accordianDescription7 = By.xpath("following::div[contains(@class,'item__description')][7]");
    private By accordianHeading8 = By.xpath("following::div[contains(@class,'item__header')][8]");
    private By accordianDescription8 = By.xpath("following::div[contains(@class,'item__description')][8]");
    private By accordianHeading9 = By.xpath("following::div[contains(@class,'item__header')][9]");
    private By accordianDescription9 = By.xpath("following::div[contains(@class,'item__description')][9]");
    private By accordianCustomerDetails = By.xpath("//div[@data-testid='accordion-header'][text()='CUSTOMER DETAILS']");
    private By accordianAgentDetails = By.xpath("//div[@data-testid='accordion-header'][text()='AGENT DETAILS']");
    private By accordianCaseDetails = By.xpath("//div[@data-testid='accordion-header'][text()='CASE DETAILS']");
//    private By accordianTimeline = By.xpath("//div[@data-testid='accordion-header'][text()='TIMELINE']");
    private By caseDetailsElements = By.xpath("//span[contains(text(),'CASE DETAILS')]//following::div[@class='accordion__wrapper__content__item']");
    private By casePropertyHeader = By.xpath(".//descendant::div[contains(@class,'header')]");
    private By casePropertyDescription = By.xpath(".//descendant::div[contains(@class,'description')]");
    private By loader = By.xpath("//div[contains(@class,'loader__container')]");
    
    public PO_CaseDetails(WebDriver driver) {
        super();
        this.driver = driver;
    }
    
    // ------------------------------------------------------------------------------------------------ 
    // Gaurang Methods
    // ------------------------------------------------------------------------------------------------
    
    //@Author : Gaurang
    //Capture ticket Id text
    public String getTicketIdText() {
        visibleText(ticketIdText);
        return driver.findElement(ticketIdText).getText();
    }
    
    //@Author : Gaurang
    //Capture create butoon text
    public String getCreateCaseButton() {
        visibleText(createBtn);
        return driver.findElement(createBtn).getText();
    }
    
    //@Author : Gaurang
    //Capture case Details Header text
    public String getCaseDetailsHeader() throws InterruptedException {
        Thread.sleep(500);
        visibleText(caseDetailsHeader);
        return driver.findElement(caseDetailsHeader).getText();
    }
    
    //@Author : Gaurang
    //Capture created by text
    public String getCreatedByText() {
        visibleText(createdByText);
        String name = driver.findElement(createdByText).getText().split("via")[1];
        return name.substring(1, name.length());
    }
    
    //@Author : Gaurang
    //open a specific ticket
    public void openSpecificTicket(String ticketId) {
        driver.get("https://workflow-managment-system-staging.byjusweb.com/tickets/"+ticketId);
    }
    
    //@Author : Gaurang
    //open a specific ticket
    public String getTableTag() {
        return driver.findElement(By.xpath("//table")).getTagName();
    }
    
    //@Author : Gaurang
    //Capture created at text
    public boolean getCreatedAtText() {
        String pattern = "E, dd MMM yyyy";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        Date date = new Date();
        String dateString = simpleDateFormat.format(date);
        visibleText(createdAtText);
        String ticketDate = driver.findElement(createdAtText).getText();
        if(!ticketDate.contains(dateString)) {
            return false;
        }
        pattern = "aa";
        simpleDateFormat = new SimpleDateFormat(pattern);
        dateString = simpleDateFormat.format(date);
        if(!ticketDate.contains(dateString.toUpperCase())) {
            return false;
        }
        return true;
    }
    
    //@Author: Gaurang
    //Get number of horizontal lines on the page
    public int getNumberOfHorizontalLines() {
        visibleText(horizontalLine);
        return driver.findElements(horizontalLine).size();
    }

    //@Author : Gaurang
    //Capture title text
    public String getTitleText() {
        visibleText(titleText);
        return driver.findElement(titleText).getText();
    }

    //@Author : Gaurang
    //Capture description heading text
    public String getDescriptionHeading() {
        visibleText(descriptionHeading);
        return driver.findElement(descriptionHeading).getText();
    }

    //@Author : Gaurang
    //Capture description content text
    public String getDescriptionContent() {
        visibleText(descriptionContent);
        return driver.findElement(descriptionContent).getText();
    }
    
    //@Author : Gaurang
    //Capture attachment header text
    public String getAttachmentHeader() {
        visibleText(attachmentHeader);
        return driver.findElement(attachmentHeader).getText();
    }
    
    //@Author : Gaurang
    //Capture properties heading text
    public String getPropertiesHeading() {
        visibleText(propertiesHeading);
        return driver.findElement(propertiesHeading).getText();
    }
    
    //@Author : Gaurang
    //Capture case status text
    public String getCaseStatusText(String role) {
        if(role.equals("requestor") == false) {
            visibleText(caseStatusText);
        }
        return driver.findElement(caseStatusText).getText();
    }
    
    //@Author : Gaurang
    //Capture case status label
    public String getCaseStatusLabel(String role) {
        if(role.equals("requestor") == false) {
            visibleText(caseStatusLabel);
        }
        return driver.findElement(caseStatusLabel).getText();
    }
    
    //@Author : Gaurang
    //Capture case property text
    public String getCasePriorityText(String role) {
        if(role.equals("requestor") == false) {
            try {
                driver.findElement(casePriorityText).click();
                Actions ac = new Actions(driver);
                ac.moveToElement(driver.findElement(casePriorityText)).build().perform();
            }
            catch(Exception e) {
            visibleText(casePriorityText);
            }
        }
        return driver.findElement(casePriorityText).getText();
    }
    
    //@Author : Gaurang
    //Capture case status label
    public String getCasePriorityLabel(String role) {
        if(role.equals("requestor") == false) {
            try {
                Actions ac = new Actions(driver);
                ac.moveToElement(driver.findElement(casePriorityLabel)).build().perform();
                
            }
            catch(Exception e) {
            visibleText(casePriorityLabel);
            }
        }
        return driver.findElement(casePriorityLabel).getText();
    }
    
    //@Author : Gaurang
    //Capture case due date text
    public String getCaseDueDateText(String role) {
        if(role.equals("requestor") == false) {
            visibleText(caseDueDateText);
        }
        return driver.findElement(caseDueDateText).getText();
    }
    
    //@Author : Gaurang
    //Capture case due date label
    public String getCaseDueDateLabel(String role) {
        if(role.equals("requestor") == false) {
            visibleText(caseDueDateLabel);
        }
        return driver.findElement(caseDueDateLabel).getAttribute("placeholder");
    }
    
    //@Author : Gaurang
    //Capture case agent text
    public String getCaseAgentText(String role) {
        if(role.equals("requestor") == false) {
            visibleText(caseAgentText);
        }
        return driver.findElement(caseAgentText).getText();
    }
    
    //@Author : Gaurang
    //Capture case agent label
    public String getCaseAgentLabel(String role) {
        if(role.equals("requestor") == false) {
            visibleText(caseAgentLabel);
        }
        return driver.findElement(caseAgentLabel).getAttribute("value");
    }
    
    //@Author : Gaurang
    //Capture case agent text
    public String getCaseGroupText(String role) {
        if(role.equals("requestor") == false) {
            visibleText(caseGroupText);
        }
        return driver.findElement(caseGroupText).getText();
    }
    
    //@Author : Gaurang
    //Capture case agent label
    public String getCaseGroupLabel(String role) {
        if(role.equals("requestor") == false) {
            visibleText(caseGroupLabel);
        }
        return driver.findElement(caseGroupLabel).getAttribute("value");
    }
    
    //@Author : Gaurang
    //Capture case agent text
    public String getCustomerDetailsText() {
        visibleText(customerDetailsText);
        return driver.findElement(customerDetailsText).getText();
    }
    
    //@Author : Gaurang
    //Capture case agent text
    public String getAgentDetailsText() {
        visibleText(agentDetailsText);
        return driver.findElement(agentDetailsText).getText();
    }
    
    //@Author : Gaurang
    //Capture case details text
    public String getCaseDetailsText() {
        visibleText(caseDetailsText);
        return driver.findElement(caseDetailsText).getText();
    }
    
    //@Author : Gaurang
    //Capture case timeline text
    public String getTimelineText() {
        visibleText(timelineText);
        return driver.findElement(timelineText).getText();
    }
    
    //@Author : Gaurang
    //click customer details accordian
    public void clickCustomerDetails() {
        visibleText(customerDetailsText);
        driver.findElement(customerDetailsText).click();
    }
    
    //@Author : Gaurang
    //Capture customer name heading text
    public String getCustomerNameHeading() {
        WebElement ele = driver.findElement(accordianCustomerDetails);
        visibleText(ele.findElement(accordianHeading1));
        return ele.findElement(accordianHeading1).getText();
    }
    
    //@Author : Gaurang
    //Capture customer name description text
    public String getCustomerNameDescription() {
        WebElement ele = driver.findElement(accordianCustomerDetails);
        visibleText(ele.findElement(accordianDescription1));
        return ele.findElement(accordianDescription1).getText();
    }
    
    //@Author : Gaurang
    //Capture customer email heading text
    public String getCustomerEmailHeading() {
        WebElement ele = driver.findElement(accordianCustomerDetails);
        visibleText(ele.findElement(accordianHeading2));
        return ele.findElement(accordianHeading2).getText();
    }
    
    //@Author : Gaurang
    //Capture customer email description text
    public String getCustomerEmailDescription() {
        WebElement ele = driver.findElement(accordianCustomerDetails);
        visibleText(ele.findElement(accordianDescription2));
        return ele.findElement(accordianDescription2).getText();
    }
    
    //@Author : Gaurang
    //click agent details accordian
    public void clickAgentDetails() {
        visibleText(agentDetailsText);
        try {
            jsClick(driver.findElement(agentDetailsText));   
        }
        catch(Exception e) {
        driver.findElement(agentDetailsText).click();
        }
    }
    
    //@Author : Gaurang
    //Capture agent name heading text
    public String getAgentNameHeading() {
        WebElement ele = driver.findElement(accordianAgentDetails);
        visibleText(ele.findElement(accordianHeading1));
        return ele.findElement(accordianHeading1).getText();
    }
    
    //@Author : Gaurang
    //Capture agent name description text
    public String getAgentNameDescription() {
        WebElement ele = driver.findElement(accordianAgentDetails);
        visibleText(ele.findElement(accordianDescription1));
        return ele.findElement(accordianDescription1).getText();
    }
    
    //@Author : Gaurang
    //Capture agent email heading text
    public String getAgentEmailHeading() {
        WebElement ele = driver.findElement(accordianAgentDetails);
        visibleText(ele.findElement(accordianHeading2));
        return ele.findElement(accordianHeading2).getText();
    }
    
    //@Author : Gaurang
    //Capture agent email description text
    public String getAgentEmailDescription() {
        WebElement ele = driver.findElement(accordianAgentDetails);
        visibleText(ele.findElement(accordianDescription2));
        return ele.findElement(accordianDescription2).getText();
    }
    
    //@Author : Gaurang
    //click case details accordian
    public void clickCaseDetails() {
        visibleText(caseDetailsText);
        try {
        jsClick(driver.findElement(caseDetailsText));
        }
        catch(Exception e) {
            driver.findElement(caseDetailsText).click();   
        }
    }
    
    //@Author : Gaurang
    //Capture case issue type heading text
    public String getIssueTypeHeading() {
        WebElement ele = driver.findElement(accordianCaseDetails);
        visibleText(ele.findElement(accordianHeading8));
        return ele.findElement(accordianHeading8).getText();
    }
    
    //@Author : Gaurang
    //Capture case issue type description text
    public String getIssueTypeDescription() {
        WebElement ele = driver.findElement(accordianCaseDetails);
        visibleText(ele.findElement(accordianDescription8));
        return ele.findElement(accordianDescription8).getText();
    }
    
    //@Author : Gaurang
    //Capture case sub category heading text
    public String getSubCategoryHeading() {
        WebElement ele = driver.findElement(accordianCaseDetails);
        visibleText(ele.findElement(accordianHeading7));
        return ele.findElement(accordianHeading7).getText();
    }
    
    //@Author : Gaurang
    //Capture case sub category description text
    public String getSubCategoryDescription() {
        WebElement ele = driver.findElement(accordianCaseDetails);
        visibleText(ele.findElement(accordianDescription7));
        return ele.findElement(accordianDescription7).getText();
    }
    
    //@Author : Gaurang
    //Capture case ipermanent workstation number text
    public String getSourceHeading() {
        WebElement ele = driver.findElement(accordianCaseDetails);
        visibleText(ele.findElement(accordianHeading1));
        return ele.findElement(accordianHeading1).getText();
    }
    
    //@Author : Gaurang
    //Capture case permanent workstation number text
    public String getSourceDescription() {
        WebElement ele = driver.findElement(accordianCaseDetails);
        visibleText(ele.findElement(accordianDescription1));
        return ele.findElement(accordianDescription1).getText();
    }
    
    //@Author : Gaurang
    //Capture case location heading text
    public String getStudentNameHeading() {
        WebElement ele = driver.findElement(accordianCaseDetails);
        visibleText(ele.findElement(accordianHeading2));
        return ele.findElement(accordianHeading2).getText();
    }
    
    //@Author : Gaurang
    //Capture case location description text
    public String getStudentNameDescription() {
        WebElement ele = driver.findElement(accordianCaseDetails);
        visibleText(ele.findElement(accordianDescription2));
        return ele.findElement(accordianDescription2).getText();
    }
    
    //@Author : Gaurang
    //Capture case issueSubType heading text
    public String getIssueSubTypeHeading() {
        WebElement ele = driver.findElement(accordianCaseDetails);
        visibleText(ele.findElement(accordianHeading9));
        return ele.findElement(accordianHeading9).getText();
    }
    
    //@Author : Gaurang
    //Capture case issueSubType description text
    public String getIssueSubTypeDescription() {
        WebElement ele = driver.findElement(accordianCaseDetails);
        visibleText(ele.findElement(accordianDescription9));
        return ele.findElement(accordianDescription9).getText();
    }
    
    //@Author : Gaurang
    //Capture case callback mobile number heading text
    public String getCallbackMobileNumberHeading() {
        WebElement ele = driver.findElement(accordianCaseDetails);
        visibleText(ele.findElement(accordianHeading3));
        return ele.findElement(accordianHeading3).getText();
    }
    
    //@Author : Gaurang
    //Capture case allback mobile number description text
    public String getCallbackMobileNumberDescription() {
        WebElement ele = driver.findElement(accordianCaseDetails);
        visibleText(ele.findElement(accordianDescription3));
        return ele.findElement(accordianDescription3).getText();
    }
    
    //@Author : Gaurang
    //Capture case language preference heading text
    public String getLanguagePreferenceHeading() {
        WebElement ele = driver.findElement(accordianCaseDetails);
        visibleText(ele.findElement(accordianHeading4));
        return ele.findElement(accordianHeading4).getText();
    }
    
    //@Author : Gaurang
    //Capture case issueSubType description text
    public String getLanguagePreferenceDescription() {
        WebElement ele = driver.findElement(accordianCaseDetails);
        visibleText(ele.findElement(accordianDescription4));
        return ele.findElement(accordianDescription4).getText();
    }
    
    //@Author : Gaurang
    //Capture case assign to group heading text
    public String getAssignToGroupHeading() {
        WebElement ele = driver.findElement(accordianCaseDetails);
        visibleText(ele.findElement(accordianHeading5));
        return ele.findElement(accordianHeading5).getText();
    }
    
    //@Author : Gaurang
    //Capture case issueSubType description text
    public String getAssignToGroupDescription() {
        WebElement ele = driver.findElement(accordianCaseDetails);
        visibleText(ele.findElement(accordianDescription5));
        return ele.findElement(accordianDescription5).getText();
    }
    
    //@Author : Gaurang
    //Capture case attachment heading text
    public String getAttachmentHeading() {
        WebElement ele = driver.findElement(accordianCaseDetails);
        visibleText(ele.findElement(accordianHeading6));
        return ele.findElement(accordianHeading6).getText();
    }
    
    //@Author : Gaurang
    //Capture case attachment description text
    public String getAttachmentDescription() {
        WebElement ele = driver.findElement(accordianCaseDetails);
        visibleText(ele.findElement(accordianDescription6));
        return ele.findElement(accordianDescription6).getText();
    }
    
    //@Author : Gaurang
    //click timeline accordian
    public void clickTimeline() {
        visibleText(timelineText);
        try {
        jsClick(driver.findElement(timelineText));
        }
        catch(Exception e) {
            driver.findElement(timelineText).click();
        }
    }
    
    //@Author : Gaurang
    //Capture update button text
    public String getUpdateBtnText() {
        visibleText(updateBtn);
        return driver.findElement(updateBtn).getText();
    }
    
    //@Author : Gaurang
    //Set case status property
    public String setCaseStatus(String value) {
        visibleText(caseStatusLabel);
        scrollToElement(caseStatusLabel);
        WebElement parent = driver.findElement(caseStatusLabel);
        parent.click();
        selectOption(value, parent);
        return value;
    }
    
    //@Author : Gaurang
    //Set case property
    public String setCasePriority(String value) {
        try {
            Actions ac = new Actions(driver);
            ac.moveToElement(driver.findElement(casePriorityLabel)).build().perform();
        }
        catch(Exception e) {
        visibleText(casePriorityLabel);
        }
        WebElement parent = driver.findElement(casePriorityLabel);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,-1000)", "");
        clickable(casePriorityLabel);
        parent.click();
        selectOption(value, parent);
        return value;
    }
    
    //@Author : Gaurang
    //Set case due date
    public String setCaseDueDate(String role) throws InterruptedException {
        visibleText(caseDueDateLabel);
        WebElement parent = driver.findElement(caseDueDateLabel);
        parent.click();
        visibleText(parent.findElement(nextMonth));
        int month = new Random().nextInt(10);
        for(int i=0; i<month; i++) {
            jsClick(parent.findElement(nextMonth));
        }
        Thread.sleep(100);
        String currMonth = driver.findElement(By.xpath("//div[contains(@class,'react-datepicker__current-month')]")).getText().split(" ")[0];
        jsClick(driver.findElement(By.xpath("(//div[contains(@aria-label,'" + currMonth + "')])[" + Integer.toString(1 + new Random().nextInt(28)) + "]")));
        String date = getCaseDueDateLabel(role);
//        driver.findElement(createdByText).click();
        return date;
    }
    
    //@Author : Gaurang
    //Set case group property
    public String setCaseGroupRandom() {
        visibleText(caseGroupLabel);
        WebElement parent = driver.findElement(caseGroupLabel);
        jsClick(parent);
//        visibleText(parent.findElements(dropDownOption));
        List<WebElement> eles = parent.findElements(dropDownSearchable);
        Random random = new Random();
        String value = eles.get(random.nextInt(eles.size())).getText();
        System.out.println("Selected group is : "+value);
        selectSearchableOption(value);
        return value;
    }
    
    //@Author : Gaurang
    //Set case agent property
    public String setCaseAgentRandom() throws InterruptedException {
        visibleText(caseAgentLabel);
        WebElement parent = driver.findElement(caseAgentLabel);
        jsClick(parent);
        driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
//        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
//        LocalDateTime now = LocalDateTime.now();  
//        System.out.println(dtf.format(now));
        visibleText(parent.findElements(dropDownSearchable), 1);
        List<WebElement> eles = parent.findElements(dropDownSearchable);
        Random random = new Random();
        String value = eles.get(random.nextInt(eles.size())).getText();
        selectSearchableOption(value);
        return value;
    }
    
    //@Author : Gaurang
    //Click the select agent dropdown
    public void clickCaseAgent() {
        visibleText(caseAgentLabel);
        clickable(caseAgentLabel);
        WebElement parent = driver.findElement(caseAgentLabel);
        jsClick(parent);
        return;
    }
    
    //@Author : Gaurang
    //Select option from the right side property menu
    public void selectOption(String value, WebElement parent) {
        visibleText(parent.findElements(dropDownOption));
        List<WebElement> eles = parent.findElements(dropDownOption);
        for(int i=0; i<eles.size(); i++) {
            if(eles.get(i).getText().compareToIgnoreCase(value) == 0) {
               jsClick(eles.get(i));
                break;
            }
        }
    }
    
    //@Author : Gaurang
    //Select option from the right side property menu for group and agent
    public void selectSearchableOption(String value) {
        List<WebElement> eles = driver.findElements(dropDownSearchable);
        for(int i=0; i<eles.size(); i++) {
            if(eles.get(i).getText().compareToIgnoreCase(value) == 0) {
                System.out.println("clicked the option: "+value);
                eles.get(i).click();
                break;
            }
        }
    }
    
    //@Author : Gaurang
    //click the update button
    public void clickUpdate() {
        clickable(updateBtn);
        jsClick(driver.findElement(updateBtn));
    }
    
    //@Author : Gaurang
    //go to specific url
    public void gotoUrl(String url) {
        driver.get(url);
    }
    
    //@Author : Gaurang
    //Capture reply button text
    public String getReplyBtnText() {
        visibleText(replyButton);
        return driver.findElement(replyButton).getText();
    }
    
    //@Author : Gaurang
    //Capture Add note button text
    public String getAddNoteBtnText() {
        visibleText(addNoteButton);
        return driver.findElement(addNoteButton).getText();
    }
    
    //@Author : Gaurang
    //Write a reply using the reply button
    public void writeReply(String data, String emailTo, int numberOfAttachments) throws InterruptedException, IOException {
//        scrollToElement(replyButton);
        visibleText(replyButton);
        jsClick(driver.findElement(replyButton));
        Actions action = new Actions(driver);
        Thread.sleep(1000);
        visibleText(emailToInput);
        action.moveToElement(driver.findElement(emailToInput)).click().sendKeys(emailTo).sendKeys(Keys.RETURN).build().perform();
        driver.findElement(ccBtn).click();
        visibleText(driver.findElement(emailCcInput));
        action.moveToElement(driver.findElement(emailCcInput)).click().sendKeys(emailTo).sendKeys(Keys.RETURN).build().perform();
        driver.findElement(bccBtn).click();
        visibleText(driver.findElement(emailBccInput));
        action.moveToElement(driver.findElement(emailBccInput)).click().sendKeys(emailTo).sendKeys(Keys.RETURN).build().perform();
        visibleText(driver.findElement(emailCcClose));
        driver.findElement(emailCcClose).click();
        visibleText(driver.findElement(emailBccClose));
        driver.findElement(emailBccClose).click();
        visibleText(driver.findElement(emailCcInput));
        action.moveToElement(driver.findElement(emailCcInput)).click().sendKeys(emailTo).sendKeys(Keys.RETURN).build().perform();
        visibleText(driver.findElement(emailBccInput));
        action.moveToElement(driver.findElement(emailBccInput)).click().sendKeys(emailTo).sendKeys(Keys.RETURN).build().perform();
        ArrayList<String> files = new ArrayList<>();
        files.add("fileUnder5");
        files.add("excelUnder5");
        files.add("csvUnder5");
        files.add("pngUnder5");
        files.add("pdfUnder5");
        files.add("docUnder5");
        addAttachment(files, numberOfAttachments);
        driver.switchTo().frame(0);
        clickable(emailBody);
        action.moveToElement(driver.findElement(emailBody)).click().sendKeys(data).build().perform();
        driver.switchTo().defaultContent();
    }
    
    //@Author : Gaurang
    // add attachment in the replies section
    public void addAttachment(ArrayList<String> files, int numberOfAttachments) throws IOException, InterruptedException {
        String fileName = "";
        for(int i=0; i<files.size(); i++) {
            if(i == files.size()-1) {
                al = excelData.getData(files.get(i), "AttachmentController_API", "Tcid");
                fileName = fileName + System.getProperty("user.dir") + al.get(1);
            }
            else {
                al = excelData.getData(files.get(i), "AttachmentController_API", "Tcid");
                fileName = fileName + System.getProperty("user.dir") + al.get(1) + "\n";
            }
        }
        WebElement addFile = driver.findElement(By.xpath(".//input[@type='file']"));
        addFile.sendKeys(fileName);
        int i=0;
        while(checkElementExists(loader) && i<10) {
            Thread.sleep(500);
            i++;
        }
        i=0;
        while(!numberOfAttachmentsText().equalsIgnoreCase(Integer.toString(numberOfAttachments)+"  Attachments") && i<50) {
            System.out.println(numberOfAttachmentsText() + "---------" + Integer.toString(numberOfAttachments)+"  Attachments");
            System.out.println(i);
            Thread.sleep(500);
            i++;
        }
        Thread.sleep(2000);
    }
    
    //@Author : Gaurang
    // add attachment in the replies section
    public boolean addAllAttachments() throws IOException, InterruptedException {
        visibleText(addAllAttachmentsBtn);
        driver.findElement(addAllAttachmentsBtn).click();
        int numberOfAttachments = driver.findElements(allAttachmets).size();
        driver.switchTo().frame(0);
        int attachmentsAddedInEditor = driver.findElements(addAllAttachmentsText).size();
        driver.switchTo().defaultContent();
        if(numberOfAttachments != attachmentsAddedInEditor) {
            return false;
        }
        return true;
    }
    
    //@Author : Gaurang
    // remove attachments
    public void removeAttachments(int num) throws InterruptedException {
        for(int i=0; i<num; i++) {
            visibleText(removeFileBtn);
            clickable(removeFileBtn);
            driver.findElement(removeFileBtn).click();
            int j=0;
            while(checkElementExists(loader) && j<10) {
                Thread.sleep(500);
                j++;
            }
        }
    }
    
    //@Author : Gaurang
    // check the email to, cc, bcc of the replies
    public boolean checkEmailToCcBcc(String to, String cc, String bcc) {
        visibleText(replyEmailTo);
        if(!driver.findElement(replyEmailTo).getText().contains(to)) {
            return false;
        }
        visibleText(replyEmailCc);
        if(!driver.findElement(replyEmailCc).getText().contains(cc)) {
            return false;
        }
        visibleText(replyEmailBcc);
        if(!driver.findElement(replyEmailBcc).getText().contains(bcc)) {
            return false;
        }
        return true;
    }
    
    //@Author : Gaurang
    // capture number of attachments text
    public String numberOfAttachmentsText() {
        visibleText(numberOfAttachments);
        return driver.findElement(numberOfAttachments).getText();
    }
    
    //@Author : Gaurang
    //click send button 
    public void clickSendBtn() {
        visibleText(sendBtn);
        clickable(sendBtn);
        driver.findElement(sendBtn).click();
    }
    
    //@Author : Gaurang
    //click delete button 
    public void clickDeleteBtn() {
        visibleText(deleteBtn);
        driver.findElement(deleteBtn).click();
    }
    
    //@Author : Gaurang
    //get discard message
    public String discardMessage() {
        visibleText(discardMessage);
        return driver.findElement(discardMessage).getText();
    }
    
    //@Author : Gaurang
    //click yes button 
    public void clickYesBtn() {
        visibleText(yesBtn);
        jsClick(driver.findElement(yesBtn));
    }
    
    //@Author : Gaurang
    //check if editor is still present
    public boolean isEditorStillPresent() {
        return checkElementExists(editorBox);
    }
    
    //@Author : Gaurang
    //get the author from the nav menu
    public String getAuthor(String role) {
        if(role.equals("requestor") == false) {
            visibleText(userName);
        }
        return driver.findElement(userName).getText();
    }
    
    //@Author : Gaurang
    //check the author of the stepper component
    public Boolean checkAuthor(String role){
      //driver.findElement(By.xpath("//div[text()='Task']/following::span[text()='Assigned To']/following::div[contains(translate(@title, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'"+val+"')]")).click();
        try {
            visibleText(stepperContainer);
            List<WebElement> replies = driver.findElements(stepperContainer);
            try {
                jsClick(driver.findElement(By.xpath("//div[@class='stepper__author']")));
                visibleText(replies.get(0).findElement(By.xpath("//div[@class='stepper__author']")));
            }
            catch(Exception e) {
                visibleText(replies.get(0).findElement(By.xpath("//div[@class='stepper__author']")));  
            }
            return replies.get(0).findElement(By.xpath("//div[@class='stepper__author']")).getText().toLowerCase().contains(getAuthor(role).toLowerCase());
        }
        catch(StaleElementReferenceException e) {
            visibleText(stepperContainer);
            List<WebElement> replies = driver.findElements(stepperContainer);
            visibleText(replies.get(0).findElement(stepperAuthor));
            return replies.get(0).findElement(By.xpath("//div[@class='stepper__author']")).getText().toLowerCase().contains(getAuthor(role).toLowerCase());
        }
    }
    
    //@Author : Gaurang
    //check the timestamp of the stepper component
    public Boolean checkTimestamp(String role){
        String pattern = "E, dd MMM yyyy";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        Date date = new Date();
        String dateString = simpleDateFormat.format(date);
        visibleText(replyTimestamp);
        String ticketDate = driver.findElement(replyTimestamp).getText();
        if(!ticketDate.contains(dateString)) {
            return false;
        }
        pattern = "aa";
        simpleDateFormat = new SimpleDateFormat(pattern);
        dateString = simpleDateFormat.format(date);
        if(!ticketDate.contains(dateString.toUpperCase())) {
            return false;
        }
        return true;
    }
    
    //@Author : Gaurang
    //get content of the stepper component
    public String getContent(){
        List<WebElement> replies;
        try {
            visibleText(stepperContainer);
            replies = driver.findElements(stepperContainer);
            //visibleText(replies.get(0).findElement(stepperContent));
            //return replies.get(0).findElement(stepperContent).getText();
            return driver.findElement(By.xpath("//div[@class='stepper__container'][1]//div[@class='stepper__description']//p")).getText();
        }
        catch(StaleElementReferenceException ex)
        {
            visibleText(stepperContainer);
            replies = driver.findElements(stepperContainer);
            visibleText(replies.get(0).findElement(stepperContent));
            return replies.get(0).findElement(stepperContent).getText();
        }
    }
    
    //@Author : Gaurang
    //Write a reply using the reply all button
    public boolean writeReplyAll(String data) throws InterruptedException, IOException {
        visibleText(replyAllButton);
        jsClick(driver.findElement(replyAllButton));
        Actions action = new Actions(driver);
        Thread.sleep(1000);
        visibleText(emailToInput);
        System.out.println(driver.findElement(replyEmailTo).getText());
        String[] emails = driver.findElement(replyEmailTo).getText().split(" ");
        for(int i=1; i<emails.length; i++) {
            System.out.println(emails[i]);
            System.out.println(driver.findElement(By.xpath("//div[@class='email_template__to']//div[@class='email__input__list_item']["+Integer.toString(i)+"]")).getText().split(" ")[0]);
            if(!emails[i].contains(driver.findElement(By.xpath("//div[@class='email_template__to']//div[@class='email__input__list_item']["+Integer.toString(i)+"]")).getText().split(" ")[0])) {
                return false;
            }
        }
//        visibleText(driver.findElement(emailCcInput));
//        System.out.println(driver.findElement(replyEmailCc).getText());
//        emails = driver.findElement(replyEmailCc).getText().split(" ");
//        for(int i=1; i<emails.length; i++) {
//            if(!emails[i].contains(driver.findElement(By.xpath("//div[@class='email_template__cc']//div[@class='email__input__list_item']["+Integer.toString(i)+"]")).getText().split(" ")[0])) {
//                return false;
//            }
//        }
//        visibleText(driver.findElement(emailBccInput));
//        System.out.println(driver.findElement(replyEmailBcc).getText());
//        emails = driver.findElement(replyEmailBcc).getText().split(" ");
//        for(int i=1; i<emails.length; i++) {
//            if(!emails[i].contains(driver.findElement(By.xpath("//div[@class='email_template__bcc']//div[@class='email__input__list_item']["+Integer.toString(i)+"]")).getText().split(" ")[0])) {
//                return false;
//            }
//        }
        driver.switchTo().frame(0);
        clickable(emailBody);
        action.moveToElement(driver.findElement(emailBody)).click().sendKeys(data).build().perform();
        driver.switchTo().defaultContent();
        return true;
    }
    
    //@Author : Gaurang
    //Write a note using the note button
    public void writeNote(String data, int numberOfAttachments) throws InterruptedException, IOException {
//        scrollToElement(replyButton);
        visibleText(addNoteButton);
        driver.findElement(addNoteButton).click();
        Thread.sleep(1000);
        ArrayList<String> files = new ArrayList<>();
        files.add("fileUnder5");
        files.add("excelUnder5");
        files.add("csvUnder5");
        files.add("pngUnder5");
        files.add("pdfUnder5");
        files.add("docUnder5");
        addAttachment(files, numberOfAttachments);
        driver.switchTo().frame(0);
        Actions action = new Actions(driver);
        action.moveToElement(driver.findElement(emailBody)).click().sendKeys(data).build().perform();
        driver.switchTo().defaultContent();
    }
    
    //@Author: Gaurang
    //Click send note button
    public void clickSubmitNoteBtn() {
        visibleText(submitNoteBtn);
        driver.findElement(submitNoteBtn).click();
    }
    
    //@Author : Gaurang
    //click cancel button 
    public void clickCancelBtn() {
        visibleText(cancelBtn);
        driver.findElement(cancelBtn).click();
    }
    
    //@Author : Gaurang
    //click cancel button 
    public void clickLeaveWithoutSavingBtn() {
        visibleText(leaveWithoutSavingBtn);
        driver.findElement(leaveWithoutSavingBtn).click();
    }
    
    //@Author : Gaurang
    //check the options in the case status dropdown
    public Boolean checkCaseStatusOptions() throws IOException {
        clickable(caseStatusLabel);
        WebElement parent = driver.findElement(caseStatusLabel);
        jsClick(parent);
        
        return checkOptions(parent, "caseStatusOptions");
    }
    
    //@Author : Gaurang
    //check the options in the case priority dropdown
    public Boolean checkCasePriorityOptions() throws IOException {
        clickable(casePriorityLabel);
        WebElement parent = driver.findElement(casePriorityLabel);
        parent.click();
        
        return checkOptions(parent, "casePriorityOptions");
    }
    
    //@Author : Gaurang
    //check options in the dropdown according to the excel sheet
    public Boolean checkOptions(WebElement parent, String rowName) throws IOException {
        al = excelData.getData(rowName, "CaseDetailsScreen", "Tcid");
        visibleText(parent.findElement(dropDownOption));
        List<WebElement> options = parent.findElements(dropDownOption);
        List<String> optionsText = new ArrayList<String>();
        options.forEach((option) -> {
            optionsText.add(option.getText());
        });
        for(int i=1; i<=optionsText.size(); i++) {
            if(optionsText.contains(al.get(i)) != true) {
                return false;
            }
        }
        parent.click();
        return true;
    }
    
    //@Author : Gaurang
    //search in the Expand search box
    public void typeInExpandedSearch(String ticketId) {
        clickable(globalSearch);
        driver.findElement(globalSearch).click();
        visibleText(expandedSearch);
        Actions action = new Actions(driver);
        action.moveToElement(driver.findElement(expandedSearch)).click().sendKeys(ticketId).sendKeys(Keys.RETURN).build().perform();
    }
    
    //@Author : Gaurang
    //check for the visibility of the error message
    public boolean iSSelectGroupFirstMessagePresent() {
        return checkElementExists(errorMessageSelectGroupFirst);
    }
    
    //@Author : Gaurang
    // Select the correct project for the ticket that was just created
    public void selectProject(String category) {
        try {
            visibleText(projectDropdown);
            clickable(projectDropdown);
            driver.findElement(projectDropdown).click();
            visibleText(dropdownOption);
            List<WebElement> options = driver.findElements(dropdownOption);
            for(int i=0; i<options.size(); i++) {
                if(options.get(i).getText().compareToIgnoreCase(category) == 0) {
                    options.get(i).click();
                    break;
                }
            }
        }
        catch (StaleElementReferenceException e) {
            visibleText(projectDropdown);
            clickable(projectDropdown);
            jsClick(driver.findElement(projectDropdown));
            visibleText(dropdownOption);
            List<WebElement> options = driver.findElements(dropdownOption);
            for(int i=0; i<options.size(); i++) {
                if(options.get(i).getText().compareToIgnoreCase(category) == 0) {
                    options.get(i).click();
                    break;
                }
            }
        }
    }
    
    public boolean checkCaseDetails(HashMap<String, String> ticketData) {
        HashMap<String, String> caseDetails = new HashMap<String, String>();
        List<WebElement> eles = driver.findElements(caseDetailsElements);
        
        for(int i=0; i<eles.size(); i++) {
            visibleText(eles.get(i).findElement(casePropertyHeader));
            visibleText(eles.get(i).findElement(casePropertyDescription));
            System.out.println(eles.get(i).findElement(casePropertyHeader).getText() + "----" + eles.get(i).findElement(casePropertyDescription).getText());
            caseDetails.put(eles.get(i).findElement(casePropertyHeader).getText(), eles.get(i).findElement(casePropertyDescription).getText());
        }
        System.out.println("-----------------------------------");
        for(Map.Entry<String, String> m: caseDetails.entrySet()) {
            String header = m.getKey().trim();
            String description = m.getValue().trim(); 
            System.out.println(header+"----"+description);
            if(ticketData.containsKey(header)) {
                if(ticketData.get(header).compareToIgnoreCase(description) != 0) {
                    System.out.println(header + "-" + description);
                    return false;
                }
            }
            else {
                System.out.println(header);
                return false;
            }
        }
        return true;
    }
    
    // ------------------------------------------------------------------------------------------------
    
    public boolean visibleText(By element)
    {
        WebDriverWait wait= new WebDriverWait(driver, 10);
        
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));
        
        return false;
    }

    public boolean visibleText(WebElement element)
    {
        WebDriverWait wait= new WebDriverWait(driver, 10);
        
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElements(element));
        
        return false;
    }

    public boolean visibleText(List<WebElement> element)
    {
        WebDriverWait wait= new WebDriverWait(driver, 10);
        
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElements(element));
        
        return false;
    }
    
    public boolean visibleText(List<WebElement> element, int sec)
    {
        WebDriverWait wait= new WebDriverWait(driver, sec);
        
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElements(element));
        
        return false;
    }
    
    public boolean clickable(By element)
    {
        WebDriverWait wait= new WebDriverWait(driver, 10);
        
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));
        
        return false;
    }
    
    public void scrollToElement(By element) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,-1000)", "");
    }
    
    public void jsClick(WebElement el) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].click();", el);
        } catch (Exception e) {
            System.out.println("=============================================================");
            System.out.println("Exception-jsClick(): " + e.getMessage());
            //takeScreenShot();
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }
    
    public boolean checkElementExists(By xpath) {
        boolean result = false;
        try {
            driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
            driver.findElement(xpath);
            result = true;
        }
        catch(org.openqa.selenium.NoSuchElementException ex) {
            result = false;
        }
        finally {
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        return result;
    }
}
