package pageObjects;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PO_CreateGroupPage {
    
    WebDriver driver;
    WebDriverWait wait;
    
    public PO_CreateGroupPage(WebDriver driver) {
        
        this.driver = driver;
        wait = new WebDriverWait(driver, 10);
    }
    
    // ----------------------------------------------------------------------------------------------------
    // xpaths of components in sidebar section of create group page
    // ----------------------------------------------------------------------------------------------------
    private String sidebarByjusLogoImageXpath = "//div[@data-testid='navMenu']/img";
    private String sidebarCasesTextXpath = "//div[@data-testid='navMenu__item']//div[text()='Cases']";
    private String sidebarGroupsTextXpath = "//div[@data-testid='navMenu__item']//div[text()='Groups']";
    private String sidebarAgentsTextXpath = "//div[@data-testid='navMenu__item']//div[text()='Agents']";
    private String sidebarMailboxTextXpath = "//div[@data-testid='navMenu__item']//div[text()='Mailbox']";
    private String sidebarLogoutTextXpath = "//div[@data-testid='navMenu__item']//div[text()='Logout']";
    
    // ----------------------------------------------------------------------------------------------------
    // xpaths of components in header section of create group page
    // ----------------------------------------------------------------------------------------------------
    private String headerCreateButtonXpath = "//div[@class='header__right-section']//button[text()='CREATE']";
    private String headerSearchCasesButtonXpath = "//div[@class='header__right-section']//button[@class='search-bar__icon']";
    
    // ----------------------------------------------------------------------------------------------------
    // xpaths of components in create group form of create group page
    // ----------------------------------------------------------------------------------------------------
    private String groupNameFieldXpath = "//div[contains(@class,'formLabel__container')]//div[contains(text(),'Group Name')]/parent::div/parent::div";
    private String groupDescriptionFieldXpath = "//div[contains(@class,'formLabel__container')]//div[contains(text(),'Group Description')]/parent::div/parent::div";
    private String addAgentsFieldXpath = "//div[contains(@class,'formLabel__container')]//div[contains(text(),'Add Agents')]/parent::div/parent::div";
    private String groupPropertyFieldXpath = "//div[contains(@class,'formLabel__container')]//div[contains(text(),'Group Property')]/parent::div/parent::div";
    private String saveButtonXpath = "//button[text()='Save']";
    private String cancelButtonXpath = "//button[text()='Cancel']";
    private String updateButtonXpath = "//button[text()='Update']";
    
    // ----------------------------------------------------------------------------------------------------
    // xpaths of components in popup
    // ----------------------------------------------------------------------------------------------------
    private String popupCloseIconXpath = "//div[@data-testid='modal-container']//img[contains(@src,'closeSlider')]";
    private String popupMessageXpath = "//div[@data-testid='modal-container']//div[contains(@class,'modal-ui_message')]";
    
    
    // @Author = Ankur
    // go to group list page
    public void goToGroupListPage() {
        
        click(By.xpath(sidebarGroupsTextXpath));
    }
    
    // @Author = Ankur
    // go to create group page
    public void goToCreateGroupPage() {
        
        goToGroupListPage();
        click(By.xpath(headerCreateButtonXpath));
    }
    
    // -------------------------------------------------
    // ******************** SIDEBAR ********************
    // -------------------------------------------------
    
//    // @Author = Ankur
//    // @Description = is an element present
//    public Boolean isDisplayed(String xpath) {
//        
//        By ele = By.xpath(xpath);
//        
//        try {
//            
//            return driver.findElements(ele).size() > 0;
//        }
//        catch(Exception e) {
//            
//            driver.navigate().refresh();
//            return driver.findElements(ele).size() > 0;
//            
//        }
//    }
    
    public boolean checkElementExists(String xpath) {
        boolean result = false;
        try {
            driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
            driver.findElement(By.xpath(xpath));
        }
        catch(org.openqa.selenium.NoSuchElementException ex) {
            result = false;
        }
        finally {
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        return result;
    }
    
    // @Author = Ankur
    // @Description = is sidebar mailbox icon present
    public Boolean isSidebarMailboxIconPresent() {
        
        return checkElementExists(sidebarMailboxTextXpath + "/parent::div//img");
    }
    
    // @Author = Ankur
    // @Description = is sidebar mailbox text present
    public Boolean isSidebarMailboxTextPresent() {
        
        return checkElementExists(sidebarMailboxTextXpath);
    }
    
    // @Author = Ankur
    // @Description = Get sidebar byjus logo source
    public String getSidebarByjusLogoSource() {
        
        return getAttributeValue(By.xpath(sidebarByjusLogoImageXpath), "src").toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = Get sidebar cases icon source
    public String getSidebarCasesIconSource() {
        
        return getAttributeValue(By.xpath(sidebarCasesTextXpath + "/parent::div//img"), "src").toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = Get sidebar cases text
    public String getSidebarCasesText() {
        
        return getText(By.xpath(sidebarCasesTextXpath)).toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = Get sidebar groups icon source
    public String getSidebarGroupsIconSource() {
        
        return getAttributeValue(By.xpath(sidebarGroupsTextXpath + "/parent::div//img"), "src").toLowerCase();
    }

    // @Author = Ankur
    // @Description = Get sidebar groups text
    public String getSidebarGroupsText() {
        
        return getText(By.xpath(sidebarGroupsTextXpath)).toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = Get sidebar agents icon source
    public String getSidebarAgentsIconSource() {
        
        return getAttributeValue(By.xpath(sidebarAgentsTextXpath + "/parent::div//img"), "src").toLowerCase();
    }
    
    // @Author = Ankur
    // Description = Get sidebar agents text
    public String getSidebarAgentsText() {
        
        return getText(By.xpath(sidebarAgentsTextXpath)).toLowerCase();
    }
    
    // @Author = Ankur
    // @Descriptionn = Get sidebar mailbox icon source
    public String getSidebarMailboxIconSource() {
        
        return getAttributeValue(By.xpath(sidebarMailboxTextXpath + "/parent::div//img"), "src").toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = Get sidebar mailbox text source
    public String getSidebarMailboxText() {
        
        return getText(By.xpath(sidebarMailboxTextXpath)).toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = Get sidebar logout icon source
    public String getSidebarLogoutIconSource() {
        
        return getAttributeValue(By.xpath(sidebarLogoutTextXpath + "/parent::div//img"), "src").toLowerCase();
    }
    
    //@Author = Ankur
    // Description = Get sidebar logout text
    public String getSidebarLogoutText() {
        
        return getText(By.xpath(sidebarLogoutTextXpath)).toLowerCase();
    }
    
    // ------------------------------------------------
    // ******************** HEADER ********************
    // ------------------------------------------------
    
    // @Author = Ankur
    // @Description = Get header groups text
    public String getHeaderGroupsText() {
        
        return getText(By.xpath("//div[@class='header__left-section']")).toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = Get header create button text
    public String getHeaderCreateButtonText() {
        
        return getText(By.xpath(headerCreateButtonXpath)).toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = Get header create button plus icon source
    public String getHeaderCreateButtonPlusIconSource() {
        
        return getAttributeValue(By.xpath(headerCreateButtonXpath + "//img"), "src").toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = Get header search cases icon source
    public String getHeaderSearchIconSource() {
        
        return getAttributeValue(By.xpath(headerSearchCasesButtonXpath + "//img"), "src").toLowerCase();
    }    
    
    
    // ------------------------------------------------------------------------------
    // ******************** CREATE GROUP FORM - GROUP NAME FIELD ********************
    // ------------------------------------------------------------------------------
    
    // @Author = Ankur
    // @Description = get group name field label text
    public String getGroupNameFieldLabelText() {
        
        return getText(By.xpath(groupNameFieldXpath + "//div[text()='Group Name']")).toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = returns true if asterisk is present after group name field
    public Boolean isGroupNameMandatoryField() {
        
        return getWebElements(By.xpath(groupNameFieldXpath + "//div[text()='*']")).size() == 1;
    }
    
    // @Author = Ankur
    // @Description = get group name field placeholder value
    public String getGroupNameFieldPlaceholderValue() {
        
        return getAttributeValue(By.xpath(groupNameFieldXpath + "//input"), "placeholder").toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = set group name value
    public void SetGroupName(String data) {
        
        setInputFieldValue(By.xpath(groupNameFieldXpath + "//input"), data);
    }
    
    // @Author = Ankur
    // @Description = clear group name
    public void clearGroupName() {
        
        String OS = System.getProperty("os.name", "generic").toLowerCase(Locale.ENGLISH);
        
        if ((OS.indexOf("mac") >= 0) || (OS.indexOf("darwin") >= 0)) {
            
            driver.findElement(By.xpath(groupNameFieldXpath + "//input")).sendKeys(Keys.COMMAND + "a");
        }
        else if (OS.indexOf("win") >= 0){
            
            driver.findElement(By.xpath(groupNameFieldXpath + "//input")).sendKeys(Keys.CONTROL + "a");
        }
        
        driver.findElement(By.xpath(groupNameFieldXpath + "//input")).sendKeys(Keys.BACK_SPACE);
    }
    
    // @Author = Ankur
    // @Description = get group name value
    public String getGroupName() {
        
        return getInputFieldValue(By.xpath(groupNameFieldXpath + "//input"));
    }
    
    // @Author = Ankur
    // @Description = get max length of group name field
    public String getMaxLengthOfGroupNameField() {
        
        return driver.findElement(By.xpath(groupNameFieldXpath + "//input")).getAttribute("maxlength");
    }
    
    // -------------------------------------------------------------------------------------
    // ******************** CREATE GROUP FORM - GROUP DESCRIPTION FIELD ********************
    // -------------------------------------------------------------------------------------
    
    // @Author = Ankur
    // @Description = get group description field label text
    public String getGroupDescriptionFieldLabelText() {
        
        return getText(By.xpath(groupDescriptionFieldXpath + "//div[text()='Group Description']")).toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = get group description field placeholder value
    public String getGroupDescriptionFieldPlaceholderValue() {
        
        return getAttributeValue(By.xpath(groupDescriptionFieldXpath + "//input"), "placeholder").toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = set group description value
    public void setGroupDescription(String data) {
        
        setInputFieldValue(By.xpath(groupDescriptionFieldXpath + "//input"), data);
    }
    
    // @Author = Ankur
    // @Description = set group description value
    public String getGroupDescriptionValue() {
        
        return getInputFieldValue(By.xpath(groupDescriptionFieldXpath + "//input"));
    }
    
    // @Author = Ankur
    // @Description = get max length of group description field
    public String getMaxLengthOfGroupDescriptionField() {
        
        return driver.findElement(By.xpath(groupDescriptionFieldXpath + "//input")).getAttribute("maxlength");
    }
    
    // ------------------------------------------------------------------------------
    // ******************** CREATE GROUP FORM - ADD AGENTS FIELD ********************
    // ------------------------------------------------------------------------------
    
    // @Author = Ankur
    // @Description = get add agents field label text
    public String getAddAgentsFieldLabelText() {
        
        return getText(By.xpath(addAgentsFieldXpath + "//div[text()='Add Agents']")).toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = get add agents field placeholder value
    public String getAddAgentsFieldPlaceholderValue() {
        
        return getAttributeValue(By.xpath(addAgentsFieldXpath + "//input"), "placeholder").toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = add agent
    private void addAgent(String agentName) {
        
        setInputFieldValue(By.xpath(addAgentsFieldXpath + "//input"), agentName);
        
        String optionXpath = "//div[@class='selectSearch__searchOptionsList']//div[contains(text(),'" + agentName + "')][1]/parent::div";
        
        if(driver.findElement(By.xpath(optionXpath + "//input")).isSelected())
            return;
        
        click(By.xpath(optionXpath + "//input"));
    }
    
    // @Author = Ankur
    // @Description = add agents 
    public void addAgents(List<String> agentList) {
        
        for(int i = 0; i < agentList.size(); ++i) {
            
            addAgent(agentList.get(i));
        }
    }
    
    // ----------------------------------------------------------------------------------
    // ******************** CREATE GROUP FORM - GROUP PROPERTY FIELD ********************
    // ----------------------------------------------------------------------------------
    
    // @Author = Ankur
    // @Description = get group property field label text
    public String getGroupPropertyFieldLabelText() {
        
        return getText(By.xpath(groupPropertyFieldXpath + "//div[contains(text(),'Group Property')]")).toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = returns true is asterisk is present after group property field
    public Boolean isGroupPropertyMandatoryField() {
        
        return getWebElements(By.xpath(groupPropertyFieldXpath + "//div[text()='*']")).size() == 1;
    }
    
    // @Author = Ankur
    // @Description = get group property field placeholder value
    public String getGroupPropertyFieldPlaceholderValue() {
        
        return getAttributeValue(By.xpath(groupPropertyFieldXpath + "//input"), "placeholder").toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = set group property value
    public void setGroupProperty(String data) {
        
        setInputFieldValue(By.xpath(groupPropertyFieldXpath + "//input"), data);
    }
    
    // @Author = Ankur
    // @Description = get group property value 
    public String getGroupPropertyValue() {
        
        return getInputFieldValue(By.xpath(groupPropertyFieldXpath + "//input"));
    }
    
    // @Author = Ankur
    // @Description = clear group property
    public void clearGroupProperty() {
        
        String OS = System.getProperty("os.name", "generic").toLowerCase(Locale.ENGLISH);
        
        if ((OS.indexOf("mac") >= 0) || (OS.indexOf("darwin") >= 0)) {
            
            driver.findElement(By.xpath(groupPropertyFieldXpath + "//input")).sendKeys(Keys.COMMAND + "a");
        }
        else if (OS.indexOf("win") >= 0){
            
            driver.findElement(By.xpath(groupPropertyFieldXpath + "//input")).sendKeys(Keys.CONTROL + "a");
        }
        
        driver.findElement(By.xpath(groupPropertyFieldXpath + "//input")).sendKeys(Keys.BACK_SPACE);
    }
    
    // @Author = Ankur
    // @Description = Get group property warning message text
    public String getGroupPropertyWarningMessage() {
        
        return getText(By.xpath(groupPropertyFieldXpath + "//div[contains(@class,'errorText')]")).toLowerCase();
    }
    
    // -------------------------------------------------------------------------
    // ******************** CREATE GROUP FORM - SAVE BUTTON ********************
    // -------------------------------------------------------------------------
    
    // @Author = Ankur
    // @Description = Get save button text
    public String getSaveButtonText() {
        
        return getText(By.xpath(saveButtonXpath));
    }
    
    // @Author = Ankur
    // @Description = Click on save button
    public void clickSaveButton() {
        
        clickButton(By.xpath(saveButtonXpath));
    }
    
    // @Author = Ankur
    // @Description = Returns true if save button is enabled
    public Boolean isSaveButtonEnabled() {
        
        return driver.findElement(By.xpath(saveButtonXpath)).isEnabled();
    }
    
    // @Author = Ankur
    // @Description = Returns true is save button is disabled
    public Boolean isSaveButtonDisabled() {
        
        return !isSaveButtonEnabled();
    }
    
    // ---------------------------------------------------------------------------
    // ******************** CREATE GROUP FORM - CANCEL BUTTON ********************
    // ---------------------------------------------------------------------------
    
    // @Author = Ankur
    // @Description = Get cancel button text
    public String getCancelButtonText() {
        
        return getText(By.xpath(cancelButtonXpath));
    }
    
    // @Author = Ankur
    // @Description = Click on cancel button
    public void clickCancelButton() {
        
        clickButton(By.xpath(cancelButtonXpath));
    }
    
    // ---------------------------------------------------------------------------
    // ******************** CREATE GROUP FORM - UPDATE BUTTON ********************
    // ---------------------------------------------------------------------------
    
    // @Author = Ankur
    // @Description = Click on save button
    public void clickUpdateButton() {
        
        clickButton(By.xpath(updateButtonXpath));
    }
    
    // @Author = Ankur
    // get agent names
    public List<String> getAgentNames(int n) {
        
        List<WebElement> agentsWE = getWebElements(By.xpath("//div[@class='selectSearch__searchOptionsList__item']//div"));
        List<String> agents = new ArrayList<String>();
        
        for(WebElement agentWE: agentsWE) {
            
            String agent = agentWE.getText().split("-")[0].trim();
            
            if(agent.length() > 0)
                agents.add(agent);
        }
        
        Collections.shuffle(agents);
        agents = agents.subList(0, Math.min(n, agents.size()));
        
        return agents;
    }
    
    // -----------------------------------------------
    // ******************** POPUP ********************
    // -----------------------------------------------
    
    // @Author = Ankur
    // @Description = close popup
    public void closePopup() {
        
        waitForSeconds(1);
        click(popupCloseIconXpath);
    }
    
    // @Author = Ankur
    // @Description = get popup message
    public String getPopupMessage() {
        
        return getText(popupMessageXpath);
    }
    
    // ---------------------------------------------------------
    // ******************** GENERIc METHODS ********************
    // ---------------------------------------------------------
    
    // @Author = Ankur
    // get input field value
    public String getInputFieldValue(By e) {
        
        return wait.until(ExpectedConditions.visibilityOfElementLocated(e)).getAttribute("value");
    }
    
    // @Author = Ankur
    // get input field value
    public String getInputFieldValue(String xpath) {
        
        By e = By.xpath(xpath);
        return wait.until(ExpectedConditions.visibilityOfElementLocated(e)).getText();
    }
    
    // @Author = Ankur
    // clear input field value
    public void clearInputFieldValue(By e) {
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(e)).clear();
    }
    
    // @Author = Ankur
    // set input field value
    public void setInputFieldValue(By e, String data) {
        
        new WebDriverWait(driver, 50).until(ExpectedConditions.visibilityOfElementLocated(e)).clear();
        new WebDriverWait(driver, 50).until(ExpectedConditions.visibilityOfElementLocated(e)).sendKeys(data);
    }
    
    // @Author = Ankur
    // get text in an element
    public String getText(By e) {
        
        return new WebDriverWait(driver, 50).until(ExpectedConditions.visibilityOfElementLocated(e)).getText();
    }
    
    // @Author = Ankur
    // @Description = get text
    public String getText(String xpath) {
        
        By e = By.xpath(xpath);
        return wait.until(ExpectedConditions.visibilityOfElementLocated(e)).getText().toLowerCase();
    }
    
    // @Author = Ankur
    // get attribute value of an element
    public String getAttributeValue(By e, String attribute) {
        
        return new WebDriverWait(driver, 50).until(ExpectedConditions.visibilityOfElementLocated(e)).getAttribute(attribute);
    }
    
    // @Author = Ankur
    // click an element
    public void click(By e) {
        
        new WebDriverWait(driver, 50).until(ExpectedConditions.visibilityOfElementLocated(e));
        new WebDriverWait(driver, 50).until(ExpectedConditions.elementToBeClickable(e)).click();
    }
    
    // @Author = Ankur
    // click an element
    public void click(String xpath) {
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath))).click();
    }
    
    // @Author = Ankur
    // click a button
    public void clickButton(By e) {
        
        new WebDriverWait(driver, 50).until(ExpectedConditions.visibilityOfElementLocated(e));
        new WebDriverWait(driver, 50).until(ExpectedConditions.elementToBeClickable(e)).click();
    }
    
    // @Author = Ankur
    // get web elements
    public List<WebElement> getWebElements(By e) {
        
        return new WebDriverWait(driver, 50).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(e));
    }

    public boolean isToastPresent(String toastMessage) {
        
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='" + toastMessage + "']")));
        return true;
    }
    
    // @Author = Ankur
    // @Description = wait for some time
    public void waitForSeconds(int time) {
        
        try {
            Thread.sleep(time * 1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
