package pageObjects;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PO_AgentList {
    
    private WebDriver driver;
    private String filterRole;
    private List<WebElement> agentList;
    private List<String> dropDownFilterList = new ArrayList<String>();
    private String email = "";
    public static By tag = By.tagName("html");
    
    
    // left side hamburger menu
    private By casesTile = By.xpath("//div[@class='menuItems-Wrapper']//div[text()='Cases']");
    private By groupsTile = By.xpath("//div[@class='menuItems-Wrapper']//div[text()='Groups']");
    private By agentsTile = By.xpath("//div[@class='menuItems-Wrapper']//div[text()='Agents']");
    private By mailboxTile = By.xpath("//div[contains(@class,'menuItems-Wrapper')]//div[text()='Mailbox']");
    private By logoutTile = By.xpath("//div[@class='menuItems-Wrapper']//div[text()='Logout']");
    private By selectedTile = By.xpath("//div[@class='menuItems-Wrapper menuItems-Wrapper--selected']");
    
    
    //Screen Header Section
    private By createBtn = By.xpath("//button[contains(text(),'CREATE')]");
    private By searchIcon = By.xpath("//div[@data-testid='search-bar']");
    private By agentsHeader = By.xpath("//div[@class='header']//div[text()='Agents']");
    
    
    //AgentList Header Section
    private By listHeaderAgentName = By.xpath("//div[@class='agent-list__header__agent-name']");
    private By listHeaderEmail = By.xpath("//div[@class='agent-list__header__agent-email']");
    private By listHeaderRole = By.xpath("//div[@class='agent-list__header__agent-role']");
    private By listHeaderGroup = By.xpath("//div[@class='agent-list__header__agent-group']");
    private By listHeaderLastLogin = By.xpath("//div[@class='agent-list__header__agent-last-login']");
    
    
    //AgentList Section
    private String expandCollapseIcon = "(//div[@class='agent-list__container__item__expand-collapse'])";
    private By agentTile = By.xpath("//div[@class='agent-list__container__item']");
    private By role = By.xpath("./child::div[@class='agent-list__container__item__agent-role']//div[@class='badges__element__card__text']");
    
    
    //Filter Section
    private By filterIcon = By.xpath("//div[@class='filter__container__text']");
    private By dropDownBox = By.xpath("//div[@class='multi__dropdown__dropdown']");
    private By dropDownItems = By.xpath("//div[@class='dropdown__dropdownOption']");
    private By applyButton = By.xpath("//button[text()='Apply']");
    private By sliderClose = By.xpath("//img[@class='slider__close']");
    private By emailInput = By.xpath("//input[@class='input']");
    
    
    //Pagination Section
    private By prevArrow = By.xpath("(//button[@data-testid='custom-button-component'])[1]");
    private By nextArrow = By.xpath("(//button[@data-testid='custom-button-component'])[2]");
    

    private By fallbackScreen = By.xpath("//div[text()='No agents found with the filter applied']");

    
    // @Author = Pratik
    // Constructor
    public PO_AgentList(WebDriver driver) {
        this.driver = driver;
    }
    
    
    // @Author = Pratik
    // Capture the Create Button and return the Text inside it.
    public String getCreateBtn() {
        visibleText(createBtn);
        return driver.findElement(createBtn).getText();
    }
    
    
    
    // @Author = Pratik
    // Capture the Cases Tile and return the Text inside it.
    public String getCasesTile() {
        visibleText(casesTile);
        return driver.findElement(casesTile).getText();
    }
    

    // @Author = Pratik
    // Capture the Groups Tile and return the Text inside it.
    public String getGroupsTile() {
        visibleText(groupsTile);
        return driver.findElement(groupsTile).getText();
    }
    

    // @Author = Pratik
    // Capture the Agents Tile and return the Text inside it.
    public String getAgentsTile() {
        visibleText(agentsTile);
        return driver.findElement(agentsTile).getText();
    }
    

    // @Author = Pratik
    // Capture the Mailbox Tile and return the Text inside it.
    public String getMailboxTile() {
        visibleText(mailboxTile);
        return driver.findElement(mailboxTile).getText();
    }
    

    // @Author = Pratik
    // Capture the Logout Tile and return the Text inside it.
    public String getLogoutTile() {
        visibleText(logoutTile);
        return driver.findElement(logoutTile).getText();
    }
    

    // @Author = Pratik
    // Capture the Search Icon.
    public Boolean checkSearchIcon() {
        visibleText(searchIcon);
        return true;
    }
    

    // @Author = Pratik
    // Capture the Selected Tile and return the Text inside it.
    public String getSelectedTile() {
        visibleText(selectedTile);
        return driver.findElement(selectedTile).getText();
    }
    

    // @Author = Pratik
    // Capture the Agents left Header and return the Text inside it.
    public String getAgentsHeader() {
        visibleText(agentsHeader);
        return driver.findElement(agentsHeader).getText();
    }
    

    // @Author = Pratik
    // Capture the AgentName Heading from AgentList Header and return the Text inside it.
    public String getListHeaderAgentName() {
        visibleText(listHeaderAgentName);
        return driver.findElement(listHeaderAgentName).getText();
    }
    

    // @Author = Pratik
    // Capture the Email Heading from AgentList Header and return the Text inside it.
    public String getListHeaderEmail() {
        visibleText(listHeaderEmail);
        return driver.findElement(listHeaderEmail).getText();
    }
    

    // @Author = Pratik
    // Capture the Role Heading from AgentList Header and return the Text inside it.
    public String getListHeaderRole() {
        visibleText(listHeaderRole);
        return driver.findElement(listHeaderRole).getText();
    }
    

    // @Author = Pratik
    // Capture the Group Heading from AgentList Header and return the Text inside it.
    public String getListHeaderGroup() {
        visibleText(listHeaderGroup);
        return driver.findElement(listHeaderGroup).getText();
    }
    

    // @Author = Pratik
    // Capture the Last Login Heading from AgentList Header and return the Text inside it.
    public String getListHeaderLastLogin() {
        visibleText(listHeaderAgentName);
        return driver.findElement(listHeaderLastLogin).getText();
    }
    

    // @Author = Pratik
    // Capture the Filter Icon and return the Text inside it.
    public String getFilterIcon() {
        visibleText(filterIcon);
        return driver.findElement(filterIcon).getText();
    }
    

    // @Author = Pratik
    // Click the Filter Icon.
    public Boolean isFilterIconClickable() {
        clickable(filterIcon);
        return true;
    }
    
    // @Author = Pratik
    // Go to AgentList Screen after a succesful Login.
    public void goToAgentListScreen() throws InterruptedException {
        clickable(agentsTile);
        Thread.sleep(1000);
        jsClick(driver.findElement(agentsTile));
    }
    

    // @Author = Pratik
    // Capture the Expand-Collapse Icon and check if it changes automatically after clicking. 
    public Boolean checkExpandCollapseIcon() {
        visibleText(By.xpath(expandCollapseIcon+"[1]"));
        String beforeClickImage = driver.findElement(By.xpath(expandCollapseIcon+"[1]//img")).getAttribute("src");
        driver.findElement(By.xpath(expandCollapseIcon+"[1]//img")).click();
        
        email = driver.findElement(By.xpath("(//div[@class='agent-list__container__item__agent-email'])[1]")).getText();
        
        String afterClickImage = driver.findElement(By.xpath(expandCollapseIcon+"[1]//img")).getAttribute("src");
        driver.findElement(By.xpath(expandCollapseIcon+"[1]//img")).click();
        
        return !beforeClickImage.equals(afterClickImage);
    }
    
    
    // @Author = Pratik
    // Apply the i-th number filter in the Roles Dropdown(in Filter Section).
    public void applyFilter(int ind) throws InterruptedException {
        //driver.findElement(filterIcon).scrollIntoView();
        clickable(filterIcon);
        driver.findElement(filterIcon).click();
        
        clickable(dropDownBox);
        driver.findElement(dropDownBox).click();
        
        By currentXpath = By.xpath("//div[@class='dropdown__dropdownOption'][text()='"+dropDownFilterList.get(ind).toLowerCase()+"']"); 
        
        filterRole = dropDownFilterList.get(ind);
        
        clickable(currentXpath);
        try {
        driver.findElement(currentXpath).click();
        }
        catch(Exception e) {
            jsClick(driver.findElement(currentXpath));   
        }
        
        clickable(applyButton);
        driver.findElement(applyButton).click();
    }
    
    
    // @Author = Pratik
    // Returns the number of agents currently present in the screen.
    public int getAgentListSize() {
        visibleText(agentTile);
        agentList = driver.findElements(agentTile);
        return agentList.size();
    }
    
    
    // @Author = Pratik
    // Returns the number of Roles available in the Filter Dropdown. 
    public int getDropDownListSize() {
        clickable(filterIcon);
        driver.findElement(filterIcon).click();
        
        clickable(dropDownBox);
        driver.findElement(dropDownBox).click();
        
        visibleText(dropDownItems);
        
        List<WebElement> elements = driver.findElements(dropDownItems);
        int dropDownSize = elements.size();
        
        for(int i=0; i<dropDownSize; i++) {
            dropDownFilterList.add(elements.get(i).getText());
        }
        
        clickable(sliderClose);
        driver.findElement(sliderClose).click();
        
        return dropDownSize;
    }
    
    // @Author = Pratik
    // check that 'Requestor' role should not be an option in role filter.
    public Boolean checkRequestorRole() {
        int dropDownSize = dropDownFilterList.size();
        for(int i=0; i<dropDownSize; i++) {
            if(dropDownFilterList.get(i).equalsIgnoreCase("Requestor")) {
                return false;
            }
        }
        System.out.println("Requestor Role is found in Role Filter dropDown, Requestor role should not be an option.");
        return true;
    }
    
    // @Author = Pratik
    // Returns true if agent has a role corresponding to the Filtered-Role, otherWise false.
    // Also Verifies the fallback Screen if there are no agents for the applied Filter.
    public Boolean checkFilterForAgent(int agentNumber) throws InterruptedException {
        WebElement currentAgent = agentList.get(agentNumber);
        
        By expandIcon=By.xpath("(//div[@class='agent-list__container__item__expand-collapse'])["+Integer.toString(agentNumber+1)+"]");
        clickable(expandIcon);
        driver.findElement(expandIcon).click();
        
        List<WebElement> roles = currentAgent.findElements(role);
        int roleSize = roles.size();
        if(roleSize==0) {
            visibleText(fallbackScreen);
        }else {
            for(int i=0;i<roleSize; i++) {
//                System.out.println(roles.get(i).getText());
                if(roles.get(i).getText().equalsIgnoreCase(filterRole)) {
                    driver.findElement(expandIcon).click();
                    return true;
                }
            }
        }
        driver.findElement(expandIcon).click();
        return false;
    }
    
    
    // @Author = Pratik
    // Returns true if the prevArrow is clickable
    public Boolean checkPrevArrow() {
        visibleText(prevArrow);
        return true;
    }
    
    
    // @Author = Pratik
    // Returns true if the nextArrow is clickable
    public Boolean checkNextArrow() {
        visibleText(nextArrow);
       return true;
    }
    
    
    // @Author = Pratik
    // Apply Email Filter and verify the result.
    public Boolean applyEmailFilterAndCheck() {
        clickable(filterIcon);
        driver.findElement(filterIcon).click();
        
        clickable(emailInput);
        driver.findElement(emailInput).sendKeys(email);
    

        clickable(applyButton);
        driver.findElement(applyButton).click();
        
        if(driver.findElements(agentTile).size()==0) {
            visibleText(fallbackScreen);
            return true;
        }else if(driver.findElements(agentTile).size()==1) {
            By expandIcon=By.xpath("//div[@class='agent-list__container__item__expand-collapse']");
            clickable(expandIcon);
            driver.findElement(expandIcon).click();
            
            return driver.findElement(By.xpath("(//div[@class='agent-list__container__item__agent-email'])[1]")).getText().equalsIgnoreCase(email);
        }
        return false;
    }
    
    
 // @Author = Pratik
    // Apply Email Filter and verify the result.
    public Boolean applyIncorrectEmailFilterAndCheck() {
        clickable(filterIcon);
        driver.findElement(filterIcon).click();
        
        clickable(emailInput);
        driver.findElement(emailInput).click();
        driver.findElement(emailInput).sendKeys(Keys.BACK_SPACE);
        driver.findElement(emailInput).sendKeys("a");
    

        clickable(applyButton);
        driver.findElement(applyButton).click();
        
        visibleText(fallbackScreen);
        return true;
    }
    
    
    // @Author = Pratik
    // return the number of total agents in the agentList screen by default.
    public int returnAgentCount() {
        String count = driver.findElement(By.xpath("//span[contains(text(),'Showing')]")).getText().split(" ")[5];
        return Integer.valueOf(count);
    }
    

    // @Author = Pratik
    // Refresh the current page.
    public void refresh() throws InterruptedException {
        driver.navigate().refresh();
    }
    
    
    
    // @author : Kalam
    // METHODS FROM BASE CLASS--------------------------------------------------------------------------------------------------
    
    
    // Wait till the parameter element is visible.
    public boolean visibleText(By element)
    {
        WebDriverWait wait= new WebDriverWait(driver, 10);
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));
        //System.out.println("Element is visible");
        return false;
    }
    
    
    // Check if the Element is Clickable.
    public boolean clickable(By element)
    {
        WebDriverWait wait= new WebDriverWait(driver, 10);
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));
        //System.out.println("Element is visible");
        return false;
    }
    
    public void jsClick(WebElement el) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].click();", el);
            System.out.println("Element clicked");
        } catch (Exception e) {
            System.out.println("=============================================================");
            System.out.println("Exception-jsClick(): " + e.getMessage());
            //takeScreenShot();
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }
}
