package pageObjects;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PO_CaseListTwo {

    public WebDriver driver;
    public WebDriverWait wait;
    
    // sidebar components xpath
    private String sidebarCasesTextXpath = "//div[@data-testid='navMenu__item']//div[text()='Cases']";
    
    // header
    private String headerCreateButtonXpath = "//button[text()='CREATE']";
    
    // toolbar components xpath
    private String toolbarSelectAllCasesCheckBoxXpath = "//input[contains(@class,'checkboxAll')]";
    private String toolbarAssignButtonXpath = "//button[text()='Assign']";
    private String toolbarBulkUpdateButtonXpath = "//button[text()='Bulk Update']";
    private String toolbarViewMyCasesCheckBoxXpath = "//label[contains(@class,'toggle')]";
    
    // slider components
    private String sliderCrossIconXpath = "//div[contains(@class,'modal-container')]//img[@alt='close']";
    private String sliderUpdateButtonXpath = "//div[contains(@class,'modal-container')]//button[text()='Update']";
    private String sliderCancelButtonXpath = "//div[contains(@class,'modal-container')]//button[text()='Cancel']";
    
    // bulk assign menu components xpath
    private String bulkAssignMenuAgentFieldXpath = "//div[contains(@class,'modal-container')]//div[text()='Agent']/parent::div/parent::div";
  
    // relative xpaths
    private String dropdownSelectedLabelXpath = "//div[@class='dropdown__selectedLabel']";
    
    // constructor 
    public PO_CaseListTwo(WebDriver driver) {
        
        this.driver = driver;
        wait = new WebDriverWait(driver, 10);
    }
    
    // @Author = Ankur
    // @Description = go to case list page
    public void goToCaseListPage() {
        
        click(By.xpath(sidebarCasesTextXpath));
    }
    
    // @Author = Ankur
    // @Description = change role
    public void changeRole(String projectName) {
        
        driver.findElement(By.xpath("//div[@class='projectDropdown']")).click();
        
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='projectDropdown']//div[contains(@class,'dropdownOption')]")));
        driver.findElement(By.xpath("//div[@class='projectDropdown']//div[contains(@class,'dropdownOption') and text()='" + projectName + "']")).click();
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(headerCreateButtonXpath)));
    }
    
    // -------------------------------------------------
    // ******************** TOOLBAR ********************
    // -------------------------------------------------
    
    // @Author = Ankur
    // @Description = select all cases
    public void selectAllCases() {
        
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(toolbarSelectAllCasesCheckBoxXpath))).click();
    }
    
    // @Author = Ankur
    // @Description = open bulk assign menu
    public void openBulkAssignMenu() {
        
        click(By.xpath(toolbarAssignButtonXpath));
    }
    
    // @Author = Ankur
    // @Description = open bulk update menu
    public void openBulkUpdateMenu() {
        
        click(By.xpath(toolbarBulkUpdateButtonXpath));
    }
    
    // @Author = Ankur
    // @Description = toggle my cases
    public void clickViewMyCasesCheckbox() {
        
        click(By.xpath(toolbarViewMyCasesCheckBoxXpath));
        wait(2000);
    }
    
    // ---------------------------------------------------
    // ******************** CASE LIST ********************
    // ---------------------------------------------------
    
    // @Author = Ankur
    // @Description = get ticket ids
    public List<String> getTicketIds() {
        
        List<String> ticketIds = new ArrayList<String>();
        
        String ticketIdXpath = "//div[@class='ticketCard_container']//span[@class='ticketCard__textTicketId']";
        int n = wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(ticketIdXpath))).size();
        
        for(int i = 1; i <= n; ++i)
            ticketIds.add(driver.findElement(By.xpath("(" + ticketIdXpath + ")[" + i + "]")).getText());
        
        return ticketIds;
    }
    
    // @Author = Ankur
    // @Description = select tickets
    public void selectCase(String ticketId) {
      
        By e = By.xpath("//span[text()='" + ticketId.substring(1) + "']/parent::div/parent::div/parent::a/parent::div/parent::div//input[@type='checkbox']");
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(e)).click();
    }
    
    // @Author = Ankur
    // @Description = get priority
    public String getPriority(String ticketId) {
        
        By e = By.xpath("//span[text()='" + ticketId.substring(1) + "']/parent::div/parent::div//div[@class='ticketCard__textPriority']");
        return wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(e)).getText();
    }
    
    // @Author = Ankur
    // @Description = check status
    public Boolean checkPriority(List<String> ticketIds, int n, String priority) {
        
        for(int t = 1; t <= 8; ++t) {
            
            driver.navigate().refresh();
            
            Boolean flag = true;
            
            for(int i = 0; i < n; ++i) {
             
                System.out.println(getPriority(ticketIds.get(i)) + "\t" + priority);
                flag &= getPriority(ticketIds.get(i)).equals(priority);
            }
            
            if(flag)
                return true;
            
            wait(2000);
        }
        
        return false;
    }
    
    // @Author = Ankur
    // @Description = get status
    public String getStatus(String ticketId) {
        
        By e = By.xpath("//span[text()='" + ticketId.substring(1) + "']/parent::div/parent::div//div[@class='ticketCard__textStatus']");
        return wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(e)).getText();
    }
    
    // @Author = Ankur
    // @Description = check status
    public Boolean checkStatus(List<String> ticketIds, int n, String status) {
        
        for(int t = 1; t <= 8; ++t) {
            
            driver.navigate().refresh();
            
            Boolean flag = true;
            
            for(int i = 0; i < n; ++i) {
             
                System.out.println(getStatus(ticketIds.get(i)) + "\t" + status);
                flag &= getStatus(ticketIds.get(i)).equals(status);
            }
            
            if(flag)
                return true;
            
            wait(2000);
        }
        
        return false;
    }
    
    // @Author = Ankur
    // @Description = get email
    public String getEmail(String ticketId) {
        
        By e = By.xpath("//span[text()='" + ticketId.substring(1) + "']/parent::div/parent::div//div[@class='ticketCard__textAgentEmail']");
        return wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(e)).getText();
    }
    
    // @Author = Ankur
    // @Description = check email
    public Boolean checkEmail(List<String> ticketIds, int n, String email) {
        
        for(int t = 1; t <= 8; ++t) {
            
            driver.navigate().refresh();
            
            Boolean flag = true;
            
            for(int i = 0; i < n; ++i) {
                
                System.out.println(getEmail(ticketIds.get(i)) + "\t" + email);
                flag &= getEmail(ticketIds.get(i)).equals(email);
            }
            
            if(flag)
                return true;
            
            wait(2000);
        }
        
        return false;
    }
    
    // ------------------------------------------------
    // ******************** SLIDER ********************
    // ------------------------------------------------
    
    // @Author = Ankur
    // @Description = close slider
    public void closeSlider() {
        
        click(By.xpath(sliderCrossIconXpath));
    }
    
    // @Author = Ankur
    // @Description = click Update Button
    public void clickUpdateButton() {
        
        click(By.xpath(sliderUpdateButtonXpath));
    }
    
    // @Author = Ankur
    // @Description = click cancel button
    public void clickCancelButton() {
        
        click(By.xpath(sliderCancelButtonXpath));
    }
    
    // ----------------------------------------------------------
    // ******************** BULK ASSIGN MENU ********************
    // ----------------------------------------------------------
    
    // @Author = Ankur
    // @Description = get bulk assign menu agent value
    public String getBulkAssigMenuAgent() {
        
        return getText(By.xpath(bulkAssignMenuAgentFieldXpath + dropdownSelectedLabelXpath));
    }
    
    // @Author = Ankur
    // @Description = set bulk assign menu agent dropdown value
    public void setBulkAssignMenuAgent(String data) {
        
        wait(2000);
        setDropdownValue("Agent", data);
    }
    
    // ----------------------------------------------------------
    // ******************** BULK UPDATE MENU ********************
    // ----------------------------------------------------------
    
    // @Author = Ankur
    // @Description = set bulk update menu priority doropdown value
    public String setBulkUpdateMenuPriority(String data) {
        
        setDropdownValue("Priority", data);
        return getDropdownValue("Priority");
    }
    
    // @Author = Ankur
    // @Description = get bulk update menu priority dropdown value
    public String getBulkUpdateMenuPriority() {
        
        return getDropdownValue("Priority");
    }
    
    // @Author = Ankur
    // @Description = set bulk update menu status dropdown value
    public String setBulkUpdateMenuStatus(String data) throws InterruptedException {
        
        setDropdownValue("Status", data);
        return getDropdownValue("Status");
    }
    
    // @Author = Ankur
    // @Description = get bulk update menu status dropdown value
    public String getBulkUpdateMenuStatus() {
        
        return getDropdownValue("Status");
    }
    
    // @Author = Ankur
    // @Description = set bulk update menu group dropdown value
    public String setBulkUpdateMenuGroup(String data) {
        
        setDropdownValue("Group", data);
        return getDropdownValue("Group");
    }
    
    // @Author = Ankur
    // @Description = get bulk update menu group dropdown value
    public String getBulkUpdateMenuGroup() {
        
        return getDropdownValue("Group");
    }
    
    // @Author = Ankur
    // @Description = set bulk update menu agent dropdown value
    public String setBulkUpdateMenuAgent(String data) {
        
        setDropdownValue("Agent", data);
        return getDropdownValue("Agent");
    }
    
    // @Author = Ankur
    // @Description = get bulk update menu agent dropdown value
    public String getBulkUpdateMenuAgent() {
        
        return getDropdownValue("Agent");
    }

    // -----------------------------------------------
    // ******************** POPUP ********************
    // -----------------------------------------------
    
    // @Author = Ankur
    // @Description = close popup
    public void closePopup() {
        
        wait(1000);
        click("//div[contains(@class,'modal-container')]//img[contains(@src,'closeSlider')]");
    }
    
    // @Author = Ankur
    // @Description = get popup message
    public String getPopupMessage() {
        
        return getText("//div[contains(@class,'modal-container')]//div[contains(@class,'message')]");
    }
    
    // ---------------------------------------------------------
    // ******************** GENERIC METHODS ********************
    // ---------------------------------------------------------
    
    // @Author = Ankur
    // @Description = set dropdown value
    public void setDropdownValue(String label, String value) {
        
        // if value is empty string then select random option from dropdown
        
        By e = By.xpath("//div[text()='" + label + "']/parent::div/parent::div//div[@class='dropdown__selectedLabel']");
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(e)).click();
        
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='dropdown__dropdownOption']")));
        List<WebElement> options = driver.findElements(By.xpath("//div[@class='dropdown__dropdownOption']"));
        
        if(value.equals(""))
            value = options.get(new Random().nextInt(options.size())).getAttribute("innerHTML");
        
        try {
            
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dropdown__dropdownOption' and text()='" + value + "']"))).click();
            
        } catch (StaleElementReferenceException e2) {
            
            wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(e)).click();
            wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(e)).click();
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dropdown__dropdownOption' and text()='" + value + "']"))).click();
        }
    }
    
    // @Author = Ankur
    // @Description = get dropdown value
    public String getDropdownValue(String label) {
        
        By e = By.xpath("//div[text()='" + label + "']/parent::div/parent::div//div[@class='dropdown__selectedLabel']");
        return wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(e)).getText();
    }
    
    
    // @Author = Ankur
    // @Description = click an element
    public void click(By e) {
        
        JavascriptExecutor executor = (JavascriptExecutor)driver;
        executor.executeScript("arguments[0].click();", driver.findElement(e));
    }
    
    // @Author = Ankur
    // @Description = get text of an element
    public String getText(By e) {
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(e));
        return driver.findElement(e).getText().trim().toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = get text of an element
    public String getText(String xpath) {
        
        By e = By.xpath(xpath);
        return wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(e)).getText();
    }
    
    // @Author = Ankur
    // @Description = click an element
    public void click(String xpath) {
        
        By e = By.xpath(xpath);
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(e)).click();
    }
    
    // @Author = Ankur
    // @Description = get web elements
    public List<WebElement> getWebElement(By e) {
        
        wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(e));
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(e));
        return driver.findElements(e);
    }
    
    // @Author = Ankur
    // @Description = wait
    public void wait(int milliseconds) {
        
        try {
            Thread.sleep(milliseconds);
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }
}
