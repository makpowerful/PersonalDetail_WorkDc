package pageObjects;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class PO_CaseFilters extends PO_CaseList {
    Actions action;
    
    // xpaths of case details screen
    private By accordianCustomerDetails = By.xpath("//div[@data-testid='accordion-header'][text()='CUSTOMER DETAILS']");
    private By accordianCaseDetails = By.xpath("//div[@data-testid='accordion-header']//span[text()='CASE DETAILS']");
    private By accordianDescription1 = By.xpath("following::div[contains(@class,'item__description')][1]");
    private By caseGroupLabel = By.xpath("(//input[@class='singleSelectSearch__container__input'])[1]");
    private By caseAgentLabel = By.xpath("(//input[@class='singleSelectSearch__container__input'])[2]");
    private By caseDetailsElements = By.xpath("//span[contains(text(),'CASE DETAILS')]//following::div[@class='accordion__wrapper__content__item']");
    private By casePropertyDescription = By.xpath(".//descendant::div[contains(@class,'description')]");
    
    // xpaths of case List screen
    private By filtersBtn = By.xpath("//button[contains(text(),'Filters')]");
    private By ticketId = By.xpath("//span[@class='ticketCard__textTicketId']");
    private By ticketStatus = By.xpath("//descendant::div[@class='ticketCard__textStatus']");
    private By ticketPriority = By.xpath("//descendant::div[@class='ticketCard__textPriority']");
    private By ticketSubCategory = By.xpath(".//div[@class='ticketCard_box subject']/span[1]");
    private By projectDropdown = By.xpath("//div[@class='projectDropdown']");
    private By createdAtText = By.xpath(".//span[@class='ticketCard__textCreatedAt']");
    
    // xpaths of filters item screen
    private By filterCustomerNameLabel = By.xpath("//div[contains(@class,'filter__body__item')]//descendant::div[contains(text(),'Customer Name')]");
    private By filterCustomerNameInput = By.xpath("//div[contains(@class,'filter__body__item')]//descendant::input[contains(@placeholder,'Search for first name')]");
    private By filterDateCreatedLabel = By.xpath("//div[contains(@class,'formLabel__container')]//descendant::div[contains(text(),'Created At')]");
    private By filterFromDateCreatedInput = By.xpath("//input[@placeholder='From Date']");
    private By filterToDateCreatedInput = By.xpath("//input[@placeholder='To Date']");
    private By filterGroupLabel = By.xpath("//div[contains(@class,'filter__body__item')]//descendant::div[contains(text(),'Group')]");
    private By filterGroupInput = By.xpath("//div[contains(@class,'filter__body__item')]//descendant::div[contains(text(),'Select Group')]");
    private By filterAgentLabel = By.xpath("//div[contains(@class,'filter__body__item')]//descendant::div[contains(text(),'Agent')]");
    private By filterAgentInput = By.xpath("//div[contains(@class,'filter__body__item')]//descendant::div[contains(text(),'Select Agent')]");
    private By filterStatusLabel = By.xpath("//div[contains(@class,'filter__body__item')]//descendant::div[contains(text(),'Status')]");
    private By filterStatusInput = By.xpath("//div[contains(@class,'filter__body__item')]//descendant::div[contains(text(),'Select Status')]");
    private By filterPriorityLabel = By.xpath("//div[contains(@class,'filter__body__item')]//descendant::div[contains(text(),'Priority')]");
    private By filterPriorityInput = By.xpath("//div[contains(@class,'filter__body__item')]//descendant::div[contains(text(),'Select Priority')]");
    private By filterSubCategoryLabel = By.xpath("//div[contains(@class,'filter__body__item')]//descendant::div[contains(text(),'Sub Category')]");
    private By filterSubCategoryInput = By.xpath("//div[contains(@class,'filter__body__item')]//descendant::div[contains(text(),'Select Sub Category')]");
    private By filterIssueTypeLabel = By.xpath("//div[contains(@class,'filter__body__item')]//descendant::div[contains(text(),'Issue Type')]");
    private By filterIssueTypeInput = By.xpath("//div[contains(@class,'filter__body__item')]//descendant::div[contains(text(),'Select Issue Type')]");
    private By filterIssueSubTypeLabel = By.xpath("//div[contains(@class,'filter__body__item')]//descendant::div[contains(text(),'Issue Sub Type')]");
    private By filterIssueSubTypeInput = By.xpath("//div[contains(@class,'filter__body__item')]//descendant::div[contains(text(),'Select Issue Sub Type')]");
    private By applyBtn = By.xpath("//button[contains(text(),'Apply')]");
    private By resetBtn = By.xpath("//button[contains(text(),'Reset')]");
    private By filterSliderText = By.xpath("//span[text()='Filters']");
    private By closeBtn = By.xpath("//img[@class='slider__close']");
    private By dropdownOption = By.xpath("//div[@class='dropdown__dropdownOption']");
    private By currentDate = By.xpath("//div[@aria-current='date']"); 
    private By datePicker = By.xpath("//div[@class='react-datepicker']");
    
    // ------------------------------------------------------------------------------------------------ 
    // Gaurang Methods
    // ------------------------------------------------------------------------------------------------
    
    //@Author : Gaurang
    //Constructor for PO_CaseFilters Class
    public PO_CaseFilters(WebDriver driver) {
        super(driver);
        action = new Actions(driver);
    }
    
    //@Author : Gaurang
    //refresh the current page
    public void refreshPage() {
        driver.navigate().refresh();
    }
    
    //@Author : Gaurang
    //Capture the filter Customer Name Label text in the filters screen
    public String getFilterCustomerNameLabel() {
        visibleText(filterCustomerNameLabel);
        return driver.findElement(filterCustomerNameLabel).getText();
    }
    
    //@Author : Gaurang
    //Capture the filter Date Created Label text in the filters screen
    public String getFilterDateCreatedLabel() {
        visibleText(filterDateCreatedLabel);
        return driver.findElement(filterDateCreatedLabel).getText();
    }
    
    //@Author : Gaurang
    //Capture the filter Group Label text in the filters screen
    public String getFilterGroupLabel() {
        visibleText(filterGroupLabel);
        return driver.findElement(filterGroupLabel).getText();
    }
    
    //@Author : Gaurang
    //Capture the filter Agent Label text in the filters screen
    public String getFilterAgentLabel() {
        visibleText(filterAgentLabel);
        return driver.findElement(filterAgentLabel).getText();
    }
    
    //@Author : Gaurang
    //Capture the filter Status Label text in the filters screen
    public String getFilterStatusLabel() {
        visibleText(filterStatusLabel);
        return driver.findElement(filterStatusLabel).getText();
    }
    
    //@Author : Gaurang
    //Capture the filter Priority Label text in the filters screen
    public String getFilterPriorityLabel() {
        visibleText(filterPriorityLabel);
        return driver.findElement(filterPriorityLabel).getText();
    }
    
    //@Author : Gaurang
    //Capture the filter Sub Category Label text in the filters screen
    public String getFilterSubCategoryLabel() {
        visibleText(filterSubCategoryLabel);
        return driver.findElement(filterSubCategoryLabel).getText();
    }
    
    //@Author : Gaurang
    //Capture the filter Issue Type Label text in the filters screen
    public String getFilterIssueTypeLabel() {
        visibleText(filterIssueTypeLabel);
        return driver.findElement(filterIssueTypeLabel).getText();
    }
    
    //@Author : Gaurang
    //Capture the filter Issue Sub Type Label text in the filters screen
    public String getFilterIssueSubTypeLabel() {
        visibleText(filterIssueSubTypeLabel);
        return driver.findElement(filterIssueSubTypeLabel).getText();
    }
    
    //@Author : Gaurang
    //Capture the filter Customer Name Input placeholder in the filters screen
    public String getFilterCustomerNameInput() {
        visibleText(filterCustomerNameInput);
        return driver.findElement(filterCustomerNameInput).getAttribute("placeholder");
    }
    
    //@Author : Gaurang
    //Capture the filter From Date Created Input placeholder in the filters screen
    public String getFilterFromDateCreatedInput() {
        visibleText(filterFromDateCreatedInput);
        return driver.findElement(filterFromDateCreatedInput).getAttribute("placeholder");
    }
    
    //@Author : Gaurang
    //Capture the filter To Date Created Input placeholder in the filters screen
    public String getFilterToDateCreatedInput() {
        visibleText(filterToDateCreatedInput);
        return driver.findElement(filterToDateCreatedInput).getAttribute("placeholder");
    }
    
    //@Author : Gaurang
    //Capture the filter Group Input text in the filters screen
    public String getFilterGroupInput() {
        visibleText(filterGroupInput);
        return driver.findElement(filterGroupInput).getText();
    }
    
    //@Author : Gaurang
    //Capture the filter Agent Input text in the filters screen
    public String getFilterAgentInput() {
        visibleText(filterAgentInput);
        return driver.findElement(filterAgentInput).getText();
    }
    
    //@Author : Gaurang
    //Capture the filter Status Input text in the filters screen
    public String getFilterStatusInput() {
        visibleText(filterStatusInput);
        return driver.findElement(filterStatusInput).getText();
    }
    
    //@Author : Gaurang
    //Capture the filter Priority Input text in the filters screen
    public String getFilterPriorityInput() {
        visibleText(filterPriorityInput);
        return driver.findElement(filterPriorityInput).getText();
    }
    
    //@Author : Gaurang
    //Capture the filter Sub Category Input text in the filters screen
    public String getFilterSubCategoryInput() {
        visibleText(filterSubCategoryInput);
        return driver.findElement(filterSubCategoryInput).getText();
    }
    
    //@Author : Gaurang
    //Capture the filter Issue Type Input text in the filters screen
    public String getFilterIssueTypeInput() {
        visibleText(filterIssueTypeInput);
        return driver.findElement(filterIssueTypeInput).getText();
    }
    
    //@Author : Gaurang
    //Capture the filter Issue Sub Type Input text in the filters screen
    public String getFilterIssueSubTypeInput() {
        visibleText(filterIssueSubTypeInput);
        return driver.findElement(filterIssueSubTypeInput).getText();
    }
    
    //@Author : Gaurang
    //Click the filters button
    public void clickFiltersBtn() {
        visibleText(filtersBtn);
        clickable(filtersBtn);
        try {
        jsClick(driver.findElement(filtersBtn));
        }
        catch(Exception e) {
            driver.findElement(filtersBtn).click(); 
        }
    }
    
    //@Author : Gaurang
    //Capture the filter Slider Text in the filters screen
    public String getFilterSliderText() {
        visibleText(filterSliderText);
        return driver.findElement(filterSliderText).getText();
    }
    
    //@Author : Gaurang
    //Capture the apply button text in the filters screen
    public String getApplyBtnText() {
        visibleText(applyBtn);
        return driver.findElement(applyBtn).getText();
    }
    
    //@Author : Gaurang
    //Capture the reset button text in the filters screen
    public String getResetBtnText() {
        visibleText(resetBtn);
        return driver.findElement(resetBtn).getText();
    }
    
    //@Author : Gaurang
    //Click the apply button
    public void clickApplyBtn() {
        visibleText(applyBtn);
        clickable(applyBtn);
        jsClick(driver.findElement(applyBtn));
    }
    
    //@Author : Gaurang
    //Click the reset button
    public void clickResetBtn() {
        visibleText(resetBtn);
        clickable(resetBtn);
        driver.findElement(resetBtn).click();
    }
    
    //@Author : Gaurang
    //Click the close button
    public void clickCloseBtn() {
        visibleText(closeBtn);
        clickable(closeBtn);
        driver.findElement(closeBtn).click();
    }
    
    //@Author : Gaurang
    //Click the Customer Details accordian
    public void clickAccordianCustomerDetails() {
        visibleText(accordianCustomerDetails);
        clickable(accordianCustomerDetails);
        try {
        driver.findElement(accordianCustomerDetails).click();
        }
        catch(Exception e) {
            jsClick(driver.findElement(accordianCustomerDetails));
        }
    }
    
    //@Author : Gaurang
    //Click the Customer Details accordian
    public void clickAccordianCaseDetails() {
        visibleText(accordianCaseDetails);
        clickable(accordianCaseDetails);
        driver.findElement(accordianCaseDetails).click();
    }
    
    //@Author : Gaurang
    // Apply the customer name filter and check the result
    public Boolean checkCustomerNameFilter(String customerName) {
        int attempt = 0;
        visibleText(filterCustomerNameInput);
        action.moveToElement(driver.findElement(filterCustomerNameInput)).click().sendKeys(customerName).build().perform();
        clickApplyBtn();
        clickFiltersBtn();
        visibleText(filterCustomerNameInput);
        if(!driver.findElement(filterCustomerNameInput).getAttribute("value").equalsIgnoreCase(customerName)) {
            return false;
        }
        clickApplyBtn();
        visibleText(ticketCards);
        List<WebElement> tickets = driver.findElements(ticketCards);
        tickets.get(0).click();
        clickAccordianCustomerDetails();
        visibleText(driver.findElement(accordianCustomerDetails).findElement(accordianDescription1));
        if(!driver.findElement(accordianCustomerDetails).findElement(accordianDescription1).getText().toLowerCase().contains(customerName.toLowerCase())) {
            return false;
        }
        goToCaseListScreen();
        clickFiltersBtn();
        visibleText(filterCustomerNameInput);
        action.moveToElement(driver.findElement(filterCustomerNameInput)).click().sendKeys(customerName).build().perform();
        clickApplyBtn();
        visibleText(rightPaginationButton);
        while(driver.findElement(rightPaginationButton).isEnabled() && attempt < 5) {
            clickable(rightPaginationButton);
            driver.findElement(rightPaginationButton).click();
            attempt++;
            visibleText(rightPaginationButton);
        }
        visibleText(ticketCards);
        tickets = driver.findElements(ticketCards);
        jsClick(tickets.get(tickets.size()-1));
        clickAccordianCustomerDetails();
        visibleText(driver.findElement(accordianCustomerDetails).findElement(accordianDescription1));
        if(!driver.findElement(accordianCustomerDetails).findElement(accordianDescription1).getText().toLowerCase().contains(customerName.toLowerCase())) {
            return false;
        }
        goToCaseListScreen();
        return true;
    }
    
    //@Author : Gaurang
    // Set the agent filter
    public void setAgentFilter(String caseAgent) {
        caseAgent = caseAgent.split(" ")[0];
        try {
            
            visibleText(filterAgentInput);
            try {
                jsClick(driver.findElement(filterAgentInput));
                action.moveToElement(driver.findElement(dropdownOption)).build().perform();
            }
            catch(Exception e) {
                action.moveToElement(driver.findElement(filterAgentInput)).click().build().perform();  
                action.moveToElement(driver.findElement(dropdownOption)).build().perform();
            }
            //visibleText(dropdownOption);
            List<WebElement> options = driver.findElements(dropdownOption);
            for(int i=0; i<options.size(); i++) {
                if(options.get(i).getText().toLowerCase().contains(caseAgent.toLowerCase())) {
                    jsClick(options.get(i));
                    System.out.println("Clicked Agent is : "+options.get(i));
                    break;
                }
            }
        } catch (StaleElementReferenceException e) {
            
            visibleText(filterAgentInput);
            action.moveToElement(driver.findElement(filterAgentInput)).click().build().perform();
            //visibleText(dropdownOption);
            List<WebElement> options = driver.findElements(dropdownOption);
            for(int i=0; i<options.size(); i++) {
                if(options.get(i).getText().compareToIgnoreCase(caseAgent) == 0) {
                    options.get(i).click();
                    System.out.println("Clicked Agent is : "+options.get(i));
                    break;
                }
            }
        }
    }
    
    //@Author : Gaurang
    // Apply the group filter and check the result
    public Boolean checkGroupFilter(String caseGroup) {
        int attempt = 0;
        if(!setGroupFilter(caseGroup)) {
            return false;
        }
        clickApplyBtn();
        visibleText(ticketCards);
        List<WebElement> tickets = driver.findElements(ticketCards);
        tickets.get(0).click();
        visibleText(caseGroupLabel);
        if(driver.findElement(caseGroupLabel).getAttribute("value").compareToIgnoreCase(caseGroup) != 0) {
            return false;
        }
        goToCaseListScreen();
        clickFiltersBtn();
        if(!setGroupFilter(caseGroup)) {
            return false;
        }
        clickApplyBtn();
        visibleText(rightPaginationButton);
        while(driver.findElement(rightPaginationButton).isEnabled() && attempt < 5) {
            clickable(rightPaginationButton);
            driver.findElement(rightPaginationButton).click();
            attempt++;
            visibleText(rightPaginationButton);
        }
        visibleText(ticketCards);
        tickets = driver.findElements(ticketCards);
        tickets.get(tickets.size()-1).click();
        visibleText(caseGroupLabel);
        if(driver.findElement(caseGroupLabel).getAttribute("value").compareToIgnoreCase(caseGroup) != 0) {
            return false;
        }
        goToCaseListScreen();
        return true;
    }
    
    //@Author : Gaurang
    // Set the group filter
    public boolean setGroupFilter(String caseGroup) {
        visibleText(filterGroupInput);
        action.moveToElement(driver.findElement(filterGroupInput)).click().build().perform();
        visibleText(dropdownOption);
        if(!driver.findElement(By.xpath("//div[@class='dropdown__dropdownOption'][1]")).getText().equalsIgnoreCase("Unassigned")) {
            return false;
        }
        try {
            List<WebElement> options = driver.findElements(dropdownOption);
            for(int i=0; i<options.size(); i++) {
                if(options.get(i).getText().compareToIgnoreCase(caseGroup) == 0) {
                    System.out.println("Value of case Group : "+caseGroup);
                    options.get(i).click();
                    break;
                }
            }
        } catch (StaleElementReferenceException e) {
            List<WebElement> options = driver.findElements(dropdownOption);
            for(int i=0; i<options.size(); i++) {
                if(options.get(i).getText().compareToIgnoreCase(caseGroup) == 0) {
                    options.get(i).click();
                    break;
                }
            }
        }
        return true;
    }
    
    //@Author : Gaurang
    // Apply the agent filter and check the result
    public Boolean checkAgentFilter(String caseAgent) {
        int attempt = 0;
        wait(2);
        setAgentFilter(caseAgent);
        clickApplyBtn();
        visibleText(ticketCards);
        List<WebElement> tickets = driver.findElements(ticketCards);
        tickets.get(0).click();
        visibleText(caseAgentLabel);
        if(driver.findElement(caseAgentLabel).getAttribute("value").compareToIgnoreCase(caseAgent) != 0) {
            System.out.println(driver.findElement(caseAgentLabel).getAttribute("value")+"-----------------"+caseAgent+"1");
            return false;
        }
        goToCaseListScreen();
        clickFiltersBtn();
        wait(2);
        setAgentFilter(caseAgent);
        clickApplyBtn();
        visibleText(rightPaginationButton);
        while(driver.findElement(rightPaginationButton).isEnabled() && attempt < 5) {
            clickable(rightPaginationButton);
            driver.findElement(rightPaginationButton).click();
            attempt++;
            visibleText(rightPaginationButton);
        }
        visibleText(ticketCards);
        tickets = driver.findElements(ticketCards);
        tickets.get(tickets.size()-1).click();
        visibleText(caseAgentLabel);
        if(driver.findElement(caseAgentLabel).getAttribute("value").compareToIgnoreCase(caseAgent) != 0) {
            System.out.println(driver.findElement(caseAgentLabel).getAttribute("value")+"-----------------"+caseAgent+"2");
            return false;
        }
        goToCaseListScreen();
        return true;
    }
    
    //@Author : Gaurang
    // Set the created after filter 
    public void setCreatedAfter() {
        try {
            visibleText(filterFromDateCreatedInput);
            clickable(filterFromDateCreatedInput);
            action.moveToElement(driver.findElement(filterFromDateCreatedInput)).click().build().perform();
            visibleText(datePicker);
            visibleText(currentDate);
            clickable(currentDate);
            driver.findElement(currentDate).click();
        }
        catch(Exception ex)
        {
            visibleText(filterFromDateCreatedInput);
            clickable(filterFromDateCreatedInput);
            action.moveToElement(driver.findElement(filterFromDateCreatedInput)).click().build().perform();
            visibleText(datePicker);
            visibleText(currentDate);
            clickable(currentDate);
            driver.findElement(currentDate).click();
        }
        try {
            visibleText(filterToDateCreatedInput);
            clickable(filterToDateCreatedInput);
            action.moveToElement(driver.findElement(filterToDateCreatedInput)).click().build().perform();
            visibleText(datePicker);
            visibleText(currentDate);
            clickable(currentDate);
            driver.findElement(currentDate).click();
        }
        catch(Exception ex)
        {
            visibleText(filterToDateCreatedInput);
            clickable(filterToDateCreatedInput);
            action.moveToElement(driver.findElement(filterToDateCreatedInput)).click().build().perform();
            visibleText(datePicker);
            visibleText(currentDate);
            clickable(currentDate);
            driver.findElement(currentDate).click();
        }
    }
    
    //@Author : Gaurang
    // Apply the created after filter and check the result
    public Boolean checkCreatedAtFilter() {
        int attempt = 0;
        setCreatedAfter();
        clickApplyBtn();
        do {
            visibleText(ticketCards);
            List<WebElement> tickets = driver.findElements(ticketCards);
            for(int i=0; i<tickets.size(); i++) {
                if(tickets.get(i).findElement(createdAtText).getText().contains("day")) {
                    return false;
                }
            }
            if(driver.findElement(rightPaginationButton).isEnabled() && attempt < 5) {
                visibleText(rightPaginationButton);
                clickable(rightPaginationButton);
                driver.findElement(rightPaginationButton).click();
                attempt++;
            }
            else {
                break;
            }
        }while(true);
        clickFiltersBtn();
        clickResetBtn();
        return true;
    }
    
    //@Author : Gaurang
    // Set the Status filter 
    public void setStatusFilter(String caseStatus) {
        visibleText(filterStatusInput);
        action.moveToElement(driver.findElement(filterStatusInput)).click().build().perform();
        visibleText(dropdownOption);
        List<WebElement> options;
        try {
            options = driver.findElements(dropdownOption);
            for(int i=0; i<options.size(); i++) {
                if(options.get(i).getText().compareToIgnoreCase(caseStatus) == 0) {
                    options.get(i).click();
                    break;
                }
            }
        }
        catch(StaleElementReferenceException ex)
        {
            options = driver.findElements(dropdownOption);
            for(int i=0; i<options.size(); i++) {
                if(options.get(i).getText().compareToIgnoreCase(caseStatus) == 0) {
                    options.get(i).click();
                    break;
                }
            }
        }
        
    }
    
    //@Author : Gaurang
    // Apply the Status filter and check the result
    public Boolean checkStatusFilter(String caseStatus) {
        int attempt = 0;
        setStatusFilter(caseStatus);
        clickApplyBtn();
        do {
            visibleText(ticketCards);
            List<WebElement> tickets = driver.findElements(ticketCards);
            for(int i=0; i<tickets.size(); i++) {
                if(tickets.get(i).findElement(ticketStatus).getText().compareToIgnoreCase(caseStatus) != 0) {
                    return false;
                }
            }
            if(driver.findElement(rightPaginationButton).isEnabled() && attempt < 5) {
                visibleText(rightPaginationButton);
                clickable(rightPaginationButton);
                driver.findElement(rightPaginationButton).click();
                attempt++;
            }
            else {
                break;
            }
        }while(true);
        clickFiltersBtn();
        clickResetBtn();
        return true;
    }
    
    //@Author : Gaurang
    // check status options are capitalized
    public Boolean checkStatusOptions() {
        visibleText(filterStatusInput);
        action.moveToElement(driver.findElement(filterStatusInput)).click().build().perform();
        visibleText(dropdownOption);
        List<WebElement> options;
        try {
            options = driver.findElements(dropdownOption);
            for(int i=0; i<options.size(); i++) {
                if(!Character.isUpperCase(options.get(i).getText().charAt(0))) {
                    return false;
                }
            }
        }
        catch(StaleElementReferenceException ex)
        {
            options = driver.findElements(dropdownOption);
            for(int i=0; i<options.size(); i++) {
                if(!Character.isUpperCase(options.get(i).getText().charAt(0))) {
                    return false;
                }
            }
        }
        visibleText(filterStatusInput);
        action.moveToElement(driver.findElement(filterStatusInput)).click().build().perform();
        return true;
    }
    
    //@Author : Gaurang
    // check priority options are capitalized
    public Boolean checkPriorityOptions() {
        visibleText(filterPriorityInput);
        action.moveToElement(driver.findElement(filterPriorityInput)).click().build().perform();
        visibleText(dropdownOption);
        List<WebElement> options;
        try {
            options = driver.findElements(dropdownOption);
            for(int i=0; i<options.size(); i++) {
                if(!Character.isUpperCase(options.get(i).getText().charAt(0))) {
                    return false;
                }
            }
        }
        catch(StaleElementReferenceException ex)
        {
            options = driver.findElements(dropdownOption);
            for(int i=0; i<options.size(); i++) {
                if(!Character.isUpperCase(options.get(i).getText().charAt(0))) {
                    return false;
                }
            }
        }
        visibleText(filterPriorityInput);
        action.moveToElement(driver.findElement(filterPriorityInput)).click().build().perform();
        return true;
    }
    
    //@Author : Gaurang
    // Set the Priority filter 
    public void setPriorityFilter(String casePriority) {
        visibleText(filterPriorityInput);
        action.moveToElement(driver.findElement(filterPriorityInput)).click().build().perform();
        visibleText(dropdownOption);
        List<WebElement> options = driver.findElements(dropdownOption);
        for(int i=0; i<options.size(); i++) {
            if(options.get(i).getText().compareToIgnoreCase(casePriority) == 0) {
               jsClick(options.get(i));
                break;
            }
        }
    }
    
    //@Author : Gaurang
    // Apply the Priority filter and check the result
    public Boolean checkPriorityFilter(String casePriority) {
        int attempt = 0;
        setPriorityFilter(casePriority);
        clickApplyBtn();
        do {
            visibleText(ticketCards);
            List<WebElement> tickets = driver.findElements(ticketCards);
            for(int i=0; i<tickets.size(); i++) {
                if(tickets.get(i).findElement(ticketPriority).getText().compareToIgnoreCase(casePriority) != 0) {
                    return false;
                }
            }
            visibleText(rightPaginationButton);
            if(driver.findElement(rightPaginationButton).isEnabled() && attempt < 5) {
                visibleText(rightPaginationButton);
                clickable(rightPaginationButton);
                driver.findElement(rightPaginationButton).click();
                attempt++;
            }
            else {
                break;
            }
        }while(true);
        clickFiltersBtn();
        clickResetBtn();
        return true;
    }
    
    //@Author : Gaurang
    // Set the SubCategory filter 
    public void setSubCategoryFilter(String subCategory) {
        visibleText(filterSubCategoryInput);
        scrollIntoView(driver.findElement(filterSubCategoryInput));
        action.moveToElement(driver.findElement(filterSubCategoryInput)).click().build().perform();
        //visibleText(dropdownOption);
        List<WebElement> options = driver.findElements(dropdownOption);
        for(int i=0; i<options.size(); i++) {
            if(options.get(i).getText().compareToIgnoreCase(subCategory) == 0) {
                jsClick(options.get(i));
                break;
            }
        }
    }
    
    // Scroll element to view
    public void scrollIntoView(WebElement element) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].scrollIntoView(true);", element);
            System.out.println("Page scrolled down");
        } catch (Exception e) {
            System.out.println("=============================================================");
            System.out.println("Exception-scrollIntoView(): " + e.getMessage());
            takeScreenShot();
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }
    
    //@Author : Gaurang
    // Apply the SubCategory filter and check the result
    public Boolean checkSubCategoryFilter(String subCategory) {
        System.out.println(subCategory);
        int attempt = 0;
        setSubCategoryFilter(subCategory);
        clickApplyBtn();
        do {
            visibleText(ticketCards);
            List<WebElement> tickets = driver.findElements(ticketCards);
            for(int i=0; i<tickets.size(); i++) {
                if(tickets.get(i).findElement(ticketSubCategory).getText().compareToIgnoreCase(subCategory) != 0) {
                    System.out.println(tickets.get(i).findElement(ticketSubCategory).getText());
                    System.out.println(tickets.get(i).findElement(ticketId).getText());
                    return false;
                }
            }
            visibleText(rightPaginationButton);
            if(driver.findElement(rightPaginationButton).isEnabled() && attempt < 5) {
                clickable(rightPaginationButton);
                driver.findElement(rightPaginationButton).click();
                attempt++;
                visibleText(rightPaginationButton);
            }
            else {
                break;
            }
        }while(true);
        clickFiltersBtn();
        clickResetBtn();
        return true;
    }
    
    //@Author : Gaurang
    // Set the issue type filter 
    public void setIssueTypeFilter(String issueType) {
        visibleText(filterIssueTypeInput);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("document.querySelector(\".modal-container\").scrollBy(0, 1000)", "");
        clickable(filterIssueTypeInput);
        driver.findElement(filterIssueTypeInput).click();
        visibleText(dropdownOption);
        
        try {
            List<WebElement> options = driver.findElements(dropdownOption);
            for(int i=0; i<options.size(); i++) {
                if(options.get(i).getText().compareToIgnoreCase(issueType) == 0) {
                    options.get(i).click();
                    break;
                }
            }
        }
        catch(Exception e) {
            List<WebElement> options = driver.findElements(dropdownOption);
            for(int i=0; i<options.size(); i++) {
                if(options.get(i).getText().compareToIgnoreCase(issueType) == 0) {
                    options.get(i).click();
                    break;
                }
            }
        }
    }
    
    //@Author : Gaurang
    // Apply the issue type filter and check the result
    public Boolean checkIssueTypeFilter(String issueType) {
        int attempt = 0;
        setIssueTypeFilter(issueType);
        clickApplyBtn();
        visibleText(ticketCards);
        List<WebElement> tickets = driver.findElements(ticketCards);
        tickets.get(0).click();
        clickAccordianCaseDetails();
        List<WebElement> eles = driver.findElements(caseDetailsElements);
        List<String> issues = new ArrayList<>();
        for(int i=0; i<eles.size(); i++) {
            try {
            issues.add(eles.get(i).findElement(By.xpath(".//descendant::div[contains(@class,'description')]")).getText().trim().toLowerCase());
            }
            catch(Exception e){
                issues.add(eles.get(i).findElement(By.xpath(".//descendant::div[contains(@class,'description')]")).getText().trim().toLowerCase());  
            }
        }
        if(!issues.contains(issueType.toLowerCase())) {
            return false;
        }
        goToCaseListScreen();
        clickFiltersBtn();
        setIssueTypeFilter(issueType);
        clickApplyBtn();
        visibleText(rightPaginationButton);
        while(driver.findElement(rightPaginationButton).isEnabled() && attempt < 5) {
            clickable(rightPaginationButton);
            driver.findElement(rightPaginationButton).click();
            attempt++;
            visibleText(rightPaginationButton);
        }
        visibleText(ticketCards);
        tickets = driver.findElements(ticketCards);
        tickets.get(tickets.size()-1).click();
        clickAccordianCaseDetails();
        eles = driver.findElements(caseDetailsElements);
        issues = new ArrayList<>();
        for(int i=0; i<eles.size(); i++) {
            try {
                Thread.sleep(1000);
            issues.add(eles.get(i).findElement(By.xpath(".//descendant::div[contains(@class,'description')]")).getText().trim().toLowerCase());
            }
            catch(Exception e) {
                eles = driver.findElements(By.xpath("//span[contains(text(),'CASE DETAILS')]//following::div[@class='accordion__wrapper__content__item']"));
                issues.add(eles.get(i).findElement(By.xpath(".//descendant::div[contains(@class,'description')]")).getText().trim().toLowerCase());
            }
        }
        if(!issues.contains(issueType.toLowerCase())) {
            return false;
        }
        goToCaseListScreen();
        return true;
    }
    
    //@Author : Gaurang
    // Set the issue sub type filter 
    public void setIssueSubTypeFilter(String issueSubType) {
        visibleText(filterIssueSubTypeInput);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("document.querySelector(\".modal-container\").scrollBy(0, 1000)", "");
        clickable(filterIssueSubTypeInput);
        jsClick(driver.findElement(filterIssueSubTypeInput));
        clickable(dropdownOption);
        js.executeScript("document.querySelector(\".modal-container\").scrollBy(0, 1000)", "");
        try {
            List<WebElement> options = driver.findElements(dropdownOption);
            for(int i=0; i<options.size(); i++) {
                if(options.get(i).getText().compareToIgnoreCase(issueSubType) == 0) {
                    options.get(i).click();
                    break;
                }
            }
        }
        catch(StaleElementReferenceException e) {
            List<WebElement> options = driver.findElements(dropdownOption);
            for(int i=0; i<options.size(); i++) {
                if(options.get(i).getText().compareToIgnoreCase(issueSubType) == 0) {
                    options.get(i).click();
                    break;
                }
            }
        }
        
    }
    
    //@Author : Gaurang
    // Apply the issue sub type filter and check the result
    public Boolean checkIssueSubTypeFilter(String issueSubType) {
        int attempt = 0;
        setIssueSubTypeFilter(issueSubType);
        clickApplyBtn();
        visibleText(ticketCards);
        List<WebElement> tickets = driver.findElements(ticketCards);
        tickets.get(0).click();
        clickAccordianCaseDetails();
        List<WebElement> eles = driver.findElements(caseDetailsElements);
        List<String> issues = new ArrayList<>();
        for(int i=0; i<eles.size(); i++) {
            issues.add(eles.get(i).findElement(casePropertyDescription).getText().trim().toLowerCase());
        }
        if(!issues.contains(issueSubType.toLowerCase())) {
            return false;
        }
        goToCaseListScreen();
        clickFiltersBtn();
        setIssueSubTypeFilter(issueSubType);
        clickApplyBtn();
        visibleText(rightPaginationButton);
        while(driver.findElement(rightPaginationButton).isEnabled() && attempt < 5) {
            clickable(rightPaginationButton);
            driver.findElement(rightPaginationButton).click();
            attempt++;
            visibleText(rightPaginationButton);
        }
        visibleText(ticketCards);
        tickets = driver.findElements(ticketCards);
        tickets.get(tickets.size()-1).click();
        clickAccordianCaseDetails();
        try {
            eles = driver.findElements(caseDetailsElements);
            issues = new ArrayList<>();
            for(int i=0; i<eles.size(); i++) {
                issues.add(eles.get(i).findElement(casePropertyDescription).getText().trim().toLowerCase());
            }
        } catch (Exception e) {
            eles = driver.findElements(caseDetailsElements);
            issues = new ArrayList<>();
            for(int i=0; i<eles.size(); i++) {
                issues.add(eles.get(i).findElement(casePropertyDescription).getText().trim().toLowerCase());
            }
        }
        if(!issues.contains(issueSubType.toLowerCase())) {
            return false;
        }
        goToCaseListScreen();
        return true;
    }
    
    //@Author : Gaurang
    // Apply the customer name, status and priority filter and check the result
    public Boolean checkCustomerNameStatusPriorityFilter(HashMap<String, String> ticketData) {
        int attempt = 0;
        visibleText(filterCustomerNameInput);
        clickable(filterCustomerNameInput);
        action.moveToElement(driver.findElement(filterCustomerNameInput)).click().sendKeys(ticketData.get("Customer Name")).build().perform();
        setStatusFilter(ticketData.get("caseStatus"));
        setPriorityFilter(ticketData.get("casePriority"));
        clickApplyBtn();
        visibleText(ticketCards);
        List<WebElement> tickets = driver.findElements(ticketCards);
        if(tickets.get(0).findElement(ticketPriority).getText().compareToIgnoreCase(ticketData.get("casePriority")) != 0) {
            return false;
        }
        if(tickets.get(0).findElement(ticketStatus).getText().compareToIgnoreCase(ticketData.get("caseStatus")) != 0) {
            return false;
        }
        tickets.get(0).click();
        clickAccordianCustomerDetails();
        visibleText(driver.findElement(accordianCustomerDetails).findElement(accordianDescription1));
        if(!driver.findElement(accordianCustomerDetails).findElement(accordianDescription1).getText().toLowerCase().contains(ticketData.get("Customer Name").toLowerCase())) {
            return false;
        }
        goToCaseListScreen();
        clickFiltersBtn();
        visibleText(filterCustomerNameInput);
        clickable(filterCustomerNameInput);
        action.moveToElement(driver.findElement(filterCustomerNameInput)).click().sendKeys(ticketData.get("Customer Name")).build().perform();
        setStatusFilter(ticketData.get("caseStatus"));
        setPriorityFilter(ticketData.get("casePriority"));
        clickApplyBtn();
        visibleText(rightPaginationButton);
        while(driver.findElement(rightPaginationButton).isEnabled() && attempt < 5) {
            clickable(rightPaginationButton);
            driver.findElement(rightPaginationButton).click();
            attempt++;
            visibleText(rightPaginationButton);
        }
        visibleText(ticketCards);
        tickets = driver.findElements(ticketCards);
        if(tickets.get(tickets.size()-1).findElement(ticketPriority).getText().compareToIgnoreCase(ticketData.get("casePriority")) != 0) {
            return false;
        }
        if(tickets.get(tickets.size()-1).findElement(ticketStatus).getText().compareToIgnoreCase(ticketData.get("caseStatus")) != 0) {
            return false;
        }
        tickets.get(tickets.size()-1).click();
        clickAccordianCustomerDetails();
        visibleText(driver.findElement(accordianCustomerDetails).findElement(accordianDescription1));
        if(!driver.findElement(accordianCustomerDetails).findElement(accordianDescription1).getText().toLowerCase().contains(ticketData.get("Customer Name").toLowerCase())) {
            return false;
        }
        goToCaseListScreen();
        return true;
    }
    
    //@Author : Gaurang
    // Apply the issue type filter and check the result
    public Boolean checkGroupSubCategoryFilter(HashMap<String, String> ticketData) {
        int attempt = 0;
        setGroupFilter(ticketData.get("caseGroup"));
        setSubCategoryFilter(ticketData.get("Sub Category"));
        clickApplyBtn();
        visibleText(ticketCards);
        List<WebElement> tickets = driver.findElements(ticketCards);
        if(tickets.get(0).findElement(ticketSubCategory).getText().compareToIgnoreCase(ticketData.get("Sub Category")) != 0) {
            return false;
        }
        tickets.get(0).click();
        visibleText(caseGroupLabel);
        if(driver.findElement(caseGroupLabel).getAttribute("value").compareToIgnoreCase(ticketData.get("caseGroup")) != 0) {
            return false;
        }
        goToCaseListScreen();
        clickFiltersBtn();
        setGroupFilter(ticketData.get("caseGroup"));
        setSubCategoryFilter(ticketData.get("Sub Category"));
        clickApplyBtn();
        visibleText(rightPaginationButton);
        while(driver.findElement(rightPaginationButton).isEnabled() && attempt < 5) {
            clickable(rightPaginationButton);
            driver.findElement(rightPaginationButton).click();
            attempt++;
            visibleText(rightPaginationButton);
        }
        visibleText(ticketCards);
        tickets = driver.findElements(ticketCards);
        if(tickets.get(tickets.size()-1).findElement(ticketSubCategory).getText().compareToIgnoreCase(ticketData.get("Sub Category")) != 0) {
            return false;
        }
        tickets.get(tickets.size()-1).click();
        visibleText(caseGroupLabel);
        if(driver.findElement(caseGroupLabel).getAttribute("value").compareToIgnoreCase(ticketData.get("caseGroup")) != 0) {
            return false;
        }
        goToCaseListScreen();
        return true;
    }
    
  //@Author : Gaurang
    // Apply the issue type filter and check the result
    public Boolean checkGroupIssueTypeFilter(HashMap<String, String> ticketData) {
        int attempt = 0;
        if(!setGroupFilter(ticketData.get("caseGroup"))) {
            return false;
        }
        setIssueTypeFilter(ticketData.get("Issue Type"));
        clickApplyBtn();
        visibleText(ticketCards);
        List<WebElement> tickets = driver.findElements(ticketCards);
        tickets.get(0).click();
        visibleText(caseGroupLabel);
        if(driver.findElement(caseGroupLabel).getAttribute("value").compareToIgnoreCase(ticketData.get("caseGroup")) != 0) {
            return false;
        }
        clickAccordianCaseDetails();
        List<WebElement> eles = driver.findElements(caseDetailsElements);
        List<String> issues = new ArrayList<>();
        for(int i=0; i<eles.size(); i++) {
            issues.add(eles.get(i).findElement(casePropertyDescription).getText().trim().toLowerCase());
        }
        if(!issues.contains(ticketData.get("Issue Type").toLowerCase())) {
            return false;
        }
        goToCaseListScreen();
        clickFiltersBtn();
        if(!setGroupFilter(ticketData.get("caseGroup"))) {
            return false;
        }
        setIssueTypeFilter(ticketData.get("Issue Type"));
        clickApplyBtn();
        visibleText(rightPaginationButton);
        while(driver.findElement(rightPaginationButton).isEnabled() && attempt < 5) {
            clickable(rightPaginationButton);
            driver.findElement(rightPaginationButton).click();
            attempt++;
            visibleText(rightPaginationButton);
        }
        visibleText(ticketCards);
        tickets = driver.findElements(ticketCards);
        tickets.get(tickets.size()-1).click();
        visibleText(caseGroupLabel);
        if(driver.findElement(caseGroupLabel).getAttribute("value").compareToIgnoreCase(ticketData.get("caseGroup")) != 0) {
            return false;
        }
        clickAccordianCaseDetails();
        eles = driver.findElements(caseDetailsElements);
        issues = new ArrayList<>();
        for(int i=0; i<eles.size(); i++) {
            issues.add(eles.get(i).findElement(casePropertyDescription).getText().trim().toLowerCase());
        }
        if(!issues.contains(ticketData.get("Issue Type").toLowerCase())) {
            return false;
        }
        goToCaseListScreen();
        return true;
    }

    //@Author : Gaurang
    // Select the correct project for the ticket that was just created
    public void selectProject(String category) {
        visibleText(projectDropdown);
        clickable(projectDropdown);
        driver.findElement(projectDropdown).click();
        visibleText(dropdownOption);
        List<WebElement> options = driver.findElements(dropdownOption);
        for(int i=0; i<options.size(); i++) {
            if(category.contains(options.get(i).getText())) {
                options.get(i).click();
                break;
            }
        }
    }
    
    
    public void jsClick(WebElement el) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].click();", el);
        } catch (Exception e) {
            System.out.println("=============================================================");
            System.out.println("Exception-jsClick(): " + e.getMessage());
            //takeScreenShot();
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }
}
