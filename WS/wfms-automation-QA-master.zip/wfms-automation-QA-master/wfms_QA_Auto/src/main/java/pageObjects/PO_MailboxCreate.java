package pageObjects;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.github.javafaker.Faker;

import resources.base;

public class PO_MailboxCreate extends base {
    public WebDriver driver;
    private Faker faker = new Faker();
    private Random random = new Random();
    private Actions action;

    // left side hamburger menu
    private By casesIcon = By.xpath("//div[@class='menuItems-Wrapper']//div[text()='Cases']");
    private By groupsIcon = By.xpath("//div[@class='menuItems-Wrapper']//div[text()='Groups']");
    private By agentsIcon = By.xpath("//div[@class='menuItems-Wrapper']//div[text()='Agents']");
    private By mailboxIcon = By.xpath("//div[contains(@class,'menuItems-Wrapper')]//div[text()='Mailbox']");
    private By logoutIcon = By.xpath("//div[@class='menuItems-Wrapper']//div[text()='Logout']");

    // header section
    private By headerText = By.className("header__left-section");
    private By createBtn = By.xpath("//button[contains(text(),'CREATE')]");
    private By searchBar = By.xpath("//div[@data-testid='search-bar']");
    private By searchBarInput = By.xpath("//input[@data-testid='search-bar-input']");
    private By projectDropdown = By.xpath("//div[@class='dropdown__dropdown projectDropdown__container__content__dropDown'] | //div[@class='projectDropdown__container__content__userName__dropDownDisabled']");
    // | //div[@class='projectDropdown__container']
    private By dropdownOption = By.xpath("//div[@class='dropdown__dropdownOption']");

    // form container mailbox screen
    private By titleText = By.xpath("//div[@class='createEditMailbox__container__title']");
    private By nameLabel = By.xpath("//div[@data-testid='formLabel']//div[contains(text(),'Name')]");
    private By emailLabel = By.xpath("//div[@data-testid='formLabel']//div[text()='Your support email']");
    private By passwordLabel = By.xpath("//div[@data-testid='formLabel']//div[text()='Mailbox Token id']");
    private By assignToGroupLabel = By.xpath("//div[@data-testid='formLabel']//div[text()='Assign to Group']");
    private By nameInput = By.xpath("//input[@placeholder='Enter Name']");
    private By emailInput = By.xpath("//input[@placeholder='Enter your email address']");
    private By passwordInput = By.xpath("//input[@placeholder='Enter your mailbox token id here']");
    private By dropdownOptions = By.xpath("//div[@class='dropdown__dropdownOption']");
    private By groupDropdown = By.xpath("//div[@data-testid='formDropdown']//div[@class='dropdown__selectedLabelContainer']");
    private By saveBtn = By.xpath("//button[contains(text(),'Save')]");
    private By cancelBtn = By.xpath("//button[contains(text(),'Cancel')]");
    private By errorMessage = By.xpath("//div[@class='formInput__errorText']");
    private By toastMessage = By.xpath("//div[contains(@class,'toast__Container')]");

    // popup after mailbox is created
    private By closeBtn = By.xpath("//img[@class='button__icon--style']");
    private By createdSuccessfullyMessage = By.xpath("//div[@class='modal-ui_message']");

    // mailbox list container header
    private By rightPaginationButton = By.xpath("//button[contains(@class,'button_right_icon')]");

    // mailbox list container
    private By mailboxListItem = By
            .xpath("//div[@class='mailboxList__container__card__item mailboxList__container__card__common']");
    private By itemName = By.xpath("descendant::div[contains(@class,'name')]");
    private By itemEmail = By.xpath("descendant::div[contains(@class,'email')]");
    private By itemGroup = By.xpath("descendant::div[contains(@class,'group')]");

    //@Author : Gaurang
    // Constructor for the PO_MailboxCreate class
    public PO_MailboxCreate(WebDriver driver) {
        super();
        this.driver = driver;
        this.action = new Actions(this.driver);
    }
    
    //@Author : Gaurang
    // get the Header text
    public String getHeaderText() {
        visibleText(headerText);
        return driver.findElement(headerText).getText();
    }

    //@Author : Gaurang
    // get the create button text
    public String getCreateBtn() {
        visibleText(createBtn);
        return driver.findElement(createBtn).getText();
    }

    //@Author : Gaurang
    // get the case icon text
    public String getCasesIcon() {
        visibleText(casesIcon);
        return driver.findElement(casesIcon).getText();
    }

    //@Author : Gaurang
    // get the group icon text
    public String getGroupsIcon() {
        visibleText(groupsIcon);
        return driver.findElement(groupsIcon).getText();
    }

    //@Author : Gaurang
    // get the agent icon text
    public String getAgentsIcon() {
        visibleText(agentsIcon);
        return driver.findElement(agentsIcon).getText();
    }

    //@Author : Gaurang
    // get the mailbox icon text
    public String getMailboxIcon() {
        visibleText(mailboxIcon);
        return driver.findElement(mailboxIcon).getText();
    }

    //@Author : Gaurang
    // get the logout icon text
    public String getLogoutIcon() {
        visibleText(logoutIcon);
        return driver.findElement(logoutIcon).getText();
    }

    //@Author : Gaurang
    // get the title text
    public String getTitleText() {
        visibleText(titleText);
        return driver.findElement(titleText).getText();
    }

    //@Author : Gaurang
    // get the name label text
    public String getNameLabel() {
        visibleText(nameLabel);
        return driver.findElement(nameLabel).getText();
    }

    //@Author : Gaurang
    // get the email label text
    public String getEmailLabel() {
        visibleText(emailLabel);
        return driver.findElement(emailLabel).getText();
    }

    //@Author : Gaurang
    // get the password label text
    public String getPasswordLabel() {
        visibleText(passwordLabel);
        return driver.findElement(passwordLabel).getText();
    }

    //@Author : Gaurang
    // get the assign to group label text
    public String getAssignToGroupLabel() {
        visibleText(assignToGroupLabel);
        return driver.findElement(assignToGroupLabel).getText();
    }

    //@Author : Gaurang
    // get the name input placeholder
    public String getNameInputPlaceholder() {
        visibleText(nameInput);
        return driver.findElement(nameInput).getAttribute("placeholder");
    }

    //@Author : Gaurang
    // get the email input placeholder
    public String getEmailInputPlaceholder() {
        visibleText(emailInput);
        return driver.findElement(emailInput).getAttribute("placeholder");
    }

    //@Author : Gaurang
    // get the password input placeholder
    public String getPasswordInputPlaceholder() {
        visibleText(passwordInput);
        return driver.findElement(passwordInput).getAttribute("placeholder");
    }

    //@Author : Gaurang
    // get the group dropdown label text
    public String getGroupDropdownLabel() {
        visibleText(groupDropdown);
        return driver.findElement(groupDropdown).getText();
    }

    //@Author : Gaurang
    // check if the search bar is clickable
    public Boolean checkCLickableSearchBar() {
        clickable(searchBar);
        return true;
    }

    //@Author : Gaurang
    // check if the search bar input is clickable
    public Boolean checkCLickableSearchBarInput() {
        driver.findElement(searchBar).click();
        clickable(searchBarInput);
        return true;
    }

    //@Author : Gaurang
    // go to mailbox list screen
    public void goToMailboxListScreen() {
        clickable(mailboxIcon);
        driver.findElement(mailboxIcon).click();
    }

    //@Author : Gaurang
    // click the cancel button
    public void clickCancelBtn() {
        visibleText(cancelBtn);
        clickable(cancelBtn);
        driver.findElement(cancelBtn).click();
    }

    //@Author : Gaurang
    // goto mailbox create screen
    public void goToMailboxCreateScreen() {
        clickable(mailboxIcon);
        jsClick(driver.findElement(mailboxIcon));
        clickable(createBtn);
        jsClick(driver.findElement(createBtn));
    }

    //@Author : Gaurang
    // create a mailbox with random values
    public HashMap<String, String> createRandomMailbox() {
        HashMap<String, String> data = new HashMap<>();
        String name = faker.name().firstName().replaceAll("'", "") + " " + faker.name().lastName().replaceAll("'", "");
        String email = name.replace(" ", ".") + Integer.toString(random.nextInt(5000)) + "@byjus.com";
        String password = email.split("@")[0];
        data.put("name", name);
        data.put("email", email);
        data.put("password", password);
        data.put("group", "QA_AutomationTesting");
        fillMailBoxInfo(data);
        clickable(saveBtn);
        driver.findElement(saveBtn).click();
        visibleText(createdSuccessfullyMessage);
        data.put("successfulMessage", driver.findElement(createdSuccessfullyMessage).getText());
        visibleText(closeBtn);
        clickable(closeBtn);
        jsClick(driver.findElement(closeBtn));
        return data;
    }

    //@Author : Gaurang
    // fill the input fields of the create mailbox screen with the provided data
    public void fillMailBoxInfo(HashMap<String, String> data) {
        visibleText(nameInput);
        visibleText(emailInput);
        visibleText(passwordInput);
        visibleText(groupDropdown);
        action.moveToElement(driver.findElement(nameInput)).click().sendKeys(data.get("name")).build().perform();
        action.moveToElement(driver.findElement(emailInput)).click().sendKeys(data.get("email")).build().perform();
        action.moveToElement(driver.findElement(passwordInput)).click().sendKeys(data.get("password")).build()
                .perform();
        driver.findElement(groupDropdown).click();
        visibleText(dropdownOptions);
        List<WebElement> options = driver.findElements(dropdownOptions);
        for (int i = 0; i < options.size(); i++) {
            if (options.get(i).getText().compareTo(data.get("group")) == 0) {
                options.get(i).click();
                break;
            }
        }
    }

    //@Author : Gaurang
    // check for the duplicate mailbox in the mailbox list screen
    public String checkDuplicateMailbox(HashMap<String, String> data) {
        fillMailBoxInfo(data);
        clickable(saveBtn);
        driver.findElement(saveBtn).click();
        visibleText(toastMessage);
        return driver.findElement(toastMessage).getText();
    }


    //@Author : Gaurang
    // check for a specific mailbox in the mailbox list screen
    public Boolean checkSpecificMailbox(HashMap<String, String> mailbox) {
        List<WebElement> parent = new ArrayList<>();
        do {
            visibleText(mailboxListItem);
            parent = driver.findElements(mailboxListItem);
            for (int i = 0; i < parent.size(); i++) {
                String email = parent.get(i).findElement(itemEmail).getText();
                String name = parent.get(i).findElement(itemName).getText();
                String group = parent.get(i).findElement(itemGroup).getText();
                if (email.compareTo(mailbox.get("email")) == 0 &&
                        name.compareTo(mailbox.get("name")) == 0 &&
                        group.compareTo(mailbox.get("group")) == 0) {
                    return true;
                }
            }
            if (driver.findElement(rightPaginationButton).isEnabled()) {
                driver.findElement(rightPaginationButton).click();
            } else {
                break;
            }
        } while (true);
        return false;
    }

    //@Author : Gaurang
    // check for error message when wrong email format is entered
    public String checkWrongEmailErrorMessage() {
        visibleText(emailInput);
        action.moveToElement(driver.findElement(emailInput)).click().sendKeys("wrongFormat").build().perform();
        visibleText(errorMessage);
        return driver.findElement(errorMessage).getText();
    }
    
    //@Author : Gaurang
    // check for error message when wrong email format is entered
    public boolean isErrorMessageStillPresent() {
        visibleText(emailInput);
        action.moveToElement(driver.findElement(emailInput)).doubleClick().sendKeys(Keys.DELETE).build().perform();
        return checkElementExists(errorMessage);
    }
    
    //@Author : Gaurang
    // Select the correct project for the ticket that was just created
    public void selectProject(String category) {
        visibleText(projectDropdown);
        clickable(projectDropdown);
        jsClick(driver.findElement(projectDropdown));
        try {
        visibleText(dropdownOption);
        }
        catch(Exception e) {
            jsClick(driver.findElement(projectDropdown));
            visibleText(dropdownOption);
        }
        try {
            List<WebElement> options = driver.findElements(dropdownOption);
            for(int i=0; i<options.size(); i++) {
                if(options.get(i).getText().compareToIgnoreCase(category) == 0) {
                    options.get(i).click();
                    break;
                }
            }
        }
        catch (StaleElementReferenceException e) {
            List<WebElement> options = driver.findElements(dropdownOption);
            for(int i=0; i<options.size(); i++) {
                if(options.get(i).getText().compareToIgnoreCase(category) == 0) {
                    options.get(i).click();
                    break;
                }
            }
        }
    }

    // ------------------------------------------------------------------------------------------------

    public boolean visibleText(By element) {
        WebDriverWait wait = new WebDriverWait(driver, 10);

        wait.ignoring(StaleElementReferenceException.class)
                .until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));
        return false;
    }

    public boolean clickable(By element) {
        WebDriverWait wait = new WebDriverWait(driver, 10);

        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));

        return false;
    }

    public boolean clickable(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, 10);

        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));

        return false;
    }
    
    public void jsClick(WebElement el) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].click();", el);
            System.out.println("Element clicked");
        } catch (Exception e) {
            System.out.println("=============================================================");
            System.out.println("Exception-jsClick(): " + e.getMessage());
            //takeScreenShot();
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }
    
    public boolean checkElementExists(By xpath) {
        boolean result = false;
        try {
            driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
            driver.findElement(xpath);
        }
        catch(org.openqa.selenium.NoSuchElementException ex) {
            result = false;
        }
        finally {
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        return result;
    }
}
