package pageObjects;

import java.util.HashMap;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PO_EditCaseDigitalFinance {
    
    public WebDriver driver;
    public WebDriverWait wait;
    public HashMap<String, String> data;
    
    public PO_EditCaseDigitalFinance(WebDriver driver) {
        
        this.driver = driver;
        data = new HashMap<>();
        wait = new WebDriverWait(driver, 10);
    }
    
    public void click(String xpath) {
        By e = By.xpath(xpath);
        
        try {
            
            wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(e)).click();
        }
        catch(Exception t){
            
            wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(e)).click();
        }
    }
    
    // @Author = Ankur
    // @Description = edit case details
    public HashMap<String, String> editCase() throws InterruptedException {
        scrollToTop();
        click("//span[text()='CASE DETAILS']/parent::div/img[@alt='edit-case-details']");
        waitForSeconds(2);
        setDropdownValue("Sub Category", ""); 
        
        if(getDropdownValue("Sub Category").equals("Digital Finance")) {
            
            setDropdownValue("Digital Finance Types", "");
            data.put("Issue Type", data.get("Digital Finance Types"));
            
            if(getDropdownValue("Digital Finance Types").equals("Loan Verfication")) {
                
                setDropdownValue("Loan Verification Types", "");
                data.put("Issue Sub Type", data.get("Loan Verification Types"));
                
                if(getDropdownValue("Loan Verification Types").equals("New Email")) {
                    
                    setDropdownValue("Priority", "");
                    setInputField("Order ID", "Test");
                }
                else if(getDropdownValue("Loan Verification Types").equals("New Ticket")) {
                    
                    setDropdownValue("Priority", "");     
                }
                
                setDropdownValue("Associate", "");
            }
            else if(getDropdownValue("Digital Finance Types").equals("Customer Grievance")) {
                
                setInputField("Name of the Student", "Test");
                setDropdownValue("Language Preference", "");
                setInputField("Application ID", "Test");
                
                setDropdownValue("Ticket Source", "");
                data.put("Issue Sub Type", data.get("Ticket Source"));
                
                setInputField("Order ID", "Test");
                setDropdownValue("Lender", "");
                setDropdownValue("QRC Type", "");
                
                if(getDropdownValue("QRC Type").equals("Complaint")) {
                    
                    setDropdownValue("Complaint Issue Type", "");
                    
                    if(getDropdownValue("Complaint Issue Type").equals("Repayment & Collection Team Assistance")) {
                        
                        setDropdownValue("Repayment & Collection team Assistance-Complaint", "");
                    }
                    else if(getDropdownValue("Complaint Issue Type").equals("Other Finance Issues")) {
                        
                        setDropdownValue("Other finance issues-Complaint", "");
                    }
                }
                else if(getDropdownValue("QRC Type").equals("Query")) {
                    
                    setDropdownValue("Query Issue Type", "");
                    
                    if(getDropdownValue("Query Issue Type").equals("EMI Details")) {
                        
                        setDropdownValue("EMI Details Issues", "");
                    }
                    else if(getDropdownValue("Query Issue Type").equals("EMI Payment Issue")) {
                        
                        setDropdownValue("EMI Payment Issue - Query", "");
                    }
                    else if(getDropdownValue("Query Issue Type").equals("Other Finance Issues")) {
                        
                        setDropdownValue("Other finance issues - Query", "");
                    }
                }
                else if(getDropdownValue("QRC Type").equals("Request")) {
                    
                    setDropdownValue("Request Issue Type", "");
                    
                    if(getDropdownValue("Request Issue Type").equals("Loan Documents")) {
                        
                        setDropdownValue("Loan Documents - Request", "");
                    }
                    else if(getDropdownValue("Request Issue Type").equals("Repayment & Collection Team Assistance")) {
                        
                        setDropdownValue("Repayment & Collection team Assistance - Request", "");
                    }
                    else if(getDropdownValue("Request Issue Type").equals("EMI Payment Issue")) {
                        
                        setDropdownValue("EMI Payment Issue - Request", "");
                    }
                    else if(getDropdownValue("Request Issue Type").equals("Other Finance Issues")) {
                        
                        setDropdownValue("Other finance issues - Request", "");
                    }
                }
                setDropdownValue("Priority", "");
            }
            else if(getDropdownValue("Digital Finance Types").equals("NACH Ops")) {
                
                setDropdownValue("Ticket Source", "");
                data.put("Issue Sub Type", data.get("Ticket Source"));
                
                setDropdownValue("Priority", "");
            }
        }
        else if(getDropdownValue("Sub Category").equals("Loan Verification-CB Request")) {
            
            setDropdownValue("Request Type", "");
            data.put("Issue Type", data.get("Request Type"));
            
            if(getDropdownValue("Request Type").equals("Callback Request")) {
                
                setInputField("Order-ID", "Test");
                
                setDropdownValue("Team Heads", "");
                data.put("Issue Sub Type", data.get("Team Heads"));
                
                setDate("Call back Date", "");
                setDropdownValue("Call back Time slot", "");
            }
            else if(getDropdownValue("Request Type").equals("DP Reconciled")) {
                
                setInputField("Order-ID", "Test");
                
                setDropdownValue("Team Heads", "");
                data.put("Issue Sub Type", data.get("Team Heads"));
                
                setDropdownValue("MOP Status", "");
            }
        }
        
        waitForSeconds(2);
        
        click("//div[contains(@class,'filter__buttons')]//button[text()='Update']");
        
        waitForSeconds(2);
        
        return data;
    }
    
    // @Author = Ankur
    // @Description = set dropdown value
    public void setDropdownValue(String label, String value) {
        
        // if value is empty string then select random option from dropdown
        
        By e = By.xpath("//div[@class='editCase__container']//div[text()='" + label + "']/parent::div/parent::div//div[@class='dropdown__selectedLabel']");
        
        try {
            
            wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(e)).click();
        }
        catch(Exception t){
            driver.get(driver.getCurrentUrl());
            visibleText(driver.findElement(e));
            jsClick(driver.findElement(e));
        }
        
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='dropdown__dropdownOption']")));
        List<WebElement> options = driver.findElements(By.xpath("//div[@class='dropdown__dropdownOption']"));
        
        if(value.equals(""))
            value = options.get(new Random().nextInt(options.size())).getText();
        
        try {
            
            for(int i = 0; i < options.size(); ++i) {
                if(options.get(i).getText().equals(value)) {
                    options.get(i).click();
                    break;
                }
            }
        }
        catch(StaleElementReferenceException e1) {
            options = driver.findElements(By.xpath("//div[@class='dropdown__dropdownOption']"));
            
            for(int i = 0; i < options.size(); ++i) {
                if(options.get(i).getText().equals(value)) {
//                    options.get(i).click();
                    jsClick(options.get(i));
                    break;
                }
            }
        }
        
        System.out.println(label + " :\t" + value);
        data.put(label, value);
    }
    
    // @Author = Ankur
    // @Description = get dropdown value
    public String getDropdownValue(String label) {
        
        By e = By.xpath("//div[@class='editCase__container']//div[text()='" + label + "']/parent::div/parent::div//div[@class='dropdown__selectedLabel']");
        
        return wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(e)).getText();
    }
    
    // @Author = Ankur
    // @Description = set input field
    public void setInputField(String label, String value) {
        
        By e = By.xpath("//div[@class='editCase__container']//div[text()='" + label + "']/parent::div/parent::div//input");
        Actions action = new Actions(driver);
        //scrollIntoView(driver.findElement(e));
        action.moveToElement(driver.findElement(e)).build().perform();
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(e)).clear();
       
        action.moveToElement(driver.findElement(e)).click().sendKeys(value).build().perform();
//        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(e)).sendKeys(value);
        
        System.out.println(label + " :\t" + value);
        data.put(label, value);
    }
    
    // @Author = Ankur
    // @Description = get input field value
    public String getInputField(String label) {
        
        By e = By.xpath("//div[@class='editCase__container']//div[text()='" + label + "']/parent::div/parent::div//input");
        
        return wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(e)).getAttribute("value");
    }
    
    // @Author = Ankur
    // @Descriptioin = set textbox value
    public void setTextboxValue(String label, String value) {
        
        By e = By.xpath("//div[@class='editCase__container']//div[text()='" + label + "']/parent::div/parent::div//p");
        
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(e)).sendKeys(value);
        
        System.out.println(label + " :\t" + value);
        data.put(label, value);
    }
    
    // @Author = Ankur
    // @Description = set data
    public void setDate(String label, String value) {
        
        By e = By.xpath("//div[@class='editCase__container']//div[text()='" + label + "']/parent::div/parent::div//input");
        try {
         jsClick(driver.findElement(e));   
        }
        catch(Exception d) {
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(e)).click();
        }
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@aria-current='date']"))).click();
        value = getInputField(label);
        
        System.out.println(label + " :\t" + value);
        data.put(label, convertDate(value));
    }
    
    // @Author = Ankur
    // @Description = convert date
    public String convertDate(String date) {
        
        HashMap<String, String> month = new HashMap<>();
        month.put("01", "Jan");
        month.put("02", "Feb");
        month.put("03", "Mar");
        month.put("04", "Apr");
        month.put("05", "May");
        month.put("06", "Jun");
        month.put("07", "Jul");
        month.put("08", "Aug");
        month.put("09", "Sep");
        month.put("10", "Oct");
        month.put("11", "Nov");
        month.put("12", "Dec");
        
        String dd = date.substring(0, 2);
        String mm = date.substring(3, 5);
        String yy = date.substring(6);
        
        String newDate = dd + "-" + month.get(mm) + "-" + yy;
        
        return newDate;
    }
    
    // @Author = Ankur
    // @Description = wait for seconds
    public void waitForSeconds(int time) {
        
        try {
            
            Thread.sleep(time * 1000);
            
        } catch (Exception e) {
            
            e.printStackTrace();
        }
    }
    
    // @Author = kalam
    // @Description = js click
    public void jsClick(WebElement el) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].click();", el);
            System.out.println("Element clicked");
        } catch (Exception e) {
            System.out.println("=============================================================");
            System.out.println("Exception-jsClick(): " + e.getMessage());
            //takeScreenShot();
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }

    // @Author = Ankur
    // @Description = open case details accordian
    public void openCaseDetailsAccordian() {
        
        By ele = By.xpath("//span[text()='CASE DETAILS']/parent::div//img[@alt='icon']");
        
        try {
        
            driver.findElement(ele).click();
            
        } catch (Exception e) {
            
            jsClick(driver.findElement(ele));
        }
    }
    
    // @Author = Ankur
    // @Description = get count of fields in case details
    public int getNumberOfFieldsInCaseDetail() {
        
        By ele = By.xpath("//span[text()='CASE DETAILS']/parent::div/parent::div//div[@class='accordion__wrapper__content__item']");
        
        return driver.findElements(ele).size();
    }
    
    // @Author = Ankur
    // @Description = get name of field 
    public String getCaseDetailFieldHeading(String index) {
        
        By ele = By.xpath("(//span[text()='CASE DETAILS']/parent::div/parent::div//div[@class='accordion__wrapper__content__item__header'])[" + index + "]");
        
        try {
            
            return driver.findElement(ele).getText();
        }
        catch(Exception e) {
            
            return driver.findElement(ele).getText();
        }
        
    }
    
    public void scrollIntoView(WebElement element) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].scrollIntoView(true);", element);
            System.out.println("Page scrolled down");
        } catch (Exception e) {
            System.out.println("=============================================================");
            System.out.println("Exception-scrollIntoView(): " + e.getMessage());
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }
    
    public void scrollToTop() {
        try {
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("document.documentElement.scrollTop = 0;");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    // @Author = Ankur
    // @Description = get value of field 
    public String getCaseDetailFieldValue(String index) throws InterruptedException {
        Thread.sleep(500);
        By ele = By.xpath("(//span[text()='CASE DETAILS']/parent::div/parent::div//div[@class='accordion__wrapper__content__item__description'])[" + index + "]");
        
        try {
            
            return driver.findElement(ele).getText();
        }
        catch(Exception e) {
            
            return driver.findElement(ele).getText();
        }
    }
    
    // @Author = Kalam
    public boolean visibleText(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, 10);

        wait.ignoring(StaleElementReferenceException.class)
                .until(ExpectedConditions.visibilityOfAllElements(element));

        return false;
    }
}
