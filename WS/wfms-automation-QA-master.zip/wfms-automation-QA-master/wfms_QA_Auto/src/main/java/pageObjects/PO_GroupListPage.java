package pageObjects;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PO_GroupListPage {

    private WebDriver driver;
    public WebDriverWait wait;
    
    // constructor
    public PO_GroupListPage(WebDriver driver) {
        
        this.driver = driver;
        wait = new WebDriverWait(driver, 10);
    }
    
    // ----------------------------------------------------------------------------------------------------
    // xpaths of components in sidebar section
    // ----------------------------------------------------------------------------------------------------
    private String sidebarByjusLogoImageXpath = "//div[@data-testid='navMenu']/img";
    private String sidebarCasesTextXpath = "//div[@data-testid='navMenu__item']//div[text()='Cases']";
    private String sidebarGroupsTextXpath = "//div[@data-testid='navMenu__item']//div[text()='Groups']";
    private String sidebarAgentsTextXpath = "//div[@data-testid='navMenu__item']//div[text()='Agents']";
    private String sidebarMailboxTextXpath = "//div[@data-testid='navMenu__item']//div[text()='Mailbox']";
    private String sidebarLogoutTextXpath = "//div[@data-testid='navMenu__item']//div[text()='Logout']";
    
    // ----------------------------------------------------------------------------------------------------
    // xpaths of components in header section
    // ----------------------------------------------------------------------------------------------------
    private String headerCreateButtonXpath = "//button[text()='CREATE']";
    
    // ----------------------------------------------------------------------------------------------------
    // xpaths of components in toolbar section
    // ----------------------------------------------------------------------------------------------------
    private String toolbarSortByDropdownLabelXpath = "//div[contains(@class,'filterSort__container')]//span[text()='Sort By :']"; 
    private String toolbarSortByDropdownValueXpath = toolbarSortByDropdownLabelXpath + "/parent::div//div[@class='dropdown__selectedLabel']";
    private String toolbarSortByDropdownOptionsXpath = toolbarSortByDropdownLabelXpath + "/parent::div//div[@class='dropdown__dropdownOption']";
    private String toolbarPaginationTextXpath = "//div[contains(@class,'pagination_toolbar')]//span";
    private String toolbarPaginationRightButtonXpath = "(//div[contains(@class,'pagination_toolbar')]//button)[2]";
    private String toolbarFiltersButtonXpath = "//img[contains(@src,'filterIcon')]/parent::div";
    
    // ----------------------------------------------------------------------------------------------------
    // xpaths of components in filters menu
    // ----------------------------------------------------------------------------------------------------
    private String filtersMenuHeadingTextXpath = "//div[@class='slider__header']";
    private String filtersMenuCrossIconXpath = "//img[@class='slider__close']";
    private String filtersMenuGroupNameLabelXpath = "//div[@class='filterSort__body']//div[text()='Group Name']";
    private String filtersMenuGroupNameValueXpath = "//div[@class='filterSort__body']//div[text()='Group Name']/parent::div/parent::div//input";
    private String filtersMenuAgentNameLabelXpath = "//div[@class='filterSort__body']//div[text()='Agent Name']";
    private String filtersMenuAgentNameValueXpath = "//div[@class='filterSort__body']//div[text()='Agent Name']/parent::div/parent::div//input";
    private String filtersMenuCreatedAfterLabelXpath = "//div[@class='filterSort__body']//div[text()='Created After']";
    private String filtersMenuCreatedAfterValueXpath = "//div[@class='filterSort__body']//div[text()='Created After']/parent::div/parent::div//input";
    private String filtersMenuApplyButtonXpath = "//div[contains(@class,'filterSort__buttons')]//button[text()='Apply']";
    private String filtersMenuResetButtonXpath = "//div[contains(@class,'filterSort__buttons')]//button[text()='Reset']";
    
    
    // @Author = Ankur
    // click on groups text in sidebar menu to go to group list page
    public void goToGroupListPage() {
        try {
        clickElement(By.xpath(sidebarGroupsTextXpath));
        }
        catch(Exception e) {
            jsClick(driver.findElement(By.xpath(sidebarGroupsTextXpath)));
        }
    }
    
    // -------------------------------------------------
    // ******************** SIDEBAR ********************
    // -------------------------------------------------

    public boolean checkElementExists(String xpath) {
        boolean result = false;
        try {
            driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
            driver.findElement(By.xpath(xpath));
        }
        catch(org.openqa.selenium.NoSuchElementException ex) {
            result = false;
        }
        finally {
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        return result;
    }
    
    // @Author = Ankur
    // @Description = is sidebar mailbox icon present
    public Boolean isSidebarMailboxIconPresent() {
        
        return checkElementExists(sidebarMailboxTextXpath + "/parent::div//img");
    }
    
    // @Author = Ankur
    // @Description = is sidebar mailbox text present
    public Boolean isSidebarMailboxTextPresent() {
        
        return checkElementExists(sidebarMailboxTextXpath);
    }
    
    // @Author = Ankur
    // @Description = Get sidebar byjus logo source
    public String getSidebarByjusLogoSource() {
        
        return getAttributeValue(sidebarByjusLogoImageXpath, "src");
    }
    
    // @Author = Ankur
    // @Description = Get sidebar cases icon source
    public String getSidebarCasesIconSource() {
        
        return getAttributeValue(sidebarCasesTextXpath + "/parent::div//img", "src");
    }
    
    // @Author = Ankur
    // @Description = Get sidebar cases text
    public String getSidebarCasesText() {
        
        return getText(sidebarCasesTextXpath);
    }
    
    // @Author = Ankur
    // @Description = Get sidebar groups icon source
    public String getSidebarGroupsIconSource() {
        
        return getAttributeValue(sidebarGroupsTextXpath + "/parent::div//img", "src");
    }

    // @Author = Ankur
    // @Description = Get sidebar groups text
    public String getSidebarGroupsText() {
        
        return getText(sidebarGroupsTextXpath);
    }
    
    // @Author = Ankur
    // @Description = Get sidebar agents icon source
    public String getSidebarAgentsIconSource() {
        
        return getAttributeValue(sidebarAgentsTextXpath + "/parent::div//img", "src");
    }
    
    // @Author = Ankur
    // Description = Get sidebar agents text
    public String getSidebarAgentsText() {
        
        return getText(sidebarAgentsTextXpath);
    }
    
    // @Author = Ankur
    // @Descriptionn = Get sidebar mailbox icon source
    public String getSidebarMailboxIconSource() {
        
        return getAttributeValue(sidebarMailboxTextXpath + "/parent::div//img", "src");
    }
    
    // @Author = Ankur
    // @Description = Get sidebar mailbox text source
    public String getSidebarMailboxText() {
        
        return getText(sidebarMailboxTextXpath);
    }
    
    // @Author = Ankur
    // @Description = Get sidebar logout icon source
    public String getSidebarLogoutIconSource() {
        
        return getAttributeValue(sidebarLogoutTextXpath + "/parent::div//img", "src");
    }
    
    //@Author = Ankur
    // Description = Get sidebar logout text
    public String getSidebarLogoutText() {
        
        return getText(sidebarLogoutTextXpath);
    }
    
    // ------------------------------------------------
    // ******************** HEADER ********************
    // ------------------------------------------------
    
    // @Author = Ankur
    // @Description = Get header groups text
    public String getHeaderGroupsText() {
        
        return getText("//div[@class='header__left-section']").toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = Get header create button text
    public String getHeaderCreateButtonText() {
        waitForSecond(1);
        return getText(By.xpath(headerCreateButtonXpath)).toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = Get header create button plus icon source
    public String getHeaderCreateButtonPlusIconSource() {
        
        return getAttributeValue(headerCreateButtonXpath + "//img", "src");
    }
    
    // @Author = Ankur
    // @Description = is header create button present
    public Boolean isHeaderCreateButtonPresent() {
        
        return checkElementExists(headerCreateButtonXpath);
    }
    
    // @Author = Ankur
    // @Description = change role
    public void changeRole(String projectName) {
        try {
            jsClick(driver.findElement(By.xpath("//div[@class='projectDropdown']")));
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='projectDropdown']//div[contains(@class,'dropdownOption')] | //div[@class='projectDropdown']//div[contains(@class,'dropDown')]")));
        jsClick(driver.findElement(By.xpath("//div[@class='projectDropdown']//div[contains(@class,'dropdown') and text()='" + projectName + "']")));
        }
        catch(StaleElementReferenceException e) {
        driver.findElement(By.xpath("//div[@class='projectDropdown']")).click();
        driver.findElement(By.xpath("//div[@class='projectDropdown']")).click();
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='projectDropdown']//div[contains(@class,'dropdown')]")));
        try {
            jsClick(driver.findElement(By.xpath("//div[@class='projectDropdown']//div[contains(@class,'dropdown') and text()='" + projectName + "']")));
        }
        catch(Exception r) {
        driver.findElement(By.xpath("//div[@class='projectDropdown']//div[contains(@class,'dropdown') and text()='" + projectName + "']")).click();
        }
        }
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(headerCreateButtonXpath)));
    }
    
    // --------------------------------------------------------------------
    // ******************** TOOLBAR - SORT BY DROPDOWN ********************
    // --------------------------------------------------------------------
    
    // @Author = Ankur
    // @Description = get sort by dropdown label
    public String getSortByDropdownLabel() {
        
        return getText(toolbarSortByDropdownLabelXpath);
    }
    
    // @Author = Ankur
    // @Description = get sort by dropdown value
    public String getSortByDropdownValue() {
        
        return getText(toolbarSortByDropdownValueXpath);
    }
    
    // @Author = Ankur
    // @Description = set sort by dropdown value
    public void setSortByDropdownValue(String option) {
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(toolbarSortByDropdownValueXpath)));
//        driver.findElement(By.xpath(toolbarSortByDropdownValueXpath)).click();
        jsClick(driver.findElement(By.xpath(toolbarSortByDropdownValueXpath)));
        
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(toolbarSortByDropdownOptionsXpath)));
        List<WebElement> options = driver.findElements(By.xpath(toolbarSortByDropdownOptionsXpath));
        
        for(int i = 0; i < options.size(); ++i) {
            
            if(options.get(i).getText().trim().toLowerCase().contains(option)) {
                
                jsClick(options.get(i));
                break;
            }
        }
    }
    
    // --------------------------------------------------------------
    // ******************** TOOLBAR - PAGINATION ********************
    // --------------------------------------------------------------
    
    // @Author = Ankur
    // @Description = get pagination text
    public String getPaginatiorText() {
        
        return getText("//span[@class='paginator_text']");
    }
    
    // @Author = Ankur
    // @Description = get left pagination button icon source
    public String getLeftPaginationButtonIconSource() {
        
        return driver.findElement(By.xpath("//img[contains(@src,'chevronLeft')]")).getAttribute("src");
    }

    // @Author = Ankur
    // @Description = get right pagination button icon source
    public String getRightPaginationButtonIconSource() {
        
        return driver.findElement(By.xpath("//img[contains(@src,'chevronRight')]")).getAttribute("src");
    }
    
    // @Author = Ankur
    // @Description = go to last page
    public void goToLastPage() {
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(toolbarPaginationRightButtonXpath)));
        
        while(driver.findElement(By.xpath(toolbarPaginationRightButtonXpath)).isEnabled()) {
            
            driver.findElement(By.xpath(toolbarPaginationRightButtonXpath)).click();
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(toolbarPaginationRightButtonXpath)));
        }
    }
    
    // ------------------------------------------------------------------
    // ******************** TOOLBAR - FILTERS BUTTON ********************
    // ------------------------------------------------------------------
    
    // @Author = Ankur
    // @Description = get filters button text
    public String getFiltersButtonText() {
        
        return getText(toolbarFiltersButtonXpath + "//div[text()='Filters']");
    }
    
    // @Author = Ankur
    // @Description = get filters button icon source
    public String getFiltersButtonFilterIconSource() {
        
        return getAttributeValue(toolbarFiltersButtonXpath + "//img[contains(@src,'filterIcon')]", "src");
    }
    
    // @Author = Ankur
    // @Description = click on filters button
    public void openFiltersMenu() {
        try {
            jsClick(driver.findElement(By.xpath("//img[contains(@src,'filterIcon')]/parent::div")));
        }
        catch(Exception e) {
        click(toolbarFiltersButtonXpath);
        }
    }
    
    public void jsClick(WebElement el) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].click();", el);
            System.out.println("Element clicked");
        } catch (Exception e) {
            System.out.println("=============================================================");
            System.out.println("Exception-jsClick(): " + e.getMessage());
            //takeScreenShot();
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }
    
    // ----------------------------------------------------
    // ******************** GROUP LIST ********************
    // ----------------------------------------------------
    
    // @Author = Ankur
    // @Description = get name of groups
    public List<String> getGroupNames() {
        
        List<String> groupNames = new ArrayList<String>();
        
        // if there is no groups in group list, return empty group names
        if(getText(toolbarPaginationTextXpath).equalsIgnoreCase("showing 0 - 0 of 0 groups"))
            return groupNames;
        
        List<WebElement> groupNamesWE = getWebElements("//div[@class='groupList__container__card']//div[contains(@class,'groupList__container__card__common__left')]");
        
        for(int i = 1; i < groupNamesWE.size(); ++i)
            groupNames.add(groupNamesWE.get(i).getText());
        
//        for(int i = 1; i < groupNamesWE.size(); ++i)
//            groupNames.add(groupNamesWE.get(i).getAttribute("innerHtml"));
        
        for(String groupName: groupNames)
            System.out.println(groupName);
        
        return groupNames;
    }
    
    // @Author = Ankur
    // @Description = get agent names of each group
    public List<String> getAgentNames(String groupName) {
        
        // Defect - https://byjustech.atlassian.net/browse/WFM-283
        driver.findElement(By.xpath("//div[text()=\"" + groupName + "\"]/parent::div//img[@alt='Expand icon']")).click();
        
        List<String> agentNames = new ArrayList<>();
        
        List<WebElement> agents = driver.findElements(By.xpath("//div[text()=\"" + groupName + "\"]/parent::div//div[@class='badges__element__card__text']"));
        
        for(int i = 0; i < agents.size(); ++i)
            agentNames.add(agents.get(i).getText());
        
        return agentNames;
    }
    
    // ---------------------------------------------------------------
    // ******************** FILTERS MENU - HEADER ********************
    // ---------------------------------------------------------------
    
    // @Author = Ankur
    // @Description = get filters menu header text
    public String getFiltersMenuHeaderText() {
        
        return getText(By.xpath(filtersMenuHeadingTextXpath)).toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = get filters menu cross icon source
    public String getFiltersMenuCrossIconSource() {
        
        return getAttributeValue(By.xpath(filtersMenuCrossIconXpath), "src").toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = click on filters menu cross icon
    public void closeFiltersMenu() {
        
        clickButton(By.xpath(filtersMenuCrossIconXpath));
    }
    
    // -------------------------------------------------------------------------
    // ******************** FILTERS MENU - GROUP NAME FIELD ********************
    // -------------------------------------------------------------------------
    
    // @Author = Ankur
    // @Description = get group name field label text
    public String getGroupNameFieldLabel() {
        
        return getText(filtersMenuGroupNameLabelXpath);
    }
    
    // @Author = Ankur
    // @Description = get group name field placeholder value
    public String getGroupNameFieldPlaceholder() {
        
        return getAttributeValue(filtersMenuGroupNameValueXpath, "placeholder");
    }
    
    // @Author = Ankur
    // @Description = get group name field value
    public String getGroupName() {
        
        return getText(filtersMenuGroupNameValueXpath);
    }
    
    // @Author = Ankur
    // @Description = set group name field value
    public void setGroupName(String data) {
        
        setInputFieldValue(filtersMenuGroupNameValueXpath, data);
    }
    
    // -------------------------------------------------------------------------
    // ******************** FILTERS MENU - AGENT NAME FIELD ********************
    // -------------------------------------------------------------------------
    
    // @Author = Ankur
    // @Description = get agent name field label text
    public String getAgentNameFieldLabelText() {
        
        return getText(filtersMenuAgentNameLabelXpath);
    }
    
    // @Author = Ankur
    // @Description = get agent name field placeholder value
    public String getAgentNameFieldPlaceholderValue() {
        
        return getAttributeValue(filtersMenuAgentNameValueXpath, "placeholder");
    }
    
    // @Author = Ankur
    // @Description = get agent name field value
    public String getAgentNameValue() {
        
        return getText(filtersMenuAgentNameValueXpath);
    }
    
    // @Author = Ankur
    // @Description = set agent name field value
    public void setAgentName(String data) {
        
        setInputFieldValue(filtersMenuAgentNameValueXpath, data);
    }
    
    // ----------------------------------------------------------------------------
    // ******************** FILTERS MENU - CREATED AFTER FIELD ********************
    // ----------------------------------------------------------------------------
    
    // @Author = Ankur
    // @Description = get created after field label text
    public String getCreatedAfterFieldLabelText() {
        
        return getText(filtersMenuCreatedAfterLabelXpath);
    }
    
    // @Author = Ankur
    // @Description = get created after field placeholder value
    public String getCreatedAfterFieldPlaceholderValue() {
        
        return getAttributeValue(filtersMenuCreatedAfterValueXpath, "placeholder");
    }
    
    // @Author = Ankur
    // @Description = set created after field value
    public void setCreatedAfter() {
        
        // Defect - https://byjustech.atlassian.net/browse/WFM-201
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(filtersMenuCreatedAfterValueXpath))).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@aria-current='date']"))).click();
    }
    
    // @Author = Ankur
    // @Description = get created after field value
    public String getCreateAfter() {
        
        return wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(filtersMenuCreatedAfterValueXpath))).getText();
    }
    
    // ---------------------------------------------------------------------
    // ******************** FILTERS MENU - APPLY BUTTON ********************
    // ---------------------------------------------------------------------
    
    // @Author = Ankur
    // @Description = get apply button text
    public String getApplyButtonText() {
        
        return getText(By.xpath(filtersMenuApplyButtonXpath)).toLowerCase();
    }
    
    
    // @Author = Ankur
    // @Description = apply filters
    public void applyFilters() {
        
        clickButton(By.xpath(filtersMenuApplyButtonXpath));
    }
    
    // ---------------------------------------------------------------------
    // ******************** FILTERS MENU - RESET BUTTON ********************
    // ---------------------------------------------------------------------
    
    // @Author = Ankur
    // @Description = get reset button text
    public String getResetButtonText() {
        
        return getText(By.xpath(filtersMenuResetButtonXpath)).toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = reset all filters
    public void resetFilters() {
        
        clickButton(By.xpath(filtersMenuResetButtonXpath));
    }
    
    // @Author = Ankur
    // set date value : It will select a random date in previous 10 months.
    public void setFiltersSliderDateFieldValue() {
        
//        clickButton(By.xpath(filtersMenuCreatedAfterFieldXpath));
        
        int t = new Random().nextInt(10); // generate a random number between 0 - 9
        
        // click on previous month icon t times
        for(int i = 0; i < t; ++i) {
            
            clickButton(By.xpath("//div[@class='react-datepicker']//button[@aria-label='Previous Month']"));
        }
        
        String currMonth = getText(By.xpath("//div[@class='react-datepicker__current-month']")).split(" ")[0];
        
        System.out.println(currMonth);
        
        // now select any random date of current month
        clickButton(By.xpath("(//div[contains(@aria-label,'" + currMonth + "')])[" + Integer.toString(1 + new Random().nextInt(30)) + "]"));
    }
    
    // ----------------------------------------------------------
    // ******************** NO GROUPS SCREEN ********************
    // ---------------------------------------------------------- 
    
    // @Author = Ankur
    // @Description = get no groups screen image source
    public String getNoGroupsScreenImageSource() {
        
        return getAttributeValue("//div[@data-testid='fallback-ui']//img", "src");
    }
    
    // @Author = Ankur
    // @Description = get no groups screen 
    public String getNoGroupsScreenText() {
        
        return getText("//div[@data-testid='fallback-ui']//div[@data-testid='title']");
    }
    
    // ---------------------------------------------------------
    // ******************** GENERIC METHODS ********************
    // ---------------------------------------------------------
    
    // @Author = Ankur
    // @Description = click on an element
    public void click(String xpath) {
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath))).click();
    }
    
    // @Author = Ankur
    // get attribute value of an element
    public String getAttributeValue(String xpath, String attribute) {
        
        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath))).getAttribute(attribute).trim().toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = Get text of a web element
    public String getText(String xpath) {
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
        return driver.findElement(By.xpath(xpath)).getText().trim().toLowerCase();
    }
    
    // @Author = Ankur
    // get attribute value of an element
    public String getAttributeValue(By e, String attribute) {
        
        return new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(e)).getAttribute(attribute);
    }
    
    // @Author = Ankur
    // get text in element using its by locator
    public String getText(By e) {
        
        return new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(e)).getText();
    }
    
    //@Author = Ankur
    // set value in an input field
    public void setInputFieldValue(By e, String data) {
        
        new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(e)).clear();
        driver.findElement(e).sendKeys(data);
    }
    
    //@Author = Ankur
    // set value in an input field
    public void setInputFieldValue(String xpath, String data) {
        
        new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath))).clear();
        driver.findElement(By.xpath(xpath)).sendKeys(data);
    }
    
    // @Author = Ankur
    // get value in an input field
    public String getInputFieldValue(By e) {
        
        return getAttributeValue(e, "value");
    }
    
    // @Author = Ankur
    // click a button
    public void clickButton(By e) {
        
        visibleText(e);
        driver.findElement(e).click();
    }
    
    // @Author = Ankur
    // click an element
    public void clickElement(By e) {
        
        new WebDriverWait(driver, 50).until(ExpectedConditions.visibilityOfElementLocated(e));
        new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(e)).click();
    }
    
    // wait for visibility of an element for 50 seconds
    public void visibleText(By element) {
        WebDriverWait wait = new WebDriverWait(driver, 50);

        wait.ignoring(StaleElementReferenceException.class)
                .until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));
    }
    
    // @Author = Ankur
    // get web elements matching given locator
    public List<WebElement> getWebElements(By e) {
        
        new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfAllElements(driver.findElements(e)));
        return driver.findElements(e);
    }
    
    // @Author = Ankur
    // @Description = get web elements matching given xpath
    public List<WebElement> getWebElements(String xpath) {
        
        return wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(xpath)));
    }
    
    // @Author = Ankur
    // @Description = edit on group icon
    public void editGroup(String groupName) {
        
        By e = By.xpath("//div[text()='" + groupName + "']/parent::div//img[@alt='Edit icon']");
        wait.until(ExpectedConditions.visibilityOfElementLocated(e)).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Edit Group']")));
        waitForSecond(1);
    }
    
    // @Author = Ankur
    // @Description = wait for seconds
    public void waitForSecond(int time) {
        
        try {
            
            Thread.sleep(time * 1000);
            
        } catch (Exception e) {
            
            e.printStackTrace();
        }
    }

    
}
