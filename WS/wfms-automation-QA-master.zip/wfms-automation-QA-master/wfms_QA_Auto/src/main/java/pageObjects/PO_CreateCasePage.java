package pageObjects;


import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.github.javafaker.Faker;

import resources.ExcelData;

public class PO_CreateCasePage {
    
    public WebDriver driver;
    public WebDriverWait wait;
    //private ArrayList<String> al = new ArrayList<String>();
    public ExcelData excelData = new ExcelData();

    // constructor
    public PO_CreateCasePage(WebDriver driver) {

        this.driver = driver;
        wait = new WebDriverWait(driver, 10);
    }
    
    // sidebar
    private String sidebarByjusLogoImageXpath = "//div[@data-testid='navMenu']/img";
    private String sidebarCasesTextXpath = "//div[@data-testid='navMenu__item']//div[contains(text(),'Cases')]";
    private String sidebarGroupsTextXpath = "//div[@data-testid='navMenu__item']//div[contains(text(),'Groups')]";
    private String sidebarAgentsTextXpath = "//div[@data-testid='navMenu__item']//div[contains(text(),'Agents')]";
    private String sidebarMailboxTextXpath = "//div[@data-testid='navMenu__item']//div[contains(text(),'Mailbox')]";
    private String sidebarLogoutTextXpath = "//div[@data-testid='navMenu__item']//div[contains(text(),'Logout')]";
    
    // header
    private String headerCreateButtonXpath = "//button[text()='CREATE']";
    
    // form
    private String categoryFieldXpath = "//div[text()='Category']/parent::div/parent::div";
    private String createButtonXpath = "//button[text()='Create']";
    private String cancelButtonXpath = "//button[text()='Cancel']";
    
    // dynamic form fields - it will be initialized every time when category is changed
    private String issueCategoryFieldXpath;
    private String issueSubCategoryFieldXpath;
    private String permanentWorkstationNumberFieldXpath;
    private String locationFieldXpath;
    private String subjectFieldXpath;
    private String descriptionFieldXpath;
    private String customerEmailFieldXpath;
    private String customerNameFieldXpath;
    private String sourceFieldXpath;
    private String nameOfStudentFieldXpath;
    private String callbackMobileNumberFieldXpath;
    private String languagePreferenceFieldXpath;
    private String assignToGroupFieldXpath;
    private String subCategoryFieldXpath;
    private String issueTypeFieldXpath;
    private String issueSubtypeFieldXpath;
    private String issueSubcategoryFieldXpath;
    
    // form relative xpaths
    private String fieldToDropdownRelativeXpath = "//div[@class='dropdown__selectedLabel']";
    private String fieldToInputRelativeXpath = "//input";
    private String fieldToTextboxRelativeXpath = "//p";
    
    // popup
    private String successFulTestCreationMessageXpath = "//div[@class='modal-ui_message']";
    private String closeModalButtonXpath = "//button[contains(@class,'modal__close-btn')]";
    
    
    // ----------------------------------------------------------------------------------------------------
    // Sidebar
    // ----------------------------------------------------------------------------------------------------
    
    /*
     * public boolean isPresent(String xpath) {
     * try {
     * driver.findElement(By.xpath(xpath)).isDisplayed();
     * }
     * catch(Exception e){
     * e.printStackTrace();
     * return false;
     * }
     * return true;
     * }
     */
    
    public boolean checkElementExists(String xpath) {
        boolean result = false;
        try {
            driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
            driver.findElement(By.xpath(xpath));
        }
        catch(org.openqa.selenium.NoSuchElementException ex) {
            result = false;
        }
        finally {
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        return result;
    }
    
    // @Author = Ankur
    // @Description = is sidebar groups text present
    public Boolean isSidebarGroupsIconPresent() {

        return checkElementExists(sidebarGroupsTextXpath + "/parent::div//img");
        //return isPresent(sidebarGroupsTextXpath + "/parent::div//img");
    }
    
    // @Author = Gaurang
    // Click the cancel button on the create case page
    public void clickCancelButton() {
        visibleText(By.xpath(cancelButtonXpath));
        clickable(By.xpath(cancelButtonXpath));
        jsClick(driver.findElement(By.xpath(cancelButtonXpath)));
    }
    
    // @Author = Gaurang
    // Click the cancel button on the create case page
    public Boolean getCurrentUrl() {
        visibleText(By.xpath("//button[text()='Filters']"));
        if(driver.getCurrentUrl().split(".com")[1].equalsIgnoreCase("/createCase"))
            return true;
        else
            return false;
    }
    
    // @Author = Ankur
    // @Description = is sidebar groups text present
    public Boolean isSidebarGroupsTextPresent() {
        
        return checkElementExists(sidebarGroupsTextXpath);
    }
    
    // @Author = Ankur
    // @Description = is sidebar agents icon present
    public Boolean isSidebarAgentsIconPresent() {
        
        return checkElementExists(sidebarAgentsTextXpath + "/parent::div//img");
    }
    
    // @Author = Ankur
    // @Description = is sidebar agents text present
    public Boolean isSidebarAgentsTextPresent() {
        
        return checkElementExists(sidebarAgentsTextXpath);
    }
    
    // @Author = Ankur
    // @Description = is sidebar mailbox icon present
    public Boolean isSidebarMailboxIconPresent() {
        
        return checkElementExists(sidebarMailboxTextXpath + "/parent::div//img");
    }
    
    // @Author = Ankur
    // @Description = is sidebar mailbox text present
    public Boolean isSidebarMailboxTextPresent() {
        
        return checkElementExists(sidebarMailboxTextXpath);
    }
    
    // @Author = Ankur
    // @Description = Get sidebar byjus logo source
    public String getSidebarByjusLogoSource() {
        
        return getAttributeValue(By.xpath(sidebarByjusLogoImageXpath), "src").toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = Get sidebar cases icon source
    public String getSidebarCasesIconSource() {
        
        return getAttributeValue(By.xpath(sidebarCasesTextXpath + "/parent::div//img"), "src").toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = Get sidebar cases text
    public String getSidebarCasesText() {
        
        return getText(By.xpath(sidebarCasesTextXpath)).toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = Get sidebar groups icon source
    public String getSidebarGroupsIconSource() {
        
        return getAttributeValue(By.xpath(sidebarGroupsTextXpath + "/parent::div//img"), "src").toLowerCase();
    }

    // @Author = Ankur
    // @Description = Get sidebar groups text
    public String getSidebarGroupsText() {
        
        return getText(By.xpath(sidebarGroupsTextXpath)).toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = Get sidebar agents icon source
    public String getSidebarAgentsIconSource() {
        
        return getAttributeValue(By.xpath(sidebarAgentsTextXpath + "/parent::div//img"), "src").toLowerCase();
    }
    
    // @Author = Ankur
    // @Descriptionn = Get sidebar mailbox icon source
    public String getSidebarMailboxIconSource() {
        
        return getAttributeValue(By.xpath(sidebarMailboxTextXpath + "/parent::div//img"), "src").toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = Get sidebar mailbox text source
    public String getSidebarMailboxText() {
        
        return getText(By.xpath(sidebarMailboxTextXpath)).toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = Get sidebar logout icon source
    public String getSidebarLogoutIconSource() {
        
        return getAttributeValue(By.xpath(sidebarLogoutTextXpath + "/parent::div//img"), "src").toLowerCase();
    }
    
    //@Author = Ankur
    // Description = Get sidebar logout text
    public String getSidebarLogoutText() {
        
        return getText(By.xpath(sidebarLogoutTextXpath)).toLowerCase();
    }
    
    // @Author = Ankur
    // Description = Get sidebar agents text
    public String getSidebarAgentsText() {
        
        return getText(By.xpath(sidebarAgentsTextXpath)).toLowerCase();
    }
    
    // ----------------------------------------------------------------------------------------------------
    // Header
    // ----------------------------------------------------------------------------------------------------
    
    // @Author = Ankur
    // @Description = change role
    public void changeRole(String projectName) {
        
        // defect - https://byjustech.atlassian.net/browse/WFM-324
        // defect - https://byjustech.atlassian.net/browse/WFM-257
        driver.findElement(By.xpath("//div[@class='projectDropdown']")).click();
        
        try {
            wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='projectDropdown']//div[contains(@class,'dropdownOption')]")));
            driver.findElement(By.xpath("//div[@class='projectDropdown']//div[contains(@class,'dropdownOption') and text()='" + projectName + "']")).click();
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(headerCreateButtonXpath)));
        }
        catch(StaleElementReferenceException e) {
            wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='projectDropdown']//div[contains(@class,'dropdownOption')]")));
            driver.findElement(By.xpath("//div[@class='projectDropdown']//div[contains(@class,'dropdownOption') and text()='" + projectName + "']")).click();
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(headerCreateButtonXpath)));
        }
    }
    
    // @Author = Ankur
    // @Description = Go to create case page
    public void goToCreateCasePage() {
        
        clickButton(By.xpath(sidebarCasesTextXpath));
        clickButton(headerCreateButtonXpath);
    }
    
    // @Author = Ankur
    // @Description = Get header groups text
    public String getHeaderCasesText() {
        
        return getText("//div[@class='header__left-section']").toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = Get header create button text
    public String getHeaderCreateButtonText() {
        
        return getText(By.xpath(headerCreateButtonXpath)).toLowerCase();
    }
    
    // @Author = Ankur
    // @Description = Get header create button plus icon source
    public String getHeaderCreateButtonPlusIconSource() {
        
        return getAttributeValue(headerCreateButtonXpath + "//img", "src");
    }
    
    // ----------------------------------------------------------------------------------------------------
    // Form
    // ----------------------------------------------------------------------------------------------------
    
//    // @Author = Ankur
//    // verify form label texts
//    public String verifyFormLabelTexts() throws IOException, InterruptedException {
//        
//        String id = "category_dropdown_values";
//        al = excelData.getData(id, "CaseCreationFormPage", "Id");  
//        String[] categories = al.get(1).split(";");
//        
//        for(String category: categories) {
//            
//            setCategoryDropdownValue(category);
//            
//            id = "category_" + category.toLowerCase() + "_labels";
//            al = excelData.getData(id, "CaseCreationFormPage", "Id");
//            String[] labels = al.get(1).split(";");
//            
//            List<WebElement> labelWebElements = driver.findElements(By.xpath("//div[@data-testid='formLabel']//div[1]"));
//            
//            if(labels.length != labelWebElements.size()) {
//                
//                return "error in count of fields when category is " + category;
//            }
//            
//            for(int i = 0; i < labelWebElements.size(); ++i) {
//                
//                String label = labelWebElements.get(i).getText();
//                
//                if(label.equalsIgnoreCase(labels[i]) == false) {
//                 
//                    return "error when category is " + category + " label is " + label + " .label should be " + labels[i];
//                }   
//            }
//        }
//        
//        return "no errors";
//    }
    
    
//    // @Author = Ankur
//    // verify form dropdown values
//    public String verifyFormDropdownValues() throws IOException, InterruptedException {
//        
//        String Id = "category_dropdown_values";
//        String[] categories = excelData.getData(Id, "CaseCreationFormPage", "Id").get(1).split(";");
//        
//        for(String category: categories) {
//            
//            setCategoryDropdownValue(category);
//            
//            Id = "category_" + category.toLowerCase() + "_dropdowns";
//            String[] dropdowns = excelData.getData(Id, "CaseCreationFormPage", "Id").get(1).split(";");
//            
//            visibleText(By.xpath("//div[@class='dropdown__selectedLabel']"));
//            List<WebElement> dropdownElements = driver.findElements(By.xpath("//div[@class='dropdown__selectedLabel']"));
//            
//            if(dropdowns.length != dropdownElements.size()) {
//             
//                return "error in count of dropdowns when category is " + category.toLowerCase();
//            }
//            
//            for(int i = 1; i < dropdownElements.size(); ++i) {
//                
//                Id = "category_" + category.toLowerCase() + "_" + dropdowns[i].replaceAll(" ", "_").toLowerCase() + "_dropdown_values";
//                if(excelData.getData(Id, "CaseCreationFormPage", "Id").size() == 0) continue;
//                String[] dropdownOptions = excelData.getData(Id, "CaseCreationFormPage", "Id").get(1).split(";");
//                
//                dropdownElements.get(i).click();
//                
//                visibleText(By.xpath("//div[@class='dropdown__dropdownOption']"));
//                List<WebElement> dropdownOptionsWebElements = driver.findElements(By.xpath("//div[@class='dropdown__dropdownOption']"));
//                
//                if(dropdownOptions.length != dropdownOptionsWebElements.size())
//                    return "error in count of options in dropdown " + dropdowns[i] + " when category is " + category;
//                
//                for(int j = 0; j < dropdownOptionsWebElements.size(); ++j) {
//                    
//                    dropdownElements.get(i).click();
//                    
//                    if(dropdownOptionsWebElements.get(j).getText().equalsIgnoreCase(dropdownOptions[j]) == false) {
//                        
//                        return "error in text " + dropdownOptions[i] + " of dropdown " + dropdowns[i] + " when category is " + category;
//                    }
//                    
//                    dropdownOptionsWebElements.get(j).click();
//                    
//                    if(dropdownElements.get(i).getText().equalsIgnoreCase(dropdownOptions[j])) {
//                        
//                        return "error in setting value " + dropdownOptions[i] + " of dropdown " + dropdowns[i];
//                    }
//                }
//            }
//        }
//        
//        return "no errors";
//    }
    
    // ----------------------------------------------------------------------------------------------------
    // Methods written below this line will be used to get labels of form fields
    // ----------------------------------------------------------------------------------------------------
    
    public String getCustomerNameLabel() {
        
        return getText(customerNameFieldXpath + "//div[text()='Customer Name']");
    }
    
    public String getCustomerEmailLabel() {
        
        return getText(customerEmailFieldXpath + "//div[text()='Customer Email']");
    }
    
    public String getIssueSubcategoryLabel() {
        
        return getText(issueSubcategoryFieldXpath + "//div[text()='Issue Subcategory']");
    }
    
    public String getSourceLabel() {
        
        return getText(sourceFieldXpath + "//div[text()='Source']");
    }
    
    public String getNameOfStudentLabel() {
        
        return getText(nameOfStudentFieldXpath + "//div[text()='Name of Student']");
    }
    
    public String getIssueTypeLabel() {
        
        return getText(issueTypeFieldXpath + "//div[text()='Issue Type']");
    }
    
    public String getIssueSubTypeLabel() {
        
        return getText(issueSubtypeFieldXpath + "//div[text()='Issue Subtype']");
    }
    
    public String getCallbackMobileNumberLabel() {
        
        return getText(callbackMobileNumberFieldXpath + "//div[text()='Callback Mobile number']");
    }
    
    public String getLanguagePreferenceLabel() {
        
        return getText(languagePreferenceFieldXpath + "//div[text()='Language Preference']");
    }
    
    public String getAssignToGroupLabel() {
        
        return getText(assignToGroupFieldXpath + "//div[text()='Assign to Group']");
    }
    
    public String getSubjectLabel() {
        
        return getText(subjectFieldXpath + "//div[text()='Subject']");
    }
    
    public String getDescriptionLabel() {
        
        return getText(descriptionFieldXpath + "//div[text()='Description']");
    }
    
    // ----------------------------------------------------------------------------------------------------
    // Methods written below this line will be used to set values in a dropdown
    // ----------------------------------------------------------------------------------------------------
    
    // @Author = Ankur
    // select from category dropdown
    public void setCategoryDropdownValue(String data) throws InterruptedException {
        
        selectFromDropdown(By.xpath(categoryFieldXpath + fieldToDropdownRelativeXpath), data);
        
        String category = getCategoryDropdownValue();
        
        if(category.equalsIgnoreCase("IT")) {
            
            customerNameFieldXpath = "//div[text()='Customer Name']/parent::div/parent::div";
            customerEmailFieldXpath = "//div[text()='Customer Email']/parent::div/parent::div";
            issueSubcategoryFieldXpath = "//div[text()='Issue Subcategory']/parent::div/parent::div";
            sourceFieldXpath = "//div[text()='Source']/parent::div/parent::div";
            nameOfStudentFieldXpath = "//div[text()='Name of Student']/parent::div/parent::div";
            issueTypeFieldXpath = "//div[text()='Issue Type']/parent::div/parent::div";
            issueSubtypeFieldXpath = "//div[text()='Issue Subtype']/parent::div/parent::div";
            callbackMobileNumberFieldXpath = "//div[text()='Callback Mobile number']/parent::div/parent::div";
            languagePreferenceFieldXpath = "//div[text()='Language Preference']/parent::div/parent::div";
            assignToGroupFieldXpath = "//div[text()='Assign to Group']/parent::div/parent::div";
            subjectFieldXpath = "//div[text()='Subject']/parent::div/parent::div";
            descriptionFieldXpath = "//div[text()='Description']/parent::div/parent::div";
        }
    }
    
    // @Author = Ankur
    // select from issue category dropdown
    public void setIssueCategoryDropdownValue(String data) throws InterruptedException {
        
        selectFromDropdown(By.xpath(issueCategoryFieldXpath + fieldToDropdownRelativeXpath), data);
    }
    
    // @Author = Ankur
    // select from issue sub category dropdown
    public void setIssueSubCategoryDropdownValue(String data) throws InterruptedException {
        
        selectFromDropdown(By.xpath(issueSubCategoryFieldXpath + fieldToDropdownRelativeXpath), data);
    }
    
    // @Author = Ankur
    // select from location dropdown
    public void setLocationDropdownValue(String data) throws InterruptedException {
        
        selectFromDropdown(By.xpath(locationFieldXpath + fieldToDropdownRelativeXpath), data);
    }
    
    // @Author = Ankur
    // select from source dropdown
    public void setSourceDropdownValue(String data) throws InterruptedException {
        
        selectFromDropdown(By.xpath(sourceFieldXpath + fieldToDropdownRelativeXpath), data);
    }
    
    // @Author = Ankur
    // select from source dropdown
    public void setLanguagePreferenceDropdownValue(String data) throws InterruptedException {
        
        selectFromDropdown(By.xpath(languagePreferenceFieldXpath + fieldToDropdownRelativeXpath), data);
    }
    
    // @Author = Ankur
    // select from assign to group dropdown
    public void setAssignToGroupDropdownValue(String data) throws InterruptedException {
        
        selectFromDropdown(By.xpath(assignToGroupFieldXpath + fieldToDropdownRelativeXpath), data);
    }
    
    // @Author = Ankur
    // select from sub category dropdown
    public void setSubCategoryDropdownValue(String data) throws InterruptedException {
        
        selectFromDropdown(By.xpath(subCategoryFieldXpath + fieldToDropdownRelativeXpath), data);
    }
    
    // @Author = Ankur
    // select from issue type dropdown
    public void setIssueTypeDropdownValue(String data) throws InterruptedException {
        
        selectFromDropdown(By.xpath(issueTypeFieldXpath + fieldToDropdownRelativeXpath), data);
    }
    
    // @Author = Ankur
    // select from issue subtype dropdown
    public void setIssueSubtypeDropdownValue(String data) throws InterruptedException {
        
        selectFromDropdown(By.xpath(issueSubtypeFieldXpath + fieldToDropdownRelativeXpath), data);
    }
    
    // ----------------------------------------------------------------------------------------------------
    // Methods written below this line will be used to get values that are set in a dropdown
    // ----------------------------------------------------------------------------------------------------
    
    // @Author = Ankur
    // get from sub category dropdown
    public String getSubCategoryDropdownValue() throws InterruptedException {
        
        return getText(By.xpath(subCategoryFieldXpath + fieldToDropdownRelativeXpath));
    }
    
    // @Author = Ankur
    // get from issue type dropdown
    public String getIssueTypeDropdownValue() throws InterruptedException {
        
        return getText(By.xpath(issueTypeFieldXpath + fieldToDropdownRelativeXpath));
    }
    
    // @Author = Ankur
    // get from issue subtype dropdown
    public String getIssueSubtypeDropdownValue() throws InterruptedException {
        
        return getText(By.xpath(issueSubtypeFieldXpath + fieldToDropdownRelativeXpath));
    }
    
    // @Author = Ankur
    // get category dropdown value
    public String getCategoryDropdownValue() {
    
         return getText(By.xpath(categoryFieldXpath + fieldToDropdownRelativeXpath));   
    }
    
    // @Author = Ankur
    // get issue category dropdown value
    public String getIssueCategoryDropdownValue() throws InterruptedException {
        
        return getText(By.xpath(issueCategoryFieldXpath + fieldToDropdownRelativeXpath));
    }
    
    // @Author = Ankur
    // get issue sub category dropdown value
    public String getIssueSubCategoryDropdownValue() throws InterruptedException {
        
        return getText(By.xpath(issueSubCategoryFieldXpath + fieldToDropdownRelativeXpath));
    }
    
    // @Author = Ankur
    // get location dropdown value
    public String getLocationDropdownValue() throws InterruptedException {
        
        return getText(By.xpath(locationFieldXpath + fieldToDropdownRelativeXpath));
    }
    
    // @Author = Ankur
    // get source dropdown value
    public String getLanguagePreferenceDropdownValue() throws InterruptedException {
        
        return getText(By.xpath(languagePreferenceFieldXpath + fieldToDropdownRelativeXpath));
    }
    
    // @Author = Ankur
    // get assign to group dropdown value
    public String getAssignToGroupDropdownValue() throws InterruptedException {
        
        return getText(By.xpath(assignToGroupFieldXpath + fieldToDropdownRelativeXpath));
    }
    
    // @Author = Ankur
    // get source dropdown value
    public String getSourceDropdownValue() throws InterruptedException {
        
        return getText(By.xpath(sourceFieldXpath + fieldToDropdownRelativeXpath));
    }
    
    // ----------------------------------------------------------------------------------------------------
    // Methods written below this line will be used to set values in a input field
    // ----------------------------------------------------------------------------------------------------
    
    public void setCustomerName(String data) {
        
        setInputFieldValue(By.xpath(customerNameFieldXpath + fieldToInputRelativeXpath), data);
    }
    
    public void setCustomerEmail(String data) {
        
        setInputFieldValue(By.xpath(customerEmailFieldXpath + fieldToInputRelativeXpath), data);
    }
    
    public void setPermanentWorkstationNumber(String data) {
        
        setInputFieldValue(By.xpath(permanentWorkstationNumberFieldXpath + fieldToInputRelativeXpath), data);
    }
    
    public void setSubject(String data) {
        
        setInputFieldValue(By.xpath(subjectFieldXpath + fieldToInputRelativeXpath), data);
    }
    
    public void setNameOfStudent(String data) {
        
        setInputFieldValue(By.xpath(nameOfStudentFieldXpath + fieldToInputRelativeXpath), data);
    }
    
    public void setCallbackMobileNumber(String data) {
        
        setInputFieldValue(By.xpath(callbackMobileNumberFieldXpath + fieldToInputRelativeXpath), data);
    }
    
    public void setIssueSubcategory(String data) {
        
        setInputFieldValue(By.xpath(issueSubcategoryFieldXpath + fieldToInputRelativeXpath), data);
    }
    
    // ----------------------------------------------------------------------------------------------------
    // Methods written below this line will be used to get values in a input field
    // ----------------------------------------------------------------------------------------------------
    
    public String getCustomerName() {
        
        return getInputFieldValue(By.xpath(customerNameFieldXpath + fieldToInputRelativeXpath));
    }
    
    public String getCustomerEmail() {
        
        return getInputFieldValue(By.xpath(customerEmailFieldXpath + fieldToInputRelativeXpath));
    }
    
    public String getPermanentWorkstationNumber() {
        
        return getInputFieldValue(By.xpath(permanentWorkstationNumberFieldXpath + fieldToInputRelativeXpath));
    }
    
    public String getSubject() {
        
        return getInputFieldValue(By.xpath(subjectFieldXpath + fieldToInputRelativeXpath));
    }
    
    public String getNameOfStudent() {
        
        return getInputFieldValue(By.xpath(nameOfStudentFieldXpath + fieldToInputRelativeXpath));
    }
    
    public String getCallbackMobileNumber() {
        
        return getInputFieldValue(By.xpath(callbackMobileNumberFieldXpath + fieldToInputRelativeXpath));
    }
    
    // ----------------------------------------------------------------------------------------------------
    // Methods written below this line will be used to set values in a textbox
    // ----------------------------------------------------------------------------------------------------
    
    public void setDescription(String data) {
        
        setTextboxFieldValue(By.xpath(descriptionFieldXpath + fieldToTextboxRelativeXpath), data);
    }
    
    // ----------------------------------------------------------------------------------------------------
    // Methods written below this line will be used to get values in a textbox
    // ----------------------------------------------------------------------------------------------------
    
    public String getDescription() {
        
        return getTextboxFieldValue(By.xpath(descriptionFieldXpath + fieldToTextboxRelativeXpath));
    }
    
    // ----------------------------------------------------------------------------------------------------
    // Methods for filling form
    // ----------------------------------------------------------------------------------------------------
    
    // @Author = Ankur
    // fill all form fields with random data
    public HashMap<String, String> createNewCase() throws InterruptedException {
        
        HashMap<String, String> data = new HashMap<>();
        
        setCategoryDropdownValue("IT");
        String category = getCategoryDropdownValue();
        data.put("category", category);
        
        Faker faker = new Faker();
        String firstName = faker.name().firstName().replaceAll("'","");
        String lastName = faker.name().lastName().replaceAll("'","");
        String emailId = firstName.toLowerCase() + "." + lastName.toLowerCase() + new Random().nextInt(1000000000) + "@byjus.com";
        String phoneNumber = "9" + Integer.toString(100000000 + new Random().nextInt(100000000));
        
        if(category.equalsIgnoreCase("IT")) {
            
            setCustomerName(firstName + " " + lastName);
            data.put("customerName", firstName + " " + lastName);
            
            setCustomerEmail(emailId);
            data.put("customerEmail", emailId);
            
            setIssueSubcategory("Test");
            data.put("issueSubCategory", "Test");
            
            setSourceDropdownValue("select random option");
            data.put("source", getSourceDropdownValue());
            
            setNameOfStudent("Test");
            data.put("nameOfStudent", "Test");
            
            setIssueTypeDropdownValue("select random option");
            data.put("issueType", getIssueTypeDropdownValue());
            
            setIssueSubtypeDropdownValue("select random option");
            data.put("issueSubType", getIssueSubtypeDropdownValue());
            
            setCallbackMobileNumber(phoneNumber);
            data.put("callbackMobileNumber", phoneNumber);
            
            setSubject("Testing");
            data.put("subject", getSubject());
            
            setDescription("This case is created for testing puropose by automation team");
            data.put("description", getDescription());
            
            setLanguagePreferenceDropdownValue("select random option");
            data.put("languagePreference", getLanguagePreferenceDropdownValue());
            
            setAssignToGroupDropdownValue("select random option");
            data.put("assignToGroup", getAssignToGroupDropdownValue());
        }
        
        clickButton(By.xpath(createButtonXpath));
        
        visibleText(By.xpath(successFulTestCreationMessageXpath));
        
        String ticketId = driver.findElement(By.xpath(successFulTestCreationMessageXpath)).getText().split(" ")[3];
        data.put("ticketId", ticketId);
        
        clickButton(By.xpath(closeModalButtonXpath));
        
        return data;
    }
    
    
    // @Author = Ankur
    // check whether create button is getting enabled if mandatory fields is empty
    public String verifyMandatoryFields() throws InterruptedException {
        
        Faker faker = new Faker();
        String firstName = faker.name().firstName().replaceAll("'","");
        String lastName = faker.name().lastName().replaceAll("'","");
        String emailId = firstName.toLowerCase() + "." + lastName.toLowerCase() + new Random().nextInt(1000000000) + "@byjus.com";
        String phoneNumber = "9" + Integer.toString(100000000 + new Random().nextInt(100000000));
        
        String[] category = {"IT", "Sales"};
        
        for(int i = 0; i < category.length; ++i) {
         
            setCategoryDropdownValue(category[i]);
    
            if(category[i].equalsIgnoreCase("IT")) {
                
                if(driver.findElement(By.xpath(createButtonXpath)).isEnabled())
                    return "create case button is enabled when category is IT and no fields are filled";
                
                // fill all the fields in form
                
                setCustomerName(firstName + " " + lastName);
                setCustomerEmail(emailId);
                setPermanentWorkstationNumber("1234");
                setSubject("Testing");
                setDescription("This case is created for testing puropose by automation team");
                
                if(!driver.findElement(By.xpath(createButtonXpath)).isEnabled())
                    return "create case button is disabled when category is IT and all fields are filled";
                
                // one by one make mandatory fields empty and check if create case button is getting enabled.
                
                setCustomerName("");
                if(!driver.findElement(By.xpath(createButtonXpath)).isEnabled())
                    return "create case button is enabled when category is IT and customer name is empty";
                
                setCustomerName(firstName + " " + lastName);
                setCustomerEmail("");
                if(!driver.findElement(By.xpath(createButtonXpath)).isEnabled())
                    return "create case button is enabled when category is IT and customer email is empty";
                
                setCustomerEmail(emailId);
                setPermanentWorkstationNumber("");
                if(!driver.findElement(By.xpath(createButtonXpath)).isEnabled())
                    return "create case button is enabled when category is IT and permanent workstation number is empty";
                
                setPermanentWorkstationNumber("1234");
                setSubject("");
                if(!driver.findElement(By.xpath(createButtonXpath)).isEnabled())
                    return "create case button is enabled when category is IT and subject is empty";
                
                setSubject("Testing");
                setDescription("");
                if(!driver.findElement(By.xpath(createButtonXpath)).isEnabled())
                    return "create case button is enabled when category is IT and description is empty";
                
                setDescription("This case is created for testing puropose");
            }
            else if(category[i].equalsIgnoreCase("Sales")) {
                
                if(driver.findElement(By.xpath(createButtonXpath)).isEnabled())
                    return "create case button is enabled when category is IT and no fields are filled";
                
                // fill all the fields in form
                
                setCustomerName(firstName + " " + lastName);
                setCustomerEmail(emailId);
                setNameOfStudent(firstName + " " + lastName);
                setCallbackMobileNumber(phoneNumber);
                setSubject("Testing");
                setDescription("This case is created for testing purpose");
                
                if(!driver.findElement(By.xpath(createButtonXpath)).isEnabled())
                    return "create case button is disabled when category is Sales and all fields are filled";
                
                // one by one make mandatory fields empty and check if create case button is getting enabled.
                
                setCustomerName("");
                if(!driver.findElement(By.xpath(createButtonXpath)).isEnabled())
                    return "create case button is enabled when category is Sales and customer name is empty";
                
                setCustomerName(firstName + " " + lastName);
                setCustomerEmail("");
                if(!driver.findElement(By.xpath(createButtonXpath)).isEnabled())
                    return "create case button is enabled when category is Sales and customer email is empty";
                
                setCustomerEmail(emailId);
                setNameOfStudent("");
                if(!driver.findElement(By.xpath(createButtonXpath)).isEnabled())
                    return "create case button is enabled when category is Sales and name of student is empty";
                
                setNameOfStudent(firstName + " " + lastName); 
                setCallbackMobileNumber("");
                if(!driver.findElement(By.xpath(createButtonXpath)).isEnabled())
                    return "create case button is enabled when category is Sales and callback mobile number is empty";
                
                setCallbackMobileNumber(phoneNumber);
                setSubject("");
                if(!driver.findElement(By.xpath(createButtonXpath)).isEnabled())
                    return "create case button is enabled when category is Sales and subject is empty";
                
                setSubject("Testing");
                setDescription("");
                if(!driver.findElement(By.xpath(createButtonXpath)).isEnabled())
                    return "create case button is enabled when category is Sales and description is empty";
                
                setDescription("This case is created for testing puropose");
            }
        }
        
        return "no errors";
    }
    
    // ----------------------------------------------------------------------------------------------------
    // Miscellaneous methods
    // ----------------------------------------------------------------------------------------------------
    
    // @Author = Ankur
    // get text of element using its by locator
    public String getText(By e) {
        
        visibleText(e);
        return driver.findElement(e).getText();
    }
    
    // @Author = Ankur
    // @Description = get text of element using its by locator
    public String getText(String xpath) {
        
        By e = By.xpath(xpath);
        visibleText(e);
        return driver.findElement(e).getText();
    }
    
    // @Author = Ankur
    // get tag name of element using its by locator
    public String getTagName(By e) {
        
        visibleText(e);
        return driver.findElement(e).getTagName();
    }
    
    // @Author = Ankur
    // select from a dropdown using by locator of dropdown and it takes a string data which we want to set 
    public void selectFromDropdown(By e, String data) throws InterruptedException {
        
        visibleText(e);
        
        driver.findElement(e).click();
        
        visibleText(By.xpath("//div[@class='dropdown__dropdownSheet']/div"));
        
        List<WebElement> elements = driver.findElements(By.xpath("//div[@class='dropdown__dropdownSheet']/div"));
        
        if(data.equalsIgnoreCase("select random option")) {
            
            elements.get(new Random().nextInt(elements.size())).click();
        }
        else {
            
            for(WebElement element: elements) {
                
                if(element.getText().equalsIgnoreCase(data)) {
                    
                    element.click();
                    break;
                }
            }  
        }
    }
    
    // @Author = Ankur
    // set textbox field value
    public void setTextboxFieldValue(By e, String data) {
        
        visibleText(e);
        driver.findElement(e).sendKeys(data);
    }
    
    // @Author = Ankur
    // get textbox field value
    public String getTextboxFieldValue(By e) {
        
        visibleText(e);
        return driver.findElement(e).getText();
    }
    
    //@Author = Ankur
    // set input field value using by locator of input field
    public void setInputFieldValue(By e, String data) {
     
        visibleText(e);
        driver.findElement(e).clear();
        driver.findElement(e).sendKeys(data);
    }
    
    // @Author = Ankur
    // get input field value using by locator of input field
    public String getInputFieldValue(By e) {
        
        visibleText(e);
        return driver.findElement(e).getAttribute("value");
    }
    
    // @Author = Ankur
    // click a button
    public void clickButton(By e) {
        clickable(e);
        visibleText(e);
        driver.findElement(e).click();
    }
    
    // @Author = Ankur
    // @Description = click a button
    public void clickButton(String xpath) {
        clickable(By.xpath(xpath));
        visibleText(By.xpath(xpath));
        driver.findElement(By.xpath(xpath)).click();
    }
    
    // wait for visibility of an element for 50 seconds
    public boolean visibleText(By element) {
        WebDriverWait wait = new WebDriverWait(driver, 10);

        wait.ignoring(StaleElementReferenceException.class)
                .until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));

        return false;
    }
    
    // @Author = Ankur
    // print array of strings
    public void printArrayOfStrings(String[] arr) {
        
        for(String s: arr) {
            
            System.out.println(s);
        }
    }
    
    // @Author = Ankur
    // @Description = get attribute value of an element
    public String getAttributeValue(By e, String attribute) {
        
        return new WebDriverWait(driver, 50).until(ExpectedConditions.visibilityOfElementLocated(e)).getAttribute(attribute);
    }
    
    // @Author = Ankur
    // @Description = get attribute value of an element
    public String getAttributeValue(String xpath, String attribute) {
        
        By e = By.xpath(xpath);
        return new WebDriverWait(driver, 50).until(ExpectedConditions.visibilityOfElementLocated(e)).getAttribute(attribute);
    }
    
    public boolean clickable(By element)
    {
        WebDriverWait wait= new WebDriverWait(driver, 10);
        
        wait.ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(element));
        
        return false;
    }
    
    // @Author = Ankur
    // @Description = get create button text
    public String getCreateButtonText() {
        
        return driver.findElement(By.xpath("//button[text()='Create']")).getText();
    }
    
    // @Author = Ankur
    // @Description = get cancel button text
    public String getCancelButtonText() {
        
        return driver.findElement(By.xpath("//button[text()='Cancel']")).getText();
    }
    
    public void jsClick(WebElement el) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].click();", el);
        } catch (Exception e) {
            System.out.println("=============================================================");
            System.out.println("Exception-jsClick(): " + e.getMessage());
            //takeScreenShot();
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }
}
