package POJOClasses;

public class POJO_Nested_TicketCreation_POST_Details {
    
    private String subCategory;
    private String issueType;
    private String issueSubType;
    private String subject;
    private String description;
    private String[] attachments;
    private String customerName;
    private String customerEmail;
    public String getSubCategory() {
        return subCategory;
    }
    public void setSubCategory(String subCategory) {
        this.subCategory = subCategory;
    }
    public String getIssueType() {
        return issueType;
    }
    public void setIssueType(String issueType) {
        this.issueType = issueType;
    }
    public String getIssueSubType() {
        return issueSubType;
    }
    public void setIssueSubType(String issueSubType) {
        this.issueSubType = issueSubType;
    }
    public String getSubject() {
        return subject;
    }
    public void setSubject(String subject) {
        this.subject = subject;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String[] getAttachments() {
        return attachments;
    }
    public void setAttachments(String[] attachments) {
        this.attachments = attachments;
    }
    public String getCustomerName() {
        return customerName;
    }
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
    public String getCustomerEmail() {
        return customerEmail;
    }
    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }
    
}
