package POJOClasses;

public class POJO_ProjectRole_POST {
    private int projectId;
    private String genericName;
    private String specificName;
    public int getProjectId() {
        return projectId;
    }
    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }
    public String getGenericName() {
        return genericName;
    }
    public void setGenericName(String genericName) {
        this.genericName = genericName;
    }
    public String getSpecificName() {
        return specificName;
    }
    public void setSpecificName(String specificName) {
        this.specificName = specificName;
    }
    public POJO_ProjectRole_POST(int projectId, String genericName, String specificName) {
        super();
        this.projectId = projectId;
        this.genericName = genericName;
        this.specificName = specificName;
    }
    public POJO_ProjectRole_POST() {
        super();
    }
}
