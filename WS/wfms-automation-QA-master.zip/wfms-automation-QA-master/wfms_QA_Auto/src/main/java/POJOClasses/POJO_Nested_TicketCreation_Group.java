package POJOClasses;

public class POJO_Nested_TicketCreation_Group {
    private Integer groupId;
    private String groupName;
    private String ownerEmail;
    private String groupEmail;
    private Integer projectId;
    public Integer getGroupId() {
        return groupId;
    }
    public void setGroupId(Integer groupId) {
        this.groupId = groupId;
    }
    public String getGroupName() {
        return groupName;
    }
    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }
    public String getOwnerEmail() {
        return ownerEmail;
    }
    public void setOwnerEmail(String ownerEmail) {
        this.ownerEmail = ownerEmail;
    }
    public String getGroupEmail() {
        return groupEmail;
    }
    public void setGroupEmail(String groupEmail) {
        this.groupEmail = groupEmail;
    }
    public Integer getProjectId() {
        return projectId;
    }
    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }
    public POJO_Nested_TicketCreation_Group(Integer groupId, String groupName, String ownerEmail, String groupEmail,
            Integer projectId) {
        super();
        this.groupId = groupId;
        this.groupName = groupName;
        this.ownerEmail = ownerEmail;
        this.groupEmail = groupEmail;
        this.projectId = projectId;
    }
}
