package POJOClasses;

public class Response_ProjectConfiguration_POJO extends Post_ProjectConfiguration_POJO {
    @Override
    public String toString() {
        
        return super.toString() + "\nResponse_ProjectConfiguration_POJO [versionNumber=" + versionNumber + ", inUse=" + inUse + "]";
    }
    private int versionNumber;
    private Boolean inUse;
    public int getVersionNumber() {
        return versionNumber;
    }
    public void setVersionNumber(int versionNumber) {
        this.versionNumber = versionNumber;
    }
    public Boolean getInUse() {
        return inUse;
    }
    public void setInUse(Boolean inUse) {
        this.inUse = inUse;
    }
}
