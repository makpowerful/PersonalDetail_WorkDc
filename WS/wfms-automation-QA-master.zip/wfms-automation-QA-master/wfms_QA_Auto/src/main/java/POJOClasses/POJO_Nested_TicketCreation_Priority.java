package POJOClasses;

public class POJO_Nested_TicketCreation_Priority {
    private String key;
    private String value;
    private Integer priority;
    public String getKey() {
        return key;
    }
    public void setKey(String key) {
        this.key = key;
    }
    public String getValue() {
        return value;
    }
    public void setValue(String value) {
        this.value = value;
    }
    public Integer getPriority() {
        return priority;
    }
    public void setPriority(Integer priority) {
        this.priority = priority;
    }
    public POJO_Nested_TicketCreation_Priority(String key, String value, Integer priority) {
        super();
        this.key = key;
        this.value = value;
        this.priority = priority;
    }
}
