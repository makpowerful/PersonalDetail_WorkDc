package POJOClasses;

public class POJO_TicketCreation_PUT {
    private POJO_Nested_TicketCreation_Priority status;
    private POJO_Nested_TicketCreation_Priority priority;
    private String dueDate;
    private POJO_Nested_TicketCreation_Group group;
    private POJO_Nested_TicketCreation_Agent agent;
    public POJO_Nested_TicketCreation_Priority getStatus() {
        return status;
    }
    public void setStatus(POJO_Nested_TicketCreation_Priority status) {
        this.status = status;
    }
    public POJO_Nested_TicketCreation_Priority getPriority() {
        return priority;
    }
    public void setPriority(POJO_Nested_TicketCreation_Priority priority) {
        this.priority = priority;
    }
    public String getDueDate() {
        return dueDate;
    }
    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }
    public POJO_Nested_TicketCreation_Group getGroup() {
        return group;
    }
    public void setGroup(POJO_Nested_TicketCreation_Group group) {
        this.group = group;
    }
    public POJO_Nested_TicketCreation_Agent getAgent() {
        return agent;
    }
    public void setAgent(POJO_Nested_TicketCreation_Agent agent) {
        this.agent = agent;
    }
}
