package POJOClasses;

public class Post_ProjectConfiguration_POJO {
    private int projectId;
    private String projectName;
    private String configuration;
    private String resourceType;
    public int getProjectId() {
        return projectId;
    }
    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }
    public String getProjectName() {
        return projectName;
    }
    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }
    public String getConfiguration() {
        return configuration;
    }
    public void setConfiguration(String configuration) {
        this.configuration = configuration;
    }
    public String getResourceType() {
        return resourceType;
    }
    public void setResourceType(String resourceType) {
        this.resourceType = resourceType;
    }
    @Override
    public String toString() {
        return "Post_ProjectConfiguration_POJO [projectId=" + projectId + ", projectName=" + projectName
                + ", configuration=" + configuration + ", resourceType=" + resourceType + "]";
    }
    
}
