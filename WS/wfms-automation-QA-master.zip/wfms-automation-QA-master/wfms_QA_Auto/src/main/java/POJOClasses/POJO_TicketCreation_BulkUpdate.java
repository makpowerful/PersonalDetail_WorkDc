package POJOClasses;

import java.util.ArrayList;

public class POJO_TicketCreation_BulkUpdate extends POJO_TicketCreation_PUT{
    private ArrayList<Integer> ticketIds;
    public ArrayList<Integer> getTicketIds() {
        return ticketIds;
    }
    public void setTicketIds(ArrayList<Integer> ticketIds) {
        this.ticketIds = ticketIds;
    }
}
