package POJOClasses;

public class POJO_TicketCreation_POST {
    
    private String channel;
    private String projectId;
    private String category;
    POJO_Nested_TicketCreation_Requester requester;
    private POJO_Nested_TicketCreation_POST_Details details;
    public POJO_Nested_TicketCreation_Requester getRequester() {
        return requester;
    }
    public void setRequester(POJO_Nested_TicketCreation_Requester requester) {
        this.requester = requester;
    }
    public String getChannel() {
        return channel;
    }
    public void setChannel(String channel) {
        this.channel = channel;
    }
    public String getProjectId() {
        return projectId;
    }
    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }
    public String getCategory() {
        return category;
    }
    public void setCategory(String category) {
        this.category = category;
    }
    public POJO_Nested_TicketCreation_POST_Details getDetails() {
        return details;
    }
    public void setDetails(POJO_Nested_TicketCreation_POST_Details details) {
        this.details = details;
    }
}
