package POJOClasses;

import java.time.LocalDateTime;

import com.google.common.base.CharMatcher;

public class Response_ProjectDetails {
    private int projectId;
    private String name;
    private String description;
    private Boolean inUse;
    private LocalDateTime createdAt;
    private String createdBy;
    private LocalDateTime updatedAt;
    private String updatedBy;
    public int getProjectId() {
        return projectId;
    }
    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public Boolean getInUse() {
        return inUse;
    }
    public void setInUse(Boolean inUse) {
        this.inUse = inUse;
    }
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    public void setCreatedAt(String createdAt) {
        this.createdAt = LocalDateTime.parse(CharMatcher.anyOf("Z").removeFrom(createdAt));
    }
    public String getCreatedBy() {
        return createdBy;
    }
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    public void setUpdatedAt(String updatedAt) {
        
        this.updatedAt = LocalDateTime.parse(CharMatcher.anyOf("Z").removeFrom(updatedAt));
    }
    public String getUpdatedBy() {
        return updatedBy;
    }
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }
    @Override
    public String toString() {
        return "Response_ProjectDetails [projectId=" + projectId + ", name=" + name + ", description=" + description
                + ", inUse=" + inUse + ", createdAt=" + createdAt + ", createdBy=" + createdBy + ", updatedAt="
                + updatedAt + ", updatedBy=" + updatedBy + "]";
    }
    
}
