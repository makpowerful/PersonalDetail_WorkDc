package payLoad;

import static io.restassured.RestAssured.given;

import java.io.IOException;

import POJOClasses.POJO_ProjectRole_POST;
import io.restassured.response.Response;

public class Payload_ProjectRoleController extends AbstractComponents {
    public static String baseURI = env + "wfms-configuration-management";

    public static POJO_ProjectRole_POST bodyContentForPost(String rowName, String sheetName) throws IOException {
        al = excelData.getData(rowName, sheetName, "Tcid");
        POJO_ProjectRole_POST bodyContent = new POJO_ProjectRole_POST();
        bodyContent.setProjectId(Integer.parseInt(al.get(1)));
        bodyContent.setGenericName((al.get(2).compareTo("N/A") == 0) ? ("") : (al.get(2)));
        bodyContent.setSpecificName((al.get(3).compareTo("N/A") == 0) ? ("") : (al.get(3)));

        return bodyContent;
    }
    
    private static String bodyContentForPut(String rowName, String sheetName) throws IOException {
        al = excelData.getData(rowName, sheetName, "Tcid");
        String specificName = (al.get(3).compareTo("N/A") == 0) ? ("") : (al.get(3));
        System.out.println(specificName);
        return "{\n"
                + "  \"specificName\": \"" + specificName + "\"\n"
                + "}";
    }

    public static Response postProjectRoleController(String rowName, String sheetName) throws IOException {
        Response response = given().body(bodyContentForPost(rowName, sheetName)).headers(mp).log().uri()
                .when().post(baseURI + "/wfms/configurationManagement/v1/roles")
                .thenReturn();
        response.then().log().status();
        response.then().log().body();
        return response;
    }
    
    public static Response putProjectRoleController(String rowName, String sheetName, int projectId, String genericName) throws IOException {
        Response response = given().headers(mp).queryParam("projectId", projectId).queryParam("genericName", genericName)
                .body(bodyContentForPut(rowName, sheetName)).log().uri()
                .when().put(baseURI + "/wfms/configurationManagement/v1/roles")
                .thenReturn();
        response.then().log().status();
        response.then().log().body();
        return response;
    }

    public static Response getProjectRoleController(int projectId, String genericName) {
        Response response = given().queryParam("projectId", projectId).queryParam("genericName", genericName).headers(mp).log().uri()
                .when().get(baseURI + "/wfms/configurationManagement/v1/roles")
                .thenReturn();
        response.then().log().status();
        response.then().log().body();
        return response;
    }

    public static Response deleteProjectRoleController(int projectId, String genericName) {
        Response response = given().queryParam("projectId", projectId).queryParam("genericName", genericName).headers(mp).log().uri()
                .when().delete(baseURI + "/wfms/configurationManagement/v1/roles")
                .thenReturn();
        response.then().log().status();
        response.then().log().body();
        return response;
    }
}
