package payLoad;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import io.restassured.response.Response;

import io.restassured.path.json.JsonPath;
import resources.ExcelData;
import resources.base;

public class PayLoad_MailBox extends base{
    
    public static String sessionToken;
    public static String role;
    static Map<String,Object> mp;
    static ExcelData excelData = new ExcelData();
    public static ArrayList<String> al = new ArrayList<String>();
    public static String baseURI = env;
    public static int MailBoxId;
    public static String name = "";
    public static String emailId = "";
    public static String password = "";
    public static int groupId;
    public static String groupName = "";
    public static int projectId;
    public static String update_name = "";
    public static String serviceToken = "f684b46d8df7f5008fb2d35bdd1f93a2a7f57cd17a7b038e1383f5c176774c67";
    
    
    
    private static String getPayloadCreate(String rowName) throws Exception {
        al = excelData.getData(rowName, "MailBox_API", "Tcid");
        
        groupId = Integer.valueOf(al.get(4));
        name = al.get(1);
        emailId =al.get(2);
        password = al.get(3);
        groupName = al.get(5);
        
        String payLoad = "{\n"
                + "    \"name\": \""+name+"\",\n"
                + "    \"email\":\""+emailId+"\",\n"
                + "    \"password\": \""+password+"\",\n"
                + "    \"groupId\": "+groupId+",\n"
                + "    \"groupName\":\""+groupName+"\",\n"
                + "    \"projectId\": "+projectId+"\n"
                + "}";
        return payLoad;
    }
    
    
    private static String getPayload(String rowName) throws IOException {
        al = excelData.getData(rowName, "MailBox_API", "Tcid");
        
        int local_groupId = Integer.valueOf(al.get(4));
        String local_name = al.get(1);
        
        if(rowName == "Create_EmptyName")local_name = "";
        
        String payLoad = "{\n"
                + "    \"name\": \""+local_name+"\",\n"
                + "    \"email\":\""+al.get(2)+"\",\n"
                + "    \"password\": \""+al.get(3)+"\",\n"
                + "    \"groupId\": "+local_groupId+",\n"
                + "    \"groupName\":\""+al.get(5)+"\",\n"
                + "    \"projectId\": "+projectId+"\n"
                + "}";
        return payLoad;
    }
    
    private static String getPayloadPUT() throws IOException {
        update_name = "u"+groupName;
        
        String payLoad = "{\n"
                + "    \"name\": \""+update_name+"\",\n"
                + "    \"email\":\""+emailId+"\",\n"
                + "    \"password\": \""+password+"\",\n"
                + "    \"groupId\": "+groupId+",\n"
                + "    \"groupName\":\""+groupName+"\",\n"
                + "    \"projectId\": "+projectId+"\n"
                + "}";
        
        return payLoad;
    }
    
    
    private static String getPayload_Status(boolean activate) throws IOException {
        String payLoad="";
        if(activate) {
            payLoad = "{\n"
                    + "  \"enabled\": true\n"
                    + "}";
        }else {
            payLoad = "{\n"
                    + "  \"enabled\": false\n"
                    + "}";
        }
        return payLoad;
    }

    
    public static JsonPath getJsonPath(Response response) {
        JsonPath obj = new JsonPath(response.asString());
        return obj;
    }

    public static void setHeaderMap() {
        mp = new HashMap<String,Object>();
        mp.put("Content-Type","application/json");
        mp.put("projectId", 2);
        mp.put("sessionToken", sessionToken);
        System.out.println("HeadersMap is set_");
    }
    

    public static Response getResPost() throws Exception {
        Response response = given().body(getPayloadCreate("Create"))
                .headers(mp).log().all()
                .when().post(baseURI + "wfms-configuration-management/api/v1/mailbox")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        if(role.equals("projectAdmin") || role.equals("superAdmin")) {
            JsonPath res = getJsonPath(response);
            MailBoxId = res.getInt("data.id");
        }
        return response;
    }
    
    public static Response getResPostWithServiceToken() throws Exception {
        //putting service Token in sessionToken to create a mailbox.
        mp.put("sessionToken",serviceToken);
        Response response = given().body(getPayloadCreate("Create"))
                .headers(mp).log().all()
                .when().post(baseURI + "wfms-configuration-management/api/v1/mailbox")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
            // updating sessionToken to it's previous value.
            mp.put("sessionToken",sessionToken);
            JsonPath res = getJsonPath(response);
            MailBoxId = res.getInt("data.id");
        return response;
    }

    
    
    

    public static Response getResPost_Negative_WrongEmailFormat() throws IOException {
        Response response = given().body(getPayload("Create_WrongEmailFormat"))
                .headers(mp).log().all()
                .when().post(baseURI + "wfms-configuration-management/api/v1/mailbox")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }

    public static Response getResPostMailBoxWithLargeName() throws IOException {
        Response response = given().body(getPayload("CreateLargeName"))
                .headers(mp).log().all()
                .when().post(baseURI + "wfms-configuration-management/api/v1/mailbox")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }
    
    

    public static Response getResPost_Negative_RepeatEmail() throws IOException {
        Response response = given().body(getPayload("Create_SameEmail"))
                .headers(mp).log().all()
                .when().post(baseURI + "wfms-configuration-management/api/v1/mailbox")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }

    
    
    

    public static Response getResPost_Negative_EmptyName() throws IOException {
        Response response = given().body(getPayload("Create_EmptyName"))
                .headers(mp).log().all()
                .when().post(baseURI + "wfms-configuration-management/api/v1/mailbox")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }


    
    
    
    public static Response getResPost_Negative_AssignedGroup() throws IOException {
        Response response = given().body(getPayload("Create_AssignedGroup"))
                .headers(mp).log().all()
                .when().post(baseURI + "wfms-configuration-management/api/v1/mailbox")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }

    
    
    

    public static Response getResPut() throws IOException {
        Response response = given().body(getPayloadPUT()).pathParam("id", MailBoxId)
                .headers(mp).log().all()
                .when().put(baseURI + "wfms-configuration-management/api/v1/mailbox/{id}")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }


    
    
    
    public static Response getResPut_Negative_NonExistentMailBoxId() throws IOException {
        Response response = given().body(getPayloadPUT()).pathParam("id", 12543)
                .headers(mp).log().all()
                .when().put(baseURI + "wfms-configuration-management/api/v1/mailbox/{id}")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }

    
    

    
    public static Response getResPut_Deactivate() throws IOException {
        Response response = given().body(getPayload_Status(false)).pathParam("id", MailBoxId)
                .headers(mp).log().all()
                .when().put(baseURI + "wfms-configuration-management/api/v1/mailbox/{id}/status")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }
    
    
    
    public static Response getResPut_DeactivateServiceToken() throws IOException {
        mp.put("sessionToken",serviceToken);
        Response response = given().body(getPayload_Status(false)).pathParam("id", MailBoxId)
                .headers(mp).log().all()
                .when().put(baseURI + "wfms-configuration-management/api/v1/mailbox/{id}/status")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        mp.put("sessionToken", sessionToken);
        return response;
    }

    
    
    

    public static Response getResPut_Activate() throws IOException {
        Response response = given().body(getPayload_Status(true)).pathParam("id", MailBoxId)
                .headers(mp).log().all()
                .when().put(baseURI + "wfms-configuration-management/api/v1/mailbox/{id}/status")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }


    
    
    
    public static Response getResPut_Activate_Negative_WrongMailBoxId() throws IOException {
        Response response = given().body(getPayload_Status(true)).pathParam("id", 12543)
                .headers(mp).log().all()
                .when().put(baseURI + "wfms-configuration-management/api/v1/mailbox/{id}/status")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }


    public static Response getRes_Get(HashMap<String,Object> hashMap) {
        Response response = given().queryParams(hashMap)
                .headers(mp)
                .when()
                .get(baseURI + "wfms-configuration-management/api/v1/mailbox")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }
    
}
