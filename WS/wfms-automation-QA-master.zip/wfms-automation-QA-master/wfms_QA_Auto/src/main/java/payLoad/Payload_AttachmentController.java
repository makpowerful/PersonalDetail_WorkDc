package payLoad;

import static io.restassured.RestAssured.given;

import java.io.File;
import java.io.IOException;

import io.restassured.response.Response;

public class Payload_AttachmentController extends AbstractComponents {
    private static String fileName;
    private static String baseURI = env + "wfms-ticket-service/api/v1";
    
    public static Response deleteAttachmentResponse(String id) {
        Response response = given().pathParam("id", id).headers(mp).log().uri()
                .when().delete(baseURI + "/attachments/{id}")
                .thenReturn();
        response.then().log().status();
        response.then().log().body();
        return response;
    }
    
    public static Response postAttachmentResponse(String rowName, String mime) throws IOException {
        al = excelData.getData(rowName, "AttachmentController_API", "Tcid");
        fileName = System.getProperty("user.dir") + al.get(1);
        File testFile = new File(fileName);
        mp.remove("Content-Type");
        Response response = given()
                .multiPart("file", testFile, mime).headers(mp).log().uri()
                .when().post(baseURI + "/attachments")
                .thenReturn();
        response.then().log().status();
        response.then().log().body();
        return response;
    }
}
