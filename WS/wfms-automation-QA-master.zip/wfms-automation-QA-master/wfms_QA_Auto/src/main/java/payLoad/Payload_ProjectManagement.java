package payLoad;


import static io.restassured.RestAssured.given;

import java.io.IOException;

import io.restassured.response.Response;

public class Payload_ProjectManagement extends AbstractComponents {
    public static String baseURI = "https://h-stage-apigateway.byjus.onl/wfms-configuration-management/wfms/projectManagement/v1";

    public static String getCreateProjectPayload(String rowName) throws IOException {
        
        al = excelData.getData(rowName, "ProjectManagement_API", "Tcid");
        
        String payload = "{\n"
                + "    \"projectId\": "+al.get(1)+",\n"
                + "    \"name\": \""+al.get(2)+"\",\n"
                + "    \"description\": \""+al.get(3)+"\",\n"
                + "    \"inUse\": "+al.get(4)+",\n"
                + "    \"createdBy\": \""+al.get(6)+"\",\n"
                + "    \"updatedBy\": \""+al.get(8)+"\"\n"
                + "}";
        
        return payload;
    }

    public static String getUpdateProjectPayload() throws IOException {
        
        al = excelData.getData("POST1", "ProjectManagement_API", "Tcid");
        
        String payload = "{\n"
                + "    \"projectId\": "+al.get(1)+",\n"
                + "    \"name\": \""+al.get(2)+"\",\n"
                + "    \"description\": \""+al.get(3)+"\",\n"
                + "    \"inUse\": "+al.get(4)+",\n"
                + "    \"createdBy\": \""+al.get(6)+"\",\n"
                + "    \"createdAt\": \"2023-02-27T06:15:56\",\n"
                + "    \"updatedBy\": \""+al.get(8)+"\"\n"
                + "}";
        
        return payload;
    }
    
    public static Response getProjectDetail(int id) {
        
        Response response = given().pathParam("id", id).headers(mp).when().get(baseURI + "/projectDetails/{id}");
        response.then().log().status();
        response.then().log().body();
        return response;
    }
    
    public static Response getProjectDetail(String id) {
        
        Response response = given().pathParam("id", id).headers(mp).when().get(baseURI + "/projectDetails/{id}");
        response.then().log().status();
        response.then().log().body();
        return response;
    }
    
    public static Response getProjectDetailsList() {

        Response response = given().headers(mp).when().get(baseURI + "/projectDetailsList");
        response.then().log().status();
        response.then().log().body();
        return response;
    }

    public static Response createProject(String payload) {
        
        Response response = given().contentType("application/json").body(payload).headers(mp).when().post(baseURI + "/projectDetails"); 
        response.then().log().status();
        response.then().log().body();
        return response;
    }
    
    public static Response updateProject(String payload) {
        
        Response response = given().contentType("application/json").body(payload).headers(mp).when().post(baseURI + "/projectDetails");
        response.then().log().status();
        response.then().log().body();
        return response;
    }

    public static Response deleteProject(int id) {
        
        Response response = given().pathParam("id", id).headers(mp).when().delete(baseURI + "/projectDetails/{id}");
        response.then().log().status();
        response.then().log().body();
        return response;
    }
    
    public static Response deleteProject(String id) {
        
        Response response = given().pathParam("id", id).headers(mp).when().delete(baseURI + "/projectDetails/{id}");
        response.then().log().status();
        response.then().log().body();
        return response;
    }
}
