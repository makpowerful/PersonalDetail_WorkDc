package payLoad;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.util.Random;

import POJOClasses.POJO_Channel_POST;
import io.restassured.response.Response;

public class Payload_ChannelController extends AbstractComponents {
    private static String baseURI = env + "wfms-configuration-management/wfms/channelManagement/v1";
    public static String channelName;
    
    public static void generateChannelName(){
        int leftLimit = 97; // letter 'a'
        int rightLimit = 122; // letter 'z'
        int targetStringLength = 10;
        Random random = new Random();

        String generatedString = random.ints(leftLimit, rightLimit + 1)
          .limit(targetStringLength)
          .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
          .toString();
        channelName = generatedString;
    }
    
    public static POJO_Channel_POST bodyContentPost(String rowName) throws IOException {
        al = excelData.getData(rowName, "ChannelController_API", "Tcid");
        POJO_Channel_POST bodyContent = new POJO_Channel_POST();
        
        bodyContent.setName(al.get(1).equalsIgnoreCase("N/A") ? "" : channelName);
        bodyContent.setDescription(al.get(2).equalsIgnoreCase("N/A") ? "" : al.get(2));
        return bodyContent;
    }
    
    public static String bodyContentPutCreatedAt(String rowName) throws IOException {
        al = excelData.getData(rowName, "ChannelController_API", "Tcid");
        return "{\n"
                + "    \"name\" : \"" + al.get(1) + "\",\n"
                + "    \"description\": \"" + al.get(2) + "\",\n"
                + "}";
    }

    public static Response postChannelController(String rowName) throws IOException {
        Response response = given().header("Content-Type", "application/json").log().body().body(bodyContentPost(rowName)).headers(mp).log().uri()
                .when().post(baseURI + "/channel")
                .thenReturn();
        response.then().log().status();
        response.then().log().body();
        return response;
    }

    public static Response putChannelController(String rowName, int channelID) throws IOException {
        Response response = given().header("Content-Type", "application/json").body(bodyContentPost(rowName)).headers(mp).log().uri()
                .pathParam("channelID", channelID)
                .when().put(baseURI + "/channel/{channelID}")
                .thenReturn();
        response.then().log().status();
        response.then().log().body();
        return response;
    }
    
    public static Response putChannelControllerCreatedAt(String rowName, int channelID) throws IOException {
        Response response = given().header("Content-Type", "application/json").body(bodyContentPutCreatedAt(rowName)).log().body().headers(mp).log().uri()
                .pathParam("channelID", channelID)
                .when().put(baseURI + "/channel/{channelID}")
                .thenReturn();
        response.then().log().status();
        response.then().log().body();
        return response;
    }

    public static Response deleteChannelController(int channelID) throws IOException {
        Response response = given().pathParam("channelID", channelID).headers(mp).log().uri()
                .when().delete(baseURI + "/channel/{channelID}")
                .thenReturn();
        response.then().log().status();
        response.then().log().body(); 
        return response;
    }

    public static Response getChannelController(int channelID) throws IOException {
        Response response = given().pathParam("channelID", channelID).headers(mp).log().uri()
                .when().get(baseURI + "/channel/{channelID}")
                .thenReturn();
        response.then().log().status();
        response.then().log().body();  
        return response;
    }

    public static Response putChannelController(String rowName, String channelID) throws IOException {
        Response response = given().header("Content-Type", "application/json").body(bodyContentPost(rowName)).headers(mp).log().uri()
                .pathParam("channelID", channelID)
                .when().put(baseURI + "/channel/{channelID}")
                .thenReturn();
        return response;
    }

    public static Response getChannelController(String channelID) {
        Response response = given().pathParam("channelID", channelID).headers(mp).log().uri()
                .when().get(baseURI + "/channel/{channelID}")
                .thenReturn();
        response.then().log().status();
        response.then().log().body();   
        return response;
    }

    public static Response deleteChannelController(String channelID) {
        Response response = given().pathParam("channelID", channelID).headers(mp).log().uri()
                .when().delete(baseURI + "/channel/{channelID}")
                .thenReturn();
        response.then().log().status();
        response.then().log().body();      
        return response;
    }

    public static Response getAllChannelController() {
        Response response = given().headers(mp).log().uri()
                .when().get(baseURI + "/channel")
                .thenReturn();
        response.then().log().status();
        response.then().log().body();    
        return response;
    }
}
