package payLoad;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import resources.ExcelData;
import resources.base;

public class PayLoad_TimeLine extends base{
    
    public static String sessionToken;
    static Map<String,Object> mp;
    static ExcelData excelData = new ExcelData();
    public static ArrayList<String> al = new ArrayList<String>();
    public static String baseURI = env;
    public static int ticketId;
    public static String priority;
    public static String caseStatus = "NEW";
    public static String dueDate;
    public static String groupName;
    public static String agentNameFirst;
    public static String agentNameLast;
    public static int nonExistentTicketId= 12322323;
    public static int projectId;
    
    
    
    
    private static String CreateTicketPayLoad() throws IOException {
        al = excelData.getData("create", "TimeLine_API", "Tcid");
        
        
        String payLoad =  "{\n"
                + "  \"channel\": \""+al.get(1)+"\",\n"
                + "  \"projectId\": "+projectId+",\n"
                + "  \"category\": \""+al.get(3)+"\",\n"
                + "  \"requester\": {\n"
                + "    \"name\": \""+al.get(4)+"\",\n"
                + "    \"email\": \""+al.get(5)+"\"\n"
                + "  },\n"
                + "  \"details\": {\n"
                + "    \"subCategory\": \""+al.get(6)+"\",\n"
                + "    \"issueType\": \""+al.get(7)+"\",\n"
                + "    \"issueSubType\": \""+al.get(8)+"\",\n"
                + "    \"subject\": \"Email storage is full\",\n"
                + "    \"description\": \"My email inbox is full and need to increase the storage\",\n"
                + "    \"attachments\": [\n"
                + "      \"63f5f8988e0b7d54271fd0bd\",\n"
                + "      \"63f5f8ed8e0b7d54271fd0be\"\n"
                + "    ],\n"
                + "    \"customerName\": \""+al.get(9)+"\",\n"
                + "    \"customerEmail\": \""+al.get(10)+"\"\n"
                + "  }\n"
                + "}";
        return payLoad;
    }
    
    
    public static void setHeaderMap() {
        mp = new HashMap<String,Object>();
        mp.put("Content-Type","application/json");
        mp.put("projectId", projectId);
        mp.put("sessionToken", sessionToken);
    }
    
    
    
    
    private static String getPutPayload(String type) throws IOException {
        al = excelData.getData(type, "TimeLine_API", "Tcid");
        
        String payLoad = "";
        if(type=="caseStatus") {
            caseStatus = al.get(1);
            payLoad = "{\n"
                    + "  \"status\": {\n"
                    + "    \"key\": \""+caseStatus+"\",\n"
                    + "    \"value\": \""+caseStatus+"\",\n"
                    + "    \"priority\": 0\n"
                    + "  }\n"
                    + "}";
        }else if(type=="priority") {
            priority = al.get(1);
            payLoad="{\n"
                    + "  \"priority\": {\n"
                    + "    \"key\": \""+al.get(1)+"\",\n"
                    + "    \"value\": \""+al.get(1)+"\",\n"
                    + "    \"priority\": 0\n"
                    + "  }\n"
                    + "}";
        }else if(type=="dueDate") {
            dueDate = al.get(2);
            payLoad = "{\n"
                    + "    \"dueDate\": \""+al.get(1)+"\"\n"
                    + "}";
        }else if(type=="group") {
            groupName = al.get(2);
            payLoad = "{\n"
                    + "    \"group\": {\n"
                    + "    \"groupId\": "+al.get(1)+",\n"
                    + "    \"groupName\": \""+groupName+"\",\n"
                    + "    \"ownerEmail\": \""+al.get(3)+"\",\n"
                    + "    \"groupEmail\": \""+al.get(4)+"\",\n"
                    + "    \"projectId\": "+projectId+"\n"
                    + "  }\n"
                    + "}";
        }else if(type=="agent") {
            agentNameFirst = al.get(1);
            agentNameLast = al.get(2);
            payLoad = "{\n"
                    + "    \"agent\": {\n"
                    + "    \"firstName\": \""+agentNameFirst+"\",\n"
                    + "    \"lastName\": \""+agentNameLast+"\",\n"
                    + "    \"email\": \""+al.get(3)+"\"\n"
                    + "  }\n"
                    + "}";
        }else {
            System.out.println("***************** SOMETHING IS WRONG!!!");
        }
        
        return payLoad;
    }
    
    
    
    
    
    public static JsonPath getJsonPath(Response response) {
        JsonPath obj = new JsonPath(response.asString());
        return obj;
    }
    
    
    

    public static Response getResPostTicket() throws IOException {
        Response response = given().body(CreateTicketPayLoad())
                .headers(mp).log().all()
                .when().post(baseURI + "wfms-ticket-service/api/v1/tickets")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        JsonPath res = getJsonPath(response);
        ticketId = res.getInt("data.ticketId");
        return response;
    }

   
    
    

    public static Response getResUpdate(String type) throws IOException {
        Response response = given().body(getPutPayload(type)).pathParam("ticketId", ticketId)
                .headers(mp).log().all()
                .when().put(baseURI + "wfms-ticket-service/api/v1/tickets/{ticketId}")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }

    
    
    
    
    public static Response getResGetTimeline() {
        Response response = given().pathParam("ticketId", ticketId)
                .headers(mp).log().all()
                .when()
                .get(baseURI + "wfms-ticket-service/api/v1/tickets/{ticketId}/timelines")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }



    
    
    public static Response getResGetTimeline_Negative_Non_existentId() {
        Response response = given().pathParam("ticketId", nonExistentTicketId)
                .headers(mp).log().all()
                .when()
                .get(baseURI + "wfms-ticket-service/api/v1/tickets/{ticketId}/timelines")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }





    public static Response deleteTicketResponse() {
        Response response = given().pathParams("ticketId",ticketId)
        .headers(mp).log().all()
        .when()
        .delete(baseURI + "wfms-ticket-service/api/v1/tickets/{ticketId}")
        .thenReturn();
        response.then().log().status();
        response.then().log().body();
        return response;
    }
    

}
