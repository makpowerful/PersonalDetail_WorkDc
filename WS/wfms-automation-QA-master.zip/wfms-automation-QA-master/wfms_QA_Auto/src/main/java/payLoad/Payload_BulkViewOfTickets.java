package payLoad;

import static io.restassured.RestAssured.given;
import io.restassured.response.Response;

public class Payload_BulkViewOfTickets extends AbstractComponents {
    
    public static String baseURI = env + "wfms-ticket-service/api/v1/tickets/export";
    
    public static Response getBulkView(String ticketIds, String projectId) {
        
        Response response = given().queryParam("ticketIds", ticketIds).queryParam("projectId", projectId).headers(mp).when().get(baseURI).thenReturn();
        response.then().log().status();
        response.then().log().body();
        
        return response;
    }
}
