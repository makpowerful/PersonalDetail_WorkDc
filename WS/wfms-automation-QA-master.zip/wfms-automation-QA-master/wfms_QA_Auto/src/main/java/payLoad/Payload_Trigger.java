package payLoad;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class Payload_Trigger {

    private static String baseURI = "https://h-stage-apigateway.byjus.onl/wfms-rule-engine";
    
    
    public static String RulePayload_twoCombo(String property, String operator, String value, int action) {
       
       if(action == 1) {
           
           return "{\n"
                   + "    \"name\": \"Test " + Long.toString(Instant.now().getEpochSecond()) + "\",\n"
                   + "    \"targetEntity\": \"TICKET\",\n"
                   + "    \"condition\": {\n"
                   + "        \"conditionType\": \"ALL\",\n"
                   + "        \"conditions\": null,\n"
                   + "        \"expressions\": [\n"
                   + "            {\n"
                   + "                \"property\": \""+property+"\",\n"
                   + "                \"operator\": \""+operator+"\",\n"
                   + "                \"value\": \""+value+"\"\n"
                   + "            }\n"
                   + "        ]\n"
                   + "    },\n"
                   + "    \"actionContextMapList\": [\n"
                   + "        {\n"
                   + "           \"actionName\": \"SET_FIELD\",\n"
                   + "           \"payload\": {\n"
                   + "               \"targetEntity\": \"TICKET\",\n"
                   + "               \"fieldName\": \"status\",\n"
                   + "               \"fieldValue\": {\n"
                   + "                   \"key\": \"close\",\n"
                   + "                   \"value\": \"CLOSE\",\n"
                   + "                   \"priority\": 2\n"
                   + "               }\n"
                   + "           }\n"
                   + "       }\n"
                   + "    ],\n"
                   + "    \"description\": \"Close the ticket when ticket is created\",\n"
                   + "    \"projectId\": 2\n"
                   + "}";
       }
       
       if(action == 2) {
           
           return "{\n"
                   + "    \"name\": \"Test " + Long.toString(Instant.now().getEpochSecond()) + "\",\n"
                   + "    \"targetEntity\": \"TICKET\",\n"
                   + "    \"condition\": {\n"
                   + "        \"conditionType\": \"ALL\",\n"
                   + "        \"conditions\": null,\n"
                   + "        \"expressions\": [\n"
                   + "            {\n"
                   + "                \"property\": \""+property+"\",\n"
                   + "                \"operator\": \""+operator+"\",\n"
                   + "                \"value\": \""+value+"\"\n"
                   + "            }\n"
                   + "        ]\n"
                   + "    },\n"
                   + "    \"actionContextMapList\": [\n"
                   + "        {\n"
                   + "           \"actionName\": \"SET_FIELD\",\n"
                   + "           \"payload\": {\n"
                   + "               \"targetEntity\": \"TICKET\",\n"
                   + "               \"fieldName\": \"priority\",\n"
                   + "               \"fieldValue\": {\n"
                   + "                   \"key\": \"high\",\n"
                   + "                   \"value\": \"HIGH\",\n"
                   + "                   \"priority\": 100\n"
                   + "               }\n"
                   + "           }\n"
                   + "       }\n"
                   + "    ],\n"
                   + "    \"description\": \"Close the ticket when ticket is created\",\n"
                   + "    \"projectId\": 2\n"
                   + "}";
       }
       
       if(action == 3) {
           
           return "{\n"
                   + "    \"name\": \"Test "+Long.toString(Instant.now().getEpochSecond())+"\",\n"
                   + "    \"targetEntity\": \"TICKET\",\n"
                   + "    \"condition\": {\n"
                   + "        \"conditionType\": \"ALL\",\n"
                   + "        \"conditions\": null,\n"
                   + "        \"expressions\": [\n"
                   + "            {\n"
                   + "                \"property\": \""+property+"\",\n"
                   + "                \"operator\": \""+operator+"\",\n"
                   + "                \"value\": \""+value+"\"\n"
                   + "            }\n"
                   + "        ]\n"
                   + "    },\n"
                   + "    \"actionContextMapList\": [\n"
                   + "        {\n"
                   + "           \"actionName\": \"SET_FIELD\",\n"
                   + "           \"payload\": {\n"
                   + "               \"targetEntity\": \"TICKET\",\n"
                   + "               \"fieldName\": \"group\",\n"
                   + "               \"projectId\": 2,\n"
                   + "               \"fieldValue\": {\n"
                   + "                   \"groupId\": 2647\n"
                   + "               }\n"
                   + "           }\n"
                   + "       }\n"
                   + "    ],\n"
                   + "    \"description\": \"Assign to group when a ticket is created\",\n"
                   + "    \"projectId\": 2\n"
                   + "}";
       }
       
       if(action == 4) {
           
           return "{\n"
                   + "    \"name\": \"Test "+Long.toString(Instant.now().getEpochSecond())+"\",\n"
                   + "    \"targetEntity\": \"TICKET\",\n"
                   + "    \"condition\": {\n"
                   + "        \"conditionType\": \"ALL\",\n"
                   + "        \"conditions\": null,\n"
                   + "        \"expressions\": [\n"
                   + "            {\n"
                   + "                \"property\": \""+property+"\",\n"
                   + "                \"operator\": \""+operator+"\",\n"
                   + "                \"value\": \""+value+"\"\n"
                   + "            }\n"
                   + "        ]\n"
                   + "    },\n"
                   + "    \"actionContextMapList\": [\n"
                   + "       {\n"
                   + "           \"actionName\": \"SET_FIELD\",\n"
                   + "           \"payload\": {\n"
                   + "               \"targetEntity\": \"TICKET\",\n"
                   + "               \"fieldName\": \"agent\",\n"
                   + "               \"fieldValue\": {\n"
                   + "                   \"firstName\": \"gaurang\",\n"
                   + "                   \"lastName\": \"agarwal\",\n"
                   + "                   \"email\": \"gaurang.agrawal1@byjus.com\"\n"
                   + "               }\n"
                   + "           }\n"
                   + "       }\n"
                   + "    ],\n"
                   + "    \"description\": \"Assign to group when a ticket is created\",\n"
                   + "    \"projectId\": 2\n"
                   + "}";
       }
       
       if(action == 5) {
           
           return "{\n"
                   + "    \"name\": \"Test "+Long.toString(Instant.now().getEpochSecond())+"\",\n"
                   + "    \"targetEntity\": \"TICKET\",\n"
                   + "    \"condition\": {\n"
                   + "        \"conditionType\": \"ALL\",\n"
                   + "        \"conditions\": null,\n"
                   + "        \"expressions\": [\n"
                   + "            {\n"
                   + "                \"property\": \""+property+"\",\n"
                   + "                \"operator\": \""+operator+"\",\n"
                   + "                \"value\": \""+value+"\"\n"
                   + "            }\n"
                   + "        ]\n"
                   + "    },\n"
                   + "    \"actionContextMapList\": [\n"
                   + "        {\n"
                   + "           \"actionName\": \"SET_FIELD\",\n"
                   + "           \"payload\": {\n"
                   + "               \"targetEntity\": \"TICKET\",\n"
                   + "               \"fieldName\": \"subject\",\n"
                   + "               \"fieldValue\": \"Test Test\"\n"
                   + "           }\n"
                   + "       }\n"
                   + "    ],\n"
                   + "    \"description\": \"Close the ticket when ticket is created\",\n"
                   + "    \"projectId\": 2\n"
                   + "}";
       }
       
       return "";
    }
}
