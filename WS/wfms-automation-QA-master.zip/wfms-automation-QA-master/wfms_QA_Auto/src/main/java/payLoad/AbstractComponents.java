package payLoad;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import resources.ExcelData;
import resources.base;

public class AbstractComponents extends base{
    protected static ExcelData excelData = new ExcelData();
    protected static ArrayList<String> al = new ArrayList<String>();
    static Map<String,Object> mp;
    static Map<String,Object> mpService;
//    static Faker faker = new Faker();
//    static int randomNum = ThreadLocalRandom.current().nextInt(1000, 10000 + 1);
//    static String firstName = faker.name().firstName().replaceAll("'","");
//    static String lastName = faker.name().lastName().replaceAll("'","");
//    static String parentName = faker.name().fullName().replaceAll("'","");
//    static String Auto="Dummy ";
//    static long Premiumid= 52514495345L+randomNum;
    
    public static JsonPath getJsonPath(Response response) {
        JsonPath obj = new JsonPath(response.asString());
        return obj;
    }
    
    public static void setHeaderMap(String projectId, String sessionToken) {
        mp = new HashMap<String,Object>();
        mp.put("Content-Type","application/json");
        mp.put("projectId", Integer.parseInt(projectId));
        mp.put("sessionToken", sessionToken);
    }
}
