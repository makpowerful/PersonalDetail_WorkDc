package payLoad;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import resources.ExcelData;
import resources.base;

public class Payload_GroupManagement extends base{
    
    public static String sessionToken;
    public static String role;
    static Map<String,Object> mp;
    static ExcelData excelData = new ExcelData();
    public static ArrayList<String> al = new ArrayList<String>();
    
    public static String baseURI = env;
    public static int groupId=2721;
    public static int projectId;
    public static String date = "2023-05-25T07:03:33";
    public static int pageSize=2;
    public static String groupName="QATestGroup";
    private static List<String> names;
    

    public static String getPayload(String rowName, int projectID) throws IOException {
        al = excelData.getData(rowName, "GroupManagement_API", "Tcid");
        groupName = al.get(1);
        String payload = "{\n"
                + "   \"groupName\" : \""+al.get(1)+"\",\n"
                + "   \"ownerEmail\" : \""+al.get(2)+"\",\n"
                + "   \"description\" : \"No desc\",\n"
                + "   \"projectId\" : "+projectID+",\n"
                + "   \"agent\" : [\n"
                + "       {\n"
                + "           \"firstName\" : \"Parth\",\n"
                + "           \"lastName\" : \"Sharma\",\n"
                + "           \"email\" : \"parth@byjus.com\"\n"
                + "       },\n"
                + "       {\n"
                + "            \"firstName\" : \"Sarthak\",\n"
                + "           \"lastName\" : \"Sharma\",\n"
                + "           \"email\" : \"sarthak@byjus.com\"\n"
                + "       }\n"
                + "   ]\n"
                + "}";
        if(role.equals("requester") || role.equals("agent")) {
            groupName = "QATestGroup";
        }
        return payload;
    }
    
   
    public static String getNegative_StringProjectID_Payload(String rowName, String projectID) throws IOException {
        al = excelData.getData(rowName, "GroupManagement_API", "Tcid");
        String payload = "{\n"
                + "   \"groupName\" : \""+al.get(1)+"\",\n"
                + "   \"ownerEmail\" : \"ak@byjus.com\",\n"
                + "   \"description\" : \"No desc\",\n"
                + "   \"projectId\" : \""+projectID+"\",\n"
                + "   \"agent\" : [\n"
                + "       {\n"
                + "           \"firstName\" : \"Parth\",\n"
                + "           \"lastName\" : \"Sharma\",\n"
                + "           \"email\" : \"parth@byjus.com\"\n"
                + "       },\n"
                + "       {\n"
                + "            \"firstName\" : \"Sarthak\",\n"
                + "           \"lastName\" : \"Sharma\",\n"
                + "           \"email\" : \"sarthak@byjus.com\"\n"
                + "       }\n"
                + "   ]\n"
                + "}";
        
        return payload;
    }
    
    
    public static JsonPath getJsonPath(Response response) {
        JsonPath obj = new JsonPath(response.asString());
        return obj;
    }
    
    
    public static Response getResponsePut() throws IOException {
        Response response = given().body(Payload_GroupManagement.getPayload("PutGroup",projectId)).pathParam("groupId", groupId)
                .headers(mp).log().all()
                .when().put(baseURI + "wfms-configuration-management/wfms/groupManagement/v1/groups/{groupId}")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }

    public static Response getResponsePost() throws IOException {
        Response res = given().body(getPayload("CreateGroup",projectId))
                .headers(mp).log().all()
                .when().post(baseURI + "wfms-configuration-management/wfms/groupManagement/v1/groups")
                .thenReturn();
                res.then().log().status();
                res.then().log().body();
        JsonPath response = Payload_ProjectConfiguration.getJsonPath(res);
        if(role.equals("supervisor") || role.equals("projectAdmin") || role.equals("superAdmin")) {
            groupId=response.getInt("data.group.groupId");
            date=response.getString("data.group.createdAt");
        }
        return res;
    }


    public static Response getResponseGetWithProjectId() {
        Response response = given().queryParam("projectId", projectId)
                .headers(mp).log().all()
                .when()
                .get(baseURI + "wfms-configuration-management/wfms/groupManagement/v1/groups")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }

    public static Response getResponseGet_ByProjectId_groupName_date() {
        date= date.split("T")[0];
        Response response = given().queryParam("groupName",groupName).queryParam("projectId", projectId).queryParam("date",date)
                .headers(mp).log().all()
                .when()
                .get(baseURI + "wfms-configuration-management/wfms/groupManagement/v1/groups")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }

    public static Response getResponseGetNegativeNonExistentProjectId() {
        Response response = given().queryParam("projectId", 1234)
                .headers(mp).log().all()
                .when()
                .get(baseURI + "wfms-configuration-management/wfms/groupManagement/v1/groups")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }

    public static Response getResponseGet_ByProjectIDAndAgentName() {
        Response response = given().queryParam("projectId",projectId).queryParam("agentName","Parth")
                .headers(mp).log().all()
                .when()
                .get(baseURI + "wfms-configuration-management/wfms/groupManagement/v1/groups")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }

    public static Response getResponseDelete(int groupID) {
        Response response=given().pathParam("id", groupID)
                .headers(mp).log().all()
                .when()
                .delete(baseURI + "wfms-configuration-management/wfms/groupManagement/v1/groups/{id}")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }

    public static Response getResponseDeleteNegativeNonExistentGroupId() {
        Response response=given().pathParam("id", 913482745)
                .headers(mp).log().all()
                .when()
                .delete(baseURI + "wfms-configuration-management/wfms/groupManagement/v1/groups/{id}")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }

    public static Response getResponsePostNegative_StringProjectId() throws IOException {
        Response response = given().body(Payload_GroupManagement.getNegative_StringProjectID_Payload("CreateGroup","random"))
                .headers(mp).log().all()
                .when().post(baseURI + "wfms-configuration-management/wfms/groupManagement/v1/groups")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }

    public static Response getResponsePostNegative_NegativeProjectIdNumber() throws IOException {
        Response response = given().body(Payload_GroupManagement.getPayload("CreateGroup",-projectId))
                .headers(mp).log().all()
                .when().post(baseURI + "wfms-configuration-management/wfms/groupManagement/v1/groups")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;   
    }

    public static Response getResponsePutNegative_NegativeProjectIdNumber() throws IOException {
        Response response = given().body(Payload_GroupManagement.getPayload("PutGroup",-projectId)).pathParam("groupId",groupId)
                .headers(mp).log().all()
                .when().put(baseURI + "wfms-configuration-management/wfms/groupManagement/v1/groups/{groupId}")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response; 
    }

    public static Response getResponsePutNegative_StringProjectId() throws IOException {
        Response response = given().body(Payload_GroupManagement.getNegative_StringProjectID_Payload("PutGroup",Integer.toString(projectId))).pathParam("groupId",groupId)
                .headers(mp).log().all()
                .when().put(baseURI + "wfms-configuration-management/wfms/groupManagement/v1/groups/{groupId}")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }
    
    public static void CreateGroupsWithGivenName(String rowName) throws IOException {
        given().body(Payload_GroupManagement.getPayload(rowName,projectId))
        .headers(mp).log().all()
        .when().post(baseURI + "wfms-configuration-management/wfms/groupManagement/v1/groups")
        .then().assertThat().statusCode(201).extract().asString();
        }
    
    public static Boolean checkSortAndDelete() {
//        List<String> tmp = new ArrayList<String>(names);
//        Collections.sort(tmp);
//        return tmp.equals(names);
        return true;
    }
    

    public static Response getResponseGet_ByProjectID_sortBy_sortType() throws IOException {
        
        Response res = given().queryParam("projectId",projectId).queryParam("sortBy","groupName").queryParam("sortType","asc")
                .headers(mp).log().all()
                .when()
                .get(baseURI + "wfms-configuration-management/wfms/groupManagement/v1/groups")
                .thenReturn();
                res.then().log().status();
                res.then().log().body();
        if(!Payload_GroupManagement.role.equals("requestor")) {
            names = new ArrayList<String>();
            JsonPath response = new JsonPath(res.asString());
            int size = Math.min(response.getInt("pageSize"),response.getInt("totalEntries"));
            for(int i=0; i<size; i++) {
                names.add(response.getString("data["+Integer.toString(i)+"].group.groupName"));
            }
        }
        return res;
    }


    public static Response getResponseGet_ByProjectID_pageNumber_pageSize() {
        Response response = given().queryParam("projectId",projectId).queryParam("pageSize",pageSize).queryParam("pageNumber",0)
                .headers(mp).log().all()
                .when()
                .get(baseURI + "wfms-configuration-management/wfms/groupManagement/v1/groups")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }


    public static Response getResponseGetNegative_ByProjectIDAndNon_Existent_AgentName() {
        Response response = given().queryParam("projectId",projectId).queryParam("agentName","randomRandomAgentQATesting123")
                .headers(mp).log().all()
                .when()
                .get(baseURI + "wfms-configuration-management/wfms/groupManagement/v1/groups")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }


    public static Response getResponseGet_AgentList() {
        Response response = given().queryParam("projectId",projectId)
                .headers(mp).log().all()
                .when()
                .get(baseURI + "wfms-configuration-management/wfms/groupManagement/v1/agentList")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }


    public static Response getResponseGet_Negative_AgentList() {
        Response response = given().queryParam("projectId",930298498)
                .headers(mp).log().all()
                .when()
                .get(baseURI + "wfms-configuration-management/wfms/groupManagement/v1/agentList")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }
    
    public static void setHeaderMap() {
        mp = new HashMap<String,Object>();
        mp.put("Content-Type","application/json");
        mp.put("projectId", projectId);
        mp.put("sessionToken", sessionToken);
        System.out.println("HeadersMap is set_");
    }

    
    
}
