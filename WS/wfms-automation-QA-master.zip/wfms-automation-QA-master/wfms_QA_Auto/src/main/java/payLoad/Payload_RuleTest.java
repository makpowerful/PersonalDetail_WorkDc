package payLoad;

import static io.restassured.RestAssured.given;

import java.util.HashMap;

import io.restassured.response.Response;

public class Payload_RuleTest {
    
    private static String baseURI = "https://h-stage-apigateway.byjus.onl/wfms-rule-engine";

    public static String RulePayload_oneCombo(String Operator1,String Operator2,String Conditiontype) {
        String bodycontent="{\r\n"
                + "    \"condition\": {\r\n"
                + "        \"conditionType\": \""+Conditiontype+"\",\r\n"
                + "        \"expressions\" : [\r\n"
                + "            {\r\n"
                + "                \"property\" : \"status\",\r\n"
                + "                \"operator\" : \""+Operator1+"\",\r\n"
                + "                \"value\": \"OPEN\"\r\n"
                + "            },\r\n"
                + "            {\r\n"
                + "                \"property\" : \"priority\",\r\n"
                + "                \"operator\" : \""+Operator2+"\",\r\n"
                + "                \"value\": \"HIGH\"\r\n"
                + "            }\r\n"
                + "        ]\r\n"
                + "    }\r\n"
                + "}";
        
       return bodycontent;
    }
    
    public static String RulePayload_twoCombo(String Conditiontype,String Conditiontype1,String Operator1,String Operator2,String Conditiontype2,String Operator3,String Operator4) {
        String bodycontent="{\r\n"
                + "    \"condition\": {\r\n"
                + "        \"conditionType\": \""+Conditiontype+"\",\r\n"
                + "        \"conditions\": [\r\n"
                + "            {\r\n"
                + "                \"conditionType\": \""+Conditiontype1+"\",\r\n"
                + "                \"expressions\": [\r\n"
                + "                    {\r\n"
                + "                        \"property\": \"status\",\r\n"
                + "                        \"operator\": \""+Operator1+"\",\r\n"
                + "                        \"value\": \"OPEN\"\r\n"
                + "                    },\r\n"
                + "                    {\r\n"
                + "                        \"property\": \"priority\",\r\n"
                + "                        \"operator\": \""+Operator2+"\",\r\n"
                + "                        \"value\": \"HIGH\"\r\n"
                + "                    }\r\n"
                + "                ]\r\n"
                + "            },\r\n"
                + "            {\r\n"
                + "                \"conditionType\": \""+Conditiontype2+"\",\r\n"
                + "                \"expressions\": [\r\n"
                + "                    {\r\n"
                + "                        \"property\": \"status\",\r\n"
                + "                        \"operator\": \""+Operator3+"\",\r\n"
                + "                        \"value\": \"OPEN\"\r\n"
                + "                    },\r\n"
                + "                    {\r\n"
                + "                        \"property\": \"priority\",\r\n"
                + "                        \"operator\": \""+Operator4+"\",\r\n"
                + "                        \"value\": \"HIGH\"\r\n"
                + "                    }\r\n"
                + "                ]\r\n"
                + "            }\r\n"
                + "        ]\r\n"
                + "    }\r\n"
                + "}";
        
       return bodycontent;
    }
    
    /*
     * public static Response getSearchAndFilterQuery(HashMap<String, String>
     * params) {
     * Response response = given().queryParams(params).log().uri()
     * .when().get(baseURI + "/api/v1/triggerAction")
     * .thenReturn();
     * response.then().log().status();
     * response.then().log().body();
     * return response;
     * }
     * 
     * public static String getResponseOneCombo() {
     * String Rule = given().header("Content-Type",
     * "application/json").body(Payload_RuleTest.RulePayload_oneCombo()).when()
     * .get(
     * "https://h-stage-apigateway.byjus.onl/wfms-rule-engine/api/v1/triggerAction")
     * .then().log().all()
     * .extract().response().asString();
     * return Rule;
     * }
     */
}
