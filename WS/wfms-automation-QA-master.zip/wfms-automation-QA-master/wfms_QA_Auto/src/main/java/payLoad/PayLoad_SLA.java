package payLoad;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import resources.ExcelData;
import resources.base;

public class PayLoad_SLA extends base{
    
    public static String sessionToken;
    public static String role;
    static Map<String,Object> mp;
    static ExcelData excelData = new ExcelData();
    public static ArrayList<String> al = new ArrayList<String>();
    public static String baseURI = env;    
    public static int projectId;
    private static int nonExistentProjectId=32333;
    public static int policyId;
    public static String policyName;
    public static int FIRST_REPLY_TIME_URGENT;
    public static int FIRST_REPLY_TIME_HIGH;
    public static int FIRST_REPLY_TIME_NORMAL;
    public static int FIRST_REPLY_TIME_LOW;
    public static int RESOLUTION_TIME_URGENT;
    public static int RESOLUTION_TIME_HIGH;
    public static int RESOLUTION_TIME_NORMAL;
    public static int RESOLUTION_TIME_LOW;
    public static int FIRST_REPLY_ESCALATION_TIME;
    public static int RESOLUTION_ESCALATION_TIME;
    public static String FIRST_REPLY_ESCALATION_EMAILID;
    public static String RESOLUTION_ESCALATION_EMAILID1;
    public static String RESOLUTION_ESCALATION_EMAILID2;
    
    
    
    private static String getPayload(String type) throws IOException {
        al = excelData.getData(type, "SLA_API", "Tcid");
        
        policyName = al.get(2);
        FIRST_REPLY_TIME_URGENT = Integer.valueOf(al.get(3));
        FIRST_REPLY_TIME_HIGH = Integer.valueOf(al.get(4));
        FIRST_REPLY_TIME_NORMAL = Integer.valueOf(al.get(5));
        FIRST_REPLY_TIME_LOW = Integer.valueOf(al.get(6));
        RESOLUTION_TIME_URGENT = Integer.valueOf(al.get(7));
        RESOLUTION_TIME_HIGH = Integer.valueOf(al.get(8));
        RESOLUTION_TIME_NORMAL = Integer.valueOf(al.get(9));
        RESOLUTION_TIME_LOW = Integer.valueOf(al.get(10));
        FIRST_REPLY_ESCALATION_TIME = Integer.valueOf(al.get(11));
        RESOLUTION_ESCALATION_TIME = Integer.valueOf(al.get(13));
        FIRST_REPLY_ESCALATION_EMAILID = al.get(12);
        RESOLUTION_ESCALATION_EMAILID1 = al.get(14);
        RESOLUTION_ESCALATION_EMAILID2 = al.get(15);
        
        String payload = "{\n"
                + " \"projectId\": "+projectId+",\n"
                + " \"policyName\": \""+policyName+"\",\n"
                + " \"policyDescription\": \"QA Testing the SLA API\",\n"
                + " \"targets\": [\n"
                + "     {\n"
                + "     \"priorityType\":\"URGENT\",\n"
                + "     \"targetType\":\"FIRST_RESPONSE_TIME\",\n"
                + "     \"targetTime\":"+FIRST_REPLY_TIME_URGENT+"\n"
                + "   },\n"
                + "   {\n"
                + "     \"priorityType\":\"HIGH\",\n"
                + "     \"targetType\":\"FIRST_RESPONSE_TIME\",\n"
                + "     \"targetTime\":"+FIRST_REPLY_TIME_HIGH+"\n"
                + "   },\n"
                + "   {\n"
                + "     \"priorityType\":\"MEDIUM\",\n"
                + "     \"targetType\":\"FIRST_RESPONSE_TIME\",\n"
                + "     \"targetTime\":"+FIRST_REPLY_TIME_NORMAL+"\n"
                + "   },\n"
                + "   {\n"
                + "     \"priorityType\":\"LOW\",\n"
                + "     \"targetType\":\"FIRST_RESPONSE_TIME\",\n"
                + "     \"targetTime\":"+FIRST_REPLY_TIME_LOW+"\n"
                + "   },\n"
                + "   {\n"
                + "     \"priorityType\":\"URGENT\",\n"
                + "     \"targetType\":\"RESOLUTION_TIME\",\n"
                + "     \"targetTime\":"+RESOLUTION_TIME_URGENT+"\n"
                + "   },\n"
                + "   {\n"
                + "     \"priorityType\":\"HIGH\",\n"
                + "     \"targetType\":\"RESOLUTION_TIME\",\n"
                + "     \"targetTime\":"+RESOLUTION_TIME_HIGH+"\n"
                + "   },\n"
                + "   {\n"
                + "     \"priorityType\":\"MEDIUM\",\n"
                + "     \"targetType\":\"RESOLUTION_TIME\",\n"
                + "     \"targetTime\":"+RESOLUTION_TIME_NORMAL+"\n"
                + "   },\n"
                + "   {\n"
                + "     \"priorityType\":\"LOW\",\n"
                + "     \"targetType\":\"RESOLUTION_TIME\",\n"
                + "     \"targetTime\":"+RESOLUTION_TIME_LOW+"\n"
                + "   }\n"
                + " ],\n"
                + " \"escalations\":[\n"
                + "   {\n"
                + "      \"escalationType\": \"FIRST_RESPONSE_TIME\",\n"
                + "      \"escalationTime\": "+FIRST_REPLY_ESCALATION_TIME+",\n"
                + "      \"emailIds\": [\n"
                + "        \""+FIRST_REPLY_ESCALATION_EMAILID+"\"\n"
                + "      ]\n"
                + "    },\n"
                + "    {\n"
                + "      \"escalationType\": \"RESOLUTION_TIME\",\n"
                + "      \"escalationTime\": "+RESOLUTION_ESCALATION_TIME+",\n"
                + "      \"emailIds\": [\n"
                + "        \""+RESOLUTION_ESCALATION_EMAILID1+"\",\n"
                + "        \""+RESOLUTION_ESCALATION_EMAILID2+"\"\n"
                + "      ]\n"
                + "    }\n"
                + " ]\n"
                + "}\n"
                + "";
        return payload;
    }
    
    
    
    
    public static void setHeaderMap() {
        mp = new HashMap<String,Object>();
        mp.put("Content-Type","application/json");
        mp.put("projectId", projectId);
        mp.put("sessionToken", sessionToken);
        System.out.println("HeadersMap is set_");
    }

    
    
    
    
    public static Response getResPost() throws IOException {
        Response res = given().body(getPayload("Create"))
                .headers(mp).log().all()
                .when().post(baseURI + "wfms-configuration-management/wfms/configurationManagement/v1/slas")
                .thenReturn();
                res.then().log().status();
                res.then().log().body();
        if(role.equals("projectAdmin") || role.equals("superAdmin")) {
            JsonPath response = getJsonPath(res);
            policyId = response.getInt("data.policyId");
        }
        return res;
    }

    
    
    
    
    public static Response getResPost_Negative_IncorrectEmailFormat() throws IOException {
        Response response = given().body(getPayload("CreateIncorrectEmailFormat"))
                .headers(mp).log().all()
                .when().post(baseURI + "wfms-configuration-management/wfms/configurationManagement/v1/slas")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }

    
    
    
    
    public static Response getResPut() throws IOException {
        Response response = given().body(getPayload("Update")).queryParam("projectId", projectId)
                .headers(mp).log().all()
                .when().put(baseURI + "wfms-configuration-management/wfms/configurationManagement/v1/slas")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }

    
    
    
    
    public static Response getResPut_Negative_NonExistentProjectId() throws IOException {
        Response response = given().body(getPayload("UpdateNegative")).queryParam("projectId", nonExistentProjectId)
                .headers(mp).log().all()
                .when().put(baseURI + "wfms-configuration-management/wfms/configurationManagement/v1/slas")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }

    
    
    
    
    public static Response getResGet() {
        Response response = given().queryParams("projectId",projectId)
                .headers(mp).log().all()
                .when()
                .get(baseURI + "wfms-configuration-management/wfms/configurationManagement/v1/slas")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }

    
    
    
    
    public static Response getResGet_Negative_NonExistentProjectId() {
        Response response = given().queryParams("projectId",nonExistentProjectId)
                .headers(mp).log().all()
                .when()
                .get(baseURI + "wfms-configuration-management/wfms/configurationManagement/v1/slas")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }

    
    
    
    
    public static Response getResDelete() {
        Response response = given().queryParams("projectId",projectId)
                .headers(mp).log().all()
                .when()
                .delete(baseURI + "wfms-configuration-management/wfms/configurationManagement/v1/slas")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }

    
    
    
    
    public static Response getResDelete_Negative_NonExistentProjectId() {
        Response response = given().queryParams("projectId",nonExistentProjectId)
                .headers(mp).log().all()
                .when()
                .delete(baseURI + "wfms-configuration-management/wfms/configurationManagement/v1/slas")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }

    
    
    
    
    public static JsonPath getJsonPath(Response response) {
        JsonPath obj = new JsonPath(response.asString());
        return obj;
    }

    
    
    
    
}
