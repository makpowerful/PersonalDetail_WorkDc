package payLoad;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONArray;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import resources.ExcelData;
import resources.base;

public class PayLoad_GetCalls_PRD extends base{
    
    static Map<String,Object> mp;
    public static String baseURI = env;
    
    
    public static void setHeaderMap(String projectId,String sessionToken) {
        mp = new HashMap<String,Object>();
        mp.put("Content-Type","application/json");
        mp.put("projectId", projectId);
        mp.put("sessionToken", sessionToken);
        System.out.println("HeadersMap is set_");
    }
    
    
    public static JsonPath getJsonPath(Response response) {
        JsonPath obj = new JsonPath(response.asString());
        return obj;
    }
    
    
    public static Response getResponseGetWithProjectId(int projectId) {
        Response response = given().queryParam("projectId", projectId)
                .headers(mp).log().all()
                .when()
                .get(baseURI + "wfms-configuration-management/wfms/groupManagement/v1/groups")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }

    public static Response getResponseGet_ByProjectId_groupName_date(String groupName, int projectId, String date) {
        date= date.split("T")[0];
        Response response = given().queryParam("groupName",groupName).queryParam("projectId", projectId).queryParam("date",date)
                .headers(mp).log().all()
                .when()
                .get(baseURI + "wfms-configuration-management/wfms/groupManagement/v1/groups")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }

    public static Response getResponseGet_ByProjectIDAndAgentName(int projectId, String agentName) {
        Response response = given().queryParam("projectId",projectId).queryParam("agentName","Parth")
                .headers(mp).log().all()
                .when()
                .get(baseURI + "wfms-configuration-management/wfms/groupManagement/v1/groups")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }



    public static Response getResponseGet_ByProjectID_pageNumber_pageSize(int projectId, int pageSize, int pageNumber) {
        Response response = given().queryParam("projectId",projectId).queryParam("pageSize",pageSize).queryParam("pageNumber",0)
                .headers(mp).log().all()
                .when()
                .get(baseURI + "wfms-configuration-management/wfms/groupManagement/v1/groups")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }


    public static Response getResponseGet_AgentList(int projectId) {
        Response response = given().queryParam("projectId",projectId)
                .headers(mp).log().all()
                .when()
                .get(baseURI + "wfms-configuration-management/wfms/groupManagement/v1/agentList")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }
    
    public static Response getRes_Get(HashMap<String,Object> hashMap) {
        Response response = given().queryParams(hashMap)
                .headers(mp)
                .when()
                .get(baseURI + "wfms-configuration-management/api/v1/mailbox")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }
    

    public static Response getResponseGetProjectConfigurationID(String resourceType, int projectId) {
        Response response = given().pathParam("resourceType", resourceType).pathParam("id", projectId)
                .headers(mp).log().all()
                .when()
                .get(baseURI + "wfms-configuration-management/wfms/configurationManagement/v1/projectConfiguration/{id}/{resourceType}")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }
    
    public static Response getResponseGetProjectConfigurationVersionNumber(String resourceType,int projectId, int versionNumber) {
        Response response =  given().pathParam("resourceType", resourceType).pathParam("id", projectId).pathParam("versionNumber",versionNumber)
                .headers(mp).log().all()
                .when()
                .get(baseURI + "wfms-configuration-management/wfms/configurationManagement/v1/projectConfiguration/{id}/{versionNumber}/{resourceType}")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }
    
    public static Response getResGet(int projectId) {
        Response response = given().queryParams("projectId",projectId)
                .headers(mp).log().all()
                .when()
                .get(baseURI + "wfms-configuration-management/wfms/configurationManagement/v1/slas")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }

    
    public static Response getResGetTimeline() {
        Response response = given().pathParam("ticketId", 5)
                .headers(mp).log().all()
                .when()
                .get(baseURI + "wfms-ticket-service/api/v1/tickets/{ticketId}/timelines")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }
    
// project management api
    
    public static Response getProjectDetail(int id) {
        
        Response response = given().pathParam("id", id).headers(mp).when().get(baseURI + "wfms-configuration-management/wfms/projectManagement/v1/projectDetails/{id}");
        response.then().log().status();
        response.then().log().body();
        return response;
    }
    
    public static Response getProjectDetail(String id) {
        
        Response response = given().pathParam("id", id).headers(mp).when().get(baseURI + "wfms-configuration-management/wfms/projectManagement/v1/projectDetails/{id}");
        response.then().log().status();
        response.then().log().body();
        return response;
    }
    
    public static Response getProjectDetailsList() {

        Response response = given().headers(mp).when().get(baseURI + "wfms-configuration-management/wfms/projectManagement/v1/projectDetailsList");
        response.then().log().status();
        response.then().log().body();
        return response;
    }
    
    // user management api
    
    public static Response getUserList(String emailIds) {
        
        Response response = given().queryParam("emailIds", emailIds).when().get(baseURI + "wfms-user-management/api/v1/users");
        response.then().log().status();
        response.then().log().body();
        return response;
    }
    
    // bulk view api
    
    public static Response getBulkView(String ticketIds) {
        
        Response response = given().queryParam("ticketIds", ticketIds).headers(mp).when().get(baseURI + "wfms-ticket-service/api/v1/tickets/export");
        response.then().log().status();
        response.then().log().body();
        
        return response;
    }
    
}
