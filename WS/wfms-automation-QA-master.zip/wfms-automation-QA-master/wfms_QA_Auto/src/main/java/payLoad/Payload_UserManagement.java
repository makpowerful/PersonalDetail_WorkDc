package payLoad;

import static io.restassured.RestAssured.given;
import java.util.ArrayList;

import io.restassured.response.Response;
import resources.ExcelData;

public class Payload_UserManagement {

    public static ExcelData excelData = new ExcelData();
    public static ArrayList<String> al = new ArrayList<String>();
    public static String baseURI = "https://h-stage-apigateway.byjus.onl/wfms-user-management/api/v1";
    
    public static String getCreateUserPayload(String firstName, String lastName, String emailId, String phoneNumber) {
        
        String payload = "{\n"
                + "    \"firstName\": \"" + firstName + "\",\n"
                + "    \"lastName\": \"" + lastName + "\",\n"
                + "    \"emailId\": \"" + emailId + "\",\n"
                + "    \"phoneNumber\": \"" + phoneNumber + "\"\n"
                + "}";
        
        return payload;
    }
    
    public static Response createUser(String payload) {
        
        Response response = given().contentType("application/json").body(payload).when().post(baseURI + "/users");
        response.then().log().status();
        response.then().log().body();
        return response;
    }
    
    public static Response getUserList(String emailIds) {
        
        Response response = given().queryParam("emailIds", emailIds).when().get(baseURI + "/users");
        response.then().log().status();
        response.then().log().body();
        return response;
    }
    
    public static Response updateUserDetails(int id, String payload) {
        
        Response response = given().contentType("application/json").body(payload).pathParam("id", id).when().put(baseURI + "/users/{id}");
        response.then().log().status();
        response.then().log().body();
        return response;
    }
    
    public static Response deleteUser(int id) {
        
        Response response = given().pathParam("id", id).when().delete(baseURI + "/users/{id}");
        response.then().log().status();
        response.then().log().body();
        return response;
    }
}
