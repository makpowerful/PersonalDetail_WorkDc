package payLoad;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.util.ArrayList;

import POJOClasses.POJO_Nested_TicketCreation_Agent;
import POJOClasses.POJO_Nested_TicketCreation_Group;
import POJOClasses.POJO_Nested_TicketCreation_POST_Details;
import POJOClasses.POJO_Nested_TicketCreation_Priority;
import POJOClasses.POJO_Nested_TicketCreation_Requester;
import POJOClasses.POJO_TicketCreation_BulkUpdate;
import POJOClasses.POJO_TicketCreation_POST;
import POJOClasses.POJO_TicketCreation_PUT;
import io.restassured.response.Response;

public class Payload_TicketController extends AbstractComponents {
    public static String baseURI = env + "wfms-ticket-service/api/v1";

    public static POJO_TicketCreation_POST bodyContentForPost(String rowName, String sheetName) throws IOException {
        al = excelData.getData(rowName, sheetName, "Tcid");
        POJO_TicketCreation_POST bodyContent = new POJO_TicketCreation_POST();
        bodyContent.setChannel(al.get(1));
        bodyContent.setProjectId(al.get(2));
        bodyContent.setCategory(al.get(3));
        POJO_Nested_TicketCreation_Requester requester = new POJO_Nested_TicketCreation_Requester(al.get(4), al.get(5));
        bodyContent.setRequester(requester);
        POJO_Nested_TicketCreation_POST_Details detailsObject = new POJO_Nested_TicketCreation_POST_Details();
        detailsObject.setSubCategory(al.get(6));
        detailsObject.setIssueType(al.get(7));
        detailsObject.setIssueSubType(al.get(8));
        detailsObject.setSubject(al.get(9));
        detailsObject.setDescription(al.get(10));
        String[] attachmentList = al.get(11).split(",");
        detailsObject.setAttachments(attachmentList);
        detailsObject.setCustomerName(al.get(12));
        detailsObject.setCustomerEmail(al.get(13));
        bodyContent.setDetails(detailsObject);

        return bodyContent;
    }
    
    public static POJO_TicketCreation_POST bodyContentForPostWrongBody(String rowName, String sheetName) throws IOException {
        al = excelData.getData(rowName, sheetName, "Tcid");
        POJO_TicketCreation_POST bodyContent = new POJO_TicketCreation_POST();
        bodyContent.setChannel(al.get(1));
        bodyContent.setProjectId(al.get(2));
        POJO_Nested_TicketCreation_Requester requester = new POJO_Nested_TicketCreation_Requester(al.get(4), al.get(5));
        bodyContent.setRequester(requester);
        POJO_Nested_TicketCreation_POST_Details detailsObject = new POJO_Nested_TicketCreation_POST_Details();
        detailsObject.setSubCategory(al.get(6));
        detailsObject.setIssueType(al.get(7));
        detailsObject.setIssueSubType(al.get(8));
        detailsObject.setSubject(al.get(9));
        detailsObject.setDescription(al.get(10));
        String[] attachmentList = al.get(11).split(",");
        detailsObject.setAttachments(attachmentList);
        detailsObject.setCustomerName(al.get(12));
        detailsObject.setCustomerEmail(al.get(13));
        bodyContent.setDetails(detailsObject);

        return bodyContent;
    }

    public static POJO_TicketCreation_PUT bodyContentForPut(int id, String rowName, String sheetName)
            throws IOException {

        al = excelData.getData(rowName, sheetName, "Tcid");

        POJO_TicketCreation_PUT bodyContent = new POJO_TicketCreation_PUT();
        bodyContent.setStatus(
                new POJO_Nested_TicketCreation_Priority(al.get(14), al.get(15), Integer.parseInt(al.get(16))));
        bodyContent.setPriority(
                new POJO_Nested_TicketCreation_Priority(al.get(17), al.get(18), Integer.parseInt(al.get(19))));
        bodyContent.setDueDate(al.get(20));
        bodyContent.setGroup(new POJO_Nested_TicketCreation_Group(Integer.parseInt(al.get(21)), al.get(22), al.get(23),
                al.get(24), Integer.parseInt(al.get(2))));
        bodyContent.setAgent(new POJO_Nested_TicketCreation_Agent(al.get(26), al.get(27),
                al.get(28)));

        return bodyContent;
    }

    public static POJO_TicketCreation_BulkUpdate bodyContentForBulkUpdate(ArrayList<Integer> ids, String rowName, String sheetName)
            throws IOException {

        al = excelData.getData(rowName, sheetName, "Tcid");
        
        POJO_TicketCreation_BulkUpdate bodyContent = new POJO_TicketCreation_BulkUpdate();
        bodyContent.setTicketIds(ids);
        bodyContent.setStatus(
                new POJO_Nested_TicketCreation_Priority(al.get(14), al.get(15), Integer.parseInt(al.get(16))));
        bodyContent.setPriority(
                new POJO_Nested_TicketCreation_Priority(al.get(17), al.get(18), Integer.parseInt(al.get(19))));
        bodyContent.setDueDate(al.get(20));
        bodyContent.setGroup(new POJO_Nested_TicketCreation_Group(Integer.parseInt(al.get(21)), al.get(22), al.get(23),
                al.get(24), Integer.parseInt(al.get(2))));
        bodyContent.setAgent(new POJO_Nested_TicketCreation_Agent(al.get(26), al.get(27),
                al.get(28)));
        
        return bodyContent;
    }

    public static Response getTicketControllerResponse(int id) {
        Response response = given().pathParam("id", id).headers(mp).log().uri()
                .when().get(baseURI + "/tickets/{id}")
                .thenReturn();
        response.then().log().status();
        response.then().log().body();
        return response;
    }

    public static Response getLimitOffsetTicketControllerResponse(int limit, int offset) {
        Response response = given().queryParams("limit", limit).queryParams("offset", offset).headers(mp).log().uri()
                .when().get(baseURI + "/tickets/")
                .thenReturn();
        response.then().log().status();
        response.then().log().body();
        return response;
    }

    public static Response putTicketControllerResponse(int id, String rowName, String sheetName) throws IOException {
        Response response = given().header("Content-Type", "application/json").pathParam("id", id).headers(mp).log().uri()
                .body(bodyContentForPut(id, rowName, sheetName))
                .when().put(baseURI + "/tickets/{id}")
                .thenReturn();
        response.then().log().status();
        response.then().log().body();
        return response;
    }

    public static Response bulkUpdateTicketControllerResponse(ArrayList<Integer> ids, String rowName, String sheetName)
            throws IOException {
        Response response = given().header("Content-Type", "application/json")
                .body(bodyContentForBulkUpdate(ids, rowName, sheetName)).headers(mp).log().uri()
                .when().put(baseURI + "/tickets/bulkUpdate")
                .thenReturn();
        response.then().log().status();
        response.then().log().body();
        return response;
    }

    public static Response postTicketControllerResponse(String rowName, String sheetName) throws IOException {
        Response response = given().header("Content-Type", "application/json")
                .body(bodyContentForPost(rowName, sheetName)).headers(mp).log().uri()
                .when().post(baseURI + "/tickets")
                .thenReturn();
        response.then().log().status();
        response.then().log().body();
        return response;
    }
    
    public static Response postTicketControllerResponseWrongBody(String rowName, String sheetName) throws IOException {
        Response response = given().header("Content-Type", "application/json")
                .body(bodyContentForPostWrongBody(rowName, sheetName)).headers(mp).log().uri()
                .when().post(baseURI + "/tickets")
                .thenReturn();
        response.then().log().status();
        response.then().log().body();
        return response;
    }

    public static Response deleteTicketControllerResponse(int id) {
        Response response = given().pathParam("id", id).headers(mp).log().uri()
                .when().delete(baseURI + "/tickets/{id}")
                .thenReturn();
        response.then().log().status();
        response.then().log().body();
        return response;
    }
}
