package payLoad;

import static io.restassured.RestAssured.given;

import io.restassured.response.Response;

public class Payload_GatewayIDService extends AbstractComponents {
    
    public static String baseURI = env + "wfms-session-service/wfms/v1/authorizationDetails";
    
    public static Response getAuthorizationDetails(String sessionToken) {
        Response response = given().queryParam("sessionToken", sessionToken).when().get(baseURI);
        response.then().log().status();
        response.then().log().body();
        return response;
    }
}
