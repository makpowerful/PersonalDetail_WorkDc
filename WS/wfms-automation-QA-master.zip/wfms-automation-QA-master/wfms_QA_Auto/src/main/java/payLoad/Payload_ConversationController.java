package payLoad;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import resources.ExcelData;
import resources.base;

public class Payload_ConversationController extends base{

    public static String sessionToken;
    static Map<String,Object> mp;
    public static String baseURI = env;
    static ExcelData excelData = new ExcelData();
    public static ArrayList<String> al = new ArrayList<String>();
    public static int ticketId;
    public static int projectId;
    public static String role;
    
    
    private static String CreateTicketPayLoad() throws IOException {
        al = excelData.getData("create", "TimeLine_API", "Tcid");
        
        String payLoad =  "{\n"
                + "  \"channel\": \""+al.get(1)+"\",\n"
                + "  \"projectId\": "+projectId+",\n"
                + "  \"category\": \""+al.get(3)+"\",\n"
                + "  \"requester\": {\n"
                + "    \"name\": \""+al.get(4)+"\",\n"
                + "    \"email\": \""+al.get(5)+"\"\n"
                + "  },\n"
                + "  \"details\": {\n"
                + "    \"subCategory\": \""+al.get(6)+"\",\n"
                + "    \"issueType\": \""+al.get(7)+"\",\n"
                + "    \"issueSubType\": \""+al.get(8)+"\",\n"
                + "    \"subject\": \"Email storage is full\",\n"
                + "    \"description\": \"My email inbox is full and need to increase the storage\",\n"
                + "    \"attachments\": [\n"
                + "      \"63f5f8988e0b7d54271fd0bd\",\n"
                + "      \"63f5f8ed8e0b7d54271fd0be\"\n"
                + "    ],\n"
                + "    \"customerName\": \""+al.get(9)+"\",\n"
                + "    \"customerEmail\": \""+al.get(10)+"\"\n"
                + "  }\n"
                + "}";
        return payLoad;
    }
    
    
    private static String getPostPayload() throws IOException {
        al = excelData.getData("create", "TimeLine_API", "Tcid");
        String payload="{\n"
                + "    \"authorDetails\": {\n"
                + "        \"email\": \""+al.get(5)+"\",\n"
                + "        \"name\": \""+al.get(4)+"\",\n"
                + "        \"roles\": [\n"
                + "            \""+role+"\"\n"
                + "        ]\n"
                + "    },\n"
                + "    \"text\": \"<p>sample reply.</p>\",\n"
                + "    \"type\": \"reply\",\n"
                + "    \"source\": \"web-form\",\n"
                + "    \"from\": \"support-wfms@byjus.com\",\n"
                + "    \"to\": [\n"
                + "        \"ankur@byjus.com\"\n"
                + "    ],\n"
                + "    \"cc\": [],\n"
                + "    \"bcc\": [],\n"
                + "    \"attachments\": []\n"
                + "}";
        return payload;
    }
    
    
    public static JsonPath getJsonPath(Response response) {
        JsonPath obj = new JsonPath(response.asString());
        return obj;
    }
    
    
    
    public static void setHeaderMap() {
        mp = new HashMap<String,Object>();
        mp.put("Content-Type","application/json");
        mp.put("projectId", projectId);
        mp.put("sessionToken", sessionToken);
        System.out.println("HeadersMap is set_");
    }

    
    
    public static Response getResponsePostNegative_ConversationController() throws IOException {
        Response response = given().body(getPostPayload()).pathParam("ticketId",98908099)
                .headers(mp).log().all()
                .when().post(baseURI + "wfms-ticket-service/api/v1/tickets/{ticketId}/conversations")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }


    public static Response getResponsePost_ConversationController() throws IOException {
        Response response = given().body(getPostPayload()).pathParam("ticketId",ticketId)
                .headers(mp).log().all()
                .when().post(baseURI + "wfms-ticket-service/api/v1/tickets/{ticketId}/conversations")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }



    public static Response getResPostTicket() throws IOException {
        Response res = given().body(CreateTicketPayLoad())
                .headers(mp).log().all()
                .when().post(baseURI + "wfms-ticket-service/api/v1/tickets")
                .thenReturn();
                res.then().log().status();
                res.then().log().body();
        JsonPath response = Payload_ProjectConfiguration.getJsonPath(res);
        ticketId = response.getInt("data.ticketId");
        return res;
    }


    public static void deleteTicketControllerResponse() {
              given().pathParams("ticketId",ticketId)
              .headers(mp)
                .when()
                .delete(baseURI + "wfms-ticket-service/api/v1/tickets/{ticketId}");
       return;
    }


}
