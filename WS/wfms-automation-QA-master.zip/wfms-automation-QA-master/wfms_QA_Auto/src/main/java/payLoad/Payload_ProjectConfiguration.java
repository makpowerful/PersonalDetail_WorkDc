package payLoad;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONArray;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import resources.ExcelData;
import resources.base;

public class Payload_ProjectConfiguration extends base{
    
    public static String sessionToken;
    static Map<String,Object> mp;
    static ExcelData excelData = new ExcelData();
    public static ArrayList<String> al = new ArrayList<String>();
    public static int projectId;
    
    public static String baseURI = env;    
    public static String getPayload() throws IOException {
        al = excelData.getData("CreateProject", "ProjectConfig_Api", "Tcid");
        
        String payload = "{\n"
                + "  \"projectId\": "+projectId+",\n"
                + "  \"projectName\": \""+al.get(2)+"\",\n"
                + "  \"configuration\": {\n"
                + "    \"project\": {\n"
                + "      \"name\": \"btc\",\n"
                + "      \"city\": {\n"
                + "        \"data\": [\n"
                + "          {\n"
                + "            \"value\": \"agra\",\n"
                + "            \"centreName\": {\n"
                + "              \"data\": [\n"
                + "                {\n"
                + "                  \"value\": \"sadar bazar\"\n"
                + "                },\n"
                + "                {\n"
                + "                  \"value\": \"pagalkhana\"\n"
                + "                }\n"
                + "              ],\n"
                + "              \"metadata\": {\n"
                + "                \"default\": \"pagalkhana\",\n"
                + "                \"dataType\": \"String\",\n"
                + "                \"fieldType\": \"dropdown\"\n"
                + "              }\n"
                + "            }\n"
                + "          },\n"
                + "          {\n"
                + "            \"value\": \"ajmer\",\n"
                + "            \"centreName\": {\n"
                + "              \"data\": [\n"
                + "                {\n"
                + "                  \"value\": \"abc\"\n"
                + "                },\n"
                + "                {\n"
                + "                  \"value\": \"xyz\"\n"
                + "                }\n"
                + "              ],\n"
                + "              \"metadata\": {\n"
                + "                \"default\": \"abc\",\n"
                + "                \"dataType\": \"String\",\n"
                + "                \"fieldType\": \"dropdown\"\n"
                + "              }\n"
                + "            }\n"
                + "          }\n"
                + "        ],\n"
                + "        \"metadata\": {\n"
                + "          \"default\": \"agra\",\n"
                + "          \"dataType\": \"String\",\n"
                + "          \"fieldType\": \"dropdown\"\n"
                + "        }\n"
                + "      },\n"
                + "      \"issueCategory\": {\n"
                + "        \"data\": [\n"
                + "          {\n"
                + "            \"value\": \"academic\",\n"
                + "            \"subcategory\": {\n"
                + "              \"data\": [\n"
                + "                {\n"
                + "                  \"value\": \"batchMerge\",\n"
                + "                  \"FromGrade\": {\n"
                + "                    \"data\": [\n"
                + "                      {\n"
                + "                        \"value\": \"4\"\n"
                + "                      },\n"
                + "                      {\n"
                + "                        \"value\": \"5\"\n"
                + "                      },\n"
                + "                      {\n"
                + "                        \"value\": \"6\"\n"
                + "                      }\n"
                + "                    ],\n"
                + "                    \"metadata\": {\n"
                + "                      \"default\": \"4\",\n"
                + "                      \"dataType\": \"String\",\n"
                + "                      \"fieldType\": \"radio\"\n"
                + "                    }\n"
                + "                  },\n"
                + "                  \"board\": {\n"
                + "                    \"data\": [\n"
                + "                      {\n"
                + "                        \"value\": \"cbse\"\n"
                + "                      },\n"
                + "                      {\n"
                + "                        \"value\": \"icse\"\n"
                + "                      },\n"
                + "                      {\n"
                + "                        \"value\": \"karnataka\"\n"
                + "                      }\n"
                + "                    ],\n"
                + "                    \"metadata\": {\n"
                + "                      \"default\": \"academic\",\n"
                + "                      \"dataType\": \"String\",\n"
                + "                      \"fieldType\": \"dropdown\"\n"
                + "                    }\n"
                + "                  },\n"
                + "                  \"startDate\": {\n"
                + "                    \"data\": [\n"
                + "                      {\n"
                + "                        \"value\": \"\"\n"
                + "                      }\n"
                + "                    ],\n"
                + "                    \"metadata\": {\n"
                + "                      \"default\": \"empty\",\n"
                + "                      \"dataType\": \"String\",\n"
                + "                      \"fieldType\": \"dropdown\"\n"
                + "                    }\n"
                + "                  },\n"
                + "                  \"sudentPID\": {\n"
                + "                    \"data\": [\n"
                + "                      {\n"
                + "                        \"value\": \"\"\n"
                + "                      }\n"
                + "                    ],\n"
                + "                    \"metadata\": {\n"
                + "                      \"default\": \"empty\",\n"
                + "                      \"dataType\": \"String\",\n"
                + "                      \"fieldType\": \"dropdown\"\n"
                + "                    }\n"
                + "                  }\n"
                + "                },\n"
                + "                {\n"
                + "                  \"value\": \"operation issue\"\n"
                + "                },\n"
                + "                {\n"
                + "                  \"value\": \"faculty absent\"\n"
                + "                }\n"
                + "              ],\n"
                + "              \"metadata\": {\n"
                + "                \"default\": \"batchMerge\",\n"
                + "                \"dataType\": \"String\",\n"
                + "                \"fieldType\": \"dropdown\"\n"
                + "              }\n"
                + "            }\n"
                + "          },\n"
                + "          {\n"
                + "            \"value\": \"assessment\",\n"
                + "            \"subcategory\": {\n"
                + "              \"data\": [\n"
                + "                {\n"
                + "                  \"value\": \"need to be explored\"\n"
                + "                }\n"
                + "              ],\n"
                + "              \"metadata\": {\n"
                + "                \"default\": \"NA\",\n"
                + "                \"dataType\": \"String\",\n"
                + "                \"fieldType\": \"dropdown\"\n"
                + "              }\n"
                + "            }\n"
                + "          },\n"
                + "          {\n"
                + "            \"value\": \"platform\",\n"
                + "            \"subcategory\": {\n"
                + "              \"data\": [\n"
                + "                {\n"
                + "                  \"value\": \"need to be explored\"\n"
                + "                }\n"
                + "              ],\n"
                + "              \"metadata\": {\n"
                + "                \"default\": \"NA\",\n"
                + "                \"dataType\": \"String\",\n"
                + "                \"fieldType\": \"dropdown\"\n"
                + "              }\n"
                + "            }\n"
                + "          }\n"
                + "        ],\n"
                + "        \"metadata\": {\n"
                + "          \"default\": \"academic\",\n"
                + "          \"dataType\": \"String\",\n"
                + "          \"fieldType\": \"dropdown\"\n"
                + "        }\n"
                + "      },\n"
                + "      \"subject\": {\n"
                + "        \"data\": [\n"
                + "          {\n"
                + "            \"value\": \"\"\n"
                + "          }\n"
                + "        ],\n"
                + "        \"metadata\": {\n"
                + "          \"default\": \"empty\",\n"
                + "          \"dataType\": \"String\",\n"
                + "          \"fieldType\": \"text\"\n"
                + "        }\n"
                + "      },\n"
                + "      \"description\": {\n"
                + "        \"data\": [\n"
                + "          {\n"
                + "            \"value\": \"\"\n"
                + "          }\n"
                + "        ],\n"
                + "        \"metadata\": {\n"
                + "          \"default\": \"empty\",\n"
                + "          \"dataType\": \"String\",\n"
                + "          \"fieldType\": \"text\"\n"
                + "        }\n"
                + "      },\n"
                + "      \"attachment\": {\n"
                + "        \"data\": [\n"
                + "          {\n"
                + "            \"value\": \"\"\n"
                + "          }\n"
                + "        ],\n"
                + "        \"metadata\": {\n"
                + "          \"default\": \"empty\",\n"
                + "          \"dataType\": \"String\",\n"
                + "          \"fieldType\": \"attachment\"\n"
                + "        }\n"
                + "      }\n"
                + "    }\n"
                + "  },\n"
                + "  \"resourceType\": \""+al.get(3)+"\"\n"
                + "}";
        
        return payload;
    }
    
    
    
    public static String getLongIdPayload() throws IOException {
        al = excelData.getData("CreateProject", "ProjectConfig_Api", "Tcid");
        
        String payload = "{\n"
                + "  \"projectId\": 123456789123456,\n"
                + "  \"projectName\": \""+al.get(2)+"\",\n"
                + "  \"configuration\": {\n"
                + "    \"project\": {\n"
                + "      \"name\": \"btc\",\n"
                + "      \"city\": {\n"
                + "        \"data\": [\n"
                + "          {\n"
                + "            \"value\": \"agra\",\n"
                + "            \"centreName\": {\n"
                + "              \"data\": [\n"
                + "                {\n"
                + "                  \"value\": \"sadar bazar\"\n"
                + "                },\n"
                + "                {\n"
                + "                  \"value\": \"pagalkhana\"\n"
                + "                }\n"
                + "              ],\n"
                + "              \"metadata\": {\n"
                + "                \"default\": \"pagalkhana\",\n"
                + "                \"dataType\": \"String\",\n"
                + "                \"fieldType\": \"dropdown\"\n"
                + "              }\n"
                + "            }\n"
                + "          },\n"
                + "          {\n"
                + "            \"value\": \"ajmer\",\n"
                + "            \"centreName\": {\n"
                + "              \"data\": [\n"
                + "                {\n"
                + "                  \"value\": \"abc\"\n"
                + "                },\n"
                + "                {\n"
                + "                  \"value\": \"xyz\"\n"
                + "                }\n"
                + "              ],\n"
                + "              \"metadata\": {\n"
                + "                \"default\": \"abc\",\n"
                + "                \"dataType\": \"String\",\n"
                + "                \"fieldType\": \"dropdown\"\n"
                + "              }\n"
                + "            }\n"
                + "          }\n"
                + "        ],\n"
                + "        \"metadata\": {\n"
                + "          \"default\": \"agra\",\n"
                + "          \"dataType\": \"String\",\n"
                + "          \"fieldType\": \"dropdown\"\n"
                + "        }\n"
                + "      },\n"
                + "      \"issueCategory\": {\n"
                + "        \"data\": [\n"
                + "          {\n"
                + "            \"value\": \"academic\",\n"
                + "            \"subcategory\": {\n"
                + "              \"data\": [\n"
                + "                {\n"
                + "                  \"value\": \"batchMerge\",\n"
                + "                  \"FromGrade\": {\n"
                + "                    \"data\": [\n"
                + "                      {\n"
                + "                        \"value\": \"4\"\n"
                + "                      },\n"
                + "                      {\n"
                + "                        \"value\": \"5\"\n"
                + "                      },\n"
                + "                      {\n"
                + "                        \"value\": \"6\"\n"
                + "                      }\n"
                + "                    ],\n"
                + "                    \"metadata\": {\n"
                + "                      \"default\": \"4\",\n"
                + "                      \"dataType\": \"String\",\n"
                + "                      \"fieldType\": \"radio\"\n"
                + "                    }\n"
                + "                  },\n"
                + "                  \"board\": {\n"
                + "                    \"data\": [\n"
                + "                      {\n"
                + "                        \"value\": \"cbse\"\n"
                + "                      },\n"
                + "                      {\n"
                + "                        \"value\": \"icse\"\n"
                + "                      },\n"
                + "                      {\n"
                + "                        \"value\": \"karnataka\"\n"
                + "                      }\n"
                + "                    ],\n"
                + "                    \"metadata\": {\n"
                + "                      \"default\": \"academic\",\n"
                + "                      \"dataType\": \"String\",\n"
                + "                      \"fieldType\": \"dropdown\"\n"
                + "                    }\n"
                + "                  },\n"
                + "                  \"startDate\": {\n"
                + "                    \"data\": [\n"
                + "                      {\n"
                + "                        \"value\": \"\"\n"
                + "                      }\n"
                + "                    ],\n"
                + "                    \"metadata\": {\n"
                + "                      \"default\": \"empty\",\n"
                + "                      \"dataType\": \"String\",\n"
                + "                      \"fieldType\": \"dropdown\"\n"
                + "                    }\n"
                + "                  },\n"
                + "                  \"sudentPID\": {\n"
                + "                    \"data\": [\n"
                + "                      {\n"
                + "                        \"value\": \"\"\n"
                + "                      }\n"
                + "                    ],\n"
                + "                    \"metadata\": {\n"
                + "                      \"default\": \"empty\",\n"
                + "                      \"dataType\": \"String\",\n"
                + "                      \"fieldType\": \"dropdown\"\n"
                + "                    }\n"
                + "                  }\n"
                + "                },\n"
                + "                {\n"
                + "                  \"value\": \"operation issue\"\n"
                + "                },\n"
                + "                {\n"
                + "                  \"value\": \"faculty absent\"\n"
                + "                }\n"
                + "              ],\n"
                + "              \"metadata\": {\n"
                + "                \"default\": \"batchMerge\",\n"
                + "                \"dataType\": \"String\",\n"
                + "                \"fieldType\": \"dropdown\"\n"
                + "              }\n"
                + "            }\n"
                + "          },\n"
                + "          {\n"
                + "            \"value\": \"assessment\",\n"
                + "            \"subcategory\": {\n"
                + "              \"data\": [\n"
                + "                {\n"
                + "                  \"value\": \"need to be explored\"\n"
                + "                }\n"
                + "              ],\n"
                + "              \"metadata\": {\n"
                + "                \"default\": \"NA\",\n"
                + "                \"dataType\": \"String\",\n"
                + "                \"fieldType\": \"dropdown\"\n"
                + "              }\n"
                + "            }\n"
                + "          },\n"
                + "          {\n"
                + "            \"value\": \"platform\",\n"
                + "            \"subcategory\": {\n"
                + "              \"data\": [\n"
                + "                {\n"
                + "                  \"value\": \"need to be explored\"\n"
                + "                }\n"
                + "              ],\n"
                + "              \"metadata\": {\n"
                + "                \"default\": \"NA\",\n"
                + "                \"dataType\": \"String\",\n"
                + "                \"fieldType\": \"dropdown\"\n"
                + "              }\n"
                + "            }\n"
                + "          }\n"
                + "        ],\n"
                + "        \"metadata\": {\n"
                + "          \"default\": \"academic\",\n"
                + "          \"dataType\": \"String\",\n"
                + "          \"fieldType\": \"dropdown\"\n"
                + "        }\n"
                + "      },\n"
                + "      \"subject\": {\n"
                + "        \"data\": [\n"
                + "          {\n"
                + "            \"value\": \"\"\n"
                + "          }\n"
                + "        ],\n"
                + "        \"metadata\": {\n"
                + "          \"default\": \"empty\",\n"
                + "          \"dataType\": \"String\",\n"
                + "          \"fieldType\": \"text\"\n"
                + "        }\n"
                + "      },\n"
                + "      \"description\": {\n"
                + "        \"data\": [\n"
                + "          {\n"
                + "            \"value\": \"\"\n"
                + "          }\n"
                + "        ],\n"
                + "        \"metadata\": {\n"
                + "          \"default\": \"empty\",\n"
                + "          \"dataType\": \"String\",\n"
                + "          \"fieldType\": \"text\"\n"
                + "        }\n"
                + "      },\n"
                + "      \"attachment\": {\n"
                + "        \"data\": [\n"
                + "          {\n"
                + "            \"value\": \"\"\n"
                + "          }\n"
                + "        ],\n"
                + "        \"metadata\": {\n"
                + "          \"default\": \"empty\",\n"
                + "          \"dataType\": \"String\",\n"
                + "          \"fieldType\": \"attachment\"\n"
                + "        }\n"
                + "      }\n"
                + "    }\n"
                + "  },\n"
                + "  \"resourceType\": \""+al.get(3)+"\"\n"
                + "}";
        
        return payload;
    }
    
    public static JsonPath getJsonPath(Response response) {
        JsonPath obj = new JsonPath(response.asString());
        return obj;
    }
    
    

    public static void setHeaderMap() {
        mp = new HashMap<String,Object>();
        mp.put("Content-Type","application/json");
        mp.put("projectId", projectId);
        mp.put("sessionToken", sessionToken);
        System.out.println("HeadersMap is set_");
    }
    
    
    public static Response getResponsePost() throws IOException {
        Response response = given().body(getPayload())
                .headers(mp).log().all()
                .when().post(baseURI + "wfms-configuration-management/wfms/configurationManagement/v1/projectConfiguration")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }
    
    
    public static JSONArray getResponseGetProjectList() {
        JSONArray response = given().pathParam("resourceType", al.get(3))
                .headers(mp).log().all()
                .when().get(baseURI + "wfms-configuration-management/wfms/configurationManagement/v1/projectList/{resourceType}")
                .then().assertThat().statusCode(200).extract()
                .as(JSONArray.class);
        return response;
    }
    
    public static Response getResponseGetProjectConfigurationID() {
        Response response = given().pathParam("resourceType", al.get(3)).pathParam("id", projectId)
                .headers(mp).log().all()
                .when()
                .get(baseURI + "wfms-configuration-management/wfms/configurationManagement/v1/projectConfiguration/{id}/{resourceType}")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }
    
    public static Response getResponseGetProjectConfigurationVersionNumber(int versionNumber) {
        Response response =  given().pathParam("resourceType", al.get(3)).pathParam("id", projectId).pathParam("versionNumber",versionNumber)
                .headers(mp).log().all()
                .when()
                .get(baseURI + "wfms-configuration-management/wfms/configurationManagement/v1/projectConfiguration/{id}/{versionNumber}/{resourceType}")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }
    
    public static Response getResponseDELETEProjectConfiguration() {
        Response response=given().pathParam("projectId", projectId).pathParam("resource",al.get(3))
                .headers(mp).log().all()
                .when()
                .delete(baseURI + "wfms-configuration-management/wfms/configurationManagement/v1/projectConfiguration/{projectId}/{resource}")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }

    public static Response getFailureResponsePostLongId() throws IOException {
        Response response = given().body(Payload_ProjectConfiguration.getLongIdPayload())
                .headers(mp).log().all()
                .when().post(baseURI + "wfms-configuration-management/wfms/configurationManagement/v1/projectConfiguration")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }



    public static Response getConfigWrongId() {
        Response response = given().pathParam("resourceType", al.get(3)).pathParam("id", "13602")
                .headers(mp).log().all()
                .when()
                .get(baseURI + "wfms-configuration-management/wfms/configurationManagement/v1/projectConfiguration/{id}/{resourceType}")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }



    public static Response getConfigWrongResource() {
        Response response = given().pathParam("resourceType", "NotJourney").pathParam("id", projectId)
                .headers(mp).log().all()
                .when()
                .get(baseURI + "wfms-configuration-management/wfms/configurationManagement/v1/projectConfiguration/{id}/{resourceType}")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }



    public static Response getConfigUnrealVersion(int version) {
        Response response =  given().pathParam("resourceType", al.get(3)).pathParam("id", projectId).pathParam("versionNumber",version)
                .headers(mp).log().all()
                .when()
                .get(baseURI + "wfms-configuration-management/wfms/configurationManagement/v1/projectConfiguration/{id}/{versionNumber}/{resourceType}")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }



    public static Response getResponseDELETEVersionProjectConfiguration() {
        Response response=given().pathParam("id", projectId).pathParam("resource",al.get(3)).pathParam("version", "2")
                .headers(mp).log().all()
                .when()
                .delete(baseURI + "wfms-configuration-management/wfms/configurationManagement/v1/projectConfiguration/{id}/{version}/{resource}")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }



    public static Response getResponseDELETENon_existingProjectConfiguration() {
        Response response=given().pathParam("id", projectId).pathParam("resource","randomRandomConfigurationTest")
                .headers(mp).log().all()
                .when()
                .delete(baseURI + "wfms-configuration-management/wfms/configurationManagement/v1/projectConfiguration/{id}/{resource}")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }



    public static Response getResponseDELETEVersionNon_existingProjectConfiguration() {
        Response response=given().pathParam("id", projectId).pathParam("resource",al.get(3)).pathParam("version", "2")
                .headers(mp).log().all()
                .when()
                .delete(baseURI + "wfms-configuration-management/wfms/configurationManagement/v1/projectConfiguration/{id}/{version}/{resource}")
                .thenReturn();
                response.then().log().status();
                response.then().log().body();
        return response;
    }
    
    
    
    
    
    
}
