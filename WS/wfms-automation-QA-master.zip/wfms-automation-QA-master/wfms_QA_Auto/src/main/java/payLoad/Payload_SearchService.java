package payLoad;

import static io.restassured.RestAssured.given;

import java.util.HashMap;

import io.restassured.response.Response;

public class Payload_SearchService extends AbstractComponents {
    
    private static String baseURI = env;

    public static Response getSearchAndFilterQuery(HashMap<String, String> params) {
        Response response = given().queryParams(params).headers(mp).log().uri()
                .when().get(baseURI + "wfms-search-service/api/v1/search/ticket")
                .thenReturn();
        response.then().log().status();
        response.then().log().body();
        return response;
    }
}
