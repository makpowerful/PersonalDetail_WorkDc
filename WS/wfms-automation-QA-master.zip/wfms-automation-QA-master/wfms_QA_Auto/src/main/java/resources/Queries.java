package resources;

public class Queries {
    
    
	public static String Chatcount(String val) {
		String Query="SELECT COUNT(Id)recordCount, OwnerId, Action_Type__c\r\n"
				+ "FROM Task\r\n"
				+ "WHERE Status = 'Open'\r\n"
				+ "AND Action_Type__c IN ('Student One-to-One', 'Parent One-to-One', 'Group Chat')\r\n"
				+ "AND OwnerId IN ('"+val+"')\r\n"
				+ "GROUP BY OwnerId, Action_Type__c\r\n"
				+ "ORDER BY COUNT(Id)";
		return Query;
	}
	
	//@Author : Bhavana
	// Query to Change status of audit case from not assigned to Rejected
	public static String StatusChange(String AuditcaseId,String colluserId)
	{
	  //Code to change the status of the audit case to rejected
        String statusChangeCode = "case c = new case();\n"
                + "c.id = '"+AuditcaseId+"';\n"
                + "c.ownerid = '"+colluserId+"';\n"
                + "c.Audit_Status__c = 'Rejected';\n"
                + "update c;";
	    return statusChangeCode;
	}
	
	//@Author : Bhavana
	// Query to Add pdId for the EMI case
	public static String AddpdId(String EMIcaseId,String PDID)
	{
	    String addpdId = "case c = new case();\n"
                + "c.id = '"+EMIcaseId+"';\n"
                + "c.PD_ID__c = '"+PDID+"';\n"
                + "update c;";
	    return addpdId;
	}

}
