package com.testing.cpsat.mock;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ ExamQ3.class, ExamQ4.class})
public class AllTests {

}
