package RS_DS_Alogrithms;

public class exponential {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		
		int rows = 5;
		//array matrix -

	    for (int i = 1; i <= rows; ++i) { //O(N~2)
	      for (int j = 1; j <= i; ++j) {
	        System.out.print("* ");
	      }
	      System.out.println();
	    }
	  }
		
	
	
	
	
//******************************************************************	
		
		//O(2^n) - Exponential time

//		Exponential (base 2) running time means that the calculations 
//		performed by an algorithm double every time as the input
//		grows.
		
	//	Example - Fibanocci Series
		
		
		
		
		
		
	

}
