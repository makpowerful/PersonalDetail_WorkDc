package InterviewPractice;

public class InvertedPyramid {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count = 5;
	       
	       for(int i=1;i<=count;i++){
	           for(int j=i;j<=count;j++){
	               System.out.print("*");
	           }
	           System.out.println();
	       }
	}

}
