package InterviewPractice;

import java.util.*;

public class SortHashMapByValue {
    public static void main(String[] args) {
        // Step 1: Create the HashMap and populate it with key-value pairs
        HashMap<String, Integer> hashMap = new HashMap<>();
        hashMap.put("Apple", 5);
        hashMap.put("Orange", 3);
        hashMap.put("Banana", 8);
        hashMap.put("Grapes", 2);

        // Step 2: Copy the entries of the HashMap to a List
        List<Map.Entry<String, Integer>> entryList = new ArrayList<>(hashMap.entrySet());

        // Step 3: Sort the List based on the values using a custom comparator
        Collections.sort(entryList, new Comparator<Map.Entry<String, Integer>>() {
            @Override
            public int compare(Map.Entry<String, Integer> entry1, Map.Entry<String, Integer> entry2) {
                return entry1.getValue().compareTo(entry2.getValue());
            }
        });

        // Step 4: Create a new LinkedHashMap to preserve the sorted order of the entries
        LinkedHashMap<String, Integer> sortedHashMap = new LinkedHashMap<>();

        // Step 5: Copy the sorted entries from the List back to the LinkedHashMap
        for (Map.Entry<String, Integer> entry : entryList) {
            sortedHashMap.put(entry.getKey(), entry.getValue());
        }

        // Print the sorted HashMap
        System.out.println(sortedHashMap);
    }
}

