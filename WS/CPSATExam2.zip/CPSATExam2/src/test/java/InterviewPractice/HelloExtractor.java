package InterviewPractice;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HelloExtractor {
    public static void main(String[] args) {
        String inputString = "LKJGFHLEUHILOHELLO";
        String patternString = "(?i)hello"; // (?i) makes the pattern case-insensitive

        // Create a Pattern object using the patternString
        Pattern pattern = Pattern.compile(patternString);

        // Create a Matcher object to find matches in the inputString
        Matcher matcher = pattern.matcher(inputString);

        // Find the first occurrence of the pattern in the inputString
        if (matcher.find()) {
            String extractedWord = matcher.group();
            System.out.println("Extracted word: " + extractedWord);
        } else {
            System.out.println("No 'hello' found in the input string.");
        }
    }
}

