package InterviewPractice;
import java.util.*;

public class SortHashMapByKey {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 String a = "kjasdnashshuuwwww";
	        char ch[] = a.toCharArray();
	        HashMap<Character,Integer> hm = new HashMap<>();
	        
	        for(char c : ch){
	            if(!hm.containsKey(c)){
	                hm.put(c,1);
	            }
	            else{
	                hm.put(c,hm.get(c)+1);
	            }
	        }
	        
	        for(HashMap.Entry<Character,Integer> hm1 : hm.entrySet()){
	            System.out.println(hm1.getKey()+":"+hm1.getValue());
	        }
	        System.out.println("****************");
	        TreeMap<Character,Integer> mt = new TreeMap<>(hm);
	        for(Map.Entry<Character,Integer> mt1 : mt.entrySet()){
	            System.out.println(mt1.getKey()+":"+mt1.getValue());
	        }
	        
	        
	        
	}

}
