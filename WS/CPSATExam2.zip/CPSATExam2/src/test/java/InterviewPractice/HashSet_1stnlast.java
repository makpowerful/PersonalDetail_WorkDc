package InterviewPractice;

import java.util.*;

public class HashSet_1stnlast {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

        String[] s = {"Mohammed","Abul","Kalam","Shabaz"};
        HashSet<String> hs = new HashSet<>();
        for(int i=0;i<s.length;i++){
            hs.add(s[i]);
        }
        
        System.out.println(hs);
        String first = null;
        String last = null;
        if(!hs.isEmpty()){
            first = hs.iterator().next();
        }
        System.out.println(first);
        Iterator<String> it = hs.iterator();
        
        while(it.hasNext()){
            last = it.next();
        }
        System.out.println(last);
        
    
	}

}
