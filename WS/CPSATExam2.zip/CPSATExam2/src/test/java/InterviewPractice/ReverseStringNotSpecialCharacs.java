package InterviewPractice;

public class ReverseStringNotSpecialCharacs {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	       String a = "S#l@es%*a";
	        char[] c = a.toCharArray();
	        revString(c);
	        System.out.print(c);
	}
	
	 public static void revString(char[] c){
	        int l = 0;
	        int r = c.length-1;
	        while(l<r){
	            if(!Character.isAlphabetic(c[l])){
	                l++;
	            }
	            else if(!Character.isAlphabetic(c[r])){
	               r--; 
	            }
	            else{
	               char temp;
	               temp = c[l];
	               c[l] = c[r];
	               c[r] = temp;
	               l++;
	               r--;
	            }
	        }
	    }

}

//Python Code
//a = "aA#$nfhd#Zk#*i"
//arr_char = []
//arr_char.extend(a)
//print(arr_char)
//l = 0
//r = len(arr_char) -1;
//while l < r :
//    if arr_char[l].isalpha() == False:
//        l+=1
//    elif arr_char[r].isalpha() == False:
//        r-=1
//    else:
//        temp = arr_char[l]
//        arr_char[l] = arr_char[r]
//       arr_char[r] = temp
//        l+=1
//        r-=1

//s =""
//for b in arr_char:
//    s+=b
//
//print(s)