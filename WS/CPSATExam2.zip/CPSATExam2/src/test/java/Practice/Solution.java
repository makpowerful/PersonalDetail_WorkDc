package Practice;

import java.util.Arrays;

class Solution {

    public static void main(String args[]){
        int[] a = {1,2,3,0,0,0};
        int[] b = {2,5,6};
        int[] c = {1};
        int[] d = {};
        int[] e = {0};
        int[] f = {1};
        merge(a,3,b,3);
        merge(c,1,d,0);
        merge(e,0,f,1);
    }
    public static String merge(int[] nums1, int m, int[] nums2, int n) {
        int c[] = new int[m+n];
        int i=0,j=0,k=0;
        while(i<m){
            c[k++]= nums1[i++];
        }
        while(j<n){
            c[k++]= nums2[j++];
        }

        Arrays.sort(c);
        System.out.println(Arrays.toString(c));
        return Arrays.toString(c);
    }
}
