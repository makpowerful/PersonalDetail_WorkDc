package Practice;
import java.util.HashMap;
import java.util.Map;


public class practice {
	
	public static void main(String[] args) {
		 String a = "TestforHashMapSorting";
	        char[] c = a.toCharArray();
	        HashMap<Character,Integer> hm= new HashMap<>();
	        
	        for(char ch : c){
	            if(!hm.containsKey(ch)){
	                hm.put(ch,1);
	            }
	            else{
	                hm.put(ch,hm.get(ch)+1);
	            }
	        }
	        System.out.println(hm);
	}

}