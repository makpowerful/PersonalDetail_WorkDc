package Practice;

import java.util.Random;

public class generateProgs {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random random=new Random();
		String[] IP= {"binarySearch.java","Fibanocci.java","InvertedPyramid.java","Merge2ArrayNoDuplicate.java",
				"NumberCombination.java", "Palindrome.java", "PrimeNumber.java","Pyramid.java","ReverseNumber.java",
				"ReverseStringNotSpecialCharacs.java","StringOccurance_Vowel.java"};
		int IPnum=rGenerate(IP);
		System.out.println(IP[IPnum]);
		System.out.println(random.nextInt(69));
		System.out.println(random.nextInt(69));
		System.out.println(random.nextInt(69));
		System.out.println(random.nextInt(69));
		
	}
	
	public static int rGenerate(String[] s) {
		Random random=new Random();
		return random.nextInt(s.length);
		
	}

}
