package NAL_JavaQuestions;

public class _1_printWithoutNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Print from 1 to 100 without using any numbers in your code
		
		   
        int one = 'A'/'A';
        String s = "..........";
        for(int i=one;i<=(s.length()*s.length());i++){
            System.out.println(i);
            }
            
        //Solution using ASCII value
        for(int i=one;i<='d';i++){
            System.out.println(i);
            } 
	}

}
