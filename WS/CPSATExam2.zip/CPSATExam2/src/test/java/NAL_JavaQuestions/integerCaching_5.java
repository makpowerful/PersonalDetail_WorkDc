package NAL_JavaQuestions;

public class integerCaching_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Integer Range is from -128 to 127
		Integer a =190;
		Integer b= 190;
		
		if(a==b) {
			System.out.println("Both are equal");
		}
		else {
			System.out.println("Both are not equal");
		}

	}

}
