package NAL_JavaQuestions;

public class _24_complexLogic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = (byte)+(char)-(int)+(long)-1;
		System.out.println(i);
	}

}
