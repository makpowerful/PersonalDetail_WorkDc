package NAL_JavaQuestions;

public class _27_UnicodeCharcProg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//hi this is my java code(' \u000d System.out.println("Hello World ");
		//\ u000d is a Unicode
		
	}

}
