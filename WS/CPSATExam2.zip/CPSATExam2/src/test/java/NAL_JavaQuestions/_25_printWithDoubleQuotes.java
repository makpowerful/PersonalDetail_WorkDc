package NAL_JavaQuestions;

public class _25_printWithDoubleQuotes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 *
		 /"Hello"/
		 /'Hello'/
		 "Hello"
		 I love "java" and "programming" and "movies"
		 'I love "java" and "programming" and "movies"'
		 */

		System.out.println("/\"Hello\"/");
		System.out.println("/'Hello'/");
		System.out.println("\"Hello\"");
		System.out.println("I love \"java\" and \"programming\" and \"movies\"");
		System.out.println("'I love \"java\" and \"programming\" and \"movies\"'");
	}
	
}
