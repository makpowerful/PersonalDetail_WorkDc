package NAL_JavaQuestions;

public class _6_NANProg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(9.0/0);
		System.out.println(9.0/0.0);
		System.out.println(1233d/0); //--> Double
		System.out.println(33f/0); //--> Float
		System.out.println(0.0/0.0);
		System.out.println(8/0);
	}

}
