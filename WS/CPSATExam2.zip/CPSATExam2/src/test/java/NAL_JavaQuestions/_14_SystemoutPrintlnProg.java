package NAL_JavaQuestions;

public class _14_SystemoutPrintlnProg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println();
		//System --> Is a class
		//out --> Is a static variable in System class
		//println --> Is a method in PrintStream class
		
	}

}
