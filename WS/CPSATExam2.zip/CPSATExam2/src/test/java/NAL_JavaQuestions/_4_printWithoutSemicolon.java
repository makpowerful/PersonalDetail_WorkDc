package NAL_JavaQuestions;

import org.apache.poi.util.SystemOutLogger;

public class _4_printWithoutSemicolon {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//1.
		if(System.out.printf("Hello World" + "\n") == null) {
			
		}
		
		//2.
		if(System.out.append("Hello World" + "\n") == null) {
			
		}
		
		//3.
		if(System.out.append("Hello World" + "\n").equals(null) ) {
			
		}
	}

}
