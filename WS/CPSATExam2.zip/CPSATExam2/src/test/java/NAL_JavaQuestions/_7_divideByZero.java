package NAL_JavaQuestions;

public class _7_divideByZero {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(2.0/0.0);
		System.out.println(0.0/0.0);
		System.out.println(Math.sqrt(-1));
		
		System.out.println(Float.NaN == Float.NaN);
		System.out.println(Float.NaN != Float.NaN);
		
	}

}
