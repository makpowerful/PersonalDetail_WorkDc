package NAL_JavaQuestions;

import java.util.StringJoiner;

public class _31_stringJoiner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StringJoiner sj = new StringJoiner(",","[","]");
		sj.add("Mohammed");
		sj.add("Abul");
		sj.add("kalam");
		
		System.out.println(sj);
		

	}

}
