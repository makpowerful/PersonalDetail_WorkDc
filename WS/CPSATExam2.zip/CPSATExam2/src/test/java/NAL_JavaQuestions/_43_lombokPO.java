package NAL_JavaQuestions;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter

public class _43_lombokPO {
	
	private String CustomerName;
	private int Age;
	private boolean isActive;
	
	
}
