package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import resources.base;

public class MD_AssetInfoPO extends base{
	
	public WebDriver driver;

	By btn_Next_xpath= By.xpath("//button[contains(text(),'Next')]");
	By btn_Save_xpath= By.xpath("//button[contains(text(),'Save')]");
	By btn_Accept_Popup_xpath= By.xpath("//lightning-button/button");
	By btn_A_Trust_Start_xpath= By.xpath("//div[2]/lightning-button/button");
	By pcklst_TOT_xpath= By.xpath("//div[2]/c-ssp-base-component-input-picklist/div/select");
	By txt_Trst_NOB_xpath= By.xpath("//input");
	By txt_Trust_Value_xpath= By.xpath("//c-ssp-base-component-input-text-icon/div/div/lightning-input/div/input");
	By rdbtn_ET_xpath= By.xpath("//span[2]");
	By date_ED_xpath= By.xpath("//div/div/input");
	By tglbtn_RecPayTrsut_xpath= By.xpath("//div/div/span/label/span");
	By btn_A_CA_Start_xpath= By.xpath("//div[2]/div/c-ssp-selection-card-with-remove-icon/div/div/div/div[2]/lightning-button/button");
	By pcklst_TOA_xpath= By.xpath("//div[2]/c-ssp-base-component-input-picklist/div/select");
	By txt_CA_NOB_xpath= By.xpath("//input");
	By txt_CA_Value_xpath= By.xpath("//c-ssp-base-component-input-text-icon/div/div/lightning-input/div/input");
	By tglbtn_CA_Anthr_Own_xpath= By.xpath("//span[2]/label");
	
	public MD_AssetInfoPO(WebDriver driver) {
		// TODO Auto-generated constructor stub

		this.driver = driver;
	}
	
	public void Click_AcceptAssetPopup() {
		
		driver.findElement(btn_Accept_Popup_xpath).click();
	}
	
	public void Click_A_Trust_Start() {
		
		driver.findElement(btn_A_Trust_Start_xpath).click();
	}
	
	public void Select_TypeOfTrust() throws InterruptedException {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,250);");
		Thread.sleep(1000);
		Select tot = new Select(driver.findElement(pcklst_TOT_xpath));
		tot.selectByVisibleText("Pooled Disability");
	}
	
	public void Enter_Trust_NameofBank() {
		
		driver.findElement(txt_Trst_NOB_xpath).sendKeys("STAR");
	}

	public void Enter_Trust_Value() {
		
		driver.findElement(txt_Trust_Value_xpath).sendKeys("100");
	}
	
    public void Click_Estab_Trust() {
		
		driver.findElement(rdbtn_ET_xpath).click();
	}
	
    public void Enter_DateEstab() {
		
		driver.findElement(date_ED_xpath).sendKeys("01/01/2020");
	}
    
    public void Click_RecPay_Trust() {
		
		driver.findElement(tglbtn_RecPayTrsut_xpath).click();
	}
    
    public void Click_CA_Start(){
    	
    	driver.findElement(btn_A_CA_Start_xpath).click();
    }
	
	public void Select_TypeOfAccount() throws InterruptedException {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,250);");
		Thread.sleep(1000);
		Select tot = new Select(driver.findElement(pcklst_TOA_xpath));
		tot.selectByVisibleText("Checking Accounts");
	}
    
    public void Enter_CA_NameofBank() {
		
		driver.findElement(txt_CA_NOB_xpath).sendKeys("STARLET");
	}
    
    public void Click_CA_AnotherOwner() {
    	
    	driver.findElement(tglbtn_CA_Anthr_Own_xpath).click();
    }
    
	public void Enter_CA_Value() {
		
		driver.findElement(txt_CA_Value_xpath).sendKeys("100");
	}
	
    public void ClickNext() {

		driver.findElement(btn_Next_xpath).click();
	}

    public void ClickSave() {

		driver.findElement(btn_Save_xpath).click();
	}
}
