package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import resources.base;

public class HHInformation_IncomeandSubPO extends base{
	
	public WebDriver driver;

	By btn_Next_xpath= By.xpath("//button[contains(text(),'Next')]");
	By tglbtn_3Mnths_Y_xpath= By.xpath("//div[1]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_3Mnths_N_xpath= By.xpath("//div[1]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By chkbx_3Mnths_HHM1_xpath= By.xpath("//div[1]/div/p[2]/c-ssp-base-component-input-checkbox[1]/div/div/lightning-input/div/span/label/span");
	By tglbtn_Strike_Y_xpath= By.xpath("//div[2]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_Strike_N_xpath= By.xpath("//div[2]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn_60days_Y_xpath= By.xpath("//div[3]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_60days_N_xpath= By.xpath("//div[3]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn_SelfE_Y_xpath= By.xpath("//div[4]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_SelfE_N_xpath= By.xpath("//div[4]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn_SSI_Y_xpath= By.xpath("//div[5]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_SSI_N_xpath= By.xpath("//div[5]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn_Retirmnt_Y_xpath= By.xpath("//div[6]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_Retirmnt_N_xpath= By.xpath("//div[6]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn_DIR_Y_xpath= By.xpath("//div[7]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_DIR_N_xpath= By.xpath("//div[7]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn_MaintI_Y_xpath= By.xpath("//div[8]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_MaintI_N_xpath= By.xpath("//div[8]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn_Insrnce_Y_xpath= By.xpath("//div[9]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_Insrnce_N_xpath= By.xpath("//div[9]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn_GSP_Y_xpath= By.xpath("//div[10]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_GSP_N_xpath= By.xpath("//div[10]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn_HA_FA_CA_Y_xpath= By.xpath("//div[11]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_HA_FA_CA_N_xpath= By.xpath("//div[11]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn_HEAP_Y_xpath= By.xpath("//div[12]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_HEAP_N_xpath= By.xpath("//div[12]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	
	public HHInformation_IncomeandSubPO(WebDriver driver) {
		// TODO Auto-generated constructor stub

		this.driver = driver;
	}
	
	//Does anyone in this household have job income from an employer or had a job in the last 3 months?
	
	public void Click_Jobin3Mnths_Y() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,250);");
		Thread.sleep(1000);
		driver.findElement(tglbtn_3Mnths_Y_xpath).click();
	}

	public void Click_Jobin3Mnths_N() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,250);");
		Thread.sleep(1000);
		driver.findElement(tglbtn_3Mnths_N_xpath).click();
	}
	
	public void Click_Jobin3Mnths_HHM1() {
		
		driver.findElement(chkbx_3Mnths_HHM1_xpath).click();
	}	
	
	//Does anyone in this household have a job but is on strike?
	
	public void Click_JobonStrike_Y() {
		
		driver.findElement(tglbtn_Strike_Y_xpath).click();
	}

	public void Click_JobonStrike_N() {
		
		driver.findElement(tglbtn_Strike_N_xpath).click();
	}
	
	//Has anyone in the household quit a job or voluntarily reduced their work hours in the last 60 days?
	
	public void Click_WH60days_Y() {
		
		driver.findElement(tglbtn_60days_Y_xpath).click();
	}

	public void Click_WH60days_N() {
		
		driver.findElement(tglbtn_60days_N_xpath).click();
	}
	
	//Does anyone in this household have self-employment income?
	
	public void Click_SelfEInc_Y() {
		
		driver.findElement(tglbtn_SelfE_Y_xpath).click();
	}

	public void Click_SelfEInc_N() {
		
		driver.findElement(tglbtn_SelfE_N_xpath).click();
	}
	
	//Does anyone in this household receive income from Social Security/SSI, Veterans Administration or railroad benefits?
	
	public void Click_SSI_VA_Y() {
		
		driver.findElement(tglbtn_SSI_Y_xpath).click();
	}

	public void Click_SSI_VA_N() {
		
		driver.findElement(tglbtn_SSI_N_xpath).click();
	}
	
	//Does anyone in this household receive income from retirement, pension or an investment such as an annuity or trust?
	
	public void Click_Retire_Pension_Y() {
		
		driver.findElement(tglbtn_Retirmnt_Y_xpath).click();
	}

	public void Click_Retire_Pension_N() {
		
		driver.findElement(tglbtn_Retirmnt_N_xpath).click();
	}
	
	//Does anyone in this household receive income from dividends, interest, or royalties?
	
	public void Click_Divid_Interest_Y() {
		
		driver.findElement(tglbtn_DIR_Y_xpath).click();
	}

	public void Click_Divid_Interest_N() {
		
		driver.findElement(tglbtn_DIR_N_xpath).click();
	}
	
	//Does anyone in this household receive support or maintenance income, such as alimony, child support, adoption subsidy payments, or foster care income?
	
	public void Click_MaintIncome_Alimny_Y() {
		
		driver.findElement(tglbtn_MaintI_Y_xpath).click();
	}

	public void Click_MaintIncome_Alimny_N() {
		
		driver.findElement(tglbtn_MaintI_N_xpath).click();
	}
	
	//Does anyone in this household receive income from an insurance or benefit such as unemployment or workers compensation?
	
	public void Click_WorkerCompen_Y() {
		
		driver.findElement(tglbtn_Insrnce_Y_xpath).click();
	}

	public void Click_WorkerCompen_N() {
		
		driver.findElement(tglbtn_Insrnce_N_xpath).click();
	}
	
	//Does anyone in this household receive any other type of goods, services, or payments?
	
	public void Click_Goods_Service_Y() {
		
		driver.findElement(tglbtn_GSP_Y_xpath).click();
	}

	public void Click_Goods_Service_N() {
		
		driver.findElement(tglbtn_GSP_N_xpath).click();
	}
	
	//Does anyone in this household receive health assistance (Medicaid), food assistance (SNAP), cash assistance (TANF) benefits in another state in the month of May or expect to receive benefits in the month of June?
	
	public void Click_HA_FA_CA_Y() {
		
		driver.findElement(tglbtn_HA_FA_CA_Y_xpath).click();
	}

	public void Click_HA_FA_CA_N() {
		
		driver.findElement(tglbtn_HA_FA_CA_N_xpath).click();
	}
	
	//Did the household get more than $20 in verified HEAP (fuel assistance) benefit in this month or in the previous 12 months?
	
	public void Click_HEAP_Y() {
		
		driver.findElement(tglbtn_HEAP_Y_xpath).click();
	}

	public void Click_HEAP_N() {
		
		driver.findElement(tglbtn_HEAP_N_xpath).click();
	}
	
    public void ClickNext() {

		driver.findElement(btn_Next_xpath).click();
	}
}
