package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import resources.base;

public class HHInformation_HealthPO extends base{
	
	public WebDriver driver;

	By btn_StartHHI_xpath = By.xpath("(//button[@type='button'])[4]");
	By tglbtn_Blind_xpath_Y = By.xpath("//div[1]/div/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label");
	By tglbtn_Blind_xpath_N = By.xpath("//div[1]/div/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label");
	By tglbtn_LTC_xpath_Y = By.xpath("//div[2]/div/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label");
	By tglbtn_LTC_xpath_N = By.xpath("//div[2]/div/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label");
	By tglbtn_MediBenft_xpath_Y = By.xpath("//div[5]/div/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label");
	By tglbtn_MediBenft_xpath_N = By.xpath("//div[5]/div/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label");
	By tglbtn_Preg_xpath_Y = By.xpath("//div[6]/div/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label");
	By tglbtn_Preg_xpath_N = By.xpath("//div[6]/div/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label");
	By chkbx_Blind_HHM1_xpath = By.xpath("//lightning-input/div/span/label/span");
	By btn_Next_xpath= By.xpath("//button[contains(text(),'Next')]");
	
	public HHInformation_HealthPO(WebDriver driver) {
		// TODO Auto-generated constructor stub

		this.driver = driver;
	}
	
	public void ClickStart_HHInfo() throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,700);");
		Thread.sleep(1000);
		driver.findElement(btn_StartHHI_xpath).click();
	}
	//Is anyone in the household blind or disabled?
	
	public void Click_Blind_Y() throws InterruptedException{
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,250);");
		Thread.sleep(1000);
		driver.findElement(tglbtn_Blind_xpath_Y).click();
		
	}
    public void Click_Blind_N() throws InterruptedException{
    	
    	JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,250);");
		Thread.sleep(1000);
    	driver.findElement(tglbtn_Blind_xpath_N).click();
	}
    
    public void Click_Blind_HHM1() {
    	
    	driver.findElement(chkbx_Blind_HHM1_xpath).click();
    	
    }
	//Does anyone in the household need assistance paying for the cost of Long-Term Care services?
    
	public void Click_LTC_Y(){
		
		driver.findElement(tglbtn_LTC_xpath_Y).click();
		
	}
    public void Click_LTC_N(){
    	
    	driver.findElement(tglbtn_LTC_xpath_N).click();
	}
    
	//Does anyone in this household currently or previously have Medicare benefits, is conditionally enrolled in Medicare Part A, or will be entitled to Medicare in the next few months?
	 
	public void Click_MediCare_Benfit_Y(){
		
		driver.findElement(tglbtn_MediBenft_xpath_Y).click();
		
	}
    public void Click_MediCare_Benfit_N(){
    	
    	driver.findElement(tglbtn_MediBenft_xpath_N).click();
	}
    
    //Is anyone in this household pregnant or was pregnant in the last three months?
	public void Click_Pregnancy_Y(){
		
		driver.findElement(tglbtn_Preg_xpath_Y).click();
		
	}
    public void Click_Pregnancy_N(){
    	
    	driver.findElement(tglbtn_Preg_xpath_N).click();
	}
    
    public void ClickNext() {

		driver.findElement(btn_Next_xpath).click();
	}
}
