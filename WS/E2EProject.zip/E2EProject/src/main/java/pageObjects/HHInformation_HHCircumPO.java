package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import resources.base;

public class HHInformation_HHCircumPO extends base{
	
	public WebDriver driver;

	By btn_Next_xpath= By.xpath("//button[contains(text(),'Next')]");
	By tglbtn_Parole_Y_xpath= By.xpath("//div/div[1]/c-ssp-household-information-question/div/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span]");
	By tglbtn_Parole_N_xpath= By.xpath("//div/div[1]/c-ssp-household-information-question/div/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn_SNAPorTANF_Bnfit_Y_xpath= By.xpath("//div/div[2]/c-ssp-household-information-question/div/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_SNAPorTANF_Bnfit_N_xpath= By.xpath("//div/div[2]/c-ssp-household-information-question/div/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn_SNAPorTANF_Vltn_Y_xpath= By.xpath("//div/div[3]/c-ssp-household-information-question/div/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_SNAPorTANF_Vltn_N_xpath= By.xpath("//div/div[3]/c-ssp-household-information-question/div/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn_FarmWorker_Y_xpath= By.xpath("//div/div[4]/c-ssp-household-information-question/div/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_FarmWorker_N_xpath= By.xpath("//div/div[4]/c-ssp-household-information-question/div/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn_Lessthan25_Y_xpath= By.xpath("//div/div[5]/c-ssp-household-information-question/div/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_Lessthan25_N_xpath= By.xpath("//div/div[5]/c-ssp-household-information-question/div/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn_EnrlSchl_Y_xpath= By.xpath("//div/div[6]/c-ssp-household-information-question/div/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_EnrlSchl_N_xpath= By.xpath("//div/div[6]/c-ssp-household-information-question/div/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn_FC18_Y_xpath= By.xpath("//div/div[7]/c-ssp-household-information-question/div/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_FC18_N_xpath= By.xpath("//div/div[7]/c-ssp-household-information-question/div/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn_SNAP_EandT_Y_xpath= By.xpath("//div/div[8]/c-ssp-household-information-question/div/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_SNAP_EandT_N_xpath= By.xpath("//div/div[8]/c-ssp-household-information-question/div/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By chkbx_EnrlSchl_HHM1_xpath= By.xpath("//div[6]/c-ssp-household-information-question/div/div/c-ssp-base-component-input-checkbox[1]/div/div/lightning-input/div/span/label/span[1]");
	By chkbx_FarmWorker_HHM1_xpath = By.xpath("//div[4]/c-ssp-household-information-question/div/div/c-ssp-base-component-input-checkbox[1]/div/div/lightning-input/div/span/label/span[1]");
	
	
	public HHInformation_HHCircumPO(WebDriver driver) {
		// TODO Auto-generated constructor stub

		this.driver = driver;
	}
	
	//Is anyone in this household fleeing a felony conviction or violating probation or parole?
	public void Click_Violating_Parole_Y() throws InterruptedException {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,250);");
		Thread.sleep(1000);
		driver.findElement(tglbtn_Parole_Y_xpath).click();
	}
	
	public void Click_Violating_Parole_N() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,250);");
		Thread.sleep(1000);
		driver.findElement(tglbtn_Parole_N_xpath).click();
	}
	//Has anyone in this household been convicted of giving wrong information about who they are or where they live to get or try to get SNAP and/or TANF benefits in more than one household at a time?
    
	public void Click_SNAPorTANF_Benefit_Y() {
		
		driver.findElement(tglbtn_SNAPorTANF_Bnfit_Y_xpath).click();
	}
	
	public void Click_SNAPorTANF_Benefit_N() {

		driver.findElement(tglbtn_SNAPorTANF_Bnfit_N_xpath).click();
	}
	
	//Has anyone in this household been convicted of a SNAP and/or TANF program violation?
	
	public void Click_SNAPorTANF_Violation_Y() {
		
		driver.findElement(tglbtn_SNAPorTANF_Vltn_Y_xpath).click();
	}
	
	public void Click_SNAPorTANF_Violation_N() {

		driver.findElement(tglbtn_SNAPorTANF_Vltn_N_xpath).click();
	}
	
	//Is anyone in this household a migrant or seasonal farmworker?
	
	public void Click_Seasonal_FW_Y() {
		
		driver.findElement(tglbtn_FarmWorker_Y_xpath).click();
	}
	
	public void Click_Seasonal_FW_N() {

		driver.findElement(tglbtn_FarmWorker_N_xpath).click();
	}

	public void Click_Seasonal_FW_HHM1() {

		driver.findElement(chkbx_FarmWorker_HHM1_xpath).click();
	}
	
	//Will the household receive less than $25 in the next 10 days?
	
	public void Click_Rec_lessthan25_FW_Y() {
		
		driver.findElement(tglbtn_Lessthan25_Y_xpath).click();
	}
	
	public void Click_Rec_lessthan25_FW_N() {

		driver.findElement(tglbtn_Lessthan25_N_xpath).click();
	}
	
    //Is anyone in this household currently enrolled in school?
	
	public void Click_Enrollin_School_Y() {
		
		driver.findElement(tglbtn_EnrlSchl_Y_xpath).click();
	}
	
	public void Click_Enrollin_School_N() {

		driver.findElement(tglbtn_EnrlSchl_N_xpath).click();
	}
	
	public void Click_Enrollin_School_HHM1() {

		driver.findElement(chkbx_EnrlSchl_HHM1_xpath).click();
	}
	
	//Was anyone in foster care when they turned 18?
	
	public void Click_FosterCare_Y() {
		
		driver.findElement(tglbtn_FC18_Y_xpath).click();
	}
	
	public void Click_FosterCare_N() {

		driver.findElement(tglbtn_FC18_N_xpath).click();
	}
	//Is anyone in the household currently participating in the SNAP Employment & Training (E&T) program?
	
	public void Click_SNAP_EmployandTrain_Y() {
		
		driver.findElement(tglbtn_SNAP_EandT_Y_xpath).click();
	}
	
	public void Click_SNAP_EmployandTrain_N() {

		driver.findElement(tglbtn_SNAP_EandT_N_xpath).click();
	}
	
    public void ClickNext() {

		driver.findElement(btn_Next_xpath).click();
	}
}
