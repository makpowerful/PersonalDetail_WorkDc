package pageObjects;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import resources.ExcelData;

public class LoginScreenPO {

	public WebDriver driver;

	By lkn_Login_xpath = By.xpath("//ul/li[6]/div/a");
	// a[contains(text(),'Sign In')] (//a[contains(@href,
	// 'javascript:void(0);')])[3]
	By txt_Usrnm_xpath = By.xpath("//div[3]/div/div/lightning-input/div/input");
	By txt_Passwd_xpath = By.xpath("//div[4]/div/div/lightning-input/div/input");
	By btn_login_xpath = By.xpath("//button[contains(text(),'Sign In')]");
	By btn_Yes_xpath = By.xpath("//button[contains(text(),'Yes')]");
	By btn_AccpetTerms_xpath = By.xpath("//button[@value='Accept']");
	
	ExcelData excelData= new ExcelData();
	ArrayList<String> al= new ArrayList<String>();

	public LoginScreenPO(WebDriver driver) {
		// TODO Auto-generated constructor stub

		this.driver = driver;
	}

	public void ClickLoginlink() throws InterruptedException {

		//WebDriverWait wait = new WebDriverWait(driver, 10);
		// WebElement passwordElement =
		// wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#Passwd")));
		// passwordElement.click();
		// wait.until(ExpectedConditions.visibilityOfElementLocated(lkn_Login_xpath).click();
		// String button = driver.findElement(lkn_Login_xpath);
		// driver.implicitly_wait(10);
		// ActionChains(driver).move_to_element(button).click(button).perform()
		// wait.Until(Ex.ElementIsVisibleAndEnabled(driver.findElement(lkn_Login_xpath)));
		/*wait.until(ExpectedConditions.visibilityOfElementLocated(lkn_Login_xpath));
		Actions act = new Actions(driver);
		act.moveToElement(driver.findElement(lkn_Login_xpath)).click().build().perform();
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);*/
		driver.findElement(lkn_Login_xpath).click();
		Thread.sleep(6000);
	}

	public void EnterUsername(String username) throws IOException {

		driver.findElement(txt_Usrnm_xpath).sendKeys(username);

	}
	
	public void EnterUN() {

		driver.findElement(txt_Usrnm_xpath).sendKeys("stateofmainecitizenjacksmith@deloitte.com");

	}
	
	public void EnterPass() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,800);");
		driver.findElement(txt_Passwd_xpath).sendKeys("dELOITTE.2*");

	}

	public void Enterpassword(String password) {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,800);");
		driver.findElement(txt_Passwd_xpath).sendKeys(password);
	}
	
	public void ClickLogin() {
		
		driver.findElement(btn_login_xpath).click();
	}
	
	public void ClickYes_UseofWbste() {
		
		/*
		 * WebDriverWait wait = new WebDriverWait(driver, 10);
		 * wait.until(ExpectedConditions.visibilityOfElementLocated(btn_Yes_xpath));
		 * Actions act = new Actions(driver);
		 * act.moveToElement(driver.findElement(btn_Yes_xpath)).click().build().perform(
		 * ); driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		 */
		driver.findElement(btn_Yes_xpath).click();
	}
	
	public void ClickAccept() {
		
		driver.findElement(btn_AccpetTerms_xpath).click();
	}

}
