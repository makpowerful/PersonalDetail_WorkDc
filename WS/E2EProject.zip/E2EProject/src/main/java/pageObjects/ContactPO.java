package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import resources.base;

public class ContactPO extends base{
	
	public WebDriver driver;

	By btn_StartHHM1_xpath = By.xpath("//div/div[2]/span");
	By rdbtn_Email_xpath = By.xpath("//span[2]");
	By btn_Next_xpath= By.xpath("//button[contains(text(),'Next')]");
	By tglbtn_SameAdd_xpath = By.xpath("//div[4]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span/label");
	By btn_StartHHM2_xpath= By.xpath("//li[2]/div/div[2]/span");
	By chk_SameAddasPri_xpath = By.xpath("//label/span");
	By pck_PrefLangHHM2_xpath= By.xpath("//div[6]/div/c-ssp-base-component-input-picklist/div/select");
	
	public ContactPO(WebDriver driver) {
		// TODO Auto-generated constructor stub

		this.driver = driver;
	}
	
	public void ClickStartHHM1() throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,250);");
		Thread.sleep(1000);
		driver.findElement(btn_StartHHM1_xpath).click();
	}
	
    public void ClickEmailRdbtn() throws InterruptedException {
    	
    	JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,850);");
		Thread.sleep(1000);
		driver.findElement(rdbtn_Email_xpath).click();
	}
    
    public void ClickNext() {

		driver.findElement(btn_Next_xpath).click();
	}
    
    public void ClickSameAddYes() throws InterruptedException {
		
    	JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,850);");
		Thread.sleep(1000);
		driver.findElement(tglbtn_SameAdd_xpath).click();
	}
    
    public void ClickStartHHM2() throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,450);");
		Thread.sleep(1000);
		driver.findElement(btn_StartHHM2_xpath).click();
	}
    
    public void ClickSameAsPriChk() throws InterruptedException
	{
		driver.findElement(chk_SameAddasPri_xpath).click();
		Thread.sleep(500);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,850);");
		Thread.sleep(1000);
	}
    
    public void SelectPrefLangHHM2() {
    	
    	Select pf = new Select(driver.findElement(pck_PrefLangHHM2_xpath));
    	pf.selectByVisibleText("English");
    }
}
