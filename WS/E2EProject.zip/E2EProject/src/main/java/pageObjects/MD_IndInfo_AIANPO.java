package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import resources.base;

public class MD_IndInfo_AIANPO extends base{
	
	public WebDriver driver;

	By btn_Next_xpath= By.xpath("//button[contains(text(),'Next')]");
	By tglbtn_MemOfTribe_Y_xpath= By.xpath("//span/label");
	By chkbx_Tribe_HM_xpath= By.xpath("//fieldset/div[1]/span[1]/label/span[1]");
	By tglbtn_RecServ_xpath= By.xpath("//div[3]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label");
	By tglbtn_ERecServ_xpath= By.xpath("//div[2]/div[3]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	
	public MD_IndInfo_AIANPO(WebDriver driver) {
		// TODO Auto-generated constructor stub

		this.driver = driver;
	}
	
	public void Click_IsInd_MemOfTribe_Y() throws InterruptedException {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,250);");
		Thread.sleep(1000);
		driver.findElement(tglbtn_MemOfTribe_Y_xpath).click();
	}
	
	public void Click_TypeOfTribe() {
		
		driver.findElement(chkbx_Tribe_HM_xpath).click();
		
	}
	
	public void Click_EverRecServ() {
		
		driver.findElement(tglbtn_RecServ_xpath).click();
		
	}
	
	public void Click_EligRecSer() {
		
		driver.findElement(tglbtn_ERecServ_xpath).click();
		
	}
	
    public void ClickNext() {

		driver.findElement(btn_Next_xpath).click();
	}

}
