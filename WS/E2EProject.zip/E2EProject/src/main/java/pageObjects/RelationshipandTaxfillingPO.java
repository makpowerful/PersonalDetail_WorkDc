package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import resources.base;

public class RelationshipandTaxfillingPO extends base{
	
	public WebDriver driver;

	By btn_StartHHM1_xpath = By.xpath("//div[6]/c-ssp-member-section-card/div/div[2]/div/ul/li[1]/div/div[2]/img");
	By btn_StartHHM2_xpath= By.xpath("//div[6]/c-ssp-member-section-card/div/div[2]/div/ul/li[2]/div/div[2]/img");
	By btn_StartHHM3_xpath= By.xpath("//div[6]/c-ssp-member-section-card/div/div[2]/div/ul/li[3]/div/div[2]/img");
	By thpl1_HHM1_xpath= By.xpath("//li[1]/div/div/div[3]/div/c-ssp-type-ahead-picklist/div/lightning-input/div/input");
	By thpl1_HHM2_xpath= By.xpath("//li[2]/div/div/div[3]/div/c-ssp-type-ahead-picklist/div/lightning-input/div/input");
	By thpl1_HHM3_xpath= By.xpath("//li[3]/div/div/div[3]/div/c-ssp-type-ahead-picklist/div/lightning-input/div/input");
	By tglbtn1_HHM1_xpath= By.xpath("//div[4]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn2_HHM1_xpath= By.xpath("//div[5]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn3_HHM1_xpath= By.xpath("//div[6]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn1_HHM2_xpath= By.xpath("//div[4]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn2_HHM2_xpath= By.xpath("//div[5]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn3_HHM2_xpath= By.xpath("//div[6]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By thpl2_HHM1_xpath= By.xpath("//li[2]/div/div/div[3]/div/c-ssp-type-ahead-picklist/div/lightning-input/div/input");
	By btn_Next_xpath= By.xpath("//button[contains(text(),'Next')]");
	By val_Parent_xpath= By.xpath("//c-ssp-type-ahead-picklist/div/ul/li[3]/div");
	By val_Spouse_xpath= By.xpath("//c-ssp-type-ahead-picklist/div/ul/li/div");
	By rdbtn_HHM1tax_xpath= By.xpath("//span[2]");
	By tglbtn1_HHM1tax_xpath= By.xpath("//div/div/span/label");
	By chk_HHM1tax_xpath= By.xpath("//lightning-checkbox-group/fieldset/div/span/label/span");
	
	public RelationshipandTaxfillingPO(WebDriver driver) {
		// TODO Auto-generated constructor stub

		this.driver = driver;
	}
	
	public void ClickStartHHM1() throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,650);");
		Thread.sleep(1000);
		driver.findElement(btn_StartHHM1_xpath).click();
	}
	
	public void ClickStartHHM2() throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,700);");
		Thread.sleep(1000);
		driver.findElement(btn_StartHHM2_xpath).click();
	}
	
	public void ClickStartHHM3() throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,750);");
		Thread.sleep(1000);
		driver.findElement(btn_StartHHM3_xpath).click();
	}
	
	public void SelectRelatnHHM1toHHM3() throws InterruptedException {
		
		driver.findElement(thpl1_HHM1_xpath).click();
		driver.findElement(thpl1_HHM1_xpath).clear();
		driver.findElement(thpl1_HHM1_xpath).sendKeys("Parent");
		Thread.sleep(800);
		driver.findElement(val_Parent_xpath).click();
		Thread.sleep(800);
		
	}
	
    public void SelectRelatnHHM2toHHM3() throws InterruptedException {
		
		driver.findElement(thpl1_HHM2_xpath).click();
		driver.findElement(thpl1_HHM2_xpath).clear();
		driver.findElement(thpl1_HHM2_xpath).sendKeys("Parent");
		Thread.sleep(800);
		driver.findElement(val_Parent_xpath).click();
		Thread.sleep(800);
		
	}
	
	public void SelectYLegalGaurdn() throws InterruptedException {

		driver.findElement(tglbtn1_HHM1_xpath).click();
		Thread.sleep(800);

	}
	
	public void SelectYPriCartaker() throws InterruptedException {

		driver.findElement(tglbtn2_HHM1_xpath).click();
		Thread.sleep(800);

	}
	
	public void SelectYMaintnHome() throws InterruptedException {

		driver.findElement(tglbtn3_HHM1_xpath).click();
		Thread.sleep(800);

	}

	public void SelectNLegalGaurdn() throws InterruptedException {

		driver.findElement(tglbtn1_HHM2_xpath).click();
		Thread.sleep(800);

	}
	
	public void SelectNPriCartaker() throws InterruptedException {

		driver.findElement(tglbtn2_HHM2_xpath).click();
		Thread.sleep(800);

	}
	
	public void SelectNMaintnHome() throws InterruptedException {

		driver.findElement(tglbtn3_HHM2_xpath).click();
		Thread.sleep(800);

	}
	
	public void SelectRelatnHHM1toHHM2() throws InterruptedException {

		driver.findElement(thpl2_HHM1_xpath).click();
		driver.findElement(thpl2_HHM1_xpath).clear();
		driver.findElement(thpl2_HHM1_xpath).sendKeys("Spouse");
		Thread.sleep(800);
		driver.findElement(val_Spouse_xpath).click();
		Thread.sleep(800);

	}
	
	public void SelectMarriedFilngtaxHHM1() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,400);");
		Thread.sleep(1000);
		driver.findElement(rdbtn_HHM1tax_xpath).click();
		Thread.sleep(800);

	}
	
	public void SelectPriCaretaxHHM1() throws InterruptedException {

		driver.findElement(tglbtn1_HHM1tax_xpath).click();
		Thread.sleep(800);

	}
	
	public void SelectDependOntaxHHM1() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,800);");
		Thread.sleep(1000);
		driver.findElement(chk_HHM1tax_xpath).click();
		Thread.sleep(800);

	}
	
    public void ClickNext() {

		driver.findElement(btn_Next_xpath).click();
	}
}
