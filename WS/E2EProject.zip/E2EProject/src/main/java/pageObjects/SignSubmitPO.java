package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import resources.base;

public class SignSubmitPO extends base{
	
	public WebDriver driver;

	By btn_SignS_Start_xpath = By.xpath("(//button[@type='button'])[6]");
	By btn_SBA_xpath= By.xpath("//button[contains(text(),'Submit Benefits Application')]");
	By btn_IAgree_xpath= By.xpath("//button[contains(text(),'I agree')]");
	By lnk_ASOU_xpath = By.xpath("//a[contains(text(),'Read and agree to Application Statement of Understanding')]");
	By lbl_ASOU_xpath = By.xpath("//span/div/div/ul/li");
	By lnk_SNAPRR_xpath = By.xpath("//a[contains(text(),'Read and agree to SNAP Rights & Responsibilities')]");
	By lbl_SNAPRR_xpath = By.xpath("//span/div[2]");
	By lnk_TANFFC_xpath = By.xpath("//a[contains(text(),'Read and agree to TANF Family Contract')]");
	By lbl_TANFFC_xpath = By.xpath("//span/div");
	By txt_FN_xpath = By.xpath("//div[1]/div/c-ssp-base-component-input-text/div/div/lightning-input/div/input");
	By txt_MN_xpath = By.xpath("//div[2]/div/c-ssp-base-component-input-text/div/div/lightning-input/div/input");
	By txt_LN_xpath = By.xpath("//div[13]/div[1]/div/c-ssp-base-component-input-text/div/div/lightning-input/div/input");
	By btn_CloseIcon_xpath = By.xpath("//button/lightning-primitive-icon");
	By pcklst_Suffix_xpath= By.xpath("//select");
	
	public SignSubmitPO(WebDriver driver) {
		// TODO Auto-generated constructor stub

		this.driver = driver;
	}
	
	public void ClickSignSubmitTile_Start() throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,1150);");
		Thread.sleep(1000);
		driver.findElement(btn_SignS_Start_xpath).click();
	}
	
	public void Click_RandA_ASOU() throws InterruptedException {
		
		driver.findElement(lnk_ASOU_xpath).click();
		Thread.sleep(800);
		driver.findElement(lbl_ASOU_xpath).click();
		Thread.sleep(800);
		Scrollend();
		driver.findElement(btn_IAgree_xpath).click();
	}
	
	public void Click_RandA_SNAPRR() throws InterruptedException {
		
		driver.findElement(lnk_SNAPRR_xpath).click();
		Thread.sleep(800);
		driver.findElement(lbl_SNAPRR_xpath).click();
		Thread.sleep(800);
		Scrollend();
		driver.findElement(btn_IAgree_xpath).click();
	}
	
	public void Click_RandA_TANFFC() throws InterruptedException {
		
		driver.findElement(lnk_TANFFC_xpath).click();
		Thread.sleep(800);
		driver.findElement(lbl_TANFFC_xpath).click();
		Thread.sleep(800);
		Scrollend();
		driver.findElement(btn_IAgree_xpath).click();
	}
	
	public void EnterFN(String fn) {
		
		driver.findElement(txt_FN_xpath).sendKeys(fn);
	}

	public void EnterMN(String mn) {
		
		driver.findElement(txt_MN_xpath).sendKeys(mn);
	}
	
	public void EnterLN(String ln) {
		
		driver.findElement(txt_LN_xpath).sendKeys(ln);
	}
	
	public void Select_Suffix_II(){
		
		Select suf= new Select(driver.findElement(pcklst_Suffix_xpath));
		suf.selectByVisibleText("II");
		
	}
	
    public void Click_SBA() {

		driver.findElement(btn_SBA_xpath).click();
	}
}
