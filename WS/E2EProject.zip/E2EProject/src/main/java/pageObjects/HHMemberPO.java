package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import resources.base;

public class HHMemberPO extends base{
	
	public WebDriver driver;

	By btn_StartHHM_xpath = By.xpath("(//button[@type='button'])[2]");
	By btn_StartHHM1_xpath = By.xpath("//button[@type='button']");
	By txt_HHM_FN_xpath = By.xpath("//div[1]/c-ssp-base-component-input-text/div/div/lightning-input/div[1]/input");
	By chkbx_HHM_MN_xpath = By.xpath("//label/span");
	By txt_HHM_MN_xpath = By.xpath("//div[2]/c-ssp-base-component-input-text/div/div/lightning-input/div/input");
	By txt_HHM_LN_xpath = By.xpath("//div[3]/div/c-ssp-base-component-input-text/div/div/lightning-input/div/input");
	By pck_Gender_xpath = By.xpath("//div[4]/div/c-ssp-base-component-input-picklist/div/select");
	By tglbtn_Does_SSN_Y_xpath = By.xpath("//div/div/span/label");
	By tglbtn_Does_SSN_N_xpath = By.xpath("//div/div/span[2]/label");
	By txt_SSN_xpath = By.xpath("//div[2]/div[2]/div/div/div/c-ssp-base-component-input-text/div/div/lightning-input/div/input");
	By txt_CN_SSN_xpath = By.xpath("//div[2]/div/c-ssp-base-component-input-text/div/div/lightning-input/div/input");
	By tglbtn_USCtzn_Y_xpath = By.xpath("//div[2]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span/label/span");
	By tglbtn_USMiltry_N_xpath = By.xpath("//div[3]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label");
	By tglbtn_Resi_Maine_Y_xpath = By.xpath("//div[4]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span/label");
	By chkbx_Rac_AmeriAlskn_xpath = By.xpath("//fieldset/div/span/label/span");
	By chkbx_Rac_Asian_xpath = By.xpath("//lightning-checkbox-group/fieldset/div/span[2]/label/span");
	By tglbtn_Hisplati_xpath = By.xpath("//c-ssp-add-house-hold-member/div/div[2]/div[4]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label");
	By pck_MarrStats_xpath = By.xpath("//div[5]/c-ssp-base-component-input-picklist/div/select");
	By chkbx_Prg_MCandCC_xpath = By.xpath("//c-ssp-base-component-multiline-input-checkbox[1]/div/div/div/label/input"); 
	By chkbx_Prg_TANFHOH_xpath = By.xpath("(//input[@name=''])[4]"); 
	By chkbx_Prg_TANF_xpath = By.xpath("(//input[@name=''])[5]"); 
	By chkbx_SubPrg_MCandCCHOH_xpath = By.xpath("(//input[@name=''])[6]"); 
	By chkbx_SubPrg_FPSHOH_xpath = By.xpath("(//input[@name=''])[7]"); 
	By chkbx_SubPrg_MSPHOH_xpath = By.xpath("(//input[@name=''])[8]"); 
	By chkbx_SubPrg_MCandCC_xpath = By.xpath("(//input[@name=''])[7]"); 
	By chkbx_SubPrg_FPS_xpath = By.xpath("(//input[@name=''])[8]"); 
	By chkbx_SubPrg_MSP_xpath = By.xpath("(//input[@name=''])[9]"); 
	By lbl_PrgSel_xpath = By.xpath("//c-ssp-add-house-hold-member/div/div[2]");
	By lbl_belowHis_xpath = By.xpath("//div[4]/div/div/p");
	By btn_Save_xpath = By.xpath("//button[contains(text(),'Save')]");
	By btn_AddHHMem_xpath= By.xpath("//button[contains(text(),'Add Member')]");
	By dt_DOB_xpath = By.xpath("//div/div/input");
	By rdbtn_ApplidSSN_xpath = By.xpath("//fieldset/div/span[2]/label/span");
	By btn_Next_xpath = By.xpath("//button[contains(text(),'Next')]");
	
	public HHMemberPO(WebDriver driver) {
		// TODO Auto-generated constructor stub

		this.driver = driver;
	}
	
	public void ClickStartHHM() throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,250);");
		Thread.sleep(1000);
		driver.findElement(btn_StartHHM_xpath).click();
	}
	
	public void ClickStartHHM1() throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,250);");
		driver.findElement(btn_StartHHM1_xpath).click();
	}
	
	public void EnterFN(String fn) throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,250);");
		driver.findElement(txt_HHM_FN_xpath).clear();
		driver.findElement(txt_HHM_FN_xpath).sendKeys(fn);
		
	}
	
    public void EnterMN(String mn) throws InterruptedException {
		
		driver.findElement(chkbx_HHM_MN_xpath).click();
		Thread.sleep(1000);
		driver.findElement(txt_HHM_MN_xpath).sendKeys(mn);
	}
    
    public void EnterLN(String ln) throws InterruptedException
	{
		driver.findElement(txt_HHM_LN_xpath).clear();
		driver.findElement(txt_HHM_LN_xpath).sendKeys(ln);
		
	}
    
    public void SelectGender_M() {
    	
    	Select Gen = new Select(driver.findElement(pck_Gender_xpath));
    	Gen.selectByIndex(1);
    	
    }
    
    public void SelectGender_F() {
    	
    	Select Gen = new Select(driver.findElement(pck_Gender_xpath));
    	Gen.selectByIndex(2);
    	
    }
    
    public void EnterDob(String dob) {
    
    	driver.findElement(dt_DOB_xpath).sendKeys(dob);
    }
    
    public void Select_Does_HHMhave_SSN_Y()	{
    	
		driver.findElement(tglbtn_Does_SSN_Y_xpath).click();
		
	}
    public void Select_Does_HHMhave_SSN_N()	{
    	
		driver.findElement(tglbtn_Does_SSN_N_xpath).click();
		
	} 
    public void Select_Doesnot_SSN_NtApplied() {
    	
    	driver.findElement(rdbtn_ApplidSSN_xpath).click();
    }
    
    public void Enter_SSN(String ssn) throws InterruptedException {
    	
		driver.findElement(txt_SSN_xpath).sendKeys(ssn);
		
	}
    public void Enter_CN_SSN(String cssn) throws InterruptedException {
    	
		driver.findElement(txt_CN_SSN_xpath).sendKeys(cssn);
		
	}
    
    public void Select_US_Citizen_Y(){
    	
		driver.findElement(tglbtn_USCtzn_Y_xpath).click();
		
	}
    public void Select_US_Miltary_N(){
    	
		driver.findElement(tglbtn_USMiltry_N_xpath).click();
		
	}
    public void Select_Resid_Maine_Y(){
    	
		driver.findElement(tglbtn_Resi_Maine_Y_xpath).click();
		
	}
    public void Select_Race_AmerAlasK(){
    	
		driver.findElement(chkbx_Rac_AmeriAlskn_xpath).click();
		
	}
    
    public void Select_Race_Asian(){
    	
		driver.findElement(chkbx_Rac_Asian_xpath).click();
		
	}
    public void Select_HispLatino(){
    	
		driver.findElement(tglbtn_Hisplati_xpath).click();
		driver.findElement(lbl_belowHis_xpath).click();
	}
    
    public void Select_MaritalStatus_Married(){
    	
		Select ms = new Select(driver.findElement(pck_MarrStats_xpath));
		ms.selectByVisibleText("Married");
		driver.findElement(lbl_PrgSel_xpath).click();
		
	}
    
    public void Select_MaritalStatus_Single(){
    	
		Select ms = new Select(driver.findElement(pck_MarrStats_xpath));
		ms.selectByVisibleText("Single");
		driver.findElement(lbl_PrgSel_xpath).click();
	}
    
    public void Select_Prg_MainCareCubCare(){
    	
    	//JavascriptExecutor js = (JavascriptExecutor) driver;
		//js.executeScript("scroll(0,1400);");
		driver.findElement(chkbx_Prg_MCandCC_xpath).click();
		
	}
    public void Select_Prg_TANFHOH(){
    	
		driver.findElement(chkbx_Prg_TANFHOH_xpath).click();
		
	}
    public void Select_Prg_TANF(){
    	
		driver.findElement(chkbx_Prg_TANF_xpath).click();
		
	}
    public void Select_SubPrg_MainCareCubCareHOH(){
    	
		driver.findElement(chkbx_SubPrg_MCandCCHOH_xpath).click();
		
	}
    public void Select_SubPrg_FamliyPlanningSerHOH(){
    	
		driver.findElement(chkbx_SubPrg_FPSHOH_xpath).click();
		
	}
    public void Select_SubPrg_MSPHOH(){
    	
		driver.findElement(chkbx_SubPrg_MSPHOH_xpath).click();
		
	}
    
    public void Select_SubPrg_MainCareCubCare(){
    	
		driver.findElement(chkbx_SubPrg_MCandCC_xpath).click();
		
	}
    public void Select_SubPrg_FamliyPlanningSer(){
    	
		driver.findElement(chkbx_SubPrg_FPS_xpath).click();
		
	}
    public void Select_SubPrg_MSP(){
    	
		driver.findElement(chkbx_SubPrg_MSP_xpath).click();
		
	}
    
    public void ClickSave() {
    	
    	driver.findElement(btn_Save_xpath).click();
    	
    }
    
    public void ClickAddHHMem() throws InterruptedException {
    	
    	JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,350);");
		Thread.sleep(700);
    	driver.findElement(btn_AddHHMem_xpath).click();
    }
    
    public void ClickNext() throws InterruptedException {
    	
    	//JavascriptExecutor js = (JavascriptExecutor) driver;
		//js.executeScript("scroll(0,600);");
		//Thread.sleep(1000);
    	driver.findElement(btn_Next_xpath).click();
    	
    }
}
