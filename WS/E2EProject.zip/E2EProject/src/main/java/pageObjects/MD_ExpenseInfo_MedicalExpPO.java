package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import resources.base;

public class MD_ExpenseInfo_MedicalExpPO extends base{
	
	public WebDriver driver;

	By btn_Next_xpath= By.xpath("//button[contains(text(),'Next')]");
	By btn_Save_xpath= By.xpath("//button[contains(text(),'Save')]");
	By btn_Month_xpath= By.xpath("//label/span");
	
	
	public MD_ExpenseInfo_MedicalExpPO(WebDriver driver) {
		// TODO Auto-generated constructor stub

		this.driver = driver;
	}
	
	public void Select_MedicalBillMonth() {
		
		driver.findElement(btn_Month_xpath).click();
	}
	
	
    public void ClickNext() {

		driver.findElement(btn_Next_xpath).click();
	}

    public void ClickSave() {

		driver.findElement(btn_Save_xpath).click();
	}
}
