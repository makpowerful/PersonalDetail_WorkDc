package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import resources.base;

public class HealthCareCoverPO extends base{
	
	public WebDriver driver;

	By btn_HealthC_Start_xpath = By.xpath("(//button[@type='button'])[5]");
	By btn_Next_xpath= By.xpath("//button[contains(text(),'Next')]");
	By tglbtn_Enrol_HC_N_xpath = By.xpath("//c-ssp-health-coverage-selection/div/div[1]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label");
	By tglbtn_NotEnrol_HC_N_xpath = By.xpath("//c-ssp-health-coverage-selection/div/div[2]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label");
	
	
	public HealthCareCoverPO(WebDriver driver) {
		// TODO Auto-generated constructor stub

		this.driver = driver;
	}
	
	public void ClickHealthCTile_Start() throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,1150);");
		Thread.sleep(1000);
		driver.findElement(btn_HealthC_Start_xpath).click();
	}
	
	public void Click_IsEnrolled_HC_N() {
		
		driver.findElement(tglbtn_Enrol_HC_N_xpath).click();

	}
	
	public void Click_IsNotEnrolled_HC_N() {
		
		driver.findElement(tglbtn_NotEnrol_HC_N_xpath).click();

	}
    
    public void ClickNext() {

		driver.findElement(btn_Next_xpath).click();
	}
}
