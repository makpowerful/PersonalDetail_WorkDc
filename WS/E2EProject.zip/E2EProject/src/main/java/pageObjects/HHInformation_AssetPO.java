package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import resources.base;

public class HHInformation_AssetPO extends base{
	
	public WebDriver driver;

	By btn_Next_xpath= By.xpath("//button[contains(text(),'Next')]");
	By tglbtn_IDA_Y_xpath= By.xpath("//div[1]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_IDA_N_xpath= By.xpath("//div[1]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn_StckorBond_Y_xpath= By.xpath("//div[2]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_StckorBond_N_xpath= By.xpath("//div[2]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn_Liquid_Y_xpath= By.xpath("//div[3]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_Liquid_N_xpath= By.xpath("//div[3]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn_Vehicle_Y_xpath= By.xpath("//div[4]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_Vehicle_N_xpath= By.xpath("//div[4]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn_RealEstate_Y_xpath= By.xpath("//div[5]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_RealEstate_N_xpath= By.xpath("//div[5]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn_LfeIns_Y_xpath= By.xpath("//div[6]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_LfeIns_N_xpath= By.xpath("//div[6]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By chkbx_IDA_HHM1_xpath= By.xpath("//div[1]/div/div/c-ssp-base-component-input-checkbox[1]/div/div/lightning-input/div/span/label/span");
	
	
	public HHInformation_AssetPO(WebDriver driver) {
		// TODO Auto-generated constructor stub

		this.driver = driver;
	}
	
	//Does anyone in this household have a checking account, savings account, certificate of deposit, individual development account (IDA), or nursing facility resident account?
	
	
	public void Click_CA_SA_IDA_Y() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,250);");
		Thread.sleep(1000);
		driver.findElement(tglbtn_IDA_Y_xpath).click();
	}
	
	public void Click_CA_SA_IDA_N() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,250);");
		Thread.sleep(1000);
		driver.findElement(tglbtn_IDA_N_xpath).click();
	}
	
	public void Click_CA_SA_IDA_HHM1() {
		
		driver.findElement(chkbx_IDA_HHM1_xpath).click();
	}
	
	//Does anyone in this household have investments such as stocks or bonds?
	
	public void Click_StocksOrBonds_Y() {
		
		driver.findElement(tglbtn_StckorBond_Y_xpath).click();
	}
	
	public void Click_StocksOrBonds_N() {
		
		driver.findElement(tglbtn_StckorBond_N_xpath).click();
	}
	//Does anyone in this household have other liquid/spendable assets such as cash?
	
	public void Click_Liquid_Y() {
		
		driver.findElement(tglbtn_Liquid_Y_xpath).click();
	}
	
	public void Click_Liquid_N() {
		
		driver.findElement(tglbtn_Liquid_N_xpath).click();
	}
	//Does anyone in this household have a vehicle?
	
	public void Click_Vehicle_Y() {
		
		driver.findElement(tglbtn_Vehicle_Y_xpath).click();
	}
	
	public void Click_Vehicle_N() {
		
		driver.findElement(tglbtn_Vehicle_N_xpath).click();
	}
	
	//Does anyone in this household have a real estate property?

	public void Click_RealEstate_Y() {
		
		driver.findElement(tglbtn_RealEstate_Y_xpath).click();
	}
	
	public void Click_RealEstate_N() {
		
		driver.findElement(tglbtn_RealEstate_N_xpath).click();
	}
	//Does anyone in this household have life insurance?
	
	public void Click_LifeInsurance_Y() {
		
		driver.findElement(tglbtn_LfeIns_Y_xpath).click();
	}
	
	public void Click_LifeInsurance_N() {
		
		driver.findElement(tglbtn_LfeIns_N_xpath).click();
	}
	
    public void ClickNext() {

		driver.findElement(btn_Next_xpath).click();
	}
}
