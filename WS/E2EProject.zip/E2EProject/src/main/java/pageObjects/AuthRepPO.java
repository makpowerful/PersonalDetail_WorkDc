package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import resources.base;

public class AuthRepPO extends base{
	
	public WebDriver driver;

	By btn_AuthRep_xpath = By.xpath("(//button[@type='button'])[3]");
	By btn_Next_xpath= By.xpath("//button[contains(text(),'Next')]");
	
	public AuthRepPO(WebDriver driver) {
		// TODO Auto-generated constructor stub

		this.driver = driver;
	}
	
	public void ClickAuthRepTile() throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,550);");
		Thread.sleep(1000);
		driver.findElement(btn_AuthRep_xpath).click();
	}
	
    
    public void ClickNext() {

		driver.findElement(btn_Next_xpath).click();
	}
}
