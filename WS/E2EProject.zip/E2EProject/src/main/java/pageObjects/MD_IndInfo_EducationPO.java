package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import resources.base;

public class MD_IndInfo_EducationPO extends base{
	
	public WebDriver driver;

	By btn_Next_xpath= By.xpath("//button[contains(text(),'Next')]");
	By btn_Save_xpath= By.xpath("//button[contains(text(),'Save')]");
	By btn_HHM1_xpath= By.xpath("//div[8]/c-ssp-member-section-card/div/div[2]/div/ul/li/div/div[2]/span");
	By btn_HHM2_xpath= By.xpath("//div[8]/c-ssp-member-section-card/div/div[2]/div/ul/li[2]/div/div[2]/span");
	By btn_HHM3_xpath= By.xpath("//div[8]/c-ssp-member-section-card/div/div[2]/div/ul/li[3]/div/div[2]/span");
	By btn_HLOE_xpath= By.xpath("//button");
	By thpl_HLOE_xpath= By.xpath("//input");
	By thpl_HLOE_2G_xpath= By.xpath("//c-ssp-type-ahead-picklist/div/ul/li[2]/div");
	By thpl_HLOE_3G_xpath= By.xpath("//c-ssp-type-ahead-picklist/div/ul/li[3]/div");
	By thpl_HLOE_4G_xpath= By.xpath("//c-ssp-type-ahead-picklist/div/ul/li[4]/div");
	By btn_CE_xpath= By.xpath("//c-ssp-selection-card-without-remove-icon/div/div/div/div[2]/lightning-button/button");
	By thpl_CE_IT_xpath= By.xpath("//div[1]/c-ssp-type-ahead-picklist/div/lightning-input/div/input");
	By thpl_CE_IT_AE_xpath= By.xpath("//c-ssp-type-ahead-picklist/div/ul/li/div");
	By thpl_CE_GL_xpath= By.xpath("//div[2]/c-ssp-type-ahead-picklist/div/lightning-input/div/input");
	By thpl_CE_GL_2G_xpath= By.xpath("//li[2]/div");
	By date_CE_EGD_xpath= By.xpath("//div/div/input");
	By thpl_CE_NOS_xpath= By.xpath("//div[3]/div/c-ssp-type-ahead-picklist/div/lightning-input/div/input");
	By thpl_CE_NOS_GCC_xpath= By.xpath("//li[2]/div");
	By rdbtn_CE_ES_FT_xpath= By.xpath("//span[2]");
	By tglbtn_CE_WSP_N_xpath= By.xpath("//div[1]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label");
	By tglbtn_CE_TAA_N_xpath= By.xpath("//div[2]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label");
	
	public MD_IndInfo_EducationPO(WebDriver driver) {
		// TODO Auto-generated constructor stub

		this.driver = driver;
	}
	
	public void Click_MI_HHM1() throws InterruptedException {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,900);");
		Thread.sleep(2000);
		driver.findElement(btn_HHM1_xpath).click();
	}
	
	public void Click_MI_HHM2() throws InterruptedException {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,1050);");
		Thread.sleep(1000);
		driver.findElement(btn_HHM2_xpath).click();
	}
	
	public void Click_MI_HHM3() throws InterruptedException {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,1150);");
		Thread.sleep(1000);
		driver.findElement(btn_HHM3_xpath).click();
	}
	
	public void Click_HLOE_Start() throws InterruptedException {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,250);");
		Thread.sleep(1000);
		driver.findElement(btn_HLOE_xpath).click();
	}
	
	public void Click_HLOE_SelectGrade() throws InterruptedException {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,250);");
		Thread.sleep(500);
		driver.findElement(thpl_HLOE_xpath).click();
	}
	
	public void Click_HLOE_Select2G() throws InterruptedException {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,250);");
		Thread.sleep(1000);
		driver.findElement(thpl_HLOE_2G_xpath).click();
	}
	
	public void Click_HLOE_Select3G() throws InterruptedException {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,250);");
		Thread.sleep(1000);
		driver.findElement(thpl_HLOE_3G_xpath).click();
	}
	
	public void Click_HLOE_Select4G() throws InterruptedException {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,250);");
		Thread.sleep(1000);
		driver.findElement(thpl_HLOE_4G_xpath).click();
	}
	
	public void Click_CE_Start() throws InterruptedException {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,250);");
		Thread.sleep(1000);
		driver.findElement(btn_CE_xpath).click();
	}
	
	public void Click_CE_IT() throws InterruptedException {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,250);");
		Thread.sleep(1000);
		driver.findElement(thpl_CE_IT_xpath).click();
	}
	
	public void Click_CE_IT_AE() throws InterruptedException {
		
		driver.findElement(thpl_CE_IT_AE_xpath).click();
	}
	
	public void Click_CE_GL() throws InterruptedException {
		
		driver.findElement(thpl_CE_GL_xpath).click();
	}
	
	public void Click_CE_GL_2G() throws InterruptedException {
		
		driver.findElement(thpl_CE_GL_2G_xpath).click();
	}
	
	public void Enter_CE_EGD() {
		
		driver.findElement(date_CE_EGD_xpath).sendKeys("01/01/2022");
	}
	
    public void Click_CE_School() throws InterruptedException {
		
		driver.findElement(thpl_CE_NOS_xpath).click();
	}
	
    public void Click_CE_SchoolGCC() throws InterruptedException {
		
		driver.findElement(thpl_CE_NOS_GCC_xpath).click();
	}
    
    public void Click_CE_FT() throws InterruptedException {
		
		driver.findElement(rdbtn_CE_ES_FT_xpath).click();
	}
	
    public void Click_CE_WSP_N() throws InterruptedException {
		
		driver.findElement(tglbtn_CE_WSP_N_xpath).click();
	}
    
    public void Click_CE_TAA_N() throws InterruptedException {
		
		driver.findElement(tglbtn_CE_TAA_N_xpath).click();
	}
	
	
    public void ClickNext() {

		driver.findElement(btn_Next_xpath).click();
	}

    public void ClickSave() {

		driver.findElement(btn_Save_xpath).click();
	}
}
