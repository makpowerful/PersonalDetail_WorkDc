package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import resources.base;

public class MD_IncSubInfoPO extends base{
	
	public WebDriver driver;

	By btn_Next_xpath= By.xpath("//button[contains(text(),'Next')]");
	By btn_Save_xpath= By.xpath("//button[contains(text(),'Save')]");
	By btn_Accept_Popup_xpath= By.xpath("//lightning-button/button");
	By btn_IncSub_Start_xpath= By.xpath("//div[2]/lightning-button/button");
	By pcklst_TOJI_xpath= By.xpath("//div[2]/c-ssp-base-component-input-picklist/div/select");
	By txt_Emp_Name_xpath= By.xpath("//input");
	By txt_EmpAddr_xpath= By.xpath("//c-ssp-address-auto-complete/div/div/c-ssp-base-component-input-text/div/div/lightning-input/div/input");
	By popup_EmpAddr_xpath= By.xpath("//span/span");
	By txt_EmpAddrL2_xpath= By.xpath("//div[2]/c-ssp-base-component-input-text/div/div/lightning-input/div/input");
	By txt_PriPN_xpath= By.xpath("//c-ssp-base-component-input-phone/div/lightning-input/div/input");
	By date_IncSour_xpath= By.xpath("//div/div/input");
	By pcklst_IncFreq_xpath= By.xpath("//div[7]/c-ssp-base-component-input-picklist/div/select");
	By txt_TaxAvg_xpath= By.xpath("//c-ssp-base-component-input-text-icon/div/div/lightning-input/div/input");
	By txt_HrsWorked_xpath= By.xpath("//c-ssp-base-component-input-number/div/lightning-input/div/input");
	By tglbtn_IncSource_xpath= By.xpath("//span/label"); 
	
	public MD_IncSubInfoPO(WebDriver driver) {
		// TODO Auto-generated constructor stub

		this.driver = driver;
	}
	
	public void Click_AcceptIncomePopup() {
		
		driver.findElement(btn_Accept_Popup_xpath).click();
	}
	
	public void Click_IncSub_Start() {
		
		driver.findElement(btn_IncSub_Start_xpath).click();
	}
	
	public void Select_TypeofJob() throws InterruptedException {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,250);");
		Thread.sleep(1000);
		Select tot = new Select(driver.findElement(pcklst_TOJI_xpath));
		tot.selectByVisibleText("AmeriCorps/VISTA - Living Allowance");
	}
	
	public void Enter_Empl_Name() {
		
		driver.findElement(txt_Emp_Name_xpath).sendKeys("LANTERN");
	}

	public void Enter_EmpAddr() throws InterruptedException {
		
		driver.findElement(txt_EmpAddr_xpath).sendKeys("1237, HARDING PLACE");
		Thread.sleep(2000);
		driver.findElement(popup_EmpAddr_xpath).click();
		
	}
	
    public void Enter_EmpAddrL2() {
		
		driver.findElement(txt_EmpAddrL2_xpath).sendKeys("2ND CROSS");
	}
	
    public void Enter_PriPN() {
		
		driver.findElement(txt_PriPN_xpath).sendKeys("5558239849");
	}
    
    public void Enter_IncomeSourceDate() {
		
		driver.findElement(date_IncSour_xpath).sendKeys("01/01/2020");
	}
    
	public void Select_IncFreq() throws InterruptedException {
		
		Select inf = new Select(driver.findElement(pcklst_IncFreq_xpath));
		inf.selectByVisibleText("Annually");
	}
	
    public void Enter_GrossTaxAverage() {

		driver.findElement(txt_TaxAvg_xpath).sendKeys("100");
	}
    
    public void Enter_HrsWorked() {

		driver.findElement(txt_HrsWorked_xpath).sendKeys("45");
	}
    
    public void Click_IncSource_Y() {

		driver.findElement(tglbtn_IncSource_xpath).click();
	}
	
    public void ClickNext() {

		driver.findElement(btn_Next_xpath).click();
	}

    public void ClickSave() {

		driver.findElement(btn_Save_xpath).click();
	}
}
