package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import resources.base;

public class HHInformation_ExpensePO extends base{
	
	public WebDriver driver;

	By btn_Next_xpath= By.xpath("//button[contains(text(),'Next')]");
	By tglbtn_3Mnths_Y_xpath= By.xpath("//div[1]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_3Mnths_N_xpath= By.xpath("//div[1]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By chkbx_3Mnths_HHM1_xpath= By.xpath("//div[1]/p[2]/c-ssp-base-component-input-checkbox[1]/div/div/lightning-input/div/span/label/span");
	By tglbtn_SE_Y_xpath= By.xpath("//div[2]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_SE_N_xpath= By.xpath("//div[2]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn_UE_Y_xpath= By.xpath("//div[3]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_UE_N_xpath= By.xpath("//div[3]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn_TDE_Y_xpath= By.xpath("//div[4]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_TDE_N_xpath= By.xpath("//div[4]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn_Almny_Y_xpath= By.xpath("//div[5]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_Almny_N_xpath= By.xpath("//div[5]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn_ME_abv60_Y_xpath= By.xpath("//div[6]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_ME_abv60_N_xpath= By.xpath("//div[6]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn_CS_Y_xpath= By.xpath("//div[7]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_CS_N_xpath= By.xpath("//div[7]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	By tglbtn_DC_Y_xpath= By.xpath("//div[8]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[1]/label/span");
	By tglbtn_DC_N_xpath= By.xpath("//div[8]/c-ssp-base-component-input-toggle/div/div/lightning-radio-group/fieldset/div/div/span[2]/label/span");
	
	
	
	public HHInformation_ExpensePO(WebDriver driver) {
		// TODO Auto-generated constructor stub

		this.driver = driver;
	}
	
	//Does anyone in your household need help paying medical bills from the last three months?
	
	public void Click_Mbin3Mnths_Y() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,250);");
		Thread.sleep(1000);
		driver.findElement(tglbtn_3Mnths_Y_xpath).click();
	}

	public void Click_Mbin3Mnths_N() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,250);");
		Thread.sleep(1000);
		driver.findElement(tglbtn_3Mnths_N_xpath).click();
	}
	
	public void Click_Mbin3Mnths_HHM1() {
		
		driver.findElement(chkbx_3Mnths_HHM1_xpath).click();
	}	
	
	//Does anyone in this household have shelter expenses?
	
    public void Click_ShelterE_Y() {
		
		driver.findElement(tglbtn_SE_Y_xpath).click();
	}

	public void Click_ShelterE_N() {
		
		driver.findElement(tglbtn_SE_N_xpath).click();
	}
	
	//Does anyone in this household have utility expenses?
	
    public void Click_UtilityE_Y() {
		
		driver.findElement(tglbtn_UE_Y_xpath).click();
	}

	public void Click_UtilityE_N() {
		
		driver.findElement(tglbtn_UE_N_xpath).click();
	}
	
	//Does anyone in this household have tax deductible expenses?
	
    public void Click_TaxDE_Y() {
		
		driver.findElement(tglbtn_TDE_Y_xpath).click();
	}

	public void Click_TaxDE_N() {
		
		driver.findElement(tglbtn_TDE_N_xpath).click();
	}
	
	//Does anyone in this household pay alimony?
	
    public void Click_Alimony_Y() {
		
		driver.findElement(tglbtn_Almny_Y_xpath).click();
	}

	public void Click_Alimony_N() {
		
		driver.findElement(tglbtn_Almny_N_xpath).click();
	}
	
	//Does anyone in this household have medical expenses for someone who is age 60 or older, blind, or has a disability?
	
    public void Click_MedicalE_60above_Y() {
		
		driver.findElement(tglbtn_ME_abv60_Y_xpath).click();
	}

	public void Click_MedicalE_60above_N() {
		
		driver.findElement(tglbtn_ME_abv60_N_xpath).click();
	}
	
	//Does anyone in this household pay child support?
	
    public void Click_ChildSupp_Y() {
		
		driver.findElement(tglbtn_CS_Y_xpath).click();
	}

	public void Click_ChildSupp_N() {
		
		driver.findElement(tglbtn_CS_N_xpath).click();
	}
	
	//Does anyone in this household pay for child care or other dependent care?
	
    public void Click_ChildC_Y() {
		
		driver.findElement(tglbtn_DC_Y_xpath).click();
	}

	public void Click_ChildC_N() {
		
		driver.findElement(tglbtn_DC_N_xpath).click();
	}
	
    public void ClickNext() {

		driver.findElement(btn_Next_xpath).click();
	}
}
