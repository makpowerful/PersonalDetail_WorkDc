package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import resources.base;

public class MD_OtherInfo_LAPO extends base{
	
	public WebDriver driver;

	By btn_Next_xpath= By.xpath("//button[contains(text(),'Next')]");
	By pcklst_LA_xpath= By.xpath("//select");
	
	public MD_OtherInfo_LAPO(WebDriver driver) {
		// TODO Auto-generated constructor stub

		this.driver = driver;
	}
	
	public void Select_CLA_LIYH() throws InterruptedException {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,250);");
		Thread.sleep(1000);
		Select cla = new Select(driver.findElement(pcklst_LA_xpath));
		cla.selectByVisibleText("Living in your home");
	}
	
	public void Select_CLA_HS() throws InterruptedException {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,250);");
		Thread.sleep(1000);
		Select cla = new Select(driver.findElement(pcklst_LA_xpath));
		cla.selectByVisibleText("Homeless Shelter");
	}
	
    public void ClickNext() {

		driver.findElement(btn_Next_xpath).click();
	}

}
