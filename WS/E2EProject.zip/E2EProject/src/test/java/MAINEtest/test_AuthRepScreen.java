package MAINEtest;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObjects.AuthRepPO;
import pageObjects.ContactPO;
import pageObjects.LoginScreenPO;
import pageObjects.ProgSelectionPO;
import resources.base;

public class test_AuthRepScreen extends base {

	// public WebDriver driver;
	public static Logger log = LogManager.getLogger(test_AuthRepScreen.class.getName());

	@Test
	public void validateAuthRepcreation() throws IOException, InterruptedException {

		// Adding Auth Rep details to the Application
		AuthRepPO ar = new AuthRepPO(driver);
		ar.ClickAuthRepTile();
		log.info("Adding Auth Rep Details to Application");
		Thread.sleep(5000);
		Scrollpagedown();
		ar.ClickNext();
		Thread.sleep(5000);
		Assert.assertEquals(driver.getTitle(), "Application Summary");
		log.info("Auth Rep Details have been added successfully");

	}
}
