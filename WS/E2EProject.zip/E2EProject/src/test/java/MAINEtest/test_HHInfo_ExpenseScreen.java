package MAINEtest;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObjects.HHInformation_AssetPO;
import pageObjects.HHInformation_ExpensePO;
import pageObjects.HHInformation_HHCircumPO;
import pageObjects.HHInformation_HealthPO;
import pageObjects.HHInformation_IncomeandSubPO;
import pageObjects.LoginScreenPO;
import resources.ExcelData;
import resources.base;

public class test_HHInfo_ExpenseScreen extends base {

	// public WebDriver driver;
	public static Logger log = LogManager.getLogger(test_HHInfo_ExpenseScreen.class.getName());

	
	
	
	/*
	 * @BeforeTest public void initialize() throws IOException {
	 * 
	 * driver = initializeDriver(); driver.manage().window().maximize();
	 * log.info("Driver is initialized"); }
	 */
	 
	 
	 
	@Test
	public void validateHHinfoExpense() throws IOException, InterruptedException {

		
		/*
		 * LoginScreenPO ls = new LoginScreenPO(driver);
		 * 
		 * driver.get(
		 * "https://sit-maine.cs32.force.com/benefits/s/signin?language=en_US");
		 * Thread.sleep(6000); ls.ClickAccept(); Thread.sleep(1000); ls.EnterUN();
		 * Thread.sleep(1000); ls.EnterPass(); Thread.sleep(1000); ls.ClickLogin();
		 * Thread.sleep(5000); ls.ClickYes_UseofWbste(); Thread.sleep(5000); driver.get(
		 * "https://sit-maine.cs32.force.com/benefits/s/application-summary?applicationId=a0hr0000001Eg3dAAC"
		 * ); Thread.sleep(5000); HHInformation_HealthPO hpo = new
		 * HHInformation_HealthPO(driver); hpo.ClickStart_HHInfo(); Thread.sleep(5000);
		 */
		 
		 

		// Adding HH information details to the Application
		log.info("Adding Expense Selection details");
		HHInformation_ExpensePO hhe = new HHInformation_ExpensePO(driver);
		hhe.Click_Mbin3Mnths_Y();
		Thread.sleep(1000);
		hhe.Click_Mbin3Mnths_HHM1();
		Thread.sleep(1000);
		hhe.Click_ShelterE_N();
		Thread.sleep(1000);
		hhe.Click_UtilityE_N();
		Thread.sleep(1000);
		hhe.Click_TaxDE_N();
		Thread.sleep(1000);
		hhe.Click_Alimony_N();
		Thread.sleep(1000);
		hhe.Click_MedicalE_60above_N();
		Thread.sleep(1000);
		hhe.Click_ChildSupp_N();
		Thread.sleep(1000);
		hhe.Click_ChildC_N();
		Thread.sleep(1000);
		hhe.ClickNext();
		Thread.sleep(6000);
		Assert.assertEquals(driver.getTitle(), "Application Summary");
		log.info("Expense Selection details have been added successfully");

	}
}
