package MAINEtest;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObjects.HHInformation_AssetPO;
import pageObjects.HHInformation_ExpensePO;
import pageObjects.HHInformation_HHCircumPO;
import pageObjects.HHInformation_HealthPO;
import pageObjects.HHInformation_IncomeandSubPO;
import pageObjects.HealthCareCoverPO;
import pageObjects.LoginScreenPO;
import pageObjects.MD_AssetInfoPO;
import pageObjects.MD_ExpenseInfo_MedicalExpPO;
import pageObjects.MD_HealthInfo_BlindPO;
import pageObjects.MD_IncSubInfoPO;
import pageObjects.MD_IndInfo_AIANPO;
import pageObjects.MD_IndInfo_EducationPO;
import pageObjects.MD_OtherInfo_LAPO;
import pageObjects.MD_OtherInfo_MSFWPO;
import resources.ExcelData;
import resources.base;

public class test_HealthCoverScreen extends base {

	// public WebDriver driver;
	public static Logger log = LogManager.getLogger(test_HealthCoverScreen.class.getName());

	
	/*
	 * @BeforeTest public void initialize() throws IOException {
	 * 
	 * driver = initializeDriver(); driver.manage().window().maximize();
	 * log.info("Driver is initialized"); }
	 */

	@Test
	public void validateHeathCoverSelection() throws IOException, InterruptedException {

		
		/*
		 * LoginScreenPO ls = new LoginScreenPO(driver);
		 * 
		 * driver.get(
		 * "https://sit-maine.cs32.force.com/benefits/s/signin?language=en_US");
		 * Thread.sleep(6000); ls.ClickAccept(); Thread.sleep(1000); ls.EnterUN();
		 * Thread.sleep(1000); ls.EnterPass(); Thread.sleep(1000); ls.ClickLogin();
		 * Thread.sleep(6000); ls.ClickYes_UseofWbste(); Thread.sleep(5000); driver.get(
		 * "https://sit-maine.cs32.force.com/benefits/s/application-summary?applicationId=a0hr0000001EgeJAAS"
		 * ); Thread.sleep(5000);
		 */
		 

		// Adding HealthCare Coverage Details on the Case
		log.info("Adding Health Coverage details");
		HealthCareCoverPO hcc= new HealthCareCoverPO(driver);
		hcc.ClickHealthCTile_Start();
		Thread.sleep(5000);
		hcc.Click_IsEnrolled_HC_N();
		Thread.sleep(1000);
		hcc.Click_IsNotEnrolled_HC_N();
		Thread.sleep(1000);		
		hcc.ClickNext();
		Thread.sleep(5000);
		Assert.assertEquals(driver.getTitle(), "Application Summary");
		log.info("Health Coverage details have been added");

	}
}
