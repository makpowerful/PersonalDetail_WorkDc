package MAINEtest;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObjects.AuthRepPO;
import pageObjects.ContactPO;
import pageObjects.HHInformation_HealthPO;
import pageObjects.LoginScreenPO;
import pageObjects.ProgSelectionPO;
import pageObjects.RelationshipandTaxfillingPO;
import resources.ExcelData;
import resources.base;

public class test_HHInfo_HealthScreen extends base{

	//public WebDriver driver;
	public static Logger log = LogManager.getLogger(test_HHInfo_HealthScreen.class.getName());
	 
	
	@Test
	public void validateHHinfoHealthSelection() throws IOException, InterruptedException {

		
		/*
		 * LoginScreenPO ls = new LoginScreenPO(driver);
		 * 
		 * 
		 * driver.get(
		 * "https://sit-maine.cs32.force.com/benefits/s/signin?language=en_US");
		 * Thread.sleep(6000); ls.ClickAccept(); Thread.sleep(1000); ls.EnterUN();
		 * Thread.sleep(1000); ls.EnterPass(); Thread.sleep(1000); driver.get(
		 * "https://sit-maine.cs32.force.com/benefits/s/application-summary?applicationId=a0hr0000001EfwtAAC"
		 * ); Thread.sleep(5000);
		 */
			
		//Adding HH information details to the Application
		log.info("Adding Household Information details");
		log.info("Adding Health Selection details");
		HHInformation_HealthPO hpo  =  new HHInformation_HealthPO(driver);
		hpo.ClickStart_HHInfo();
		Thread.sleep(5000);
		hpo.Click_Blind_Y();
		Thread.sleep(800);
		hpo.Click_Blind_HHM1();
		Scrollpagedown();
		hpo.Click_LTC_N();
		Thread.sleep(1000);
		hpo.Click_MediCare_Benfit_N();
		Scrollpagedown();
		hpo.Click_Pregnancy_N();
		Thread.sleep(1000);
		hpo.ClickNext();
		Thread.sleep(4000);
		Assert.assertEquals(driver.getTitle(),"Household Information");
		log.info("Health Selection details have been added successfully");
		
	}
}
