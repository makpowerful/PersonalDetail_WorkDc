package MAINEtest;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObjects.HHInformation_AssetPO;
import pageObjects.HHInformation_HHCircumPO;
import pageObjects.HHInformation_HealthPO;
import pageObjects.HHInformation_OAssetPO;
import pageObjects.LoginScreenPO;
import resources.ExcelData;
import resources.base;

public class test_HHInfo_OAssetScreen extends base {

	// public WebDriver driver;
	public static Logger log = LogManager.getLogger(test_HHInfo_OAssetScreen.class.getName());

	
	
	/*
	 * @BeforeTest public void initialize() throws IOException {
	 * 
	 * driver = initializeDriver(); driver.manage().window().maximize();
	 * log.info("Driver is initialized"); }
	 */
	 
	 
	@Test
	public void validateHHinfoHHCircumSelection() throws IOException, InterruptedException {

		
		/*
		 * LoginScreenPO ls = new LoginScreenPO(driver);
		 * 
		 * driver.get(
		 * "https://sit-maine.cs32.force.com/benefits/s/signin?language=en_US");
		 * Thread.sleep(6000); ls.ClickAccept(); Thread.sleep(1000); ls.EnterUN();
		 * Thread.sleep(1000); ls.EnterPass(); Thread.sleep(1000); ls.ClickLogin();
		 * Thread.sleep(5000); ls.ClickYes_UseofWbste(); Thread.sleep(5000); driver.get(
		 * "https://sit-maine.cs32.force.com/benefits/s/application-summary?applicationId=a0hr0000001Eg34AAC"
		 * ); Thread.sleep(5000); HHInformation_HealthPO hpo = new
		 * HHInformation_HealthPO(driver); hpo.ClickStart_HHInfo(); Thread.sleep(5000);
		 */
		 

		// Adding HH information details to the Application
		log.info("Adding Other Asset Selection details");
		HHInformation_OAssetPO hhoa = new HHInformation_OAssetPO(driver);
		hhoa.Click_TrustFund_Y();
		Thread.sleep(1000);
		hhoa.Click_TrustFund_HHM1();
		Thread.sleep(1000);
		hhoa.Click_Annuity_N();
		Thread.sleep(1000);
		hhoa.Click_LifeEstate_N();
		Thread.sleep(1000);
		hhoa.Click_PromiNote_LandContrct_N();
		Thread.sleep(1000);
		hhoa.Click_BurialF_N();
		Thread.sleep(1000);
		hhoa.ClickNext();
		Thread.sleep(4000);
		Assert.assertEquals(driver.getTitle(), "Household Information");
		log.info("Other Asset Selection details have been added successfully");

	}
}
