package MAINEtest;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObjects.HHInformation_HHCircumPO;
import pageObjects.HHInformation_HealthPO;
import pageObjects.LoginScreenPO;
import resources.ExcelData;
import resources.base;

public class test_HHInfo_HHCircumScreen extends base {

	// public WebDriver driver;
	public static Logger log = LogManager.getLogger(test_HHInfo_HHCircumScreen.class.getName());

	
	/*
	 * @BeforeTest public void initialize() throws IOException {
	 * 
	 * driver = initializeDriver(); driver.manage().window().maximize();
	 * log.info("Driver is initialized"); }
	 */
	 
	@Test
	public void validateHHinfoHHCircumSelection() throws IOException, InterruptedException {

		/*
		 * LoginScreenPO ls = new LoginScreenPO(driver);
		 * 
		 * driver.get(
		 * "https://sit-maine.cs32.force.com/benefits/s/signin?language=en_US");
		 * Thread.sleep(6000); ls.ClickAccept(); Thread.sleep(1000); ls.EnterUN();
		 * Thread.sleep(1000); ls.EnterPass(); Thread.sleep(1000); ls.ClickLogin();
		 * Thread.sleep(5000); ls.ClickYes_UseofWbste(); Thread.sleep(5000); driver.get(
		 * "https://sit-maine.cs32.force.com/benefits/s/application-summary?applicationId=a0hr0000001Eg34AAC"
		 * ); Thread.sleep(5000); HHInformation_HealthPO hpo = new
		 * HHInformation_HealthPO(driver); hpo.ClickStart_HHInfo(); Thread.sleep(5000);
		 */

		// Adding HH information details to the Application
		log.info("Adding Household Circumstance Selection details");
		HHInformation_HHCircumPO hhc = new HHInformation_HHCircumPO(driver);
		hhc.Click_Violating_Parole_N();
		Thread.sleep(1000);
		hhc.Click_SNAPorTANF_Benefit_N();
		Thread.sleep(1000);
		hhc.Click_SNAPorTANF_Violation_N();
		Thread.sleep(1000);
		hhc.Click_Seasonal_FW_Y();
		Thread.sleep(1000);
		Scrollpagedown();
		hhc.Click_Seasonal_FW_HHM1();
		Thread.sleep(1000);
		hhc.Click_Rec_lessthan25_FW_N();
		Thread.sleep(1000);
		hhc.Click_Enrollin_School_Y();
		Thread.sleep(1000);
		hhc.Click_Enrollin_School_HHM1();
		Thread.sleep(500);
		Scrollpagedown();
		hhc.Click_FosterCare_N();
		Thread.sleep(1000);
		hhc.Click_SNAP_EmployandTrain_N();
		Thread.sleep(1000);
		hhc.ClickNext();
		Thread.sleep(4000);
		Assert.assertEquals(driver.getTitle(), "Household Information");
		log.info("Household Circumstance Selection details have been added successfully");

	}
}
