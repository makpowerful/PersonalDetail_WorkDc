package MAINEtest;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObjects.DashboardPO;
import pageObjects.GetBenefitPO;
import pageObjects.LoginScreenPO;
import pageObjects.PrimaryAppDetailPO;
import resources.ExcelData;
import resources.base;

public class test_PrimaryAppDetailScreen extends base{

	//public WebDriver driver;
	public static Logger log = LogManager.getLogger(test_PrimaryAppDetailScreen.class.getName());
	ExcelData excelData = new ExcelData();
	ArrayList<String> al = new ArrayList<String>();
	/*
	 * @BeforeTest public void initialize() throws IOException {
	 * 
	 * driver = initializeDriver(); driver.manage().window().maximize();
	 * log.info("Driver is initialized"); driver.get(prop.getProperty("url"));
	 * log.info("Navigated to Home page"); }
	 */
	@Test
	public void validatePriAppDetail() throws IOException, InterruptedException {

		
		PrimaryAppDetailPO pad = new PrimaryAppDetailPO(driver);
		/*
		 * al = excelData.getData("TC1", "Primary Applicant", "Sno");
		 * System.out.println(al.toString()); pad.EnterFN(al.get(1).toString());
		 * Thread.sleep(1000);
		 * 
		 * 
		 * pad.EnterMN(al.get(2).toString()); Thread.sleep(1000);
		 * 
		 * Scrollpagedown();
		 * 
		 * pad.EnterLN(al.get(3).toString()); Thread.sleep(1000);
		 * 
		 * pad.Does_PA_Addr_Y(); Thread.sleep(1000);
		 * 
		 * pad.EnterPA_Add(al.get(4).toString()); Thread.sleep(1000);
		 * 
		 * pad.EnterPA_AddL2(al.get(5).toString()); Thread.sleep(1000);
		 * 
		 * pad.Does_PA_MAddr_N(); Thread.sleep(1000);
		 */
		Thread.sleep(1500);
		Scrollpagedown();
		pad.ClickNext();
		Thread.sleep(6000);
		Assert.assertEquals(driver.getTitle(),"programSelection");
		log.info("User has landed on Program Selection Details screen");
		

	}
}
