package MAINEtest;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObjects.HHInformation_AssetPO;
import pageObjects.HHInformation_ExpensePO;
import pageObjects.HHInformation_HHCircumPO;
import pageObjects.HHInformation_HealthPO;
import pageObjects.HHInformation_IncomeandSubPO;
import pageObjects.LoginScreenPO;
import pageObjects.MD_AssetInfoPO;
import pageObjects.MD_ExpenseInfo_MedicalExpPO;
import pageObjects.MD_HealthInfo_BlindPO;
import pageObjects.MD_IncSubInfoPO;
import pageObjects.MD_IndInfo_AIANPO;
import pageObjects.MD_IndInfo_EducationPO;
import pageObjects.MD_OtherInfo_LAPO;
import pageObjects.MD_OtherInfo_MSFWPO;
import resources.ExcelData;
import resources.base;

public class test_MemDetailsScreen extends base {

	// public WebDriver driver;
	public static Logger log = LogManager.getLogger(test_MemDetailsScreen.class.getName());

	/*
	 * @BeforeTest public void initialize() throws IOException {
	 * 
	 * driver = initializeDriver(); driver.manage().window().maximize();
	 * log.info("Driver is initialized"); }
	 */

	@Test
	public void validateHHinfoExpense() throws IOException, InterruptedException {

		/*
		 * LoginScreenPO ls = new LoginScreenPO(driver);
		 * 
		 * driver.get(
		 * "https://sit-maine.cs32.force.com/benefits/s/signin?language=en_US");
		 * Thread.sleep(6000); ls.ClickAccept(); Thread.sleep(1000); ls.EnterUN();
		 * Thread.sleep(1000); ls.EnterPass(); Thread.sleep(1000); ls.ClickLogin();
		 * Thread.sleep(5000); ls.ClickYes_UseofWbste(); Thread.sleep(5000); driver.get(
		 * "https://sit-maine.cs32.force.com/benefits/s/application-summary?applicationId=a0hr0000001Eg5eAAC"
		 * ); Thread.sleep(5000);
		 */

		// Adding Member Details for HHM1
		log.info("Adding Member details (Individual Information) for HHM1");
		MD_IndInfo_EducationPO epo = new MD_IndInfo_EducationPO(driver);
		epo.Click_MI_HHM1();
		Thread.sleep(10500);
		Scrollpagedown();
		log.info("Adding Highest Level Of Education details for HHM1");
		epo.Click_HLOE_Start();
		Thread.sleep(3000);
		epo.Click_HLOE_SelectGrade();
		Thread.sleep(1000);
		epo.Click_HLOE_Select3G();
		Thread.sleep(1000);
		epo.ClickSave();
		Thread.sleep(3000);
		log.info("Highest Level Of Education details have been added");
		log.info("Adding Current Education details for HHM1");
		Scrollpagedown();
		epo.Click_CE_Start();
		Thread.sleep(3500);
		epo.Click_CE_IT();
		Thread.sleep(1000);
		epo.Click_CE_IT_AE();
		Thread.sleep(1000);
		epo.Click_CE_GL();
		Thread.sleep(1000);
		epo.Click_CE_GL_2G();
		Thread.sleep(1000);
		epo.Enter_CE_EGD();
		Thread.sleep(1000);
		epo.Click_CE_School();
		Thread.sleep(1000);
		epo.Click_CE_SchoolGCC();
		Thread.sleep(1000);
		epo.Click_CE_FT();
		Thread.sleep(1000);
		epo.Click_CE_WSP_N();
		Thread.sleep(1000);
		epo.Click_CE_TAA_N();
		Thread.sleep(1000);
		epo.ClickSave();
		Thread.sleep(3000);
		epo.ClickNext();
		Thread.sleep(4000);
		log.info("Current Education details have been added");
		Assert.assertEquals(driver.getTitle(), "Member Individual Info");
		MD_IndInfo_AIANPO aian = new MD_IndInfo_AIANPO(driver);
		aian.Click_IsInd_MemOfTribe_Y();
		Thread.sleep(1000);
		aian.Click_TypeOfTribe();
		Thread.sleep(1000);
		aian.Click_EverRecServ();
		Thread.sleep(1000);
		aian.Click_EligRecSer();
		Thread.sleep(1000);
		aian.ClickNext();
		Thread.sleep(8000);
		Assert.assertEquals(driver.getTitle(), "Member Health Info");
		log.info("Member details (Individual Information) for HHM1 have been added successfully");

		log.info("Adding Member details (Health Information) for HHM1");
		MD_HealthInfo_BlindPO bl = new MD_HealthInfo_BlindPO(driver);
		Thread.sleep(2000);
		bl.Click_ESRD_N();
		Thread.sleep(1000);
		bl.ClickNext();
		Thread.sleep(8000);

		Assert.assertEquals(driver.getTitle(), "Member Other Information");
		log.info("Member details (Health Information) for HHM1 have been added successfully");
		log.info("Adding Member details (Other Information) for HHM1");

		MD_OtherInfo_LAPO la = new MD_OtherInfo_LAPO(driver);
		la.Select_CLA_LIYH();
		la.ClickNext();
		Thread.sleep(4000);
		MD_OtherInfo_MSFWPO msfw = new MD_OtherInfo_MSFWPO(driver);
		msfw.Click_Job30days_N();
		la.ClickNext();
		Thread.sleep(10000);
		Assert.assertEquals(driver.getTitle(), "Member Resources Info");
		log.info("Member details (Other Information) for HHM1 have been added successfully");
		log.info("Adding Member details (Asset Information) for HHM1");

		MD_AssetInfoPO ai = new MD_AssetInfoPO(driver);
		ai.Click_AcceptAssetPopup();
		Thread.sleep(1500);
		ai.Click_A_Trust_Start();
		Thread.sleep(3000);
		ai.Select_TypeOfTrust();
		Thread.sleep(1000);
		ai.Enter_Trust_NameofBank();
		Thread.sleep(1000);
		ai.Enter_Trust_Value();
		Thread.sleep(1000);
		ai.Click_Estab_Trust();
		Thread.sleep(1000);
		ai.Enter_DateEstab();
		Thread.sleep(1000);
		ai.Click_RecPay_Trust();
		Thread.sleep(1000);
		ai.ClickSave();
		Thread.sleep(3000);
		ai.Click_CA_Start();
		Thread.sleep(3000);
		ai.Select_TypeOfAccount();
		Thread.sleep(1000);
		ai.Enter_CA_NameofBank();
		Thread.sleep(1000);
		ai.Enter_CA_Value();
		Thread.sleep(1000);
		ai.Click_CA_AnotherOwner();
		Thread.sleep(1000);
		ai.ClickSave();
		Thread.sleep(3000);
		ai.ClickNext();
		Thread.sleep(8000);
		Assert.assertEquals(driver.getTitle(), "Member Income Info");
		log.info("Member details (Asset Information) for HHM1 have been added successfully");
		log.info("Adding Member details (Income and subsidies Information) for HHM1");
		MD_IncSubInfoPO is = new MD_IncSubInfoPO(driver);
		is.Click_AcceptIncomePopup();
		Thread.sleep(2000);
		is.Click_IncSub_Start();
		Thread.sleep(3000);
		is.Select_TypeofJob();
		Thread.sleep(1000);
		is.Enter_Empl_Name();
		Thread.sleep(1000);
		is.Enter_EmpAddr();
		Thread.sleep(1000);
		is.Enter_EmpAddrL2();
		Thread.sleep(1000);
		is.Enter_PriPN();
		Thread.sleep(1000);
		is.Enter_IncomeSourceDate();
		Thread.sleep(1000);
		is.Select_IncFreq();
		Thread.sleep(1000);
		is.Enter_GrossTaxAverage();
		Thread.sleep(1000);
		is.Enter_HrsWorked();
		Thread.sleep(1000);
		is.Click_IncSource_Y();
		Thread.sleep(1000);
		is.ClickSave();
		Thread.sleep(3000);
		is.ClickNext();
		Thread.sleep(8000);
		Assert.assertEquals(driver.getTitle(), "Member Expense Info");
		log.info("Member details (Income and subsidies Information) for HHM1 have been added successfully");
		log.info("Adding Member details (Expense Information) for HHM1");
		MD_ExpenseInfo_MedicalExpPO me = new MD_ExpenseInfo_MedicalExpPO(driver);
		me.Select_MedicalBillMonth();
		Thread.sleep(1000);
		me.ClickNext();
		Thread.sleep(7000);
		Assert.assertEquals(driver.getTitle(), "Application Summary");
		log.info("Member details (Expense Information) for HHM1 have been added successfully");

		// Adding Member Details for HHM2
		log.info("Adding Member details (Individual Information) for HHM2");
		epo.Click_MI_HHM2();
		Thread.sleep(5000);
		log.info("Adding Highest Level Of Education details for HHM2");
		epo.Click_HLOE_Start();
		Thread.sleep(3000);
		epo.Click_HLOE_SelectGrade();
		Thread.sleep(1000);
		epo.Click_HLOE_Select2G();
		Thread.sleep(1000);
		epo.ClickSave();
		Thread.sleep(2000);
		log.info("Highest Level Of Education details have been added");
		epo.ClickNext();
		Thread.sleep(7000);
		Assert.assertEquals(driver.getTitle(), "Member Other Information");
		log.info("Member details (Individual Information) for HHM2 have been added successfully");
		log.info("Adding Member details (Other Information) for HHM2");
		la.Select_CLA_HS();
		Thread.sleep(1000);
		la.ClickNext();
		Thread.sleep(7000);
		Assert.assertEquals(driver.getTitle(), "Application Summary");
		log.info("Member details (Other Information) for HHM2 have been added successfully");

		// Adding Member Details for HHM3
		log.info("Adding Member details (Individual Information) for HHM3");
		epo.Click_MI_HHM3();
		Thread.sleep(5000);
		log.info("Adding Highest Level Of Education details for HHM3");
		epo.Click_HLOE_Start();
		Thread.sleep(300);
		epo.Click_HLOE_SelectGrade();
		Thread.sleep(1000);
		epo.Click_HLOE_Select4G();
		Thread.sleep(1000);
		epo.ClickSave();
		Thread.sleep(2000);
		log.info("Highest Level Of Education details have been added");
		epo.ClickNext();
		Thread.sleep(7000);
		Assert.assertEquals(driver.getTitle(), "Member Other Information");
		log.info("Member details (Individual Information) for HHM3 have been added successfully");
		log.info("Adding Member details (Other Information) for HHM3");
		la.Select_CLA_HS();
		Thread.sleep(1000);
		la.ClickNext();
		Thread.sleep(7000);
		Assert.assertEquals(driver.getTitle(), "Application Summary");
		log.info("Member details (Other Information) for HHM3 have been added successfully");

	}
}
