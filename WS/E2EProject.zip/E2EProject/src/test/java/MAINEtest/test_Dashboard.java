package MAINEtest;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObjects.DashboardPO;
import pageObjects.LoginScreenPO;
import resources.base;

public class test_Dashboard extends base{

	//public WebDriver driver;
	public static Logger log = LogManager.getLogger(test_Dashboard.class.getName());
	 
	
	/*
	 * @BeforeTest public void initialize() throws IOException {
	 * 
	 * driver = initializeDriver();
	 * 
	 * 
	 * }
	 */

	//@Test
	//public void navigateToSummary()
	//{
		//DashboardPO db= new DashboardPO();
		//db.clickContinuebtn();
		//log.info("Navigating to dasboard....");
//}
	
	@Test
	public void validateWelcomeScreen() throws IOException, InterruptedException {

		/*
		 * LoginScreenPO ls = new LoginScreenPO(driver);
		 * 
		 * // Click on Login link on Landing Page
		 * 
		 * ls.ClickLoginlink(); Thread.sleep(5000);
		 * log.info("Navigating to User Login Screen.");
		 * 
		 * // Enter Username and Password to login.
		 * 
		 * ls.EnterUsername(); Thread.sleep(1000); ls.Enterpassword();
		 * Thread.sleep(1000); ls.ClickLogin(); Thread.sleep(5000);
		 * log.info("Login has been done successfully");
		 */
		
		DashboardPO db = new DashboardPO(driver);
		Scrollpagedown();
		Scrollpagedown();
		Thread.sleep(1500);
		db.ClickAFB();
		Thread.sleep(6000);
		Assert.assertEquals(driver.getTitle(),"getStartedBenefits");
		log.info("User has landed on Get Started on the Benefits Application screen");

	}
}
