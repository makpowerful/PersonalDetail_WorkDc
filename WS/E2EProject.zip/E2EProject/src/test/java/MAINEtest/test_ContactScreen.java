package MAINEtest;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObjects.ContactPO;
import pageObjects.LoginScreenPO;
import pageObjects.ProgSelectionPO;
import resources.base;

public class test_ContactScreen extends base {

	// public WebDriver driver;
	public static Logger log = LogManager.getLogger(test_ContactScreen.class.getName());

	/*
	 * @BeforeTest public void initialize() throws IOException {
	 * 
	 * driver = initializeDriver(); driver.manage().window().maximize();
	 * log.info("Driver is initialized"); driver.get(prop.getProperty("url"));
	 * log.info("Navigated to Home page"); }
	 */

	@Test
	public void validateContactSelection() throws IOException, InterruptedException {

		// Adding Contact details to members
		ContactPO cs = new ContactPO(driver);
		cs.ClickStartHHM1();
		Thread.sleep(3000);
		log.info("Adding Contact details for HHM1");
		Thread.sleep(10000);
		cs.ClickEmailRdbtn();
		Thread.sleep(1000);
		cs.ClickNext();
		Thread.sleep(3500);
		cs.ClickSameAddYes();
		cs.ClickNext();
		Thread.sleep(5000);
		log.info("Contact details successfully added for HHM1");
		log.info("Adding Contact details for HHM2");
		cs.ClickStartHHM2();
		Thread.sleep(5000);
		cs.ClickSameAsPriChk();
		cs.SelectPrefLangHHM2();
		Thread.sleep(1000);
		cs.ClickNext();
		Thread.sleep(5000);
		Assert.assertEquals(driver.getTitle(), "Application Summary");
		log.info("Contact Details have been added successfully for all members");

	}
}
