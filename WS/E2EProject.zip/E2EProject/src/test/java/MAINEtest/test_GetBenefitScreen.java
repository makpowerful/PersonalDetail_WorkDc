package MAINEtest;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObjects.DashboardPO;
import pageObjects.GetBenefitPO;
import pageObjects.LoginScreenPO;
import resources.base;

public class test_GetBenefitScreen extends base{

	//public WebDriver driver;
	public static Logger log = LogManager.getLogger(test_GetBenefitScreen.class.getName());

	/*
	 * @BeforeTest public void initialize() throws IOException {
	 * 
	 * driver = initializeDriver(); driver.manage().window().maximize();
	 * log.info("Driver is initialized"); driver.get(prop.getProperty("url"));
	 * log.info("Navigated to Home page"); }
	 */
	
	@Test
	public void validateGetBenefit() throws IOException, InterruptedException {

		/*
		 * LoginScreenPO ls = new LoginScreenPO(driver);
		 * 
		 * // Click on Login link on Landing Page
		 * 
		 * ls.ClickLoginlink(); Thread.sleep(5000);
		 * log.info("Navigating to User Login Screen.");
		 * 
		 * // Enter Username and Password to login.
		 * 
		 * ls.EnterUsername(); Thread.sleep(1000); ls.Enterpassword();
		 * Thread.sleep(1000); ls.ClickLogin(); Thread.sleep(5000);
		 * log.info("Login has been done successfully");
		 * 
		 * DashboardPO db = new DashboardPO(driver); Scrollpagedown(); Scrollpagedown();
		 * db.ClickAFB();
		 * log.info("User has landed on Get Started on the Benefits Application screen"
		 * ); Thread.sleep(5000);
		 */
		
		
		GetBenefitPO gb = new GetBenefitPO(driver);
		Scrollend();
		Scrollup();
		gb.ClickSBA();
		Thread.sleep(3000);
		gb.ClicklblWelcome();
		Thread.sleep(1000);
		Scrollend();
		gb.ClickIAgree();
		Thread.sleep(6000);
		Assert.assertEquals(driver.getTitle(),"Primary Applicant Details");
		log.info("User has landed on Primary Applicant Details screen");
		

	}
}
