package MAINEtest;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObjects.ProgSelectionPO;
import resources.base;

public class test_ProgSelectionScreen extends base{

	//public WebDriver driver;
	public static Logger log = LogManager.getLogger(test_ProgSelectionScreen.class.getName());

	/*
	 * @BeforeTest public void initialize() throws IOException {
	 * 
	 * driver = initializeDriver(); driver.manage().window().maximize();
	 * log.info("Driver is initialized"); driver.get(prop.getProperty("url"));
	 * log.info("Navigated to Home page"); }
	 */
	
	@Test
	public void validateProgSelec() throws IOException, InterruptedException {

		/*
		 * LoginScreenPO ls = new LoginScreenPO(driver);
		 * 
		 * // Click on Login link on Landing Page
		 * 
		 * ls.ClickLoginlink(); Thread.sleep(5000);
		 * log.info("Navigating to User Login Screen.");
		 * 
		 * // Enter Username and Password to login.
		 * 
		 * ls.EnterUsername(); Thread.sleep(1000); ls.Enterpassword();
		 * Thread.sleep(1000); ls.ClickLogin(); Thread.sleep(5000);
		 * Assert.assertEquals(driver.getTitle(),"Home");
		 * log.info("Login has been done successfully");
		 * 
		 * DashboardPO db = new DashboardPO(driver); Scrollpagedown(); Scrollpagedown();
		 * db.ClickAFB();
		 * log.info("User has landed on Get Started on the Benefits Application screen"
		 * ); Thread.sleep(5000);
		 * 
		 * 
		 * 
		 * GetBenefitPO gb = new GetBenefitPO(driver); Scrollend(); Scrollup();
		 * gb.ClickSBA(); Thread.sleep(3000); gb.ClicklblWelcome(); Thread.sleep(1000);
		 * Scrollend(); gb.ClickIAgree(); Thread.sleep(3000);
		 * log.info("User has landed on Primary Applicant Details screen");
		 * 
		 * PrimaryAppDetailPO pad = new PrimaryAppDetailPO(driver); Scrollend();
		 * pad.ClickNext(); Thread.sleep(4000);
		 * log.info("User has landed on Program Selection Details screen");
		 */
		ProgSelectionPO ps = new ProgSelectionPO(driver);
		ps.ClickMainCare();
		Thread.sleep(1000);
		ps.ClickSNAP();
		Thread.sleep(1000);
		ps.ClickTANF();
		Thread.sleep(1000);
		ps.ClickNext();
		Thread.sleep(8000);
		Assert.assertEquals(driver.getTitle(),"Application Summary");
		log.info("User has landed on Application Summary after making program selection screen");
		

	}
}
